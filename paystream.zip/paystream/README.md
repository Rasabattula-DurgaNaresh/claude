# PayStream — Instant Payments Platform

LBG / HCLTech Hackathon Challenge | Java 17 · Spring Boot 3 · Apache Kafka · H2

---

## Architecture

```
                     ┌─────────────────────────────┐
POST /api/payments   │     payment-ingestor         │
──────────────────►  │     port 8080                │
                     │  • Bean Validation           │
                     │  • Account existence check   │
                     │  • Idempotency store (H2)    │
                     └─────────────┬───────────────┘
                                   │ PaymentEvent
                                   ▼ payments.submitted (6 partitions)
                     ┌─────────────────────────────┐
                     │     payment-processor        │
                     │     port 8081                │
                     │  • Business rules engine     │
                     │  • Persist to H2             │
                     │  • Live metrics counters     │
                     └─────────────┬───────────────┘
                                   │ PaymentOutcome
                                   ▼ payments.processed (6 partitions)
```

---

## Prerequisites

| Tool    | Version  |
|---------|----------|
| Java    | 17 LTS   |
| Maven   | 3.9+     |
| Docker  | Latest (for Kafka) |

---

## Quick Start

### 1. Start Kafka (Docker)
```bash
docker compose up -d
```
Kafka UI available at http://localhost:8090

### 2. Run payment-ingestor (port 8080)
```bash
cd payment-ingestor
mvn spring-boot:run
```

### 3. Run payment-processor (port 8081)
```bash
cd payment-processor
mvn spring-boot:run
```

### 4. Submit a test payment
```bash
curl -X POST http://localhost:8080/api/payments \
  -H "Content-Type: application/json" \
  -d '{
    "paymentId": "a1b2c3d4-0001-0001-0001-000000000001",
    "debitAccountId": "20-15-88/43917265",
    "creditAccountId": "20-15-88/43917266",
    "amount": "1500.00",
    "currency": "GBP",
    "reference": "INV-001",
    "timestamp": "2024-10-15T09:00:00Z"
  }'
```

### 5. Check outcome
```bash
# Live metrics (in-memory counters)
curl http://localhost:8081/api/metrics/summary

# DB-backed aggregate report
curl http://localhost:8081/api/reports/summary

# Paginated activity with filters
curl "http://localhost:8081/api/reports/activity?status=PROCESSED&page=0&size=10"

# Account payment history
curl http://localhost:8081/api/accounts/20-15-88/43917265/history
```

---

## Import into Eclipse

1. **File → Import → Existing Maven Projects**
2. Browse to `payment-ingestor/` → Finish
3. Repeat for `payment-processor/`
4. Both projects use H2 in-memory DB — no external DB setup needed
5. Run `PaymentIngestorApplication` and `PaymentProcessorApplication` as Spring Boot Apps

**H2 Console** (dev only):
- Ingestor:  http://localhost:8080/h2-console  JDBC URL: `jdbc:h2:mem:ingestordb`
- Processor: http://localhost:8081/h2-console  JDBC URL: `jdbc:h2:mem:processordb`

---

## Running Tests (no Kafka required)

```bash
cd payment-ingestor  && mvn test
cd payment-processor && mvn test
```
Tests use `@EmbeddedKafka` — no Docker needed.

---

## API Reference

### payment-ingestor (port 8080)

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/payments` | Submit payment |
| GET  | `/api/accounts/{id}` | Account lookup |
| GET  | `/actuator/health` | Health check |
| GET  | `/actuator/metrics` | Kafka producer metrics |

### payment-processor (port 8081)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/metrics/summary` | Live counters (in-memory) |
| GET | `/api/reports/summary` | Aggregate DB report |
| GET | `/api/reports/activity` | Paginated outcomes (`?status=` `?accountId=`) |
| GET | `/api/accounts/{id}/history` | Account payment history |
| GET | `/actuator/health` | Health check |

---

## Business Rules

| Condition | Status |
|-----------|--------|
| `amount > £250,000` | `HELD` |
| `debitAccountId == creditAccountId` | `REJECTED` |
| All other valid payments | `PROCESSED` |

---

## Resilience Design

### 1. Concurrency
- **Idempotency store** (`idempotency_records` table with UNIQUE constraint on `payment_id`)  
  Two simultaneous POST requests with the same `paymentId`: one succeeds, the other catches `DataIntegrityViolationException` → **409 Conflict**.
- **AtomicLong counters** in `MetricsCounter` ensure thread-safe updates from 6 concurrent Kafka listener threads.

### 2. Distributed Failures
- **`acks=all`** on Kafka producer: message is durable even if the broker leader crashes after ack.
- **Consumer BATCH ack-mode**: offsets only committed after the full poll batch is persisted to H2. Consumer crash mid-batch replays from last committed offset — no silent payment loss.

### 3. Network Unreliability
- **`retries=3` + `enable.idempotence=true`**: transient broker unavailability (leader re-election, network blip) is retried safely without producing duplicate messages.
- **`auto.offset.reset=earliest`**: consumer restart replays unprocessed messages rather than skipping them.

### 4. Partial Updates
- In the ingestor: idempotency record is saved **before** Kafka publish. If Kafka fails, record is marked `KAFKA_FAILED` — client can retry without getting a false 409.
- In the processor: H2 outcome is persisted in a `@Transactional` block. Kafka publish of `PaymentOutcome` is best-effort — failure is logged but does not roll back the DB record.

### 5. Retries
- Kafka producer retries handled at the infrastructure level (`retries=3`).
- Consumer retries handled by BATCH ack-mode: unhandled exceptions cause the batch to replay from last offset.
- Client-side retries are safe because both services are fully idempotent.

### 6. Observability
- Every payment log line includes `paymentId` for end-to-end tracing across services.
- `/api/metrics/summary` — live counters updated per Kafka message (no DB hit).
- `/api/reports/summary` — DB-backed aggregate for SLA reports.
- `/actuator/health` + `/actuator/metrics` — Spring Boot Actuator for Kafka producer metrics.
- H2 Console available in dev for direct DB inspection.

### 7. Data Consistency
- Services have **independent H2 databases** — no shared state.
- Payment validation (account existence, status) is done atomically with idempotency record write.
- Processor `payment_outcomes` table has UNIQUE constraint on `paymentId` — duplicate Kafka deliveries are safely detected and skipped.

---

## Kafka Configuration Choices

### Producer (`payment-ingestor`)

| Property | Value | Reason |
|----------|-------|--------|
| `acks` | `all` | All ISR replicas must ack — prevents data loss on broker crash |
| `linger.ms` | `5` | Short batch window keeps latency low for real-time payments |
| `compression.type` | `snappy` | Good CPU/ratio trade-off; worthwhile at burst throughput |
| `enable.idempotence` | `true` | Exactly-once per partition on producer retry |

### Consumer (`payment-processor`)

| Property | Value | Reason |
|----------|-------|--------|
| `max.poll.records` | `50` | Prevents session timeout with synchronous DB writes |
| `concurrency` | `6` | Saturates all 6 partitions; higher values are wasteful |
| `auto.offset.reset` | `earliest` | Replay on restart — safer than skipping payments |
| `ack-mode` | `BATCH` | Offsets committed only after full batch persists to H2 |

---

## Project Structure

```
paystream/
├── docker-compose.yml
├── sample-payments.json
├── README.md
├── payment-ingestor/
│   ├── pom.xml
│   └── src/main/java/com/lbg/paystream/ingestor/
│       ├── PaymentIngestorApplication.java
│       ├── config/     KafkaProducerConfig, KafkaTopicConfig
│       ├── controller/ PaymentController
│       ├── dto/        PaymentRequest, PaymentEvent, AccountResponse
│       ├── entity/     AccountEntity, IdempotencyRecord
│       ├── exception/  GlobalExceptionHandler, custom exceptions
│       ├── kafka/      PaymentKafkaProducer
│       ├── loader/     AccountDataLoader
│       ├── repository/ AccountRepository, IdempotencyRepository
│       └── service/    PaymentService
└── payment-processor/
    ├── pom.xml
    └── src/main/java/com/lbg/paystream/processor/
        ├── PaymentProcessorApplication.java
        ├── config/     KafkaConsumerConfig
        ├── controller/ MetricsController, ReportingController
        ├── dto/        PaymentEvent, PaymentOutcome
        ├── entity/     AccountEntity, PaymentOutcomeEntity
        ├── exception/  GlobalExceptionHandler, ResourceNotFoundException
        ├── kafka/      PaymentKafkaConsumer
        ├── loader/     AccountDataLoader
        ├── repository/ AccountRepository, PaymentOutcomeRepository
        └── service/    MetricsCounter, PaymentProcessorService, ReportingService
```
