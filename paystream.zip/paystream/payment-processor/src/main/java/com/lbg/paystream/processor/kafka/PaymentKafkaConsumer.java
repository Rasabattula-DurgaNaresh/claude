package com.lbg.paystream.processor.kafka;

import com.lbg.paystream.processor.dto.PaymentEvent;
import com.lbg.paystream.processor.service.PaymentProcessorService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

/**
 * Kafka consumer for payment-processor.
 *
 * Concurrency: concurrency=6 (configured in application.yml) spins up 6
 * listener threads, one per partition. Each thread independently processes
 * its assigned partitions, giving linear throughput scaling.
 *
 * Retries / Distributed failures:
 * BATCH ack-mode (configured in application.yml) means offsets are committed
 * only after the entire poll batch is processed without exception.
 * If PaymentProcessorService throws an unhandled exception, the batch
 * is retried from the last committed offset — ensuring no payment is skipped.
 *
 * Network unreliability:
 * The consumer group coordinator handles rebalancing on network partition.
 * auto.offset.reset=earliest ensures no messages are skipped on rejoining.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class PaymentKafkaConsumer {

    private final PaymentProcessorService processorService;

    @KafkaListener(
            topics = "payments.submitted",
            groupId = "payment-processor-group",
            containerFactory = "kafkaListenerContainerFactory"
    )
    public void onPaymentSubmitted(
            @Payload PaymentEvent event,
            @Header(KafkaHeaders.RECEIVED_PARTITION) int partition,
            @Header(KafkaHeaders.OFFSET) long offset) {

        log.debug("[Consumer] Received paymentId={} partition={} offset={}",
                event.getPaymentId(), partition, offset);

        try {
            processorService.process(event);
        } catch (Exception e) {
            // Log with full context for observability; rethrow to trigger batch retry
            log.error("[Consumer] Error processing paymentId={} partition={} offset={}: {}",
                    event.getPaymentId(), partition, offset, e.getMessage(), e);
            throw e;
        }
    }
}
