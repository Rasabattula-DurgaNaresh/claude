package com.lbg.paystream.processor.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

/**
 * JPA entity for the payment_outcomes table.
 *
 * Data consistency:
 * The unique constraint on payment_id makes this entity the idempotency
 * store for the consumer. If a Kafka message is redelivered (at-least-once
 * semantics), the second insert attempt catches a DataIntegrityViolationException
 * and the consumer skips without double-counting.
 *
 * Observability:
 * processingTimeMs is stored per row so analysts can identify slow batches
 * or outliers. processedAt enables time-range queries for SLA reporting.
 */
@Entity
@Table(name = "payment_outcomes",
       uniqueConstraints = @UniqueConstraint(columnNames = "payment_id"))
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentOutcomeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "payment_id", nullable = false, unique = true)
    private UUID paymentId;

    @Column(name = "debit_account_id", nullable = false)
    private String debitAccountId;

    @Column(name = "credit_account_id", nullable = false)
    private String creditAccountId;

    @Column(name = "amount", nullable = false, precision = 19, scale = 4)
    private BigDecimal amount;

    @Column(name = "currency", nullable = false, length = 3)
    private String currency;

    /**
     * PROCESSED | HELD | REJECTED
     */
    @Column(name = "status", nullable = false, length = 20)
    private String status;

    @Column(name = "processed_at", nullable = false)
    private Instant processedAt;

    @Column(name = "processing_time_ms", nullable = false)
    private long processingTimeMs;
}
