package com.lbg.paystream.processor.repository;

import com.lbg.paystream.processor.entity.PaymentOutcomeEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface PaymentOutcomeRepository extends JpaRepository<PaymentOutcomeEntity, Long> {

    Optional<PaymentOutcomeEntity> findByPaymentId(UUID paymentId);

    // Reporting: paginated list with optional status and accountId filters
    @Query("SELECT p FROM PaymentOutcomeEntity p " +
           "WHERE (:status IS NULL OR p.status = :status) " +
           "AND (:accountId IS NULL OR p.debitAccountId = :accountId OR p.creditAccountId = :accountId)")
    Page<PaymentOutcomeEntity> findByFilters(
            @Param("status") String status,
            @Param("accountId") String accountId,
            Pageable pageable);

    // Account history: payments involving a specific account, most recent first
    @Query("SELECT p FROM PaymentOutcomeEntity p " +
           "WHERE p.debitAccountId = :accountId OR p.creditAccountId = :accountId " +
           "ORDER BY p.processedAt DESC")
    List<PaymentOutcomeEntity> findByAccountId(@Param("accountId") String accountId);

    // Aggregate summary queries
    @Query("SELECT COUNT(p) FROM PaymentOutcomeEntity p WHERE p.status = :status")
    long countByStatus(@Param("status") String status);

    @Query("SELECT COALESCE(SUM(p.amount), 0) FROM PaymentOutcomeEntity p WHERE p.status = 'PROCESSED'")
    java.math.BigDecimal sumProcessedAmount();

    @Query("SELECT MIN(p.processedAt) FROM PaymentOutcomeEntity p")
    java.time.Instant findEarliestProcessedAt();

    @Query("SELECT MAX(p.processedAt) FROM PaymentOutcomeEntity p")
    java.time.Instant findLatestProcessedAt();

    @Query("SELECT COALESCE(AVG(p.processingTimeMs), 0) FROM PaymentOutcomeEntity p")
    double avgProcessingTimeMs();
}
