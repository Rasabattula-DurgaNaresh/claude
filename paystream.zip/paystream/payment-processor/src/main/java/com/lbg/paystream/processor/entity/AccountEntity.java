package com.lbg.paystream.processor.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * Account entity for payment-processor H2 database.
 * Seeded from accounts.json at startup.
 * Used to enrich reporting responses with accountName.
 * Services do NOT share a database — each has its own H2 instance.
 */
@Entity
@Table(name = "accounts")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AccountEntity {

    @Id
    @Column(name = "account_id")
    private String accountId;

    @Column(name = "account_name")
    private String accountName;

    @Column(name = "account_type")
    private String accountType;

    @Column(name = "status")
    private String status;

    @Column(name = "currency", length = 3)
    private String currency;

    @Column(name = "opened_date")
    private LocalDate openedDate;
}
