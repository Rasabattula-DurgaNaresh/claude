package com.lbg.paystream.processor.service;

import com.lbg.paystream.processor.entity.AccountEntity;
import com.lbg.paystream.processor.entity.PaymentOutcomeEntity;
import com.lbg.paystream.processor.repository.AccountRepository;
import com.lbg.paystream.processor.repository.PaymentOutcomeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.*;

/**
 * Provides DB-backed reporting and account history queries.
 *
 * Observability gaps addressed:
 * - /api/reports/summary gives a single-call aggregate view (counts by status,
 *   total amounts, date range) so operations teams can assess platform health
 *   without writing SQL or reading Kafka topics directly.
 * - /api/accounts/{id}/history allows customer-service teams to look up all
 *   payments for an account without touching the Kafka topic.
 */
@Service
@RequiredArgsConstructor
public class ReportingService {

    private final PaymentOutcomeRepository outcomeRepository;
    private final AccountRepository accountRepository;

    /**
     * Aggregate summary from payment_outcomes table.
     */
    public Map<String, Object> getSummary() {
        long processed = outcomeRepository.countByStatus("PROCESSED");
        long held      = outcomeRepository.countByStatus("HELD");
        long rejected  = outcomeRepository.countByStatus("REJECTED");
        BigDecimal totalAmount = outcomeRepository.sumProcessedAmount();
        Instant earliest = outcomeRepository.findEarliestProcessedAt();
        Instant latest   = outcomeRepository.findLatestProcessedAt();

        Map<String, Object> summary = new LinkedHashMap<>();
        summary.put("totalProcessed", processed);
        summary.put("totalHeld",      held);
        summary.put("totalRejected",  rejected);
        summary.put("totalRecords",   processed + held + rejected);
        summary.put("totalProcessedAmount", totalAmount);
        summary.put("dateRangeFrom",  earliest);
        summary.put("dateRangeTo",    latest);
        return summary;
    }

    /**
     * Paginated activity list with optional status and accountId filters.
     */
    public Map<String, Object> getActivity(String status, String accountId, int page, int size) {
        Page<PaymentOutcomeEntity> resultPage = outcomeRepository.findByFilters(
                status, accountId,
                PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "processedAt"))
        );

        List<Map<String, Object>> rows = resultPage.getContent()
                .stream()
                .map(this::toRow)
                .toList();

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("page",          resultPage.getNumber());
        result.put("size",          resultPage.getSize());
        result.put("totalElements", resultPage.getTotalElements());
        result.put("totalPages",    resultPage.getTotalPages());
        result.put("content",       rows);
        return result;
    }

    /**
     * Payment history for a specific account (debit or credit side).
     */
    public List<Map<String, Object>> getAccountHistory(String accountId) {
        return outcomeRepository.findByAccountId(accountId)
                .stream()
                .map(this::toEnrichedRow)
                .toList();
    }

    // ── helpers ──────────────────────────────────────────────────────────────

    private Map<String, Object> toRow(PaymentOutcomeEntity e) {
        Map<String, Object> row = new LinkedHashMap<>();
        row.put("paymentId",       e.getPaymentId());
        row.put("debitAccountId",  e.getDebitAccountId());
        row.put("creditAccountId", e.getCreditAccountId());
        row.put("amount",          e.getAmount());
        row.put("currency",        e.getCurrency());
        row.put("status",          e.getStatus());
        row.put("processedAt",     e.getProcessedAt());
        row.put("processingTimeMs", e.getProcessingTimeMs());
        return row;
    }

    private Map<String, Object> toEnrichedRow(PaymentOutcomeEntity e) {
        Map<String, Object> row = toRow(e);
        // Enrich with account name for reporting (spec requirement)
        accountRepository.findById(e.getDebitAccountId())
                .map(AccountEntity::getAccountName)
                .ifPresent(name -> row.put("debitAccountName", name));
        accountRepository.findById(e.getCreditAccountId())
                .map(AccountEntity::getAccountName)
                .ifPresent(name -> row.put("creditAccountName", name));
        return row;
    }
}
