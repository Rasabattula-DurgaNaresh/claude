package com.lbg.paystream.processor.controller;

import com.lbg.paystream.processor.service.MetricsCounter;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Exposes live in-memory counters — no DB hit required.
 * Updated in real-time by the Kafka listener threads via AtomicLong.
 *
 * GET /api/metrics/summary
 */
@RestController
@RequestMapping("/api/metrics")
@RequiredArgsConstructor
public class MetricsController {

    private final MetricsCounter metricsCounter;

    @GetMapping("/summary")
    public ResponseEntity<Map<String, Object>> summary() {
        Map<String, Object> metrics = new LinkedHashMap<>();
        metrics.put("totalProcessed",       metricsCounter.getTotalProcessed());
        metrics.put("totalHeld",            metricsCounter.getTotalHeld());
        metrics.put("totalRejected",        metricsCounter.getTotalRejected());
        metrics.put("avgProcessingTimeMs",  metricsCounter.getAvgProcessingTimeMs());
        return ResponseEntity.ok(metrics);
    }
}
