package com.lbg.paystream.processor.service;

import org.springframework.stereotype.Component;

import java.util.concurrent.atomic.AtomicLong;

/**
 * Thread-safe in-memory counters for live metrics.
 *
 * Concurrency challenge addressed:
 * The @KafkaListener runs on multiple threads (concurrency=6).
 * Standard long++ is NOT thread-safe. AtomicLong uses CAS operations,
 * ensuring accurate counts even with concurrent partition processing.
 *
 * Note: These counters reset on service restart (in-memory only).
 * For persistent metrics use the /api/reports/summary DB-backed endpoint.
 *
 * Observability:
 * Exposed via GET /api/metrics/summary for real-time throughput monitoring
 * without hitting the database.
 */
@Component
public class MetricsCounter {

    private final AtomicLong totalProcessed  = new AtomicLong(0);
    private final AtomicLong totalHeld       = new AtomicLong(0);
    private final AtomicLong totalRejected   = new AtomicLong(0);
    private final AtomicLong totalTimeMs     = new AtomicLong(0);
    private final AtomicLong totalMessages   = new AtomicLong(0);

    public void recordProcessed(long processingTimeMs) {
        totalProcessed.incrementAndGet();
        totalMessages.incrementAndGet();
        totalTimeMs.addAndGet(processingTimeMs);
    }

    public void recordHeld(long processingTimeMs) {
        totalHeld.incrementAndGet();
        totalMessages.incrementAndGet();
        totalTimeMs.addAndGet(processingTimeMs);
    }

    public void recordRejected(long processingTimeMs) {
        totalRejected.incrementAndGet();
        totalMessages.incrementAndGet();
        totalTimeMs.addAndGet(processingTimeMs);
    }

    public long getTotalProcessed()  { return totalProcessed.get(); }
    public long getTotalHeld()       { return totalHeld.get(); }
    public long getTotalRejected()   { return totalRejected.get(); }

    public double getAvgProcessingTimeMs() {
        long msgs = totalMessages.get();
        return msgs == 0 ? 0.0 : (double) totalTimeMs.get() / msgs;
    }
}
