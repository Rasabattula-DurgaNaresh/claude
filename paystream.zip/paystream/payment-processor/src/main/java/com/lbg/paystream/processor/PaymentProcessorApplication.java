package com.lbg.paystream.processor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * PayStream Payment Processor Service
 * Port: 8081
 *
 * Responsibilities:
 * - Consumes PaymentEvents from Kafka topic: payments.submitted
 * - Applies business rules (PROCESSED / HELD based on amount threshold)
 * - Persists PaymentOutcomeEntity to H2 for reporting
 * - Publishes PaymentOutcome to Kafka topic: payments.processed
 * - Exposes reporting and metrics endpoints
 *
 * Key resilience features:
 * - Idempotent consumer: duplicate Kafka deliveries are safely detected via
 *   unique paymentId constraint in payment_outcomes
 * - Concurrent listener threads (6) matching partition count for max throughput
 * - BATCH ack-mode prevents offset commit before DB persistence succeeds
 * - Thread-safe in-memory counters (AtomicLong) for live metrics
 */
@SpringBootApplication
public class PaymentProcessorApplication {
    public static void main(String[] args) {
        SpringApplication.run(PaymentProcessorApplication.class, args);
    }
}
