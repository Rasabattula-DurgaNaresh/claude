package com.lbg.paystream.processor.loader;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.lbg.paystream.processor.entity.AccountEntity;
import com.lbg.paystream.processor.repository.AccountRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.util.List;

/**
 * Seeds the H2 accounts table from accounts.json at startup.
 * Used by the processor to enrich payment outcomes with accountName in reports.
 * Independent copy from ingestor — services do not share data.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class AccountDataLoader implements CommandLineRunner {

    private final AccountRepository accountRepository;

    @Override
    public void run(String... args) throws Exception {
        if (accountRepository.count() > 0) {
            log.info("[DataLoader] Processor accounts already loaded.");
            return;
        }
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());

        try (InputStream is = new ClassPathResource("accounts.json").getInputStream()) {
            List<AccountEntity> accounts = mapper.readValue(is, new TypeReference<>() {});
            accountRepository.saveAll(accounts);
            log.info("[DataLoader] Loaded {} accounts into H2 (processor).", accounts.size());
        } catch (Exception e) {
            log.error("[DataLoader] Failed to load accounts.json in processor: {}", e.getMessage(), e);
            throw e;
        }
    }
}
