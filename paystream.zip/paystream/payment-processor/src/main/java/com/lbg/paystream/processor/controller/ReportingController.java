package com.lbg.paystream.processor.controller;

import com.lbg.paystream.processor.service.ReportingService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * DB-backed reporting endpoints for payment-processor (port 8081).
 *
 * GET /api/reports/summary          – aggregate counts + total amounts
 * GET /api/reports/activity         – paginated list, optional ?status= & ?accountId=
 * GET /api/accounts/{id}/history    – all outcomes for an account (debit or credit)
 *
 * Observability gaps addressed:
 * These endpoints let operations and analytics teams query payment history
 * and aggregate stats without direct DB access or Kafka topic consumption.
 */
@Slf4j
@RestController
@RequiredArgsConstructor
public class ReportingController {

    private final ReportingService reportingService;

    /**
     * GET /api/reports/summary
     * Aggregate counts by status, total processed amount, and date range.
     */
    @GetMapping("/api/reports/summary")
    public ResponseEntity<Map<String, Object>> summary() {
        return ResponseEntity.ok(reportingService.getSummary());
    }

    /**
     * GET /api/reports/activity
     * Paginated payment outcomes with optional filters.
     *
     * @param status    optional: PROCESSED | HELD | REJECTED
     * @param accountId optional: filter by debit or credit account
     * @param page      zero-based page number (default 0)
     * @param size      page size (default 20)
     */
    @GetMapping("/api/reports/activity")
    public ResponseEntity<Map<String, Object>> activity(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String accountId,
            @RequestParam(defaultValue = "0")  int page,
            @RequestParam(defaultValue = "20") int size) {

        log.debug("[Reports] activity status={} accountId={} page={} size={}",
                status, accountId, page, size);
        return ResponseEntity.ok(reportingService.getActivity(status, accountId, page, size));
    }

    /**
     * GET /api/accounts/{accountId}/history
     * All payment outcomes where the account appears as debit OR credit.
     * Results ordered most-recent first.
     */
    @GetMapping("/api/accounts/{accountId}/history")
    public ResponseEntity<List<Map<String, Object>>> accountHistory(
            @PathVariable String accountId) {

        log.debug("[Reports] account history for {}", accountId);
        return ResponseEntity.ok(reportingService.getAccountHistory(accountId));
    }
}
