package com.lbg.paystream.processor.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

/**
 * Kafka message published to topic: payments.processed
 * Contains the result of applying business rules to a PaymentEvent.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentOutcome {
    private UUID paymentId;
    private String debitAccountId;
    private String creditAccountId;
    private BigDecimal amount;
    private String currency;
    private String status;          // PROCESSED | HELD | REJECTED
    private Instant processedAt;
    private long processingTimeMs;
}
