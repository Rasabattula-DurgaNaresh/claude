package com.lbg.paystream.processor.service;

import com.lbg.paystream.processor.dto.PaymentEvent;
import com.lbg.paystream.processor.dto.PaymentOutcome;
import com.lbg.paystream.processor.entity.PaymentOutcomeEntity;
import com.lbg.paystream.processor.repository.PaymentOutcomeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;

/**
 * Applies business rules to incoming PaymentEvents and persists outcomes.
 *
 * Challenges addressed:
 *
 * 1. DATA CONSISTENCY (Partial Updates):
 *    The outcome is persisted to H2 INSIDE a @Transactional block BEFORE
 *    publishing to Kafka. If the Kafka publish fails, the DB row still exists
 *    (status recorded). If the DB write fails, neither the DB nor Kafka is updated.
 *    This avoids the "phantom payment" scenario where Kafka has a PROCESSED event
 *    but no DB record for reporting.
 *
 * 2. CONCURRENCY (Duplicate Kafka deliveries):
 *    Kafka provides at-least-once delivery. On consumer restart, the same message
 *    may be redelivered. The UNIQUE constraint on payment_id catches this:
 *    DataIntegrityViolationException → skip silently, log, don't update counters.
 *
 * 3. DISTRIBUTED FAILURES (Kafka publish after DB write):
 *    If Kafka publish for payments.processed fails, the outcome is still in H2.
 *    The consumer does NOT rethrow — allowing the batch to commit.
 *    A separate reconciliation process (not in scope) can re-publish from H2.
 *
 * 4. RETRIES:
 *    The @KafkaListener (via BATCH ack-mode) will retry the entire batch on
 *    unhandled exceptions. To prevent infinite retry loops, DB
 *    DataIntegrityViolationException (duplicate) is caught and swallowed.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class PaymentProcessorService {

    private static final BigDecimal HOLD_THRESHOLD = new BigDecimal("250000");
    private static final String TOPIC_PROCESSED    = "payments.processed";

    private final PaymentOutcomeRepository outcomeRepository;
    private final KafkaTemplate<String, PaymentOutcome> outcomeKafkaTemplate;
    private final MetricsCounter metricsCounter;

    /**
     * Process a single payment event:
     * 1. Apply business rule → determine status
     * 2. Persist outcome to H2 (idempotent via unique constraint)
     * 3. Publish PaymentOutcome to payments.processed
     * 4. Update in-memory metrics counters
     */
    @Transactional
    public void process(PaymentEvent event) {
        long startMs = System.currentTimeMillis();

        String status = determineStatus(event);

        PaymentOutcomeEntity entity = PaymentOutcomeEntity.builder()
                .paymentId(event.getPaymentId())
                .debitAccountId(event.getDebitAccountId())
                .creditAccountId(event.getCreditAccountId())
                .amount(event.getAmount())
                .currency(event.getCurrency())
                .status(status)
                .processedAt(Instant.now())
                .processingTimeMs(System.currentTimeMillis() - startMs)
                .build();

        try {
            outcomeRepository.save(entity);
        } catch (DataIntegrityViolationException e) {
            // Duplicate Kafka delivery — outcome already persisted. Skip safely.
            log.warn("[Processor] Duplicate delivery detected, skipping paymentId={}",
                    event.getPaymentId());
            return;
        }

        long processingTimeMs = System.currentTimeMillis() - startMs;
        entity.setProcessingTimeMs(processingTimeMs);
        outcomeRepository.save(entity);

        // Publish outcome to payments.processed (best-effort; failure logged, not rethrown)
        PaymentOutcome outcome = PaymentOutcome.builder()
                .paymentId(event.getPaymentId())
                .debitAccountId(event.getDebitAccountId())
                .creditAccountId(event.getCreditAccountId())
                .amount(event.getAmount())
                .currency(event.getCurrency())
                .status(status)
                .processedAt(entity.getProcessedAt())
                .processingTimeMs(processingTimeMs)
                .build();

        try {
            outcomeKafkaTemplate.send(TOPIC_PROCESSED, event.getDebitAccountId(), outcome);
        } catch (Exception e) {
            log.error("[Processor] Failed to publish outcome for paymentId={}: {}",
                    event.getPaymentId(), e.getMessage());
            // Do NOT rethrow — DB record is persisted; don't poison the batch
        }

        // Update live counters (thread-safe AtomicLong)
        switch (status) {
            case "PROCESSED" -> metricsCounter.recordProcessed(processingTimeMs);
            case "HELD"      -> metricsCounter.recordHeld(processingTimeMs);
            case "REJECTED"  -> metricsCounter.recordRejected(processingTimeMs);
        }

        log.info("[Processor] paymentId={} status={} amount={} processingTimeMs={}",
                event.getPaymentId(), status, event.getAmount(), processingTimeMs);
    }

    /**
     * Business rules:
     * - amount > £250,000 → HELD (requires manual review)
     * - debitAccountId == creditAccountId → REJECTED (same-account transfer)
     * - all other valid payments → PROCESSED
     */
    private String determineStatus(PaymentEvent event) {
        if (event.getDebitAccountId().equals(event.getCreditAccountId())) {
            return "REJECTED";
        }
        if (event.getAmount().compareTo(HOLD_THRESHOLD) > 0) {
            return "HELD";
        }
        return "PROCESSED";
    }
}
