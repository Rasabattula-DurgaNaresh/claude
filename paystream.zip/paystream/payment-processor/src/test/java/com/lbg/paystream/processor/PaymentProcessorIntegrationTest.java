package com.lbg.paystream.processor;

import com.lbg.paystream.processor.dto.PaymentEvent;
import com.lbg.paystream.processor.entity.PaymentOutcomeEntity;
import com.lbg.paystream.processor.repository.PaymentOutcomeRepository;
import com.lbg.paystream.processor.service.MetricsCounter;
import com.lbg.paystream.processor.service.PaymentProcessorService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integration tests for payment-processor.
 *
 * Tests cover:
 * - PROCESSED status for normal payments
 * - HELD status for payments exceeding £250,000
 * - REJECTED for same-account transfers
 * - Duplicate Kafka delivery handled safely (idempotent consumer)
 * - In-memory metrics counters updated correctly
 * - Reporting endpoints return expected structure
 */
@SpringBootTest
@AutoConfigureMockMvc
@DirtiesContext
@EmbeddedKafka(partitions = 6, topics = {"payments.submitted", "payments.processed"})
class PaymentProcessorIntegrationTest {

    @Autowired PaymentProcessorService processorService;
    @Autowired PaymentOutcomeRepository outcomeRepository;
    @Autowired MetricsCounter metricsCounter;
    @Autowired MockMvc mockMvc;

    @BeforeEach
    void clean() {
        outcomeRepository.deleteAll();
    }

    // ── Business rules ────────────────────────────────────────────────────────

    @Test
    void normalPayment_persistedAsProcessed() {
        PaymentEvent event = event("20-15-88/43917265", "20-15-88/43917266",
                new BigDecimal("500.00"));
        processorService.process(event);

        Optional<PaymentOutcomeEntity> saved = outcomeRepository.findByPaymentId(event.getPaymentId());
        assertThat(saved).isPresent();
        assertThat(saved.get().getStatus()).isEqualTo("PROCESSED");
    }

    @Test
    void largePayment_persistedAsHeld() {
        PaymentEvent event = event("20-15-88/43917265", "20-15-88/43917266",
                new BigDecimal("300000.00"));
        processorService.process(event);

        assertThat(outcomeRepository.findByPaymentId(event.getPaymentId()))
                .isPresent()
                .hasValueSatisfying(e -> assertThat(e.getStatus()).isEqualTo("HELD"));
    }

    @Test
    void sameAccountTransfer_persistedAsRejected() {
        PaymentEvent event = event("20-15-88/43917265", "20-15-88/43917265",
                new BigDecimal("100.00"));
        processorService.process(event);

        assertThat(outcomeRepository.findByPaymentId(event.getPaymentId()))
                .isPresent()
                .hasValueSatisfying(e -> assertThat(e.getStatus()).isEqualTo("REJECTED"));
    }

    // ── Idempotency (duplicate Kafka delivery) ────────────────────────────────

    @Test
    void duplicateKafkaDelivery_onlyOneRowPersisted() {
        PaymentEvent event = event("20-15-88/43917265", "20-15-88/43917266",
                new BigDecimal("750.00"));

        processorService.process(event); // first delivery
        processorService.process(event); // duplicate — should be silently skipped

        long count = outcomeRepository.findAll().stream()
                .filter(e -> e.getPaymentId().equals(event.getPaymentId()))
                .count();
        assertThat(count).isEqualTo(1);
    }

    // ── Metrics counters ─────────────────────────────────────────────────────

    @Test
    void metricsCountersUpdatedCorrectly() {
        long beforeProcessed = metricsCounter.getTotalProcessed();
        long beforeHeld      = metricsCounter.getTotalHeld();

        processorService.process(event("20-15-88/43917265", "20-15-88/43917266",
                new BigDecimal("200.00")));
        processorService.process(event("20-15-88/43917265", "20-15-88/43917266",
                new BigDecimal("500000.00")));

        assertThat(metricsCounter.getTotalProcessed()).isEqualTo(beforeProcessed + 1);
        assertThat(metricsCounter.getTotalHeld()).isEqualTo(beforeHeld + 1);
    }

    // ── Reporting endpoints ───────────────────────────────────────────────────

    @Test
    void metricsSummaryEndpoint_returns200() throws Exception {
        mockMvc.perform(get("/api/metrics/summary"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalProcessed").exists())
                .andExpect(jsonPath("$.totalHeld").exists())
                .andExpect(jsonPath("$.avgProcessingTimeMs").exists());
    }

    @Test
    void reportsSummaryEndpoint_returns200() throws Exception {
        mockMvc.perform(get("/api/reports/summary"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalRecords").exists());
    }

    @Test
    void reportsActivityEndpoint_paginated() throws Exception {
        processorService.process(event("20-15-88/43917265", "20-15-88/43917266",
                new BigDecimal("100.00")));

        mockMvc.perform(get("/api/reports/activity?page=0&size=10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalElements").exists())
                .andExpect(jsonPath("$.content").isArray());
    }

    @Test
    void accountHistoryEndpoint_returns200() throws Exception {
        processorService.process(event("20-15-88/43917265", "20-15-88/43917266",
                new BigDecimal("50.00")));

        mockMvc.perform(get("/api/accounts/20-15-88/43917265/history"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray());
    }

    // ── helpers ───────────────────────────────────────────────────────────────

    private PaymentEvent event(String debit, String credit, BigDecimal amount) {
        return PaymentEvent.builder()
                .paymentId(UUID.randomUUID())
                .debitAccountId(debit)
                .creditAccountId(credit)
                .amount(amount)
                .currency("GBP")
                .reference("TEST-REF")
                .timestamp(Instant.now().minusSeconds(1))
                .ingestedAt(Instant.now())
                .build();
    }
}
