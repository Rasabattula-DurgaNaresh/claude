package com.lbg.paystream.ingestor.exception;

/**
 * Thrown when an account is not found in the H2 accounts table.
 * Maps to HTTP 404.
 */
public class AccountNotFoundException extends RuntimeException {
    public AccountNotFoundException(String accountId, String role) {
        super(role + " account not found: " + accountId);
    }
}
