package com.lbg.paystream.ingestor.kafka;

import com.lbg.paystream.ingestor.dto.PaymentEvent;
import com.lbg.paystream.ingestor.loader.AccountDataLoader;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;

/**
 * Publishes PaymentEvents to the Kafka topic: payments.submitted
 *
 * Partition key = debitAccountId ensures ordering: all payments from the
 * same debit account land on the same partition and are processed in order.
 *
 * Network unreliability / Retries:
 * KafkaTemplate.send() is async. We attach a callback to log send failures
 * for observability. The producer's retry configuration (retries=3, acks=all)
 * handles transient broker failures transparently.
 *
 * Distributed failure handling:
 * If the broker is completely unavailable, the send future fails. The
 * service layer catches this and marks the idempotency record as KAFKA_FAILED
 * so operators can requeue without risk of duplicate processing.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class PaymentKafkaProducer {
    private static final String TOPIC = "payments.submitted";
	private static final Logger log = LoggerFactory.getLogger(AccountDataLoader.class);


    private  KafkaTemplate<String, PaymentEvent> kafkaTemplate;

    public CompletableFuture<SendResult<String, PaymentEvent>> publish(PaymentEvent event) {
        String partitionKey = event.getDebitAccountId(); // preserves per-account ordering

        log.info("[Producer] Publishing paymentId={} debitAccount={} amount={} {}",
                event.getPaymentId(), event.getDebitAccountId(),
                event.getAmount(), event.getCurrency());

        CompletableFuture<SendResult<String, PaymentEvent>> future =
                kafkaTemplate.send(TOPIC, partitionKey, event);

        future.whenComplete((result, ex) -> {
            if (ex != null) {
                // Observability: log with paymentId so the failure is traceable
                log.error("[Producer] FAILED to send paymentId={} error={}",
                        event.getPaymentId(), ex.getMessage());
            } else {
                log.debug("[Producer] Sent paymentId={} partition={} offset={}",
                        event.getPaymentId(),
                        result.getRecordMetadata().partition(),
                        result.getRecordMetadata().offset());
            }
        });

        return future;
    }
}
