package com.lbg.paystream.ingestor.service;

import com.lbg.paystream.ingestor.dto.AccountResponse;
import com.lbg.paystream.ingestor.dto.PaymentEvent;
import com.lbg.paystream.ingestor.dto.PaymentRequest;
import com.lbg.paystream.ingestor.entity.AccountEntity;
import com.lbg.paystream.ingestor.entity.IdempotencyRecord;
import com.lbg.paystream.ingestor.exception.AccountNotFoundException;
import com.lbg.paystream.ingestor.exception.AccountSuspendedException;
import com.lbg.paystream.ingestor.exception.DuplicatePaymentException;
import com.lbg.paystream.ingestor.kafka.PaymentKafkaProducer;
import com.lbg.paystream.ingestor.loader.AccountDataLoader;
import com.lbg.paystream.ingestor.repository.AccountRepository;
import com.lbg.paystream.ingestor.repository.IdempotencyRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

/**
 * Core service for the payment-ingestor microservice.
 *
 * Challenges addressed in this class:
 *
 * 1. CONCURRENCY – Two simultaneous requests with the same paymentId.
 *    The idempotency record is saved inside a @Transactional method.
 *    The UNIQUE constraint on payment_id means only ONE write can succeed;
 *    the second thread catches DataIntegrityViolationException → 409.
 *
 * 2. PARTIAL UPDATES – What if we save the idempotency record but Kafka publish fails?
 *    We catch the Kafka failure and update the idempotency record status to
 *    KAFKA_FAILED. The client gets a 503 and can retry. The duplicate check
 *    is relaxed for KAFKA_FAILED records so the client retry is allowed through.
 *
 * 3. DATA CONSISTENCY – Validation (account existence, status) is done inside
 *    the same transaction as the idempotency record write, ensuring we never
 *    publish to Kafka a payment for a non-existent or suspended account.
 *
 * 4. NETWORK UNRELIABILITY – Kafka send is async with retry configured at the
 *    producer level. The service waits for the CompletableFuture to complete
 *    before returning 202, guaranteeing the message reached the broker.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class PaymentService {

    private  AccountRepository accountRepository;
    private  IdempotencyRepository idempotencyRepository;
    private PaymentKafkaProducer kafkaProducer;
    
	private static final Logger log = LoggerFactory.getLogger(AccountDataLoader.class);

 
    @Transactional
    public UUID submitPayment(PaymentRequest request) {
        UUID paymentId = request.getPaymentId();

        idempotencyRepository.findByPaymentId(paymentId).ifPresent(existing -> {
            if ("ACCEPTED".equals(existing.getStatus())) {
                throw new DuplicatePaymentException(paymentId);
            }
            // KAFKA_FAILED: allow retry by deleting the failed record
            idempotencyRepository.delete(existing);
            log.warn("[Service] Retrying previously KAFKA_FAILED paymentId={}", paymentId);
        });

        // ── Account validation ────────────────────────────────────────────
        AccountEntity debit = accountRepository.findById(request.getDebitAccountId())
                .orElseThrow(() -> new AccountNotFoundException(request.getDebitAccountId(), "Debit"));

        AccountEntity credit = accountRepository.findById(request.getCreditAccountId())
                .orElseThrow(() -> new AccountNotFoundException(request.getCreditAccountId(), "Credit"));

        if ("SUSPENDED".equalsIgnoreCase(debit.getStatus())) {
            throw new AccountSuspendedException(debit.getAccountId());
        }
        if ("SUSPENDED".equalsIgnoreCase(credit.getStatus())) {
            throw new AccountSuspendedException(credit.getAccountId());
        }

        // ── Persist idempotency record BEFORE Kafka publish ───────────────
        // This guarantees: if Kafka publish succeeds, record exists;
        // if Kafka publish fails, record is marked KAFKA_FAILED for retry.
        IdempotencyRecord record;
        try {
            record = idempotencyRepository.save(IdempotencyRecord.builder()
                    .paymentId(paymentId)
                    .recordedAt(Instant.now())
                    .status("ACCEPTED")
                    .build());
        } catch (DataIntegrityViolationException e) {
            // Race condition: another thread won the unique constraint race
            throw new DuplicatePaymentException(paymentId);
        }

        // ── Build and publish Kafka event ─────────────────────────────────
        PaymentEvent event = PaymentEvent.builder()
                .paymentId(paymentId)
                .debitAccountId(request.getDebitAccountId())
                .creditAccountId(request.getCreditAccountId())
                .amount(request.getAmount())
                .currency(request.getCurrency())
                .reference(request.getReference())
                .timestamp(request.getTimestamp())
                .ingestedAt(Instant.now())
                .build();

        try {
            kafkaProducer.publish(event).get(); // block to confirm broker receipt
        } catch (Exception e) {
            // Partial update recovery: mark the idempotency record as failed
            // so the client can safely retry without getting a false 409.
            record.setStatus("KAFKA_FAILED");
            idempotencyRepository.save(record);
            log.error("[Service] Kafka publish failed for paymentId={}: {}", paymentId, e.getMessage());
            throw new RuntimeException("Failed to publish payment to Kafka. Please retry.", e);
        }

        log.info("[Service] Payment accepted and published. paymentId={}", paymentId);
        return paymentId;
    }

    /**
     * Returns account details by ID. Used by GET /api/accounts/{accountId}
     */
    public AccountResponse getAccount(String accountId) {
        AccountEntity acct = accountRepository.findById(accountId)
                .orElseThrow(() -> new AccountNotFoundException(accountId, "Account"));
        return AccountResponse.builder()
                .accountId(acct.getAccountId())
                .accountName(acct.getAccountName())
                .accountType(acct.getAccountType())
                .status(acct.getStatus())
                .currency(acct.getCurrency())
                .openedDate(acct.getOpenedDate())
                .build();
    }
}
