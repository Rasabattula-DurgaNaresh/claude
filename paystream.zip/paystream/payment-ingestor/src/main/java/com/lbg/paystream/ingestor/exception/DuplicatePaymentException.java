package com.lbg.paystream.ingestor.exception;

import java.util.UUID;

/**
 * Thrown when a paymentId has already been accepted.
 *
 * Concurrency / Retry challenge addressed:
 * Client-side retries (due to network unreliability) can cause the same
 * paymentId to arrive multiple times. The idempotency store catches this
 * and returns 409 so the client knows the payment was already accepted.
 * Maps to HTTP 409 Conflict.
 */
public class DuplicatePaymentException extends RuntimeException {
    public DuplicatePaymentException(UUID paymentId) {
        super("Duplicate paymentId: " + paymentId);
    }
}
