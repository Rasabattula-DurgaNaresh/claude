package com.lbg.paystream.ingestor.exception;

/**
 * Thrown when an account has status = SUSPENDED.
 * Maps to HTTP 422 Unprocessable Entity.
 */
public class AccountSuspendedException extends RuntimeException {
    public AccountSuspendedException(String accountId) {
        super("Account is suspended: " + accountId);
    }
}
