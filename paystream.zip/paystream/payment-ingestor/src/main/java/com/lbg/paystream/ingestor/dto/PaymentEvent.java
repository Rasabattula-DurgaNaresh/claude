package com.lbg.paystream.ingestor.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

/**
 * Kafka message published to topic: payments.submitted
 *
 * Partition key = debitAccountId ensures all payments for the same
 * account are processed in order (partition affinity).
 *
 * Data consistency: This event is only published AFTER the idempotency
 * record is persisted to H2, guaranteeing at-least-once delivery semantics.
 * The processor uses paymentId to detect and skip duplicates.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentEvent {
    private UUID paymentId;
    private String debitAccountId;
    private String creditAccountId;
    public UUID getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(UUID paymentId) {
		this.paymentId = paymentId;
	}

	public String getDebitAccountId() {
		return debitAccountId;
	}

	public void setDebitAccountId(String debitAccountId) {
		this.debitAccountId = debitAccountId;
	}

	public String getCreditAccountId() {
		return creditAccountId;
	}

	public void setCreditAccountId(String creditAccountId) {
		this.creditAccountId = creditAccountId;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public Instant getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Instant timestamp) {
		this.timestamp = timestamp;
	}

	public Instant getIngestedAt() {
		return ingestedAt;
	}

	public void setIngestedAt(Instant ingestedAt) {
		this.ingestedAt = ingestedAt;
	}

	private BigDecimal amount;
    private String currency;
    private String reference;
    private Instant timestamp;
    private Instant ingestedAt;
    
    public static Builder builder() { return new Builder(); }
    
    public static class Builder {
        private final PaymentEvent obj = new PaymentEvent();
 
        public Builder paymentId(UUID v)    { obj.paymentId   = v; return this; }
        public Builder debitAccountId(String v)  { obj.debitAccountId = v; return this; }
        public Builder creditAccountId(String v)  { obj.creditAccountId = v; return this; }
        public Builder amount(BigDecimal v)       { obj.amount      = v; return this; }
        public Builder currency(String v)     { obj.currency    = v; return this; }
        public Builder reference(String v){ obj.reference  = v; return this; }
        public Builder timestamp(Instant v){ obj.timestamp  = v; return this; }
        public Builder ingestedAt(Instant v){ obj.ingestedAt  = v; return this; }

 
        public PaymentEvent build()        { return obj; }
    }
 
}
