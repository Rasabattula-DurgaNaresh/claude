package com.lbg.paystream.ingestor.config;

import com.lbg.paystream.ingestor.dto.PaymentEvent;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;

import java.util.HashMap;
import java.util.Map;

/**
 * Kafka producer configuration for payment-ingestor.
 *
 * Network unreliability challenge:
 * The producer is configured with retries + idempotence so transient
 * broker unavailability (e.g. leader re-election during rolling restart)
 * does not cause data loss or duplicates.
 *
 * Distributed failures:
 * acks=all ensures the message is durable even if the Kafka leader crashes
 * immediately after acknowledging. The payment is not lost.
 */
@Configuration
public class KafkaProducerConfig {

    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;

    @Bean
    public ProducerFactory<String, PaymentEvent> producerFactory() {
        Map<String, Object> props = new HashMap<>();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);

        // Durability: all ISR replicas must ack (prevents data loss on broker crash)
        props.put(ProducerConfig.ACKS_CONFIG, "all");

        // Low latency for instant payments: short batch wait
        props.put(ProducerConfig.LINGER_MS_CONFIG, 5);

        // Throughput: compress batches (CPU-efficient snappy codec)
        props.put(ProducerConfig.COMPRESSION_TYPE_CONFIG, "snappy");

        // Exactly-once per partition: sequence numbers prevent broker-side duplicates
        props.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, true);

        // Retry on transient network errors (idempotence makes retries safe)
        props.put(ProducerConfig.RETRIES_CONFIG, 3);

        // Must be ≤5 when idempotence is enabled
        props.put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, 5);

        // Don't add Spring type headers — keeps messages schema-neutral
        props.put(JsonSerializer.ADD_TYPE_INFO_HEADERS, false);

        return new DefaultKafkaProducerFactory<>(props);
    }

    @Bean
    public KafkaTemplate<String, PaymentEvent> kafkaTemplate() {
        return new KafkaTemplate<>(producerFactory());
    }
}
