package com.lbg.paystream.ingestor.dto;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Data
@Builder
public class AccountResponse {
    private String accountId;
    private String accountName;
    private String accountType;
    private String status;
    private String currency;
    private LocalDate openedDate;
    public static Builder builder() { return new Builder(); }
    
    public static class Builder {
        private final AccountResponse obj = new AccountResponse();
 
        public Builder accountId(String v)    { obj.accountId   = v; return this; }
        public Builder accountName(String v)  { obj.accountName = v; return this; }
        public Builder accountType(String v)  { obj.accountType = v; return this; }
        public Builder status(String v)       { obj.status      = v; return this; }
        public Builder currency(String v)     { obj.currency    = v; return this; }
        public Builder openedDate(LocalDate v){ obj.openedDate  = v; return this; }
 
        public AccountResponse build()        { return obj; }
    }
 
}
