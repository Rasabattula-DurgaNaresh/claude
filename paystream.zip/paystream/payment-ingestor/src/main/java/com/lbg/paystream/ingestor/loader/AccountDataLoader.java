package com.lbg.paystream.ingestor.loader;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.lbg.paystream.ingestor.entity.AccountEntity;
import com.lbg.paystream.ingestor.repository.AccountRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.util.List;

/**
 * Seeds the H2 accounts table from accounts.json at startup.
 *
 * Observability: Logs the count of accounts loaded so operators can verify
 * seed data on startup without querying the DB manually.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class AccountDataLoader implements CommandLineRunner {
	
	private static final Logger log = LoggerFactory.getLogger(AccountDataLoader.class);

    private final AccountRepository accountRepository = null;

    @Override
    public void run(String... args) throws Exception {
        if (accountRepository.count() > 0) {
            log.info("[DataLoader] Accounts already loaded, skipping seed.");
            return;
        }
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());

        try (InputStream is = new ClassPathResource("accounts.json").getInputStream()) {
            List<AccountEntity> accounts = mapper.readValue(is, new TypeReference<>() {});
            accountRepository.saveAll(accounts);
            log.info("[DataLoader] Loaded {} accounts into H2 (ingestor).", accounts.size());
        } catch (Exception e) {
            log.error("[DataLoader] Failed to load accounts.json: {}", e.getMessage(), e);
            throw e;
        }
    }
}
