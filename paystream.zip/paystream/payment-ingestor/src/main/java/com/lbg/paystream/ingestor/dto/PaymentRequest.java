package com.lbg.paystream.ingestor.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

/**
 * Inbound payment request DTO.
 * All fields validated via Bean Validation (@Valid on controller parameter).
 *
 * Observability note: paymentId is logged on every request so operators can
 * trace a single payment across both microservices and Kafka topics.
 */
@Data
public class PaymentRequest {

    @NotNull(message = "Payment ID must be a valid UUID")
    private UUID paymentId;

    @NotBlank(message = "Debit account ID must not be blank")
    private String debitAccountId;

    @NotBlank(message = "Credit account ID must not be blank")
    private String creditAccountId;

    @NotNull(message = "Amount must be greater than 0")
    @DecimalMin(value = "0.01", message = "Amount must be greater than 0")
    private BigDecimal amount;

    @NotBlank(message = "Currency must be a 3-character ISO code")
    @Size(min = 3, max = 3, message = "Currency must be a 3-character ISO code")
    private String currency;

    @Size(max = 35, message = "Reference must not exceed 35 characters")
    private String reference;   // optional

    @NotNull(message = "Timestamp must not be in the future")
    @PastOrPresent(message = "Timestamp must not be in the future")
    private Instant timestamp;

	public UUID getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(UUID paymentId) {
		this.paymentId = paymentId;
	}

	public String getDebitAccountId() {
		return debitAccountId;
	}

	public void setDebitAccountId(String debitAccountId) {
		this.debitAccountId = debitAccountId;
	}

	public String getCreditAccountId() {
		return creditAccountId;
	}

	public void setCreditAccountId(String creditAccountId) {
		this.creditAccountId = creditAccountId;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public Instant getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Instant timestamp) {
		this.timestamp = timestamp;
	}

	@Override
	public String toString() {
		return "PaymentRequest [paymentId=" + paymentId + ", debitAccountId=" + debitAccountId + ", creditAccountId="
				+ creditAccountId + ", amount=" + amount + ", currency=" + currency + ", reference=" + reference
				+ ", timestamp=" + timestamp + "]";
	}
    
    
}
