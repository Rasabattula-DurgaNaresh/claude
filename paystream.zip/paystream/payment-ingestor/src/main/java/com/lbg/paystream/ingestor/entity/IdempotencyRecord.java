package com.lbg.paystream.ingestor.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.UUID;

import com.lbg.paystream.ingestor.dto.AccountResponse;

/**
 * Idempotency store for the ingestor.
 *
 * Concurrency challenge addressed:
 * Two simultaneous POST requests with the same paymentId (e.g. client retry
 * storm or network duplicate) must NOT produce two Kafka messages.
 *
 * Solution: Unique constraint on payment_id. First write succeeds; second
 * catches DataIntegrityViolationException → 409 Conflict.
 *
 * Partial-update safety: The row is inserted in a single atomic operation
 * BEFORE publishing to Kafka. If Kafka publish fails, the idempotency record
 * still exists so a client retry will get a 409 and the operator knows to
 * investigate rather than blindly resending.
 */
@Entity
@Table(name = "idempotency_records",
       uniqueConstraints = @UniqueConstraint(columnNames = "payment_id"))
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IdempotencyRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "payment_id", nullable = false, unique = true)
    private UUID paymentId;
    
    @Column(name = "recorded_at", nullable = false)
    private Instant recordedAt;

    @Column(name = "status", nullable = false, length = 20)
    private String status;  // ACCEPTED | KAFKA_FAILED

    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public UUID getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(UUID paymentId) {
		this.paymentId = paymentId;
	}

	public Instant getRecordedAt() {
		return recordedAt;
	}

	public void setRecordedAt(Instant recordedAt) {
		this.recordedAt = recordedAt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public static Builder builder() { return new Builder(); }
	 
    public static class Builder {
        private final IdempotencyRecord obj = new IdempotencyRecord();
 
        public Builder paymentId(UUID v)    { obj.paymentId   = v; return this; }
        public Builder recordedAt(Instant v)  { obj.recordedAt = v; return this; }
        public Builder status(String v)       { obj.status      = v; return this; }
 
        public IdempotencyRecord build()        { return obj; }
		
    }
 
	
}
