package com.lbg.paystream.ingestor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * PayStream Payment Ingestor Service
 * Port: 8080
 *
 * Responsibilities:
 * - Validates incoming payment requests (Bean Validation + account checks)
 * - Publishes PaymentEvent to Kafka topic: payments.submitted
 * - Serves account lookup endpoint from H2
 *
 * Distributed resilience handled via:
 * - Idempotency key (paymentId UUID) prevents duplicate processing
 * - Kafka producer with acks=all + retries for network unreliability
 * - Optimistic locking on idempotency store for concurrent duplicate submissions
 */
@SpringBootApplication
public class PaymentIngestorApplication {
    public static void main(String[] args) {
        SpringApplication.run(PaymentIngestorApplication.class, args);
    }
}
