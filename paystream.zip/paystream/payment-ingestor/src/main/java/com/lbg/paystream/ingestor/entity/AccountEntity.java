package com.lbg.paystream.ingestor.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * Account entity for payment-ingestor H2 database.
 * Seeded at startup from accounts.json.
 * Used solely for account existence and status validation.
 */
@Entity
@Table(name = "accounts")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AccountEntity {

    @Id
    @Column(name = "account_id", nullable = false)
    private String accountId;

    @Column(name = "account_name", nullable = false)
    private String accountName;

    @Column(name = "account_type", nullable = false)
    private String accountType;   // PERSONAL | BUSINESS | SAVINGS

    @Column(name = "status", nullable = false)
    private String status;        // ACTIVE | SUSPENDED

    @Column(name = "currency", nullable = false, length = 3)
    private String currency;

    @Column(name = "opened_date")
    private LocalDate openedDate;

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public LocalDate getOpenedDate() {
		return openedDate;
	}

	public void setOpenedDate(LocalDate openedDate) {
		this.openedDate = openedDate;
	}

	@Override
	public String toString() {
		return "AccountEntity [accountId=" + accountId + ", accountName=" + accountName + ", accountType=" + accountType
				+ ", status=" + status + ", currency=" + currency + ", openedDate=" + openedDate + "]";
	}
    
    
}
