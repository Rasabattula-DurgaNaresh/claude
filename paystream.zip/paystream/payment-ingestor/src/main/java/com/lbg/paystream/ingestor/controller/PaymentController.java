package com.lbg.paystream.ingestor.controller;

import com.lbg.paystream.ingestor.dto.AccountResponse;
import com.lbg.paystream.ingestor.dto.PaymentRequest;
import com.lbg.paystream.ingestor.loader.AccountDataLoader;
import com.lbg.paystream.ingestor.service.PaymentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.UUID;

/**
 * REST controller for payment-ingestor (port 8080).
 *
 * Endpoints:
 *   POST /api/payments           – Submit a payment (validated + published to Kafka)
 *   GET  /api/accounts/{id}      – Look up account details from H2
 */
@Slf4j
@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class PaymentController {
	
	private static final Logger log = LoggerFactory.getLogger(AccountDataLoader.class);

    private PaymentService paymentService;

    @PostMapping("/payments")
    public ResponseEntity<Map<String, Object>> submitPayment(
            @Valid @RequestBody PaymentRequest request) {

        log.info("[Controller] POST /api/payments paymentId={}", request.getPaymentId());
        UUID paymentId = paymentService.submitPayment(request);

        return ResponseEntity.accepted().body(Map.of(
                "paymentId", paymentId.toString(),
                "status", "ACCEPTED",
                "message", "Payment submitted for processing"
        ));
    }

    @GetMapping("/accounts/{accountId}")
    public ResponseEntity<AccountResponse> getAccount(@PathVariable String accountId) {
        log.debug("[Controller] GET /api/accounts/{}", accountId);
        return ResponseEntity.ok(paymentService.getAccount(accountId));
    }
}
