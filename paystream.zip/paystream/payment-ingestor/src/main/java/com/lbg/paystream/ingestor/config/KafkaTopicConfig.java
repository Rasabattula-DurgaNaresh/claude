package com.lbg.paystream.ingestor.config;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;

/**
 * Kafka topic declarations.
 * Spring Kafka AdminClient creates topics automatically if they don't exist.
 * This removes the need for manual kafka-topics.sh calls when running without Docker.
 */
@Configuration
public class KafkaTopicConfig {

    // 6 partitions: allows up to 6 concurrent consumer threads (one per partition)
    @Bean
    public NewTopic paymentsSubmitted() {
        return TopicBuilder.name("payments.submitted")
                .partitions(6)
                .replicas(1)   // 1 for local/H2 dev; set to 3 in production
                .build();
    }

    @Bean
    public NewTopic paymentsProcessed() {
        return TopicBuilder.name("payments.processed")
                .partitions(6)
                .replicas(1)
                .build();
    }
}
