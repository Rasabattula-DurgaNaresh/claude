package com.lbg.paystream.ingestor.exception;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Centralised error handling for payment-ingestor.
 *
 * Observability: All errors include timestamp + path so logs and
 * monitoring dashboards can correlate error spikes with specific endpoints.
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    // ── 400 Validation errors ─────────────────────────────────────────────────
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleValidation(
            MethodArgumentNotValidException ex, HttpServletRequest req) {

        List<Map<String, String>> violations = ex.getBindingResult()
                .getFieldErrors()
                .stream()
                .map(this::toViolation)
                .collect(Collectors.toList());

        return ResponseEntity.badRequest()
                .body(errorBody(400, "Validation failed", req.getRequestURI(), violations));
    }

    // ── 404 Account not found ─────────────────────────────────────────────────
    @ExceptionHandler(AccountNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleNotFound(
            AccountNotFoundException ex, HttpServletRequest req) {

        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(errorBody(404, ex.getMessage(), req.getRequestURI(), List.of()));
    }

    // ── 409 Duplicate payment ─────────────────────────────────────────────────
    @ExceptionHandler(DuplicatePaymentException.class)
    public ResponseEntity<Map<String, Object>> handleDuplicate(
            DuplicatePaymentException ex, HttpServletRequest req) {

        return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(errorBody(409, ex.getMessage(), req.getRequestURI(), List.of()));
    }

    // ── 422 Account suspended ─────────────────────────────────────────────────
    @ExceptionHandler(AccountSuspendedException.class)
    public ResponseEntity<Map<String, Object>> handleSuspended(
            AccountSuspendedException ex, HttpServletRequest req) {

        return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY)
                .body(errorBody(422, ex.getMessage(), req.getRequestURI(), List.of()));
    }

    // ── 500 Unexpected ───────────────────────────────────────────────────────
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleGeneric(
            Exception ex, HttpServletRequest req) {

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(errorBody(500, "Internal server error", req.getRequestURI(), List.of()));
    }

    // ── helpers ───────────────────────────────────────────────────────────────
    private Map<String, Object> errorBody(int status, String error,
                                          String path, List<?> violations) {
        Map<String, Object> body = new HashMap<>();
        body.put("timestamp", Instant.now().toString());
        body.put("status", status);
        body.put("error", error);
        body.put("path", path);
        body.put("violations", violations);
        return body;
    }

    private Map<String, String> toViolation(FieldError fe) {
        Map<String, String> v = new HashMap<>();
        v.put("field", fe.getField());
        v.put("message", fe.getDefaultMessage());
        return v;
    }
}
