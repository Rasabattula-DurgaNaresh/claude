package com.lbg.paystream.ingestor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.paystream.ingestor.dto.PaymentRequest;
import com.lbg.paystream.ingestor.repository.AccountRepository;
import com.lbg.paystream.ingestor.repository.IdempotencyRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integration tests for payment-ingestor.
 * Uses EmbeddedKafka so no running broker is needed.
 *
 * Tests cover:
 * - Happy path: valid payment → 202
 * - Duplicate paymentId → 409 (concurrency / retry safety)
 * - Unknown account → 404
 * - Suspended account → 422
 * - Bean Validation failure → 400
 * - Account lookup → 200
 */
@SpringBootTest
@AutoConfigureMockMvc
@DirtiesContext
@EmbeddedKafka(partitions = 6, topics = {"payments.submitted", "payments.processed"})
class PaymentIngestorIntegrationTest {

    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper objectMapper;
    @Autowired IdempotencyRepository idempotencyRepository;

    @BeforeEach
    void cleanIdempotencyTable() {
        idempotencyRepository.deleteAll();
    }

    // ── Happy path ────────────────────────────────────────────────────────────

    @Test
    void submitValidPayment_returns202() throws Exception {
        PaymentRequest req = validRequest();

        mockMvc.perform(post("/api/payments")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isAccepted())
                .andExpect(jsonPath("$.paymentId").value(req.getPaymentId().toString()))
                .andExpect(jsonPath("$.status").value("ACCEPTED"));
    }

    // ── Idempotency / Concurrency ─────────────────────────────────────────────

    @Test
    void submitDuplicatePaymentId_returns409() throws Exception {
        PaymentRequest req = validRequest();
        String body = objectMapper.writeValueAsString(req);

        mockMvc.perform(post("/api/payments")
                        .contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isAccepted());

        mockMvc.perform(post("/api/payments")
                        .contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.status").value(409));
    }

    // ── Account validation ────────────────────────────────────────────────────

    @Test
    void unknownDebitAccount_returns404() throws Exception {
        PaymentRequest req = validRequest();
        req.setDebitAccountId("99-99-99/00000000");

        mockMvc.perform(post("/api/payments")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value(404));
    }

    @Test
    void suspendedDebitAccount_returns422() throws Exception {
        PaymentRequest req = validRequest();
        req.setDebitAccountId("20-15-88/43917268"); // SUSPENDED in seed data

        mockMvc.perform(post("/api/payments")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.status").value(422));
    }

    // ── Bean Validation ───────────────────────────────────────────────────────

    @Test
    void missingAmount_returns400WithViolation() throws Exception {
        PaymentRequest req = validRequest();
        req.setAmount(null);

        mockMvc.perform(post("/api/payments")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.violations").isArray());
    }

    @Test
    void invalidCurrencyLength_returns400() throws Exception {
        PaymentRequest req = validRequest();
        req.setCurrency("GBPP");

        mockMvc.perform(post("/api/payments")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isBadRequest());
    }

    // ── Account lookup ────────────────────────────────────────────────────────

    @Test
    void getKnownAccount_returns200() throws Exception {
        mockMvc.perform(get("/api/accounts/20-15-88/43917265"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.accountId").value("20-15-88/43917265"))
                .andExpect(jsonPath("$.status").value("ACTIVE"));
    }

    @Test
    void getUnknownAccount_returns404() throws Exception {
        mockMvc.perform(get("/api/accounts/99-99-99/00000000"))
                .andExpect(status().isNotFound());
    }

    // ── helpers ───────────────────────────────────────────────────────────────

    private PaymentRequest validRequest() {
        PaymentRequest req = new PaymentRequest();
        req.setPaymentId(UUID.randomUUID());
        req.setDebitAccountId("20-15-88/43917265");   // ACTIVE Alice Johnson
        req.setCreditAccountId("20-15-88/43917266");  // ACTIVE Bob Smith
        req.setAmount(new BigDecimal("1500.00"));
        req.setCurrency("GBP");
        req.setReference("INV-2024-001");
        req.setTimestamp(Instant.now().minusSeconds(1));
        return req;
    }
}
