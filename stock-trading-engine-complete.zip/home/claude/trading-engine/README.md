# 🏦 Stock Market Order Processing Engine
## Java Multithreading & Concurrency — Complete Project

A **production-grade** multi-threaded stock trading system demonstrating
**every** major Java concurrency concept in one cohesive, runnable application.

---

## 🚀 How to Run

### Requirements
- Java 17+
- Maven 3.8+

### Build & Run
```bash
cd trading-engine
mvn clean package -q
java -jar target/trading-engine.jar
```

### Without Maven
```bash
# Compile
find src -name "*.java" -print | xargs javac -d target/classes

# Run
java -cp target/classes com.trading.Main
```

---

## 📁 Project Structure

```
trading-engine/
├── pom.xml
├── README.md
└── src/main/java/com/trading/
    ├── Main.java                          ← Entry point — wires all components
    │
    ├── model/
    │   ├── Order.java                     ← volatile + AtomicReference
    │   ├── Trade.java                     ← Immutable (thread-safe by design)
    │   └── MarketData.java                ← volatile + AtomicLong + LongAdder
    │
    ├── engine/
    │   ├── TradingEngine.java             ← BlockingQueue + CompletableFuture + volatile
    │   ├── OrderBook.java                 ← ReentrantLock + StampedLock
    │   ├── TradeSettlementService.java    ← CountDownLatch + CompletableFuture
    │   └── ReportGenerator.java           ← ForkJoinPool + CyclicBarrier + Phaser
    │
    ├── service/
    │   ├── AccountService.java            ← ConcurrentHashMap + AtomicLong + Semaphore
    │   ├── ValidationService.java         ← ExecutorService + Callable + ThreadLocal
    │   └── MarketDataService.java         ← ScheduledExecutorService + CopyOnWriteArrayList
    │
    └── util/
        ├── MetricsCollector.java          ← LongAdder + ScheduledExecutorService
        ├── ConnectionPool.java            ← Semaphore (bounded resource pool)
        ├── CircuitBreaker.java            ← AtomicReference state machine
        └── ThreadLocalContext.java        ← ThreadLocal + InheritableThreadLocal
```

---

## 🧵 Concurrency Concepts Map

| Concept | File | Purpose |
|---------|------|---------|
| **Thread / Runnable** | Main.java | 10 client threads submit orders |
| **Lambda threads** | Main.java | Client simulation tasks |
| **Daemon threads** | TradingEngine | Engine threads auto-stop on exit |
| **volatile** | TradingEngine, OrderBook, MarketData | Visibility of flags and prices |
| **synchronized** | AccountService | CAS loop via AtomicLong |
| **AtomicLong** | Order, AccountService | ID gen, balance CAS loop |
| **AtomicInteger** | MetricsCollector | Counter operations |
| **AtomicReference** | Order status, CircuitBreaker | CAS state transitions |
| **LongAdder** | MetricsCollector, MarketData | High-throughput counters |
| **BlockingQueue** | TradingEngine | Order pipeline (put/take) |
| **ConcurrentHashMap** | TradingEngine, AccountService | Thread-safe maps |
| **CopyOnWriteArrayList** | MarketDataService | Listener registry |
| **ExecutorService (Fixed)** | ValidationService, Settlement | Thread pools |
| **ScheduledExecutorService** | MarketDataService, Metrics | Periodic tasks |
| **CompletableFuture** | TradingEngine | Async pipeline chaining |
| **CountDownLatch** | TradeSettlementService, Main | Wait-for-completion |
| **CyclicBarrier** | ReportGenerator | 3-section report sync |
| **Semaphore** | ConnectionPool → AccountService | Max 10 DB connections |
| **ReentrantLock** | OrderBook | Fair exclusive matching lock |
| **StampedLock** | OrderBook | Optimistic read for bid/ask |
| **ForkJoinPool** | ReportGenerator | Parallel P&L computation |
| **RecursiveTask** | ReportGenerator | Divide-and-conquer sum/max |
| **ThreadLocal** | ValidationService | Per-thread request context |
| **InheritableThreadLocal** | ThreadLocalContext | Trace ID propagation |
| **Phaser** | ReportGenerator | Multi-phase report generation |
| **CircuitBreaker** | CircuitBreaker | AtomicReference state machine |

---

## 🏗️ Architecture Flow

```
10 Client Threads (FixedThreadPool)
         │
         │  offer()   ← non-blocking, back-pressure if full
         ▼
┌─────────────────────────────────┐
│  LinkedBlockingQueue<Order>     │  ← BlockingQueue: thread-safe hand-off
└────────────┬────────────────────┘
             │ poll(200ms)         ← blocks efficiently when empty
             ▼
┌─────────────────────────────────┐
│  OrderConsumer Thread           │  ← Daemon thread
│  (CompletableFuture pipeline)   │
└────────────┬────────────────────┘
             │
             ▼
┌─────────────────────────────────┐
│  ValidationService              │  ← FixedThreadPool(4) + ThreadLocal
│  (Callable → async validate)    │
└────────────┬────────────────────┘
             │ thenAcceptAsync
             ▼
┌─────────────────────────────────┐
│  OrderBook (per symbol)         │  ← ReentrantLock + StampedLock
│  Price-time priority matching   │  ← TreeMap sorted by price
└────────────┬────────────────────┘
             │ Trade matched
             ▼
┌─────────────────────────────────┐
│  LinkedBlockingQueue<Trade>     │  ← Settlement queue
└────────────┬────────────────────┘
             │
             ▼
┌─────────────────────────────────┐
│  TradeSettlementService         │  ← CountDownLatch(2) atomicity
│  Debit buyer + Credit seller    │  ← Both async, latch awaits both
└────────────┬────────────────────┘
             │
             ▼
┌─────────────────────────────────┐
│  AccountService                 │  ← ConcurrentHashMap + AtomicLong CAS
│  DB ops limited by Semaphore    │  ← Max 10 concurrent connections
└─────────────────────────────────┘

Background threads:
  MarketDataFeed    ← ScheduledExecutorService, 200ms ticks, volatile writes
  MetricsDashboard  ← ScheduledExecutorService, 3s interval, LongAdder.sum()
```

---

## 📊 Sample Output

```
═════════════════════════════════════════════════════════════════
  STOCK MARKET ORDER PROCESSING ENGINE
  Java Multithreading & Concurrency Complete Demo
═════════════════════════════════════════════════════════════════
  Symbols  : AAPL, GOOGL, MSFT, AMZN, TSLA
  Clients  : 10 concurrent threads
  Orders   : 1000 total
  CPU Cores: 8
═════════════════════════════════════════════════════════════════

[Init] Creating client accounts...
[Init] 10 accounts created.
[Init] Market data feed started for: AAPL, GOOGL, MSFT, AMZN, TSLA
[TradingEngine] Started. Ready to process orders.
[Simulation] Starting 10 client threads...

[MktData] AAPL  182.00 → 182.83  (0.46%)
[Matched] Trade[A1B2C3D4] AAPL buyer=ACC-2 seller=ACC-7 price=182.45 qty=87 value=15873.15
[Settled] Trade[A1B2C3D4] latency=12ms

╔══════════════ LIVE METRICS [cycle=1 up=3s] ══════════════╗
║  Orders Received : 340      | Trades Executed  : 48       ║
║  Orders Rejected : 2        | Settlement Fails : 0        ║
║  Fill Rate       :  14.1%   | Trade Volume     : 4230      ║
║  Avg Latency     :  11.2ms  | Max Latency      : 38ms     ║
╚═══════════════════════════════════════════════════════════╝

[Main] All 10 clients done. Queue depth: 43
[Main] Draining remaining orders (5 seconds)...

=== GENERATING FULL REPORT ===
[Report] All 3 sections ready — assembling...

[TRADES]
  Count  : 127
  Volume : 10482 shares
  Total  : 1924563.40
  Avg    : 15154.83
  Max    : 48920.00
  (Computed with ForkJoinPool RecursiveTask)

[MARKET DATA]
  AAPL   last=183.21 high=185.40 low=181.20 vol=48200
  GOOGL  last=141.50 high=143.20 low=139.80 vol=32100
  MSFT   last=376.80 high=378.90 low=374.10 vol=28400
  AMZN   last=179.20 high=180.50 low=177.80 vol=19800
  TSLA   last=249.30 high=252.10 low=246.50 vol=41300

[ACCOUNTS]
  Total     : 10
  Trades    : 127
  DB In-Use : 3
```

---

## 🔑 Key Design Decisions

### Why ReentrantLock over synchronized in OrderBook?
- `tryLock(timeout)` prevents deadlock
- Fair mode: FIFO ordering, no starvation
- Can be interrupted while waiting
- Separable lock/unlock methods

### Why StampedLock for bid/ask reads?
- Market depth is read thousands of times/second per price tick
- Optimistic read: **zero lock overhead** when no write is happening
- Falls back to read lock only when write is detected mid-read

### Why LongAdder over AtomicLong for metrics?
- `AtomicLong`: single cell → all threads contend on **one CAS** → high contention
- `LongAdder`: stripe of cells → each thread updates **its own cell** → near-zero contention
- `sum()` aggregates all cells: slightly more read cost, dramatically less write cost

### Why CopyOnWriteArrayList for listeners?
- Listeners added/removed rarely (low write frequency)
- Called on **every price tick** (very high read frequency)
- Iteration is lock-free (reads a snapshot); writes create new array

### Why CountDownLatch(2) for settlement?
- A trade = debit buyer **AND** credit seller
- Both must succeed (no partial settlement — accounting integrity)
- `latch.await()` blocks until **both** complete or timeout

### Why ForkJoinPool for reports?
- P&L computation across thousands of trades is CPU-bound
- **Work-stealing**: idle threads steal tasks from busy ones
- `RecursiveTask` splits array recursively → all CPU cores utilised
