package com.trading.engine;

import com.trading.model.Order;
import com.trading.model.Trade;
import com.trading.service.AccountService;
import com.trading.service.MarketDataService;
import com.trading.service.ValidationService;
import com.trading.util.MetricsCollector;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * CONCEPTS: BlockingQueue, CompletableFuture pipeline, ExecutorService (Fixed+Cached),
 *           volatile (shutdown flag), AtomicLong (order ID generator)
 *
 * Architecture:
 *   Client threads → BlockingQueue → Consumer thread → Validation (async pool)
 *                 → Matching (ReentrantLock) → Settlement (CountDownLatch) → Done
 *
 * BlockingQueue (LinkedBlockingQueue):
 *   - Producer threads call put() — blocks if full (back-pressure)
 *   - Single consumer thread calls take() — blocks if empty
 *   - Thread-safe: no synchronized needed between producers and consumer
 *   - Natural rate-limiting: producers slow down when engine is busy
 *
 * volatile boolean running:
 *   - Written by shutdown thread, read by consumer thread
 *   - volatile ensures the write is immediately visible (no CPU cache)
 *   - Without volatile, consumer thread might loop forever (stale cached value)
 *
 * AtomicLong orderIdCounter:
 *   - getAndIncrement() is a single atomic CPU instruction
 *   - No lock needed — generates globally unique IDs under any concurrency
 */
public class TradingEngine {

    // BlockingQueue: decouples producers (clients) from consumer (engine)
    // LinkedBlockingQueue: unbounded, nodes allocated on demand
    // ArrayBlockingQueue: bounded — use for explicit back-pressure
    private final BlockingQueue<Order> incomingOrders   = new LinkedBlockingQueue<>(50_000);
    private final BlockingQueue<Trade> pendingSettlement = new LinkedBlockingQueue<>();

    private final ConcurrentHashMap<String, OrderBook> orderBooks = new ConcurrentHashMap<>();

    private final ValidationService     validationService;
    private final TradeSettlementService settlementService;
    private final MarketDataService      marketDataService;
    private final AccountService         accountService;
    private final MetricsCollector       metrics;

    // AtomicLong: lock-free globally unique order ID generation
    private final AtomicLong orderIdCounter = new AtomicLong(100_000);

    // volatile: written by shutdown(), read by consumer loop — must be visible
    private volatile boolean running = false;

    // Dedicated thread pools for different engine stages
    private final ExecutorService matchingExecutor;
    private final ExecutorService settlementExecutor;

    private Thread consumerThread;
    private Thread settlementThread;

    public TradingEngine(AccountService accountService,
                         MarketDataService marketDataService,
                         MetricsCollector metrics) {
        this.accountService    = accountService;
        this.marketDataService = marketDataService;
        this.metrics           = metrics;
        this.validationService  = new ValidationService();
        this.settlementService  = new TradeSettlementService(accountService, metrics);
        this.matchingExecutor  = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "MatchingEngine");
            t.setDaemon(true);
            return t;
        });
        this.settlementExecutor = Executors.newFixedThreadPool(4, r -> {
            Thread t = new Thread(r, "Settler-" + System.nanoTime() % 1000);
            t.setDaemon(true);
            return t;
        });
    }

    public void start() {
        running = true;   // volatile write — visible to all threads immediately
        startOrderConsumer();
        startSettlementConsumer();
        System.out.println("[TradingEngine] Started. Ready to process orders.");
    }

    /**
     * Submit an order from a client thread.
     * Non-blocking: if queue full, logs warning and rejects.
     */
    public long submitOrder(String accountId, String symbol,
                            Order.Type type, double price, int quantity) {
        Order order = new Order(accountId, symbol, type, price, quantity);
        metrics.orderReceived();

        boolean queued = incomingOrders.offer(order); // non-blocking offer
        if (!queued) {
            System.err.println("[Engine] Queue full! Order rejected: " + order);
            order.setStatus(Order.Status.REJECTED);
            metrics.orderRejected();
        }
        return orderIdCounter.getAndIncrement(); // atomic ID generation
    }

    // ── Consumer thread: drains incomingOrders → validate → match ────────────
    private void startOrderConsumer() {
        consumerThread = new Thread(() -> {
            while (running || !incomingOrders.isEmpty()) {
                try {
                    // take() BLOCKS until an order is available (efficient — no spin)
                    Order order = incomingOrders.poll(200, TimeUnit.MILLISECONDS);
                    if (order == null) continue; // timeout — check running flag

                    // CompletableFuture pipeline: validate → match → queue for settlement
                    validationService.validateAsync(order)
                        .thenAcceptAsync(result -> {
                            if (!result.valid()) {
                                order.setStatus(Order.Status.REJECTED);
                                System.out.printf("[Rejected] %s reason=%s%n",
                                        order.getOrderId(), result.reason());
                                metrics.orderRejected();
                                return;
                            }

                            order.setStatus(Order.Status.VALIDATED);
                            metrics.orderValidated();

                            // Match order in the order book (ReentrantLock inside)
                            OrderBook book = orderBooks.computeIfAbsent(
                                    order.getSymbol(), OrderBook::new);
                            Optional<Trade> trade = book.addOrder(order);

                            trade.ifPresent(t -> {
                                System.out.printf("[Matched] %s%n", t);
                                pendingSettlement.offer(t); // queue for settlement
                            });

                        }, matchingExecutor)
                        .exceptionally(ex -> {
                            System.err.println("[Engine] Pipeline error: " + ex.getMessage());
                            return null;
                        });

                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
            System.out.println("[OrderConsumer] Shutting down.");
        }, "OrderConsumer");
        consumerThread.setDaemon(true);
        consumerThread.start();
    }

    // ── Settlement consumer: drains pendingSettlement queue ──────────────────
    private void startSettlementConsumer() {
        settlementThread = new Thread(() -> {
            while (running || !pendingSettlement.isEmpty()) {
                try {
                    Trade trade = pendingSettlement.poll(200, TimeUnit.MILLISECONDS);
                    if (trade == null) continue;

                    // CompletableFuture: non-blocking settlement call
                    settlementService.settle(trade)
                        .thenAccept(success -> {
                            if (!success) {
                                System.err.println("[SettlementFailed] " + trade.getTradeId());
                            }
                        })
                        .exceptionally(ex -> {
                            System.err.println("[Settlement error] " + ex.getMessage());
                            return null;
                        });

                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
            System.out.println("[SettlementConsumer] Shutting down.");
        }, "SettlementConsumer");
        settlementThread.setDaemon(true);
        settlementThread.start();
    }

    public void shutdown() throws InterruptedException {
        System.out.println("[TradingEngine] Initiating shutdown...");
        running = false; // volatile write — consumer threads see this immediately

        // Drain remaining orders
        Thread.sleep(2000);

        matchingExecutor.shutdown();
        settlementExecutor.shutdown();
        matchingExecutor.awaitTermination(5, TimeUnit.SECONDS);
        settlementExecutor.awaitTermination(5, TimeUnit.SECONDS);
        settlementService.shutdown();
        validationService.shutdown();
        System.out.println("[TradingEngine] Shutdown complete.");
    }

    /** Aggregate all trades across all order books. */
    public List<Trade> getAllTrades() {
        return orderBooks.values().stream()
                .flatMap(book -> book.getTradeHistory().stream())
                .toList();
    }

    public ConcurrentHashMap<String, OrderBook> getOrderBooks() { return orderBooks; }
    public int getQueueDepth()    { return incomingOrders.size(); }
    public boolean isRunning()    { return running; }
}
