package com.trading.util;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.LongAdder;

/**
 * CONCEPTS: LongAdder, AtomicLong, ScheduledExecutorService
 *
 * LongAdder vs AtomicLong:
 *   AtomicLong uses a single CAS on one cell → high contention when many threads increment
 *   LongAdder uses a stripe of cells → each thread updates its own cell → near-zero contention
 *   sum() aggregates all cells. Perfect for high-frequency counters (metrics, stats).
 *
 * ScheduledExecutorService: prints a live metrics dashboard every 5 seconds.
 */
public class MetricsCollector {

    // LongAdder for high-throughput counters (100s of threads incrementing simultaneously)
    private final LongAdder ordersReceived  = new LongAdder();
    private final LongAdder ordersValidated = new LongAdder();
    private final LongAdder ordersRejected  = new LongAdder();
    private final LongAdder tradesExecuted  = new LongAdder();
    private final LongAdder tradeVolume     = new LongAdder();  // shares traded
    private final LongAdder settlementFails = new LongAdder();

    // AtomicLong for values that need exact snapshot (latency tracking)
    private final AtomicLong totalLatencyMs     = new AtomicLong(0);
    private final AtomicLong maxLatencyMs       = new AtomicLong(0);
    private final AtomicLong reportingCycleCount= new AtomicLong(0);

    private final long startTimeMs = System.currentTimeMillis();

    // ScheduledExecutorService — runs metrics reporter on a fixed schedule
    private final ScheduledExecutorService scheduler =
            Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "MetricsReporter");
                t.setDaemon(true);   // daemon — dies when main thread exits
                return t;
            });

    public void startReporting(int intervalSeconds) {
        scheduler.scheduleAtFixedRate(this::printDashboard,
                intervalSeconds, intervalSeconds, TimeUnit.SECONDS);
    }

    // ── Increment methods (called from many threads simultaneously) ──────────
    public void orderReceived()             { ordersReceived.increment(); }
    public void orderValidated()            { ordersValidated.increment(); }
    public void orderRejected()             { ordersRejected.increment(); }
    public void tradeExecuted(int qty)      { tradesExecuted.increment(); tradeVolume.add(qty); }
    public void settlementFailed()          { settlementFails.increment(); }

    public void recordLatency(long latencyMs) {
        totalLatencyMs.addAndGet(latencyMs);
        // Update max latency using CAS loop (no lock needed)
        long current;
        do {
            current = maxLatencyMs.get();
        } while (latencyMs > current && !maxLatencyMs.compareAndSet(current, latencyMs));
    }

    // ── LongAdder.sum() aggregates all stripe cells ──────────────────────────
    public long getOrdersReceived()  { return ordersReceived.sum(); }
    public long getTradesExecuted()  { return tradesExecuted.sum(); }
    public long getTradeVolume()     { return tradeVolume.sum(); }

    private void printDashboard() {
        long cycle    = reportingCycleCount.incrementAndGet();
        long uptime   = (System.currentTimeMillis() - startTimeMs) / 1000;
        long received = ordersReceived.sum();
        long executed = tradesExecuted.sum();
        long rejected = ordersRejected.sum();
        long fails    = settlementFails.sum();
        long volume   = tradeVolume.sum();
        long maxLat   = maxLatencyMs.get();
        long totalLat = totalLatencyMs.get();
        double avgLat = executed > 0 ? (double) totalLat / executed : 0;
        double fillRate = received > 0 ? (executed * 100.0 / received) : 0;

        System.out.println("
╔══════════════ LIVE METRICS [cycle=" + cycle + " up=" + uptime + "s] ══════════════╗");
        System.out.printf( "║  Orders Received : %-8d  | Trades Executed  : %-8d  ║%n", received, executed);
        System.out.printf( "║  Orders Rejected : %-8d  | Settlement Fails : %-8d  ║%n", rejected, fails);
        System.out.printf( "║  Fill Rate       : %5.1f%%    | Trade Volume     : %-8d  ║%n", fillRate, volume);
        System.out.printf( "║  Avg Latency     : %5.1fms   | Max Latency      : %-8dms ║%n", avgLat, maxLat);
        System.out.println("╚═══════════════════════════════════════════════════════════════╝");
    }

    public void shutdown() {
        printDashboard(); // final report
        scheduler.shutdown();
    }
}