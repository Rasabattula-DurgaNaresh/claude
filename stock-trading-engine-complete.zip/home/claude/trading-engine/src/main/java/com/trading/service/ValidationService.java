package com.trading.service;

import com.trading.model.Order;
import com.trading.util.ThreadLocalContext;

import java.util.concurrent.*;

/**
 * CONCEPTS: ExecutorService, Callable, Future, ThreadLocal
 *
 * FixedThreadPool: maintains a pool of N reusable threads.
 *   - New tasks queue in a LinkedBlockingQueue when all threads are busy.
 *   - Prevents unbounded thread creation (unlike newCachedThreadPool).
 *   - Ideal for CPU-bound work like validation logic.
 *
 * Callable<ValidationResult>: unlike Runnable, returns a value.
 * Future<ValidationResult>: handle to retrieve the result asynchronously.
 * ThreadLocal: each validator thread gets its own RequestContext.
 */
public class ValidationService {

    // Fixed pool: 4 validator threads (tune to CPU cores for CPU-bound work)
    private final ExecutorService validatorPool = Executors.newFixedThreadPool(4, r -> {
        Thread t = new Thread(r);
        t.setName("Validator-" + t.getId());
        t.setDaemon(true);
        return t;
    });

    public record ValidationResult(boolean valid, String reason) {
        public static ValidationResult ok()               { return new ValidationResult(true, "OK"); }
        public static ValidationResult fail(String reason){ return new ValidationResult(false, reason); }
    }

    /**
     * Submit an order for async validation.
     * Returns a CompletableFuture so callers can chain further operations.
     */
    public CompletableFuture<ValidationResult> validateAsync(Order order) {
        return CompletableFuture.supplyAsync(() -> validate(order), validatorPool);
    }

    /**
     * Validation logic runs inside the validator thread pool.
     * ThreadLocal carries per-request context without passing it as a parameter.
     */
    private ValidationResult validate(Order order) {
        // Set thread-local context for this validation task
        ThreadLocalContext.RequestContext ctx = new ThreadLocalContext.RequestContext(
                "VAL-" + order.getOrderId(), order.getAccountId());
        ThreadLocalContext.set(ctx);
        ThreadLocalContext.setTraceId("TRACE-" + order.getOrderId());

        try {
            ctx.setCurrentOperation("VALIDATE_PRICE");
            if (order.getPrice() <= 0)
                return ValidationResult.fail("Price must be positive: " + order.getPrice());

            ctx.setCurrentOperation("VALIDATE_QTY");
            if (order.getQuantity() <= 0 || order.getQuantity() > 100_000)
                return ValidationResult.fail("Quantity out of range: " + order.getQuantity());

            ctx.setCurrentOperation("VALIDATE_SYMBOL");
            if (order.getSymbol() == null || order.getSymbol().isBlank())
                return ValidationResult.fail("Symbol is required");

            ctx.setCurrentOperation("VALIDATE_ACCOUNT");
            if (order.getAccountId() == null || order.getAccountId().isBlank())
                return ValidationResult.fail("AccountId is required");

            ctx.setCurrentOperation("RISK_CHECK");
            // Simulate risk check latency
            Thread.sleep((long)(Math.random() * 10 + 2));

            double tradeValue = order.getPrice() * order.getQuantity();
            if (tradeValue > 5_000_000)
                return ValidationResult.fail("Trade value exceeds limit: ₹" + tradeValue);

            return ValidationResult.ok();

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return ValidationResult.fail("Validation interrupted");
        } finally {
            // CRITICAL: clear ThreadLocal to prevent memory leak in pooled threads!
            ThreadLocalContext.clear();
        }
    }

    public void shutdown() {
        validatorPool.shutdown();
        try { validatorPool.awaitTermination(5, TimeUnit.SECONDS); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}