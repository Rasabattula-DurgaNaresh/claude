package com.trading.engine;

import com.trading.model.Trade;
import com.trading.service.AccountService;
import com.trading.service.MarketDataService;
import com.trading.util.MetricsCollector;

import java.util.List;
import java.util.concurrent.*;

/**
 * CONCEPTS: ForkJoinPool, RecursiveTask, CyclicBarrier, Phaser
 *
 * ForkJoinPool (work-stealing): idle workers steal tasks from busy workers' queues.
 * RecursiveTask<Double>: divide-and-conquer — split array, fork left, compute right, join.
 *
 * CyclicBarrier(3, action): all 3 report threads must reach barrier before any continues.
 *   REUSABLE — unlike CountDownLatch, CyclicBarrier resets automatically after each cycle.
 *   The barrierAction runs on the LAST thread to arrive.
 *
 * Phaser: more flexible than CyclicBarrier — supports dynamic party registration
 *   and multiple phases. Each arriveAndAwaitAdvance() call advances to the next phase.
 */
public class ReportGenerator {

    private final AccountService    accountService;
    private final MarketDataService marketDataService;
    private final MetricsCollector  metrics;
    private final ForkJoinPool      forkJoinPool;

    public ReportGenerator(AccountService accountService,
                           MarketDataService marketDataService,
                           MetricsCollector metrics) {
        this.accountService    = accountService;
        this.marketDataService = marketDataService;
        this.metrics           = metrics;
        this.forkJoinPool      = new ForkJoinPool(Runtime.getRuntime().availableProcessors());
    }

    /** Generate full report using CyclicBarrier to synchronise 3 parallel sections. */
    public void generateFullReport(List<Trade> allTrades) throws Exception {
        System.out.println("\n=== GENERATING FULL REPORT ===");
        String[] sections = new String[3];

        // CyclicBarrier: all 3 threads rendezvous before final print
        CyclicBarrier barrier = new CyclicBarrier(3,
            () -> System.out.println("[Report] All 3 sections ready — assembling..."));

        ExecutorService pool = Executors.newFixedThreadPool(3);

        pool.submit(() -> { try {
            sections[0] = buildTradeSection(allTrades);
            barrier.await();
        } catch (Exception e) { Thread.currentThread().interrupt(); }});

        pool.submit(() -> { try {
            sections[1] = buildMarketSection();
            barrier.await();
        } catch (Exception e) { Thread.currentThread().interrupt(); }});

        pool.submit(() -> { try {
            sections[2] = buildAccountSection();
            barrier.await();
        } catch (Exception e) { Thread.currentThread().interrupt(); }});

        pool.shutdown();
        pool.awaitTermination(30, TimeUnit.SECONDS);

        for (String s : sections) System.out.println(s);
        System.out.println("=== REPORT COMPLETE ===\n");
    }

    private String buildTradeSection(List<Trade> trades) {
        if (trades.isEmpty()) return "\n[TRADES]\n  No trades executed.\n";
        double[] vals = trades.stream().mapToDouble(Trade::getTradeValue).toArray();
        double total  = forkJoinPool.invoke(new SumTask(vals, 0, vals.length));
        double max    = forkJoinPool.invoke(new MaxTask(vals, 0, vals.length));
        long   vol    = trades.stream().mapToLong(Trade::getQuantity).sum();
        return String.format(
            "\n[TRADES]\n  Count  : %d\n  Volume : %d shares\n" +
            "  Total  : %.2f\n  Avg    : %.2f\n  Max    : %.2f\n" +
            "  (Computed with ForkJoinPool RecursiveTask)\n",
            trades.size(), vol, total, total / trades.size(), max);
    }

    private String buildMarketSection() {
        StringBuilder sb = new StringBuilder("\n[MARKET DATA]\n");
        marketDataService.getAllMarketData().forEach((sym, md) ->
            sb.append(String.format("  %-6s last=%.2f high=%.2f low=%.2f vol=%d%n",
                sym, md.getLastPrice(), md.getDayHigh(), md.getDayLow(), md.getTotalVolume())));
        return sb.toString();
    }

    private String buildAccountSection() {
        return String.format(
            "\n[ACCOUNTS]\n  Total     : %d\n  Trades    : %d\n  DB In-Use : %d\n",
            accountService.getAccountCount(),
            metrics.getTradesExecuted(),
            accountService.getDbPool().inUse());
    }

    /** Phaser demo: 3 worker threads, 3 phases (collect → compute → format). */
    public void generatePhasedReport(List<Trade> trades) throws InterruptedException {
        System.out.println("\n=== PHASED REPORT (Phaser demo) ===");
        int N = 3;
        Phaser phaser = new Phaser(N + 1); // +1 for orchestrator
        ExecutorService pool = Executors.newFixedThreadPool(N);

        for (int i = 0; i < N; i++) {
            final int id = i;
            pool.submit(() -> {
                try {
                    Thread.sleep((long)(Math.random() * 150 + 50));
                    System.out.printf("  [Phase 0 - collect] Thread-%d done%n", id);
                    phaser.arriveAndAwaitAdvance();  // Phase 0

                    Thread.sleep((long)(Math.random() * 200 + 50));
                    System.out.printf("  [Phase 1 - compute] Thread-%d done%n", id);
                    phaser.arriveAndAwaitAdvance();  // Phase 1

                    Thread.sleep((long)(Math.random() * 100 + 20));
                    System.out.printf("  [Phase 2 - format ] Thread-%d done%n", id);
                    phaser.arriveAndDeregister();    // done — deregister
                } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            });
        }

        phaser.arriveAndAwaitAdvance(); System.out.println("  [Orchestrator] Phase 0 complete");
        phaser.arriveAndAwaitAdvance(); System.out.println("  [Orchestrator] Phase 1 complete");
        phaser.arriveAndDeregister();

        pool.shutdown();
        pool.awaitTermination(10, TimeUnit.SECONDS);
        System.out.println("=== PHASED REPORT DONE ===\n");
    }

    // ── RecursiveTask: divide-and-conquer sum ────────────────────────────────
    private static class SumTask extends RecursiveTask<Double> {
        private static final int THRESHOLD = 200;
        private final double[] data; private final int start, end;
        SumTask(double[] data, int start, int end) { this.data=data; this.start=start; this.end=end; }
        @Override protected Double compute() {
            if (end - start <= THRESHOLD) {
                double s = 0; for (int i = start; i < end; i++) s += data[i]; return s;
            }
            int mid = (start + end) / 2;
            SumTask left = new SumTask(data, start, mid), right = new SumTask(data, mid, end);
            left.fork();
            return right.compute() + left.join();
        }
    }

    // ── RecursiveTask: divide-and-conquer max ────────────────────────────────
    private static class MaxTask extends RecursiveTask<Double> {
        private static final int THRESHOLD = 200;
        private final double[] data; private final int start, end;
        MaxTask(double[] data, int start, int end) { this.data=data; this.start=start; this.end=end; }
        @Override protected Double compute() {
            if (end - start <= THRESHOLD) {
                double m = Double.NEGATIVE_INFINITY; for (int i = start; i < end; i++) if (data[i]>m) m=data[i]; return m;
            }
            int mid = (start + end) / 2;
            MaxTask left = new MaxTask(data, start, mid), right = new MaxTask(data, mid, end);
            left.fork();
            return Math.max(right.compute(), left.join());
        }
    }

    public void shutdown() { forkJoinPool.shutdown(); }
}
