package com.trading.util;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * CONCEPT: AtomicReference state machine
 *
 * CircuitBreaker prevents cascading failures when a downstream service degrades.
 * States: CLOSED (normal) → OPEN (failing, reject all) → HALF_OPEN (testing recovery)
 *
 * AtomicReference<State>: guarantees state transitions are atomic.
 * Only ONE thread can successfully CAS from CLOSED → OPEN even under high concurrency.
 */
public class CircuitBreaker {

    public enum State { CLOSED, OPEN, HALF_OPEN }

    private final AtomicReference<State> state        = new AtomicReference<>(State.CLOSED);
    private final AtomicInteger          failureCount  = new AtomicInteger(0);
    private final AtomicLong             openedAt      = new AtomicLong(0);

    private final int  failureThreshold;   // failures before opening
    private final long retryTimeoutMs;     // ms to stay OPEN before trying HALF_OPEN
    private final String serviceName;

    public CircuitBreaker(String serviceName, int failureThreshold, long retryTimeoutMs) {
        this.serviceName      = serviceName;
        this.failureThreshold = failureThreshold;
        this.retryTimeoutMs   = retryTimeoutMs;
    }

    /** Returns true if the call is allowed (circuit CLOSED or HALF_OPEN for probe). */
    public boolean allowCall() {
        State current = state.get();

        if (current == State.CLOSED) return true;

        if (current == State.OPEN) {
            long elapsed = System.currentTimeMillis() - openedAt.get();
            if (elapsed >= retryTimeoutMs) {
                // Attempt transition OPEN → HALF_OPEN (only one thread wins CAS)
                if (state.compareAndSet(State.OPEN, State.HALF_OPEN)) {
                    System.out.printf("[CircuitBreaker:%s] OPEN → HALF_OPEN (probe call allowed)%n", serviceName);
                    return true; // allow one probe request
                }
            }
            return false; // still OPEN — reject
        }

        // HALF_OPEN: allow the probe through
        return current == State.HALF_OPEN;
    }

    /** Record a successful call — may close the circuit. */
    public void recordSuccess() {
        State current = state.get();
        if (current == State.HALF_OPEN) {
            if (state.compareAndSet(State.HALF_OPEN, State.CLOSED)) {
                failureCount.set(0);
                System.out.printf("[CircuitBreaker:%s] HALF_OPEN → CLOSED (service recovered)%n", serviceName);
            }
        } else if (current == State.CLOSED) {
            failureCount.set(0); // reset on success
        }
    }

    /** Record a failed call — may open the circuit. */
    public void recordFailure() {
        int failures = failureCount.incrementAndGet();
        State current = state.get();

        if (current == State.HALF_OPEN) {
            // Probe failed — go back to OPEN
            if (state.compareAndSet(State.HALF_OPEN, State.OPEN)) {
                openedAt.set(System.currentTimeMillis());
                System.out.printf("[CircuitBreaker:%s] HALF_OPEN → OPEN (probe failed)%n", serviceName);
            }
        } else if (current == State.CLOSED && failures >= failureThreshold) {
            // Too many failures — open the circuit
            if (state.compareAndSet(State.CLOSED, State.OPEN)) {
                openedAt.set(System.currentTimeMillis());
                System.out.printf("[CircuitBreaker:%s] CLOSED → OPEN (failures=%d)%n",
                        serviceName, failures);
            }
        }
    }

    public State getState()    { return state.get(); }
    public int   getFailures() { return failureCount.get(); }
}