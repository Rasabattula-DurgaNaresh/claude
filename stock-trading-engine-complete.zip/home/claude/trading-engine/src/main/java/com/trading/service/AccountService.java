package com.trading.service;

import com.trading.util.ConnectionPool;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * CONCEPTS: ConcurrentHashMap, AtomicLong, Semaphore (via ConnectionPool)
 *
 * ConcurrentHashMap: 16-segment striped locking by default in Java 8+.
 *   - Reads are NEVER locked (non-blocking).
 *   - Writes lock only the affected segment.
 *   - Far better concurrency than Collections.synchronizedMap().
 *
 * AtomicLong: balance stored in smallest unit (paise/cents × 100).
 *   - CAS loop for debit: ensures balance never goes negative even with
 *     1000 threads debiting simultaneously.
 *
 * ConnectionPool (Semaphore): limits concurrent "DB" access to 10 threads.
 */
public class AccountService {

    // ConcurrentHashMap: thread-safe map with fine-grained (segment) locking
    // Key: accountId  Value: balance in paise (₹ × 10000 to avoid floating point)
    private final ConcurrentHashMap<String, AtomicLong> balances =
            new ConcurrentHashMap<>();

    // Limit concurrent "DB" connections — models real connection pool constraint
    private final ConnectionPool dbPool = new ConnectionPool("AccountDB", 10);

    public void createAccount(String accountId, double initialBalance) {
        long balancePaise = (long)(initialBalance * 10000);
        balances.putIfAbsent(accountId, new AtomicLong(balancePaise));
    }

    /**
     * Thread-safe debit using CAS loop — no locks on the balance itself.
     * Multiple threads can debit different accounts simultaneously.
     * Even for the SAME account, CAS ensures atomicity without synchronized.
     */
    public boolean debit(String accountId, double amount) throws InterruptedException {
        if (!dbPool.acquire(2000)) {
            System.err.println("[AccountService] DB pool timeout for debit: " + accountId);
            return false;
        }
        try {
            AtomicLong balance = balances.computeIfAbsent(accountId,
                    k -> new AtomicLong(10_000_0000L)); // default ₹10,000

            long amountPaise = (long)(amount * 10000);

            // CAS loop: retry until we atomically debit or detect insufficient funds
            long current;
            do {
                current = balance.get();
                if (current < amountPaise) {
                    return false; // insufficient funds
                }
            } while (!balance.compareAndSet(current, current - amountPaise));

            // Simulate DB write latency
            Thread.sleep((long)(Math.random() * 3));
            return true;

        } finally {
            dbPool.release(); // ALWAYS release in finally!
        }
    }

    /**
     * Thread-safe credit — addAndGet is inherently atomic on AtomicLong.
     */
    public void credit(String accountId, double amount) throws InterruptedException {
        if (!dbPool.acquire(2000)) {
            System.err.println("[AccountService] DB pool timeout for credit: " + accountId);
            return;
        }
        try {
            long amountPaise = (long)(amount * 10000);
            balances.computeIfAbsent(accountId, k -> new AtomicLong(0))
                    .addAndGet(amountPaise);
            Thread.sleep((long)(Math.random() * 3));
        } finally {
            dbPool.release();
        }
    }

    public double getBalance(String accountId) {
        AtomicLong bal = balances.get(accountId);
        return bal != null ? bal.get() / 10000.0 : 0.0;
    }

    public int getAccountCount()  { return balances.size(); }
    public ConnectionPool getDbPool() { return dbPool; }
}