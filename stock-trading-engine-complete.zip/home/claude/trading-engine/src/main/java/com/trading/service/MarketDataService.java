package com.trading.service;

import com.trading.model.MarketData;

import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.*;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * CONCEPTS: ScheduledExecutorService, volatile, ConcurrentHashMap, CopyOnWriteArrayList
 *
 * ScheduledExecutorService: simulates a real-time market data feed.
 *   - scheduleAtFixedRate: runs regardless of previous execution time (may overlap)
 *   - scheduleWithFixedDelay: waits for completion before starting delay
 *
 * CopyOnWriteArrayList for listeners: listeners list is rarely modified (add/remove)
 *   but frequently iterated (on every price tick). COW creates a new copy on every
 *   write, making iteration completely lock-free and safe.
 *
 * volatile in MarketData: price written by feed thread, read by ALL other threads.
 */
public class MarketDataService {

    private final ConcurrentHashMap<String, MarketData> marketDataMap =
            new ConcurrentHashMap<>();

    // CopyOnWriteArrayList: thread-safe for add/remove; lock-free for iteration
    // Perfect for event listener registries (many reads, few writes)
    private final CopyOnWriteArrayList<MarketDataListener> listeners =
            new CopyOnWriteArrayList<>();

    private final ScheduledExecutorService feedScheduler =
            Executors.newScheduledThreadPool(2, r -> {
                Thread t = new Thread(r, "MarketDataFeed");
                t.setDaemon(true);
                return t;
            });

    private final Random random = new Random();

    @FunctionalInterface
    public interface MarketDataListener {
        void onPriceUpdate(String symbol, double newPrice, double oldPrice);
    }

    public MarketData register(String symbol, double openPrice) {
        MarketData md = new MarketData(symbol, openPrice);
        marketDataMap.put(symbol, md);
        return md;
    }

    public void addListener(MarketDataListener listener) {
        listeners.add(listener); // COW: creates new array copy
    }

    public void removeListener(MarketDataListener listener) {
        listeners.remove(listener); // COW: creates new array copy
    }

    /**
     * Start simulated market data feed — updates prices randomly.
     * scheduleAtFixedRate: fires every 200ms regardless of execution time.
     */
    public void startFeed() {
        // Price feed: every 200ms
        feedScheduler.scheduleAtFixedRate(this::tickAllPrices, 0, 200, TimeUnit.MILLISECONDS);

        // Best bid/ask update: every 100ms
        feedScheduler.scheduleAtFixedRate(this::updateBidAsk, 50, 100, TimeUnit.MILLISECONDS);
    }

    private void tickAllPrices() {
        // Iterate ConcurrentHashMap — safe, uses internal segment locks
        marketDataMap.forEach((symbol, md) -> {
            double oldPrice = md.getLastPrice();
            // Simulate realistic price movement (±0.5%)
            double change   = oldPrice * (random.nextGaussian() * 0.005);
            double newPrice = Math.max(1.0, oldPrice + change);
            int    volume   = random.nextInt(1000) + 100;

            md.updatePrice(newPrice, volume); // volatile write inside

            // Iterate CopyOnWriteArrayList — completely lock-free (iterates snapshot)
            for (MarketDataListener listener : listeners) {
                try { listener.onPriceUpdate(symbol, newPrice, oldPrice); }
                catch (Exception ignored) {} // one bad listener must not stop the feed
            }
        });
    }

    private void updateBidAsk() {
        marketDataMap.forEach((symbol, md) -> {
            double last = md.getLastPrice(); // volatile read
            md.setBid(last - random.nextDouble() * 0.05);  // volatile write
            md.setAsk(last + random.nextDouble() * 0.05);  // volatile write
        });
    }

    public MarketData getMarketData(String symbol) {
        return marketDataMap.get(symbol);
    }

    public Map<String, MarketData> getAllMarketData() {
        return java.util.Collections.unmodifiableMap(marketDataMap);
    }

    public void shutdown() {
        feedScheduler.shutdown();
    }
}