package com.trading;

import com.trading.engine.*;
import com.trading.model.Order;
import com.trading.service.AccountService;
import com.trading.service.MarketDataService;
import com.trading.util.MetricsCollector;

import java.util.List;
import java.util.Random;
import java.util.concurrent.*;

/**
 * ════════════════════════════════════════════════════════════════════════════
 * STOCK MARKET ORDER PROCESSING ENGINE
 * Java Multithreading & Concurrency — All Concepts Demo
 * ════════════════════════════════════════════════════════════════════════════
 *
 * Concepts used in this simulation:
 *
 *  Thread           → OrderConsumer, SettlementConsumer, MarketDataFeed threads
 *  Runnable/Lambda  → Client simulation tasks submitted to ExecutorService
 *  volatile         → running flag in TradingEngine, lastTradePrice in OrderBook
 *  synchronized     → AccountService balance CAS loop (via AtomicLong)
 *  ReentrantLock    → OrderBook critical section (price-time priority matching)
 *  StampedLock      → Optimistic reads for best bid/ask in OrderBook
 *  AtomicInteger    → Order ID generator (MetricsCollector counters)
 *  AtomicLong       → orderIdCounter, balance storage (paise)
 *  AtomicReference  → Order.status transitions, CircuitBreaker state machine
 *  LongAdder        → MetricsCollector counters (high-throughput, low contention)
 *  BlockingQueue    → Order ingestion (LinkedBlockingQueue — producer/consumer)
 *  ConcurrentHashMap → orderBooks per symbol, account balances
 *  CopyOnWriteArrayList → MarketDataService listener registry
 *  ExecutorService  → FixedThreadPool for validators, settlers
 *  ScheduledExecutorService → MarketDataFeed (price ticks every 200ms)
 *  CompletableFuture → validate→match→settle async pipeline
 *  CountDownLatch   → Atomic settlement: debit + credit must both complete
 *  CyclicBarrier    → Report generation: 3 sections sync before assembly
 *  Semaphore        → ConnectionPool: max 10 concurrent DB connections
 *  ForkJoinPool     → RecursiveTask for parallel P&L / sum / max computation
 *  ThreadLocal      → Per-validator RequestContext (no parameter passing)
 *  InheritableThreadLocal → TraceId inherited by child async threads
 *  Phaser           → Multi-phase report generation (collect→compute→format)
 *  Daemon threads   → All engine threads (die automatically when main exits)
 */
public class Main {

    private static final int NUM_SYMBOLS  = 5;
    private static final int NUM_CLIENTS  = 10;
    private static final int ORDERS_PER_CLIENT = 100;

    private static final String[] SYMBOLS = {"AAPL", "GOOGL", "MSFT", "AMZN", "TSLA"};
    private static final double[] OPEN_PRICES = {182.0, 140.0, 375.0, 178.0, 248.0};

    public static void main(String[] args) throws Exception {

        printBanner();

        // ── 1. Initialise services ────────────────────────────────────────────
        MetricsCollector  metrics  = new MetricsCollector();
        AccountService    accounts = new AccountService();
        MarketDataService mktData  = new MarketDataService();

        // ── 2. Create accounts for 10 clients (₹1,00,000 each) ───────────────
        System.out.println("[Init] Creating client accounts...");
        for (int i = 0; i < NUM_CLIENTS; i++) {
            accounts.createAccount("ACC-" + i, 100_000.0);
        }
        System.out.println("[Init] " + NUM_CLIENTS + " accounts created.");

        // ── 3. Register market data and start feed ────────────────────────────
        System.out.println("[Init] Registering market data...");
        for (int i = 0; i < NUM_SYMBOLS; i++) {
            MarketDataService.MarketDataListener listener = (sym, np, op) -> {}; // no-op
            mktData.register(SYMBOLS[i], OPEN_PRICES[i]);
        }
        // Add a logging listener (stored in CopyOnWriteArrayList)
        mktData.addListener((sym, newPrice, oldPrice) -> {
            // Only log significant moves (>0.3%)
            double change = Math.abs((newPrice - oldPrice) / oldPrice * 100);
            if (change > 0.3) {
                System.out.printf("[MktData] %s  %.2f → %.2f  (%.2f%%)%n",
                        sym, oldPrice, newPrice, (newPrice-oldPrice)/oldPrice*100);
            }
        });
        mktData.startFeed(); // ScheduledExecutorService — ticks every 200ms
        System.out.println("[Init] Market data feed started for: " + String.join(", ", SYMBOLS));

        // ── 4. Start the trading engine ───────────────────────────────────────
        TradingEngine engine = new TradingEngine(accounts, mktData, metrics);
        engine.start();

        // ── 5. Start metrics dashboard (ScheduledExecutorService, every 3s) ──
        metrics.startReporting(3);

        // ── 6. Simulate 10 clients submitting orders concurrently ─────────────
        System.out.println("\n[Simulation] Starting " + NUM_CLIENTS + " client threads...");
        System.out.println("[Simulation] Each client submits " + ORDERS_PER_CLIENT + " orders.");
        System.out.println("─".repeat(60));

        // FixedThreadPool: exactly 10 threads, one per simulated client
        ExecutorService clientPool = Executors.newFixedThreadPool(NUM_CLIENTS, r -> {
            Thread t = new Thread(r);
            t.setName("Client-" + Thread.currentThread().getId());
            return t;
        });

        // CountDownLatch: wait for ALL clients to finish submitting
        CountDownLatch allClientsSubmitted = new CountDownLatch(NUM_CLIENTS);
        Random rng = new Random(42); // deterministic seed for reproducibility

        for (int c = 0; c < NUM_CLIENTS; c++) {
            final int clientId = c;
            clientPool.submit(() -> {                    // Runnable lambda
                try {
                    for (int o = 0; o < ORDERS_PER_CLIENT; o++) {
                        // Pick random symbol and type
                        String symbol = SYMBOLS[rng.nextInt(NUM_SYMBOLS)];
                        Order.Type type = rng.nextBoolean() ? Order.Type.BUY : Order.Type.SELL;

                        // Spread prices around market price for realistic matching
                        double marketPrice = mktData.getMarketData(symbol).getLastPrice();
                        double offset      = (rng.nextDouble() - 0.48) * marketPrice * 0.02;
                        double price       = Math.max(1.0, marketPrice + offset);
                        int    quantity    = rng.nextInt(200) + 1;

                        engine.submitOrder("ACC-" + clientId, symbol, type, price, quantity);

                        // Random inter-order delay (1-20ms) — simulate real client behaviour
                        Thread.sleep(rng.nextInt(20) + 1);
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                } finally {
                    allClientsSubmitted.countDown(); // this client is done
                }
            });
        }

        // Wait for all clients to finish submitting orders
        System.out.println("[Main] Waiting for all clients to finish submitting...");
        allClientsSubmitted.await(60, TimeUnit.SECONDS);
        System.out.println("[Main] All " + NUM_CLIENTS + " clients done. " +
                "Queue depth: " + engine.getQueueDepth());

        // ── 7. Let engine process remaining orders (drain phase) ──────────────
        System.out.println("[Main] Draining remaining orders (5 seconds)...");
        Thread.sleep(5000);

        // ── 8. Shutdown engine gracefully ─────────────────────────────────────
        engine.shutdown();
        clientPool.shutdown();
        mktData.shutdown();

        // ── 9. Generate comprehensive reports ────────────────────────────────
        List<Trade> allTrades = engine.getAllTrades();
        ReportGenerator reporter = new ReportGenerator(accounts, mktData, metrics);

        System.out.println("\n[Main] Generating reports using CyclicBarrier...");
        reporter.generateFullReport(allTrades);

        System.out.println("[Main] Generating phased report using Phaser...");
        reporter.generatePhasedReport(allTrades);

        // ── 10. Verify CircuitBreaker state machine ───────────────────────────
        System.out.println("[Demo] CircuitBreaker state machine demo...");
        demonstrateCircuitBreaker();

        // ── 11. Final metrics printout ────────────────────────────────────────
        System.out.println("\n[Main] Printing final order book states...");
        engine.getOrderBooks().forEach((symbol, book) ->
            System.out.printf("  %-6s matched=%d  buyOrders=%d  sellOrders=%d  lastPrice=%.2f%n",
                symbol, book.getTotalMatchedOrders(),
                book.getBuyOrderCount(), book.getSellOrderCount(),
                book.getLastTradePrice())
        );

        System.out.printf("%n[Final] Total trades executed: %d%n", allTrades.size());
        System.out.printf("[Final] Total orders received : %d%n", metrics.getOrdersReceived());
        System.out.printf("[Final] Total trade volume    : %d shares%n", metrics.getTradeVolume());

        metrics.shutdown(); // final metrics print + stop scheduler
        reporter.shutdown();

        printConceptSummary();
    }

    private static void demonstrateCircuitBreaker() {
        com.trading.util.CircuitBreaker cb =
                new com.trading.util.CircuitBreaker("PaymentGateway", 3, 2000);

        System.out.println("  State: " + cb.getState()); // CLOSED
        // Simulate 3 failures → circuit opens
        for (int i = 0; i < 3; i++) cb.recordFailure();
        System.out.println("  After 3 failures: " + cb.getState()); // OPEN

        // Call is rejected while OPEN
        System.out.println("  allowCall(): " + cb.allowCall()); // false

        try { Thread.sleep(2100); } catch (InterruptedException e) {} // wait for timeout

        // After timeout: OPEN → HALF_OPEN for probe
        System.out.println("  After timeout: allowCall()=" + cb.allowCall()); // true (HALF_OPEN)
        cb.recordSuccess(); // probe succeeded
        System.out.println("  After success: " + cb.getState()); // CLOSED
    }

    private static void printBanner() {
        System.out.println("═".repeat(65));
        System.out.println("  STOCK MARKET ORDER PROCESSING ENGINE");
        System.out.println("  Java Multithreading & Concurrency Complete Demo");
        System.out.println("═".repeat(65));
        System.out.println("  Symbols  : AAPL, GOOGL, MSFT, AMZN, TSLA");
        System.out.println("  Clients  : " + NUM_CLIENTS + " concurrent threads");
        System.out.println("  Orders   : " + (NUM_CLIENTS * ORDERS_PER_CLIENT) + " total");
        System.out.println("  CPU Cores: " + Runtime.getRuntime().availableProcessors());
        System.out.println("═".repeat(65) + "\n");
    }

    private static void printConceptSummary() {
        System.out.println("\n" + "═".repeat(65));
        System.out.println("  CONCURRENCY CONCEPTS DEMONSTRATED IN THIS PROJECT");
        System.out.println("═".repeat(65));
        System.out.println("  Thread / Runnable / Lambda → Client threads, engine threads");
        System.out.println("  volatile                   → running flag, lastTradePrice");
        System.out.println("  AtomicLong                 → Order ID, balances (CAS loop)");
        System.out.println("  AtomicReference            → Order status, CircuitBreaker state");
        System.out.println("  LongAdder                  → Metrics counters (high-throughput)");
        System.out.println("  BlockingQueue              → Order ingestion pipeline");
        System.out.println("  ConcurrentHashMap          → Order books, account balances");
        System.out.println("  CopyOnWriteArrayList       → Market data listener registry");
        System.out.println("  ExecutorService (Fixed)    → Validator pool, settler pool");
        System.out.println("  ScheduledExecutorService   → Market data feed, metrics");
        System.out.println("  CompletableFuture          → Validate→Match→Settle pipeline");
        System.out.println("  CountDownLatch             → Settlement atomicity, client sync");
        System.out.println("  CyclicBarrier              → Report section synchronisation");
        System.out.println("  Semaphore                  → DB connection pool (max 10)");
        System.out.println("  ReentrantLock              → Order matching critical section");
        System.out.println("  StampedLock                → Optimistic best bid/ask reads");
        System.out.println("  ForkJoinPool               → Parallel P&L computation");
        System.out.println("  RecursiveTask              → Divide-and-conquer sum/max");
        System.out.println("  ThreadLocal                → Per-thread validation context");
        System.out.println("  InheritableThreadLocal     → Trace ID propagation");
        System.out.println("  Phaser                     → Multi-phase report generation");
        System.out.println("  Daemon threads             → All engine background threads");
        System.out.println("═".repeat(65));
    }
}
