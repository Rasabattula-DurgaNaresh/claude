package com.trading.model;

import java.time.Instant;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Represents a buy/sell order in the trading system.
 *
 * CONCURRENCY: volatile fields for cross-thread visibility of mutable state.
 * AtomicReference for status transitions to ensure atomic compare-and-set.
 */
public class Order implements Comparable<Order> {

    public enum Type   { BUY, SELL }
    public enum Status { PENDING, VALIDATED, MATCHED, EXECUTED, REJECTED, CANCELLED }

    private final String  orderId;
    private final String  accountId;
    private final String  symbol;
    private final Type    type;
    private final int     quantity;

    // volatile: price may be modified by price-adjustment threads; must be visible
    private volatile double price;

    // AtomicReference: status transitions must be atomic (no partial writes)
    private final AtomicReference<Status> status = new AtomicReference<>(Status.PENDING);

    private final Instant submittedAt;
    private volatile Instant executedAt;

    public Order(String accountId, String symbol, Type type, double price, int quantity) {
        this.orderId     = UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        this.accountId   = accountId;
        this.symbol      = symbol;
        this.type        = type;
        this.price       = price;
        this.quantity    = quantity;
        this.submittedAt = Instant.now();
    }

    /**
     * Atomic status transition — CAS ensures only one thread succeeds.
     */
    public boolean transitionStatus(Status expected, Status next) {
        return status.compareAndSet(expected, next);
    }

    public void setStatus(Status s) { status.set(s); }

    // Getters
    public String  getOrderId()     { return orderId; }
    public String  getAccountId()   { return accountId; }
    public String  getSymbol()      { return symbol; }
    public Type    getType()        { return type; }
    public int     getQuantity()    { return quantity; }
    public double  getPrice()       { return price; }
    public Status  getStatus()      { return status.get(); }
    public Instant getSubmittedAt() { return submittedAt; }
    public Instant getExecutedAt()  { return executedAt; }

    public void setPrice(double price)          { this.price = price; }
    public void setExecutedAt(Instant instant)  { this.executedAt = instant; }

    // Priority: BUY orders sorted by highest price first; SELL by lowest
    @Override
    public int compareTo(Order other) {
        if (this.type == Type.BUY) {
            return Double.compare(other.price, this.price); // descending
        }
        return Double.compare(this.price, other.price);    // ascending
    }

    @Override
    public String toString() {
        return String.format("Order[%s %s %s %.2f x%d status=%s]",
                orderId, type, symbol, price, quantity, status.get());
    }
}