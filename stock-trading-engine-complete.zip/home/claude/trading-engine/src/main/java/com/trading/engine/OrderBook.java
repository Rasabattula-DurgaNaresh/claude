package com.trading.engine;

import com.trading.model.Order;
import com.trading.model.Trade;
import java.util.*;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.StampedLock;

/**
 * CONCEPTS: ReentrantLock, StampedLock, volatile
 * ReentrantLock: explicit locking with tryLock, fair ordering.
 * StampedLock: optimistic reads (no lock overhead) with fallback to read lock.
 * volatile: lastTradePrice written by one thread, read by all without locking.
 */
public class OrderBook {
    private final String symbol;
    private final TreeMap<Double, Deque<Order>> buyBook  = new TreeMap<>(Collections.reverseOrder());
    private final TreeMap<Double, Deque<Order>> sellBook = new TreeMap<>();
    private final List<Trade> tradeHistory = new ArrayList<>();
    private final ReentrantLock matchingLock = new ReentrantLock(true); // fair
    private final StampedLock   depthLock    = new StampedLock();
    private volatile double lastTradePrice    = 0.0;
    private volatile int    totalMatchedOrders = 0;

    public OrderBook(String symbol) { this.symbol = symbol; }

    public Optional<Trade> addOrder(Order order) {
        matchingLock.lock();
        try { return order.getType() == Order.Type.BUY ? tryMatchBuy(order) : tryMatchSell(order); }
        finally { matchingLock.unlock(); }
    }

    private Optional<Trade> tryMatchBuy(Order buy) {
        if (sellBook.isEmpty() || buy.getPrice() < sellBook.firstKey()) {
            enqueue(buyBook, buy.getPrice(), buy); return Optional.empty();
        }
        double bestAsk = sellBook.firstKey();
        Deque<Order> sellers = sellBook.get(bestAsk);
        Order sell = sellers.pollFirst();
        if (sellers.isEmpty()) sellBook.remove(bestAsk);
        return Optional.of(executeTrade(buy, sell, bestAsk));
    }

    private Optional<Trade> tryMatchSell(Order sell) {
        if (buyBook.isEmpty() || sell.getPrice() > buyBook.firstKey()) {
            enqueue(sellBook, sell.getPrice(), sell); return Optional.empty();
        }
        double bestBid = buyBook.firstKey();
        Deque<Order> buyers = buyBook.get(bestBid);
        Order buy = buyers.pollFirst();
        if (buyers.isEmpty()) buyBook.remove(bestBid);
        return Optional.of(executeTrade(buy, sell, bestBid));
    }

    private Trade executeTrade(Order buy, Order sell, double price) {
        buy.setStatus(Order.Status.MATCHED);
        sell.setStatus(Order.Status.MATCHED);
        Trade trade = new Trade(buy, sell, price);
        tradeHistory.add(trade);
        lastTradePrice = price;    // volatile write
        totalMatchedOrders += 2;
        return trade;
    }

    private void enqueue(TreeMap<Double, Deque<Order>> book, double price, Order order) {
        book.computeIfAbsent(price, k -> new ArrayDeque<>()).addLast(order);
    }

    public double getBestBid() {
        long stamp = depthLock.tryOptimisticRead();
        double bid = buyBook.isEmpty() ? 0 : buyBook.firstKey();
        if (!depthLock.validate(stamp)) {
            stamp = depthLock.readLock();
            try { bid = buyBook.isEmpty() ? 0 : buyBook.firstKey(); }
            finally { depthLock.unlockRead(stamp); }
        }
        return bid;
    }

    public double getBestAsk() {
        long stamp = depthLock.tryOptimisticRead();
        double ask = sellBook.isEmpty() ? 0 : sellBook.firstKey();
        if (!depthLock.validate(stamp)) {
            stamp = depthLock.readLock();
            try { ask = sellBook.isEmpty() ? 0 : sellBook.firstKey(); }
            finally { depthLock.unlockRead(stamp); }
        }
        return ask;
    }

    public String getSymbol()            { return symbol; }
    public double getLastTradePrice()    { return lastTradePrice; }
    public int    getTotalMatchedOrders(){ return totalMatchedOrders; }
    public List<Trade> getTradeHistory() { return Collections.unmodifiableList(tradeHistory); }
    public int getBuyOrderCount()  { return buyBook.values().stream().mapToInt(Deque::size).sum(); }
    public int getSellOrderCount() { return sellBook.values().stream().mapToInt(Deque::size).sum(); }
}
