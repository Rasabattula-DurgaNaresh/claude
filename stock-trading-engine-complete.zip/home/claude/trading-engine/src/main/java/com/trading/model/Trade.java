package com.trading.model;

import java.time.Instant;
import java.util.UUID;

/**
 * Represents a completed trade between a buyer and a seller.
 * Immutable — thread-safe by construction.
 */
public final class Trade {
    private final String  tradeId;
    private final Order   buyOrder;
    private final Order   sellOrder;
    private final String  symbol;
    private final double  executionPrice;
    private final int     quantity;
    private final Instant tradedAt;
    private final double  tradeValue;  // executionPrice * quantity

    public Trade(Order buyOrder, Order sellOrder, double executionPrice) {
        this.tradeId        = UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        this.buyOrder       = buyOrder;
        this.sellOrder      = sellOrder;
        this.symbol         = buyOrder.getSymbol();
        this.executionPrice = executionPrice;
        this.quantity       = Math.min(buyOrder.getQuantity(), sellOrder.getQuantity());
        this.tradedAt       = Instant.now();
        this.tradeValue     = executionPrice * quantity;
    }

    // All getters — no setters (immutable)
    public String  getTradeId()        { return tradeId; }
    public Order   getBuyOrder()       { return buyOrder; }
    public Order   getSellOrder()      { return sellOrder; }
    public String  getSymbol()         { return symbol; }
    public double  getExecutionPrice() { return executionPrice; }
    public int     getQuantity()       { return quantity; }
    public Instant getTradedAt()       { return tradedAt; }
    public double  getTradeValue()     { return tradeValue; }

    @Override
    public String toString() {
        return String.format("Trade[%s] %s buyer=%s seller=%s price=%.2f qty=%d value=%.2f",
                tradeId, symbol,
                buyOrder.getAccountId(), sellOrder.getAccountId(),
                executionPrice, quantity, tradeValue);
    }
}