package com.trading.engine;

import com.trading.model.Order;
import com.trading.model.Trade;
import com.trading.service.AccountService;
import com.trading.util.MetricsCollector;

import java.time.Instant;
import java.util.concurrent.*;

/**
 * CONCEPTS: CountDownLatch, CompletableFuture pipeline, ExecutorService
 *
 * CountDownLatch(2): settlement is atomic — BOTH debit AND credit must complete
 * before we finalize a trade. latch.await() blocks until count reaches 0.
 *
 * CompletableFuture: non-blocking async pipeline.
 *   debit buyer (async) + credit seller (async) → validate → mark EXECUTED → notify
 */
public class TradeSettlementService {

    private final AccountService   accountService;
    private final MetricsCollector metrics;

    private final ExecutorService settlementPool =
            Executors.newFixedThreadPool(4, r -> {
                Thread t = new Thread(r, "Settler-" + System.nanoTime() % 1000);
                t.setDaemon(true);
                return t;
            });

    public TradeSettlementService(AccountService accountService, MetricsCollector metrics) {
        this.accountService = accountService;
        this.metrics        = metrics;
    }

    public CompletableFuture<Boolean> settle(Trade trade) {
        return CompletableFuture.supplyAsync(() -> doSettle(trade), settlementPool);
    }

    private boolean doSettle(Trade trade) {
        long startMs = System.currentTimeMillis();

        // CountDownLatch(2): wait for both debit + credit to complete
        CountDownLatch latch = new CountDownLatch(2);
        boolean[] results = { false, false };

        // Debit buyer (async)
        CompletableFuture.runAsync(() -> {
            try {
                double val = trade.getExecutionPrice() * trade.getQuantity();
                results[0] = accountService.debit(trade.getBuyOrder().getAccountId(), val);
            } catch (Exception e) {
                results[0] = false;
            } finally {
                latch.countDown(); // 2 -> 1
            }
        }, settlementPool);

        // Credit seller (async, concurrent with debit)
        CompletableFuture.runAsync(() -> {
            try {
                double val = trade.getExecutionPrice() * trade.getQuantity();
                accountService.credit(trade.getSellOrder().getAccountId(), val);
                results[1] = true;
            } catch (Exception e) {
                results[1] = false;
            } finally {
                latch.countDown(); // 1 -> 0
            }
        }, settlementPool);

        // Block until BOTH complete (or 5s timeout)
        try {
            if (!latch.await(5, TimeUnit.SECONDS)) {
                System.err.println("[Settlement] TIMEOUT: " + trade.getTradeId());
                metrics.settlementFailed();
                return false;
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            metrics.settlementFailed();
            return false;
        }

        if (!results[0]) {
            System.err.printf("[Settlement] DEBIT FAILED trade=%s buyer=%s%n",
                    trade.getTradeId(), trade.getBuyOrder().getAccountId());
            metrics.settlementFailed();
            return false;
        }

        // Both succeeded — finalize
        trade.getBuyOrder().setStatus(Order.Status.EXECUTED);
        trade.getSellOrder().setStatus(Order.Status.EXECUTED);
        trade.getBuyOrder().setExecutedAt(Instant.now());
        trade.getSellOrder().setExecutedAt(Instant.now());

        long latencyMs = System.currentTimeMillis() - startMs;
        metrics.tradeExecuted(trade.getQuantity());
        metrics.recordLatency(latencyMs);

        System.out.printf("[Settled] %s  latency=%dms%n", trade, latencyMs);
        return true;
    }

    public void shutdown() {
        settlementPool.shutdown();
        try { settlementPool.awaitTermination(10, TimeUnit.SECONDS); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}
