package com.trading.util;

import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

/**
 * CONCEPT: Semaphore — limits concurrent access to a shared resource.
 *
 * A Semaphore with N permits allows exactly N threads to hold connections
 * simultaneously. The (N+1)th thread BLOCKS until a permit is released.
 *
 * Use case: DB connection pools, HTTP connection limits, rate limiting.
 *
 * Fair semaphore (true) = FIFO ordering, prevents starvation.
 */
public class ConnectionPool {

    private final Semaphore permits;
    private final int       maxConnections;
    private final String    poolName;

    public ConnectionPool(String poolName, int maxConnections) {
        this.poolName       = poolName;
        this.maxConnections = maxConnections;
        this.permits        = new Semaphore(maxConnections, true); // fair = FIFO
    }

    /**
     * Acquire a connection — blocks until one is available or timeout expires.
     * @return true if acquired, false if timed out
     */
    public boolean acquire(long timeoutMs) throws InterruptedException {
        boolean acquired = permits.tryAcquire(timeoutMs, TimeUnit.MILLISECONDS);
        if (!acquired) {
            System.err.printf("[%s] Timeout waiting for connection (available=%d)%n",
                    poolName, permits.availablePermits());
        }
        return acquired;
    }

    /**
     * Release a connection back to the pool.
     * ALWAYS call in finally block!
     */
    public void release() {
        permits.release();
    }

    public int available()    { return permits.availablePermits(); }
    public int inUse()        { return maxConnections - permits.availablePermits(); }
    public int queued()       { return permits.getQueueLength(); }
    public String getPoolName() { return poolName; }

    @Override
    public String toString() {
        return String.format("ConnectionPool[%s inUse=%d/%d queued=%d]",
                poolName, inUse(), maxConnections, queued());
    }
}