package com.trading.util;

/**
 * CONCEPT: ThreadLocal
 * Each thread (validator, settler, reporter) gets its OWN copy of RequestContext.
 * No sharing → no synchronisation needed for the context itself.
 * Critical: always call clear() in finally to prevent memory leaks in thread pools.
 */
public class ThreadLocalContext {

    public static class RequestContext {
        private final String correlationId;
        private final String accountId;
        private final long   startTimeMs;
        private String       currentOperation;

        public RequestContext(String correlationId, String accountId) {
            this.correlationId  = correlationId;
            this.accountId      = accountId;
            this.startTimeMs    = System.currentTimeMillis();
            this.currentOperation = "INIT";
        }

        public long elapsedMs() { return System.currentTimeMillis() - startTimeMs; }
        public String getCorrelationId()           { return correlationId; }
        public String getAccountId()               { return accountId; }
        public String getCurrentOperation()        { return currentOperation; }
        public void   setCurrentOperation(String op){ this.currentOperation = op; }

        @Override
        public String toString() {
            return String.format("[%s|%s|%s|%dms]",
                    correlationId, accountId, currentOperation, elapsedMs());
        }
    }

    // ThreadLocal — each thread has its own independent RequestContext instance
    private static final ThreadLocal<RequestContext> CTX = new ThreadLocal<>();

    // InheritableThreadLocal — child threads (from CompletableFuture async callbacks)
    // automatically inherit parent thread's trace ID
    private static final InheritableThreadLocal<String> TRACE_ID =
            new InheritableThreadLocal<>();

    public static void set(RequestContext ctx)   { CTX.set(ctx); }
    public static RequestContext get()           { return CTX.get(); }

    public static void setTraceId(String traceId) { TRACE_ID.set(traceId); }
    public static String getTraceId()             { return TRACE_ID.get(); }

    /** MUST call in finally block — prevents memory leaks in thread pools! */
    public static void clear() {
        CTX.remove();
        TRACE_ID.remove();
    }

    public static String logPrefix() {
        RequestContext ctx = CTX.get();
        return ctx != null ? ctx.toString() : "[no-ctx]";
    }
}