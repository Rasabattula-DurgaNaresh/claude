package com.trading.model;

import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.LongAdder;

/**
 * Real-time market data for a stock symbol.
 *
 * CONCURRENCY:
 *  - volatile double fields: price updates visible to all threads without locking
 *  - AtomicLong: high/low tracking with CAS (no lock needed)
 *  - LongAdder: volume counting — better than AtomicLong under high contention
 *    because it maintains per-thread cells to reduce CAS collisions
 */
public class MarketData {

    private final String symbol;

    // volatile: written by market-data feed thread, read by all other threads
    private volatile double lastPrice;
    private volatile double bidPrice;   // best buy price
    private volatile double askPrice;   // best sell price
    private volatile long   lastUpdate;

    // AtomicLong stores price * 100 (avoid floating point) for atomic CAS
    private final AtomicLong dayHigh;   // * 100
    private final AtomicLong dayLow;    // * 100

    // LongAdder: much better than synchronized or even AtomicLong for pure increments
    // Under high contention, LongAdder splits into per-thread cells → near-zero contention
    private final LongAdder totalVolume    = new LongAdder();
    private final LongAdder totalTrades    = new LongAdder();
    private final LongAdder totalTurnover  = new LongAdder(); // * 100

    public MarketData(String symbol, double openPrice) {
        this.symbol    = symbol;
        this.lastPrice = openPrice;
        this.bidPrice  = openPrice - 0.01;
        this.askPrice  = openPrice + 0.01;
        this.dayHigh   = new AtomicLong((long)(openPrice * 100));
        this.dayLow    = new AtomicLong((long)(openPrice * 100));
        this.lastUpdate = System.currentTimeMillis();
    }

    /**
     * Update price — uses CAS loop to update day high/low atomically without locking.
     */
    public void updatePrice(double newPrice, int volume) {
        this.lastPrice  = newPrice;  // volatile write
        this.lastUpdate = System.currentTimeMillis();

        long newPriceLong = (long)(newPrice * 100);

        // CAS loop to update dayHigh atomically
        long currentHigh;
        do {
            currentHigh = dayHigh.get();
        } while (newPriceLong > currentHigh && !dayHigh.compareAndSet(currentHigh, newPriceLong));

        // CAS loop to update dayLow atomically
        long currentLow;
        do {
            currentLow = dayLow.get();
        } while (newPriceLong < currentLow && !dayLow.compareAndSet(currentLow, newPriceLong));

        // LongAdder — lock-free, high-throughput counter updates
        totalVolume.add(volume);
        totalTrades.increment();
        totalTurnover.add((long)(newPrice * volume * 100));
    }

    // Getters
    public String getSymbol()       { return symbol; }
    public double getLastPrice()    { return lastPrice; }       // volatile read
    public double getBidPrice()     { return bidPrice; }
    public double getAskPrice()     { return askPrice; }
    public double getDayHigh()      { return dayHigh.get() / 100.0; }
    public double getDayLow()       { return dayLow.get() / 100.0; }
    public long   getTotalVolume()  { return totalVolume.sum(); }    // LongAdder.sum()
    public long   getTotalTrades()  { return totalTrades.sum(); }
    public double getTotalTurnover(){ return totalTurnover.sum() / 100.0; }
    public long   getLastUpdate()   { return lastUpdate; }

    public void setBid(double bid)  { this.bidPrice = bid; }   // volatile write
    public void setAsk(double ask)  { this.askPrice = ask; }
}