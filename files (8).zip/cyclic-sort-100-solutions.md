# 100 Cyclic Sort Problems — Complete Java Solutions

> **100 Problems · 5 Java files · 5 PNG diagrams · O(n) O(1) all core patterns**

---

## Diagram Index

| Diagram | Covers |
|---------|--------|
| `diagrams/01_cyclic_sort_core.png` | Step-by-step sort of [3,1,5,4,2] + master template |
| `diagrams/02_missing_duplicate_detect.png` | All 5 detection cases after sort |
| `diagrams/03_permutation_cycles.png` | Permutation cycles + Floyd's comparison |
| `diagrams/04_variant_templates.png` | All 5 cyclic sort variants + detection passes |
| `diagrams/05_decision_tree.png` | Complete decision guide → algorithm → complexity |

## Project Structure

```
cyclic-sort-100/
├── pom.xml
├── diagrams/           ← 5 PNG flow diagrams
├── docs/               ← This guide
└── src/main/java/com/cyclicsort/
    ├── basic/       BasicCyclicSort.java        (B1-10)
    ├── missing/     MissingVariations.java       (M1-10)
    ├── duplicate/   DuplicateVariations.java     (D1-10)
    ├── permutation/ PermutationProblems.java     (P1-10, PE1-10, I1-10)
    └── advanced/    AdvancedAndMatrix.java       (MA1-10, AD1-10, LC1-10, IN1-10)
```

**Run:**
```bash
mvn compile exec:java -Dexec.mainClass="com.cyclicsort.basic.BasicCyclicSort"
mvn compile exec:java -Dexec.mainClass="com.cyclicsort.advanced.AdvancedAndMatrix"
```

---

# The Core Idea

Cyclic Sort works on arrays where values are in a **known range [1..n]** (or [0..n-1]).
The key insight: **value v belongs at index v-1**.
So we can place each element at its correct position in O(n) with O(1) space.

```
nums = [3, 1, 5, 4, 2]   (range 1..5)
         ↓
After cyclic sort: [1, 2, 3, 4, 5]
         ↓
Scan: first index where nums[i] != i+1 → answer!
```

---

# Master Template

```java
// ═══════════════════════════════════════════════════════════
// SORT PHASE — Place each number at its correct index
// ═══════════════════════════════════════════════════════════
int i = 0;
while (i < nums.length) {
    int j = nums[i] - 1;           // where nums[i] SHOULD be (index)

    if (nums[i] != nums[j]) {      // not in correct position AND no duplicate
        swap(nums, i, j);          // place nums[i] at index j
    } else {
        i++;                       // already correct (or duplicate) → move on
    }
}
// Why no infinite loop? Each swap places at least one number correctly.
// Total swaps ≤ n → O(n) total

// ═══════════════════════════════════════════════════════════
// DETECTION PHASE — Scan for anomaly
// ═══════════════════════════════════════════════════════════
for (int i = 0; i < n; i++) {
    if (nums[i] != i + 1) {
        // nums[i] is the DUPLICATE
        // i + 1   is the MISSING number
    }
}
```

---

# All 5 Variant Templates

## Variant 1 — Range [1..n], no duplicates (classic)
```java
// Use when: all values in [1..n], at most one missing
int j = nums[i] - 1;
if (nums[i] != nums[j]) swap(nums, i, j); else i++;
```

## Variant 2 — Range [0..n-1] (0-indexed)
```java
// Use when: LeetCode 268 (values 0..n)
int j = nums[i];                       // value IS the correct index
if (nums[i] < n && nums[i] != i) swap(nums, i, j); else i++;
```

## Variant 3 — Range [1..n] WITH duplicates
```java
// Use when: LeetCode 442 (find all duplicates)
int j = nums[i] - 1;
if (nums[i] != nums[j]) swap(nums, i, j); // different values → swap
else i++;                                   // same value → duplicate or correct
```

## Variant 4 — First Missing Positive (values may be outside range)
```java
// Use when: LeetCode 41 (arbitrary integers, find first missing positive)
int j = nums[i] - 1;
if (nums[i] > 0 && nums[i] <= n && nums[i] != nums[j])
    swap(nums, i, j);     // only swap if in valid range
else i++;
```

## Variant 5 — Negate Marking (no sort, just mark)
```java
// Use when: LeetCode 442 without modifying sort structure
for (int num : nums) {
    int idx = Math.abs(num) - 1;
    if (nums[idx] < 0) result.add(Math.abs(num)); // already negated → duplicate
    else nums[idx] = -nums[idx];                   // mark as seen
}
```

---

# BASIC CYCLIC SORT (B1–B10)

## B1. Missing Number (LeetCode 268) ⭐
```java
// [3,0,1] → 2
// Sort 0-indexed: nums[i] goes to index nums[i]
// After sort: first i where nums[i] != i is missing
// Or XOR shortcut: XOR(0..n) XOR all elements = missing number
```
**Time:** O(n) **Space:** O(1)

---

## B2. Find All Numbers Disappeared (LeetCode 448) ⭐
```java
// [4,3,2,7,8,2,3,1] → [5,6]
// Cyclic sort: place nums[i] at index nums[i]-1
// After: all indices i where nums[i] != i+1 are missing
```
**Time:** O(n) **Space:** O(1) output not counted

---

## B3. Find the Duplicate Number (LeetCode 287) ⭐⭐
```java
// [1,3,4,2,2] → 2
// Cyclic sort: when nums[i] == nums[nums[i]-1] AND nums[i] != i+1 → duplicate!
// Alternative: Floyd's cycle detection (no array modification)
```
**Time:** O(n) **Space:** O(1)

---

## B4. Find All Duplicates (LeetCode 442) ⭐
```java
// [4,3,2,7,8,2,3,1] → [2,3]
// After cyclic sort: nums[i] != i+1 means nums[i] is a duplicate
```

---

## B5. Set Mismatch (LeetCode 645) ⭐
```java
// [1,2,2,4] → [2,3]  (dup=2, missing=3)
// After sort: first index i with nums[i] != i+1
// Return [nums[i], i+1]
```

---

## B6. First Missing Positive (LeetCode 41) ⭐⭐⭐
```java
// [3,4,-1,1] → 2
// Only place numbers in range [1..n]
// Ignore negatives, zeros, values > n
// After: first i with nums[i] != i+1 → return i+1
```
**This is the hardest variant** — values can be any integer!

---

## B7. Cyclically Sort Numbers [1..n]
```java
// [3,1,5,4,2] → [1,2,3,4,5]
// Pure cyclic sort — the base operation all other problems build on
```

---

## B8. Find Corrupt Pair
Same as B5 — returns [duplicate, missing].

---

## B9. Smallest Missing Positive
Same as B6 — alias.

---

## B10. Missing Number in Sorted Array
```java
// Binary search: if nums[mid] == mid+1 → missing is right; else left
// O(log n) — even better than cyclic sort for sorted input!
```

---

# MISSING NUMBER VARIATIONS (M1–M10)

## M1. Missing Number II (two missing)
Sort then collect all indices where `nums[i] != i+1`.

## M2. Kth Positive (LeetCode 1539)
Binary search or scan — find which positive number is kth missing from sorted array.

## M3. First K Missing Positives
Cyclic sort then collect, extend beyond n if needed. Track extra elements to skip.

## M4. Missing Ranges (LeetCode 163)
Linear scan: track `prev`, output range string for each gap. Use `long` to avoid overflow.

## M5. Smallest Missing Non-Negative
Cyclic sort for [0..n-1] range.

## M6. Missing in Consecutive Sequence
Sort first, then check `nums[i] == start + i`. First violation is missing.

## M7. Find Missing and Repeating ⭐
```java
// Math approach: use sum and sum-of-squares formulas
// diff = expected_sum - actual_sum = missing - repeating
// sqDiff / diff = missing + repeating
// Solve 2-equation system: O(n) O(1)
```

## M8. Missing from 1 to N (XOR)
```java
int xor = 0;
for (int i = 1; i <= n; i++) xor ^= i;
for (int x : nums) xor ^= x;
return xor; // all pairs cancel, missing remains
```

## M9. Find Lost Number (Sum formula)
`missing = n*(n+1)/2 - sum(array)`

## M10. Missing with Duplicates
Standard cyclic sort Variant 4 (handles duplicates safely).

---

# DUPLICATE NUMBER VARIATIONS (D1–D10)

## D1. Find Duplicate Elements
Cyclic sort, then collect indices where `nums[i] != i+1`.

## D2. Find Repeated Number (Floyd's)
Treat array values as "next pointer": `slow=nums[slow], fast=nums[nums[fast]]`.
Phase 2: reset slow to start, advance both by 1 until meeting → cycle entry = duplicate.

## D3. Nearby Duplicate (LeetCode 219)
HashMap: `lastSeen[num]`. If `i - lastSeen[num] <= k` → true.

## D4. Duplicate Zeros (LeetCode 1089)
Count zeros, then fill from end backward.

## D5. Duplicate and Missing Pair
Cyclic sort → first mismatch gives both.

## D6. Find Unique (Single Non-Duplicate)
`XOR` of all elements. Pairs cancel, unique remains.

## D7. Duplicate Cycles Detection
DFS from each unvisited node; if revisit in current traversal → cycle.

## D8. Circular Duplicate
Slow/fast on circular index jumps.

## D9. Duplicate Number II
Cyclic sort variant — same as B3.

## D10. Multiple Duplicates (Negate Marking)
```java
int idx = Math.abs(num) - 1;
if (nums[idx] < 0) → seen before = duplicate
else nums[idx] = -nums[idx]; // mark as seen
```

---

# POSITIVE INTEGER PLACEMENT (P1–P10)

## P1-P2. First Missing Even/Odd
HashSet lookup for smallest even/odd not present.

## P3. Rearrange Positives
Three-way partition: positives → zeros → negatives.

## P5. Position Numbers Correctly
Standard cyclic sort for valid range values.

## P6. Normalize Array
Rank values 1..k preserving order. Use sorted copy + HashMap.

## P7. Rearrange to Identity Permutation
0-indexed cyclic sort: `nums[i] → index nums[i]`.

## P8. Index Matching Rearrangement
Each element to its value's position.

## P9. Place by Frequency
Sort by frequency descending, then by value descending (LeetCode 1636).

## P10. Restore Permutation
Given encoded perm: `result[i+1] = result[i] XOR encoded[i]`.

---

# PERMUTATION & REARRANGEMENT (PE1–PE10)

## PE1. Build Array from Permutation (LeetCode 1920)
`ans[i] = nums[nums[i]]` — one-liner!

## PE2. Array Nesting (LeetCode 565) ⭐⭐
```java
// Find longest chain: i → nums[i] → nums[nums[i]] → ...
// Mark visited with -1. Each element visited once → O(n)
// Answer = max chain length
```

## PE3. Permutation Cycles
Count cycles by DFS from each unvisited node.

## PE4. Reinitialize Permutation (LeetCode 1806)
Simulate reinit steps until identity is reached.

## PE5. Global and Local Inversions (LeetCode 775)
`|nums[i] - i| > 1` for any i → NOT ideal permutation.

## PE6. Beautiful Arrangement (LeetCode 526)
Backtracking: try each unvisited number at each position if divisible.

## PE7. Rearrange by Sign (LeetCode 2149)
Two output pointers: `pos=0, neg=1`, stride 2.

## PE8. Shuffle (LeetCode 1470)
`result[2i] = nums[i], result[2i+1] = nums[n+i]`

## PE9. Sort by Parity (LeetCode 905)
Two-pointer in-place: left from start (find odd), right from end (find even), swap.

## PE10. Wiggle Sort (LeetCode 280)
Single pass: if expected relation violated at index i → swap(i, i-1).

---

# INDEX MAPPING PROBLEMS (I1–I10)

## I1. Smallest Missing Index
Same as B6.

## I2. Index Equals Value Search
Binary search on sorted array: `nums[mid] < mid → lo=mid+1`, else `hi=mid`.

## I3. Rearrange According to Index
`result[index[i]] = nums[i]`

## I4. Index Replacement
Sort, assign rank to each element's position.

## I5. Fixed Point (LeetCode 1064)
Binary search: first i where `arr[i] >= i` in sorted array.

## I6. Recover Swapped Elements
Scan for `nums[i] != i+1`, find where that value is.

---

# MATRIX & GRID (MA1–MA10)

## MA1. Missing in Matrix
Sum all expected 1..n*m, subtract actual sum. O(n*m).

## MA2. Duplicate in Matrix
HashSet scan. O(n*m).

## MA3. Restore Matrix Order
Row-wise: max to top row, min to bottom.

## MA4. Cyclic Grid Rotation
Transpose then reverse each row = 90° clockwise rotation.

## MA5. Matrix Rearrangement
Flatten → sort → reshape.

## MA9. Sort Matrix Diagonally (LeetCode 1329)
Extract each diagonal, sort, put back.

---

# ADVANCED CYCLIC APPLICATIONS (AD1–AD10)

## AD1. Find Corrupted Pair in O(1) Space
Cyclic sort + scan. O(n) time, O(1) space (better than HashSet).

## AD2. Detect Infinite Cycle
Track visited nodes in path; if revisited without leaving → cycle.

## AD3. Circular Array Loop (LeetCode 457) ⭐⭐
Fast/slow with direction constraint (all same sign) + no self-loops.

## AD4. Find Cycle Start
Floyd's phase 2: reset slow to 0, advance both by 1. Meeting = cycle entry.

## AD5. Happy Number (LeetCode 202) ⭐
Floyd's on `sumSquaredDigits(n)` function. If cycle ends at 1 → happy.

## AD6-AD7. Linked List Cycle I/II (LeetCode 141/142) ⭐⭐
Classic Floyd's on linked list nodes.

## AD8. Floyd's for Duplicate (LeetCode 287) ⭐⭐⭐
`slow=nums[slow], fast=nums[nums[fast]]`
Phase 2: reset slow=nums[0], advance both → meet at duplicate.

## AD9. Detect Repeated Permutation
Apply permutation repeatedly until state repeats.

## AD10. Circular Index Traversal
Wrap around using `(cur+1) % n`.

---

# LEETCODE QUICK REFERENCE

| # | Problem | Approach | Time | Space |
|---|---------|----------|------|-------|
| 268 | Missing Number | Cyclic/XOR | O(n) | O(1) |
| 448 | Disappeared Numbers | Cyclic sort | O(n) | O(1) |
| 287 | Find Duplicate | Floyd's / Cyclic | O(n) | O(1) |
| 442 | All Duplicates | Cyclic sort | O(n) | O(1) |
| 41  | First Missing Pos | Cyclic sort | O(n) | O(1) |
| 645 | Set Mismatch | Cyclic sort | O(n) | O(1) |
| 457 | Circular Array Loop | Fast/slow | O(n) | O(1) |
| 202 | Happy Number | Floyd's | O(log n) | O(1) |
| 565 | Array Nesting | Follow path | O(n) | O(1) |
| 1539 | Kth Positive | Binary search | O(log n) | O(1) |

---

# INTERVIEW PROBLEMS (IN1–IN10)

## IN1. Seat Allocation
Find first unoccupied seat = first missing positive in seat array.

## IN2. Student Roll Rearrangement
Cyclic sort on roll numbers [1..n].

## IN3. Missing Ticket
Sum formula: `expected - actual`.

## IN4. Corrupted Database Record
Cyclic sort → returns [duplicate_id, missing_id].

## IN5. Inventory ID Matching
Set lookup for all IDs 1..maxID.

## IN6. Wrongly Placed Elements
After cyclic sort: collect all `nums[i]` where `nums[i] != i+1`.

## IN7. Repeating Sensor ID
Negate-marking scan.

## IN8. Reorder Employee IDs
Cyclic sort on employee ID array.

## IN9. Missing Packet Sequence
Boolean array of received packets; collect gaps.

## IN10. Recover Lost Permutation
Append missing values from 1..n to the partial permutation.

---

# Pattern Selection Guide

```
Is array range [1..n]?
├── YES
│   ├── Find missing single?    → Cyclic sort Var1 or XOR
│   ├── Find all missing?       → Cyclic sort Var1 + scan
│   ├── Find single duplicate?  → Cyclic sort Var1 (when equal) OR Floyd's
│   ├── Find all duplicates?    → Cyclic sort Var3 OR negate marking
│   ├── Find both?              → Cyclic sort Var1 + scan → [nums[i], i+1]
│   └── Values may be >n?      → Cyclic sort Var4 (first missing positive)
└── NO
    ├── [0..n-1] range?         → Cyclic sort Var2 (0-indexed)
    ├── Function creates cycle? → Floyd's tortoise & hare
    ├── Permutation problem?    → Follow cycle path, mark visited
    └── Arbitrary array?        → HashSet, sort, or math formulas
```

---

# Golden Rules

1. **Place at correct index:** `nums[i]` belongs at index `nums[i] - 1`
2. **Swap condition:** `nums[i] != nums[j]` (prevents infinite loop on duplicates)
3. **Skip condition:** `nums[i] == i+1` (already correct) OR out of range
4. **Detection:** scan after sort — `nums[i] != i+1` reveals everything
5. **No Floyd's needed** if you can modify the array (cyclic sort is simpler)
6. **Use Floyd's** when you cannot modify the array (LeetCode 287 follow-up)

*100 Cyclic Sort Problems — Complete Java Solutions | O(n) Time | O(1) Space*
