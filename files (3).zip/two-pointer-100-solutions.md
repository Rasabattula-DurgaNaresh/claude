# 100 Two Pointer Problems in Java — Complete Solutions

> **100 Problems · 6 Java files · 5 PNG diagrams · All patterns with templates**

---

## Diagram Index

| Diagram | Pattern |
|---------|---------|
| `diagrams/01_opposite_ends.png` | Opposite-ends: left=0, right=n-1 converging inward |
| `diagrams/02_fast_slow.png` | Fast/Slow (Floyd's): cycle, middle, Nth-from-end |
| `diagrams/03_read_write.png` | Read/Write: same direction, write lags behind read |
| `diagrams/04_3sum.png` | 3Sum: sort + fix one + opposite-ends on remainder |
| `diagrams/05_decision_tree.png` | Master decision tree: problem → correct pattern |

---

## Core Patterns at a Glance

### Pattern 1 — Opposite Ends (Sorted Array)
```java
// When: sorted array, find pair/triplet with sum/target
// Guarantee: moving the correct pointer provably converges to answer
int left = 0, right = arr.length - 1;
while (left < right) {
    int sum = arr[left] + arr[right];
    if      (sum == target) { /* found */ left++; right--; }
    else if (sum < target)  left++;   // need larger value
    else                    right--;  // need smaller value
}
// Problems: Two Sum II, 3Sum, 4Sum, Container Water, Palindrome
```

### Pattern 2 — Fast / Slow Pointer (Floyd's Algorithm)
```java
// When: linked list cycle detection, middle finding, Nth from end
ListNode slow = head, fast = head;
while (fast != null && fast.next != null) {
    slow = slow.next;           // 1 step
    fast = fast.next.next;      // 2 steps
    if (slow == fast) /* cycle detected! */;
}
// When fast reaches end → slow is at middle
// Problems: Cycle detect, Middle of list, Palindrome list, Reorder list
```

### Pattern 3 — Read / Write (Same Direction)
```java
// When: in-place filtering, removing elements, compressing
// Write pointer: last valid position   Read pointer: scans ahead
int write = 0;
for (int read = 0; read < arr.length; read++) {
    if (shouldKeep(arr[read])) {
        arr[write++] = arr[read]; // copy valid element
    }
    // else: skip — write stays, read advances
}
// Problems: Remove Dups, Remove Element, Move Zeroes, Compress
```

### Pattern 4 — Variable Window (Sliding Window)
```java
// Longest valid: expand freely, shrink when invalid
int left = 0;
for (int right = 0; right < n; right++) {
    // add arr[right] to window
    while (isInvalid()) { left++; }  // shrink
    maxLen = Math.max(maxLen, right - left + 1);
}

// Shortest valid: expand until valid, shrink while valid
for (int right = 0; right < n; right++) {
    // add arr[right]
    while (isValid()) {
        minLen = Math.min(minLen, right - left + 1);
        left++;  // shrink
    }
}
// Problems: Min Window Substring, Min Size Subarray Sum, Permutation
```

### Pattern 5 — Count with atMost Trick
```java
// count(exactly K) = atMost(K) - atMost(K - 1)
int atMost(int[] arr, int k) {
    int left = 0, count = 0;
    // maintain window state with at most k constraint
    for (int right = 0; right < arr.length; right++) {
        // add arr[right]
        while (constraint > k) { left++; /* remove arr[left-1] */ }
        count += right - left + 1; // all subarrays ending at right
    }
    return count;
}
// Problems: Binary Subarrays Sum, Count Fair Pairs, Subarrays K Distinct
```

---

## Pattern Selection Guide

| Problem Hint | Pattern | Time | Space |
|-------------|---------|------|-------|
| Sorted array, find pair | Opposite ends | O(n) | O(1) |
| 3Sum, 4Sum | Sort + fix + opposite ends | O(n²) / O(n³) | O(1) |
| Container/water/rain | Greedy opposite ends | O(n) | O(1) |
| Palindrome check | Opposite ends | O(n) | O(1) |
| Remove/filter in-place | Read/Write same dir | O(n) | O(1) |
| Cycle detection | Fast/Slow | O(n) | O(1) |
| Middle of list | Fast/Slow | O(n) | O(1) |
| Merge sorted arrays | Two forward pointers | O(n+m) | O(1) |
| Longest with constraint | Variable expand | O(n) | O(k) |
| Shortest valid | Variable contract | O(n) | O(k) |
| Count exact K | atMost(K) - atMost(K-1) | O(n) | O(k) |

---

# BEGINNER LEVEL — Problems 1–20

## P1. Two Sum II — Input Array Is Sorted (LeetCode 167) ⭐
**Pattern:** Opposite Ends — sorted array guarantees convergence

```java
public static int[] twoSumSorted(int[] numbers, int target) {
    int left = 0, right = numbers.length - 1;
    while (left < right) {
        int sum = numbers[left] + numbers[right];
        if      (sum == target) return new int[]{left+1, right+1}; // 1-indexed
        else if (sum < target)  left++;   // current sum too small → need bigger left
        else                    right--;  // current sum too big  → need smaller right
    }
    return new int[]{-1, -1};
}
// [2,7,11,15] target=9 → [1,2]
// Why works: sorted array lets us deterministically eliminate candidates
```

---

## P2. Remove Duplicates from Sorted Array (LeetCode 26) ⭐
**Pattern:** Read/Write pointers — write tracks last unique element

```java
public static int removeDuplicates(int[] nums) {
    int write = 0;
    for (int read = 1; read < nums.length; read++) {
        if (nums[read] != nums[write]) {  // found new unique element
            write++;
            nums[write] = nums[read];     // copy to next write position
        }
        // else: duplicate — skip (read advances, write stays)
    }
    return write + 1;
}
// [1,1,2,3,3] → 3 (array becomes [1,2,3,_,_])
```

---

## P3. Remove Element (LeetCode 27)
**Pattern:** Read/Write — keep all elements ≠ val

```java
int write = 0;
for (int read = 0; read < nums.length; read++) {
    if (nums[read] != val) nums[write++] = nums[read];
}
return write;
```

---

## P4. Merge Sorted Array (LeetCode 88) ⭐
**Pattern:** Merge from END — prevents overwriting nums1 data

```java
// p1 = m-1, p2 = n-1, fill from position m+n-1 backward
while (p1 >= 0 && p2 >= 0) {
    if (nums1[p1] > nums2[p2]) nums1[p--] = nums1[p1--];
    else                        nums1[p--] = nums2[p2--];
}
while (p2 >= 0) nums1[p--] = nums2[p2--]; // remaining nums2 elements
// Key: merge backward avoids needing extra space
```

---

## P5. Valid Palindrome (LeetCode 125) ⭐
**Pattern:** Opposite ends, skip non-alphanumeric

```java
int left = 0, right = s.length() - 1;
while (left < right) {
    while (left < right && !Character.isLetterOrDigit(s.charAt(left)))  left++;
    while (left < right && !Character.isLetterOrDigit(s.charAt(right))) right--;
    if (Character.toLowerCase(s.charAt(left)) != Character.toLowerCase(s.charAt(right)))
        return false;
    left++; right--;
}
return true;
// "A man, a plan, a canal: Panama" → true
```

---

## P6. Reverse String (LeetCode 344)
**Pattern:** Opposite ends swap

```java
while (left < right) {
    char tmp = s[left]; s[left++] = s[right]; s[right--] = tmp;
}
```

---

## P7. Reverse Vowels of a String (LeetCode 345)
**Pattern:** Opposite ends, skip non-vowels

```java
while (left < right) {
    while (left < right && !isVowel(s[left]))  left++;
    while (left < right && !isVowel(s[right])) right--;
    if (left < right) swap and advance;
}
```

---

## P8. Squares of a Sorted Array (LeetCode 977) ⭐
**Pattern:** Opposite ends, fill result from BACK (largest square is at either end)

```java
int left = 0, right = n-1, pos = n-1;
while (left <= right) {
    int lSq = nums[left]*nums[left], rSq = nums[right]*nums[right];
    if (lSq > rSq) { result[pos--] = lSq; left++;  }
    else            { result[pos--] = rSq; right--; }
}
// [-4,-1,0,3,10] → [0,1,9,16,100]
// Key: largest squares always at either end of sorted array
```

---

## P9. Move Zeroes (LeetCode 283) ⭐
**Pattern:** Read/Write — copy non-zeros, fill rest with 0

```java
int write = 0;
for (int read = 0; read < nums.length; read++) {
    if (nums[read] != 0) nums[write++] = nums[read];
}
while (write < nums.length) nums[write++] = 0;
// [0,1,0,3,12] → [1,3,12,0,0]
```

---

## P10. Sort Colors / Dutch National Flag (LeetCode 75) ⭐⭐
**Pattern:** Three pointers — lo, mid, hi

```java
int lo = 0, mid = 0, hi = nums.length - 1;
while (mid <= hi) {
    if      (nums[mid] == 0) { swap(lo++, mid++); }  // 0: put in front
    else if (nums[mid] == 1) { mid++; }               // 1: leave in place
    else                     { swap(mid, hi--); }     // 2: put at back (don't mid++!)
}
// [2,0,2,1,1,0] → [0,0,1,1,2,2]
// Critical: don't advance mid when swapping with hi (unknown what came from back)
```

---

## P11. Container With Most Water (LeetCode 11) ⭐⭐
**Pattern:** Opposite ends — always move the SHORTER bar

```java
int left = 0, right = height.length - 1, maxWater = 0;
while (left < right) {
    maxWater = Math.max(maxWater, Math.min(height[left], height[right]) * (right - left));
    if (height[left] < height[right]) left++;   // shorter limits us — try taller
    else                               right--;
}
// [1,8,6,2,5,4,8,3,7] → 49
// Proof: moving taller bar can only maintain or decrease width with same height limit
```

---

## P12. Is Subsequence (LeetCode 392)
**Pattern:** Two forward pointers, s-pointer only advances on match

```java
int ps = 0, pt = 0;
while (ps < s.length() && pt < t.length()) {
    if (s.charAt(ps) == t.charAt(pt)) ps++; // match → advance s
    pt++;                                    // always advance t
}
return ps == s.length();
// "ace" in "abcde" → true
```

---

## P13. Backspace String Compare (LeetCode 844) ⭐
**Pattern:** Scan from END, count pending backspaces

```java
// Process both strings from right, skip characters when backspace count > 0
int skipS = 0, skipT = 0;
while (ps >= 0 || pt >= 0) {
    while (ps >= 0) { if(s[ps]=='#'){skipS++;ps--;} else if(skipS>0){skipS--;ps--;} else break; }
    // same for t
    if (s.charAt(ps) != t.charAt(pt)) return false;
    ps--; pt--;
}
// "ab##" vs "c#d#" → true (both result in "")
```

---

## P14. Merge Strings Alternately (LeetCode 1768)
**Pattern:** Two forward pointers on two strings

```java
while (p1 < word1.length() && p2 < word2.length()) {
    sb.append(word1.charAt(p1++));
    sb.append(word2.charAt(p2++));
}
// Append remaining of longer string
```

---

## P15. Reverse Words in String III (LeetCode 557)
**Pattern:** Find word boundaries, reverse each word's characters in place

---

## P16. Palindrome Linked List (LeetCode 234) ⭐⭐
**Pattern:** Fast/Slow to middle → Reverse second half → Compare

```java
// Step 1: Find middle with fast/slow
// Step 2: Reverse from middle to end
// Step 3: Compare left half with reversed right half
// Time O(n), Space O(1) — in-place reversal
```

---

## P17. Middle of the Linked List (LeetCode 876)
**Pattern:** Fast/Slow — when fast reaches end, slow is at middle

```java
ListNode slow = head, fast = head;
while (fast != null && fast.next != null) {
    slow = slow.next; fast = fast.next.next;
}
return slow; // middle node
```

---

## P18. Remove Duplicates from Sorted List (LeetCode 83)
**Pattern:** Single pointer — skip duplicate nodes

```java
while (curr != null && curr.next != null) {
    if (curr.val == curr.next.val) curr.next = curr.next.next;
    else                           curr = curr.next;
}
```

---

## P19. Delete All Duplicates from Sorted List II (LeetCode 82)
**Pattern:** Prev + curr — skip entire runs of duplicates

```java
// When curr and curr.next have same value, skip all nodes with that value
// Uses dummy head to handle deletion of head node
```

---

## P20. Find Distance Value Between Two Arrays (LeetCode 1385)
**Pattern:** Sort arr2, binary search for each arr1 element — O(n log m)

---

# EASY-MEDIUM — Problems 21–40

## P21. 3Sum (LeetCode 15) ⭐⭐⭐
**Pattern:** Sort + Fix one + Opposite ends | See diagram: `diagrams/04_3sum.png`

```java
Arrays.sort(nums);
for (int i = 0; i < nums.length - 2; i++) {
    if (i > 0 && nums[i] == nums[i-1]) continue; // skip duplicate fixed element
    if (nums[i] > 0) break;                       // all remaining positive, impossible
    int left = i+1, right = nums.length-1;
    while (left < right) {
        int sum = nums[i] + nums[left] + nums[right];
        if (sum == 0) {
            result.add(Arrays.asList(nums[i], nums[left], nums[right]));
            // Skip duplicates before advancing
            while (left < right && nums[left]  == nums[left+1])  left++;
            while (left < right && nums[right] == nums[right-1]) right--;
            left++; right--;
        } else if (sum < 0) left++;
        else                right--;
    }
}
// [-1,0,1,2,-1,-4] → [[-1,-1,2],[-1,0,1]]
// Time O(n²), Space O(1) extra
```

---

## P22. 3Sum Closest (LeetCode 16) ⭐⭐
```java
Arrays.sort(nums);
int closest = nums[0]+nums[1]+nums[2];
for (int i = 0; i < nums.length-2; i++) {
    int l = i+1, r = nums.length-1;
    while (l < r) {
        int sum = nums[i]+nums[l]+nums[r];
        if (Math.abs(sum-target) < Math.abs(closest-target)) closest = sum;
        if (sum < target) l++; else if (sum > target) r--; else return sum;
    }
}
```

---

## P23. 4Sum (LeetCode 18) ⭐⭐
```java
// Two outer loops (i, j) + inner opposite-ends
// Use long for sum to prevent overflow
// Time O(n³)
```

---

## P24. Two Sum Less Than K (LeetCode 1099)
```java
// Sort + opposite ends, find max sum still < k
if (sum < k) { answer = Math.max(answer, sum); left++; }
else           right--;
```

---

## P25. Boats to Save People (LeetCode 881) ⭐
**Pattern:** Sort + opposite ends greedy

```java
// Pair heaviest with lightest if they fit; otherwise heavy goes alone
while (left <= right) {
    if (people[left] + people[right] <= limit) left++;
    right--; // heaviest always boards this boat
    boats++;
}
// [3,2,2,1] limit=3 → 3 boats
```

---

## P26. Assign Cookies (LeetCode 455)
```java
// Sort both, greedily assign smallest sufficient cookie
Arrays.sort(g); Arrays.sort(s);
int pg = 0, ps = 0;
while (pg < g.length && ps < s.length) {
    if (s[ps] >= g[pg]) pg++; // cookie satisfies child
    ps++;
}
return pg;
```

---

## P27. Pair Sum in Sorted Rotated Array
```java
// Find rotation point, then apply circular opposite-ends
// Use modular arithmetic for circular traversal
```

---

## P28. Count Pairs Whose Sum Is Less Than Target (LeetCode 2824)
```java
// Sort, opposite ends: if sum < target, all (left, left+1..right) valid
if (sorted[left] + sorted[right] < target) {
    count += right - left; // right - left pairs are valid with this left
    left++;
} else right--;
```

---

## P29. Count Number of Fair Pairs (LeetCode 2563) ⭐⭐
```java
// count(sum <= upper) - count(sum <= lower - 1)
// Each count uses sort + opposite ends
long countFairPairs(int[] nums, int lower, int upper) {
    Arrays.sort(nums);
    return countAtMost(nums, upper) - countAtMost(nums, lower - 1);
}
// [0,1,7,4,4,5] lower=3 upper=6 → 6
```

---

## P30. Find Pair With Given Difference
```java
// Sort + two forward pointers tracking current difference
// Advance right if diff < k, left if diff > k
```

---

## P31. Trapping Rain Water (LeetCode 42) ⭐⭐⭐
**Pattern:** Opposite ends — track left/right maximum walls

```java
while (left < right) {
    if (height[left] < height[right]) {
        // Left side is bottleneck — water determined by leftMax
        if (height[left] >= leftMax) leftMax = height[left];
        else                          water += leftMax - height[left];
        left++;
    } else {
        if (height[right] >= rightMax) rightMax = height[right];
        else                            water += rightMax - height[right];
        right--;
    }
}
// Water at i = min(maxLeft, maxRight) - height[i]
// [0,1,0,2,1,0,1,3,2,1,2,1] → 6
```

---

## P32. Max Consecutive Ones III (LeetCode 1004) ⭐
```java
// Allow at most K zeros; variable window
while (zeros > k) { if (nums[left++] == 0) zeros--; }
// [1,1,1,0,0,0,1,1,1,1,0] k=2 → 6
```

---

## P33. Longest Mountain in Array (LeetCode 845)
```java
// Find each peak, then expand left and right while decreasing
```

---

## P34. Longest Substring Without Repeating Characters (LeetCode 3) ⭐⭐
```java
Map<Character,Integer> lastSeen = new HashMap<>();
int left = 0, maxLen = 0;
for (int right = 0; right < s.length(); right++) {
    char c = s.charAt(right);
    if (lastSeen.containsKey(c) && lastSeen.get(c) >= left)
        left = lastSeen.get(c) + 1;  // jump past the duplicate
    lastSeen.put(c, right);
    maxLen = Math.max(maxLen, right - left + 1);
}
// "abcabcbb" → 3
```

---

## P35. Longest Repeating Character Replacement (LeetCode 424) ⭐⭐
```java
// Key: (window_size - maxFreq) <= k means window is valid
// maxFreq = most frequent char in window; need ≤k replacements for rest
int[] freq = new int[26];
int left = 0, maxFreq = 0;
for (int right = 0; right < s.length(); right++) {
    freq[s.charAt(right)-'A']++;
    maxFreq = Math.max(maxFreq, freq[s.charAt(right)-'A']);
    if ((right-left+1) - maxFreq > k) freq[s.charAt(left++)-'A']--;
    maxLen = Math.max(maxLen, right-left+1);
}
// "AABABBA" k=1 → 4
```

---

## P36. Minimum Size Subarray Sum (LeetCode 209) ⭐
```java
// Variable contract: shrink while sum >= target
while (sum >= target) {
    minLen = Math.min(minLen, right - left + 1);
    sum -= nums[left++];
}
// [2,3,1,2,4,3] target=7 → 2 ([4,3])
```

---

## P37. Permutation in String (LeetCode 567) ⭐
```java
// Fixed window of len(s1); compare frequency arrays
if (Arrays.equals(need, window)) return true;
// slide: add right char, remove left char
// "ab" in "eidbaooo" → true
```

---

## P38. Find All Anagrams in a String (LeetCode 438) ⭐
```java
// Same as P37 but collect all matching start indices
// "cbaebabacd" "abc" → [0, 6]
```

---

## P39. Minimum Window Substring (LeetCode 76) ⭐⭐⭐
```java
// Variable contract: expand until all t chars covered, shrink to minimize
// Use 'formed' counter (how many char types meet their required count)
while (formed == required) {
    // update answer, then shrink from left
}
// "ADOBECODEBANC","ABC" → "BANC"
// Time O(|s| + |t|)
```

---

## P40. Sliding Window Maximum (LeetCode 239) ⭐⭐
```java
// Monotonic decreasing deque; max always at front
// Add right: pop all smaller elements from back (they're dominated)
// Front: evict if out of window (index < i-k+1)
// [1,3,-1,-3,5,3,6,7] k=3 → [3,3,5,5,6,7]
```

---

# STRING PROBLEMS — 41–60

## P41. Valid Palindrome II (LeetCode 680) ⭐
```java
// Try skipping left or right mismatch — one deletion allowed
if (s.charAt(left) != s.charAt(right))
    return isPalin(s, left+1, right) || isPalin(s, left, right-1);
// "abca" → true (delete 'c' or 'a')
```

---

## P42. Long Pressed Name (LeetCode 925)
```java
// name pointer advances only on match; typed can repeat previous
while (pt < typed.length()) {
    if (pn<name.length() && name[pn]==typed[pt]) { pn++; pt++; }
    else if (pt>0 && typed[pt]==typed[pt-1])      pt++;  // long press
    else return false;
}
```

---

## P43. Shortest Distance to a Character (LeetCode 821)
```java
// Two passes: left→right tracking last c, right→left tracking next c
// Min of both distances at each position
```

---

## P44. Reverse Only Letters (LeetCode 917)
```java
// Opposite ends, skip non-letters (keep non-letter positions)
while (left < right) {
    while (!isLetter(arr[left]))  left++;
    while (!isLetter(arr[right])) right--;
    if (left < right) swap and advance;
}
```

---

## P45. Partition Labels (LeetCode 763) ⭐⭐
```java
// Track last index of each character; partition when current index = end
int[] lastIndex = new int[26];
for (int i=0; i<s.length(); i++) lastIndex[s.charAt(i)-'a'] = i;
int start=0, end=0;
for (int i=0; i<s.length(); i++) {
    end = Math.max(end, lastIndex[s.charAt(i)-'a']);
    if (i == end) { result.add(end-start+1); start=i+1; }
}
// "ababcbacadefegdehijhklij" → [9,7,8]
```

---

## P46. Push Dominoes (LeetCode 838)
```java
// Two passes: right-force (from left) + left-force (from right)
// Net force determines final direction of each domino
```

---

## P47. Compare Version Numbers (LeetCode 165)
```java
// Extract each segment between dots using two pointers
// Compare segment by segment numerically
```

---

## P48. Sentence Similarity III (LeetCode 1813) ⭐
```java
// Match prefix from left, suffix from right
// Middle of shorter must be empty (full overlap)
```

---

## P49. Append Characters to Make Subsequence (LeetCode 2486)
```java
// Match t as subsequence of s, count unmatched tail of t
int pt = 0;
for (char c : s.toCharArray()) if (pt < t.length() && c == t.charAt(pt)) pt++;
return t.length() - pt; // characters that need to be appended
```

---

## P50. Check If Two String Arrays Are Equivalent (LeetCode 1662)
```java
// Two pointers across arrays of strings — virtual concatenation comparison
// No actual string concatenation needed
```

---

## P51. One Edit Distance (LeetCode 161)
```java
// If lengths differ by > 1: false
// Find first mismatch; verify remaining is identical after skip
```

---

## P52. Break a Palindrome (LeetCode 1328)
```java
// Replace first non-'a' with 'a', OR if all 'a' replace last with 'b'
// Must change exactly one character to make it non-palindrome
```

---

## P53. Count Binary Substrings (LeetCode 696) ⭐
```java
// Track consecutive group sizes; count = sum of min(prevGroup, currGroup)
int count=0, prev=0, curr=1;
for (int i=1; i<s.length(); i++) {
    if (s[i]==s[i-1]) curr++;
    else { count+=Math.min(prev,curr); prev=curr; curr=1; }
}
return count + Math.min(prev,curr);
// "00110011" → 6
```

---

## P54. Minimum Length After Deleting Similar Ends (LeetCode 1750) ⭐
```java
// Delete matching characters from both ends; repeat until ends differ
while (left<right && s[left]==s[right]) {
    char c = s[left];
    while (s[left]==c)  left++;
    while (s[right]==c) right--;
}
return right - left + 1;
```

---

## P55-60. Additional String Problems
- P55: Smallest palindrome by matching mismatched pairs with min char
- P56: strStr() — brute force O(n*m) or KMP O(n+m)
- P57: Reverse Words — split + reverse array + join
- P58: Zigzag — simulate rows with direction flag
- P59: String Compression — read/write pointer encoding
- P60: LR Transform — validate relative positions of L and R

---

# ARRAY PROBLEMS — 61–80

## P61. Pair With Target Sum
```java
// Sorted array + opposite ends — O(n)
if (arr[left]+arr[right]==target) return {left,right};
if sum<target: left++; else right--;
```

---

## P62-63. Triplet Sum / Close — Same as P21-22

---

## P64. Triplets With Smaller Sum
```java
// Sort, fix first, count valid triplets with opposite-ends
if (nums[i]+nums[l]+nums[r] < target) {
    count += r-l; // all (l, l+1..r) form valid triplets with nums[i]+nums[l]
    l++;
} else r--;
```

---

## P65. Subarrays With Product Less Than K (LeetCode 713) ⭐
```java
// Variable window — shrink when product >= k
int l=0, product=1;
for (int r=0; r<nums.length; r++) {
    product *= nums[r];
    while (product >= k) product /= nums[l++];
    count += r-l+1; // all subarrays ending at r with product < k
}
// [10,5,2,6] k=100 → 8
```

---

## P66. Minimum Operations to Reduce X to Zero (LeetCode 1658) ⭐⭐
```java
// Key insight: find longest middle subarray with sum = total - x
int target = total - x;
// Standard longest-subarray-with-sum-target via prefix sum or sliding window
// Answer = nums.length - maxMiddleLength
```

---

## P67. Max Area of Island (LeetCode 695)
```java
// DFS traversal — recursive flood fill to count connected 1s
```

---

## P68. Product of Array Except Self (LeetCode 238) ⭐⭐
```java
// Left pass: result[i] = product of all nums[0..i-1]
// Right pass: multiply result[i] by product of all nums[i+1..n-1]
// Time O(n), Space O(1) extra
result[0] = 1;
for (int i=1; i<n; i++) result[i] = result[i-1]*nums[i-1]; // left products
int right=1;
for (int i=n-1; i>=0; i--) { result[i] *= right; right *= nums[i]; } // right products
```

---

## P69-80. More Array Problems
- P69: Duplicate Zeros — two-pass backward fill
- P70: Wiggle Sort — adjacent swaps based on parity
- P71: Intersection Two Arrays — sort both + two pointers O(n log n)
- P72: Interval Intersections — two pointers on sorted intervals
- P73: Min Difference Three Moves — sort + try 4 combinations of changes
- P74: Number of Subsequences — sort + opposite ends + modular power
- P75: Smallest Difference Pair — sort both + two pointers
- P76: Pair Max Sum — sort, return last two elements
- P77: Sorted Squares — same as P8 (opposite ends)
- P78: K-diff Pairs — sort + two forward pointers tracking distance
- P79: Partition by Pivot — three-way partition like Dutch flag
- P80: Separate Positive/Negative — separate two arrays then interleave

---

# LINKED LIST PROBLEMS — 81–90

## P81. Detect Cycle in Linked List (LeetCode 141) ⭐⭐
```java
// Floyd's algorithm: fast=2 steps, slow=1 step
// If they meet → cycle. Proof: fast gains 1 on slow each iteration
// In a cycle of length c: they'll meet after at most c steps
```

---

## P82. Linked List Cycle II (LeetCode 142) ⭐⭐⭐
```java
// Phase 1: detect meeting point (same as P81)
// Phase 2: reset slow to head, advance both at same speed
// Mathematical proof: distance(head→entry) = distance(meeting→entry)
ListNode slow = head;
while (slow != fast) { slow = slow.next; fast = fast.next; }
return slow; // cycle entry
```

---

## P83. Remove Nth Node From End (LeetCode 19) ⭐⭐
```java
// Fast starts N+1 ahead of slow (with dummy head)
// When fast reaches null, slow is just before the Nth-from-end node
ListNode dummy = new ListNode(0); dummy.next = head;
// Advance fast N+1 times
// Walk both until fast is null
slow.next = slow.next.next; // remove the target node
```

---

## P84. Intersection of Two Linked Lists (LeetCode 160) ⭐⭐
```java
// Switch to other list at end — ensures equal total path lengths
ListNode a=headA, b=headB;
while (a != b) {
    a = (a == null) ? headB : a.next;
    b = (b == null) ? headA : b.next;
}
return a; // intersection node or null
// Proof: both traverse lenA + lenB steps total, meeting at intersection
```

---

## P85. Reorder List (LeetCode 143) ⭐⭐⭐
```java
// 3-step approach: Find middle → Reverse second half → Merge alternately
// 1→2→3→4→5 becomes 1→5→2→4→3
// Time O(n), Space O(1)
```

---

## P86. Rotate List (LeetCode 61)
```java
// 1. Find length, make circular
// 2. Advance to (length - k % length - 1)th node
// 3. Cut there: newHead = newTail.next, newTail.next = null
```

---

## P87. Split Linked List in Parts (LeetCode 725)
```java
// Distribute evenly: base = len/k, first (len%k) parts get +1
```

---

## P88. Swap Nodes in Pairs (LeetCode 24) ⭐
```java
// Iterative with prev pointer:
// prev → first → second → rest
// becomes: prev → second → first → rest
while (prev.next != null && prev.next.next != null) {
    ListNode first=prev.next, second=prev.next.next;
    first.next=second.next; second.next=first; prev.next=second;
    prev=first;
}
```

---

## P89. Odd Even Linked List (LeetCode 328) ⭐
```java
// Maintain two chains: odd-indexed and even-indexed nodes
// Reconnect at end: odd tail → even head
while (even != null && even.next != null) {
    odd.next=even.next; odd=odd.next;
    even.next=odd.next; even=even.next;
}
odd.next = evenHead;
```

---

## P90. Flatten Multilevel Doubly Linked List (LeetCode 430)
```java
// When child found: splice child list between curr and curr.next
// Find child list tail, relink pointers
```

---

# ADVANCED PROBLEMS — 91–100

## P91. Shortest Unsorted Continuous Subarray (LeetCode 581) ⭐⭐
```java
// Find min of "wrong" section (scanning right-to-left)
// Find max of "wrong" section (scanning left-to-right)
// Find leftmost position < min, rightmost position > max
// Two-pass approach, O(n) time O(1) space
```

---

## P92. Count Subarrays With Fixed Bounds (LeetCode 2444) ⭐⭐⭐
```java
// Track: lastMin (last index with minK), lastMax (last with maxK), lastBad (out of range)
// count += max(0, min(lastMin, lastMax) - lastBad)
// Elegantly counts valid subarrays ending at each index in O(n)
// [1,3,5,2,7,5] minK=1 maxK=5 → 2
```

---

## P93. Binary Subarrays With Sum (LeetCode 930) ⭐
```java
// atMost trick: count(sum==goal) = atMost(goal) - atMost(goal-1)
// atMost: standard variable window counting subarrays with sum ≤ goal
// [1,0,1,0,1] goal=2 → 4
```

---

## P94. Subarray Product Less Than K (LeetCode 713) — see P65

---

## P95. Minimum Swaps to Group All 1's Together (LeetCode 1151) ⭐
```java
// Fixed window = totalOnes; count zeros in window (= swaps needed)
// Minimize zeros count across all windows
```

---

## P96. Longest Subarray of 1's After Deleting One Element (LeetCode 1493) ⭐
```java
// Allow at most 1 zero; result = window size - 1 (account for deleted element)
while (zeros > 1) { if(nums[left++]==0) zeros--; }
maxLen = Math.max(maxLen, right - left); // note: right - left, not +1
```

---

## P97. Fruit Into Baskets (LeetCode 904) ⭐⭐
```java
// = Longest subarray with at most 2 distinct values
// Variable window with HashMap tracking frequency per fruit type
// [1,2,1] → 3, [3,3,3,1,2,1,1,2,3,3,4] → 5
```

---

## P98. Smallest Range Covering Elements from K Lists (LeetCode 632) ⭐⭐⭐
```java
// Min-heap across K lists; always advance list with current minimum
// Track current max across all lists
// Slide window: extract min, add next from same list, update max
// Time O(n log k), Space O(k)
```

---

## P99. Find K Closest Elements (LeetCode 658) ⭐⭐
```java
// Binary search for optimal window start
// Compare: x - arr[mid]  vs  arr[mid+k] - x
// If left end farther → window starts later (lo = mid+1)
// else hi = mid
// O(log(n-k)) search + O(k) output
```

---

## P100. Minimum Adjacent Swaps for K Consecutive Ones (LeetCode 1703) ⭐⭐⭐
```java
// 1. Collect positions of all 1s
// 2. Adjust: pos[i] - i removes gap counting
// 3. For each window of size k, cost = sum|adj[j] - median|
// 4. Use prefix sums for O(1) window cost calculation
// Median minimizes sum of absolute differences
```

---

## How to Run

```bash
mvn compile

mvn exec:java -Dexec.mainClass="com.twopointer.beginner.BeginnerProblems"
mvn exec:java -Dexec.mainClass="com.twopointer.easymedium.EasyMediumProblems"
mvn exec:java -Dexec.mainClass="com.twopointer.string.StringProblems"
mvn exec:java -Dexec.mainClass="com.twopointer.array.ArrayProblems"
mvn exec:java -Dexec.mainClass="com.twopointer.linkedlist.LinkedListProblems"
mvn exec:java -Dexec.mainClass="com.twopointer.advanced.AdvancedProblems"
```

---

## Complexity Summary

| # | Problem | Time | Space | Pattern |
|---|---------|------|-------|---------|
| 1 | Two Sum II | O(n) | O(1) | Opposite ends |
| 2 | Remove Duplicates | O(n) | O(1) | Read/Write |
| 4 | Merge Sorted | O(m+n) | O(1) | Merge backward |
| 8 | Sorted Squares | O(n) | O(n) | Opposite ends |
| 10 | Sort Colors | O(n) | O(1) | Three pointers |
| 11 | Container Water | O(n) | O(1) | Opposite ends |
| 16 | Palindrome List | O(n) | O(1) | Fast/Slow |
| 21 | 3Sum | O(n²) | O(1) | Fix+opposite |
| 25 | Boats | O(n log n) | O(1) | Sort+opposite |
| 29 | Fair Pairs | O(n log n) | O(1) | atMost trick |
| 31 | Trapping Rain | O(n) | O(1) | Opposite ends |
| 36 | Min Subarray | O(n) | O(1) | Variable contract |
| 39 | Min Window | O(n+m) | O(m) | Variable contract |
| 81 | Detect Cycle | O(n) | O(1) | Fast/Slow |
| 83 | Remove Nth | O(n) | O(1) | Fast/Slow |
| 84 | Intersection | O(m+n) | O(1) | Pointer switch |
| 92 | Fixed Bounds | O(n) | O(1) | Three pointers |
| 98 | Smallest Range | O(n log k) | O(k) | Min-heap |
| 100 | Min Swaps K-1s | O(n) | O(n) | Median window |

*100 Two Pointer Problems — Complete Java Solutions*
