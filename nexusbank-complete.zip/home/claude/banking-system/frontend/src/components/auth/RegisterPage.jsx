import React, { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import toast from 'react-hot-toast'
import { TrendingUp } from 'lucide-react'
import { authApi } from '../../utils/api'
import { useAuthStore } from '../../store/authStore'

export default function RegisterPage() {
  const nav = useNavigate()
  const login = useAuthStore(s => s.login)
  const [form, setForm] = useState({ firstName:'', lastName:'', email:'', phoneNo:'', password:'', dateOfBirth:'' })
  const [loading, setLoading] = useState(false)

  const handle = async (e) => {
    e.preventDefault()
    setLoading(true)
    try {
      const { data } = await authApi.register(form)
      login(data)
      toast.success('Account created successfully!')
      nav('/dashboard')
    } catch (err) {
      toast.error(err.response?.data?.message || 'Registration failed')
    } finally { setLoading(false) }
  }

  const Field = ({ label, field, type='text', placeholder }) => (
    <div style={{ marginBottom:'1rem' }}>
      <label className="label">{label}</label>
      <input className="input" type={type} placeholder={placeholder}
        value={form[field]} onChange={e => setForm(f=>({...f,[field]:e.target.value}))} required />
    </div>
  )

  return (
    <div style={{ minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', padding:'2rem', background:'#0a1628' }}>
      <div style={{ width:'100%', maxWidth:'480px' }} className="animate-fade">
        <div style={{ display:'flex', alignItems:'center', gap:'0.75rem', marginBottom:'2rem' }}>
          <div style={{ width:'36px', height:'36px', borderRadius:'8px', background:'linear-gradient(135deg, #c9a227, #e0b84a)', display:'flex', alignItems:'center', justifyContent:'center' }}>
            <TrendingUp size={18} color="#0a1628" />
          </div>
          <span style={{ fontFamily:'Playfair Display', fontSize:'1.3rem', fontWeight:700 }}>NexusBank</span>
        </div>

        <h2 style={{ fontFamily:'Playfair Display, serif', fontSize:'1.8rem', marginBottom:'0.4rem' }}>Create account</h2>
        <p style={{ color:'#8899aa', marginBottom:'1.8rem', fontSize:'0.9rem' }}>
          Already have an account? <Link to="/login" style={{ color:'#c9a227', textDecoration:'none', fontWeight:600 }}>Sign in</Link>
        </p>

        <div className="card">
          <form onSubmit={handle}>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'0 1rem' }}>
              <Field label="First Name" field="firstName" placeholder="Alice" />
              <Field label="Last Name"  field="lastName"  placeholder="Johnson" />
            </div>
            <Field label="Email"       field="email"       type="email" placeholder="you@email.com" />
            <Field label="Phone"       field="phoneNo"     placeholder="+1234567890" />
            <Field label="Date of Birth" field="dateOfBirth" type="date" />
            <Field label="Password"    field="password"    type="password" placeholder="Min 8 characters" />
            <button className="btn btn-primary" type="submit" disabled={loading}
              style={{ width:'100%', justifyContent:'center', padding:'0.85rem', marginTop:'0.5rem', opacity:loading?0.7:1 }}>
              {loading ? 'Creating account...' : 'Create Account'}
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}