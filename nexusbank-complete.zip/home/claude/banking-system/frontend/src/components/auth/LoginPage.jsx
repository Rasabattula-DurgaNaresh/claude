import React, { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import toast from 'react-hot-toast'
import { Lock, Mail, Eye, EyeOff, TrendingUp } from 'lucide-react'
import { authApi } from '../../utils/api'
import { useAuthStore } from '../../store/authStore'

export default function LoginPage() {
  const nav = useNavigate()
  const login = useAuthStore(s => s.login)
  const [form, setForm] = useState({ login: '', password: '' })
  const [show, setShow] = useState(false)
  const [loading, setLoading] = useState(false)

  const handle = async (e) => {
    e.preventDefault()
    setLoading(true)
    try {
      const { data } = await authApi.login(form)
      login(data)
      toast.success(`Welcome back, ${data.fullName}!`)
      nav('/dashboard')
    } catch (err) {
      toast.error(err.response?.data?.message || 'Login failed')
    } finally { setLoading(false) }
  }

  return (
    <div style={{ minHeight:'100vh', display:'grid', gridTemplateColumns:'1fr 1fr' }}>
      {/* Left — Brand panel */}
      <div style={{ background:'linear-gradient(135deg, #0a1628 0%, #112040 60%, #1a3260 100%)', display:'flex', flexDirection:'column', justifyContent:'center', padding:'4rem', position:'relative', overflow:'hidden' }}>
        <div style={{ position:'absolute', top:'-20%', right:'-10%', width:'500px', height:'500px', borderRadius:'50%', background:'radial-gradient(circle, rgba(201,162,39,0.08) 0%, transparent 70%)' }} />
        <div style={{ position:'absolute', bottom:'-20%', left:'-10%', width:'400px', height:'400px', borderRadius:'50%', background:'radial-gradient(circle, rgba(59,130,246,0.06) 0%, transparent 70%)' }} />

        <div style={{ display:'flex', alignItems:'center', gap:'0.75rem', marginBottom:'3rem' }}>
          <div style={{ width:'42px', height:'42px', borderRadius:'10px', background:'linear-gradient(135deg, #c9a227, #e0b84a)', display:'flex', alignItems:'center', justifyContent:'center' }}>
            <TrendingUp size={22} color="#0a1628" strokeWidth={2.5} />
          </div>
          <span style={{ fontFamily:'Playfair Display, serif', fontSize:'1.5rem', fontWeight:700, color:'#f8fafc' }}>NexusBank</span>
        </div>

        <h1 style={{ fontFamily:'Playfair Display, serif', fontSize:'2.8rem', fontWeight:700, lineHeight:1.2, marginBottom:'1rem', color:'#f8fafc' }}>
          Your finances,<br/><span style={{ color:'#c9a227' }}>reimagined.</span>
        </h1>
        <p style={{ color:'#8899aa', fontSize:'1rem', lineHeight:1.7, maxWidth:'360px' }}>
          Microservices-powered banking with real-time transactions, intelligent analytics, and enterprise-grade security.
        </p>

        <div style={{ marginTop:'3rem', display:'flex', gap:'2rem' }}>
          {[['$2.4B+', 'Assets Managed'], ['150K+', 'Active Users'], ['99.99%', 'Uptime']].map(([v,l]) => (
            <div key={l}>
              <div style={{ fontFamily:'Playfair Display', fontSize:'1.4rem', fontWeight:700, color:'#c9a227' }}>{v}</div>
              <div style={{ fontSize:'0.78rem', color:'#8899aa', marginTop:'0.2rem' }}>{l}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Right — Login form */}
      <div style={{ display:'flex', alignItems:'center', justifyContent:'center', padding:'2rem', background:'#112040' }}>
        <div style={{ width:'100%', maxWidth:'400px' }} className="animate-fade">
          <h2 style={{ fontFamily:'Playfair Display, serif', fontSize:'2rem', marginBottom:'0.5rem' }}>Sign in</h2>
          <p style={{ color:'#8899aa', marginBottom:'2rem', fontSize:'0.9rem' }}>
            New to NexusBank? <Link to="/register" style={{ color:'#c9a227', textDecoration:'none', fontWeight:600 }}>Create account</Link>
          </p>

          <form onSubmit={handle}>
            <div style={{ marginBottom:'1.2rem' }}>
              <label className="label">Email or Phone</label>
              <div style={{ position:'relative' }}>
                <Mail size={16} style={{ position:'absolute', left:'0.9rem', top:'50%', transform:'translateY(-50%)', color:'#8899aa' }} />
                <input className="input" style={{ paddingLeft:'2.5rem' }} placeholder="you@nexusbank.com"
                  value={form.login} onChange={e => setForm(f=>({...f, login:e.target.value}))} required />
              </div>
            </div>
            <div style={{ marginBottom:'1.5rem' }}>
              <label className="label">Password</label>
              <div style={{ position:'relative' }}>
                <Lock size={16} style={{ position:'absolute', left:'0.9rem', top:'50%', transform:'translateY(-50%)', color:'#8899aa' }} />
                <input className="input" style={{ paddingLeft:'2.5rem', paddingRight:'2.5rem' }}
                  type={show?'text':'password'} placeholder="••••••••"
                  value={form.password} onChange={e => setForm(f=>({...f, password:e.target.value}))} required />
                <button type="button" onClick={()=>setShow(s=>!s)}
                  style={{ position:'absolute', right:'0.9rem', top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', color:'#8899aa' }}>
                  {show ? <EyeOff size={16}/> : <Eye size={16}/>}
                </button>
              </div>
            </div>

            <button className="btn btn-primary" type="submit" disabled={loading}
              style={{ width:'100%', justifyContent:'center', padding:'0.85rem', fontSize:'0.95rem', opacity:loading?0.7:1 }}>
              {loading ? 'Signing in...' : 'Sign in'}
            </button>
          </form>

          <div style={{ marginTop:'1.5rem', padding:'1rem', borderRadius:'10px', background:'rgba(201,162,39,0.08)', border:'1px solid rgba(201,162,39,0.2)' }}>
            <p style={{ fontSize:'0.8rem', color:'#8899aa', marginBottom:'0.3rem' }}>Demo credentials</p>
            <p style={{ fontSize:'0.82rem', color:'#c9a227' }}>admin@nexusbank.com / Admin@123456</p>
          </div>
        </div>
      </div>
    </div>
  )
}