import React, { useEffect, useState } from 'react'
import { ArrowUpRight, ArrowDownLeft, TrendingUp, TrendingDown, Wallet, CreditCard, RefreshCw, Plus } from 'lucide-react'
import { AreaChart, Area, PieChart, Pie, Cell, Tooltip, ResponsiveContainer, XAxis, YAxis } from 'recharts'
import { useNavigate } from 'react-router-dom'
import { accountApi, transactionApi } from '../../utils/api'
import { useAuthStore } from '../../store/authStore'
import { format, subMonths, startOfMonth } from 'date-fns'

const fmt = (n) => n ? new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',minimumFractionDigits:2}).format(n) : '$0.00'

const MetricCard = ({ title, value, sub, icon: Icon, color, trend }) => (
  <div className="card animate-fade" style={{ position:'relative', overflow:'hidden' }}>
    <div style={{ position:'absolute', top:0, right:0, width:'80px', height:'80px', borderRadius:'0 14px 0 80px', background:`${color}12` }} />
    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
      <div>
        <p style={{ fontSize:'0.78rem', color:'#8899aa', textTransform:'uppercase', letterSpacing:'0.05em', marginBottom:'0.5rem' }}>{title}</p>
        <p style={{ fontSize:'1.6rem', fontWeight:700, fontFamily:'Playfair Display', color:'#f8fafc' }}>{value}</p>
        {sub && <p style={{ fontSize:'0.78rem', color:trend>=0?'#22c55e':'#ef4444', marginTop:'0.3rem', display:'flex', alignItems:'center', gap:'0.25rem' }}>
          {trend >= 0 ? <TrendingUp size={12}/> : <TrendingDown size={12}/>} {sub}
        </p>}
      </div>
      <div style={{ width:'42px', height:'42px', borderRadius:'10px', background:`${color}18`, display:'flex', alignItems:'center', justifyContent:'center' }}>
        <Icon size={20} color={color} strokeWidth={1.8} />
      </div>
    </div>
  </div>
)

const chartData = [
  { month:'Jan', income:4200, expense:2800 },
  { month:'Feb', income:5100, expense:3100 },
  { month:'Mar', income:4800, expense:2600 },
  { month:'Apr', income:6200, expense:3800 },
  { month:'May', income:5800, expense:3200 },
  { month:'Jun', income:7100, expense:4100 },
]

const spendColors = ['#c9a227','#3b82f6','#22c55e','#ef4444','#a855f7','#f97316']

export default function Dashboard() {
  const nav = useNavigate()
  const user = useAuthStore(s => s.user)
  const [accounts, setAccounts] = useState([])
  const [spending, setSpending] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    (async () => {
      try {
        const [accRes] = await Promise.all([accountApi.getAll()])
        setAccounts(accRes.data || [])
        try {
          const from = subMonths(new Date(), 1).toISOString()
          const to   = new Date().toISOString()
          const sRes = await transactionApi.getSpending(from, to)
          setSpending(sRes.data || [])
        } catch {}
      } catch {}
      setLoading(false)
    })()
  }, [])

  const totalBalance = accounts.reduce((s, a) => s + (a.availableBalance || 0), 0)
  const totalAccounts= accounts.length
  const hour = new Date().getHours()
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening'

  return (
    <div style={{ padding:'2rem', maxWidth:'1200px' }}>
      {/* Header */}
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:'2rem' }}>
        <div>
          <p style={{ color:'#8899aa', fontSize:'0.9rem', marginBottom:'0.25rem' }}>{greeting},</p>
          <h1 style={{ fontFamily:'Playfair Display', fontSize:'2rem', fontWeight:700 }}>
            {user?.fullName?.split(' ')[0]} <span style={{ color:'#c9a227' }}>👋</span>
          </h1>
          <p style={{ color:'#8899aa', fontSize:'0.85rem', marginTop:'0.3rem' }}>CIF: {user?.cifNo}</p>
        </div>
        <div style={{ display:'flex', gap:'0.75rem' }}>
          <button className="btn btn-ghost" onClick={()=>window.location.reload()}>
            <RefreshCw size={14}/> Refresh
          </button>
          <button className="btn btn-primary" onClick={()=>nav('/accounts')}>
            <Plus size={14}/> New Account
          </button>
        </div>
      </div>

      {/* Metrics */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(200px, 1fr))', gap:'1rem', marginBottom:'2rem' }}>
        <MetricCard title="Total Balance"    value={loading?'...' :fmt(totalBalance)} sub="+2.4% this month" icon={Wallet}    color="#c9a227" trend={1} />
        <MetricCard title="Active Accounts"  value={loading?'...' :totalAccounts}     sub={`${totalAccounts} accounts`}        icon={CreditCard} color="#3b82f6" trend={1} />
        <MetricCard title="Monthly Income"   value={fmt(7100)}  sub="+18% vs last month" icon={ArrowUpRight}   color="#22c55e" trend={1} />
        <MetricCard title="Monthly Spend"    value={fmt(4100)}  sub="+5% vs last month"  icon={ArrowDownLeft}  color="#ef4444" trend={-1} />
      </div>

      {/* Charts */}
      <div style={{ display:'grid', gridTemplateColumns:'2fr 1fr', gap:'1.5rem', marginBottom:'2rem' }}>
        {/* Area chart */}
        <div className="card">
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'1.5rem' }}>
            <h3 style={{ fontWeight:600 }}>Cash Flow</h3>
            <div style={{ display:'flex', gap:'1rem', fontSize:'0.78rem' }}>
              <span style={{ color:'#c9a227' }}>● Income</span>
              <span style={{ color:'#ef4444' }}>● Expense</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="inc" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="#c9a227" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#c9a227" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="exp" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="#ef4444" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <XAxis dataKey="month" tick={{fill:'#8899aa',fontSize:11}} axisLine={false} tickLine={false} />
              <YAxis tick={{fill:'#8899aa',fontSize:11}} axisLine={false} tickLine={false} tickFormatter={v=>`$${v/1000}k`} />
              <Tooltip contentStyle={{background:'#1a3260',border:'1px solid rgba(255,255,255,0.1)',borderRadius:'8px',color:'#f8fafc'}} formatter={v=>[fmt(v)]} />
              <Area type="monotone" dataKey="income"  stroke="#c9a227" fill="url(#inc)" strokeWidth={2} />
              <Area type="monotone" dataKey="expense" stroke="#ef4444" fill="url(#exp)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Spending pie */}
        <div className="card">
          <h3 style={{ fontWeight:600, marginBottom:'1.5rem' }}>Spending</h3>
          {spending.length > 0 ? (
            <>
              <ResponsiveContainer width="100%" height={150}>
                <PieChart>
                  <Pie data={spending} dataKey="totalAmount" nameKey="category" cx="50%" cy="50%" outerRadius={65} innerRadius={40}>
                    {spending.map((_, i) => <Cell key={i} fill={spendColors[i % spendColors.length]} />)}
                  </Pie>
                  <Tooltip contentStyle={{background:'#1a3260',border:'none',borderRadius:'8px',color:'#f8fafc'}} formatter={v=>[fmt(v)]} />
                </PieChart>
              </ResponsiveContainer>
              {spending.slice(0,4).map((s,i)=>(
                <div key={i} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginTop:'0.5rem' }}>
                  <div style={{ display:'flex', alignItems:'center', gap:'0.5rem' }}>
                    <div style={{ width:'8px', height:'8px', borderRadius:'50%', background:spendColors[i%spendColors.length] }} />
                    <span style={{ fontSize:'0.8rem', color:'#8899aa' }}>{s.category || 'Other'}</span>
                  </div>
                  <span style={{ fontSize:'0.8rem', fontWeight:600 }}>{fmt(s.totalAmount)}</span>
                </div>
              ))}
            </>
          ) : (
            <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:'180px', color:'#8899aa', fontSize:'0.85rem' }}>
              No spending data yet
            </div>
          )}
        </div>
      </div>

      {/* Account cards */}
      <div className="card">
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'1.25rem' }}>
          <h3 style={{ fontWeight:600 }}>My Accounts</h3>
          <button className="btn btn-ghost" onClick={()=>nav('/accounts')} style={{ fontSize:'0.8rem', padding:'0.4rem 0.75rem' }}>
            View all →
          </button>
        </div>
        {loading ? (
          <div style={{ display:'flex', gap:'1rem' }}>
            {[1,2].map(i=><div key={i} className="loading" style={{ height:'120px', flex:1, borderRadius:'10px', background:'rgba(255,255,255,0.05)' }} />)}
          </div>
        ) : accounts.length === 0 ? (
          <div style={{ textAlign:'center', padding:'2rem', color:'#8899aa' }}>
            <Wallet size={32} style={{ margin:'0 auto 0.75rem', opacity:0.4 }} />
            <p>No accounts yet</p>
            <button className="btn btn-primary" style={{ margin:'1rem auto 0' }} onClick={()=>nav('/accounts')}>Open Account</button>
          </div>
        ) : (
          <div style={{ display:'flex', gap:'1rem', flexWrap:'wrap' }}>
            {accounts.map(a => (
              <div key={a.accountId} style={{
                flex:'1 1 240px', minWidth:'240px', padding:'1.25rem',
                borderRadius:'12px', cursor:'pointer',
                background:`linear-gradient(135deg, ${a.accountType==='SAVINGS'?'#1a3260, #0a2040':a.accountType==='CURRENT'?'#1a1040, #2a1060':'#0a2a20, #0a3a20'})`,
                border:'1px solid rgba(255,255,255,0.08)',
                transition:'transform 0.2s, box-shadow 0.2s',
              }}
                onClick={()=>nav('/statement')}
                onMouseEnter={e=>{e.currentTarget.style.transform='translateY(-2px)';e.currentTarget.style.boxShadow='0 8px 24px rgba(0,0,0,0.3)'}}
                onMouseLeave={e=>{e.currentTarget.style.transform='none';e.currentTarget.style.boxShadow='none'}}
              >
                <div style={{ display:'flex', justifyContent:'space-between', marginBottom:'1rem' }}>
                  <span className="badge badge-gold" style={{ fontSize:'0.7rem' }}>{a.accountType}</span>
                  <span className={`badge badge-${a.status==='ACTIVE'?'green':'red'}`} style={{ fontSize:'0.7rem' }}>{a.status}</span>
                </div>
                <p style={{ fontSize:'1.5rem', fontWeight:700, fontFamily:'Playfair Display', marginBottom:'0.25rem' }}>{fmt(a.availableBalance)}</p>
                <p style={{ fontSize:'0.75rem', color:'rgba(255,255,255,0.5)' }}>{a.accountNumber}</p>
                <p style={{ fontSize:'0.7rem', color:'rgba(255,255,255,0.35)', marginTop:'0.75rem' }}>{a.ifscCode}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}