import React, { useState } from 'react'
import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import { TrendingUp, LayoutDashboard, Wallet, ArrowLeftRight, FileText, CreditCard, LogOut, Bell, ChevronLeft } from 'lucide-react'
import { useAuthStore } from '../../store/authStore'
import { authApi } from '../../utils/api'
import toast from 'react-hot-toast'

const NavItem = ({ to, icon: Icon, label, collapsed }) => (
  <NavLink to={to} style={({ isActive }) => ({
    display:'flex', alignItems:'center', gap:'0.75rem',
    padding: collapsed ? '0.75rem' : '0.75rem 1rem',
    borderRadius:'10px', textDecoration:'none', fontSize:'0.875rem', fontWeight:500,
    transition:'all 0.2s',
    justifyContent: collapsed ? 'center' : 'flex-start',
    color: isActive ? '#c9a227' : '#8899aa',
    background: isActive ? 'rgba(201,162,39,0.1)' : 'transparent',
    borderLeft: isActive ? '3px solid #c9a227' : '3px solid transparent',
    marginBottom:'0.25rem',
  })}>
    <Icon size={18} strokeWidth={1.8} />
    {!collapsed && <span>{label}</span>}
  </NavLink>
)

export default function Layout() {
  const nav = useNavigate()
  const { user, logout } = useAuthStore()
  const [collapsed, setCollapsed] = useState(false)

  const handleLogout = async () => {
    try { await authApi.logout() } catch {}
    logout()
    nav('/login')
    toast.success('Signed out successfully')
  }

  return (
    <div style={{ display:'flex', minHeight:'100vh', background:'#0a1628' }}>
      {/* Sidebar */}
      <aside style={{
        width: collapsed ? '72px' : '240px', flexShrink:0,
        background:'#112040',
        borderRight:'1px solid rgba(255,255,255,0.06)',
        display:'flex', flexDirection:'column',
        transition:'width 0.25s ease', overflow:'hidden',
        position:'sticky', top:0, height:'100vh',
      }}>
        {/* Logo */}
        <div style={{ padding: collapsed ? '1.25rem 0' : '1.25rem 1.25rem', display:'flex', alignItems:'center', justifyContent: collapsed?'center':'space-between', borderBottom:'1px solid rgba(255,255,255,0.06)', marginBottom:'1rem' }}>
          {!collapsed && (
            <div style={{ display:'flex', alignItems:'center', gap:'0.6rem' }}>
              <div style={{ width:'32px', height:'32px', borderRadius:'8px', background:'linear-gradient(135deg,#c9a227,#e0b84a)', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
                <TrendingUp size={16} color="#0a1628" strokeWidth={2.5} />
              </div>
              <span style={{ fontFamily:'Playfair Display', fontSize:'1.1rem', fontWeight:700, whiteSpace:'nowrap' }}>NexusBank</span>
            </div>
          )}
          {collapsed && <div style={{ width:'32px', height:'32px', borderRadius:'8px', background:'linear-gradient(135deg,#c9a227,#e0b84a)', display:'flex', alignItems:'center', justifyContent:'center' }}><TrendingUp size={16} color="#0a1628" strokeWidth={2.5} /></div>}
          <button onClick={()=>setCollapsed(c=>!c)} style={{ background:'none', border:'none', cursor:'pointer', color:'#8899aa', padding:'0.25rem', borderRadius:'6px' }}>
            <ChevronLeft size={16} style={{ transform: collapsed?'rotate(180deg)':'none', transition:'transform 0.25s' }} />
          </button>
        </div>

        {/* Nav */}
        <nav style={{ flex:1, padding:'0 0.75rem', overflowY:'auto' }}>
          {!collapsed && <p style={{ fontSize:'0.68rem', color:'#8899aa', textTransform:'uppercase', letterSpacing:'0.08em', marginBottom:'0.5rem', paddingLeft:'0.5rem' }}>Main</p>}
          <NavItem to="/dashboard" icon={LayoutDashboard} label="Dashboard"  collapsed={collapsed} />
          <NavItem to="/accounts"  icon={Wallet}          label="Accounts"   collapsed={collapsed} />
          <NavItem to="/transfer"  icon={ArrowLeftRight}  label="Transfer"   collapsed={collapsed} />
          <NavItem to="/statement" icon={FileText}        label="Statement"  collapsed={collapsed} />
          <NavItem to="/loans"     icon={CreditCard}      label="Loans"      collapsed={collapsed} />
        </nav>

        {/* User */}
        <div style={{ padding:'1rem', borderTop:'1px solid rgba(255,255,255,0.06)' }}>
          {!collapsed && user && (
            <div style={{ marginBottom:'0.75rem' }}>
              <div style={{ fontSize:'0.85rem', fontWeight:600, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{user.fullName}</div>
              <div style={{ fontSize:'0.72rem', color:'#8899aa', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{user.cifNo}</div>
            </div>
          )}
          <button onClick={handleLogout} className="btn btn-ghost"
            style={{ width:'100%', justifyContent: collapsed?'center':'flex-start', fontSize:'0.82rem', padding:'0.6rem 0.8rem' }}>
            <LogOut size={15} />
            {!collapsed && 'Sign out'}
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main style={{ flex:1, overflow:'auto', background:'#0d1f3c' }}>
        <Outlet />
      </main>
    </div>
  )
}