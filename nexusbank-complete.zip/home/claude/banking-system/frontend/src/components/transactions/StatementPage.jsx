import React, { useEffect, useState } from 'react'
import { ArrowUpCircle, ArrowDownCircle, Filter, Download } from 'lucide-react'
import { transactionApi, accountApi } from '../../utils/api'
import { format } from 'date-fns'

const fmt = (n) => new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(n||0)

export default function StatementPage() {
  const [accounts, setAccounts] = useState([])
  const [selected, setSelected] = useState('')
  const [txns, setTxns] = useState([])
  const [page, setPage] = useState(0)
  const [totalPages, setTotalPages] = useState(0)
  const [loading, setLoading] = useState(false)

  useEffect(()=>{
    accountApi.getAll().then(r=>{
      const accs = r.data || []
      setAccounts(accs)
      if (accs.length) setSelected(accs[0].accountNumber)
    }).catch(()=>{})
  },[])

  useEffect(()=>{
    if (!selected) return
    setLoading(true)
    transactionApi.getStatement(selected, page).then(r=>{
      setTxns(r.data.content || [])
      setTotalPages(r.data.totalPages || 0)
    }).catch(()=>setTxns([])).finally(()=>setLoading(false))
  },[selected, page])

  const credit = txns.filter(t=>t.transactionType==='CREDIT'||t.transactionType==='FUND_TRANSFER'&&false)
  const debit  = txns.filter(t=>['DEBIT','FUND_TRANSFER','NEFT','RTGS','IMPS','BILL_PAYMENT'].includes(t.transactionType))

  const typeColor = (t) => ['CREDIT'].includes(t) ? '#22c55e' : '#ef4444'
  const typeIcon  = (t) => ['CREDIT'].includes(t) ? ArrowUpCircle : ArrowDownCircle

  return (
    <div style={{ padding:'2rem', maxWidth:'900px' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:'2rem' }}>
        <div>
          <h1 style={{ fontFamily:'Playfair Display', fontSize:'1.8rem', fontWeight:700 }}>Account Statement</h1>
          <p style={{ color:'#8899aa', fontSize:'0.875rem', marginTop:'0.3rem' }}>Full transaction history</p>
        </div>
        <button className="btn btn-ghost"><Download size={14}/> Export</button>
      </div>

      {/* Account selector */}
      <div className="card" style={{ marginBottom:'1.5rem', display:'flex', gap:'0.75rem', alignItems:'center', flexWrap:'wrap' }}>
        <Filter size={14} style={{ color:'#8899aa' }} />
        <div style={{ display:'flex', gap:'0.5rem', flexWrap:'wrap' }}>
          {accounts.map(a=>(
            <button key={a.accountId} className={`btn ${selected===a.accountNumber?'btn-primary':'btn-ghost'}`}
              style={{ fontSize:'0.8rem', padding:'0.4rem 0.85rem' }}
              onClick={()=>{setSelected(a.accountNumber);setPage(0)}}>
              {a.accountNumber}
            </button>
          ))}
        </div>
      </div>

      {/* Transaction list */}
      <div className="card" style={{ padding:0, overflow:'hidden' }}>
        <div style={{ padding:'1rem 1.5rem', borderBottom:'1px solid rgba(255,255,255,0.06)', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <h3 style={{ fontWeight:600 }}>Transactions</h3>
          <span style={{ fontSize:'0.8rem', color:'#8899aa' }}>Page {page+1} of {Math.max(1,totalPages)}</span>
        </div>

        {loading ? (
          <div style={{ padding:'2rem' }}>
            {[1,2,3,4,5].map(i=><div key={i} className="loading" style={{ height:'56px', borderRadius:'8px', background:'rgba(255,255,255,0.04)', marginBottom:'0.5rem' }} />)}
          </div>
        ) : txns.length === 0 ? (
          <div style={{ padding:'4rem', textAlign:'center', color:'#8899aa' }}>
            <ArrowUpCircle size={36} style={{ margin:'0 auto 1rem', opacity:0.3 }} />
            <p>No transactions found</p>
          </div>
        ) : txns.map((t,i) => {
          const Icon = typeIcon(t.transactionType)
          const color = typeColor(t.transactionType)
          const isCredit = t.transactionType === 'CREDIT'
          return (
            <div key={i} style={{ display:'grid', gridTemplateColumns:'auto 1fr auto', gap:'1rem', alignItems:'center', padding:'1rem 1.5rem', borderBottom:'1px solid rgba(255,255,255,0.04)', transition:'background 0.15s' }}
              onMouseEnter={e=>e.currentTarget.style.background='rgba(255,255,255,0.02)'}
              onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
              <div style={{ width:'38px', height:'38px', borderRadius:'10px', background:`${color}15`, display:'flex', alignItems:'center', justifyContent:'center' }}>
                <Icon size={18} color={color} strokeWidth={1.8} />
              </div>
              <div>
                <p style={{ fontWeight:500, fontSize:'0.875rem' }}>{t.description || t.transactionType}</p>
                <p style={{ fontSize:'0.75rem', color:'#8899aa', marginTop:'0.15rem' }}>
                  {t.referenceNumber} · {t.transactionDate ? format(new Date(t.transactionDate),'dd MMM yyyy HH:mm') : ''}
                </p>
                {t.counterpartyName && <p style={{ fontSize:'0.72rem', color:'#8899aa' }}>{isCredit?'From':'To'}: {t.counterpartyName}</p>}
              </div>
              <div style={{ textAlign:'right' }}>
                <p style={{ fontWeight:700, color, fontSize:'0.95rem' }}>{isCredit?'+':'-'}{fmt(t.amount)}</p>
                {t.charges > 0 && <p style={{ fontSize:'0.72rem', color:'#ef4444', marginTop:'0.1rem' }}>Fee: {fmt(t.charges)}</p>}
                <span className={`badge badge-${t.status==='COMPLETED'?'green':t.status==='FAILED'?'red':'blue'}`} style={{ fontSize:'0.65rem', marginTop:'0.3rem' }}>{t.status}</span>
              </div>
            </div>
          )
        })}

        {totalPages > 1 && (
          <div style={{ padding:'1rem 1.5rem', display:'flex', justifyContent:'center', gap:'0.5rem' }}>
            <button className="btn btn-ghost" style={{ fontSize:'0.8rem' }} disabled={page===0} onClick={()=>setPage(p=>p-1)}>← Prev</button>
            <button className="btn btn-ghost" style={{ fontSize:'0.8rem' }} disabled={page>=totalPages-1} onClick={()=>setPage(p=>p+1)}>Next →</button>
          </div>
        )}
      </div>
    </div>
  )
}