import React, { useEffect, useState } from 'react'
import toast from 'react-hot-toast'
import { ArrowRight, CheckCircle } from 'lucide-react'
import { transactionApi, accountApi } from '../../utils/api'

const fmt = (n) => new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(n||0)

export default function TransferPage() {
  const [accounts, setAccounts] = useState([])
  const [form, setForm] = useState({ fromAccount:'', toAccount:'', beneficiaryName:'', ifscCode:'NEXUS001', bankName:'NexusBank', amount:'', description:'', narration:'', transferType:'IMPS' })
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)

  useEffect(()=>{
    accountApi.getAll().then(r=>setAccounts(r.data||[])).catch(()=>{})
  },[])

  const handle = async (e) => {
    e.preventDefault()
    if (!form.fromAccount) { toast.error('Select source account'); return }
    setLoading(true)
    try {
      const { data } = await transactionApi.transfer({...form, amount:parseFloat(form.amount)})
      setResult(data)
      toast.success('Transfer successful!')
    } catch(err) {
      toast.error(err.response?.data?.message || 'Transfer failed')
    } finally { setLoading(false) }
  }

  const srcAccount = accounts.find(a=>a.accountNumber===form.fromAccount)
  const types = [['IMPS','IMPS (Instant, 24/7)'],['NEFT','NEFT ($5 fee)'],['RTGS','RTGS ($25–30 fee)'],['FUND_TRANSFER','Internal Transfer']]

  if (result) return (
    <div style={{ padding:'2rem', maxWidth:'560px' }}>
      <div className="card animate-fade" style={{ textAlign:'center', padding:'3rem', borderColor:'rgba(34,197,94,0.3)' }}>
        <CheckCircle size={56} color="#22c55e" style={{ margin:'0 auto 1.25rem' }} />
        <h2 style={{ fontFamily:'Playfair Display', fontSize:'1.6rem', marginBottom:'0.5rem' }}>Transfer Successful</h2>
        <p style={{ color:'#8899aa', marginBottom:'2rem' }}>Your money has been sent successfully</p>
        <div style={{ background:'rgba(255,255,255,0.04)', borderRadius:'10px', padding:'1.25rem', textAlign:'left' }}>
          {[['Reference', result.referenceNumber],['Amount',fmt(result.amount)],['Charges',fmt(result.charges)],['Status',result.status],['Type',result.transactionType]].map(([l,v])=>(
            <div key={l} style={{ display:'flex', justifyContent:'space-between', padding:'0.5rem 0', borderBottom:'1px solid rgba(255,255,255,0.05)' }}>
              <span style={{ color:'#8899aa', fontSize:'0.85rem' }}>{l}</span>
              <span style={{ fontWeight:600, fontSize:'0.85rem' }}>{v}</span>
            </div>
          ))}
        </div>
        <button className="btn btn-primary" style={{ marginTop:'1.5rem', width:'100%', justifyContent:'center' }} onClick={()=>setResult(null)}>New Transfer</button>
      </div>
    </div>
  )

  return (
    <div style={{ padding:'2rem', maxWidth:'640px' }}>
      <h1 style={{ fontFamily:'Playfair Display', fontSize:'1.8rem', fontWeight:700, marginBottom:'0.4rem' }}>Fund Transfer</h1>
      <p style={{ color:'#8899aa', fontSize:'0.875rem', marginBottom:'2rem' }}>Transfer money securely via IMPS, NEFT, or RTGS</p>

      <form onSubmit={handle} className="card animate-fade" style={{ display:'grid', gap:'1.25rem' }}>
        <div>
          <label className="label">From Account</label>
          <select className="input" value={form.fromAccount} onChange={e=>setForm(f=>({...f,fromAccount:e.target.value}))} required>
            <option value="">Select account</option>
            {accounts.filter(a=>a.status==='ACTIVE').map(a=>(
              <option key={a.accountId} value={a.accountNumber}>{a.accountName} — {a.accountNumber} ({fmt(a.availableBalance)})</option>
            ))}
          </select>
          {srcAccount && <p style={{ fontSize:'0.78rem', color:'#22c55e', marginTop:'0.35rem' }}>Available: {fmt(srcAccount.availableBalance)}</p>}
        </div>

        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'1rem' }}>
          <div>
            <label className="label">Beneficiary Account</label>
            <input className="input" placeholder="Account number" value={form.toAccount} onChange={e=>setForm(f=>({...f,toAccount:e.target.value}))} required />
          </div>
          <div>
            <label className="label">Beneficiary Name</label>
            <input className="input" placeholder="Account holder name" value={form.beneficiaryName} onChange={e=>setForm(f=>({...f,beneficiaryName:e.target.value}))} required />
          </div>
          <div>
            <label className="label">IFSC Code</label>
            <input className="input" placeholder="NEXUS001" value={form.ifscCode} onChange={e=>setForm(f=>({...f,ifscCode:e.target.value}))} required />
          </div>
          <div>
            <label className="label">Bank Name</label>
            <input className="input" placeholder="Bank name" value={form.bankName} onChange={e=>setForm(f=>({...f,bankName:e.target.value}))} />
          </div>
        </div>

        <div>
          <label className="label">Transfer Type</label>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'0.5rem' }}>
            {types.map(([val,label])=>(
              <label key={val} style={{ display:'flex', alignItems:'center', gap:'0.6rem', padding:'0.75rem', borderRadius:'10px', cursor:'pointer', border:`1px solid ${form.transferType===val?'#c9a227':'rgba(255,255,255,0.08)'}`, background:form.transferType===val?'rgba(201,162,39,0.08)':'transparent', transition:'all 0.15s' }}>
                <input type="radio" name="txType" value={val} checked={form.transferType===val} onChange={e=>setForm(f=>({...f,transferType:e.target.value}))} style={{ accentColor:'#c9a227' }} />
                <span style={{ fontSize:'0.82rem' }}>{label}</span>
              </label>
            ))}
          </div>
        </div>

        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'1rem' }}>
          <div>
            <label className="label">Amount ($)</label>
            <input className="input" type="number" min="1" step="0.01" placeholder="0.00" value={form.amount} onChange={e=>setForm(f=>({...f,amount:e.target.value}))} required />
          </div>
          <div>
            <label className="label">Description</label>
            <input className="input" placeholder="Purpose" value={form.description} onChange={e=>setForm(f=>({...f,description:e.target.value}))} />
          </div>
        </div>

        <button className="btn btn-primary" type="submit" disabled={loading} style={{ justifyContent:'center', padding:'0.9rem', fontSize:'0.95rem', opacity:loading?0.7:1 }}>
          {loading ? 'Processing...' : <><span>Send Money</span><ArrowRight size={16}/></>}
        </button>
      </form>
    </div>
  )
}