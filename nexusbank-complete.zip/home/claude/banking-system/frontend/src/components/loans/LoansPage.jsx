import React, { useEffect, useState } from 'react'
import { CreditCard, Plus, ChevronDown } from 'lucide-react'
import toast from 'react-hot-toast'
import { loanApi, accountApi } from '../../utils/api'

const fmt = (n) => new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(n||0)

export default function LoansPage() {
  const [loans, setLoans]       = useState([])
  const [accounts, setAccounts] = useState([])
  const [loading, setLoading]   = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [schedule, setSchedule] = useState(null)
  const [form, setForm] = useState({ loanType:'PERSONAL', requestedAmount:'', tenureMonths:12, annualIncome:'', purpose:'', accountNumber:'' })

  const load = async () => {
    setLoading(true)
    try {
      const [lr, ar] = await Promise.all([loanApi.getAll(), accountApi.getAll()])
      setLoans(lr.data || [])
      setAccounts(ar.data || [])
    } catch { toast.error('Failed to load loans') }
    finally { setLoading(false) }
  }

  useEffect(()=>{ load() },[])

  const handleApply = async (e) => {
    e.preventDefault()
    try {
      await loanApi.apply({...form, requestedAmount:parseFloat(form.requestedAmount), annualIncome:parseFloat(form.annualIncome)})
      toast.success('Loan application submitted!')
      setShowForm(false)
      load()
    } catch(err) { toast.error(err.response?.data?.message || 'Application failed') }
  }

  const viewSchedule = async (id) => {
    try {
      const r = await loanApi.getSchedule(id)
      setSchedule(r.data)
    } catch { toast.error('Could not load schedule') }
  }

  const statusColor = (s) => s==='ACTIVE'||s==='DISBURSED'?'green':s==='APPLIED'||s==='UNDER_REVIEW'?'blue':s==='APPROVED'?'gold':'red'
  const loanTypes = ['PERSONAL','HOME','AUTO','EDUCATION','BUSINESS','GOLD']

  return (
    <div style={{ padding:'2rem', maxWidth:'900px' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'2rem' }}>
        <div>
          <h1 style={{ fontFamily:'Playfair Display', fontSize:'1.8rem', fontWeight:700 }}>Loans</h1>
          <p style={{ color:'#8899aa', fontSize:'0.875rem', marginTop:'0.3rem' }}>Manage your loan applications</p>
        </div>
        <button className="btn btn-primary" onClick={()=>setShowForm(s=>!s)}><Plus size={14}/> Apply for Loan</button>
      </div>

      {showForm && (
        <div className="card animate-fade" style={{ marginBottom:'2rem', borderColor:'rgba(201,162,39,0.25)' }}>
          <h3 style={{ fontWeight:600, marginBottom:'1.25rem' }}>New Loan Application</h3>
          <form onSubmit={handleApply} style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'1rem' }}>
            <div>
              <label className="label">Loan Type</label>
              <select className="input" value={form.loanType} onChange={e=>setForm(f=>({...f,loanType:e.target.value}))}>
                {loanTypes.map(t=><option key={t} value={t}>{t} LOAN</option>)}
              </select>
            </div>
            <div>
              <label className="label">Linked Account</label>
              <select className="input" value={form.accountNumber} onChange={e=>setForm(f=>({...f,accountNumber:e.target.value}))} required>
                <option value="">Select account</option>
                {accounts.filter(a=>a.status==='ACTIVE').map(a=><option key={a.accountId} value={a.accountNumber}>{a.accountNumber}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Loan Amount ($)</label>
              <input className="input" type="number" min="1000" placeholder="50000" value={form.requestedAmount} onChange={e=>setForm(f=>({...f,requestedAmount:e.target.value}))} required />
            </div>
            <div>
              <label className="label">Tenure (months)</label>
              <input className="input" type="number" min="6" max="360" placeholder="12" value={form.tenureMonths} onChange={e=>setForm(f=>({...f,tenureMonths:+e.target.value}))} required />
            </div>
            <div>
              <label className="label">Annual Income ($)</label>
              <input className="input" type="number" min="1" placeholder="60000" value={form.annualIncome} onChange={e=>setForm(f=>({...f,annualIncome:e.target.value}))} required />
            </div>
            <div>
              <label className="label">Purpose</label>
              <input className="input" placeholder="Purpose of loan" value={form.purpose} onChange={e=>setForm(f=>({...f,purpose:e.target.value}))} />
            </div>
            <div style={{ gridColumn:'1/-1', display:'flex', justifyContent:'flex-end', gap:'0.75rem' }}>
              <button className="btn btn-ghost" type="button" onClick={()=>setShowForm(false)}>Cancel</button>
              <button className="btn btn-primary" type="submit">Submit Application</button>
            </div>
          </form>
        </div>
      )}

      {loading ? (
        <div style={{ display:'grid', gap:'1rem' }}>
          {[1,2].map(i=><div key={i} className="loading" style={{ height:'140px', borderRadius:'14px', background:'rgba(255,255,255,0.04)' }} />)}
        </div>
      ) : loans.length === 0 ? (
        <div className="card" style={{ textAlign:'center', padding:'4rem' }}>
          <CreditCard size={48} style={{ margin:'0 auto 1rem', opacity:0.3 }} />
          <h3>No loan applications</h3>
          <p style={{ color:'#8899aa', marginTop:'0.5rem' }}>Apply for your first loan to get started</p>
        </div>
      ) : (
        <div style={{ display:'grid', gap:'1rem' }}>
          {loans.map(l=>(
            <div key={l.loanId} className="card animate-fade">
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr 1fr auto', gap:'1.5rem', alignItems:'center' }}>
                <div>
                  <p style={{ fontSize:'0.72rem', color:'#8899aa', marginBottom:'0.2rem', textTransform:'uppercase', letterSpacing:'0.05em' }}>Type</p>
                  <p style={{ fontWeight:600 }}>{l.loanType?.replace('_',' ')}</p>
                  <p style={{ fontSize:'0.75rem', color:'#8899aa', fontFamily:'monospace', marginTop:'0.15rem' }}>{l.applicationNumber}</p>
                </div>
                <div>
                  <p style={{ fontSize:'0.72rem', color:'#8899aa', marginBottom:'0.2rem' }}>Amount</p>
                  <p style={{ fontWeight:700, fontFamily:'Playfair Display', fontSize:'1.1rem' }}>{fmt(l.requestedAmount)}</p>
                  {l.emiAmount && <p style={{ fontSize:'0.75rem', color:'#c9a227', marginTop:'0.15rem' }}>EMI: {fmt(l.emiAmount)}/mo</p>}
                </div>
                <div>
                  <p style={{ fontSize:'0.72rem', color:'#8899aa', marginBottom:'0.2rem' }}>Tenure</p>
                  <p style={{ fontWeight:600 }}>{l.tenureMonths} months</p>
                  {l.interestRate && <p style={{ fontSize:'0.75rem', color:'#22c55e' }}>{l.interestRate}% p.a.</p>}
                </div>
                <div>
                  <p style={{ fontSize:'0.72rem', color:'#8899aa', marginBottom:'0.3rem' }}>Status</p>
                  <span className={`badge badge-${statusColor(l.status)}`}>{l.status}</span>
                </div>
                <button className="btn btn-ghost" style={{ fontSize:'0.8rem', padding:'0.4rem 0.75rem' }} onClick={()=>setSchedule(null)||viewSchedule(l.loanId)}>
                  <ChevronDown size={14}/> Schedule
                </button>
              </div>

              {schedule && (
                <div style={{ marginTop:'1.25rem', borderTop:'1px solid rgba(255,255,255,0.06)', paddingTop:'1.25rem' }}>
                  <h4 style={{ fontWeight:600, marginBottom:'0.75rem', fontSize:'0.875rem' }}>EMI Schedule</h4>
                  <div style={{ overflowX:'auto' }}>
                    <table style={{ width:'100%', borderCollapse:'collapse', fontSize:'0.8rem' }}>
                      <thead>
                        <tr style={{ color:'#8899aa' }}>
                          {['Month','Due Date','EMI','Principal','Interest','Balance'].map(h=>(
                            <th key={h} style={{ textAlign:'left', padding:'0.4rem 0.75rem', borderBottom:'1px solid rgba(255,255,255,0.06)', fontWeight:500 }}>{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {schedule.slice(0,6).map((row,i)=>(
                          <tr key={i} style={{ borderBottom:'1px solid rgba(255,255,255,0.03)' }}>
                            <td style={{ padding:'0.5rem 0.75rem' }}>{row.month}</td>
                            <td style={{ padding:'0.5rem 0.75rem', color:'#8899aa' }}>{row.dueDate?.substring(0,10)}</td>
                            <td style={{ padding:'0.5rem 0.75rem', color:'#c9a227', fontWeight:600 }}>{fmt(row.emi)}</td>
                            <td style={{ padding:'0.5rem 0.75rem' }}>{fmt(row.principal)}</td>
                            <td style={{ padding:'0.5rem 0.75rem', color:'#ef4444' }}>{fmt(row.interest)}</td>
                            <td style={{ padding:'0.5rem 0.75rem' }}>{fmt(row.balance)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {schedule.length > 6 && <p style={{ color:'#8899aa', fontSize:'0.75rem', padding:'0.5rem 0.75rem' }}>...and {schedule.length-6} more months</p>}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}