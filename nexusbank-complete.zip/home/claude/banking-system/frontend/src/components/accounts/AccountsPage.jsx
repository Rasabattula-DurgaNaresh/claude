import React, { useEffect, useState } from 'react'
import { Plus, Wallet, Lock, RefreshCw } from 'lucide-react'
import toast from 'react-hot-toast'
import { accountApi } from '../../utils/api'

const fmt = (n) => new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(n||0)

export default function AccountsPage() {
  const [accounts, setAccounts] = useState([])
  const [loading, setLoading]   = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ accountType:'SAVINGS', accountName:'', branchCode:'001', initialDeposit:'', currency:'USD' })
  const [saving, setSaving] = useState(false)

  const load = async () => {
    setLoading(true)
    try { const r = await accountApi.getAll(); setAccounts(r.data || []) }
    catch { toast.error('Failed to load accounts') }
    finally { setLoading(false) }
  }

  useEffect(()=>{ load() }, [])

  const handleOpen = async (e) => {
    e.preventDefault(); setSaving(true)
    try {
      await accountApi.openAccount({...form, initialDeposit:parseFloat(form.initialDeposit)})
      toast.success('Account opened successfully!')
      setShowForm(false)
      load()
    } catch(err) { toast.error(err.response?.data?.message || 'Failed to open account') }
    finally { setSaving(false) }
  }

  const handleFreeze = async (num) => {
    try { await accountApi.freeze(num,'Customer request'); toast.success('Account frozen'); load() }
    catch { toast.error('Failed to freeze account') }
  }

  const types = ['SAVINGS','CURRENT','SALARY','FIXED_DEPOSIT','RECURRING_DEPOSIT','NRE','NRO']

  return (
    <div style={{ padding:'2rem', maxWidth:'900px' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'2rem' }}>
        <div>
          <h1 style={{ fontFamily:'Playfair Display', fontSize:'1.8rem', fontWeight:700 }}>My Accounts</h1>
          <p style={{ color:'#8899aa', fontSize:'0.875rem', marginTop:'0.3rem' }}>{accounts.length} account{accounts.length!==1?'s':''} linked</p>
        </div>
        <div style={{ display:'flex', gap:'0.75rem' }}>
          <button className="btn btn-ghost" onClick={load}><RefreshCw size={14}/></button>
          <button className="btn btn-primary" onClick={()=>setShowForm(s=>!s)}><Plus size={14}/> Open Account</button>
        </div>
      </div>

      {/* Open account form */}
      {showForm && (
        <div className="card animate-fade" style={{ marginBottom:'2rem', borderColor:'rgba(201,162,39,0.3)' }}>
          <h3 style={{ fontWeight:600, marginBottom:'1.25rem' }}>Open New Account</h3>
          <form onSubmit={handleOpen} style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'1rem' }}>
            <div>
              <label className="label">Account Type</label>
              <select className="input" value={form.accountType} onChange={e=>setForm(f=>({...f,accountType:e.target.value}))}>
                {types.map(t=><option key={t} value={t}>{t.replace('_',' ')}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Account Name</label>
              <input className="input" placeholder="e.g. My Savings" value={form.accountName} onChange={e=>setForm(f=>({...f,accountName:e.target.value}))} required />
            </div>
            <div>
              <label className="label">Branch Code</label>
              <input className="input" placeholder="001" value={form.branchCode} onChange={e=>setForm(f=>({...f,branchCode:e.target.value}))} required />
            </div>
            <div>
              <label className="label">Initial Deposit ($)</label>
              <input className="input" type="number" min="500" step="0.01" placeholder="1000.00" value={form.initialDeposit} onChange={e=>setForm(f=>({...f,initialDeposit:e.target.value}))} required />
            </div>
            <div style={{ gridColumn:'1/-1', display:'flex', gap:'0.75rem', justifyContent:'flex-end' }}>
              <button className="btn btn-ghost" type="button" onClick={()=>setShowForm(false)}>Cancel</button>
              <button className="btn btn-primary" type="submit" disabled={saving}>{saving?'Opening...':'Open Account'}</button>
            </div>
          </form>
        </div>
      )}

      {/* Account list */}
      {loading ? (
        <div style={{ display:'grid', gap:'1rem' }}>
          {[1,2].map(i=><div key={i} className="loading" style={{ height:'160px', borderRadius:'14px', background:'rgba(255,255,255,0.04)' }} />)}
        </div>
      ) : accounts.length === 0 ? (
        <div className="card" style={{ textAlign:'center', padding:'4rem' }}>
          <Wallet size={48} style={{ margin:'0 auto 1rem', opacity:0.3 }} />
          <h3>No accounts yet</h3>
          <p style={{ color:'#8899aa', marginTop:'0.5rem' }}>Open your first account to get started</p>
        </div>
      ) : (
        <div style={{ display:'grid', gap:'1rem' }}>
          {accounts.map(a => (
            <div key={a.accountId} className="card animate-fade" style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr auto', alignItems:'center', gap:'1.5rem' }}>
              <div>
                <div style={{ display:'flex', alignItems:'center', gap:'0.5rem', marginBottom:'0.25rem' }}>
                  <Wallet size={14} style={{ color:'#c9a227' }} />
                  <span style={{ fontWeight:600 }}>{a.accountName}</span>
                </div>
                <p style={{ fontSize:'0.78rem', color:'#8899aa', fontFamily:'monospace' }}>{a.accountNumber}</p>
                <div style={{ display:'flex', gap:'0.5rem', marginTop:'0.5rem' }}>
                  <span className="badge badge-gold">{a.accountType?.replace('_',' ')}</span>
                  <span className={`badge badge-${a.status==='ACTIVE'?'green':'red'}`}>{a.status}</span>
                </div>
              </div>
              <div>
                <p style={{ fontSize:'0.75rem', color:'#8899aa', marginBottom:'0.25rem' }}>Available Balance</p>
                <p style={{ fontSize:'1.25rem', fontWeight:700, fontFamily:'Playfair Display' }}>{fmt(a.availableBalance)}</p>
              </div>
              <div>
                <p style={{ fontSize:'0.75rem', color:'#8899aa', marginBottom:'0.25rem' }}>IFSC / Branch</p>
                <p style={{ fontSize:'0.85rem', fontFamily:'monospace' }}>{a.ifscCode}</p>
                {a.interestRate && <p style={{ fontSize:'0.75rem', color:'#22c55e', marginTop:'0.2rem' }}>Interest: {a.interestRate}% p.a.</p>}
              </div>
              <div style={{ display:'flex', gap:'0.5rem' }}>
                {a.status === 'ACTIVE' && (
                  <button className="btn btn-danger" style={{ fontSize:'0.78rem', padding:'0.4rem 0.75rem' }} onClick={()=>handleFreeze(a.accountNumber)}>
                    <Lock size={13}/> Freeze
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}