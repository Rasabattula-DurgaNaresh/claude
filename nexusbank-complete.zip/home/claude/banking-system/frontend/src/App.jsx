import React from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { useAuthStore } from './store/authStore'
import LoginPage     from './components/auth/LoginPage'
import RegisterPage  from './components/auth/RegisterPage'
import Dashboard     from './components/dashboard/Dashboard'
import AccountsPage  from './components/accounts/AccountsPage'
import TransferPage  from './components/transactions/TransferPage'
import StatementPage from './components/transactions/StatementPage'
import LoansPage     from './components/loans/LoansPage'
import Layout        from './components/shared/Layout'

const Guard = ({ children }) => {
  const isAuth = useAuthStore(s => s.isAuthenticated)
  return isAuth ? children : <Navigate to="/login" replace />
}

export default function App() {
  return (
    <BrowserRouter>
      <Toaster
        position="top-right"
        toastOptions={{
          style: { background: '#1a3260', color: '#f8fafc', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '10px', fontFamily: "'DM Sans', sans-serif" },
          success: { iconTheme: { primary: '#c9a227', secondary: '#0a1628' } }
        }}
      />
      <Routes>
        <Route path="/login"    element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/" element={<Guard><Layout /></Guard>}>
          <Route index             element={<Navigate to="/dashboard" replace />} />
          <Route path="dashboard"  element={<Dashboard />} />
          <Route path="accounts"   element={<AccountsPage />} />
          <Route path="transfer"   element={<TransferPage />} />
          <Route path="statement"  element={<StatementPage />} />
          <Route path="loans"      element={<LoansPage />} />
        </Route>
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </BrowserRouter>
  )
}