import axios from 'axios'
import { useAuthStore } from '../store/authStore'

const api = axios.create({
  baseURL: '/api',
  timeout: 15000,
})

api.interceptors.request.use((config) => {
  const token = useAuthStore.getState().getToken()
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

api.interceptors.response.use(
  (res) => res,
  async (err) => {
    if (err.response?.status === 401) {
      useAuthStore.getState().logout()
      window.location.href = '/login'
    }
    return Promise.reject(err)
  }
)

export const authApi = {
  login:    (data)  => api.post('/auth/login', data),
  register: (data)  => api.post('/auth/register', data),
  logout:   ()      => api.post('/auth/logout'),
}

export const accountApi = {
  getAll:        ()           => api.get('/accounts'),
  getOne:        (num)        => api.get(`/accounts/${num}`),
  openAccount:   (data)       => api.post('/accounts', data),
  freeze:        (num, reason)=> api.patch(`/accounts/${num}/freeze?reason=${reason}`),
}

export const transactionApi = {
  transfer:       (data)          => api.post('/transactions/transfer', data),
  getStatement:   (acc, page=0)   => api.get(`/transactions/statement/${acc}?page=${page}&size=20`),
  getSpending:    (from, to)      => api.get(`/transactions/spending-analysis?from=${from}&to=${to}`),
}

export const loanApi = {
  apply:       (data) => api.post('/loans/apply', data),
  getAll:      ()     => api.get('/loans'),
  getSchedule: (id)   => api.get(`/loans/${id}/emi-schedule`),
}

export default api