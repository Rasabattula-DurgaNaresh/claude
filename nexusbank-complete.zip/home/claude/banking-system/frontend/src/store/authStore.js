import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export const useAuthStore = create(
  persist(
    (set, get) => ({
      user:         null,
      accessToken:  null,
      refreshToken: null,
      isAuthenticated: false,

      login: (data) => set({
        user:         { userId: data.userId, email: data.email, fullName: data.fullName, role: data.role, cifNo: data.cifNo },
        accessToken:  data.accessToken,
        refreshToken: data.refreshToken,
        isAuthenticated: true,
      }),

      logout: () => set({
        user: null, accessToken: null, refreshToken: null, isAuthenticated: false
      }),

      getToken: () => get().accessToken,
    }),
    { name: 'nexusbank-auth', partialize: (s) => ({ user: s.user, accessToken: s.accessToken, refreshToken: s.refreshToken, isAuthenticated: s.isAuthenticated }) }
  )
)