# NexusBank — Full-Stack Banking Platform
## Spring Boot Microservices + React JS + Oracle DB

---

## 🏗️ Architecture

```
                        ┌────────────────┐
                        │  React Frontend │  :3000
                        └───────┬────────┘
                                │ HTTP/REST
                        ┌───────▼────────┐
                        │   API Gateway  │  :8080 (Spring Cloud Gateway)
                        │  JWT Filter    │
                        │  Rate Limiting │
                        │  CORS          │
                        └───────┬────────┘
              ┌─────────────────┼──────────────────┐
              │                 │                  │
    ┌─────────▼──────┐ ┌───────▼──────┐ ┌─────────▼──────┐
    │  Auth Service  │ │ Account Svc  │ │Transaction Svc │
    │  :8081         │ │  :8082       │ │  :8083         │
    └────────────────┘ └──────────────┘ └────────────────┘
              │                 │                  │
    ┌─────────▼──────┐          │         ┌────────▼───────┐
    │  Loan Service  │          │         │Notification Svc│
    │  :8084         │          │         │  :8085 (Kafka) │
    └────────────────┘          │         └────────────────┘
              │                 │
    ┌─────────▼─────────────────▼────┐
    │         Oracle Database         │  :1521
    │  (Flyway migrations per service)│
    └────────────────────────────────┘

Supporting Infrastructure:
  Eureka Server  :8761  — Service discovery
  Redis          :6379  — JWT sessions, caching
  Kafka          :9092  — Async event streaming
  Zookeeper      :2181  — Kafka coordination
```

---

## 🚀 Quick Start

### Prerequisites
- Docker Desktop 4.x+
- Docker Compose v2

### Run Everything
```bash
git clone <repo>
cd banking-system

# Start all services
docker-compose up -d

# Wait ~3 minutes for Oracle to initialise
docker-compose logs -f oracle-db   # wait for "DATABASE IS READY TO USE!"

# Access
open http://localhost:3000          # React frontend
open http://localhost:8761          # Eureka dashboard
open http://localhost:8080/swagger-ui.html  # API gateway docs
```

### Dev Mode (without Docker)
```bash
# 1. Start infrastructure only
docker-compose up -d oracle-db kafka redis zookeeper

# 2. Start services
cd services
mvn -pl eureka-server spring-boot:run &
mvn -pl api-gateway   spring-boot:run &
mvn -pl auth-service  spring-boot:run &
mvn -pl account-service spring-boot:run &
mvn -pl transaction-service spring-boot:run &
mvn -pl loan-service  spring-boot:run &
mvn -pl notification-service spring-boot:run &

# 3. Start frontend
cd frontend
npm install
npm run dev     # http://localhost:3000
```

---

## 🔑 Default Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@nexusbank.com | Admin@123456 |

---

## 📦 Service Inventory

| Service | Port | Tech | Responsibilities |
|---------|------|------|-----------------|
| **API Gateway** | 8080 | Spring Cloud Gateway | JWT validation, routing, rate limiting, CORS |
| **Eureka Server** | 8761 | Spring Eureka | Service registry & discovery |
| **Auth Service** | 8081 | Spring Boot + JWT | Login, register, refresh, logout (Redis blacklist) |
| **Account Service** | 8082 | Spring Boot + JPA | Open/freeze/query accounts, balance updates |
| **Transaction Service** | 8083 | Spring Boot + Feign | Fund transfers, statements, spending analysis |
| **Loan Service** | 8084 | Spring Boot + JPA | Loan applications, EMI schedules, approval |
| **Notification Service** | 8085 | Spring Boot + Kafka | Email/SMS alerts (Kafka consumer) |
| **React Frontend** | 3000 | React 18 + Vite | Full banking UI (Recharts, Zustand, React Router) |

---

## 🗄️ Oracle Schema

Each service runs its own Flyway migrations against a shared Oracle schema.

```sql
-- Auth Service
BANKING_USERS          -- customer accounts, roles, MFA, lockout

-- Account Service  
BANK_ACCOUNTS          -- savings, current, FD, RD, NRE accounts

-- Transaction Service
TRANSACTIONS           -- IMPS, NEFT, RTGS, credits, debits

-- Loan Service
LOAN_APPLICATIONS      -- loan requests, EMI, repayment tracking
```

---

## 🔐 Security

- **JWT** — RS256 signed, 1-hour access token, 7-day refresh token
- **Redis** — Refresh token store + access token blacklist on logout
- **Account lockout** — 5 failed logins → 30-minute lockout
- **API Gateway** — Central JWT validation, injects X-User-Id/X-User-Role headers
- **Pessimistic locking** — Oracle SELECT FOR UPDATE on balance operations
- **Optimistic locking** — @Version on Account entity prevents lost updates

---

## 🌐 API Endpoints

### Auth (public)
```
POST /api/auth/login         { login, password }
POST /api/auth/register      { firstName, lastName, email, phoneNo, password }
POST /api/auth/logout        Authorization: Bearer <token>
POST /api/auth/refresh?refreshToken=...
```

### Accounts (authenticated)
```
GET  /api/accounts                      — list all accounts
POST /api/accounts                      — open new account
GET  /api/accounts/{accountNumber}      — account details
PATCH /api/accounts/{accountNumber}/freeze?reason=...
```

### Transactions (authenticated)
```
POST /api/transactions/transfer                         — fund transfer
GET  /api/transactions/statement/{accountNumber}        — paginated statement
GET  /api/transactions/spending-analysis?from=&to=      — category breakdown
```

### Loans (authenticated)
```
POST /api/loans/apply                — submit application
GET  /api/loans                      — my loans
GET  /api/loans/{loanId}/emi-schedule
POST /api/loans/{loanId}/approve     — admin only
```

---

## 🎨 Frontend Pages

| Page | Route | Features |
|------|-------|---------|
| Login | /login | JWT auth, demo credentials |
| Register | /register | Customer onboarding |
| Dashboard | /dashboard | Metrics, cash flow chart, spending pie, account cards |
| Accounts | /accounts | List, open account form, freeze |
| Transfer | /transfer | IMPS/NEFT/RTGS with step confirmation |
| Statement | /statement | Paginated transaction list with search |
| Loans | /loans | Apply, view EMI schedule, loan status |

---

## 📊 Kafka Events

| Topic | Producers | Consumers |
|-------|-----------|-----------|
| `account-events` | Account Service | Notification Service |
| `transaction-events` | Transaction Service | Notification Service |

Events: `ACCOUNT_OPENED`, `ACCOUNT_FROZEN`, `TRANSFER_COMPLETED`
