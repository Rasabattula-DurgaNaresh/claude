package com.banking.auth.dto;

import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;

@Data
public class RegisterRequest {
    @NotBlank @Size(min=2, max=50) private String firstName;
    @NotBlank @Size(min=2, max=50) private String lastName;
    @Email    @NotBlank            private String email;
    @Pattern(regexp="^\\+?[0-9]{10,15}$") private String phoneNo;
    @NotBlank @Size(min=8, max=100) private String password;
    @Past                           private LocalDate dateOfBirth;
}