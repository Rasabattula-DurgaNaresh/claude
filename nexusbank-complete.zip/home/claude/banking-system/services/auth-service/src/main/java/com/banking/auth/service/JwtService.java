package com.banking.auth.service;

import com.banking.auth.entity.User;
import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Map;

@Service @Slf4j
public class JwtService {

    @Value("${jwt.secret}")   private String secret;
    @Value("${jwt.access-token-expiry-ms:3600000}")   private long accessExpiry;    // 1h
    @Value("${jwt.refresh-token-expiry-ms:604800000}") private long refreshExpiry;  // 7d

    private SecretKey key() {
        return Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
    }

    public String generateAccessToken(User user) {
        return Jwts.builder()
            .subject(String.valueOf(user.getUserId()))
            .claims(Map.of(
                "email",   user.getEmail(),
                "role",    user.getRole().name(),
                "name",    user.getFullName(),
                "cifNo",   user.getCifNo(),
                "tokenType", "ACCESS"))
            .issuedAt(new Date())
            .expiration(new Date(System.currentTimeMillis() + accessExpiry))
            .signWith(key())
            .compact();
    }

    public String generateRefreshToken(User user) {
        return Jwts.builder()
            .subject(String.valueOf(user.getUserId()))
            .claims(Map.of("tokenType", "REFRESH"))
            .issuedAt(new Date())
            .expiration(new Date(System.currentTimeMillis() + refreshExpiry))
            .signWith(key())
            .compact();
    }

    public Claims parseToken(String token) {
        return Jwts.parser()
            .verifyWith(key())
            .build()
            .parseSignedClaims(token)
            .getPayload();
    }

    public boolean isValid(String token) {
        try { parseToken(token); return true; }
        catch (JwtException e) { return false; }
    }

    public String extractUserId(String token) {
        return parseToken(token).getSubject();
    }
}