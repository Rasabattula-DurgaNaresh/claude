package com.banking.auth.service;

import com.banking.auth.dto.*;
import com.banking.auth.entity.User;
import com.banking.auth.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

@Service @RequiredArgsConstructor @Slf4j
public class AuthService {

    private final UserRepository        userRepo;
    private final JwtService            jwtService;
    private final PasswordEncoder       passwordEncoder;
    private final StringRedisTemplate   redis;

    private static final int MAX_FAILED = 5;
    private static final String BLACKLIST_PREFIX = "token:blacklist:";
    private static final String REFRESH_PREFIX   = "token:refresh:";

    @Transactional
    public AuthResponse login(LoginRequest req) {
        User user = userRepo.findByEmailOrPhone(req.getLogin())
            .orElseThrow(() -> new AuthException("Invalid credentials"));

        if (user.isLocked()) {
            throw new AuthException("Account locked until " + user.getLockedUntil());
        }

        if (!passwordEncoder.matches(req.getPassword(), user.getPasswordHash())) {
            handleFailedLogin(user);
            throw new AuthException("Invalid credentials");
        }

        // Reset failed count on success
        user.setFailedLoginCount(0);
        user.setLockedUntil(null);
        user.setLastLoginAt(LocalDateTime.now());
        userRepo.save(user);

        String accessToken  = jwtService.generateAccessToken(user);
        String refreshToken = jwtService.generateRefreshToken(user);

        // Store refresh token in Redis (7 days)
        redis.opsForValue().set(
            REFRESH_PREFIX + user.getUserId(),
            refreshToken, 7, TimeUnit.DAYS);

        log.info("User {} logged in successfully", user.getEmail());
        return buildAuthResponse(user, accessToken, refreshToken);
    }

    @Transactional
    public AuthResponse register(RegisterRequest req) {
        if (userRepo.existsByEmail(req.getEmail())) {
            throw new AuthException("Email already registered");
        }
        if (userRepo.existsByPhoneNo(req.getPhoneNo())) {
            throw new AuthException("Phone number already registered");
        }

        User user = User.builder()
            .cifNo("CIF" + System.currentTimeMillis())
            .firstName(req.getFirstName())
            .lastName(req.getLastName())
            .email(req.getEmail())
            .phoneNo(req.getPhoneNo())
            .passwordHash(passwordEncoder.encode(req.getPassword()))
            .dateOfBirth(req.getDateOfBirth())
            .build();

        user = userRepo.save(user);
        log.info("New user registered: {}", user.getEmail());

        String access  = jwtService.generateAccessToken(user);
        String refresh = jwtService.generateRefreshToken(user);
        redis.opsForValue().set(REFRESH_PREFIX + user.getUserId(), refresh, 7, TimeUnit.DAYS);

        return buildAuthResponse(user, access, refresh);
    }

    public void logout(String token) {
        try {
            String userId = jwtService.extractUserId(token);
            // Blacklist access token
            redis.opsForValue().set(BLACKLIST_PREFIX + token, "1", 1, TimeUnit.HOURS);
            // Delete refresh token
            redis.delete(REFRESH_PREFIX + userId);
            log.info("User {} logged out", userId);
        } catch (Exception e) {
            log.warn("Logout error: {}", e.getMessage());
        }
    }

    public AuthResponse refresh(String refreshToken) {
        if (!jwtService.isValid(refreshToken)) {
            throw new AuthException("Invalid refresh token");
        }
        String userId = jwtService.extractUserId(refreshToken);
        String stored = redis.opsForValue().get(REFRESH_PREFIX + userId);

        if (!refreshToken.equals(stored)) {
            throw new AuthException("Refresh token mismatch or expired");
        }

        User user = userRepo.findById(Long.parseLong(userId))
            .orElseThrow(() -> new AuthException("User not found"));

        String newAccess  = jwtService.generateAccessToken(user);
        String newRefresh = jwtService.generateRefreshToken(user);
        redis.opsForValue().set(REFRESH_PREFIX + userId, newRefresh, 7, TimeUnit.DAYS);

        return buildAuthResponse(user, newAccess, newRefresh);
    }

    private void handleFailedLogin(User user) {
        int count = user.getFailedLoginCount() + 1;
        user.setFailedLoginCount(count);
        if (count >= MAX_FAILED) {
            user.setLockedUntil(LocalDateTime.now().plusMinutes(30));
            log.warn("Account {} locked after {} failed attempts", user.getEmail(), count);
        }
        userRepo.save(user);
    }

    private AuthResponse buildAuthResponse(User user, String access, String refresh) {
        return AuthResponse.builder()
            .accessToken(access).refreshToken(refresh)
            .tokenType("Bearer")
            .userId(user.getUserId())
            .email(user.getEmail())
            .fullName(user.getFullName())
            .role(user.getRole().name())
            .cifNo(user.getCifNo())
            .build();
    }
}