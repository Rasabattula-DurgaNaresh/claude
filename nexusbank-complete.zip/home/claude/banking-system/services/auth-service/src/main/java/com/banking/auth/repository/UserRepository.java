package com.banking.auth.repository;

import com.banking.auth.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    Optional<User> findByCifNo(String cifNo);
    boolean existsByEmail(String email);
    boolean existsByPhoneNo(String phoneNo);

    @Query("SELECT u FROM User u WHERE u.email = :login OR u.phoneNo = :login")
    Optional<User> findByEmailOrPhone(String login);
}