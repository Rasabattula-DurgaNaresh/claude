package com.banking.auth.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "BANKING_USERS",
    uniqueConstraints = {
        @UniqueConstraint(columnNames = "EMAIL",    name = "UQ_USER_EMAIL"),
        @UniqueConstraint(columnNames = "PHONE_NO", name = "UQ_USER_PHONE"),
        @UniqueConstraint(columnNames = "CIF_NO",   name = "UQ_USER_CIF")
    })
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_user")
    @SequenceGenerator(name = "seq_user", sequenceName = "SEQ_BANKING_USERS",
                       allocationSize = 50, initialValue = 1001)
    @Column(name = "USER_ID")
    private Long userId;

    @Column(name = "CIF_NO",      nullable = false, length = 15)  private String cifNo;
    @Column(name = "FIRST_NAME",  nullable = false, length = 50)  private String firstName;
    @Column(name = "LAST_NAME",   nullable = false, length = 50)  private String lastName;
    @Column(name = "EMAIL",       nullable = false, length = 100) private String email;
    @Column(name = "PHONE_NO",    nullable = false, length = 15)  private String phoneNo;
    @Column(name = "PASSWORD_HASH", nullable = false, length = 255) private String passwordHash;
    @Column(name = "DATE_OF_BIRTH")                                 private LocalDate dateOfBirth;

    @Enumerated(EnumType.STRING)
    @Column(name = "ROLE",        nullable = false, length = 20)
    @Builder.Default private Role role = Role.CUSTOMER;

    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS",      nullable = false, length = 20)
    @Builder.Default private UserStatus status = UserStatus.ACTIVE;

    @Column(name = "IS_MFA_ENABLED") @Builder.Default private boolean mfaEnabled = false;
    @Column(name = "FAILED_LOGIN_COUNT") @Builder.Default private int failedLoginCount = 0;
    @Column(name = "LOCKED_UNTIL")  private LocalDateTime lockedUntil;

    @CreationTimestamp @Column(name = "CREATED_AT", updatable = false) private LocalDateTime createdAt;
    @UpdateTimestamp   @Column(name = "UPDATED_AT")                     private LocalDateTime updatedAt;
    @Column(name = "LAST_LOGIN_AT") private LocalDateTime lastLoginAt;

    public enum Role        { CUSTOMER, TELLER, MANAGER, ADMIN }
    public enum UserStatus  { ACTIVE, SUSPENDED, LOCKED, CLOSED }

    public String getFullName() { return firstName + " " + lastName; }
    public boolean isLocked() {
        return lockedUntil != null && LocalDateTime.now().isBefore(lockedUntil);
    }
}