package com.banking.notification.consumer;

import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import java.util.Map;

/**
 * Kafka consumer — listens for banking events and sends notifications.
 */
@Component @Slf4j
public class TransactionEventConsumer {

    @KafkaListener(topics = "transaction-events", groupId = "notification-group")
    public void handleTransactionEvent(Map<String, Object> event) {
        String type = (String) event.get("event");
        log.info("Received transaction event: {}", type);

        switch (type) {
            case "TRANSFER_COMPLETED" -> {
                String ref    = (String) event.get("referenceNumber");
                Object amount = event.get("amount");
                String from   = (String) event.get("fromAccount");
                log.info("[NOTIFY] Transfer {} completed: {} debited ${}", ref, from, amount);
                // sendEmail / sendSms logic here
            }
            default -> log.warn("Unhandled event type: {}", type);
        }
    }

    @KafkaListener(topics = "account-events", groupId = "notification-group")
    public void handleAccountEvent(Map<String, Object> event) {
        String type = (String) event.get("event");
        log.info("Received account event: {}", type);

        switch (type) {
            case "ACCOUNT_OPENED" -> log.info("[NOTIFY] Welcome email sent for account: {}", event.get("accountNumber"));
            case "ACCOUNT_FROZEN" -> log.warn("[NOTIFY] Account frozen alert sent: {}", event.get("accountNumber"));
        }
    }
}