package com.banking.loan.controller;

import com.banking.loan.entity.LoanApplication;
import com.banking.loan.service.LoanService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController @RequestMapping("/api/loans")
@RequiredArgsConstructor @Tag(name = "Loans")
public class LoanController {
    private final LoanService loanService;

    @PostMapping("/apply")
    public ResponseEntity<LoanApplication> apply(
            @RequestHeader("X-User-Id") String userId,
            @RequestBody LoanApplication req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(loanService.apply(Long.parseLong(userId), req));
    }

    @GetMapping
    public ResponseEntity<List<LoanApplication>> getMyLoans(@RequestHeader("X-User-Id") String userId) {
        return ResponseEntity.ok(loanService.getByUser(Long.parseLong(userId)));
    }

    @GetMapping("/{loanId}/emi-schedule")
    public ResponseEntity<?> emiSchedule(@PathVariable Long loanId) {
        return ResponseEntity.ok(loanService.getEmiSchedule(loanId));
    }

    @PostMapping("/{loanId}/approve")
    public ResponseEntity<LoanApplication> approve(@PathVariable Long loanId) {
        return ResponseEntity.ok(loanService.approve(loanId));
    }
}