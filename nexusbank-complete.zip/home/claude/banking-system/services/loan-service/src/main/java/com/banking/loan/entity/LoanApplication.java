package com.banking.loan.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity @Table(name = "LOAN_APPLICATIONS")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class LoanApplication {
    @Id @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq_loan")
    @SequenceGenerator(name="seq_loan", sequenceName="SEQ_LOAN_APPLICATIONS", allocationSize=50, initialValue=1)
    @Column(name="LOAN_ID") private Long loanId;
    @Column(name="APPLICATION_NUMBER", nullable=false, unique=true, length=20) private String applicationNumber;
    @Column(name="USER_ID",             nullable=false) private Long userId;
    @Column(name="ACCOUNT_NUMBER",      nullable=false, length=20) private String accountNumber;
    @Enumerated(EnumType.STRING)
    @Column(name="LOAN_TYPE",           nullable=false, length=20) private LoanType loanType;
    @Column(name="REQUESTED_AMOUNT",    nullable=false, precision=19, scale=2) private BigDecimal requestedAmount;
    @Column(name="APPROVED_AMOUNT",     precision=19, scale=2) private BigDecimal approvedAmount;
    @Column(name="INTEREST_RATE",       precision=5,  scale=2) private BigDecimal interestRate;
    @Column(name="TENURE_MONTHS",       nullable=false) private Integer tenureMonths;
    @Column(name="EMI_AMOUNT",          precision=19, scale=2) private BigDecimal emiAmount;
    @Column(name="CIBIL_SCORE") private Integer cibilScore;
    @Column(name="ANNUAL_INCOME",       precision=19, scale=2) private BigDecimal annualIncome;
    @Column(name="PURPOSE",             length=255) private String purpose;
    @Enumerated(EnumType.STRING)
    @Column(name="STATUS",              nullable=false, length=20)
    @Builder.Default private LoanStatus status = LoanStatus.APPLIED;
    @Column(name="REJECTION_REASON",    length=255) private String rejectionReason;
    @Column(name="DISBURSED_DATE") private LocalDateTime disbursedDate;
    @CreationTimestamp @Column(name="APPLIED_DATE", updatable=false) private LocalDateTime appliedDate;
    @Column(name="OUTSTANDING_AMOUNT",  precision=19, scale=2) private BigDecimal outstandingAmount;
    @Column(name="PAID_EMIS") @Builder.Default private int paidEmis = 0;

    public enum LoanType   { HOME, PERSONAL, AUTO, EDUCATION, BUSINESS, GOLD, CREDIT_CARD }
    public enum LoanStatus { APPLIED, UNDER_REVIEW, APPROVED, REJECTED, DISBURSED, ACTIVE, CLOSED, DEFAULTED }

    public BigDecimal calculateEmi() {
        if (requestedAmount == null || interestRate == null || tenureMonths == null) return null;
        double p = requestedAmount.doubleValue();
        double r = interestRate.doubleValue() / (12 * 100);
        int    n = tenureMonths;
        double emi = p * r * Math.pow(1+r,n) / (Math.pow(1+r,n) - 1);
        return BigDecimal.valueOf(Math.round(emi * 100.0) / 100.0);
    }
}