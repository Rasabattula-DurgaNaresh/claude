package com.banking.loan.service;

import com.banking.loan.entity.LoanApplication;
import com.banking.loan.entity.LoanApplication.*;
import com.banking.loan.repository.LoanRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

@Service @RequiredArgsConstructor @Slf4j
public class LoanService {
    private final LoanRepository loanRepo;

    @Transactional
    public LoanApplication apply(Long userId, LoanApplication req) {
        req.setUserId(userId);
        req.setApplicationNumber("LN" + System.currentTimeMillis());
        req.setStatus(LoanStatus.APPLIED);
        req.setInterestRate(getInterestRate(req.getLoanType()));
        req.setEmiAmount(req.calculateEmi());
        req.setOutstandingAmount(req.getRequestedAmount());
        LoanApplication saved = loanRepo.save(req);
        log.info("Loan application {} submitted", saved.getApplicationNumber());
        return saved;
    }

    @Transactional
    public LoanApplication approve(Long loanId) {
        LoanApplication loan = loanRepo.findById(loanId)
            .orElseThrow(() -> new RuntimeException("Loan not found: " + loanId));
        loan.setStatus(LoanStatus.APPROVED);
        loan.setApprovedAmount(loan.getRequestedAmount());
        loan.setDisbursedDate(LocalDateTime.now());
        return loanRepo.save(loan);
    }

    public List<LoanApplication> getByUser(Long userId) { return loanRepo.findByUserId(userId); }

    public List<Map<String, Object>> getEmiSchedule(Long loanId) {
        LoanApplication loan = loanRepo.findById(loanId)
            .orElseThrow(() -> new RuntimeException("Loan not found"));
        List<Map<String, Object>> schedule = new ArrayList<>();
        double p = loan.getRequestedAmount().doubleValue();
        double r = loan.getInterestRate().doubleValue() / 1200;
        double emi = loan.getEmiAmount().doubleValue();
        LocalDateTime due = LocalDateTime.now().plusMonths(1);
        for (int i = 1; i <= loan.getTenureMonths(); i++) {
            double interest = p * r;
            double principal = emi - interest;
            p -= principal;
            schedule.add(Map.of("month", i, "dueDate", due,
                "emi", Math.round(emi*100)/100.0, "principal", Math.round(principal*100)/100.0,
                "interest", Math.round(interest*100)/100.0, "balance", Math.max(0, Math.round(p*100)/100.0)));
            due = due.plusMonths(1);
        }
        return schedule;
    }

    private BigDecimal getInterestRate(LoanType type) {
        return switch (type) {
            case HOME       -> new BigDecimal("8.50");
            case PERSONAL   -> new BigDecimal("13.50");
            case AUTO       -> new BigDecimal("9.50");
            case EDUCATION  -> new BigDecimal("10.50");
            case BUSINESS   -> new BigDecimal("12.00");
            case GOLD       -> new BigDecimal("7.50");
            default         -> new BigDecimal("15.00");
        };
    }
}