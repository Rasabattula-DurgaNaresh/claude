package com.banking.loan.repository;
import com.banking.loan.entity.LoanApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface LoanRepository extends JpaRepository<LoanApplication, Long> {
    List<LoanApplication> findByUserId(Long userId);
    List<LoanApplication> findByStatus(LoanApplication.LoanStatus status);
}