package com.banking.account.repository;

import com.banking.account.entity.Account;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

public interface AccountRepository extends JpaRepository<Account, Long> {

    List<Account>           findByUserId(Long userId);
    Optional<Account>       findByAccountNumber(String accountNumber);
    boolean                 existsByAccountNumber(String accountNumber);

    @Query("SELECT a FROM Account a WHERE a.userId = :uid AND a.status = 'ACTIVE'")
    List<Account> findActiveByUserId(@Param("uid") Long userId);

    @Query("SELECT SUM(a.availableBalance) FROM Account a WHERE a.userId = :uid AND a.status = 'ACTIVE'")
    BigDecimal getTotalBalanceByUser(@Param("uid") Long userId);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT a FROM Account a WHERE a.accountNumber = :num")
    Optional<Account> findByAccountNumberForUpdate(@Param("num") String accountNumber);

    Page<Account> findByStatus(Account.AccountStatus status, Pageable pageable);
}