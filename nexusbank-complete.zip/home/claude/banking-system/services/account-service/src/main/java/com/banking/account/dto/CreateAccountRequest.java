package com.banking.account.dto;

import com.banking.account.entity.Account;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.math.BigDecimal;

@Data
public class CreateAccountRequest {
    @NotNull                  private Account.AccountType accountType;
    @NotBlank                 private String accountName;
    @NotBlank @Size(max=10)   private String branchCode;
    @DecimalMin("0.00")       private BigDecimal initialDeposit;
    @Size(max=3)              private String currency;
}