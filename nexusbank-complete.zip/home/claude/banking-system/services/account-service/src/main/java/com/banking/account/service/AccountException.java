package com.banking.account.service;
public class AccountException extends RuntimeException {
    public AccountException(String message) { super(message); }
}