package com.banking.account.controller;

import com.banking.account.dto.*;
import com.banking.account.service.AccountService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/accounts")
@RequiredArgsConstructor
@Tag(name = "Account Management")
public class AccountController {

    private final AccountService accountService;

    @PostMapping
    @Operation(summary = "Open a new bank account")
    public ResponseEntity<AccountDto> openAccount(
            @RequestHeader("X-User-Id")    String userId,
            @RequestHeader("X-User-Cif")   String cifNo,
            @RequestBody @Valid CreateAccountRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(accountService.openAccount(Long.parseLong(userId), cifNo, req));
    }

    @GetMapping
    @Operation(summary = "Get all accounts for the authenticated user")
    public ResponseEntity<List<AccountDto>> getMyAccounts(
            @RequestHeader("X-User-Id") String userId) {
        return ResponseEntity.ok(accountService.getAccountsByUser(Long.parseLong(userId)));
    }

    @GetMapping("/{accountNumber}")
    @Operation(summary = "Get account details by account number")
    public ResponseEntity<AccountDto> getAccount(@PathVariable String accountNumber) {
        return ResponseEntity.ok(accountService.getByAccountNumber(accountNumber));
    }

    @PatchMapping("/{accountNumber}/freeze")
    @Operation(summary = "Freeze an account")
    public ResponseEntity<AccountDto> freeze(
            @PathVariable String accountNumber,
            @RequestParam String reason) {
        return ResponseEntity.ok(accountService.freezeAccount(accountNumber, reason));
    }
}