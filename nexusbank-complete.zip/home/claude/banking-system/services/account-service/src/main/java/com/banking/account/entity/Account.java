package com.banking.account.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "BANK_ACCOUNTS",
    uniqueConstraints = @UniqueConstraint(columnNames = "ACCOUNT_NUMBER", name = "UQ_ACCOUNT_NUMBER"))
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_account")
    @SequenceGenerator(name = "seq_account", sequenceName = "SEQ_BANK_ACCOUNTS",
                       allocationSize = 50, initialValue = 1)
    @Column(name = "ACCOUNT_ID")
    private Long accountId;

    @Column(name = "ACCOUNT_NUMBER",  nullable = false, length = 20, unique = true) private String accountNumber;
    @Column(name = "USER_ID",         nullable = false)                              private Long   userId;
    @Column(name = "CIF_NO",          nullable = false, length = 15)                 private String cifNo;
    @Column(name = "ACCOUNT_NAME",    nullable = false, length = 100)                private String accountName;
    @Column(name = "BRANCH_CODE",     nullable = false, length = 10)                 private String branchCode;
    @Column(name = "IFSC_CODE",       nullable = false, length = 11)                 private String ifscCode;
    @Column(name = "CURRENCY",        nullable = false, length = 3)
    @Builder.Default private String currency = "USD";

    @Enumerated(EnumType.STRING)
    @Column(name = "ACCOUNT_TYPE",    nullable = false, length = 20)
    private AccountType accountType;

    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS",          nullable = false, length = 20)
    @Builder.Default private AccountStatus status = AccountStatus.ACTIVE;

    @Column(name = "AVAILABLE_BALANCE", nullable = false, precision = 19, scale = 2)
    @Builder.Default private BigDecimal availableBalance = BigDecimal.ZERO;

    @Column(name = "LEDGER_BALANCE",    nullable = false, precision = 19, scale = 2)
    @Builder.Default private BigDecimal ledgerBalance    = BigDecimal.ZERO;

    @Column(name = "MINIMUM_BALANCE",   nullable = false, precision = 19, scale = 2)
    @Builder.Default private BigDecimal minimumBalance   = new BigDecimal("500.00");

    @Column(name = "DAILY_LIMIT",       precision = 19, scale = 2) private BigDecimal dailyLimit;
    @Column(name = "INTEREST_RATE",     precision = 5,  scale = 2) private BigDecimal interestRate;
    @Column(name = "MATURITY_DATE")                                  private LocalDate  maturityDate;
    @Column(name = "IS_JOINT_ACCOUNT") @Builder.Default            private boolean    jointAccount = false;

    @Version @Column(name = "VERSION") private Long version; // optimistic locking

    @CreationTimestamp @Column(name = "OPENED_DATE", updatable = false) private LocalDateTime openedDate;
    @UpdateTimestamp   @Column(name = "UPDATED_AT")                      private LocalDateTime updatedAt;
    @Column(name = "CLOSED_DATE")                                        private LocalDateTime closedDate;

    public enum AccountType   { SAVINGS, CURRENT, SALARY, FIXED_DEPOSIT, RECURRING_DEPOSIT, NRE, NRO }
    public enum AccountStatus { ACTIVE, DORMANT, FROZEN, CLOSED, PENDING }

    public boolean canDebit(BigDecimal amount) {
        return status == AccountStatus.ACTIVE &&
               availableBalance.subtract(amount).compareTo(minimumBalance) >= 0;
    }
}