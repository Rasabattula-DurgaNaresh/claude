package com.banking.account.service;

import com.banking.account.dto.*;
import com.banking.account.entity.Account;
import com.banking.account.repository.AccountRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Service @RequiredArgsConstructor @Slf4j
public class AccountService {

    private final AccountRepository  accountRepo;
    private final KafkaTemplate<String, Object> kafka;

    @Transactional
    public AccountDto openAccount(Long userId, String cifNo, CreateAccountRequest req) {
        String accountNumber = generateAccountNumber(req.getAccountType());

        BigDecimal minBalance = switch (req.getAccountType()) {
            case SAVINGS         -> new BigDecimal("500.00");
            case CURRENT         -> new BigDecimal("5000.00");
            case SALARY          -> BigDecimal.ZERO;
            case FIXED_DEPOSIT   -> new BigDecimal("10000.00");
            default              -> new BigDecimal("1000.00");
        };

        BigDecimal interest = switch (req.getAccountType()) {
            case SAVINGS         -> new BigDecimal("4.00");
            case FIXED_DEPOSIT   -> new BigDecimal("7.50");
            case RECURRING_DEPOSIT -> new BigDecimal("6.50");
            default              -> BigDecimal.ZERO;
        };

        Account account = Account.builder()
            .accountNumber(accountNumber)
            .userId(userId)
            .cifNo(cifNo)
            .accountName(req.getAccountName())
            .accountType(req.getAccountType())
            .branchCode(req.getBranchCode())
            .ifscCode("NEXUS" + req.getBranchCode())
            .currency(req.getCurrency() != null ? req.getCurrency() : "USD")
            .availableBalance(req.getInitialDeposit())
            .ledgerBalance(req.getInitialDeposit())
            .minimumBalance(minBalance)
            .interestRate(interest)
            .dailyLimit(new BigDecimal("50000.00"))
            .maturityDate(req.getAccountType() == Account.AccountType.FIXED_DEPOSIT
                ? LocalDate.now().plusYears(1) : null)
            .build();

        account = accountRepo.save(account);

        // Publish event
        kafka.send("account-events", Map.of(
            "event", "ACCOUNT_OPENED",
            "accountId", account.getAccountId(),
            "accountNumber", accountNumber,
            "userId", userId,
            "type", req.getAccountType().name()
        ));

        log.info("Account {} opened for user {}", accountNumber, userId);
        return toDto(account);
    }

    @Transactional(readOnly = true)
    public List<AccountDto> getAccountsByUser(Long userId) {
        return accountRepo.findByUserId(userId).stream()
            .map(this::toDto).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public AccountDto getByAccountNumber(String accountNumber) {
        return accountRepo.findByAccountNumber(accountNumber)
            .map(this::toDto)
            .orElseThrow(() -> new AccountException("Account not found: " + accountNumber));
    }

    @Transactional
    public void updateBalance(String accountNumber, BigDecimal amount, String type) {
        Account account = accountRepo.findByAccountNumberForUpdate(accountNumber)
            .orElseThrow(() -> new AccountException("Account not found: " + accountNumber));

        if ("DEBIT".equals(type)) {
            if (!account.canDebit(amount)) {
                throw new AccountException("Insufficient balance in account: " + accountNumber);
            }
            account.setAvailableBalance(account.getAvailableBalance().subtract(amount));
            account.setLedgerBalance(account.getLedgerBalance().subtract(amount));
        } else {
            account.setAvailableBalance(account.getAvailableBalance().add(amount));
            account.setLedgerBalance(account.getLedgerBalance().add(amount));
        }
        accountRepo.save(account);
    }

    @Transactional
    public AccountDto freezeAccount(String accountNumber, String reason) {
        Account account = accountRepo.findByAccountNumber(accountNumber)
            .orElseThrow(() -> new AccountException("Account not found: " + accountNumber));
        account.setStatus(Account.AccountStatus.FROZEN);
        kafka.send("account-events", Map.of("event", "ACCOUNT_FROZEN",
                "accountNumber", accountNumber, "reason", reason));
        return toDto(accountRepo.save(account));
    }

    private String generateAccountNumber(Account.AccountType type) {
        String prefix = switch (type) {
            case SAVINGS         -> "SB";
            case CURRENT         -> "CA";
            case SALARY          -> "SA";
            case FIXED_DEPOSIT   -> "FD";
            default              -> "XX";
        };
        String number;
        do {
            number = prefix + String.format("%012d", (long)(Math.random() * 1_000_000_000_000L));
        } while (accountRepo.existsByAccountNumber(number));
        return number;
    }

    private AccountDto toDto(Account a) {
        return AccountDto.builder()
            .accountId(a.getAccountId())
            .accountNumber(a.getAccountNumber())
            .accountName(a.getAccountName())
            .accountType(a.getAccountType().name())
            .status(a.getStatus().name())
            .availableBalance(a.getAvailableBalance())
            .ledgerBalance(a.getLedgerBalance())
            .minimumBalance(a.getMinimumBalance())
            .currency(a.getCurrency())
            .branchCode(a.getBranchCode())
            .ifscCode(a.getIfscCode())
            .interestRate(a.getInterestRate())
            .maturityDate(a.getMaturityDate())
            .openedDate(a.getOpenedDate())
            .build();
    }
}