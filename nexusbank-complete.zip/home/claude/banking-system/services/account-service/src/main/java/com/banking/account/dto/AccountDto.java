package com.banking.account.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data @Builder @JsonInclude(JsonInclude.Include.NON_NULL)
public class AccountDto {
    private Long       accountId;
    private String     accountNumber;
    private String     accountName;
    private String     accountType;
    private String     status;
    private BigDecimal availableBalance;
    private BigDecimal ledgerBalance;
    private BigDecimal minimumBalance;
    private String     currency;
    private String     branchCode;
    private String     ifscCode;
    private BigDecimal interestRate;
    private LocalDate  maturityDate;
    private LocalDateTime openedDate;
}