#!/bin/bash
# Build all microservices
set -e
echo "Building all services..."
cd "$(dirname "$0")"
mvn clean package -DskipTests
echo "All services built successfully!"