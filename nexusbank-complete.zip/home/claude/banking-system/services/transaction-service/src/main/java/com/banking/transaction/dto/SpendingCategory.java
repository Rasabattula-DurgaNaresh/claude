package com.banking.transaction.dto;
import java.math.BigDecimal;
public record SpendingCategory(String category, BigDecimal totalAmount) {}