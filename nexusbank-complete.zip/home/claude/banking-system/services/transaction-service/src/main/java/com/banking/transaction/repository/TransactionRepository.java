package com.banking.transaction.repository;

import com.banking.transaction.entity.Transaction;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {

    Page<Transaction> findByAccountNumberOrderByTransactionDateDesc(
        String accountNumber, Pageable pageable);

    List<Transaction> findByAccountNumberAndTransactionDateBetween(
        String accountNumber, LocalDateTime from, LocalDateTime to);

    Optional<Transaction> findByReferenceNumber(String ref);

    @Query("SELECT SUM(t.amount) FROM Transaction t WHERE t.accountNumber = :acc " +
           "AND t.transactionType = 'DEBIT' AND t.transactionDate >= :since " +
           "AND t.status = 'COMPLETED'")
    BigDecimal getDailyDebitTotal(@Param("acc") String acc, @Param("since") LocalDateTime since);

    @Query("SELECT t.category, SUM(t.amount) FROM Transaction t " +
           "WHERE t.userId = :uid AND t.transactionDate BETWEEN :from AND :to " +
           "GROUP BY t.category ORDER BY SUM(t.amount) DESC")
    List<Object[]> getSpendingByCategory(
        @Param("uid") Long userId,
        @Param("from") LocalDateTime from,
        @Param("to") LocalDateTime to);

    List<Transaction> findByUserIdAndFlaggedTrue(Long userId);
    long countByAccountNumberAndTransactionDateAfter(String acc, LocalDateTime since);
}