package com.banking.transaction.service;

import com.banking.transaction.client.AccountClient;
import com.banking.transaction.dto.*;
import com.banking.transaction.entity.Transaction;
import com.banking.transaction.entity.Transaction.*;
import com.banking.transaction.repository.TransactionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.*;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service @RequiredArgsConstructor @Slf4j
public class TransactionService {

    private final TransactionRepository txRepo;
    private final AccountClient         accountClient;
    private final KafkaTemplate<String, Object> kafka;

    @Transactional
    public TransactionDto transfer(Long userId, FundTransferRequest req) {
        // 1. Validate source account
        AccountClient.AccountInfo source = accountClient.getAccount(req.getFromAccount());
        if (!"ACTIVE".equals(source.status())) {
            throw new TransactionException("Source account is " + source.status());
        }
        if (source.availableBalance().compareTo(req.getAmount()) < 0) {
            throw new TransactionException("Insufficient balance");
        }

        // 2. Validate destination account (if same bank)
        if (req.getIfscCode().startsWith("NEXUS")) {
            AccountClient.AccountInfo dest = accountClient.getAccount(req.getToAccount());
            if (!"ACTIVE".equals(dest.status())) {
                throw new TransactionException("Destination account is not active");
            }
        }

        // 3. Calculate charges
        BigDecimal charges = calculateCharges(req.getTransferType(), req.getAmount());

        // 4. Create transaction record
        Transaction tx = Transaction.builder()
            .referenceNumber(generateRef(req.getTransferType().name()))
            .userId(userId)
            .accountNumber(req.getFromAccount())
            .counterpartyAccount(req.getToAccount())
            .counterpartyName(req.getBeneficiaryName())
            .counterpartyBank(req.getBankName())
            .ifscCode(req.getIfscCode())
            .transactionType(req.getTransferType())
            .amount(req.getAmount())
            .charges(charges)
            .description(req.getDescription())
            .narration(req.getNarration())
            .channel(Channel.INTERNET_BANKING)
            .status(TransactionStatus.PROCESSING)
            .build();

        tx = txRepo.save(tx);

        // 5. Debit source
        BigDecimal totalDebit = req.getAmount().add(charges);
        accountClient.updateBalance(req.getFromAccount(), totalDebit, "DEBIT");

        // 6. Credit destination (same bank)
        if (req.getIfscCode().startsWith("NEXUS")) {
            accountClient.updateBalance(req.getToAccount(), req.getAmount(), "CREDIT");
            // Create credit transaction for recipient
            Transaction creditTx = Transaction.builder()
                .referenceNumber(tx.getReferenceNumber() + "_CR")
                .userId(userId)
                .accountNumber(req.getToAccount())
                .counterpartyAccount(req.getFromAccount())
                .transactionType(TransactionType.CREDIT)
                .amount(req.getAmount())
                .description("Received from " + req.getFromAccount())
                .status(TransactionStatus.COMPLETED)
                .completedAt(LocalDateTime.now())
                .build();
            txRepo.save(creditTx);
        }

        // 7. Update status
        tx.setStatus(TransactionStatus.COMPLETED);
        tx.setCompletedAt(LocalDateTime.now());
        tx = txRepo.save(tx);

        // 8. Publish event
        kafka.send("transaction-events", Map.of(
            "event", "TRANSFER_COMPLETED",
            "referenceNumber", tx.getReferenceNumber(),
            "amount", req.getAmount(),
            "fromAccount", req.getFromAccount(),
            "toAccount", req.getToAccount(),
            "userId", userId
        ));

        log.info("Transfer {} completed: {} → {} amount={}", 
                tx.getReferenceNumber(), req.getFromAccount(), req.getToAccount(), req.getAmount());
        return toDto(tx);
    }

    @Transactional(readOnly = true)
    public Page<TransactionDto> getStatement(String accountNumber, Pageable pageable) {
        return txRepo.findByAccountNumberOrderByTransactionDateDesc(accountNumber, pageable)
            .map(this::toDto);
    }

    @Transactional(readOnly = true)
    public List<SpendingCategory> getSpendingAnalysis(Long userId, LocalDateTime from, LocalDateTime to) {
        return txRepo.getSpendingByCategory(userId, from, to).stream()
            .map(row -> new SpendingCategory((String)row[0], (BigDecimal)row[1]))
            .collect(Collectors.toList());
    }

    private BigDecimal calculateCharges(TransactionType type, BigDecimal amount) {
        return switch (type) {
            case NEFT -> new BigDecimal("5.00");
            case RTGS -> amount.compareTo(new BigDecimal("200000")) > 0
                       ? new BigDecimal("30.00") : new BigDecimal("25.00");
            case IMPS -> new BigDecimal("5.00");
            default   -> BigDecimal.ZERO;
        };
    }

    private String generateRef(String type) {
        return type + System.currentTimeMillis() + (int)(Math.random() * 9999);
    }

    private TransactionDto toDto(Transaction t) {
        return TransactionDto.builder()
            .transactionId(t.getTransactionId())
            .referenceNumber(t.getReferenceNumber())
            .transactionType(t.getTransactionType().name())
            .amount(t.getAmount())
            .charges(t.getCharges())
            .currency(t.getCurrency())
            .accountNumber(t.getAccountNumber())
            .counterpartyAccount(t.getCounterpartyAccount())
            .counterpartyName(t.getCounterpartyName())
            .description(t.getDescription())
            .status(t.getStatus().name())
            .channel(t.getChannel().name())
            .transactionDate(t.getTransactionDate())
            .completedAt(t.getCompletedAt())
            .category(t.getCategory())
            .build();
    }
}