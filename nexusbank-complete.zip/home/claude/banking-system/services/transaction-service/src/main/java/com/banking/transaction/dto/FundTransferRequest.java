package com.banking.transaction.dto;

import com.banking.transaction.entity.Transaction;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.math.BigDecimal;

@Data
public class FundTransferRequest {
    @NotBlank                       private String fromAccount;
    @NotBlank                       private String toAccount;
    @NotBlank                       private String beneficiaryName;
    @NotBlank                       private String ifscCode;
    private String bankName;
    @NotNull @DecimalMin("1.00")    private BigDecimal amount;
    private String description;
    private String narration;
    private Transaction.TransactionType transferType = Transaction.TransactionType.IMPS;
}