package com.banking.transaction.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data @Builder @JsonInclude(JsonInclude.Include.NON_NULL)
public class TransactionDto {
    private Long   transactionId;
    private String referenceNumber;
    private String transactionType;
    private BigDecimal amount;
    private BigDecimal charges;
    private String currency;
    private String accountNumber;
    private String counterpartyAccount;
    private String counterpartyName;
    private String description;
    private String status;
    private String channel;
    private String category;
    private LocalDateTime transactionDate;
    private LocalDateTime completedAt;
}