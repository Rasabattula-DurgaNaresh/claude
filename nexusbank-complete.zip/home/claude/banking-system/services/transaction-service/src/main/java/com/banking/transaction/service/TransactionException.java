package com.banking.transaction.service;
public class TransactionException extends RuntimeException {
    public TransactionException(String message) { super(message); }
}