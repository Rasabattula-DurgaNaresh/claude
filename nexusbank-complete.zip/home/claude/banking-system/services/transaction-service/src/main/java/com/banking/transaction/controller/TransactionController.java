package com.banking.transaction.controller;

import com.banking.transaction.dto.*;
import com.banking.transaction.service.TransactionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/transactions")
@RequiredArgsConstructor
@Tag(name = "Transactions")
public class TransactionController {

    private final TransactionService txService;

    @PostMapping("/transfer")
    @Operation(summary = "Initiate a fund transfer")
    public ResponseEntity<TransactionDto> transfer(
            @RequestHeader("X-User-Id") String userId,
            @RequestBody @Valid FundTransferRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(txService.transfer(Long.parseLong(userId), req));
    }

    @GetMapping("/statement/{accountNumber}")
    @Operation(summary = "Get account statement (paginated)")
    public ResponseEntity<Page<TransactionDto>> getStatement(
            @PathVariable String accountNumber,
            @RequestParam(defaultValue = "0")  int page,
            @RequestParam(defaultValue = "20") int size) {
        Pageable pageable = PageRequest.of(page, size);
        return ResponseEntity.ok(txService.getStatement(accountNumber, pageable));
    }

    @GetMapping("/spending-analysis")
    @Operation(summary = "Get spending analysis by category")
    public ResponseEntity<List<SpendingCategory>> spendingAnalysis(
            @RequestHeader("X-User-Id") String userId,
            @RequestParam @DateTimeFormat(iso=DateTimeFormat.ISO.DATE_TIME) LocalDateTime from,
            @RequestParam @DateTimeFormat(iso=DateTimeFormat.ISO.DATE_TIME) LocalDateTime to) {
        return ResponseEntity.ok(txService.getSpendingAnalysis(Long.parseLong(userId), from, to));
    }
}