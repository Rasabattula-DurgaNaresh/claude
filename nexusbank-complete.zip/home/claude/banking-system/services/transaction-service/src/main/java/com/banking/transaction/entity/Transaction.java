package com.banking.transaction.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "TRANSACTIONS",
    indexes = {
        @Index(name = "IDX_TX_ACCOUNT",    columnList = "ACCOUNT_NUMBER"),
        @Index(name = "IDX_TX_DATE",       columnList = "TRANSACTION_DATE"),
        @Index(name = "IDX_TX_REF",        columnList = "REFERENCE_NUMBER"),
        @Index(name = "IDX_TX_USER",       columnList = "USER_ID")
    })
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_tx")
    @SequenceGenerator(name = "seq_tx", sequenceName = "SEQ_TRANSACTIONS",
                       allocationSize = 100, initialValue = 1)
    @Column(name = "TRANSACTION_ID")
    private Long transactionId;

    @Column(name = "REFERENCE_NUMBER", nullable = false, length = 30, unique = true) private String referenceNumber;
    @Column(name = "USER_ID",          nullable = false)                              private Long   userId;
    @Column(name = "ACCOUNT_NUMBER",   nullable = false, length = 20)                private String accountNumber;
    @Column(name = "COUNTERPARTY_ACCOUNT", length = 20)                              private String counterpartyAccount;
    @Column(name = "COUNTERPARTY_NAME",    length = 100)                             private String counterpartyName;
    @Column(name = "COUNTERPARTY_BANK",    length = 50)                              private String counterpartyBank;
    @Column(name = "IFSC_CODE",            length = 11)                              private String ifscCode;

    @Enumerated(EnumType.STRING)
    @Column(name = "TRANSACTION_TYPE", nullable = false, length = 20)
    private TransactionType transactionType;

    @Enumerated(EnumType.STRING)
    @Column(name = "CHANNEL", length = 20)
    @Builder.Default private Channel channel = Channel.INTERNET_BANKING;

    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS", nullable = false, length = 20)
    @Builder.Default private TransactionStatus status = TransactionStatus.PENDING;

    @Column(name = "AMOUNT",           nullable = false, precision = 19, scale = 2) private BigDecimal amount;
    @Column(name = "CURRENCY",         nullable = false, length = 3)
    @Builder.Default private String currency = "USD";
    @Column(name = "BALANCE_AFTER",    precision = 19, scale = 2)                   private BigDecimal balanceAfter;
    @Column(name = "CHARGES",          precision = 19, scale = 2)
    @Builder.Default private BigDecimal charges = BigDecimal.ZERO;
    @Column(name = "DESCRIPTION",      length = 255)                                private String description;
    @Column(name = "NARRATION",        length = 500)                                private String narration;
    @Column(name = "CATEGORY",         length = 50)                                 private String category;
    @Column(name = "FAILURE_REASON",   length = 255)                                private String failureReason;
    @Column(name = "IS_FLAGGED")   @Builder.Default private boolean flagged = false;
    @Column(name = "MERCHANT_CODE",    length = 20)                                 private String merchantCode;

    @CreationTimestamp
    @Column(name = "TRANSACTION_DATE", nullable = false, updatable = false)
    private LocalDateTime transactionDate;

    @Column(name = "COMPLETED_AT") private LocalDateTime completedAt;

    public enum TransactionType {
        CREDIT, DEBIT, FUND_TRANSFER, NEFT, RTGS, IMPS,
        UPI, ATM_WITHDRAWAL, BILL_PAYMENT, EMI, FEE, INTEREST
    }

    public enum Channel { INTERNET_BANKING, MOBILE_APP, ATM, BRANCH, API, SYSTEM }
    public enum TransactionStatus { PENDING, PROCESSING, COMPLETED, FAILED, REVERSED, FLAGGED }
}