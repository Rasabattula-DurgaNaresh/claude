package com.banking.transaction.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

/**
 * Feign client for inter-service communication with Account Service.
 * Calls go through Eureka service discovery.
 */
@FeignClient(name = "account-service", path = "/api/accounts")
public interface AccountClient {

    @GetMapping("/{accountNumber}")
    AccountInfo getAccount(@PathVariable String accountNumber);

    @PatchMapping("/{accountNumber}/balance")
    void updateBalance(
        @PathVariable String accountNumber,
        @RequestParam BigDecimal amount,
        @RequestParam String type);

    record AccountInfo(
        String  accountNumber,
        String  accountName,
        String  status,
        String  currency,
        java.math.BigDecimal availableBalance,
        java.math.BigDecimal minimumBalance
    ) {}
}