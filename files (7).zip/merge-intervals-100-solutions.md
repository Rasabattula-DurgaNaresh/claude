# 100 Merge Interval Problems — Complete Java Solutions

> **100 Problems · 5 Java files · 5 PNG diagrams · All patterns + LeetCode classics**

---

## Diagram Index

| Diagram | Covers |
|---------|--------|
| `diagrams/01_merge_intervals_core.png` | Merge logic, before/after, overlap cases |
| `diagrams/02_sweep_line_meeting_rooms.png` | Sweep line visualization + meeting room count |
| `diagrams/03_insert_intersection.png` | Insert interval 3-phase + intersection two-pointer |
| `diagrams/04_calendar_skyline.png` | Calendar booking II + skyline problem |
| `diagrams/05_decision_tree.png` | Master guide: problem type → algorithm → complexity |

## Project Structure

```
merge-intervals-100/
├── pom.xml
├── diagrams/           ← 5 PNG diagrams
├── docs/               ← This guide
└── src/main/java/com/mergeintervals/
    ├── utils/      Interval.java                (shared utility)
    ├── beginner/   BeginnerProblems.java         (P1-20)
    ├── easymedium/ EasyMediumProblems.java       (P21-40)
    ├── medium/     MediumProblems.java            (P41-60)
    └── hard/       HardProblems.java              (P61-100)
```

**Run:**
```bash
mvn compile exec:java -Dexec.mainClass="com.mergeintervals.beginner.BeginnerProblems"
mvn compile exec:java -Dexec.mainClass="com.mergeintervals.hard.HardProblems"
```

---

# Core Algorithms & Templates

## Template 1 — Sort + Merge (Most Common)
```java
// O(n log n) time, O(n) space
// Works for: merge intervals, remove covered, count disjoint
Arrays.sort(intervals, (a,b) -> a[0] - b[0]); // sort by start time
List<int[]> result = new ArrayList<>();
for (int[] curr : intervals) {
    if (result.isEmpty() || result.get(result.size()-1)[1] < curr[0]) {
        result.add(curr);                             // no overlap → new interval
    } else {
        result.get(result.size()-1)[1] =
            Math.max(result.get(result.size()-1)[1], curr[1]); // overlap → extend end
    }
}
// Overlap condition: prev.end >= curr.start  (touching = overlap for merging)
```

## Template 2 — Insert Interval (3-Phase)
```java
// O(n) time — already sorted input
// Phase 1: add all ending before newInterval starts
while (i < n && intervals[i][1] < newInterval[0]) result.add(intervals[i++]);
// Phase 2: merge all overlapping with newInterval
while (i < n && intervals[i][0] <= newInterval[1]) {
    newInterval[0] = Math.min(newInterval[0], intervals[i][0]);
    newInterval[1] = Math.max(newInterval[1], intervals[i][1]);
    i++;
}
result.add(newInterval);
// Phase 3: add remaining
while (i < n) result.add(intervals[i++]);
```

## Template 3 — Sweep Line (Count/Events)
```java
// O(n log n) — for counting simultaneous intervals (meeting rooms)
List<int[]> events = new ArrayList<>();
for (int[] iv : intervals) {
    events.add(new int[]{iv[0], +1}); // start: +1 active
    events.add(new int[]{iv[1], -1}); // end:   -1 active
}
events.sort((a,b) -> a[0] != b[0] ? a[0]-b[0] : a[1]-b[1]); // ties: end before start
int max = 0, cur = 0;
for (int[] ev : events) { cur += ev[1]; max = Math.max(max, cur); }
return max; // = minimum rooms needed
```

## Template 4 — Min-Heap for Rooms
```java
// O(n log n) — direct meeting room allocation
Arrays.sort(intervals, (a,b) -> a[0]-b[0]);
PriorityQueue<Integer> endTimes = new PriorityQueue<>(); // min-heap
for (int[] iv : intervals) {
    if (!endTimes.isEmpty() && endTimes.peek() <= iv[0])
        endTimes.poll(); // reuse room
    endTimes.offer(iv[1]); // allocate until this end time
}
return endTimes.size();
```

## Template 5 — Two Pointer Intersection
```java
// O(m+n) — find intersection of two sorted interval lists
int i=0, j=0;
while (i < A.length && j < B.length) {
    int lo = Math.max(A[i][0], B[j][0]);
    int hi = Math.min(A[i][1], B[j][1]);
    if (lo <= hi) result.add(new int[]{lo, hi}); // valid intersection
    if (A[i][1] < B[j][1]) i++; else j++;        // advance smaller end
}
```

## Template 6 — TreeMap for Dynamic Intervals
```java
// O(log n) per operation — for My Calendar, Range Module
TreeMap<Integer,Integer> ranges = new TreeMap<>();
// Add [start,end]: merge adjacent/overlapping neighbors
Integer lo = ranges.floorKey(end + 1);
while (lo != null && ranges.get(lo) >= start - 1) {
    start = Math.min(start, lo);
    end   = Math.max(end, ranges.get(lo));
    ranges.remove(lo);
    lo = ranges.floorKey(end + 1);
}
ranges.put(start, end);
```

---

# Overlap Detection

```java
// Two intervals [a,b] and [c,d] overlap if:
a <= d && c <= b    // NOT: b < c or d < a

// Examples:
[1,5] and [3,8]: 1<=8 && 3<=5 → OVERLAP (merge to [1,8])
[1,5] and [5,8]: 1<=8 && 5<=5 → TOUCHING (merge to [1,8])
[1,5] and [6,8]: 1<=8 && 6<=5 → FALSE    (no overlap)

// Coverage: [a,b] covers [c,d] if a<=c && d<=b
```

---

# BEGINNER LEVEL (P1–P20)

## P1. Merge Overlapping Intervals ⭐⭐
**LeetCode 56** — Core merge pattern.

```java
// [[1,4],[3,6],[8,10],[15,18],[17,20]] → [[1,6],[8,10],[15,20]]
// Sort by start → iterate → extend end if overlap
```

---

## P2. Insert Interval ⭐⭐
**LeetCode 57** — Three-phase insert without sorting. O(n).

```java
// [[1,2],[5,6],[8,10],[12,15]] + [3,8] → [[1,2],[3,10],[12,15]]
// Phase1: copy before → Phase2: merge overlapping → Phase3: copy after
```

---

## P3. Find Overlapping Intervals
Return all pairs (i,j) where i and j overlap. O(n²) brute force, O(n log n) with sort.

---

## P4. Check if Two Intervals Overlap
```java
a[0] <= b[1] && b[0] <= a[1]  // O(1)
```

---

## P5. Count Overlapping Pairs
O(n²) brute: check all pairs. Can optimize with sweep line to O(n log n).

---

## P6. Intersection of Two Interval Lists ⭐
**LeetCode 986** — Two-pointer. Advance pointer with smaller end. O(m+n).

```java
// A=[[0,4],[5,10]] B=[[2,6],[8,15]] → [[2,4],[5,6],[8,10]]
```

---

## P7. Remove Covered Intervals ⭐
**LeetCode 1288** — Sort by start asc, end desc. Track maxEnd. O(n log n).

```java
// Sort so larger intervals come first for same start
// [c,d] is covered if there exists [a,b] with a≤c and d≤b
```

---

## P8. Find Non-Overlapping Intervals ⭐
**LeetCode 435** — Greedy: sort by END, keep earliest-ending non-overlapping. O(n log n).

```java
// Min intervals to REMOVE to make rest non-overlapping
// Sort by end → greedily keep interval with earliest end
```

---

## P9. Merge Meeting Schedules
Merge two persons' sorted schedules into one merged busy schedule.

---

## P10. Can Attend All Meetings ⭐
**LeetCode 252** — Sort by start, check if any consecutive pair overlaps. O(n log n).

---

## P11. Minimum Meeting Rooms ⭐⭐
**LeetCode 253** — Min-heap of end times. Pop if room freed, always push. O(n log n).

---

## P12. Merge Adjacent Intervals
Merge only intervals that differ by at most 1 (e.g., [1,3] merges with [4,6] → [1,6]).

---

## P13. Free Time Between Meetings
After merging, find gaps between merged intervals. O(n log n).

---

## P14. Remove Intervals Inside Others
Sort by start desc, end asc; track maxEnd; skip if covered.

---

## P15-16. Sort by Start / End Time
`Arrays.sort(intervals, (a,b)->a[0]-b[0])` / `(a,b)->a[1]-b[1]`

---

## P17. Count Disjoint After Merge
`merge(intervals).length`

---

## P18. Find Interval Containing a Point
Linear scan: `iv[0] <= point && point <= iv[1]`. Binary search possible after sort.

---

## P19. Check All Disjoint
Sort, verify no adjacent overlap.

---

## P20. Maximum Overlap Count ⭐
Sweep line: events (+1 on start, -1 on end), sort, scan. O(n log n).

---

# EASY-MEDIUM (P21–P40)

## P21. Employee Free Time ⭐⭐
**LeetCode 759** — Flatten all schedules, sort, find gaps between merged intervals.

```java
// schedule = [[[1,3],[6,7]],[[2,4]],[[2,5],[9,12]]]
// Merged busy: [[1,5],[6,7],[9,12]]
// Free time: [[5,6],[7,9]]
```

---

## P22. Merge Intervals In-Place
Modify input list directly with index tracking. O(n log n) time, O(1) extra.

---

## P23. Insert and Merge Efficiently
Same as P2 — already O(n) with sorted input.

---

## P24. Find Common Free Slot
Merge all busy intervals from all schedules; first gap ≥ duration is the slot.

---

## P25. Merge Intervals from Multiple Lists
Flatten + sort + merge. O(N log N) where N = total intervals.

---

## P26. Find Earliest Meeting Slot
Same as P24 — first available gap between merged busy intervals.

---

## P27. Find Conflicting Appointments
Sort + check consecutive pairs. O(n log n).

---

## P28. Partition into Non-Overlapping Groups
Greedy: assign to first group that doesn't conflict. O(n² ) worst case.

---

## P29. Remove Minimum Overlapping Intervals
= P8. Greedy sort by end time.

---

## P30. Minimum Arrows to Burst Balloons ⭐
**LeetCode 452** — Sort by end. Arrow at end of first balloon bursts all overlapping.

```java
// [[10,16],[2,8],[1,6],[7,12]] → 2 arrows
// Sort by end → shoot at balloon[0].end, skip all overlapping
```

---

## P31. Union of Intervals
= P1 merge.

---

## P32. Find Interval Gaps
After merge, collect gaps: `[prevEnd, nextStart]`.

---

## P33. Merge Using Stack
Use Deque as explicit stack instead of ArrayList. Same result.

---

## P34. Merge Without Extra Space
Track write index in the original array. O(1) extra space.

---

## P35. Count Intervals After Merging
`merge(intervals).length`

---

## P36. Stream Intersections
Two-pointer on streaming sorted lists.

---

## P37. Merge from Linked List
Traverse linked list → collect → merge.

---

## P38. Merge K Sorted Interval Lists
Flatten all + sort + merge. O(N log N).

---

## P39. Detect Duplicate Intervals
HashSet with key = "start,end". O(n).

---

## P40. Smallest Covering Interval
Min of all starts, max of all ends. O(n).

---

# MEDIUM (P41–P60)

## P41. Weighted Interval Scheduling ⭐⭐
DP with binary search. Sort by end time. `dp[i] = max(dp[i-1], dp[last_non_conflict]+weight[i])`. O(n log n).

---

## P42. Maximum Non-Overlapping Intervals ⭐
Greedy: sort by end, pick earliest-ending compatible interval. O(n log n).

---

## P43. Dynamic Interval Insertion
TreeMap-based: `floorKey` + `ceilingKey` to merge adjacent intervals. O(log n) per insert.

---

## P44. Query Overlapping Intervals
Linear scan or interval tree for O(log n + k) queries.

---

## P45. Calendar Booking System (My Calendar I) ⭐
**LeetCode 729** — TreeMap: `floorKey` checks prev, `ceilingKey` checks next. O(log n).

---

## P46. Interval Tree Design
BST augmented with `maxEnd` — enables O(log n) overlap search.

```
Node: [lo, hi, maxEnd]
Insert: update maxEnd on path up
Search: if maxEnd < query.start → skip subtree
```

---

## P47. Find All Interval Chains
Connect intervals where previous end = next start.

---

## P48. Merge with Priorities
Sort by start then priority desc; skip portions already covered by higher priority.

---

## P49. Schedule Tasks with Intervals
Sort task windows by deadline (end time); greedily assign.

---

## P50. Minimum Platforms Problem ⭐
Sort arrivals and departures separately; two-pointer sweep. O(n log n).

---

## P51. Skyline Problem ⭐⭐⭐
**LeetCode 218** — Events: (L, -H) for start, (R, +H) for end. Sort events. Track height with TreeMap. O(n log n).

```java
// Buildings [[2,9,10],[3,7,15],[5,12,12]] → critical points
// Heights multiset: add on left edge, remove on right edge
// Output when max height changes
```

---

## P53. Range Module ⭐⭐
**LeetCode 715** — TreeMap[start → end] for disjoint ranges. Add/Remove/Query in O(log n).

---

## P54. Continuous Ranges in Array ⭐
Sort array, group consecutive numbers. O(n log n).

---

## P55. Summary Ranges ⭐
**LeetCode 228** — Same as P54 but output "a->b" or "a". O(n).

---

## P56. Missing Ranges ⭐
**LeetCode 163** — Scan gaps between consecutive elements. Use long for overflow.

---

## P57. Count Active at Time Point
Count intervals where `start <= t < end`. O(n) linear scan.

---

## P58. Find Peak Interval Overlap
= P20 (sweep line max). O(n log n).

---

## P59. Longest Merged Interval
After merge, find interval with max (end - start).

---

## P60. Split into Non-Overlapping Parts
Sweep line: record [start, end, count] for each sub-interval with its overlap count.

---

# MEDIUM-HARD (P61–P80)

## P61-70. Domain Applications
All use core merge/sweep templates adapted to domain data types (IP ranges as long[], genomic coordinates, memory blocks with PID, video segments).

---

## P71. My Calendar II ⭐⭐
**LeetCode 731** — Maintain `booked` and `overlaps` lists. Reject if new booking overlaps any existing double-booking. O(n²) but passes with small n.

---

## P72. My Calendar III ⭐⭐
**LeetCode 732** — TreeMap delta array (sweep line online). `delta[start]++, delta[end]--`. Max prefix sum = max overlap. O(n log n).

---

## P73. Job Scheduling with Profits ⭐⭐⭐
**LeetCode 1235** — DP with binary search. `dp[endTime] = maxProfit`. TreeMap for `floorEntry`. O(n log n).

```java
Arrays.sort(jobs, (a,b)->a[1]-b[1]); // sort by end
TreeMap<Integer,Integer> dp = new TreeMap<>();
dp.put(0, 0);
for (int[] job : jobs) {
    int cur = dp.floorEntry(job[0]).getValue() + job[2];
    if (cur > dp.lastEntry().getValue()) dp.put(job[1], cur);
}
return dp.lastEntry().getValue();
```

---

## P77. Dynamic Disjoint Set
TreeMap `[start→end]`: add merges neighbors, query checks with floorKey. O(log n) ops.

---

## P80. CPU Task Scheduling ⭐
**LeetCode 621** — Formula: `max(n, (maxFreq-1)*(n+1)+maxCount)`.

---

# HARD — LEETCODE CLASSICS (P81–P100)

## P81. LeetCode 56 — Merge Intervals ⭐⭐
Sort by start. Extend end on overlap. Return merged list.

---

## P82. LeetCode 57 — Insert Interval ⭐⭐
3-phase: copy before / merge overlapping / copy after. O(n).

---

## P83. LeetCode 435 — Non-Overlapping Intervals ⭐⭐
Greedy by end time. Count removed intervals. O(n log n).

---

## P84. LeetCode 253 — Meeting Rooms II ⭐⭐
Min-heap of end times. Size of heap = rooms needed. O(n log n).

---

## P85. LeetCode 759 — Employee Free Time ⭐⭐
Flatten → merge → find gaps. O(N log N).

---

## P86. LeetCode 228 — Summary Ranges ⭐
Group consecutive integers → "a->b" or "a". O(n).

---

## P87. LeetCode 163 — Missing Ranges ⭐
Scan gaps. Use long to avoid integer overflow on INT_MAX±1.

---

## P88. LeetCode 715 — Range Module ⭐⭐⭐
TreeMap[start→end]. addRange/removeRange/queryRange all O(log n + k).

---

## P89. LeetCode 729 — My Calendar I ⭐⭐
TreeMap: floorKey (prev interval), ceilingKey (next interval). O(log n).

---

## P90. LeetCode 731 — My Calendar II ⭐⭐
Track booked + double-booked lists. Block triple-booking.

---

## P91. LeetCode 732 — My Calendar III ⭐⭐⭐
TreeMap delta. `book(s,e)`: `delta[s]++, delta[e]--`. Return max prefix sum.

---

## P92. Advanced Interval Tree
BST with `maxEnd` augmentation. O(log n) single overlap search, O(log n + k) all overlaps.

---

## P93. Interval Search Engine
Index intervals by start time; binary search for candidates; verify overlap.

---

## P95. Merge Billions of Intervals
External sort strategy: chunk → sort each chunk → merge sorted chunks with min-heap.

---

## P96. Cloud Resource Optimization
Merge usage windows; free time = total - used.

---

## P97. Real-Time Event Detection
TreeMap-based: on each new event, check neighbors in sorted structure for overlap.

---

## P98. Reusable Library
`MergeIntervalLib` provides: `merge()`, `insert()`, `minRooms()`, `maxOverlap()`, `intersection()`.

---

## P99. Scheduling Toolkit
`SchedulingToolkit` provides: `bestMeetingSlot()`, `allFreeSlots()`, `utilizationPercent()`.

---

## P100. Interval Master Set
Benchmark runner demonstrating all core algorithms on sample data.

---

# Complexity Summary

| Algorithm | Time | Space | Use Case |
|-----------|------|-------|----------|
| Sort + Merge | O(n log n) | O(n) | Merge, count, remove covered |
| Insert Interval | O(n) | O(n) | Sorted input, single insert |
| Sweep Line | O(n log n) | O(n) | Count simultaneous, peak overlap |
| Min-Heap Rooms | O(n log n) | O(n) | Meeting rooms, min platforms |
| Two Pointer Intersect | O(m+n) | O(1) | Sorted lists intersection |
| TreeMap Dynamic | O(log n) per op | O(n) | Calendar, range module |
| DP + Binary Search | O(n log n) | O(n) | Weighted scheduling |
| Interval Tree | O(log n) query | O(n) | Overlap search engine |

---

# Pattern Selection Guide

```
Problem asks for:
├── Merge/combine overlaps?          → Sort + Merge Template (T1)
├── Insert into sorted list?         → 3-Phase Insert (T2)
├── Count rooms/platforms?           → Min-Heap (T4) OR Sweep Line (T3)
├── Find free time/gaps?             → Merge then find gaps
├── Intersection of two lists?       → Two Pointer (T5)
├── Dynamic insert/query?            → TreeMap (T6)
├── Remove fewest to non-overlap?    → Greedy sort by END
├── Maximum profit selection?        → DP + Binary Search
└── Point in time active count?      → Sweep Line (T3)
```

*100 Merge Interval Problems — Complete Java Solutions*
