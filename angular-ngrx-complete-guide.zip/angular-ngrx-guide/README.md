# ⚡ Angular + NgRx — Complete Guide with Code Examples

A comprehensive, production-quality code guide covering **every major topic** in Angular and NgRx State Management.

## 📁 Project Structure

```
src/app/
├── 01-components/          # Angular Components
│   ├── basic/              # @Component, selectors, inputs, outputs
│   ├── lifecycle/          # All lifecycle hooks (ngOnInit → ngOnDestroy)
│   ├── communication/      # @Input, @Output, EventEmitter, ViewChild
│   └── content-projection/ # ng-content, multi-slot projection
│
├── 02-templates/           # Template Syntax
│   ├── data-binding/       # Interpolation, property, event, two-way binding
│   ├── directives/         # *ngIf, *ngFor, [ngClass], [ngStyle], custom directives
│   ├── pipes/              # Built-in pipes + custom async/pure/impure pipes
│   └── template-ref/       # <ng-template>, <ng-container>, TemplateRef
│
├── 03-services-di/         # Services & Dependency Injection
│                           # providedIn, hierarchical DI, injection tokens
│
├── 04-routing/             # Angular Router
│   ├── guards/             # CanActivate, CanDeactivate, CanLoad
│   └── resolvers/          # Route data resolvers
│
├── 05-forms/               # Forms
│   ├── template-driven/    # ngModel, FormsModule
│   ├── reactive/           # FormBuilder, FormGroup, FormArray
│   └── custom-validators/  # Sync + async validators
│
├── 06-http/                # HttpClient
│                           # GET/POST/PUT/DELETE, interceptors, error handling
│
├── 07-rxjs/                # RxJS Operators
│                           # map, filter, switchMap, combineLatest, etc.
│
├── 08-ngrx/                # NgRx State Management
│   ├── 01-store-basics/    # Store setup, StoreModule
│   ├── 02-actions/         # createAction, createActionGroup
│   ├── 03-reducers/        # createReducer, on()
│   ├── 04-effects/         # createEffect, ofType, switchMap
│   ├── 05-selectors/       # createSelector, createFeatureSelector
│   ├── 06-entity/          # EntityAdapter, EntityState
│   ├── 07-router-store/    # RouterState integration
│   └── 08-component-store/ # Local state management
│
├── 09-advanced/            # Advanced Topics
│   ├── change-detection/   # OnPush, ChangeDetectorRef
│   ├── lazy-loading/       # Lazy modules, preloading
│   ├── signals/            # Angular Signals (v16+)
│   └── standalone/         # Standalone components (v15+)
│
└── 10-testing/             # Testing
                            # Component, service, pipe, NgRx tests
```

## 🚀 Quick Start

```bash
npm install
ng serve
# Open http://localhost:4200
```

## 📚 Topics Covered

### Angular Core
1. Components & Decorators
2. Template Syntax & Data Binding
3. Built-in & Custom Directives
4. Pipes (built-in + custom)
5. Services & Dependency Injection
6. Angular Router (guards, resolvers, lazy loading)
7. Forms (Template-driven & Reactive)
8. HttpClient & Interceptors
9. RxJS Operators
10. Change Detection (Default vs OnPush)
11. Lifecycle Hooks
12. Content Projection (ng-content)
13. Angular Signals (v16+)
14. Standalone Components (v15+)

### NgRx (Redux for Angular)
1. Store Setup & Configuration
2. Actions (createAction, createActionGroup)
3. Reducers (createReducer, on())
4. Effects (createEffect, ofType)
5. Selectors (createSelector, memoization)
6. Entity Adapter (EntityState)
7. Router Store Integration
8. Component Store (local state)
9. Store DevTools

---
*Angular 17 · NgRx 17 · TypeScript 5.3 · RxJS 7.8*