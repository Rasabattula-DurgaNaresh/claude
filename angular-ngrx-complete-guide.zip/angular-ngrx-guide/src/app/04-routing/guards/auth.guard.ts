/**
 * TOPIC 7: Route Guards
 *
 * CanActivate  — prevent entering a route
 * CanDeactivate— prevent leaving a route (unsaved changes)
 * CanLoad      — prevent loading lazy modules
 * Resolve      — pre-fetch data before activating route
 */
import { inject }           from '@angular/core';
import { CanActivateFn, CanDeactivateFn, Router } from '@angular/router';
import { AuthService }      from '../../03-services-di/todo.service';

// ── Functional Guard (Angular 14+) ────────────────────────────────────────────
export const authGuard: CanActivateFn = (route, state) => {
  const auth   = inject(AuthService);
  const router = inject(Router);

  if (auth.isLoggedIn()) {
    return true;
  }

  // Redirect to login with returnUrl
  router.navigate(['/components'], {
    queryParams: { returnUrl: state.url }
  });
  return false;
};

// ── CanDeactivate — unsaved changes guard ─────────────────────────────────────
export interface HasUnsavedChanges {
  hasUnsavedChanges(): boolean;
}

export const unsavedChangesGuard: CanDeactivateFn<HasUnsavedChanges> =
  (component) => {
    if (component.hasUnsavedChanges()) {
      return window.confirm('You have unsaved changes. Leave anyway?');
    }
    return true;
  };

// ── Role-based guard ──────────────────────────────────────────────────────────
export const roleGuard: CanActivateFn = (route) => {
  const auth  = inject(AuthService);
  const roles = route.data['roles'] as string[];

  if (!auth.isLoggedIn()) return false;

  const userRole = auth.user()?.role;
  if (roles && !roles.includes(userRole || '')) {
    console.warn('Access denied. Required roles:', roles);
    return false;
  }
  return true;
};