/**
 * Route Resolver — fetch data BEFORE route activates
 * Component receives data via ActivatedRoute.snapshot.data
 */
import { inject }    from '@angular/core';
import { ResolveFn } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { catchError, of } from 'rxjs';

export interface ResolvedData {
  users: any[];
  timestamp: string;
}

export const dataResolver: ResolveFn<ResolvedData> = (route, state) => {
  const http = inject(HttpClient);

  return http.get<any[]>('https://jsonplaceholder.typicode.com/users?_limit=3').pipe(
    // Transform + enrich the data
    catchError(() => of([]))
  ) as any;
};