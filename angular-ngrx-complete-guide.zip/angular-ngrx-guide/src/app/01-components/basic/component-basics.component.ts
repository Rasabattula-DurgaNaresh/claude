/**
 * TOPIC 1: Angular Components
 * - @Component decorator with selector, template, styles
 * - @Input() and @Output() decorators
 * - EventEmitter for parent-child communication
 * - ViewChild and ContentChild
 * - Standalone components (Angular 15+)
 */
import {
  Component, Input, Output, EventEmitter,
  ViewChild, ElementRef, ChangeDetectionStrategy,
  OnInit, signal, computed
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule }  from '@angular/forms';

// ── Child component ─────────────────────────────────────────────────────────
@Component({
  selector:   'app-user-card',
  standalone: true,
  imports:    [CommonModule],
  template: `
    <div class="card" [class.highlighted]="highlighted">
      <div class="flex justify-b items-c">
        <div>
          <h3>{{ user.name }}</h3>
          <p style="color:var(--muted); font-size:13px">{{ user.email }}</p>
        </div>
        <span class="badge" [class]="roleBadgeClass">{{ user.role }}</span>
      </div>
      <div class="mt-8 flex gap-8">
        <button class="btn btn-primary btn-sm" (click)="onSelect()">Select</button>
        <button class="btn btn-ghost btn-sm" (click)="onDelete()">Delete</button>
      </div>
    </div>
  `,
  styles: [`
    .card { padding: 16px; border: 1px solid var(--border); border-radius: 10px;
            margin-bottom: 10px; transition: all .2s; }
    .card.highlighted { border-color: var(--red); box-shadow: 0 0 0 2px rgba(221,0,49,.12); }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class UserCardComponent {
  @Input({ required: true }) user!: { id: number; name: string; email: string; role: string };
  @Input() highlighted = false;

  @Output() selected = new EventEmitter<typeof this.user>();
  @Output() deleted  = new EventEmitter<number>();

  get roleBadgeClass() {
    return { 'badge-red': this.user.role === 'admin',
             'badge-blue': this.user.role === 'user',
             'badge-green': this.user.role === 'editor' };
  }

  onSelect() { this.selected.emit(this.user); }
  onDelete() { this.deleted.emit(this.user.id); }
}

// ── Parent component ────────────────────────────────────────────────────────
@Component({
  selector:    'app-component-basics',
  standalone:  true,
  imports:     [CommonModule, FormsModule, UserCardComponent],
  templateUrl: './component-basics.component.html',
})
export class ComponentBasicsComponent implements OnInit {

  // 1. Signals for reactive state (Angular 16+)
  selectedUser = signal<{ id: number; name: string; email: string; role: string } | null>(null);
  searchTerm   = signal('');

  users = signal([
    { id: 1, name: 'Alice Johnson', email: 'alice@example.com', role: 'admin' },
    { id: 2, name: 'Bob Smith',     email: 'bob@example.com',   role: 'user'  },
    { id: 3, name: 'Carol White',   email: 'carol@example.com', role: 'editor'},
    { id: 4, name: 'Dave Brown',    email: 'dave@example.com',  role: 'user'  },
  ]);

  // Computed signal
  filteredUsers = computed(() =>
    this.users().filter(u =>
      u.name.toLowerCase().includes(this.searchTerm().toLowerCase()) ||
      u.email.toLowerCase().includes(this.searchTerm().toLowerCase())
    )
  );

  totalUsers = computed(() => this.users().length);

  // 2. ViewChild — access DOM element or child component
  @ViewChild('searchInput') searchInput!: ElementRef<HTMLInputElement>;

  ngOnInit() {
    console.log('ComponentBasicsComponent initialized');
  }

  onUserSelected(user: typeof this.users._rawValue[0]) {
    this.selectedUser.set(user);
  }

  onUserDeleted(id: number) {
    this.users.update(list => list.filter(u => u.id !== id));
    if (this.selectedUser()?.id === id) this.selectedUser.set(null);
  }

  addUser() {
    const newId = Date.now();
    this.users.update(list => [...list, {
      id: newId, name: `User ${newId % 1000}`,
      email: `user${newId % 1000}@example.com`, role: 'user'
    }]);
  }

  focusSearch() { this.searchInput?.nativeElement.focus(); }
}