/**
 * TOPIC 2: Angular Lifecycle Hooks
 * All 8 lifecycle hooks in order:
 * constructor → ngOnChanges → ngOnInit → ngDoCheck →
 * ngAfterContentInit → ngAfterContentChecked →
 * ngAfterViewInit → ngAfterViewChecked → ngOnDestroy
 */
import {
  Component, Input, OnInit, OnDestroy, OnChanges,
  AfterViewInit, AfterViewChecked, AfterContentInit,
  AfterContentChecked, DoCheck, SimpleChanges,
  ViewChild, ElementRef, ChangeDetectorRef, signal
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule }  from '@angular/forms';
import { interval, Subscription } from 'rxjs';

// Child to demonstrate OnChanges
@Component({
  selector:   'app-lifecycle-child',
  standalone: true,
  imports:    [CommonModule],
  template: `
    <div class="card" style="border-color: var(--blue)">
      <p><strong>Child receives:</strong> {{ value }}</p>
      <p style="font-size:12px; color:var(--muted)">Changes count: {{ changeCount }}</p>
    </div>
  `,
})
export class LifecycleChildComponent implements OnChanges {
  @Input() value = '';
  changeCount = 0;

  ngOnChanges(changes: SimpleChanges) {
    this.changeCount++;
    console.log('ngOnChanges:', changes);
    // changes['value'] = { currentValue, previousValue, firstChange, isFirstChange() }
  }
}

// Parent demonstrating all lifecycle hooks
@Component({
  selector:    'app-lifecycle',
  standalone:  true,
  imports:     [CommonModule, FormsModule, LifecycleChildComponent],
  templateUrl: './lifecycle.component.html',
})
export class LifecycleComponent
  implements OnInit, OnDestroy, OnChanges, DoCheck,
             AfterViewInit, AfterViewChecked,
             AfterContentInit, AfterContentChecked {

  @ViewChild('counterEl') counterEl!: ElementRef;
  @Input() externalValue = 'initial';

  logs     = signal<string[]>([]);
  counter  = signal(0);
  inputVal = signal('hello');
  showChild = signal(true);

  private subscription!: Subscription;
  private readonly MAX_LOGS = 20;

  constructor(private cdr: ChangeDetectorRef) {
    this.log('constructor — synchronous, avoid side effects here');
  }

  // 1. ngOnChanges — called when @Input() values change
  ngOnChanges(changes: SimpleChanges): void {
    this.log(`ngOnChanges: ${JSON.stringify(Object.keys(changes))}`);
  }

  // 2. ngOnInit — component initialized, @Input values set
  ngOnInit(): void {
    this.log('ngOnInit — perfect for API calls, subscriptions');
    this.subscription = interval(5000).subscribe(() => {
      this.log('interval tick');
    });
  }

  // 3. ngDoCheck — every change detection cycle (use carefully!)
  ngDoCheck(): void {
    // this.log('ngDoCheck'); // Too noisy — commented out
  }

  // 4. ngAfterContentInit — ng-content projected content ready (once)
  ngAfterContentInit(): void {
    this.log('ngAfterContentInit — projected content initialized');
  }

  // 5. ngAfterContentChecked — after ng-content change detection (every cycle)
  ngAfterContentChecked(): void {
    // this.log('ngAfterContentChecked'); // Very frequent
  }

  // 6. ngAfterViewInit — component's view + child views ready (once)
  ngAfterViewInit(): void {
    this.log('ngAfterViewInit — ViewChild references are now available');
    // Safe to access this.counterEl here
    if (this.counterEl) {
      this.counterEl.nativeElement.style.color = '#dd0031';
    }
    // Avoid ExpressionChangedAfterItHasBeenCheckedError:
    this.cdr.detectChanges();
  }

  // 7. ngAfterViewChecked — after view's change detection (every cycle)
  ngAfterViewChecked(): void {
    // Runs very frequently — keep logic minimal
  }

  // 8. ngOnDestroy — cleanup BEFORE component is destroyed
  ngOnDestroy(): void {
    this.log('ngOnDestroy — ALWAYS unsubscribe here!');
    this.subscription?.unsubscribe();  // Prevent memory leaks!
  }

  increment() { this.counter.update(c => c + 1); }

  private log(msg: string) {
    const time = new Date().toLocaleTimeString();
    this.logs.update(l => [`[${time}] ${msg}`, ...l].slice(0, this.MAX_LOGS));
  }

  clearLogs() { this.logs.set([]); }
}