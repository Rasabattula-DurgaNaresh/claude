/**
 * TOPIC 3: Angular Template Syntax & Data Binding
 *
 * 1. Interpolation:      {{ expression }}
 * 2. Property binding:   [property]="expression"
 * 3. Event binding:      (event)="handler($event)"
 * 4. Two-way binding:    [(ngModel)]="property"
 * 5. Attribute binding:  [attr.aria-label]="..."
 * 6. Class binding:      [class.active]="bool" or [ngClass]
 * 7. Style binding:      [style.color]="..." or [ngStyle]
 * 8. Template reference: #myRef
 */
import { Component, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule }  from '@angular/forms';

@Component({
  selector:    'app-data-binding',
  standalone:  true,
  imports:     [CommonModule, FormsModule],
  templateUrl: './data-binding.component.html',
})
export class DataBindingComponent {
  // State
  message   = signal('Hello, Angular!');
  count     = signal(0);
  isActive  = signal(false);
  color     = signal('#dd0031');
  fontSize  = signal(16);
  imageUrl  = signal('https://angular.io/assets/images/logos/angular/angular.svg');
  inputText = signal('');

  // Computed
  doubleCount = computed(() => this.count() * 2);
  upperMsg    = computed(() => this.message().toUpperCase());
  wordCount   = computed(() => this.inputText().split(' ').filter(Boolean).length);

  // For two-way binding demo
  twoWayValue = 'edit me';

  handleInput(event: Event) {
    this.inputText.set((event.target as HTMLInputElement).value);
  }

  handleClick(event: MouseEvent) {
    this.count.update(c => c + 1);
    console.log('Clicked at:', event.clientX, event.clientY);
  }

  handleKeydown(event: KeyboardEvent) {
    if (event.key === 'Enter') {
      console.log('Enter pressed, value:', (event.target as HTMLInputElement).value);
    }
  }

  getButtonClass() {
    return {
      'btn-primary': this.isActive(),
      'btn-ghost':   !this.isActive(),
    };
  }

  getProgressStyle() {
    const pct = Math.min((this.count() / 10) * 100, 100);
    return { width: pct + '%', background: pct >= 100 ? 'var(--green)' : 'var(--red)' };
  }
}