/**
 * TOPIC 5: Angular Pipes
 *
 * Built-in: date, currency, number, percent, uppercase/lowercase,
 *           titlecase, json, slice, async, keyvalue, i18nSelect
 *
 * Custom: Pure (default) — only re-runs when input changes
 *         Impure (pure: false) — re-runs every CD cycle
 *         Async — transforms Observable/Promise
 */
import { Component, Pipe, PipeTransform, signal } from '@angular/core';
import { CommonModule, DatePipe, CurrencyPipe }   from '@angular/common';
import { Observable, interval, map }              from 'rxjs';

// ── 1. Custom Pure Pipe — File size formatter ─────────────────────────────────
@Pipe({ name: 'fileSize', standalone: true })
export class FileSizePipe implements PipeTransform {
  transform(bytes: number, precision = 1): string {
    if (bytes === 0) return '0 B';
    const units = ['B','KB','MB','GB','TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return `${(bytes / Math.pow(1024, i)).toFixed(precision)} ${units[i]}`;
  }
}

// ── 2. Custom Pure Pipe — Truncate text ──────────────────────────────────────
@Pipe({ name: 'truncate', standalone: true })
export class TruncatePipe implements PipeTransform {
  transform(value: string, limit = 30, suffix = '...'): string {
    return value.length <= limit ? value : value.slice(0, limit) + suffix;
  }
}

// ── 3. Custom Impure Pipe — Filter array ─────────────────────────────────────
@Pipe({ name: 'filterBy', standalone: true, pure: false })  // pure: false = impure
export class FilterByPipe implements PipeTransform {
  transform<T>(arr: T[], key: keyof T, term: string): T[] {
    if (!term) return arr;
    return arr.filter(i => String(i[key]).toLowerCase().includes(term.toLowerCase()));
  }
}

// ── 4. Custom Async Pipe — Countdown ─────────────────────────────────────────
@Pipe({ name: 'countdown', standalone: true })
export class CountdownPipe implements PipeTransform {
  transform(seconds: number): Observable<number> {
    return interval(1000).pipe(map(i => Math.max(0, seconds - i - 1)));
  }
}

@Component({
  selector:    'app-pipes',
  standalone:  true,
  imports:     [CommonModule, FileSizePipe, TruncatePipe, FilterByPipe, CountdownPipe],
  templateUrl: './pipes.component.html',
})
export class PipesComponent {
  now          = new Date();
  price        = 1234567.89;
  ratio        = 0.7256;
  longText     = 'Angular pipes transform values in your template without changing the component state.';
  fileSize     = 1_572_864;  // ~1.5 MB
  searchTerm   = signal('');

  // Async pipe demo
  clock$: Observable<Date> = interval(1000).pipe(map(() => new Date()));

  products = [
    { id: 1, name: 'Angular Book',    price: 49.99,  category: 'books'    },
    { id: 2, name: 'NgRx Course',     price: 129.00, category: 'courses'  },
    { id: 3, name: 'TypeScript Guide',price: 39.99,  category: 'books'    },
    { id: 4, name: 'RxJS Handbook',   price: 44.99,  category: 'books'    },
    { id: 5, name: 'Angular CLI',     price: 0,       category: 'tools'    },
  ];

  user = { gender: 'female' };
  genderMap = { male: 'he/him', female: 'she/her', other: 'they/them' };
}