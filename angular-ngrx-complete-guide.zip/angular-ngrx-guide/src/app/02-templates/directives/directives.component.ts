/**
 * TOPIC 4: Angular Directives
 *
 * Structural Directives (modify DOM structure):
 *   @if / @else / @else if  (Angular 17 — new control flow)
 *   @for / @empty           (Angular 17)
 *   @switch / @case         (Angular 17)
 *   *ngIf, *ngFor, *ngSwitch (legacy)
 *
 * Attribute Directives (modify appearance/behavior):
 *   [ngClass], [ngStyle]
 *   Custom attribute directives
 */
import {
  Component, Directive, ElementRef, HostListener,
  HostBinding, Input, signal, computed
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule }  from '@angular/forms';

// ── Custom Attribute Directive ────────────────────────────────────────────────
@Directive({
  selector:   '[appHighlight]',
  standalone: true,
})
export class HighlightDirective {
  @Input('appHighlight') highlightColor = '#fef3c7';
  @Input() defaultColor = 'transparent';

  @HostBinding('style.background-color') backgroundColor = this.defaultColor;
  @HostBinding('style.transition') transition = 'background-color .2s';
  @HostBinding('style.padding')    padding    = '2px 4px';
  @HostBinding('style.border-radius') borderRadius = '4px';

  @HostListener('mouseenter') onMouseEnter() {
    this.backgroundColor = this.highlightColor;
  }
  @HostListener('mouseleave') onMouseLeave() {
    this.backgroundColor = this.defaultColor;
  }
}

// ── Custom Structural Directive ───────────────────────────────────────────────
// (Modern approach uses built-in control flow; old approach shown for reference)

@Component({
  selector:    'app-directives',
  standalone:  true,
  imports:     [CommonModule, FormsModule, HighlightDirective],
  templateUrl: './directives.component.html',
})
export class DirectivesComponent {
  showPanel  = signal(true);
  currentTab = signal<'A' | 'B' | 'C'>('A');
  status     = signal<'loading' | 'success' | 'error'>('success');

  items = signal([
    { id: 1, name: 'Angular',    tags: ['framework', 'typescript'], stars: 92000 },
    { id: 2, name: 'React',      tags: ['library',   'javascript'], stars: 216000 },
    { id: 3, name: 'Vue',        tags: ['framework', 'javascript'], stars: 207000 },
    { id: 4, name: 'Svelte',     tags: ['compiler',  'javascript'], stars: 76000  },
    { id: 5, name: 'NgRx',       tags: ['redux',     'typescript'], stars: 8000   },
  ]);

  filterTerm = signal('');

  filteredItems = computed(() =>
    this.items().filter(i =>
      i.name.toLowerCase().includes(this.filterTerm().toLowerCase())));

  addItem() {
    const id = Date.now();
    this.items.update(arr => [...arr, {
      id, name: `Library ${arr.length + 1}`, tags: ['new'], stars: 0
    }]);
  }
  removeItem(id: number) { this.items.update(arr => arr.filter(i => i.id !== id)); }
  trackById(index: number, item: { id: number }) { return item.id; }
}