import { ApplicationConfig, importProvidersFrom } from '@angular/core';
import { provideRouter, withPreloading, PreloadAllModules } from '@angular/router';
import { provideHttpClient, withInterceptors }              from '@angular/common/http';
import { provideAnimations }                                from '@angular/platform-browser/animations';
import { provideStore }                                      from '@ngrx/store';
import { provideEffects }                                    from '@ngrx/effects';
import { provideStoreDevtools }                              from '@ngrx/store-devtools';
import { provideRouterStore, routerReducer }                 from '@ngrx/router-store';

import { routes }             from './app.routes';
import { counterReducer }     from './08-ngrx/03-reducers/counter.reducer';
import { todosReducer }       from './08-ngrx/03-reducers/todos.reducer';
import { usersReducer }       from './08-ngrx/03-reducers/users.reducer';
import { CounterEffects }     from './08-ngrx/04-effects/counter.effects';
import { UsersEffects }       from './08-ngrx/04-effects/users.effects';
import { authInterceptor }    from './06-http/auth.interceptor';
import { loggingInterceptor } from './06-http/logging.interceptor';

export const appConfig: ApplicationConfig = {
  providers: [
    // Router
    provideRouter(routes, withPreloading(PreloadAllModules)),

    // HTTP + Interceptors
    provideHttpClient(withInterceptors([authInterceptor, loggingInterceptor])),

    // Animations
    provideAnimations(),

    // NgRx Store
    provideStore({
      counter: counterReducer,
      todos:   todosReducer,
      users:   usersReducer,
      router:  routerReducer,
    }),

    // NgRx Effects
    provideEffects([CounterEffects, UsersEffects]),

    // NgRx DevTools (Chrome extension)
    provideStoreDevtools({
      maxAge: 25,
      logOnly: false,
      autoPause: true,
      trace: false,
      traceLimit: 75,
    }),

    // NgRx Router Store
    provideRouterStore(),
  ],
};