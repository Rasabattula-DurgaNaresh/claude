import { Routes } from '@angular/router';
import { authGuard }    from './04-routing/guards/auth.guard';
import { dataResolver } from './04-routing/resolvers/data.resolver';

export const routes: Routes = [
  { path: '', redirectTo: 'components', pathMatch: 'full' },

  // Eagerly loaded
  {
    path: 'components',
    loadComponent: () =>
      import('./01-components/basic/component-basics.component')
        .then(m => m.ComponentBasicsComponent),
    data: { title: 'Components' },
  },
  {
    path: 'lifecycle',
    loadComponent: () =>
      import('./01-components/lifecycle/lifecycle.component')
        .then(m => m.LifecycleComponent),
  },
  {
    path: 'templates',
    loadComponent: () =>
      import('./02-templates/data-binding/data-binding.component')
        .then(m => m.DataBindingComponent),
  },
  {
    path: 'directives',
    loadComponent: () =>
      import('./02-templates/directives/directives.component')
        .then(m => m.DirectivesComponent),
  },
  {
    path: 'pipes',
    loadComponent: () =>
      import('./02-templates/pipes/pipes.component')
        .then(m => m.PipesComponent),
  },
  {
    path: 'services',
    loadComponent: () =>
      import('./03-services-di/services.component')
        .then(m => m.ServicesComponent),
  },
  {
    path: 'forms',
    loadComponent: () =>
      import('./05-forms/reactive/reactive-forms.component')
        .then(m => m.ReactiveFormsComponent),
  },
  {
    path: 'rxjs',
    loadComponent: () =>
      import('./07-rxjs/rxjs-operators.component')
        .then(m => m.RxjsOperatorsComponent),
  },
  // NgRx (protected)
  {
    path: 'ngrx',
    canActivate: [authGuard],
    resolve: { data: dataResolver },
    loadComponent: () =>
      import('./08-ngrx/01-store-basics/store-basics.component')
        .then(m => m.StoreBasicsComponent),
  },
  {
    path: 'effects',
    loadComponent: () =>
      import('./08-ngrx/04-effects/effects-demo.component')
        .then(m => m.EffectsDemoComponent),
  },
  {
    path: 'signals',
    loadComponent: () =>
      import('./09-advanced/signals/signals.component')
        .then(m => m.SignalsComponent),
  },
  // Lazy-loaded feature module
  {
    path: 'users',
    loadChildren: () =>
      import('./09-advanced/lazy-loading/users.routes')
        .then(m => m.usersRoutes),
  },
  { path: '**', redirectTo: 'components' },
];