/**
 * TOPIC 13: Testing Angular + NgRx
 * Component tests with TestBed
 * Service tests with TestBed
 * NgRx reducer tests (pure functions)
 * NgRx selector tests
 * NgRx effect tests
 */
import { TestBed }         from '@angular/core/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { counterReducer, initialCounterState } from '../08-ngrx/03-reducers/counter.reducer';
import { CounterActions }  from '../08-ngrx/02-actions/counter.actions';
import { selectCounterValue, selectDoubleCount } from '../08-ngrx/05-selectors/counter.selectors';

// ── 1. Reducer Tests (pure functions — easy!) ─────────────────────────────────
describe('Counter Reducer', () => {
  const initial = initialCounterState;

  it('should return initial state for unknown action', () => {
    const state = counterReducer(undefined, { type: '@@INIT' } as any);
    expect(state).toEqual(initial);
  });

  it('should increment by step', () => {
    const state = counterReducer({ ...initial, step: 2 }, CounterActions.increment());
    expect(state.value).toBe(2);
  });

  it('should decrement by step', () => {
    const state = counterReducer({ ...initial, value: 10, step: 3 }, CounterActions.decrement());
    expect(state.value).toBe(7);
  });

  it('should increment by amount', () => {
    const state = counterReducer(initial, CounterActions.incrementBy({ amount: 15 }));
    expect(state.value).toBe(15);
  });

  it('should reset to initial state', () => {
    const state = counterReducer({ ...initial, value: 99 }, CounterActions.reset());
    expect(state.value).toBe(0);
    expect(state.history).toEqual([]);
  });

  it('should update step', () => {
    const state = counterReducer(initial, CounterActions.setStep({ step: 5 }));
    expect(state.step).toBe(5);
  });

  it('should track history', () => {
    let state = counterReducer(initial, CounterActions.increment());
    state = counterReducer(state, CounterActions.increment());
    expect(state.history).toHaveSize(2);
    expect(state.history[1].value).toBe(2);
  });
});

// ── 2. Selector Tests ────────────────────────────────────────────────────────
describe('Counter Selectors', () => {
  const mockState = {
    counter: { value: 10, step: 2, history: [] }
  };

  it('selectCounterValue should return value', () => {
    const value = selectCounterValue.projector(mockState.counter);
    expect(value).toBe(10);
  });

  it('selectDoubleCount should return doubled value', () => {
    const doubled = selectDoubleCount.projector(10);
    expect(doubled).toBe(20);
  });
});

// ── 3. Component with MockStore ───────────────────────────────────────────────
describe('NgRx MockStore', () => {
  let store: MockStore;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      providers: [
        provideMockStore({
          initialState: {
            counter: initialCounterState
          }
        })
      ]
    }).compileComponents();

    store = TestBed.inject(MockStore);
  });

  it('should dispatch increment action', () => {
    const dispatchSpy = spyOn(store, 'dispatch');
    store.dispatch(CounterActions.increment());
    expect(dispatchSpy).toHaveBeenCalledWith(CounterActions.increment());
  });

  it('should override selector value', () => {
    const mockSelector = store.overrideSelector(selectCounterValue, 42);

    let selectorValue: number | undefined;
    store.select(selectCounterValue).subscribe(v => selectorValue = v);
    expect(selectorValue).toBe(42);

    mockSelector.setResult(100);
    store.refreshState();
    expect(selectorValue).toBe(100);
  });
});

// ── 4. Service Test ───────────────────────────────────────────────────────────
// (TodoService using signals)
import { TodoService } from '../03-services-di/todo.service';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';

describe('TodoService', () => {
  let service: TodoService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        TodoService,
        provideHttpClient(),
        provideHttpClientTesting(),
      ]
    });
    service = TestBed.inject(TodoService);
  });

  it('should add a todo', () => {
    service.addTodo('Test task');
    expect(service.todos()).toHaveSize(1);
    expect(service.todos()[0].title).toBe('Test task');
    expect(service.todos()[0].completed).toBeFalse();
  });

  it('should toggle a todo', () => {
    service.addTodo('Toggle me');
    const id = service.todos()[0].id;
    service.toggleTodo(id);
    expect(service.todos()[0].completed).toBeTrue();
    service.toggleTodo(id);
    expect(service.todos()[0].completed).toBeFalse();
  });

  it('should delete a todo', () => {
    service.addTodo('Delete me');
    const id = service.todos()[0].id;
    service.deleteTodo(id);
    expect(service.todos()).toHaveSize(0);
  });

  it('should compute count', () => {
    expect(service.count()).toBe(0);
    service.addTodo('Task 1');
    service.addTodo('Task 2');
    expect(service.count()).toBe(2);
  });
});