/**
 * TOPIC 6: Services & Dependency Injection
 *
 * providedIn: 'root' — singleton for entire app
 * providedIn: 'any'  — new instance per lazy-loaded module
 * Component-level — new instance per component
 * InjectionToken   — inject primitives & configs
 */
import { Injectable, InjectionToken, signal, computed } from '@angular/core';
import { HttpClient }  from '@angular/common/http';
import { Observable, BehaviorSubject, tap, catchError, throwError } from 'rxjs';

// ── InjectionToken — inject primitive values / configs ────────────────────────
export const API_URL_TOKEN = new InjectionToken<string>('API_URL', {
  providedIn: 'root',
  factory:    () => 'https://jsonplaceholder.typicode.com',
});

export const APP_CONFIG_TOKEN = new InjectionToken<{ debug: boolean; version: string }>('APP_CONFIG', {
  providedIn: 'root',
  factory:    () => ({ debug: true, version: '1.0.0' }),
});

export interface Todo {
  id:        number;
  title:     string;
  completed: boolean;
  userId:    number;
}

// ── Primary Service — providedIn: 'root' = singleton ─────────────────────────
@Injectable({ providedIn: 'root' })
export class TodoService {
  // Private state using signals
  private _todos   = signal<Todo[]>([]);
  private _loading = signal(false);
  private _error   = signal<string | null>(null);

  // Public read-only state
  readonly todos    = this._todos.asReadonly();
  readonly loading  = this._loading.asReadonly();
  readonly error    = this._error.asReadonly();
  readonly count    = computed(() => this._todos().length);
  readonly doneCount = computed(() => this._todos().filter(t => t.completed).length);

  constructor(private http: HttpClient) {}

  loadTodos(limit = 5): Observable<Todo[]> {
    this._loading.set(true);
    this._error.set(null);

    return this.http.get<Todo[]>(`https://jsonplaceholder.typicode.com/todos?_limit=${limit}`).pipe(
      tap(todos => {
        this._todos.set(todos);
        this._loading.set(false);
      }),
      catchError(err => {
        this._error.set(err.message);
        this._loading.set(false);
        return throwError(() => err);
      })
    );
  }

  addTodo(title: string): void {
    const newTodo: Todo = {
      id:        Date.now(),
      title,
      completed: false,
      userId:    1,
    };
    this._todos.update(list => [...list, newTodo]);
  }

  toggleTodo(id: number): void {
    this._todos.update(list =>
      list.map(t => t.id === id ? { ...t, completed: !t.completed } : t)
    );
  }

  deleteTodo(id: number): void {
    this._todos.update(list => list.filter(t => t.id !== id));
  }

  clearCompleted(): void {
    this._todos.update(list => list.filter(t => !t.completed));
  }
}

// ── Logger Service — can be injected anywhere ─────────────────────────────────
@Injectable({ providedIn: 'root' })
export class LoggerService {
  private logs: string[] = [];

  log(message: string, level: 'info' | 'warn' | 'error' = 'info') {
    const entry = `[${new Date().toISOString()}] [${level.toUpperCase()}] ${message}`;
    this.logs.push(entry);
    console[level](entry);
  }

  getLogs() { return [...this.logs]; }
  clearLogs() { this.logs = []; }
}

// ── Auth Service — demonstrate service injection into service ─────────────────
@Injectable({ providedIn: 'root' })
export class AuthService {
  private currentUser = signal<{ name: string; role: string } | null>(null);

  readonly user      = this.currentUser.asReadonly();
  readonly isLoggedIn = computed(() => this.currentUser() !== null);

  constructor(private logger: LoggerService) {}  // Service injected into service!

  login(username: string): void {
    this.currentUser.set({ name: username, role: 'admin' });
    this.logger.log(`User ${username} logged in`);
  }

  logout(): void {
    this.logger.log(`User ${this.currentUser()?.name} logged out`);
    this.currentUser.set(null);
  }
}