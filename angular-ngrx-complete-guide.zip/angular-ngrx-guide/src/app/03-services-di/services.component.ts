import {
  Component, OnInit, OnDestroy, Inject, inject, signal
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule }  from '@angular/forms';
import { TodoService, AuthService, LoggerService, Todo,
         API_URL_TOKEN, APP_CONFIG_TOKEN } from './todo.service';
import { Subscription } from 'rxjs';

@Component({
  selector:    'app-services',
  standalone:  true,
  imports:     [CommonModule, FormsModule],
  templateUrl: './services.component.html',
})
export class ServicesComponent implements OnInit, OnDestroy {
  // Modern inject() function (Angular 14+)
  todoService  = inject(TodoService);
  authService  = inject(AuthService);
  loggerService = inject(LoggerService);

  // Inject InjectionToken
  @Inject(API_URL_TOKEN) apiUrl = inject(API_URL_TOKEN);
  appConfig = inject(APP_CONFIG_TOKEN);

  newTitle   = signal('');
  username   = signal('');
  logs       = signal<string[]>([]);
  private sub!: Subscription;

  ngOnInit() {
    this.loadTodos();
  }

  loadTodos() {
    this.sub = this.todoService.loadTodos(5).subscribe({
      next:  () => this.logs.update(l => [...l, 'Todos loaded successfully']),
      error: (e) => this.logs.update(l => [...l, `Error: ${e.message}`]),
    });
  }

  addTodo() {
    if (!this.newTitle().trim()) return;
    this.todoService.addTodo(this.newTitle());
    this.newTitle.set('');
  }

  login()  { this.authService.login(this.username()); }
  logout() { this.authService.logout(); }

  ngOnDestroy() { this.sub?.unsubscribe(); }
}