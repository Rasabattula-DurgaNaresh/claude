/**
 * NgRx TOPIC 6: Entity Adapter
 * EntityAdapter manages collections of entities efficiently.
 * Provides built-in CRUD operations: addOne, addMany, updateOne,
 * removeOne, upsertOne, setAll, etc.
 * EntityState = { ids: [], entities: {} }
 */
import { createEntityAdapter, EntityAdapter, EntityState } from '@ngrx/entity';
import { createAction, createReducer, createSelector,
         createFeatureSelector, on, props, emptyProps } from '@ngrx/store';

// ── Entity interface ──────────────────────────────────────────────────────────
export interface Product {
  id:       number;
  name:     string;
  price:    number;
  category: string;
  inStock:  boolean;
}

// ── Actions ───────────────────────────────────────────────────────────────────
export const loadProducts    = createAction('[Products] Load');
export const loadSuccess     = createAction('[Products] Load Success', props<{ products: Product[] }>());
export const addProduct      = createAction('[Products] Add',    props<{ product: Product }>());
export const updateProduct   = createAction('[Products] Update', props<{ id: number; changes: Partial<Product> }>());
export const deleteProduct   = createAction('[Products] Delete', props<{ id: number }>());
export const selectProduct   = createAction('[Products] Select', props<{ id: number | null }>());

// ── Entity Adapter — manages the normalized state ─────────────────────────────
export const productAdapter: EntityAdapter<Product> = createEntityAdapter<Product>({
  selectId:    p => p.id,                    // ID field
  sortComparer: (a, b) => a.name.localeCompare(b.name), // Sort function
});

// ── State with entity + extra fields ─────────────────────────────────────────
export interface ProductsState extends EntityState<Product> {
  // Extra fields beyond the entity collection
  selectedId: number | null;
  loading:    boolean;
  error:      string | null;
}

export const initialState: ProductsState = productAdapter.getInitialState({
  selectedId: null,
  loading:    false,
  error:      null,
});

// ── Reducer using adapter methods ─────────────────────────────────────────────
export const productsReducer = createReducer(
  initialState,

  on(loadProducts,  (state)         => ({ ...state, loading: true })),
  on(loadSuccess,   (state, { products }) =>
    productAdapter.setAll(products, { ...state, loading: false })
  ),

  // Adapter CRUD methods
  on(addProduct,    (state, { product })         => productAdapter.addOne(product, state)),
  on(updateProduct, (state, { id, changes })     => productAdapter.updateOne({ id, changes }, state)),
  on(deleteProduct, (state, { id })              => productAdapter.removeOne(id, state)),
  on(selectProduct, (state, { id })              => ({ ...state, selectedId: id })),
);

// ── Selectors from adapter ────────────────────────────────────────────────────
const selectProductsFeature = createFeatureSelector<ProductsState>('products');

// Adapter provides selectAll, selectEntities, selectIds, selectTotal
export const {
  selectAll:      selectAllProducts,
  selectEntities: selectProductEntities,
  selectIds:      selectProductIds,
  selectTotal:    selectProductTotal,
} = productAdapter.getSelectors(selectProductsFeature);

export const selectSelectedProduct = createSelector(
  selectProductEntities,
  selectProductsFeature,
  (entities, state) => state.selectedId ? entities[state.selectedId] : null
);

export const selectByCategory = (category: string) => createSelector(
  selectAllProducts,
  products => products.filter(p => p.category === category)
);