import { createReducer, on }  from '@ngrx/store';
import { TodosActions, Todo } from '../02-actions/todos.actions';

export interface TodosState {
  items:    Todo[];
  filter:   'all' | 'active' | 'done';
  loading:  boolean;
  error:    string | null;
  nextId:   number;
}

export const initialTodosState: TodosState = {
  items:   [
    { id: 1, title: 'Learn NgRx Actions',   completed: true,  priority: 'high',   createdAt: new Date().toISOString() },
    { id: 2, title: 'Learn NgRx Reducers',  completed: false, priority: 'high',   createdAt: new Date().toISOString() },
    { id: 3, title: 'Learn NgRx Effects',   completed: false, priority: 'medium', createdAt: new Date().toISOString() },
    { id: 4, title: 'Learn NgRx Selectors', completed: false, priority: 'medium', createdAt: new Date().toISOString() },
  ],
  filter:  'all',
  loading: false,
  error:   null,
  nextId:  5,
};

export const todosReducer = createReducer(
  initialTodosState,

  // Add a new todo
  on(TodosActions.addTodo, (state, { title, priority }) => ({
    ...state,
    items:  [...state.items, {
      id: state.nextId, title, priority,
      completed: false, createdAt: new Date().toISOString(),
    }],
    nextId: state.nextId + 1,
  })),

  // Toggle completed status
  on(TodosActions.toggleTodo, (state, { id }) => ({
    ...state,
    items: state.items.map(todo =>
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    ),
  })),

  // Delete a todo
  on(TodosActions.deleteTodo, (state, { id }) => ({
    ...state,
    items: state.items.filter(todo => todo.id !== id),
  })),

  // Partial update
  on(TodosActions.updateTodo, (state, { id, changes }) => ({
    ...state,
    items: state.items.map(todo =>
      todo.id === id ? { ...todo, ...changes } : todo
    ),
  })),

  on(TodosActions.clearDone,  (state) => ({
    ...state, items: state.items.filter(t => !t.completed),
  })),

  on(TodosActions.setFilter,  (state, { filter }) => ({ ...state, filter })),

  // API — Load
  on(TodosActions.loadTodos, (state)         => ({ ...state, loading: true,  error: null })),
  on(TodosActions.loadTodosSuccess, (state, { todos }) => ({
    ...state, loading: false, items: todos,
  })),
  on(TodosActions.loadTodosFailure, (state, { error }) => ({
    ...state, loading: false, error,
  })),
);