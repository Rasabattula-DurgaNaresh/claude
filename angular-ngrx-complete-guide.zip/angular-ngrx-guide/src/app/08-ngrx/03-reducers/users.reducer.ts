import { createReducer, on } from '@ngrx/store';
import { UsersActions, User } from '../02-actions/users.actions';

export interface UsersState {
  users:          User[];
  selectedUserId: number | null;
  loading:        boolean;
  error:          string | null;
}

export const initialUsersState: UsersState = {
  users:          [],
  selectedUserId: null,
  loading:        false,
  error:          null,
};

export const usersReducer = createReducer(
  initialUsersState,
  on(UsersActions.loadUsers,         (s)      => ({ ...s, loading: true, error: null })),
  on(UsersActions.loadUsersSuccess,  (s, { users }) => ({ ...s, loading: false, users })),
  on(UsersActions.loadUsersFailure,  (s, { error }) => ({ ...s, loading: false, error })),
  on(UsersActions.selectUser,        (s, { userId }) => ({ ...s, selectedUserId: userId })),
  on(UsersActions.clearSelection,    (s)      => ({ ...s, selectedUserId: null })),
);