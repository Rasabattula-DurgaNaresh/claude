/**
 * NgRx TOPIC 2: Reducers
 * Reducers are pure functions: (state, action) => newState
 * createReducer() + on() pattern
 * Immer-like syntax for complex objects
 */
import { createReducer, on } from '@ngrx/store';
import { CounterActions }    from '../02-actions/counter.actions';

export interface CounterState {
  value:   number;
  step:    number;
  history: { action: string; value: number }[];
}

export const initialCounterState: CounterState = {
  value:   0,
  step:    1,
  history: [],
};

export const counterReducer = createReducer(
  initialCounterState,

  // on() handles an action — return NEW state (immutable!)
  on(CounterActions.increment, (state) => ({
    ...state,
    value:   state.value + state.step,
    history: [...state.history, { action: 'increment', value: state.value + state.step }].slice(-10),
  })),

  on(CounterActions.decrement, (state) => ({
    ...state,
    value:   state.value - state.step,
    history: [...state.history, { action: 'decrement', value: state.value - state.step }].slice(-10),
  })),

  on(CounterActions.reset, (_state) => ({
    ...initialCounterState,  // Return fresh initial state
  })),

  on(CounterActions.incrementBy, (state, { amount }) => ({
    ...state,
    value:   state.value + amount,
    history: [...state.history, { action: `+${amount}`, value: state.value + amount }].slice(-10),
  })),

  on(CounterActions.setStep, (state, { step }) => ({
    ...state,
    step,
  })),
);