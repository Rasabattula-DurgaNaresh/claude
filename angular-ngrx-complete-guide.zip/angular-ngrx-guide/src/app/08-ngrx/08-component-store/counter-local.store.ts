/**
 * NgRx TOPIC 7: ComponentStore — Local State Management
 * For component-level state that doesn't need to be in global store.
 * @ngrx/component-store
 */
import { Injectable }       from '@angular/core';
import { ComponentStore }   from '@ngrx/component-store';
import { Observable }       from 'rxjs';
import { tap, switchMap, catchError } from 'rxjs/operators';
import { EMPTY }            from 'rxjs';
import { HttpClient }       from '@angular/common/http';
import { inject }           from '@angular/core';

export interface CounterLocalState {
  count:    number;
  step:     number;
  loading:  boolean;
  history:  number[];
}

@Injectable()  // NOT 'root' — scoped to component
export class CounterLocalStore extends ComponentStore<CounterLocalState> {
  private http = inject(HttpClient);

  constructor() {
    super({ count: 0, step: 1, loading: false, history: [] });
  }

  // ── Selectors ─────────────────────────────────────────────────────────────
  readonly count$   = this.select(s => s.count);
  readonly step$    = this.select(s => s.step);
  readonly loading$ = this.select(s => s.loading);
  readonly history$ = this.select(s => s.history);
  readonly double$  = this.select(this.count$, c => c * 2);

  // Combined selector
  readonly vm$ = this.select({
    count:   this.count$,
    step:    this.step$,
    loading: this.loading$,
    double:  this.double$,
  });

  // ── Updaters (synchronous) ────────────────────────────────────────────────
  readonly increment = this.updater((state) => ({
    ...state,
    count:   state.count + state.step,
    history: [...state.history, state.count + state.step].slice(-5),
  }));

  readonly decrement = this.updater((state) => ({
    ...state,
    count:   state.count - state.step,
    history: [...state.history, state.count - state.step].slice(-5),
  }));

  readonly setStep = this.updater((state, step: number) => ({ ...state, step }));

  readonly reset = this.updater((state) => ({
    count: 0, step: state.step, loading: false, history: [],
  }));

  // ── Effects (asynchronous) ────────────────────────────────────────────────
  readonly loadRemoteCount = this.effect((trigger$: Observable<void>) =>
    trigger$.pipe(
      tap(() => this.patchState({ loading: true })),
      switchMap(() =>
        this.http.get<any>('https://jsonplaceholder.typicode.com/posts/1').pipe(
          tap(post => {
            this.patchState({ count: post.id * 10, loading: false });
          }),
          catchError(() => {
            this.patchState({ loading: false });
            return EMPTY;
          })
        )
      )
    )
  );
}