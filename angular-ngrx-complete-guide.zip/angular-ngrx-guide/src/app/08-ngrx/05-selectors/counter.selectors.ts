/**
 * NgRx TOPIC 3: Selectors
 * Selectors are pure functions for reading state slices.
 * createFeatureSelector() — get a top-level state slice
 * createSelector()        — compose selectors (memoized!)
 */
import { createFeatureSelector, createSelector } from '@ngrx/store';
import { CounterState } from '../03-reducers/counter.reducer';

// 1. Feature selector — get the 'counter' slice
export const selectCounterFeature = createFeatureSelector<CounterState>('counter');

// 2. Derived selectors (memoized — only recomputed when input changes)
export const selectCounterValue   = createSelector(selectCounterFeature, s => s.value);
export const selectCounterStep    = createSelector(selectCounterFeature, s => s.step);
export const selectCounterHistory = createSelector(selectCounterFeature, s => s.history);

// 3. Computed selectors
export const selectDoubleCount    = createSelector(selectCounterValue,   v => v * 2);
export const selectIsPositive     = createSelector(selectCounterValue,   v => v > 0);
export const selectIsNegative     = createSelector(selectCounterValue,   v => v < 0);
export const selectAbsCount       = createSelector(selectCounterValue,   v => Math.abs(v));

// 4. Composed selector (multiple inputs)
export const selectCounterSummary = createSelector(
  selectCounterValue,
  selectCounterStep,
  selectDoubleCount,
  (value, step, double) => ({ value, step, double, formatted: `${value} (step: ${step})` })
);