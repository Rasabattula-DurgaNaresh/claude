import { createFeatureSelector, createSelector } from '@ngrx/store';
import { TodosState } from '../03-reducers/todos.reducer';

export const selectTodosFeature = createFeatureSelector<TodosState>('todos');

export const selectAllTodos  = createSelector(selectTodosFeature, s => s.items);
export const selectFilter    = createSelector(selectTodosFeature, s => s.filter);
export const selectLoading   = createSelector(selectTodosFeature, s => s.loading);
export const selectError     = createSelector(selectTodosFeature, s => s.error);

// Derived
export const selectFilteredTodos = createSelector(
  selectAllTodos,
  selectFilter,
  (todos, filter) => {
    switch (filter) {
      case 'active': return todos.filter(t => !t.completed);
      case 'done':   return todos.filter(t => t.completed);
      default:       return todos;
    }
  }
);

export const selectTodoStats = createSelector(
  selectAllTodos,
  todos => ({
    total:  todos.length,
    done:   todos.filter(t => t.completed).length,
    active: todos.filter(t => !t.completed).length,
    byPriority: {
      high:   todos.filter(t => t.priority === 'high').length,
      medium: todos.filter(t => t.priority === 'medium').length,
      low:    todos.filter(t => t.priority === 'low').length,
    }
  })
);

export const selectHighPriorityTodos = createSelector(
  selectAllTodos,
  todos => todos.filter(t => t.priority === 'high' && !t.completed)
);

// Parametric selector
export const selectTodoById = (id: number) => createSelector(
  selectAllTodos,
  todos => todos.find(t => t.id === id)
);