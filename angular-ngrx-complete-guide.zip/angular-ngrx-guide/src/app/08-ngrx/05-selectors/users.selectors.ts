import { createFeatureSelector, createSelector } from '@ngrx/store';
import { UsersState } from '../03-reducers/users.reducer';

export const selectUsersFeature  = createFeatureSelector<UsersState>('users');
export const selectAllUsers      = createSelector(selectUsersFeature, s => s.users);
export const selectUsersLoading  = createSelector(selectUsersFeature, s => s.loading);
export const selectUsersError    = createSelector(selectUsersFeature, s => s.error);
export const selectSelectedId    = createSelector(selectUsersFeature, s => s.selectedUserId);

export const selectSelectedUser  = createSelector(
  selectAllUsers,
  selectSelectedId,
  (users, id) => id !== null ? users.find(u => u.id === id) : null
);

export const selectUserCount     = createSelector(selectAllUsers, users => users.length);