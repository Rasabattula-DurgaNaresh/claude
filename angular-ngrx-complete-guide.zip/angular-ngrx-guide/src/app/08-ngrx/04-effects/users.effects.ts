import { Injectable, inject } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { HttpClient }  from '@angular/common/http';
import { switchMap, map, catchError, tap, exhaustMap } from 'rxjs/operators';
import { of }          from 'rxjs';
import { UsersActions, User } from '../02-actions/users.actions';

@Injectable()
export class UsersEffects {
  private actions$ = inject(Actions);
  private http     = inject(HttpClient);

  // 1. Load users on action dispatch
  loadUsers$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UsersActions.loadUsers),    // Listen for loadUsers action
      exhaustMap(() =>                   // exhaustMap: ignore clicks while loading
        this.http.get<User[]>('https://jsonplaceholder.typicode.com/users').pipe(
          map(users => UsersActions.loadUsersSuccess({ users })),
          catchError(error => of(UsersActions.loadUsersFailure({ error: error.message }))),
        )
      )
    )
  );

  // 2. Log on success
  logSuccess$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UsersActions.loadUsersSuccess),
      tap(({ users }) => console.log('[Effect] Users loaded:', users.length)),
    ), { dispatch: false }
  );

  // 3. Log on failure
  handleError$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UsersActions.loadUsersFailure),
      tap(({ error }) => console.error('[Effect] Load users failed:', error)),
    ), { dispatch: false }
  );
}