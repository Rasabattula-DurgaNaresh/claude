/**
 * NgRx Effects — Full demonstration
 */
import { Component, OnInit, inject } from '@angular/core';
import { CommonModule, AsyncPipe }   from '@angular/common';
import { Store }                     from '@ngrx/store';
import { UsersActions }              from '../02-actions/users.actions';
import { selectAllUsers, selectUsersLoading, selectUsersError,
         selectSelectedUser } from '../05-selectors/users.selectors';

@Component({
  selector:    'app-effects-demo',
  standalone:  true,
  imports:     [CommonModule, AsyncPipe],
  template: `
    <div class="page">
      <h1 class="section-title">10 — NgRx Effects</h1>

      <div class="info mb-16">
        Effects intercept actions, perform async operations (HTTP, localStorage, timers),
        and dispatch new actions. They never mutate state directly.
      </div>

      <div class="card">
        <div class="flex justify-b items-c mb-8">
          <p class="sub-title" style="margin:0">Users (HTTP Effect)</p>
          <button class="btn btn-primary btn-sm" (click)="loadUsers()">
            {{ (loading$ | async) ? 'Loading...' : 'Dispatch loadUsers' }}
          </button>
        </div>

        @if (loading$ | async) {
          <div class="info">⏳ Effect is running HTTP request...</div>
        }
        @if (error$ | async; as err) {
          <div class="warn">❌ Effect dispatched failure: {{ err }}</div>
        }

        <div class="grid-3 mt-8">
          @for (user of (users$ | async); track user.id) {
            <div class="card" style="cursor:pointer; padding:12px"
                 (click)="selectUser(user.id)">
              <strong style="font-size:14px">{{ user.name }}</strong>
              <p style="font-size:12px; color:var(--muted)">{{ user.email }}</p>
              <p style="font-size:12px; color:var(--muted)">{{ user.phone }}</p>
            </div>
          }
        </div>
      </div>

      <div class="card mt-16">
        <p class="sub-title">Effect Pattern Reference</p>
        <pre style="font-size:11px">
@Injectable()
export class UsersEffects {{'{'}
  private actions$ = inject(Actions);
  private http     = inject(HttpClient);

  // Typical API load effect
  loadUsers$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UsersActions.loadUsers),     // 1. Listen for action
      exhaustMap(() =>                    // 2. Handle async
        this.http.get&lt;User[]&gt;('/api/users').pipe(
          map(users =>                    // 3a. Dispatch success
            UsersActions.loadUsersSuccess({{ '{' }}users{{ '}' }})),
          catchError(error => of(         // 3b. Dispatch failure
            UsersActions.loadUsersFailure({{ '{' }}error: error.message{{ '}' }})))
        )
      )
    )
  );

  // Side-effect only (no dispatch)
  logAction$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UsersActions.loadUsersSuccess),
      tap({{ '{' }}users{{ '}' }} => console.log('Loaded:', users.length))
    ), {{ '{' }}dispatch: false{{ '}' }}   // ← IMPORTANT: prevent infinite loop
  );
{{'}'}}</pre>
      </div>
    </div>
  `,
})
export class EffectsDemoComponent implements OnInit {
  private store = inject(Store);

  users$   = this.store.select(selectAllUsers);
  loading$ = this.store.select(selectUsersLoading);
  error$   = this.store.select(selectUsersError);
  selected$ = this.store.select(selectSelectedUser);

  ngOnInit() { this.loadUsers(); }

  loadUsers() { this.store.dispatch(UsersActions.loadUsers()); }
  selectUser(id: number) { this.store.dispatch(UsersActions.selectUser({ userId: id })); }
}