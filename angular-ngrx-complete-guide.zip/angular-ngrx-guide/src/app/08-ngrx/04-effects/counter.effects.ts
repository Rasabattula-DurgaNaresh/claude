/**
 * NgRx TOPIC 4: Effects
 * Effects handle side effects (API calls, logging, navigation).
 * They listen for actions, perform async work, dispatch new actions.
 * createEffect() — registers an Effect
 * ofType()       — filter actions by type
 * switchMap      — cancel previous, use latest
 */
import { Injectable, inject } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { tap, map, delay }  from 'rxjs/operators';
import { CounterActions }   from '../02-actions/counter.actions';
import { EMPTY } from 'rxjs';

@Injectable()
export class CounterEffects {
  private actions$ = inject(Actions);

  // 1. Non-dispatching effect — side effect only (logging)
  logIncrement$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CounterActions.increment, CounterActions.decrement),
      tap(action => console.log('[Effect] Counter action:', action.type)),
    ), { dispatch: false }  // Does NOT dispatch a new action
  );

  // 2. Dispatch after delay (auto-reset after 30 increments concept)
  // For demo: simulates persistence
  persistCounter$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CounterActions.increment, CounterActions.decrement, CounterActions.incrementBy),
      tap(action => {
        // Persist to localStorage
        console.log('[Effect] Persisting counter state after:', action.type);
      }),
    ), { dispatch: false }
  );
}