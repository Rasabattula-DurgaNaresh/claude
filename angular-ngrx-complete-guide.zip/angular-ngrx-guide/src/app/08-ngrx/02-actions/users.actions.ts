import { createActionGroup, props, emptyProps } from '@ngrx/store';

export interface User {
  id:       number;
  name:     string;
  email:    string;
  username: string;
  phone:    string;
  website:  string;
}

export const UsersActions = createActionGroup({
  source: 'Users',
  events: {
    'Load Users':          emptyProps(),
    'Load Users Success':  props<{ users: User[] }>(),
    'Load Users Failure':  props<{ error: string }>(),
    'Select User':         props<{ userId: number }>(),
    'Clear Selection':     emptyProps(),
  }
});