import { createActionGroup, createAction, props, emptyProps } from '@ngrx/store';

export interface Todo {
  id:        number;
  title:     string;
  completed: boolean;
  priority:  'low' | 'medium' | 'high';
  createdAt: string;
}

// Grouped actions — API pattern
export const TodosActions = createActionGroup({
  source: 'Todos',
  events: {
    // UI actions
    'Add Todo':     props<{ title: string; priority: Todo['priority'] }>(),
    'Toggle Todo':  props<{ id: number }>(),
    'Delete Todo':  props<{ id: number }>(),
    'Update Todo':  props<{ id: number; changes: Partial<Todo> }>(),
    'Clear Done':   emptyProps(),
    'Set Filter':   props<{ filter: 'all' | 'active' | 'done' }>(),

    // API actions — Load
    'Load Todos':          emptyProps(),
    'Load Todos Success':  props<{ todos: Todo[] }>(),
    'Load Todos Failure':  props<{ error: string }>(),

    // API actions — Create
    'Create Todo':          props<{ title: string }>(),
    'Create Todo Success':  props<{ todo: Todo }>(),
    'Create Todo Failure':  props<{ error: string }>(),
  }
});