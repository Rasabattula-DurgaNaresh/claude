/**
 * NgRx TOPIC 1: Actions
 * Actions describe unique events. They are plain objects with a 'type' string.
 * createAction() — type-safe action creator factory
 * createActionGroup() — group related actions (Angular 14+)
 * props<T>() — payload type definition
 */
import { createAction, createActionGroup, props, emptyProps } from '@ngrx/store';

// ── 1. Basic actions with createAction ────────────────────────────────────────
export const increment    = createAction('[Counter] Increment');
export const decrement    = createAction('[Counter] Decrement');
export const reset        = createAction('[Counter] Reset');
export const incrementBy  = createAction('[Counter] Increment By', props<{ amount: number }>());
export const setStep      = createAction('[Counter] Set Step',     props<{ step: number }>());

// ── 2. Action Groups — bundle related actions (recommended) ───────────────────
export const CounterActions = createActionGroup({
  source: 'Counter',
  events: {
    'Increment':    emptyProps(),
    'Decrement':    emptyProps(),
    'Reset':        emptyProps(),
    'Increment By': props<{ amount: number }>(),
    'Set Step':     props<{ step: number }>(),
  }
});
// Generates: CounterActions.increment(), CounterActions.decrement(), etc.