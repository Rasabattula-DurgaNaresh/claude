/**
 * NgRx TOPIC 5: Using the Store
 * inject(Store) — get the global store
 * store.select() — select state slices (returns Observable)
 * store.dispatch() — dispatch actions
 */
import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule, AsyncPipe, JsonPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Store }       from '@ngrx/store';

import { CounterActions }        from '../02-actions/counter.actions';
import { TodosActions, Todo }    from '../02-actions/todos.actions';
import { UsersActions }          from '../02-actions/users.actions';
import { selectCounterSummary, selectCounterHistory } from '../05-selectors/counter.selectors';
import { selectFilteredTodos, selectTodoStats, selectFilter } from '../05-selectors/todos.selectors';
import { selectAllUsers, selectUsersLoading, selectUsersError, selectSelectedUser } from '../05-selectors/users.selectors';

@Component({
  selector:    'app-store-basics',
  standalone:  true,
  imports:     [CommonModule, AsyncPipe, JsonPipe, FormsModule],
  templateUrl: './store-basics.component.html',
})
export class StoreBasicsComponent implements OnInit {
  private store = inject(Store);

  // Select state slices (Observables)
  counterSummary$ = this.store.select(selectCounterSummary);
  history$        = this.store.select(selectCounterHistory);
  todos$          = this.store.select(selectFilteredTodos);
  todoStats$      = this.store.select(selectTodoStats);
  todoFilter$     = this.store.select(selectFilter);
  users$          = this.store.select(selectAllUsers);
  usersLoading$   = this.store.select(selectUsersLoading);
  usersError$     = this.store.select(selectUsersError);
  selectedUser$   = this.store.select(selectSelectedUser);

  // Local UI state
  newTodoTitle  = '';
  newPriority: Todo['priority'] = 'medium';
  customAmount  = 5;

  ngOnInit() {
    // Auto-load users on component init
    this.store.dispatch(UsersActions.loadUsers());
  }

  // Counter actions
  increment()    { this.store.dispatch(CounterActions.increment()); }
  decrement()    { this.store.dispatch(CounterActions.decrement()); }
  reset()        { this.store.dispatch(CounterActions.reset());     }
  incrementBy(n: number) { this.store.dispatch(CounterActions.incrementBy({ amount: n })); }
  setStep(step: number)  { this.store.dispatch(CounterActions.setStep({ step })); }

  // Todo actions
  addTodo() {
    if (!this.newTodoTitle.trim()) return;
    this.store.dispatch(TodosActions.addTodo({ title: this.newTodoTitle, priority: this.newPriority }));
    this.newTodoTitle = '';
  }
  toggleTodo(id: number)   { this.store.dispatch(TodosActions.toggleTodo({ id })); }
  deleteTodo(id: number)   { this.store.dispatch(TodosActions.deleteTodo({ id })); }
  clearDone()              { this.store.dispatch(TodosActions.clearDone()); }
  setFilter(filter: any)   { this.store.dispatch(TodosActions.setFilter({ filter })); }

  // Users actions
  loadUsers()              { this.store.dispatch(UsersActions.loadUsers()); }
  selectUser(id: number)   { this.store.dispatch(UsersActions.selectUser({ userId: id })); }
  clearSelection()         { this.store.dispatch(UsersActions.clearSelection()); }
}