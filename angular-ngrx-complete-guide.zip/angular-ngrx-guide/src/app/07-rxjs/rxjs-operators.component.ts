/**
 * TOPIC 10: RxJS Operators — The essential ones
 *
 * Creation:     of, from, interval, timer, fromEvent, EMPTY, NEVER
 * Transform:    map, pluck, switchMap, mergeMap, concatMap, exhaustMap
 * Filter:       filter, take, takeUntil, skip, distinctUntilChanged, debounceTime
 * Combination:  combineLatest, forkJoin, zip, merge, withLatestFrom
 * Error:        catchError, retry, retryWhen, throwError
 * Utility:      tap, delay, timeout, finalize, share, shareReplay
 */
import {
  Component, OnInit, OnDestroy, signal, inject
} from '@angular/core';
import { CommonModule }  from '@angular/common';
import { FormsModule }   from '@angular/forms';
import { HttpClient }    from '@angular/common/http';
import {
  Subject, BehaviorSubject, ReplaySubject, AsyncSubject,
  Observable, interval, timer, fromEvent, of, from, EMPTY,
  combineLatest, forkJoin, merge, zip,
  Subscription, takeUntil, map, filter, take, skip,
  debounceTime, distinctUntilChanged, switchMap, mergeMap,
  concatMap, exhaustMap, catchError, retry, tap, delay,
  share, shareReplay, withLatestFrom, startWith, scan,
  throttleTime, finalize, timeout
} from 'rxjs';

@Component({
  selector:    'app-rxjs-operators',
  standalone:  true,
  imports:     [CommonModule, FormsModule],
  templateUrl: './rxjs-operators.component.html',
})
export class RxjsOperatorsComponent implements OnInit, OnDestroy {
  private http    = inject(HttpClient);
  private destroy$ = new Subject<void>();

  // State
  logs    = signal<string[]>([]);
  counter = signal(0);
  searchTerm = signal('');
  searchResults = signal<any[]>([]);
  searchLoading = signal(false);

  // Subjects
  private searchSubject$ = new BehaviorSubject<string>('');

  // ── 1. Subjects ────────────────────────────────────────────────────────────
  subject$      = new Subject<string>();
  behavior$     = new BehaviorSubject<string>('initial');  // has current value
  replay$       = new ReplaySubject<string>(3);             // buffers last N
  async$        = new AsyncSubject<string>();               // only emits on complete

  // ── 2. Counter with scan ──────────────────────────────────────────────────
  counterStream$ = new Subject<'inc' | 'dec' | 'reset'>();
  counterValue$  = this.counterStream$.pipe(
    startWith('reset' as const),
    scan((acc, action) => {
      if (action === 'inc')   return acc + 1;
      if (action === 'dec')   return acc - 1;
      if (action === 'reset') return 0;
      return acc;
    }, 0)
  );

  ngOnInit() {
    // ── Auto-increment with interval ────────────────────────────────────────
    interval(1000).pipe(
      take(5),                         // Take only 5 values
      map(n => n * 2),                 // Transform
      filter(n => n % 4 === 0),        // Filter
      takeUntil(this.destroy$),        // Cleanup on destroy
    ).subscribe(n => this.log(`interval: ${n}`));

    // ── debounce search ────────────────────────────────────────────────────
    this.searchSubject$.pipe(
      debounceTime(400),
      distinctUntilChanged(),
      tap(() => this.searchLoading.set(true)),
      switchMap(term => term.length >= 2
        ? this.http.get<any[]>(`https://jsonplaceholder.typicode.com/posts?title_like=${term}&_limit=3`)
        : of([])
      ),
      takeUntil(this.destroy$),
    ).subscribe({
      next: results => {
        this.searchResults.set(results);
        this.searchLoading.set(false);
      },
      error: () => this.searchLoading.set(false),
    });

    // ── forkJoin — parallel requests ────────────────────────────────────────
    forkJoin({
      posts: this.http.get<any[]>('https://jsonplaceholder.typicode.com/posts?_limit=2'),
      users: this.http.get<any[]>('https://jsonplaceholder.typicode.com/users?_limit=2'),
    }).pipe(takeUntil(this.destroy$))
      .subscribe(({ posts, users }) => {
        this.log(`forkJoin: ${posts.length} posts + ${users.length} users`);
      });

    // ── Subject demo ──────────────────────────────────────────────────────
    this.subject$.pipe(takeUntil(this.destroy$))
      .subscribe(v => this.log(`Subject: ${v}`));

    this.behavior$.pipe(takeUntil(this.destroy$))
      .subscribe(v => this.log(`BehaviorSubject: ${v}`));
  }

  onSearch(term: string) {
    this.searchSubject$.next(term);
  }

  // ── Higher-order mapping comparison ───────────────────────────────────────
  demonstrateMapping(type: 'switch' | 'merge' | 'concat' | 'exhaust') {
    const click$ = of(1).pipe(delay(0));
    const request$ = (n: number) => of(`result-${n}`).pipe(delay(500));

    const ops: Record<string, any> = {
      switch:  switchMap,   // cancel prev, use latest
      merge:   mergeMap,    // all concurrent (parallel)
      concat:  concatMap,   // queue, one at a time
      exhaust: exhaustMap,  // ignore new while prev running
    };

    this.log(`[${type}Map] demonstrating...`);
    click$.pipe(ops[type]((n: any) => request$(n).pipe(tap(() => {}))))
      .subscribe(r => this.log(`[${type}Map] result: ${r}`));
  }

  emitSubject() { this.subject$.next(`value-${Date.now() % 1000}`); }
  updateBehavior(v: string) { this.behavior$.next(v); }

  private log(msg: string) {
    const t = new Date().toLocaleTimeString();
    this.logs.update(l => [`[${t}] ${msg}`, ...l].slice(0, 15));
  }

  clearLogs() { this.logs.set([]); }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }
}