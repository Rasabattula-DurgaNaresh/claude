import { Component }               from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule }              from '@angular/common';

interface NavItem {
  path: string;
  label: string;
  badge: string;
  color: string;
}

@Component({
  selector:    'app-root',
  standalone:  true,
  imports:     [RouterOutlet, RouterLink, RouterLinkActive, CommonModule],
  templateUrl: './app.component.html',
  styleUrl:    './app.component.scss',
})
export class AppComponent {
  title = 'Angular + NgRx Complete Guide';

  navItems: NavItem[] = [
    { path: '/components', label: 'Components',  badge: '01', color: '#dd0031' },
    { path: '/lifecycle',  label: 'Lifecycle',   badge: '02', color: '#dd0031' },
    { path: '/templates',  label: 'Templates',   badge: '03', color: '#dd0031' },
    { path: '/directives', label: 'Directives',  badge: '04', color: '#e65100' },
    { path: '/pipes',      label: 'Pipes',       badge: '05', color: '#e65100' },
    { path: '/services',   label: 'Services/DI', badge: '06', color: '#1565c0' },
    { path: '/forms',      label: 'Forms',       badge: '07', color: '#1565c0' },
    { path: '/rxjs',       label: 'RxJS',        badge: '08', color: '#7b3ff2' },
    { path: '/ngrx',       label: 'NgRx Store',  badge: '09', color: '#7b3ff2' },
    { path: '/effects',    label: 'NgRx Effects', badge: '10', color: '#7b3ff2' },
    { path: '/signals',    label: 'Signals',     badge: '11', color: '#0d9488' },
    { path: '/users',      label: 'Lazy Module', badge: '12', color: '#0d9488' },
  ];
}