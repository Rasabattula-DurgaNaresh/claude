/**
 * TOPIC 11: Angular Signals (v16+)
 * Signals are reactive primitives — a new way to manage state in Angular.
 * They are synchronous, glitch-free, and work without RxJS.
 *
 * signal()    — create a writable signal
 * computed()  — derive a value from other signals
 * effect()    — run side effects when signals change
 * toSignal()  — convert Observable to Signal
 * toObservable() — convert Signal to Observable
 */
import {
  Component, OnInit, signal, computed, effect,
  Signal, WritableSignal, inject, DestroyRef
} from '@angular/core';
import { CommonModule }  from '@angular/common';
import { FormsModule }   from '@angular/forms';
import { toSignal, toObservable }        from '@angular/core/rxjs-interop';
import { HttpClient }    from '@angular/common/http';
import { interval, map } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

interface CartItem {
  id:       number;
  name:     string;
  price:    number;
  quantity: number;
}

@Component({
  selector:    'app-signals',
  standalone:  true,
  imports:     [CommonModule, FormsModule],
  templateUrl: './signals.component.html',
})
export class SignalsComponent implements OnInit {
  private http       = inject(HttpClient);
  private destroyRef = inject(DestroyRef);

  // ── 1. Writable signals ───────────────────────────────────────────────────
  count     = signal(0);
  name      = signal('Angular');
  darkMode  = signal(false);
  isLoading = signal(false);

  // ── 2. Computed signals (memoized) ────────────────────────────────────────
  doubled  = computed(() => this.count() * 2);
  greeting = computed(() => `Hello, ${this.name()}!`);
  theme    = computed(() => this.darkMode() ? 'dark' : 'light');

  // ── 3. Shopping cart signals ──────────────────────────────────────────────
  cart = signal<CartItem[]>([
    { id: 1, name: 'Angular Course',  price: 49.99, quantity: 1 },
    { id: 2, name: 'NgRx Workshop',   price: 79.99, quantity: 2 },
    { id: 3, name: 'RxJS Handbook',   price: 29.99, quantity: 1 },
  ]);

  cartTotal = computed(() =>
    this.cart().reduce((sum, item) => sum + item.price * item.quantity, 0)
  );
  cartCount = computed(() =>
    this.cart().reduce((sum, item) => sum + item.quantity, 0)
  );
  hasItems = computed(() => this.cart().length > 0);

  // ── 4. toSignal — convert Observable to Signal ────────────────────────────
  clock: Signal<Date> = toSignal(
    interval(1000).pipe(map(() => new Date())),
    { initialValue: new Date() }
  );

  // ── 5. Effect — run code when signals change ──────────────────────────────
  private logEffect = effect(() => {
    // This runs whenever count() changes
    console.log('[Signal Effect] Count changed to:', this.count());
    // Cleanup runs before next execution
    return () => console.log('[Signal Effect] Cleanup');
  });

  // ── 6. Signal from HTTP ───────────────────────────────────────────────────
  posts: Signal<any[]> = toSignal(
    this.http.get<any[]>('https://jsonplaceholder.typicode.com/posts?_limit=3'),
    { initialValue: [] }
  );

  ngOnInit() {
    // Effect that persists dark mode to localStorage
    effect(() => {
      localStorage.setItem('darkMode', JSON.stringify(this.darkMode()));
    }, { allowSignalWrites: true });
  }

  // ── Cart methods ──────────────────────────────────────────────────────────
  addItem(name: string, price: number) {
    const existing = this.cart().find(i => i.name === name);
    if (existing) {
      this.updateQuantity(existing.id, 1);
    } else {
      this.cart.update(items => [...items, {
        id: Date.now(), name, price, quantity: 1
      }]);
    }
  }

  updateQuantity(id: number, delta: number) {
    this.cart.update(items =>
      items.map(item => item.id === id
        ? { ...item, quantity: Math.max(0, item.quantity + delta) }
        : item
      ).filter(item => item.quantity > 0)
    );
  }

  removeItem(id: number) {
    this.cart.update(items => items.filter(i => i.id !== id));
  }

  clearCart() { this.cart.set([]); }
}