/**
 * TOPIC 12: Lazy Loading — Feature Routes
 * Loaded only when the user navigates to /users
 */
import { Routes } from '@angular/router';

export const usersRoutes: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('./users-list.component').then(m => m.UsersListComponent),
  },
  {
    path: ':id',
    loadComponent: () =>
      import('./user-detail.component').then(m => m.UserDetailComponent),
  },
];