import { Component, inject } from '@angular/core';
import { CommonModule }       from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { HttpClient }         from '@angular/common/http';
import { toSignal }           from '@angular/core/rxjs-interop';

@Component({
  selector:   'app-users-list',
  standalone: true,
  imports:    [CommonModule, RouterLink],
  template: `
    <div class="page">
      <h1 class="section-title">12 — Lazy-Loaded Module</h1>
      <div class="info mb-16">
        This module was loaded lazily — it was NOT included in the initial bundle.
        Check the Network tab: users chunk loaded only when you navigated here.
      </div>
      <div class="grid-3">
        @for (user of users(); track user.id) {
          <div class="card" style="cursor:pointer" [routerLink]="[user.id]">
            <strong>{{ user.name }}</strong>
            <p style="font-size:12px; color:var(--muted)">{{ user.email }}</p>
            <p style="font-size:12px; color:var(--muted)">{{ user.phone }}</p>
          </div>
        }
      </div>
    </div>
  `,
})
export class UsersListComponent {
  private http = inject(HttpClient);
  users = toSignal(
    this.http.get<any[]>('https://jsonplaceholder.typicode.com/users'),
    { initialValue: [] }
  );
}