import { Component, inject } from '@angular/core';
import { CommonModule }       from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient }         from '@angular/common/http';
import { toSignal }           from '@angular/core/rxjs-interop';
import { switchMap, map }     from 'rxjs';

@Component({
  selector:   'app-user-detail',
  standalone: true,
  imports:    [CommonModule],
  template: `
    <div class="page">
      <button class="btn btn-ghost btn-sm mb-16" (click)="back()">← Back</button>
      @if (user(); as u) {
        <div class="card">
          <h2>{{ u.name }}</h2>
          <p>Email: {{ u.email }}</p>
          <p>Phone: {{ u.phone }}</p>
          <p>Company: {{ u.company?.name }}</p>
        </div>
      }
    </div>
  `,
})
export class UserDetailComponent {
  private route  = inject(ActivatedRoute);
  private router = inject(Router);
  private http   = inject(HttpClient);

  user = toSignal(
    this.route.params.pipe(
      switchMap(({ id }) =>
        this.http.get<any>(`https://jsonplaceholder.typicode.com/users/${id}`)
      )
    )
  );

  back() { this.router.navigate(['/users']); }
}