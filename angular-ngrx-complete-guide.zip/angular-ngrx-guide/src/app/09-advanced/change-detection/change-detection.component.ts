/**
 * TOPIC 14: Change Detection
 * Default: checks entire tree on every event/async operation
 * OnPush:  only checks when:
 *   - @Input() reference changes
 *   - Event originated from component
 *   - Observable/async pipe emits
 *   - ChangeDetectorRef.detectChanges() called
 *   - Signal updates (auto in v17)
 */
import {
  Component, ChangeDetectionStrategy, ChangeDetectorRef,
  Input, signal, inject
} from '@angular/core';
import { CommonModule } from '@angular/common';

let renderCount = 0;

@Component({
  selector:   'app-onpush-child',
  standalone: true,
  imports:    [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,  // ← Only checks on @Input change
  template: `
    <div class="card" style="border-color:var(--purple)">
      <span class="badge badge-purple">OnPush</span>
      <p class="mt-8"><strong>{{ title }}</strong></p>
      <p style="font-size:12px; color:var(--muted)">
        Render count: <strong>{{ getRenderCount() }}</strong>
        (OnPush — only updates when @Input changes)
      </p>
    </div>
  `,
})
export class OnPushChildComponent {
  @Input() title = '';
  private renders = 0;
  getRenderCount() { return ++this.renders; }
}

@Component({
  selector:    'app-change-detection',
  standalone:  true,
  imports:     [CommonModule, OnPushChildComponent],
  templateUrl: './change-detection.component.html',
  changeDetection: ChangeDetectionStrategy.Default,
})
export class ChangeDetectionComponent {
  private cdr = inject(ChangeDetectorRef);

  // Signals cause focused re-renders
  title     = signal('Initial Title');
  counter   = signal(0);
  unrelated = signal('unrelated state');

  childTitle = 'Same Title';  // @Input won't change = OnPush child won't re-render

  updateTitle()   { this.title.set(`Title ${Date.now() % 1000}`); }
  updateChild()   { this.childTitle = `Child ${Date.now() % 1000}`; }
  triggerCdr()    { this.cdr.detectChanges(); }
  markForCheck()  { this.cdr.markForCheck(); }
  detachCdr()     { this.cdr.detach(); }
  reattachCdr()   { this.cdr.reattach(); }
}