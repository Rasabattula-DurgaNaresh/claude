/**
 * HttpClient — typed HTTP requests with full CRUD
 */
import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Observable, catchError, retry, throwError, tap } from 'rxjs';
import { map } from 'rxjs/operators';

export interface Post {
  id:     number;
  userId: number;
  title:  string;
  body:   string;
}

@Injectable({ providedIn: 'root' })
export class ApiService {
  private http = inject(HttpClient);
  private BASE = 'https://jsonplaceholder.typicode.com';

  // ── GET with query params ─────────────────────────────────────────────────
  getPosts(page = 1, limit = 5): Observable<Post[]> {
    const params = new HttpParams()
      .set('_page', page.toString())
      .set('_limit', limit.toString());

    return this.http.get<Post[]>(`${this.BASE}/posts`, { params }).pipe(
      map(posts => posts.map(p => ({ ...p, title: p.title.toUpperCase() }))),
      retry(2),
      catchError(this.handleError)
    );
  }

  // ── GET single ────────────────────────────────────────────────────────────
  getPost(id: number): Observable<Post> {
    return this.http.get<Post>(`${this.BASE}/posts/${id}`).pipe(
      catchError(this.handleError)
    );
  }

  // ── POST ──────────────────────────────────────────────────────────────────
  createPost(post: Partial<Post>): Observable<Post> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post<Post>(`${this.BASE}/posts`, post, { headers }).pipe(
      tap(created => console.log('Created:', created)),
      catchError(this.handleError)
    );
  }

  // ── PUT (full update) ─────────────────────────────────────────────────────
  updatePost(id: number, post: Partial<Post>): Observable<Post> {
    return this.http.put<Post>(`${this.BASE}/posts/${id}`, post).pipe(
      catchError(this.handleError)
    );
  }

  // ── PATCH (partial update) ────────────────────────────────────────────────
  patchPost(id: number, changes: Partial<Post>): Observable<Post> {
    return this.http.patch<Post>(`${this.BASE}/posts/${id}`, changes).pipe(
      catchError(this.handleError)
    );
  }

  // ── DELETE ────────────────────────────────────────────────────────────────
  deletePost(id: number): Observable<void> {
    return this.http.delete<void>(`${this.BASE}/posts/${id}`).pipe(
      catchError(this.handleError)
    );
  }

  // ── Response with headers ─────────────────────────────────────────────────
  getPostsWithHeaders(limit = 5): Observable<{ data: Post[]; total: number }> {
    return this.http.get<Post[]>(`${this.BASE}/posts?_limit=${limit}`, {
      observe: 'response',  // Full response including headers
    }).pipe(
      map(res => ({
        data:  res.body || [],
        total: parseInt(res.headers.get('x-total-count') || '100'),
      }))
    );
  }

  private handleError(error: any): Observable<never> {
    const msg = error.error?.message || error.message || 'Server error';
    console.error('ApiService Error:', error);
    return throwError(() => new Error(msg));
  }
}