/**
 * TOPIC 9: HTTP Interceptors (Functional — Angular 15+)
 * Interceptors run for every HTTP request/response.
 * Use cases: auth headers, logging, error handling, retry logic.
 */
import { HttpInterceptorFn, HttpErrorResponse } from '@angular/common/http';
import { inject }  from '@angular/core';
import { Router }  from '@angular/router';
import { catchError, throwError } from 'rxjs';

// ── Auth interceptor — attach Bearer token ─────────────────────────────────────
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const token = localStorage.getItem('auth_token');

  const authReq = token
    ? req.clone({ headers: req.headers.set('Authorization', `Bearer ${token}`) })
    : req;

  return next(authReq).pipe(
    catchError((error: HttpErrorResponse) => {
      if (error.status === 401) {
        localStorage.removeItem('auth_token');
        // inject(Router).navigate(['/login']);  // could redirect
      }
      return throwError(() => error);
    })
  );
};