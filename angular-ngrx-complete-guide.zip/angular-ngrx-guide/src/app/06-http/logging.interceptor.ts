import { HttpInterceptorFn } from '@angular/common/http';
import { tap, finalize }      from 'rxjs';

// ── Logging interceptor — log duration of every request ──────────────────────
export const loggingInterceptor: HttpInterceptorFn = (req, next) => {
  const start = Date.now();
  console.log(`[HTTP] ▶ ${req.method} ${req.url}`);

  return next(req).pipe(
    tap({
      next:  (res) => console.log(`[HTTP] ✅ Response:`, res),
      error: (err) => console.error(`[HTTP] ❌ Error:`, err.status, err.message),
    }),
    finalize(() => {
      const ms = Date.now() - start;
      console.log(`[HTTP] ⏱ ${req.method} ${req.url} completed in ${ms}ms`);
    })
  );
};