/**
 * TOPIC 8: Angular Reactive Forms
 *
 * FormControl  — single field
 * FormGroup    — collection of controls
 * FormArray    — dynamic list of controls
 * FormBuilder  — shorthand factory
 * Validators   — built-in + custom
 * valueChanges — reactive Observable for form changes
 */
import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import {
  ReactiveFormsModule, FormBuilder, FormGroup, FormArray,
  Validators, AbstractControl, ValidationErrors, AsyncValidatorFn
} from '@angular/forms';
import { CommonModule }  from '@angular/common';
import { Observable, of, Subscription, debounceTime, distinctUntilChanged } from 'rxjs';
import { delay, map }   from 'rxjs/operators';

// ── Custom Validators ─────────────────────────────────────────────────────────
const noWhitespace = (ctrl: AbstractControl): ValidationErrors | null =>
  (ctrl.value || '').trim().length === 0 ? { whitespace: true } : null;

const passwordMatch = (group: AbstractControl): ValidationErrors | null => {
  const pw  = group.get('password')?.value;
  const pwc = group.get('confirmPassword')?.value;
  return pw === pwc ? null : { passwordMismatch: true };
};

const uniqueUsernameValidator = (takenNames: string[]): AsyncValidatorFn =>
  (ctrl: AbstractControl): Observable<ValidationErrors | null> =>
    of(takenNames.includes(ctrl.value) ? { usernameTaken: true } : null).pipe(delay(500));

@Component({
  selector:    'app-reactive-forms',
  standalone:  true,
  imports:     [ReactiveFormsModule, CommonModule],
  templateUrl: './reactive-forms.component.html',
})
export class ReactiveFormsComponent implements OnInit, OnDestroy {
  private fb  = inject(FormBuilder);
  private sub = new Subscription();

  // 1. Registration form with FormGroup + FormArray
  regForm = this.fb.group({
    // Personal
    firstName: ['', [Validators.required, Validators.minLength(2), noWhitespace]],
    lastName:  ['', [Validators.required, Validators.minLength(2)]],
    username:  ['', {
      validators:      [Validators.required, Validators.pattern(/^[a-z0-9_]{3,20}$/)],
      asyncValidators: [uniqueUsernameValidator(['admin', 'root', 'user'])],
      updateOn:        'blur',
    }],
    email:     ['', [Validators.required, Validators.email]],

    // Nested group
    address: this.fb.group({
      street: ['', Validators.required],
      city:   ['', Validators.required],
      zip:    ['', [Validators.required, Validators.pattern(/^\d{5}$/)]]
    }),

    // Password group with cross-field validation
    passwords: this.fb.group({
      password:        ['', [Validators.required, Validators.minLength(8)]],
      confirmPassword: ['', Validators.required],
    }, { validators: passwordMatch }),

    role:   ['user', Validators.required],
    agree:  [false, Validators.requiredTrue],

    // Dynamic fields (FormArray)
    skills: this.fb.array([
      this.fb.control('', Validators.required),
    ]),
  });

  submittedData: any = null;
  showPassword = false;

  get skills(): FormArray { return this.regForm.get('skills') as FormArray; }
  get passwords() { return this.regForm.get('passwords') as FormGroup; }

  ngOnInit() {
    // React to form value changes
    const emailSub = this.regForm.get('email')!.valueChanges.pipe(
      debounceTime(300),
      distinctUntilChanged(),
    ).subscribe(email => console.log('Email changed:', email));
    this.sub.add(emailSub);

    // Auto-fill city based on zip (demo)
    const zipSub = this.regForm.get('address.zip')!.valueChanges
      .pipe(debounceTime(400))
      .subscribe(zip => {
        if (zip === '10001') this.regForm.get('address.city')?.setValue('New York');
        if (zip === '90210') this.regForm.get('address.city')?.setValue('Beverly Hills');
      });
    this.sub.add(zipSub);
  }

  addSkill()     { this.skills.push(this.fb.control('', Validators.required)); }
  removeSkill(i: number) { this.skills.removeAt(i); }

  onSubmit() {
    if (this.regForm.invalid) {
      this.regForm.markAllAsTouched();
      return;
    }
    this.submittedData = this.regForm.value;
    console.log('Submitted:', this.submittedData);
  }

  // Helper: get specific field errors
  getError(path: string): string {
    const ctrl = this.regForm.get(path);
    if (!ctrl?.touched || !ctrl.errors) return '';
    const e = ctrl.errors;
    if (e['required'])        return 'This field is required';
    if (e['email'])           return 'Invalid email address';
    if (e['minlength'])       return `Minimum ${e['minlength'].requiredLength} characters`;
    if (e['pattern'])         return 'Invalid format';
    if (e['whitespace'])      return 'Cannot be only whitespace';
    if (e['usernameTaken'])   return 'Username is already taken';
    return 'Invalid value';
  }

  isInvalid(path: string): boolean {
    const ctrl = this.regForm.get(path);
    return !!(ctrl?.touched && ctrl?.invalid);
  }

  ngOnDestroy() { this.sub.unsubscribe(); }
}