# Java Collections Framework — Complete Tutorial

> **52 Topics · 8 Java files · 5 PNG diagrams · 100+ Interview Q&As**

---

## Diagram Index

| Diagram | Covers |
|---------|--------|
| `diagrams/01_collection_hierarchy.png` | Full hierarchy tree + complexity table |
| `diagrams/02_hashmap_internals.png` | put() flow, bucket chaining, Java 8 treeification |
| `diagrams/03_stream_api.png` | Pipeline stages + common collectors |
| `diagrams/04_concurrent_collections.png` | Thread safety options + ConcurrentHashMap |
| `diagrams/05_custom_implementations.png` | LRU Cache + Min Heap visualization |

## Project Structure

```
java-collections-complete/
├── pom.xml
├── diagrams/           ← 5 PNG flow diagrams
├── docs/               ← This guide
└── src/main/java/com/collections/
    ├── core/       CollectionIntroDemo.java    (Topics 1-5)
    ├── list/       ListDemo.java               (Topics 6-9)
    ├── set/        SetDemo.java                (Topics 13-16)
    ├── map/        MapDemo.java                (Topics 17-29)
    ├── queue/      QueueDemo.java              (Topics 10-12)
    ├── advanced/   Java8FeaturesDemo.java      (Topics 30-38)
    ├── concurrent/ ConcurrentDemo.java         (Topics 35-37)
    └── custom/     CustomImplementations.java  (Topic 39)
```

**Run:**
```bash
mvn compile exec:java -Dexec.mainClass="com.collections.core.CollectionIntroDemo"
mvn compile exec:java -Dexec.mainClass="com.collections.custom.CustomImplementations"
```

---

# SECTION 1: Introduction to Collections (Topics 1–5)

## Topic 1 — Why Collections Framework

**Problems with arrays:**
- Fixed size — cannot grow/shrink dynamically
- No built-in methods for search, sort, insert, delete
- Primitive types only (no auto-boxing at array level)

**Collections solve this:**
```java
// Array — fixed, manual management
int[] arr = new int[10];

// Collection — dynamic, rich API
List<Integer> list = new ArrayList<>();
list.add(1); list.add(2);  // grows automatically
list.sort(null);            // built-in sort
list.contains(2);           // built-in search
```

## Topic 2 — Collection Hierarchy

> **See diagram:** `diagrams/01_collection_hierarchy.png`

```
java.lang.Iterable
└── java.util.Collection
    ├── List  (ordered, duplicates allowed)
    │   ├── ArrayList
    │   ├── LinkedList
    │   └── Vector → Stack
    ├── Set   (no duplicates)
    │   ├── HashSet
    │   ├── LinkedHashSet
    │   └── TreeSet (SortedSet → NavigableSet)
    └── Queue (FIFO)
        ├── PriorityQueue
        └── Deque
            ├── ArrayDeque
            └── LinkedList

java.util.Map (SEPARATE — NOT a Collection)
├── HashMap
├── LinkedHashMap
├── TreeMap (SortedMap → NavigableMap)
├── Hashtable → Properties
├── WeakHashMap
├── IdentityHashMap
└── EnumMap
```

## Topic 3 — Iterable Interface

```java
// Iterable<T> has one method: Iterator<T> iterator()
// Implementing Iterable enables for-each loop and forEach()

class NumberRange implements Iterable<Integer> {
    int start, end;
    @Override
    public Iterator<Integer> iterator() {
        return new Iterator<>() {
            int curr = start;
            public boolean hasNext() { return curr <= end; }
            public Integer next()    { return curr++; }
        };
    }
}

// Usage
for (int n : new NumberRange(1,5)) { ... }  // for-each works!
range.forEach(n -> System.out.print(n));    // forEach works!
range.spliterator();                         // parallel support
```

## Topic 4 — Collection Interface Methods

```java
// Core operations — all implementations must support these
col.add(elem)                // add element, return true
col.addAll(collection)       // add all elements
col.remove(obj)              // remove first occurrence
col.removeAll(collection)    // remove all in collection
col.retainAll(collection)    // keep only elements in collection (intersection)
col.contains(obj)            // O(n) for List, O(1) for Set/Map
col.containsAll(collection)  // all elements present?
col.size()                   // count
col.isEmpty()                // size() == 0
col.clear()                  // remove all
col.toArray()                // convert to Object[]
col.iterator()               // get Iterator
col.forEach(action)          // Java 8: Consumer for each element
```

---

# SECTION 2: List Implementations (Topics 6–9)

## Topic 6 — ArrayList In Depth

**Internal structure:** `Object[] elementData` + `int size`

**Growth algorithm:** New capacity = `oldCapacity + (oldCapacity >> 1)` ≈ 1.5×

```java
// Capacity growth: 10 → 15 → 22 → 33 → 49 → 73 → ...
// Resize: Arrays.copyOf(elementData, newCapacity)
// Amortized O(1) for add() due to rare copies

ArrayList<String> list = new ArrayList<>();         // capacity=10
ArrayList<String> list = new ArrayList<>(50);       // pre-size avoids resizing
ArrayList<String> list = new ArrayList<>(existing); // copy constructor

list.add(elem);           // O(1) amortized (O(n) when resize needed)
list.add(index, elem);    // O(n) — shift elements right
list.get(index);          // O(1) — direct array access
list.set(index, elem);    // O(1)
list.remove(index);       // O(n) — shift elements left
list.remove(Object);      // O(n) — search + shift
list.contains(elem);      // O(n) — linear scan
list.indexOf(elem);       // O(n)
list.subList(from, to);   // O(1) — returns VIEW (not copy!)
list.sort(comp);          // O(n log n) — TimSort
list.removeIf(pred);      // Java 8 — O(n)
list.replaceAll(func);    // Java 8 — O(n)
```

**ArrayList vs LinkedList:**

| Operation | ArrayList | LinkedList |
|-----------|-----------|------------|
| get(i) | **O(1)** | O(n) |
| add(end) | **O(1) amort** | O(1) |
| add(middle) | O(n) | O(n) to find + **O(1)** |
| remove(middle) | O(n) | O(n) to find + **O(1)** |
| Memory | Less | More (prev+next pointers) |
| Cache performance | **Better** (contiguous) | Worse (scattered) |
| Use when | Random access | Frequent insert/delete |

## Topic 7 — LinkedList In Depth

**Internal:** Doubly linked list — each node has `prev`, `next`, `data`

```java
LinkedList<T> → implements List<T>, Deque<T>

// O(1) at ends
ll.addFirst(e)  / ll.offerFirst(e)   // add at head
ll.addLast(e)   / ll.offerLast(e)    // add at tail
ll.removeFirst()/ ll.pollFirst()     // remove head
ll.removeLast() / ll.pollLast()      // remove tail
ll.getFirst()   / ll.peekFirst()     // view head
ll.getLast()    / ll.peekLast()      // view tail

// O(n) — must traverse to index
ll.get(index)
ll.remove(index)
ll.add(index, elem)

// Head node: prev=null   Tail node: next=null
// Empty: head=tail=null
```

## Topic 8 — Vector (Legacy)

```java
// Vector = synchronized ArrayList
// All methods have 'synchronized' keyword → slow for single-threaded use
// Default initial capacity: 10, doubles on overflow

Vector<T> v = new Vector<>();           // default capacity=10, increment=0 (doubles)
Vector<T> v = new Vector<>(5, 10);      // capacity=5, increment=10

v.addElement(e)     // same as add()
v.elementAt(i)      // same as get()
v.removeElement(e)  // same as remove()
v.capacity()        // current array size

// Prefer over Vector:
Collections.synchronizedList(new ArrayList<>())  // for thread safety
CopyOnWriteArrayList<>()                         // for read-heavy concurrent
```

## Topic 9 — Stack (LIFO)

```java
// Legacy Stack extends Vector — all Vector methods accessible (bad OOP)
// Prefer: Deque<T> stack = new ArrayDeque<>()

Stack<T> stack = new Stack<>();
stack.push(item)   // O(1)
stack.pop()        // O(1) — removes and returns top
stack.peek()       // O(1) — view top without removing
stack.empty()      // isEmpty()
stack.search(o)    // 1-based position from top, -1 if absent

// Modern approach (ArrayDeque is faster — no synchronization)
Deque<T> stack = new ArrayDeque<>();
stack.push(item)   // addFirst()
stack.pop()        // removeFirst()
stack.peek()       // peekFirst()
```

**Common stack problems:**
- Balanced parentheses — push open, match with close
- Evaluate postfix expression
- Next greater element — monotonic stack
- Largest rectangle in histogram

---

# SECTION 3: Queue Implementations (Topics 10–12)

## Topic 10-11 — Queue & PriorityQueue

```java
// Queue — FIFO (first in, first out)
Queue<T> q = new LinkedList<>();    // or ArrayDeque

// Method pairs — exception vs return null
q.offer(e)  vs q.add(e)     // add to tail (offer=safe, add=throws if full)
q.poll()    vs q.remove()   // remove head (poll=null if empty, remove=throws)
q.peek()    vs q.element()  // view head (peek=null if empty, element=throws)

// PriorityQueue — Min-Heap by default
PriorityQueue<Integer> minHeap = new PriorityQueue<>();
PriorityQueue<Integer> maxHeap = new PriorityQueue<>(Collections.reverseOrder());
PriorityQueue<T> custom = new PriorityQueue<>(Comparator.comparing(T::field));

// Heap operations
heap.offer(e)    // O(log n) — heapify up
heap.poll()      // O(log n) — extract min + heapify down
heap.peek()      // O(1)     — view min

// Top-K pattern
PriorityQueue<Integer> topK = new PriorityQueue<>();  // min-heap
for (int n : array) {
    topK.offer(n);
    if (topK.size() > k) topK.poll();  // remove smallest
}
// topK contains k largest elements
```

## Topic 12 — Deque

```java
// Deque = Double-Ended Queue — add/remove at both ends
Deque<T> deque = new ArrayDeque<>();  // preferred (faster than LinkedList)

deque.offerFirst(e) / deque.offerLast(e)   // add
deque.pollFirst()   / deque.pollLast()     // remove
deque.peekFirst()   / deque.peekLast()     // view

// As Stack: push(e)=addFirst(), pop()=removeFirst(), peek()=peekFirst()
// As Queue: offer(e)=addLast(), poll()=removeFirst(), peek()=peekFirst()

// ArrayDeque vs LinkedList:
// - ArrayDeque: resizable circular array, no null, faster cache
// - LinkedList: each node separately allocated, allows null
```

---

# SECTION 4: Set Implementations (Topics 13–16)

## Topic 14 — HashSet In Depth

**Internal:** `HashMap<E, PRESENT>` — element stored as map key, value is dummy constant.

```java
// hashCode() + equals() CONTRACT — MUST implement for custom objects!
// Rule 1: a.equals(b)  →  a.hashCode() == b.hashCode()  (always!)
// Rule 2: a.hashCode() == b.hashCode()  →  a.equals(b) may be FALSE (collision OK)

@Override
public boolean equals(Object o) {
    if (!(o instanceof Point)) return false;
    Point p = (Point)o;
    return x==p.x && y==p.y;
}

@Override
public int hashCode() { return Objects.hash(x, y); }  // combine fields

// Set operations
Set<Integer> a = new HashSet<>(Arrays.asList(1,2,3,4,5));
Set<Integer> b = new HashSet<>(Arrays.asList(3,4,5,6,7));

// Union: a.addAll(b)
// Intersection: a.retainAll(b)
// Difference: a.removeAll(b)
// Subset: b.containsAll(a)
```

## Topic 15 — LinkedHashSet

```java
// Backed by LinkedHashMap — maintains insertion order
// Same O(1) performance as HashSet
LinkedHashSet<String> lhs = new LinkedHashSet<>();
lhs.add("C"); lhs.add("A"); lhs.add("B");
// Iteration: always C, A, B (insertion order preserved)
```

## Topic 16 — TreeSet

```java
// Backed by Red-Black tree — always sorted
TreeSet<Integer> ts = new TreeSet<>(); // natural order
TreeSet<T> ts = new TreeSet<>(comparator); // custom order

// NavigableSet methods — unique to TreeSet!
ts.first()        // smallest
ts.last()         // largest
ts.floor(e)       // greatest element ≤ e
ts.ceiling(e)     // smallest element ≥ e
ts.lower(e)       // greatest element strictly < e
ts.higher(e)      // smallest element strictly > e
ts.subSet(lo, hi) // elements between lo (inclusive) and hi (exclusive)
ts.headSet(e)     // elements strictly less than e
ts.tailSet(e)     // elements greater than or equal to e
ts.descendingSet()// reverse order view

// All O(log n): add, remove, contains
// No null elements (NPE since null can't be compared)
```

---

# SECTION 5: Map Implementations (Topics 17–25)

## Topic 18 — HashMap In Depth

> **See diagram:** `diagrams/02_hashmap_internals.png`

**Internal structure:** `Node<K,V>[] table` (array of linked lists, becoming trees)

```java
// put(key, value) algorithm:
// 1. hash = key.hashCode() ^ (hash >>> 16)  // spread high bits to low
// 2. bucket = hash & (capacity - 1)          // fast modulo
// 3. Check bucket:
//    - Empty → new Node
//    - Key exists → update value
//    - Collision → append to chain (or insert in tree)
// 4. If chain length ≥ 8 → convert to TreeNode (Red-Black tree)  [Java 8]
// 5. If size > capacity × 0.75 → resize (double capacity, rehash all)

// Key settings
new HashMap<>()             // capacity=16, loadFactor=0.75
new HashMap<>(capacity)     // custom initial capacity
new HashMap<>(cap, factor)  // custom capacity and load factor

// Java 8 operations
map.getOrDefault(key, def)              // safe get
map.putIfAbsent(key, value)             // only if absent
map.merge(key, val, mergeFn)            // combine existing + new
map.compute(key, (k,v) -> newVal)       // compute new value
map.computeIfAbsent(key, k -> val)      // compute if absent
map.computeIfPresent(key, (k,v) -> val) // compute if present
map.replaceAll((k,v) -> transform(v))   // transform all values
map.forEach((k,v) -> action)            // iterate
```

## Topic 19 — LinkedHashMap + LRU Cache

```java
// LinkedHashMap maintains doubly-linked list of entries

// Insertion order (default accessOrder=false)
LinkedHashMap<K,V> insertMap = new LinkedHashMap<>();

// Access order (LRU pattern) — accessOrder=true
LinkedHashMap<K,V> lruMap = new LinkedHashMap<>(16, 0.75f, true);
// get() moves entry to end (most recently used)

// LRU Cache implementation
class LRUCache<K,V> extends LinkedHashMap<K,V> {
    private final int capacity;
    LRUCache(int cap) { super(cap, 0.75f, true); this.capacity=cap; }

    @Override
    protected boolean removeEldestEntry(Map.Entry<K,V> eldest) {
        return size() > capacity;  // auto-evict when over capacity
    }
}
```

## Topic 20 — TreeMap

```java
// Backed by Red-Black tree — O(log n) all operations
// Maintains keys in natural order (or custom Comparator)

TreeMap<K,V> map = new TreeMap<>();               // natural key order
TreeMap<K,V> map = new TreeMap<>(comparator);     // custom order

// NavigableMap methods
map.firstKey() / map.lastKey()
map.floorKey(k) / map.ceilingKey(k)
map.lowerKey(k) / map.higherKey(k)
map.headMap(k)  / map.tailMap(k)
map.subMap(from, fromInclusive, to, toInclusive)
map.descendingMap()     // reverse order view
map.entrySet()          // sorted entry iteration
```

---

# SECTION 6: Comparable vs Comparator (Topics 26–28)

## Topic 26 — Comparable Interface

```java
// Natural ordering — implement inside the class
class Student implements Comparable<Student> {
    String name; int age; double gpa;

    @Override
    public int compareTo(Student other) {
        return this.name.compareTo(other.name); // natural: alphabetical
    }
}

Collections.sort(students);    // uses compareTo() automatically
Arrays.sort(students);         // same
```

## Topic 27 — Comparator Interface

```java
// External/custom ordering — defined outside the class
// Enables multiple different orderings for the same class

// Lambda comparator
Comparator<Student> byGPA = (a, b) -> Double.compare(b.gpa, a.gpa); // desc

// Method reference style
Comparator<Student> byName   = Comparator.comparing(Student::name);
Comparator<Student> byAge    = Comparator.comparingInt(Student::age);
Comparator<Student> byGPAasc = Comparator.comparingDouble(Student::gpa);

// Chaining (multi-field sort)
students.sort(Comparator.comparingInt(Student::age)
                        .thenComparingDouble(Student::gpa)
                        .reversed());

// Null-safe comparators
Comparator<String> nullFirst = Comparator.nullsFirst(Comparator.naturalOrder());
```

## Topic 28 — Comparable vs Comparator

| Feature | Comparable | Comparator |
|---------|-----------|------------|
| Location | Inside the class | External class/lambda |
| Package | `java.lang` | `java.util` |
| Method | `compareTo(T o)` | `compare(T o1, T o2)` |
| Sort usage | `Collections.sort(list)` | `Collections.sort(list, comp)` |
| Multiple orderings | NO | YES |
| Modifying class | Required | Not required |
| Natural order | Defines it | Overrides it |

---

# SECTION 7: Java 8 Features (Topics 30–34)

## Topic 31 — Stream API In Depth

> **See diagram:** `diagrams/03_stream_api.png`

```java
// Stream pipeline: Source → Intermediate (lazy) → Terminal (triggers execution)

// SOURCES
collection.stream()                          // from Collection
collection.parallelStream()                  // parallel processing
Arrays.stream(arr)                           // from array
Stream.of(a, b, c)                          // from values
Stream.generate(Supplier)                    // infinite from supplier
Stream.iterate(seed, UnaryOperator)          // infinite from seed + fn
IntStream.range(1, 10)                       // 1..9
IntStream.rangeClosed(1, 10)                 // 1..10

// INTERMEDIATE (lazy — not executed until terminal)
.filter(predicate)      // keep matching
.map(function)          // transform each element
.mapToInt/Long/Double() // to primitive stream
.flatMap(function)      // flatten nested streams
.sorted()               // natural order
.sorted(comparator)     // custom order
.distinct()             // remove duplicates (uses equals)
.limit(n)               // take first n
.skip(n)                // skip first n
.peek(consumer)         // debug: inspect without modifying

// TERMINAL (triggers execution)
.collect(Collectors.toList())     // collect to list
.collect(Collectors.toSet())      // collect to set
.collect(Collectors.toMap(k,v))   // collect to map
.forEach(consumer)                // side effect per element
.reduce(identity, BinaryOperator) // fold to single value
.count()                          // count elements
.findFirst()                      // Optional<T> first match
.findAny()                        // Optional<T> any match (parallel-friendly)
.anyMatch(predicate)              // true if any match
.allMatch(predicate)              // true if all match
.noneMatch(predicate)             // true if none match
.min(comparator)                  // Optional minimum
.max(comparator)                  // Optional maximum
.toArray()                        // to Object[]
```

## Topic 32 — Collectors Class

```java
// Grouping
Map<String,List<T>> byDept = stream.collect(Collectors.groupingBy(T::getDept));
Map<String,Long>    counts = stream.collect(Collectors.groupingBy(T::getDept, Collectors.counting()));
Map<String,Double>  avgSal = stream.collect(Collectors.groupingBy(T::getDept, Collectors.averagingDouble(T::getSalary)));

// Partitioning (boolean split)
Map<Boolean,List<T>> split = stream.collect(Collectors.partitioningBy(pred));

// Joining
String joined = stream.collect(Collectors.joining(", ", "[", "]"));

// Statistics
IntSummaryStatistics stats = stream.collect(Collectors.summarizingInt(T::getScore));
// stats.getCount(), getSum(), getMin(), getMax(), getAverage()

// toMap with merge function (handle duplicate keys)
Map<K,V> map = stream.collect(Collectors.toMap(T::key, T::val, (v1,v2) -> v1));

// Downstream collectors
Map<Dept, Optional<Emp>> topEarner = stream.collect(
    Collectors.groupingBy(Emp::dept, Collectors.maxBy(Comparator.comparing(Emp::salary))));
```

---

# SECTION 8: Concurrent Collections (Topics 35–37)

## Topic 35 — ConcurrentHashMap

> **See diagram:** `diagrams/04_concurrent_collections.png`

```java
// Java 7: 16 segments, each a mini HashMap with its own lock
// Java 8: CAS (lock-free) + synchronized on individual bins (no segments)

ConcurrentHashMap<K,V> map = new ConcurrentHashMap<>();

// Atomic operations
map.putIfAbsent(key, value)              // atomic check-then-put
map.computeIfAbsent(key, fn)             // compute if absent (atomic)
map.computeIfPresent(key, (k,v)->newV)   // update if present (atomic)
map.merge(key, val, BiFunction)          // merge value (atomic)

// Bulk operations (Java 8) — with parallelism threshold
map.forEach(threshold, (k,v) -> action)
map.search(threshold, (k,v) -> result)
map.reduce(threshold, transformer, reducer)

// Thread-safe size (approximate — no global lock)
map.size()      // approximate
map.mappingCount() // more accurate long count

// NOT allowed: null keys or null values
```

## Topic 36 — Fail-Fast vs Fail-Safe

```java
// Fail-FAST: ArrayList, HashMap, HashSet iterators
// - Throw ConcurrentModificationException if structurally modified during iteration
// - Detected via modCount: saved at iterator creation, checked on each next()

Iterator<T> it = list.iterator();
while (it.hasNext()) {
    T item = it.next();
    if (condition) it.remove();    // SAFE — uses iterator's own remove
    // list.remove(item);          // UNSAFE — direct list modification throws CME
}

// Java 8 removeIf() — safe bulk removal
list.removeIf(e -> condition);

// Fail-SAFE: CopyOnWriteArrayList, ConcurrentHashMap iterators
// - Work on snapshot or weakly consistent — no exception
// - CopyOnWrite: snapshot copied on write, iterator sees original snapshot
// - ConcurrentHashMap: weakly consistent — may or may not see concurrent modifications
```

---

# SECTION 9: Custom Implementations (Topic 39)

## MyArrayList — Key Code

```java
// Backing: Object[] data, int size
void add(T elem) {
    if (size == data.length) grow();             // resize if full
    data[size++] = elem;
}

void grow() {
    data = Arrays.copyOf(data, data.length + data.length/2 + 1); // 1.5×
}

T get(int i)     { return (T) data[i]; }          // O(1) direct access
void remove(i)   { System.arraycopy(data, i+1, data, i, size-i-1); size--; } // O(n) shift
```

## MyLinkedList — Key Code

```java
// Node has: T data, Node<T> prev, Node<T> next
// Maintains head and tail pointers

void addFirst(T data) {
    Node<T> n = new Node<>(data);
    n.next = head; if (head != null) head.prev = n;
    head = n; if (tail == null) tail = n;
    size++;
}
```

## MyMinHeap — Key Code

```java
// Array representation: parent(i)=(i-1)/2, left=2i+1, right=2i+2

void insert(int val) {
    heap[size++] = val;
    heapifyUp(size-1);              // bubble up to restore heap property
}

void heapifyUp(int i) {
    while (i > 0) {
        int parent = (i-1)/2;
        if (heap[parent] > heap[i]) { swap(i, parent); i = parent; }
        else break;
    }
}

int extractMin() {
    int min = heap[0];
    heap[0] = heap[--size];        // move last to root
    heapifyDown(0);                // sink down to restore
    return min;
}
```

## Custom HashMap — Key Code

```java
// Entry<K,V>[] table (chaining for collision)

void put(K key, V value) {
    int bucket = Math.abs(key.hashCode() ^ (key.hashCode()>>>16)) & (capacity-1);
    Entry head = table[bucket];
    for (Entry e = head; e != null; e = e.next)
        if (key.equals(e.key)) { e.value=value; return; } // update
    Entry newEntry = new Entry(key, value);
    newEntry.next = head; table[bucket] = newEntry;        // prepend
    if (++size > capacity * 0.75) resize();                // rehash
}
```

---

# SECTION 10: Time Complexity Reference (Topic 40)

## List Complexities

| Operation | ArrayList | LinkedList |
|-----------|-----------|------------|
| get(i) | **O(1)** | O(n) |
| add(end) | **O(1)** amort | **O(1)** |
| add(head) | O(n) | **O(1)** |
| add(middle) | O(n) | O(n)* |
| remove(i) | O(n) | O(n)* |
| contains | O(n) | O(n) |
| size | O(1) | O(1) |

*O(1) if reference known, O(n) to find it

## Set Complexities

| Operation | HashSet | LinkedHashSet | TreeSet |
|-----------|---------|--------------|---------|
| add | O(1) avg | O(1) avg | **O(log n)** |
| remove | O(1) avg | O(1) avg | **O(log n)** |
| contains | O(1) avg | O(1) avg | **O(log n)** |
| iteration | O(n) | O(n) ordered | O(n) sorted |

## Map Complexities

| Operation | HashMap | LinkedHashMap | TreeMap |
|-----------|---------|--------------|---------|
| put | O(1) avg | O(1) avg | **O(log n)** |
| get | O(1) avg | O(1) avg | **O(log n)** |
| remove | O(1) avg | O(1) avg | **O(log n)** |
| containsKey | O(1) avg | O(1) avg | **O(log n)** |
| Ordering | None | Insertion/Access | **Sorted** |

---

# 100+ Interview Questions & Answers

## Java Basics (Q1–Q10)

**Q1. What is the difference between Collection and Collections?**
`Collection` is the root interface (List, Set, Queue extend it). `Collections` is a utility class with static methods like `sort()`, `reverse()`, `binarySearch()`, `synchronizedList()`.

**Q2. Why doesn't Map extend Collection?**
Map stores key-value pairs while Collection stores individual elements. They have different fundamental contracts — map operations (get, put, containsKey) don't align with Collection's element-based interface.

**Q3. What is the difference between Iterable and Iterator?**
`Iterable` — the collection that can be iterated; has `iterator()` method. `Iterator` — the cursor object with `hasNext()`, `next()`, `remove()`. Each `iterator()` call creates a new Iterator from the beginning.

**Q4. What is a fail-fast iterator?**
Throws `ConcurrentModificationException` if the collection is structurally modified (add/remove) during iteration, unless using the iterator's own `remove()`. Detected via `modCount` counter.

**Q5. Difference between `size()` and `capacity()`?**
`size()` = actual number of elements currently stored. `capacity()` = allocated array size (internal, only Vector/ArrayList expose it). `size ≤ capacity` always.

**Q6. Can we have null in collections?**
ArrayList, LinkedList, HashSet, HashMap: **YES** (HashMap allows one null key, multiple null values). TreeSet, TreeMap: **NO** (null breaks compareTo). ConcurrentHashMap: **NO** (NPE on null key/value). PriorityQueue: **NO**.

**Q7. What is the difference between `remove(int index)` and `remove(Object o)` in ArrayList?**
`remove(int)` — removes by position (index), returns the removed element. `remove(Object)` — removes first occurrence by value using equals(). For Integer lists: `list.remove(Integer.valueOf(5))` removes value 5, `list.remove(5)` removes index 5.

**Q8. What is `Arrays.asList()` and its limitations?**
Returns a fixed-size List backed by the array. You can `set()` (modify), but cannot `add()` or `remove()` — throws `UnsupportedOperationException`. To get a mutable copy: `new ArrayList<>(Arrays.asList(arr))`.

**Q9. What is `Collections.emptyList()` vs `Collections.singletonList()`?**
`emptyList()` — immutable empty list, shared instance (no allocation). `singletonList(e)` — immutable single-element list. Both are read-only — all mutation methods throw UnsupportedOperationException.

**Q10. What is a marker interface? Give collection examples.**
Interface with no methods — used to signal capability. Examples: `Serializable`, `Cloneable`, `RandomAccess`. `RandomAccess` marks lists with O(1) access (ArrayList implements it, LinkedList does not).

---

## ArrayList & LinkedList (Q11–Q25)

**Q11. How does ArrayList resize?**
When `size == capacity`, creates new array with `capacity × 1.5 + 1`, copies all elements. Default capacity: 10. Can pre-size with `new ArrayList<>(expectedSize)` to avoid resizing.

**Q12. What is the time complexity of ArrayList.add(index, e)?**
O(n) — must shift all elements from `index` to `size-1` one position right to make room.

**Q13. Is ArrayList thread-safe?**
No. Use `Collections.synchronizedList(new ArrayList<>())` or `CopyOnWriteArrayList` for thread safety.

**Q14. What is the difference between `Iterator.remove()` and `list.remove()`?**
`Iterator.remove()` is safe during iteration (updates modCount correctly). `list.remove()` during iteration causes `ConcurrentModificationException`.

**Q15. How does LinkedList implement both List and Deque?**
LinkedList maintains `head` and `tail` pointers to `Node` objects. List operations use index traversal. Deque operations use direct head/tail pointer manipulation (O(1)).

**Q16. When should you prefer LinkedList over ArrayList?**
When you have many insertions/deletions at the beginning or middle of the list, AND you don't need random access. In practice, ArrayList is usually faster due to better cache locality.

**Q17. What is `ListIterator` and how is it different from `Iterator`?**
`ListIterator` is bidirectional — supports `hasPrevious()`, `previous()`, `add()`, `set()`. Only works on List types. Allows modification during traversal via its own add/set/remove methods.

---

## HashMap Internals (Q26–Q40)

**Q26. How does HashMap work internally?**
See diagram `02_hashmap_internals.png`. hash → spread → bucket index → LinkedList/TreeNode chain. Java 8: chain converts to Red-Black tree when length ≥ 8.

**Q27. What is the significance of hashCode() and equals()?**
HashMap uses `hashCode()` to find the bucket (fast O(1) lookup), then `equals()` to find the exact key within the bucket. If only equals is overridden without hashCode, equal objects may go to different buckets.

**Q28. What happens when two keys have the same hash?**
Collision handling via chaining: both entries stored in same bucket as a LinkedList. get() traverses the chain using equals() to find the right key.

**Q29. What is load factor in HashMap?**
Ratio of entries to capacity. Default 0.75 (resize when 75% full). Higher load factor: less memory, more collisions. Lower: more memory, fewer collisions. Resize doubles capacity and rehashes all entries.

**Q30. What is treeification in Java 8 HashMap?**
When a bucket's chain length reaches 8, it converts from LinkedList to Red-Black tree. This improves worst-case performance from O(n) to O(log n) for highly skewed hash distributions.

**Q31. How is ConcurrentHashMap different from synchronized HashMap?**
`Collections.synchronizedMap()` locks the entire map for every operation (coarse lock). `ConcurrentHashMap` in Java 8 uses CAS operations and bin-level locks — multiple threads can write to different bins simultaneously. Much better throughput.

**Q32. Can HashMap have duplicate keys?**
No. Putting with an existing key updates the value. Keys are compared using hashCode() + equals(). Values CAN be duplicates.

**Q33. What is `computeIfAbsent` and when to use it?**
Atomically computes value for a key only if absent. Safe for initializing default structures: `map.computeIfAbsent(key, k -> new ArrayList<>()).add(value)` — creates list if absent then adds.

---

## Set Questions (Q41–Q50)

**Q41. How is HashSet implemented internally?**
Backed by `HashMap<E, PRESENT>` where PRESENT is a dummy constant. `add(e)` calls `map.put(e, PRESENT)`. `contains(e)` calls `map.containsKey(e)`. All O(1) average.

**Q42. Why must you override hashCode() when overriding equals()?**
Contract: if `a.equals(b)` is true, then `a.hashCode()` must equal `b.hashCode()`. If you break this, HashSet/HashMap can store "duplicates" (two equal objects in different buckets).

**Q43. Difference between HashSet and TreeSet?**
HashSet: O(1) operations, no ordering, allows null. TreeSet: O(log n) operations, always sorted, no null, implements NavigableSet.

**Q44. When would you use LinkedHashSet?**
When you need a Set (no duplicates, O(1) operations) AND you need to maintain insertion order during iteration. Example: keeping unique user IDs in visit order.

---

## Stream API (Q51–Q65)

**Q51. What is a Stream?**
A sequence of elements supporting sequential and parallel aggregate operations. Not a data structure — doesn't store elements. Lazy — intermediate ops not executed until terminal op is called.

**Q52. Difference between `map()` and `flatMap()`?**
`map()` — 1-to-1 transformation: each element maps to one result. `flatMap()` — 1-to-many: each element maps to a stream, all streams flattened to one. Example: `List<List<T>>` → `List<T>` via `flatMap(Collection::stream)`.

**Q53. What is the difference between `findFirst()` and `findAny()`?**
`findFirst()` — returns first element (deterministic, respects encounter order). `findAny()` — returns any element (non-deterministic, better for parallel streams). Both return `Optional<T>`.

**Q54. How do parallel streams work?**
Uses Fork/Join framework. The Spliterator splits the stream into sub-streams processed in parallel by the common pool. Use when: CPU-bound work, large datasets, no shared mutable state.

**Q55. What is `Optional` and why use it?**
Container for a potentially-null value. Forces callers to handle absence explicitly — reduces NPE. `Optional.of(v)` — non-null value. `Optional.ofNullable(v)` — may be null. `Optional.empty()`.

**Q56. Explain `reduce()` operation.**
```java
// Fold stream into single result
int sum  = stream.reduce(0, Integer::sum);    // identity + accumulator
int prod = stream.reduce(1, (a,b) -> a*b);    // without identity → Optional
// Optional<Integer> max = stream.reduce(Integer::max);
```

---

## Concurrent Collections (Q66–Q80)

**Q66. What is the difference between Hashtable and HashMap?**
Hashtable: synchronized (all methods), no null keys/values, legacy (Java 1.0). HashMap: not synchronized, one null key allowed, faster, modern. Prefer HashMap + ConcurrentHashMap.

**Q67. What is CopyOnWriteArrayList?**
Thread-safe ArrayList variant. On every write (add/remove/set), a fresh copy of the underlying array is made. Reads are non-blocking and very fast. Suitable for read-heavy, write-rare scenarios (e.g., event listener lists).

**Q68. What is BlockingQueue?**
Queue that blocks when trying to dequeue from empty queue (until element available) or enqueue to full queue (until space available). Perfect for producer-consumer pattern without explicit synchronization.

**Q69. What is the difference between `poll()` and `take()` in BlockingQueue?**
`poll()` — returns null if queue empty (non-blocking). `take()` — blocks until element available. `poll(timeout, unit)` — waits up to timeout then returns null.

---

## Coding Problems (Q81–Q100)

**Q81. Implement a frequency counter using HashMap:**
```java
Map<String,Integer> freq = new HashMap<>();
for (String word : words) freq.merge(word, 1, Integer::sum);
// or: freq.put(word, freq.getOrDefault(word,0)+1);
```

**Q82. Find top-K frequent elements:**
```java
Map<Integer,Integer> freq = new HashMap<>();
for (int n : nums) freq.merge(n, 1, Integer::sum);
PriorityQueue<Integer> heap = new PriorityQueue<>(Comparator.comparingInt(freq::get));
for (int key : freq.keySet()) {
    heap.offer(key);
    if (heap.size() > k) heap.poll();
}
```

**Q83. Detect duplicate in array (O(n)):**
```java
Set<Integer> seen = new HashSet<>();
for (int n : nums) if (!seen.add(n)) return true; // add returns false for dup
return false;
```

**Q84. Group anagrams:**
```java
Map<String,List<String>> groups = new HashMap<>();
for (String s : strs) {
    char[] arr = s.toCharArray(); Arrays.sort(arr);
    String key = new String(arr);
    groups.computeIfAbsent(key, k -> new ArrayList<>()).add(s);
}
return new ArrayList<>(groups.values());
```

**Q85. Implement LRU Cache:**
```java
class LRUCache extends LinkedHashMap<Integer,Integer> {
    private final int capacity;
    LRUCache(int cap) { super(cap, 0.75f, true); this.capacity=cap; }
    protected boolean removeEldestEntry(Map.Entry<Integer,Integer> e) {
        return size() > capacity;
    }
}
```

**Q86. Find first non-repeating character:**
```java
Map<Character,Integer> freq = new LinkedHashMap<>();  // insertion order!
for (char c : s.toCharArray()) freq.merge(c, 1, Integer::sum);
for (Map.Entry<Character,Integer> e : freq.entrySet())
    if (e.getValue() == 1) return e.getKey();
return '\0';
```

**Q87. Sort employees by department then salary:**
```java
employees.sort(Comparator.comparing(Employee::getDept)
                         .thenComparingDouble(Employee::getSalary)
                         .reversed());
```

**Q88. Count words in sentence using Stream:**
```java
Map<String,Long> wordCount = Arrays.stream(sentence.split("\\s+"))
    .collect(Collectors.groupingBy(w -> w.toLowerCase(), Collectors.counting()));
```

**Q89. Flatten nested list:**
```java
List<Integer> flat = nested.stream()
    .flatMap(Collection::stream)
    .collect(Collectors.toList());
```

**Q90. Find second largest element:**
```java
Optional<Integer> secondLargest = nums.stream()
    .distinct()
    .sorted(Comparator.reverseOrder())
    .skip(1)
    .findFirst();
```

---

# Choosing the Right Collection

| Need | Use |
|------|-----|
| Fast random access, ordered | `ArrayList` |
| Frequent insert/delete at ends | `ArrayDeque` or `LinkedList` |
| No duplicates, fast lookup | `HashSet` |
| No duplicates, sorted | `TreeSet` |
| No duplicates, insertion order | `LinkedHashSet` |
| Key-value, fast lookup | `HashMap` |
| Key-value, sorted by key | `TreeMap` |
| Key-value, insertion order | `LinkedHashMap` |
| Key-value, thread-safe | `ConcurrentHashMap` |
| Priority ordering | `PriorityQueue` |
| Producer-consumer | `ArrayBlockingQueue` |
| Read-heavy concurrent list | `CopyOnWriteArrayList` |
| LRU cache | `LinkedHashMap` (accessOrder=true) |
| Enum keys | `EnumMap` |
| Enum set | `EnumSet` |

---

*Java Collections Framework — Complete Tutorial | 52 Topics | 8 Java Files | 5 Diagrams*
