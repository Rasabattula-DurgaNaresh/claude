# 100 Sliding Window Problems in Java — Complete Solutions

> **100 Problems · 5 Java files · 5 PNG diagrams · Pattern templates + complexity analysis**

---

## Diagram Index

| Diagram | Topic |
|---------|-------|
| `diagrams/01_fixed_window.png` | Fixed window mechanics & template |
| `diagrams/02_variable_window.png` | Variable expand/contract templates |
| `diagrams/03_monotonic_deque.png` | Deque-based max/min in O(n) |
| `diagrams/04_two_heaps.png` | Two-heap pattern for sliding median |
| `diagrams/05_pattern_decision.png` | Master decision tree for all patterns |

---

## Core Pattern Templates

### Fixed Window — O(n) time, O(1) space
```java
int windowSum = 0;
for (int i = 0; i < k; i++) windowSum += arr[i];   // build first window
int result = windowSum;
for (int i = k; i < n; i++) {
    windowSum += arr[i] - arr[i - k];               // slide
    result = Math.max(result, windowSum);            // update
}
```

### Variable Window (Find Longest) — O(n) time
```java
int left = 0, maxLen = 0;
for (int right = 0; right < n; right++) {
    // EXPAND: add arr[right] to window state
    while (isInvalid(windowState)) {
        // SHRINK: remove arr[left]
        left++;
    }
    maxLen = Math.max(maxLen, right - left + 1);
}
```

### Variable Window (Find Shortest) — O(n) time
```java
int left = 0, minLen = Integer.MAX_VALUE;
for (int right = 0; right < n; right++) {
    // EXPAND: add arr[right]
    while (isValid(windowState)) {
        minLen = Math.min(minLen, right - left + 1);
        // SHRINK: remove arr[left]
        left++;
    }
}
```

### Monotonic Deque — O(n) time, O(k) space
```java
Deque<Integer> dq = new ArrayDeque<>();
for (int i = 0; i < n; i++) {
    while (!dq.isEmpty() && dq.peekFirst() < i - k + 1) dq.pollFirst(); // stale
    while (!dq.isEmpty() && arr[dq.peekLast()] <= arr[i]) dq.pollLast(); // dominated
    dq.offerLast(i);
    if (i >= k - 1) result[i - k + 1] = arr[dq.peekFirst()]; // max at front
}
```

### atMost Trick (Count Exact = Count AtMost(K) - AtMost(K-1))
```java
// count subarrays with EXACTLY K distinct
int exactly(int[] arr, int k) {
    return atMost(arr, k) - atMost(arr, k - 1);
}
int atMost(int[] arr, int k) {
    Map<Integer,Integer> freq = new HashMap<>();
    int left = 0, count = 0;
    for (int right = 0; right < arr.length; right++) {
        freq.merge(arr[right], 1, Integer::sum);
        while (freq.size() > k) {
            int lv = arr[left++];
            freq.put(lv, freq.get(lv) - 1);
            if (freq.get(lv) == 0) freq.remove(lv);
        }
        count += right - left + 1;
    }
    return count;
}
```

### Two Heaps (Sliding Median) — O(n log k) time, O(k) space
```java
PriorityQueue<Integer> lo = new PriorityQueue<>(Collections.reverseOrder()); // max-heap
PriorityQueue<Integer> hi = new PriorityQueue<>();                           // min-heap
// Invariant: lo.size() == hi.size() or lo.size() == hi.size() + 1
// Median: odd K → lo.peek(), even K → (lo.peek() + hi.peek()) / 2.0
```

---

## Pattern Selection Guide

| Problem Says | Pattern | Time | Space |
|-------------|---------|------|-------|
| Fixed size K + sum/avg/max | Fixed window | O(n) | O(1) |
| Max/min in every window | Monotonic deque | O(n) | O(k) |
| Longest with constraint | Variable expand | O(n) | O(1)–O(n) |
| Shortest with constraint | Variable contract | O(n) | O(1) |
| Count with exactly K | atMost(K) - atMost(K-1) | O(n) | O(n) |
| Median in window | Two heaps + lazy delete | O(n log k) | O(k) |
| Max/min + range constraint | Two deques (max+min) | O(n) | O(k) |
| Weighted/circular | Prefix sum + deque | O(n) | O(n) |

---

# BEGINNER — Fixed Window (Problems 1–20)

## P1. Maximum Sum Subarray of Size K
**Pattern:** Fixed window, running sum  
**LeetCode:** 643 variant

```java
public static int maxSumSubarrayK(int[] arr, int k) {
    int windowSum = 0;
    for (int i = 0; i < k; i++) windowSum += arr[i];
    int maxSum = windowSum;
    for (int i = k; i < arr.length; i++) {
        windowSum += arr[i] - arr[i - k]; // slide: add right, drop left
        maxSum = Math.max(maxSum, windowSum);
    }
    return maxSum;
}
// arr=[2,1,5,1,3,2] k=3 → 9 ([5,1,3])
// Time: O(n), Space: O(1)
```

---

## P2. Average of All Subarrays of Size K
**Pattern:** Fixed window, maintain running sum

```java
public static double[] avgSubarrayK(int[] arr, int k) {
    double[] result = new double[arr.length - k + 1];
    double sum = 0;
    for (int i = 0; i < k; i++) sum += arr[i];
    result[0] = sum / k;
    for (int i = k; i < arr.length; i++) {
        sum += arr[i] - arr[i - k];
        result[i - k + 1] = sum / k;
    }
    return result;
}
// Time: O(n), Space: O(n-k+1)
```

---

## P3. First Negative Integer in Every Window of Size K
**Pattern:** Fixed window + Deque to track indices of negatives

```java
public static long[] firstNegativeInWindow(long[] arr, int k) {
    long[] result = new long[arr.length - k + 1];
    Deque<Integer> dq = new ArrayDeque<>(); // stores indices of negatives
    for (int i = 0; i < k; i++) if (arr[i] < 0) dq.offerLast(i);
    for (int i = k; i <= arr.length; i++) {
        result[i - k] = dq.isEmpty() ? 0 : arr[dq.peekFirst()];
        if (!dq.isEmpty() && dq.peekFirst() <= i - k) dq.pollFirst(); // stale
        if (i < arr.length && arr[i] < 0) dq.offerLast(i);
    }
    return result;
}
// arr=[-8,2,3,-6,10] k=2 → [-8,0,-6,-6]
```

---

## P4. Count Occurrences of Anagrams
**Pattern:** Fixed window of length |pattern|, frequency array comparison

```java
public static int countAnagrams(String s, String pat) {
    int[] need = new int[26], window = new int[26];
    for (char c : pat.toCharArray()) need[c - 'a']++;
    int k = pat.length(), count = 0;
    for (int i = 0; i < k; i++) window[s.charAt(i) - 'a']++;
    if (Arrays.equals(need, window)) count++;
    for (int i = k; i < s.length(); i++) {
        window[s.charAt(i) - 'a']++;
        window[s.charAt(i - k) - 'a']--;
        if (Arrays.equals(need, window)) count++;
    }
    return count;
}
// "cbaebabacd","abc" → 2
```

---

## P5. Maximum Element in Every Window of Size K
**Pattern:** Monotonic deque — decreasing, max at front

```java
public static int[] maxInWindows(int[] arr, int k) {
    int n = arr.length;
    int[] result = new int[n - k + 1];
    Deque<Integer> dq = new ArrayDeque<>(); // stores indices
    for (int i = 0; i < n; i++) {
        while (!dq.isEmpty() && dq.peekFirst() < i - k + 1) dq.pollFirst(); // stale
        while (!dq.isEmpty() && arr[dq.peekLast()] <= arr[i]) dq.pollLast(); // dominated
        dq.offerLast(i);
        if (i >= k - 1) result[i - k + 1] = arr[dq.peekFirst()];
    }
    return result;
}
// [1,3,-1,-3,5,3,6,7] k=3 → [3,3,5,5,6,7]
// Key: each element pushed/popped at most once → O(n)
```

---

## P6. Minimum Element in Every Window of Size K
**Pattern:** Monotonic deque — increasing, min at front

```java
// Same as P5 but change <= to >= in the dominated check
while (!dq.isEmpty() && arr[dq.peekLast()] >= arr[i]) dq.pollLast();
// [1,3,-1,-3,5,3,6,7] k=3 → [-1,-3,-3,-3,3,3]
```

---

## P7. Find All Subarrays of Size K with Given Sum
**Approach:** Fixed window, check equality

```java
for (int i = k; i < arr.length; i++) {
    windowSum += arr[i] - arr[i - k];
    if (windowSum == target) result.add(new int[]{i - k + 1, i});
}
```

---

## P8. Distinct Elements in Every Window
**Pattern:** Fixed window + HashMap for frequency

```java
public static int[] distinctInWindows(int[] arr, int k) {
    Map<Integer, Integer> freq = new HashMap<>();
    // Build first window
    for (int i = 0; i < k; i++) freq.merge(arr[i], 1, Integer::sum);
    result[0] = freq.size();
    for (int i = k; i < arr.length; i++) {
        freq.merge(arr[i], 1, Integer::sum);
        int out = arr[i - k];
        freq.put(out, freq.get(out) - 1);
        if (freq.get(out) == 0) freq.remove(out);
        result[i - k + 1] = freq.size(); // map size = distinct count
    }
}
// [1,2,1,3,4,2,3] k=4 → [3,4,4,3]
```

---

## P9. Sum of Min and Max in Every Window
```java
// Combine P5 (max deque) + P6 (min deque), sum results
long[] result = new long[n - k + 1];
for (int i = 0; i < result.length; i++) result[i] = maxArr[i] + minArr[i];
```

---

## P10. Sliding Window Median
**Pattern:** Two heaps (max-heap lower half, min-heap upper half) + lazy deletion  
**See diagram:** `diagrams/04_two_heaps.png`

```java
// lo = max-heap (lower half)   hi = min-heap (upper half)
// Invariant: lo.size() == hi.size() or lo.size() == hi.size() + 1
// Median: k odd → lo.peek()   k even → (lo.peek() + hi.peek()) / 2.0
// Lazy deletion: track elements to remove in HashMap, skip when at top
// Time: O(n log k), Space: O(k)
```

---

## P11. K-Radius Subarray Averages (LeetCode 2090)
```java
// Window size = 2k+1; result[-1] for indices without full window
// Same fixed window but centered at index k
int window = 2 * k + 1;
result[k] = (int)(sum / window);
```

---

## P12. Maximum Average Subarray I (LeetCode 643)
```java
// Return maxSum/k after sliding
double findMaxAverage(int[] nums, int k) { return maxSum / k; }
// [1,12,-5,-6,50,3] k=4 → 12.75
```

---

## P13. Number of Subarrays of Size K and Average ≥ Threshold (LeetCode 1343)
```java
if (sum >= (long) threshold * k) count++;
// Multiply by k to avoid division — avoid floating point
```

---

## P14. Defuse the Bomb (LeetCode 1652) — Circular
```java
// Circular window: duplicate array [0..2n-1] conceptually
// For k>0: sum of next k; for k<0: sum of prev |k|
```

---

## P15. Grumpy Bookstore Owner (LeetCode 1052)
```java
// Base = customers when not grumpy
// Find K-window with max extra customers (grumpy times)
// Answer = base + maxExtra
```

---

## P16. Diet Plan Performance (LeetCode 1176)
```java
// Points: +1 if sum > upper, -1 if sum < lower, else 0
// Fixed window of size k
```

---

## P17. Binary Subarrays with Sum (LeetCode 930)
```java
// atMost trick: count(sum==goal) = atMost(goal) - atMost(goal-1)
int atMost(int[] nums, int goal) {
    // count subarrays with sum <= goal
    int left=0,sum=0,count=0;
    for(int r=0;r<nums.length;r++){
        sum+=nums[r];
        while(sum>goal) sum-=nums[left++];
        count+=r-left+1;
    }
    return count;
}
```

---

## P18. Maximum Points You Can Obtain from Cards (LeetCode 1423)
```java
// Key insight: take k cards from ends = total - min(middle window of size n-k)
int windowSize = n - k;
// Find min sum of size-windowSize subarray, subtract from total
```

---

## P19. Minimum Swaps to Bring All Elements ≤ K Together
```java
// Window size = count of elements <= K in full array
// Count zeros (elements > K) in each window — minimize that count
```

---

## P20. Subarray Beauty Problem (LeetCode 2653)
```java
// Find xth smallest negative number in each window
// Frequency array for values [-50..50], iterate to find xth negative
```

---

# BEGINNER VARIABLE — Problems 21–40

## P21. Longest Substring Without Repeating Characters (LeetCode 3) ⭐⭐
**Pattern:** Variable expand, HashMap tracks last seen index

```java
Map<Character, Integer> lastSeen = new HashMap<>();
int left = 0, maxLen = 0;
for (int right = 0; right < s.length(); right++) {
    char c = s.charAt(right);
    if (lastSeen.containsKey(c) && lastSeen.get(c) >= left)
        left = lastSeen.get(c) + 1; // jump past duplicate
    lastSeen.put(c, right);
    maxLen = Math.max(maxLen, right - left + 1);
}
// "abcabcbb" → 3, "pwwkew" → 3
// Time: O(n), Space: O(min(n,alphabet))
```

---

## P22. Longest Substring with At Most K Distinct Characters (LeetCode 340)
**Pattern:** Variable, shrink when distinct > K

```java
Map<Character, Integer> freq = new HashMap<>();
int left = 0, maxLen = 0;
for (int right = 0; right < s.length(); right++) {
    freq.merge(s.charAt(right), 1, Integer::sum);
    while (freq.size() > k) {
        char lc = s.charAt(left++);
        freq.put(lc, freq.get(lc) - 1);
        if (freq.get(lc) == 0) freq.remove(lc);
    }
    maxLen = Math.max(maxLen, right - left + 1);
}
// "araaci" k=2 → 4 ("araa")
```

---

## P23. Longest Repeating Character Replacement (LeetCode 424) ⭐⭐
**Key insight:** `window_size - maxFreq <= k` means we can make all chars same

```java
int[] freq = new int[26];
int left = 0, maxFreq = 0, maxLen = 0;
for (int right = 0; right < s.length(); right++) {
    freq[s.charAt(right) - 'A']++;
    maxFreq = Math.max(maxFreq, freq[s.charAt(right) - 'A']);
    if ((right - left + 1) - maxFreq > k) {
        freq[s.charAt(left++) - 'A']--;
        // maxFreq may be stale but only grows — lazy update OK
    }
    maxLen = Math.max(maxLen, right - left + 1);
}
// "AABABBA" k=1 → 4, "ABAB" k=2 → 4
```

---

## P24. Fruit Into Baskets (LeetCode 904)
**= Longest subarray with at most 2 distinct values**

```java
// Same as P22 with k=2, use HashMap<Integer,Integer>
// [1,2,1] → 3, [0,1,2,2] → 3, [1,2,3,2,2] → 4
```

---

## P25. Permutation in String (LeetCode 567)
**Pattern:** Fixed window of length |s1|, frequency array

```java
// Window size = s1.length(), check if freq arrays match
// [Early termination] Use 'formed' counter instead of Arrays.equals
// "ab" in "eidbaooo" → true
```

---

## P26. Find All Anagrams in a String (LeetCode 438) ⭐
```java
// Same as P25 but collect all matching starting indices
// "cbaebabacd","abc" → [0,6]
```

---

## P27. Minimum Window Substring (LeetCode 76) ⭐⭐⭐
**Pattern:** Variable contract — expand until all covered, then shrink

```java
// Track: formed (matched char types), required (distinct chars in t)
// Expand: add s[right], check if formed increases
// Contract: while formed == required, update min, shrink from left
// "ADOBECODEBANC","ABC" → "BANC"
// Time: O(|s|+|t|), Space: O(|s|+|t|)
```

---

## P28-29. Smallest Subarray / Min Size Subarray Sum (LeetCode 209) ⭐
```java
// Pattern: variable contract (non-negative arrays)
int left=0,sum=0,minLen=Integer.MAX_VALUE;
for(int right=0;right<n;right++){
    sum+=nums[right];
    while(sum>=target){
        minLen=Math.min(minLen,right-left+1);
        sum-=nums[left++];
    }
}
// [2,3,1,2,4,3] target=7 → 2 ([4,3])
```

---

## P30. Longest Subarray with Sum ≤ K (non-negative arrays)
```java
while (sum > k) sum -= nums[left++];
maxLen = Math.max(maxLen, right - left + 1);
```

---

## P31. Longest Subarray with Sum Exactly K
```java
// Prefix sum + HashMap (handles negatives!)
Map<Integer,Integer> prefixIndex = new HashMap<>();
prefixIndex.put(0,-1);
int maxLen=0,sum=0;
for(int i=0;i<nums.length;i++){
    sum+=nums[i];
    if(prefixIndex.containsKey(sum-k))
        maxLen=Math.max(maxLen,i-prefixIndex.get(sum-k));
    prefixIndex.putIfAbsent(sum,i); // first occurrence
}
```

---

## P32. Longest Continuous Increasing Subarray (LeetCode 674)
```java
int run=1;
for(int i=1;i<nums.length;i++){
    run = nums[i]>nums[i-1] ? run+1 : 1;
    maxLen = Math.max(maxLen, run);
}
```

---

## P33. Max Consecutive Ones III (LeetCode 1004) ⭐
```java
// Allow at most K zeros (flips)
int left=0,zeros=0,maxLen=0;
for(int right=0;right<nums.length;right++){
    if(nums[right]==0) zeros++;
    while(zeros>k){ if(nums[left++]==0) zeros--; }
    maxLen=Math.max(maxLen,right-left+1);
}
// [1,1,1,0,0,0,1,1,1,1,0] k=2 → 6
```

---

## P34. Longest Ones After Replacement
```java
// = P23 but binary: maxFreq tracks count of 1s
int left=0,maxOnes=0,maxLen=0;
for(int right=0;right<nums.length;right++){
    if(nums[right]==1) maxOnes++;
    if((right-left+1)-maxOnes>k) if(nums[left++]==1) maxOnes--;
    maxLen=Math.max(maxLen,right-left+1);
}
```

---

## P35. Get Equal Substrings Within Budget (LeetCode 1208)
```java
int left=0,cost=0,maxLen=0;
for(int right=0;right<s.length();right++){
    cost+=Math.abs(s.charAt(right)-t.charAt(right));
    while(cost>maxCost) cost-=Math.abs(s.charAt(left)-t.charAt(left++));
    maxLen=Math.max(maxLen,right-left+1);
}
```

---

## P36. Frequency of the Most Frequent Element (LeetCode 1838) ⭐
```java
// Sort first! Cost to make all elements in window = arr[right]:
// windowSum + k >= arr[right] * windowSize
Arrays.sort(nums);
long windowSum=0; int left=0;
for(int right=1;right<nums.length;right++){
    windowSum+=(long)(nums[right]-nums[right-1])*(right-left);
    while(windowSum>k) windowSum-=nums[right]-nums[left++];
    maxFreq=Math.max(maxFreq,right-left+1);
}
```

---

## P37. Longest Nice Subarray (LeetCode 2401)
```java
// All pairs have AND=0 (no shared bits)
int left=0,usedBits=0;
for(int right=0;right<nums.length;right++){
    while((usedBits&nums[right])!=0) usedBits^=nums[left++]; // remove bits
    usedBits|=nums[right];
    maxLen=Math.max(maxLen,right-left+1);
}
```

---

## P38. Maximum Erasure Value (LeetCode 1695) ⭐
```java
// Max sum subarray with all unique elements
Set<Integer> seen=new HashSet<>();
int left=0,sum=0,maxSum=0;
for(int right=0;right<nums.length;right++){
    while(seen.contains(nums[right])){ seen.remove(nums[left]); sum-=nums[left++]; }
    seen.add(nums[right]); sum+=nums[right];
    maxSum=Math.max(maxSum,sum);
}
// [4,2,4,5,6] → 17 ([2,4,5,6])
```

---

## P39. Subarrays with Product Less Than K (LeetCode 713) ⭐
```java
int left=0,product=1,count=0;
for(int right=0;right<nums.length;right++){
    product*=nums[right];
    while(product>=k) product/=nums[left++];
    count+=right-left+1; // all subarrays ending at right
}
// [10,5,2,6] k=100 → 8
```

---

## P40. Longest Turbulent Subarray (LeetCode 978)
```java
// Alternating up-down-up...
int left=0;
for(int right=1;right<arr.length;right++){
    int cmp=Integer.compare(arr[right],arr[right-1]);
    if(cmp==0) left=right;
    else if(right>1&&cmp==Integer.compare(arr[right-1],arr[right-2])) left=right-1;
    maxLen=Math.max(maxLen,right-left+1);
}
```

---

# INTERMEDIATE — Problems 41–60

## P41. Minimum Window Subsequence (LeetCode 727)
**Pattern:** Two-pass — forward finds end, backward finds min start

```java
// Forward: match all of s2 as subsequence
// Backward: shrink from matched position
// "abcdebdde","bde" → "bcde"
// Time: O(|s1|*|s2|), Space: O(1)
```

---

## P42. Sliding Window Maximum (LeetCode 239) ⭐⭐⭐
**Pattern:** Monotonic decreasing deque — O(n)

```java
// See diagram: diagrams/03_monotonic_deque.png
// [1,3,-1,-3,5,3,6,7] k=3 → [3,3,5,5,6,7]
// Each element pushed and popped at most ONCE → O(n) total
```

---

## P43. Sliding Window Minimum
```java
// Same as P42 with >= in dominated check (increasing deque)
```

---

## P44. Minimum Operations to Reduce X to Zero (LeetCode 1658) ⭐
```java
// Key insight: remove from left+right to sum X
// = find longest middle subarray with sum = total - X
int target = total - x;
// Standard variable window for longest subarray sum = target
// "1,1,4,2,3" x=5 → 2 (remove 1+4 or 2+3)
```

---

## P45. Longest Substring with Exactly K Distinct Characters
```java
// atMost(K) - atMost(K-1)
// Uses exact = difference of "at most" counts
```

---

## P46. Count Number of Nice Subarrays (LeetCode 1248) ⭐
```java
// Count subarrays with exactly K odd numbers
// = atMostOdds(K) - atMostOdds(K-1)
// [1,1,2,1,1] k=3 → 2
```

---

## P47. Number of Substrings Containing All Three Characters (LeetCode 1358)
```java
// Once all a,b,c present, all right-extensions are valid
// count += s.length() - right (all extensions)
// "abcabc" → 10
```

---

## P48. Count Vowel Substrings (LeetCode 2062)
```java
// Exactly all 5 vowels = atLeast(5) - atLeast(6)
// Break window on consonant
```

---

## P49. Maximum Vowels in Substring of Given Length (LeetCode 1456)
```java
// Fixed window of size k, count vowels
Set<Character> vowels = Set.of('a','e','i','o','u');
```

---

## P50. Longest Substring with Same Letters After Replacement
```java
// Alias of P23 — character replacement
```

---

## P51. Count Complete Substrings (LeetCode 2953)
```java
// Try all possible distinct char counts (1-26)
// Window size = distinct * k, check each char appears exactly k times
```

---

## P52. Longest Semi-Repetitive Substring (LeetCode 2730)
```java
// At most 1 adjacent pair of same characters
int pairs=0;
while(pairs>1){ if(s[left]==s[left+1]) pairs--; left++; }
```

---

## P53. Count Binary Substrings (LeetCode 696)
```java
// Groups of consecutive 0s and 1s
// count += min(prevGroupSize, currGroupSize) on each group switch
```

---

## P54. Longest Harmonious Subsequence (LeetCode 594)
```java
// max-min = 1; use frequency map
if (freq.containsKey(key+1)) maxLen = Math.max(maxLen, freq[key]+freq[key+1]);
```

---

## P55. Replace Substring for Balanced String (LeetCode 1234)
```java
// Find minimum window to replace so each char (Q,W,E,R) has n/4
// Shrink while all char frequencies <= n/4 (outside window)
```

---

## P56. Number of Subarrays with Bounded Maximum (LeetCode 795)
```java
// count(max<=R) - count(max<=L-1)
// Each: run length of valid elements
```

---

## P57. Continuous Subarrays (LeetCode 2762)
```java
// |arr[i] - arr[j]| <= 2 for all pairs in window
// Two monotonic deques (max + min): shrink when max - min > 2
```

---

## P58. Maximum White Tiles Covered by Carpet (LeetCode 2271)
```java
// Sort tiles, binary search for window end, prefix sum for coverage
```

---

## P59. Longest Subarray of 1s After Deleting One Element (LeetCode 1493)
```java
// Allow at most 1 zero (the "deleted" element)
// result = window size - 1 (account for deleted element)
```

---

## P60. Count Subarrays Where Max Appears at Least K Times (LeetCode 2962)
```java
// Shrink from left when maxCount >= k
// count += nums.length - right (all right-extensions are valid)
```

---

# ADVANCED — Problems 61–80

## P61. Minimum Swaps to Group All 1s Together (LeetCode 1151)
```java
// Window size = total number of 1s
// Count zeros in best window (zeros = swaps needed)
```

---

## P62. Minimum Swaps to Group All 1s Together II (Circular, LeetCode 2134)
```java
// Circular: use index % n for wrap-around
// Window of size totalOnes on doubled virtual array
```

---

## P63. Sliding Window Maximum Using Heap
```java
// O(n log n) with PriorityQueue + lazy deletion
// Heap stores [value, index]; skip indices < i-k+1
// Prefer deque (O(n)) when possible
```

---

## P64. Longest Substring with At Least K Repeating Characters (LeetCode 395)
```java
// Divide and conquer on characters with freq < k
// Split at any char with freq < k — recursively solve both halves
// O(n * unique_chars) = O(26n)
```

---

## P65. Maximum Robots Within Budget (LeetCode 2398) ⭐
```java
// Variable window + deque for max chargeTime
// Cost = max(chargeTimes in window) + k * sum(runningCosts in window)
// Monotonic deque tracks max charge time; sum maintained as runSum
```

---

## P66. Take K of Each Character From Left and Right (LeetCode 2516)
```java
// Total - window: find max middle window where all 3 chars have enough remaining
// remaining[i] = total[i] - window[i] >= k for all i
```

---

## P67. Shortest Subarray with Sum at Least K (LeetCode 862) ⭐⭐
```java
// CRITICAL: handles NEGATIVE numbers (sliding window alone won't work!)
// Prefix sum + monotonic increasing deque
long[] prefix = new long[n+1];
// For each i: find smallest j where prefix[i] - prefix[j] >= k
// j candidates: monotone increasing prefix deque
// Time: O(n), Space: O(n)
```

---

## P68. Count Subarrays with Fixed Bounds (LeetCode 2444) ⭐
```java
// Track last positions of minK, maxK, and out-of-bound element
// count += max(0, min(lastMin, lastMax) - lastBad)
// [1,3,5,2,7,5] minK=1 maxK=5 → 2
```

---

## P69. Maximum Frequency Stack Window Problem
```java
// Frequency-based approach within window
// Window that requires most replacements to make uniform
```

---

## P70. Substring with Concatenation of All Words (LeetCode 30)
```java
// Fixed window of size words.length * wordLen
// Check each position — inner loop is O(words * wordLen)
// Total: O(n * m) where m = total words length
```

---

## P71. Longest Duplicate Substring (LeetCode 1044)
```java
// Binary search on answer length + rolling hash O(n log n)
// Binary search: can we find duplicate of this length?
// Rolling hash: compute hash in O(1) per shift
```

---

## P72. Repeated DNA Sequences (LeetCode 187)
```java
// Fixed window of size 10, HashSet for seen sequences
// Rabin-Karp hash for O(1) per window shift (optimize)
```

---

## P73. Count Distinct Substrings with Constraints
```java
// Sliding + distinct count tracking
```

---

## P74. Minimum Recolors to Get K Consecutive Black Blocks (LeetCode 2379)
```java
// Fixed window of size k, count whites → that's min ops
```

---

## P75. Longest Valid Obstacle Course at Each Position (LeetCode 1964)
```java
// LIS variant with patience sorting (binary search)
// Binary search for first tail > obstacle[i] (upper bound for ≤)
```

---

## P76. Longest Arithmetic Subarray
```java
// Track consecutive common difference
int run=2,prevDiff=nums[1]-nums[0];
for(int i=2;i<nums.length;i++){
    int diff=nums[i]-nums[i-1];
    run = diff==prevDiff ? run+1 : 2;
    prevDiff=diff;
}
```

---

## P77. Find K Closest Elements (LeetCode 658) ⭐
```java
// Binary search for window start: compare arr[mid] vs arr[mid+k] distance to x
// If x-arr[mid] > arr[mid+k]-x → window starts at mid+1
// O(log(n-k)) search, O(k) output
```

---

## P78. Longest Equal Subarray (LeetCode 2831)
```java
// Group positions by value, variable window on each group's positions
// Removals = (span - occurrences) = (pos[r]-pos[l]+1) - (r-l+1) <= k
```

---

## P79. Minimum Adjacent Swaps for K Consecutive Ones (LeetCode 1703)
```java
// Gather 1-positions, adjust for gaps, find optimal window via median
// Cost = sum |pos[i] - median| using prefix sums for O(1) window cost
```

---

## P80. Maximize Confusion of an Exam (LeetCode 2024)
```java
// Allow at most k flips of T or F
// Answer = max(longestRunFlippingT, longestRunFlippingF)
// Each: standard variable window with change counter
```

---

# HARD / INTERVIEW-LEVEL — Problems 81–100

## P81. Sliding Window Median Using Two Heaps (LeetCode 480) ⭐⭐⭐
```java
// Max-heap lo (lower half) + Min-heap hi (upper half) + lazy deletion map
// Invariant: lo.size() == hi.size() or lo.size() == hi.size() + 1
// Add: if num <= lo.peek() → lo, else → hi
// Lazy remove: add to toRemove map, skip when at top during balance
// Time: O(n log k), Space: O(k)
```

---

## P82. Median in Data Stream with Sliding Window
```java
// Online version: process one element at a time
// Remove oldest element from appropriate heap
// Balance after each add/remove
```

---

## P83. Longest Substring with Every Char ≥ K Frequency (LeetCode 395)
```java
// = P64. Divide and conquer
// Any char with freq < k forces a split boundary
```

---

## P84. Smallest Range Covering Elements from K Lists (LeetCode 632) ⭐⭐
```java
// Min-heap across lists + track current max
// Slide: always extend from list with current minimum
// Range shrinks as elements converge
// [4,10,15,24,26],[0,9,12,20],[5,18,22,30] → [20,24]
```

---

## P85. Minimum Window Containing All Characters
```java
// = P27 (minimum window substring)
```

---

## P86. Maximum Subarray Sum with Unique Elements
```java
// = P38 (maximum erasure value)
```

---

## P87. Longest Subarray with Absolute Difference ≤ Limit (LeetCode 1438) ⭐⭐
```java
// Two monotonic deques: one for max, one for min
// Shrink when maxDq.front - minDq.front > limit
// [8,2,4,7] limit=4 → 2, [10,1,2,4,7,2] limit=5 → 4
// Time: O(n), Space: O(n) for deques
```

---

## P88. Shortest Impossible Sequence of Rolls (LeetCode 2350)
```java
// Greedy: count complete sets of 1..k
// Each complete set extends the sequence length by 1
```

---

## P89. Minimum Operations to Make Array Continuous (LeetCode 2009)
```java
// Sort + deduplicate, slide window of size n
// Find max elements that fit in range [x, x+n-1]
// Answer = n - maxFitting
```

---

## P90. Longest Continuous Subarray with Absolute Diff ≤ Limit
```java
// = P87 (two deques)
```

---

## P91. Number of Valid Subarrays (LeetCode 1063)
```java
// Subarray valid if leftmost element <= all others
// Monotonic stack: when element popped (larger than current), count contribution
```

---

## P92. Longest Repeating Substring (LeetCode 1062)
```java
// Binary search on length + rolling hash
// findRepeat(len): use hash set to check if duplicate substring of length len exists
```

---

## P93. Maximum Sum of Distinct Subarrays with Length K (LeetCode 2461)
```java
// Fixed window + uniqueness tracking via HashMap
// Only record maxSum when freq.size() == k (all distinct)
// [1,5,4,2,9,9,9] k=3 → 15 ([1,5,4] or [5,4,2])
```

---

## P94. Count Subarrays with Score Less Than K (LeetCode 2302)
```java
// score = sum * length; variable window
// shrink while score >= k
```

---

## P95. Sliding Window Maximum Using Monotonic Queue
```java
// = P42, clean reference implementation
// ArrayDeque used as monotonic queue
```

---

## P96. Sum of Subarray Minimums (LeetCode 907) ⭐⭐
```java
// Contribution technique: for each element as minimum
// left[i] = elements to the left where arr[i] is still minimum
// right[i] = elements to the right where arr[i] is still minimum
// contribution = arr[i] * left[i] * right[i]
// Use monotonic stack to compute left[] and right[] in O(n)
```

---

## P97. Sum of Subarray Ranges (LeetCode 2104)
```java
// Range = max - min
// sumOfRanges = sum_of_maximums - sum_of_minimums
// Each computed with monotonic stack (contribution technique)
```

---

## P98. Count Subarrays with Median K (LeetCode 2488)
```java
// Convert to +1/-1 based on comparison with k
// Median condition: balance = 0 (odd length) or 1 (even length) after k seen
// Use prefix balance + HashMap to count pairs
```

---

## P99. Number of Wonderful Substrings (LeetCode 1915) ⭐⭐
```java
// Bitmask XOR tracks parity of char frequencies
// Wonderful = all even (mask==0) or exactly one odd (mask is power of 2)
// For each right, count masks we've seen at distance-0 or single-bit-flip away
// count += seen[mask] + sum(seen[mask ^ (1<<i)] for i in 0..9)
```

---

## P100. Minimum Number of K Consecutive Bit Flips (LeetCode 995) ⭐⭐
```java
// Diff array trick: track net flips applied at each position
// flips[i] = net flips at position i (from range updates ending at i)
// When curr value after flips is 0: must flip, use diff array to update range
// [0,0,0,1,0,1,1,0] k=3 → 3 flips
// Time: O(n), Space: O(n)
```

---

# Complexity Summary

| # | Problem | Time | Space | Pattern |
|---|---------|------|-------|---------|
| 1 | Max Sum K | O(n) | O(1) | Fixed |
| 3 | First Negative | O(n) | O(k) | Fixed+Deque |
| 4 | Count Anagrams | O(n) | O(26) | Fixed+Freq |
| 5 | Max in Windows | O(n) | O(k) | Mono Deque |
| 10 | Sliding Median | O(n log k) | O(k) | Two Heaps |
| 17 | Binary Sum | O(n) | O(1) | atMost Trick |
| 21 | No-Repeat | O(n) | O(26) | Variable+Map |
| 23 | Char Replace | O(n) | O(26) | Variable |
| 27 | Min Window | O(n+m) | O(n+m) | Variable Contract |
| 33 | Ones III | O(n) | O(1) | Variable |
| 36 | Max Freq Elem | O(n log n) | O(1) | Sort+Variable |
| 39 | Product <K | O(n) | O(1) | Variable |
| 41 | Min Subseq | O(n·m) | O(1) | Two Pass |
| 42 | Sliding Max | O(n) | O(k) | Mono Deque |
| 44 | Min Ops X | O(n) | O(1) | Variable |
| 57 | Continuous | O(n) | O(k) | Two Deques |
| 67 | Short Sum K | O(n) | O(n) | Prefix+Deque |
| 68 | Fixed Bounds | O(n) | O(1) | Three Pointers |
| 81 | Sliding Median | O(n log k) | O(k) | Two Heaps |
| 84 | Smallest Range | O(n log k) | O(k) | Min Heap |
| 87 | Abs Diff Limit | O(n) | O(k) | Two Deques |
| 96 | Sum Minimums | O(n) | O(n) | Mono Stack |
| 99 | Wonderful | O(10n) | O(2^10) | Bitmask |
| 100 | K Bit Flips | O(n) | O(n) | Diff Array |

---

## How to Run

```bash
# Compile
mvn compile

# Run any class
mvn exec:java -Dexec.mainClass="com.slidingwindow.fixed.FixedWindowProblems"
mvn exec:java -Dexec.mainClass="com.slidingwindow.variable.VariableWindowProblems"
mvn exec:java -Dexec.mainClass="com.slidingwindow.intermediate.IntermediateProblems"
mvn exec:java -Dexec.mainClass="com.slidingwindow.advanced.AdvancedProblems"
mvn exec:java -Dexec.mainClass="com.slidingwindow.hard.HardProblems"
```

---

*100 Sliding Window Problems — Complete Java Solutions*
