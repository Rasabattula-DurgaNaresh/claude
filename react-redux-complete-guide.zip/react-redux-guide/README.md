# ⚛️ React.js + Redux — Complete Guide with Code Examples

A comprehensive, runnable code guide covering **every major topic** in React.js and Redux.

## 📁 Project Structure

```
src/
├── components/          # React Core Concepts
│   ├── 01_JSX/          # JSX syntax, expressions, conditionals
│   ├── 02_FunctionalComponents/  # Props, default props, prop types
│   ├── 03_ClassComponents/       # Lifecycle methods, state
│   ├── 04_Hooks/                 # useState, useEffect, useRef, useMemo, useCallback
│   ├── 05_EventHandling/         # Events, synthetic events, forms
│   ├── 06_ConditionalRendering/  # if/else, ternary, && operator
│   ├── 07_Lists/                 # map, keys, filtering
│   ├── 08_Forms/                 # Controlled/uncontrolled, validation
│   ├── 09_Styling/               # CSS modules, styled-components, Tailwind
│   └── 10_HigherOrderComponents/ # HOC pattern
│
├── hooks/               # Custom Hooks
│   ├── useFetch.js      # Data fetching hook
│   ├── useLocalStorage.js # LocalStorage sync
│   ├── useDebounce.js   # Debounce input
│   └── usePrevious.js   # Track previous value
│
├── context/             # React Context API
│   ├── ThemeContext.js  # Theme provider
│   └── AuthContext.js   # Auth provider
│
├── redux/               # Redux State Management
│   ├── 01_BasicRedux/   # Store, actions, reducers (vanilla Redux)
│   ├── 02_ReduxToolkit/ # createSlice, configureStore
│   ├── 03_AsyncThunk/   # createAsyncThunk, API calls
│   ├── 04_ReduxSaga/    # redux-saga generators
│   ├── 05_Selectors/    # reselect memoized selectors
│   ├── 06_Middleware/   # Custom middleware
│   └── 07_RTKQuery/     # RTK Query — data fetching
│
├── routing/             # React Router v6
│   ├── BasicRouting.jsx # Routes, Link, NavLink
│   ├── NestedRoutes.jsx # Outlet, nested routes
│   ├── ProtectedRoute.jsx # Auth guard
│   └── LazyRoutes.jsx   # Code splitting
│
├── forms/               # Advanced Forms
│   ├── ReactHookForm.jsx # react-hook-form + Zod
│   └── FormValidation.jsx # Custom validation
│
├── api/                 # API Integration
│   ├── axiosConfig.js   # Axios instance, interceptors
│   └── ApiService.js    # CRUD service layer
│
├── testing/             # Testing Examples
│   ├── Counter.test.jsx # Component tests
│   └── redux.test.js    # Redux tests
│
└── advanced/            # Advanced Patterns
    ├── CodeSplitting.jsx # React.lazy, Suspense
    ├── ErrorBoundary.jsx # Error boundaries
    ├── Portals.jsx       # React portals
    ├── Memoization.jsx   # React.memo, useMemo
    └── Performance.jsx   # Performance patterns
```

## 🚀 Quick Start

```bash
npm install
npm start
```

## 📚 Topics Covered

### React.js
1. JSX & Expressions
2. Functional & Class Components
3. Props & PropTypes
4. State Management (useState)
5. Lifecycle (useEffect, class lifecycle)
6. Event Handling
7. Conditional Rendering
8. Lists & Keys
9. Forms (controlled & uncontrolled)
10. Custom Hooks
11. Context API
12. React Router v6
13. Code Splitting & Lazy Loading
14. Error Boundaries
15. Portals
16. Performance Optimization (memo, useMemo, useCallback)
17. Higher-Order Components
18. Render Props

### Redux
1. Core Concepts (Store, Actions, Reducers)
2. Redux Toolkit (createSlice, configureStore)
3. Async Operations (createAsyncThunk)
4. Redux Saga
5. Memoized Selectors (reselect)
6. Custom Middleware
7. RTK Query
8. Redux DevTools
9. Immer (immutable updates)

---
*All code is production-quality and thoroughly commented for learning.*
