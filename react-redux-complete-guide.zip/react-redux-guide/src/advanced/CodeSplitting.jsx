/**
 * TOPIC: Code Splitting — React.lazy + Suspense
 * Load components only when needed to reduce initial bundle size.
 */
import React, { lazy, Suspense, useState } from "react";

// Only loaded when HeavyComponent is actually rendered
const HeavyDashboard = lazy(() =>
  // Simulate slow load
  new Promise(resolve =>
    setTimeout(() => resolve({ default: () => (
      <div style={{ padding: "20px", background: "#f0fdf4" }}>
        <h2>Heavy Dashboard (Lazy Loaded!)</h2>
        <p>This component was only fetched when you clicked "Load".</p>
        <p>In a real app, this could be a large chart library or admin panel.</p>
      </div>
    )}), 1500)
  )
);

// Custom loading fallback
const LoadingSpinner = () => (
  <div style={{ padding: "20px", textAlign: "center" }}>
    <div style={{
      width: "40px", height: "40px", margin: "0 auto",
      border: "4px solid #e2e8f0", borderTopColor: "#3b82f6",
      borderRadius: "50%", animation: "spin 0.8s linear infinite"
    }} />
    <p>Loading component...</p>
    <style>{"@keyframes spin { to { transform: rotate(360deg); } }"}</style>
  </div>
);

const CodeSplitting = () => {
  const [showDashboard, setShowDashboard] = useState(false);

  return (
    <div style={{ padding: "20px" }}>
      <h1>Code Splitting</h1>
      <p>Click to lazy-load the Dashboard component:</p>
      <button onClick={() => setShowDashboard(true)}
        style={{ padding: "10px 20px", background: "#3b82f6", color: "white",
                 border: "none", borderRadius: "6px", cursor: "pointer" }}>
        {showDashboard ? "Loaded!" : "Load Dashboard"}
      </button>

      {showDashboard && (
        <Suspense fallback={<LoadingSpinner />}>
          <HeavyDashboard />
        </Suspense>
      )}
    </div>
  );
};

export default CodeSplitting;
