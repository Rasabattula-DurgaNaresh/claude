/**
 * TOPIC: Performance — React.memo, useMemo, useCallback
 */
import React, { useState, useMemo, useCallback, memo } from "react";

// ── React.memo — skip re-render if props unchanged ────────────────────────────
const ExpensiveList = memo(({ items, onDelete }) => {
  console.log("ExpensiveList rendered");
  return (
    <ul style={{ listStyle: "none", padding: 0 }}>
      {items.map(item => (
        <li key={item.id} style={{ display: "flex", justifyContent: "space-between",
                                    padding: "8px", marginBottom: "4px", background: "#f8fafc",
                                    borderRadius: "4px", border: "1px solid #e2e8f0" }}>
          <span>{item.name}</span>
          <button onClick={() => onDelete(item.id)}
            style={{ background: "#ef4444", color: "white", border: "none",
                     borderRadius: "4px", padding: "2px 8px" }}>×</button>
        </li>
      ))}
    </ul>
  );
});

// Custom comparison function for memo
const StatCard = memo(({ title, value, formatter = v => v }) => {
  console.log(`StatCard "${title}" rendered`);
  return (
    <div style={{ padding: "16px", background: "#eff6ff", borderRadius: "8px",
                  border: "1px solid #bfdbfe", textAlign: "center" }}>
      <div style={{ fontSize: "24px", fontWeight: "bold", color: "#1d4ed8" }}>
        {formatter(value)}
      </div>
      <div style={{ color: "#64748b", fontSize: "14px" }}>{title}</div>
    </div>
  );
}, (prev, next) => prev.value === next.value && prev.title === next.title);

const Memoization = () => {
  const [items, setItems] = useState([
    { id: 1, name: "React",  price: 100 },
    { id: 2, name: "Redux",  price: 200 },
    { id: 3, name: "TypeScript", price: 150 },
  ]);
  const [theme, setTheme] = useState("light");

  // useMemo — expensive computation (only when items change, not theme)
  const stats = useMemo(() => {
    console.log("Computing stats...");
    return {
      total: items.reduce((sum, i) => sum + i.price, 0),
      avg:   items.length ? (items.reduce((s, i) => s + i.price, 0) / items.length).toFixed(2) : 0,
      count: items.length,
    };
  }, [items]);

  // useCallback — stable function reference (not recreated on theme change)
  const handleDelete = useCallback((id) => {
    setItems(prev => prev.filter(i => i.id !== id));
  }, []);

  const addItem = useCallback(() => {
    setItems(prev => [...prev, { id: Date.now(), name: `Item ${prev.length + 1}`, price: Math.round(Math.random() * 300) }]);
  }, []);

  return (
    <div style={{ padding: "20px" }}>
      <h1>Performance Optimization</h1>
      <div style={{ marginBottom: "16px", display: "flex", gap: "8px" }}>
        <button onClick={() => setTheme(t => t === "light" ? "dark" : "light")}>
          Toggle Theme (won&apos;t recompute stats)
        </button>
        <button onClick={addItem}>Add Item</button>
        <span style={{ color: "#64748b" }}>Theme: {theme}</span>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: "12px", marginBottom: "16px" }}>
        <StatCard title="Total Value"    value={stats.total} formatter={v => `$${v}`} />
        <StatCard title="Average Price"  value={stats.avg}   formatter={v => `$${v}`} />
        <StatCard title="Items Count"    value={stats.count} />
      </div>

      <ExpensiveList items={items} onDelete={handleDelete} />
      <p style={{ color: "#94a3b8", fontSize: "12px" }}>Open console to see render counts</p>
    </div>
  );
};

export default Memoization;
