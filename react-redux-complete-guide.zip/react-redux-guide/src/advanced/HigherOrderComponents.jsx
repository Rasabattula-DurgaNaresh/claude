/**
 * TOPIC: Higher-Order Components (HOC)
 * A HOC is a function that takes a component and returns an enhanced component.
 * Pattern: const EnhancedComponent = withSomething(OriginalComponent)
 */
import React, { useState, useEffect } from "react";

// ── 1. withLoading HOC ────────────────────────────────────────────────────────
const withLoading = (WrappedComponent) => {
  const WithLoadingComponent = ({ isLoading, loadingText = "Loading...", ...props }) => {
    if (isLoading) {
      return (
        <div style={{ padding: "20px", textAlign: "center", color: "#64748b" }}>
          <div style={{ marginBottom: "8px" }}>⏳</div>
          {loadingText}
        </div>
      );
    }
    return <WrappedComponent {...props} />;
  };
  WithLoadingComponent.displayName = `WithLoading(${WrappedComponent.displayName || WrappedComponent.name})`;
  return WithLoadingComponent;
};

// ── 2. withAuth HOC ───────────────────────────────────────────────────────────
const withAuth = (WrappedComponent) => {
  return ({ requiredRole, ...props }) => {
    const user = { name: "Alice", role: "admin" }; // Mock auth state
    if (!user) return <p>Please log in.</p>;
    if (requiredRole && user.role !== requiredRole)
      return <p>Access denied. Required role: {requiredRole}</p>;
    return <WrappedComponent user={user} {...props} />;
  };
};

// ── 3. withLogger HOC ─────────────────────────────────────────────────────────
const withLogger = (WrappedComponent) => {
  return (props) => {
    useEffect(() => {
      console.log(`[HOC] ${WrappedComponent.name} mounted with props:`, props);
      return () => console.log(`[HOC] ${WrappedComponent.name} unmounted`);
    }, [props]);
    return <WrappedComponent {...props} />;
  };
};

// ── Base components ───────────────────────────────────────────────────────────
const UserProfile = ({ user }) => (
  <div style={{ padding: "16px", background: "#f8fafc", borderRadius: "8px" }}>
    <h3>{user.name}</h3><p>Role: {user.role}</p>
  </div>
);

const DataList = ({ items }) => (
  <ul>{items?.map((item, i) => <li key={i}>{item}</li>)}</ul>
);

// ── Apply HOCs ────────────────────────────────────────────────────────────────
const UserProfileWithAuth   = withAuth(withLogger(UserProfile));
const DataListWithLoading   = withLoading(DataList);

const HigherOrderComponents = () => {
  const [loading, setLoading] = useState(true);
  const [items, setItems]     = useState([]);

  useEffect(() => {
    setTimeout(() => { setItems(["React","Redux","TypeScript"]); setLoading(false); }, 1500);
  }, []);

  return (
    <div style={{ padding: "20px" }}>
      <h1>Higher-Order Components</h1>
      <h3>1. withAuth HOC</h3>
      <UserProfileWithAuth />
      <h3>2. withLoading HOC</h3>
      <DataListWithLoading isLoading={loading} loadingText="Fetching items..." items={items} />
    </div>
  );
};

export default HigherOrderComponents;
