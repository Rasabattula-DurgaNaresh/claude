/**
 * TOPIC: Error Boundaries — Catch render errors in component tree
 */
import React, { Component, useState } from "react";

class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error("Error caught:", error, errorInfo);
    this.setState({ errorInfo });
    // Log to Sentry: Sentry.captureException(error, { extra: errorInfo });
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{ padding: "20px", background: "#fef2f2", border: "1px solid #fecaca", borderRadius: "8px" }}>
          <h3 style={{ color: "#dc2626" }}>Something went wrong</h3>
          <p style={{ color: "#7f1d1d" }}>{this.state.error?.message}</p>
          {this.props.fallback && this.props.fallback}
          <button onClick={() => this.setState({ hasError: false, error: null, errorInfo: null })}
            style={{ padding: "8px 16px", background: "#dc2626", color: "white", border: "none", borderRadius: "4px" }}>
            Try Again
          </button>
          {process.env.NODE_ENV === "development" && (
            <details style={{ marginTop: "12px", fontSize: "12px", color: "#64748b" }}>
              <summary>Stack trace (dev only)</summary>
              <pre>{this.state.errorInfo?.componentStack}</pre>
            </details>
          )}
        </div>
      );
    }
    return this.props.children;
  }
}

// Buggy component for demo
const BuggyWidget = ({ shouldCrash }) => {
  if (shouldCrash) throw new Error("Widget crashed on purpose!");
  return <div style={{ padding: "12px", background: "#f0fdf4", borderRadius: "6px" }}>Widget is working fine ✅</div>;
};

const ErrorBoundaryDemo = () => {
  const [crash, setCrash] = useState(false);
  return (
    <div style={{ padding: "20px" }}>
      <h1>Error Boundary</h1>
      <button onClick={() => setCrash(c => !c)} style={{ padding: "8px 16px", marginBottom: "12px" }}>
        {crash ? "Fix Widget" : "Crash Widget"}
      </button>
      <ErrorBoundary fallback={<p>Custom fallback content here.</p>}>
        <BuggyWidget shouldCrash={crash} />
      </ErrorBoundary>
    </div>
  );
};

export { ErrorBoundary };
export default ErrorBoundaryDemo;
