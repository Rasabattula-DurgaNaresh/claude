/**
 * Utility functions used throughout the app
 */

// ── Formatters ─────────────────────────────────────────────────────────────────
export const formatCurrency = (amount, currency = "USD") =>
  new Intl.NumberFormat("en-US", { style: "currency", currency }).format(amount);

export const formatDate = (date, options = {}) =>
  new Intl.DateTimeFormat("en-US", { dateStyle: "medium", ...options }).format(new Date(date));

export const formatRelativeTime = (date) => {
  const diff = (Date.now() - new Date(date)) / 1000;
  if (diff < 60)   return "just now";
  if (diff < 3600) return `${Math.floor(diff / 60)} minutes ago`;
  if (diff < 86400)return `${Math.floor(diff / 3600)} hours ago`;
  return `${Math.floor(diff / 86400)} days ago`;
};

// ── Array utilities ────────────────────────────────────────────────────────────
export const groupBy = (array, key) =>
  array.reduce((groups, item) => ({
    ...groups,
    [item[key]]: [...(groups[item[key]] || []), item]
  }), {});

export const unique = (array, key) =>
  key ? [...new Map(array.map(item => [item[key], item])).values()] : [...new Set(array)];

export const sortBy = (array, key, direction = "asc") =>
  [...array].sort((a, b) =>
    direction === "asc" ? (a[key] > b[key] ? 1 : -1) : (a[key] < b[key] ? 1 : -1));

// ── String utilities ───────────────────────────────────────────────────────────
export const truncate = (str, length = 50) =>
  str.length <= length ? str : str.slice(0, length) + "...";

export const capitalize = (str) =>
  str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();

export const slugify = (str) =>
  str.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

// ── Async utilities ────────────────────────────────────────────────────────────
export const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

export const retry = async (fn, maxAttempts = 3, delay = 1000) => {
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      return await fn();
    } catch (error) {
      if (attempt === maxAttempts) throw error;
      await sleep(delay * attempt);
    }
  }
};

// ── Local storage ──────────────────────────────────────────────────────────────
export const storage = {
  get:    (key, fallback = null) => { try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; } },
  set:    (key, value) => localStorage.setItem(key, JSON.stringify(value)),
  remove: (key) => localStorage.removeItem(key),
  clear:  () => localStorage.clear(),
};

// ── Validation ─────────────────────────────────────────────────────────────────
export const validators = {
  email:    (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v),
  phone:    (v) => /^\+?[\d\s-]{10,}$/.test(v),
  url:      (v) => { try { new URL(v); return true; } catch { return false; } },
  required: (v) => v !== null && v !== undefined && v !== "",
  minLength:(v, n) => String(v).length >= n,
  maxLength:(v, n) => String(v).length <= n,
};
