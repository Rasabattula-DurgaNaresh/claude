/**
 * TOPIC: React Hook Form + Zod Validation
 * Best library for performant, flexible forms.
 */
import React from "react";
import { useForm, Controller, useFieldArray } from "react-hook-form";

const fieldStyle = {
  display: "block", width: "100%", padding: "8px 12px",
  border: "1px solid #d1d5db", borderRadius: "6px",
  fontSize: "14px", boxSizing: "border-box", marginTop: "4px",
};
const errStyle = { color: "#dc2626", fontSize: "12px", marginTop: "3px" };
const labelStyle = { display: "block", fontWeight: 500, fontSize: "14px", color: "#374151" };

const ReactHookForm = () => {
  const {
    register,       // registers input into the form
    handleSubmit,   // wraps submit to validate first
    formState: { errors, isSubmitting, isValid, touchedFields, dirtyFields },
    reset,          // reset form state
    watch,          // watch field values
    setValue,       // programmatically set values
    getValues,      // get current values without subscribe
    control,        // needed for Controller and useFieldArray
  } = useForm({
    mode: "onChange",    // Validate on every change
    defaultValues: {
      firstName: "", lastName: "", email: "", age: "",
      role: "user", bio: "", skills: [{ name: "" }],
    }
  });

  const { fields, append, remove } = useFieldArray({ control, name: "skills" });

  const watchedEmail = watch("email");  // Re-renders on email change

  const onSubmit = async (data) => {
    await new Promise(r => setTimeout(r, 1000));  // Simulate API
    console.log("Form data:", data);
    alert("Form submitted! Check console.");
    reset();
  };

  const inputField = (name, label, rules = {}, type = "text", placeholder = "") => (
    <div style={{ marginBottom: "14px" }}>
      <label style={labelStyle}>
        {label} {rules.required && <span style={{ color: "#dc2626" }}>*</span>}
      </label>
      <input type={type} placeholder={placeholder}
        {...register(name, rules)}
        style={{ ...fieldStyle, borderColor: errors[name] ? "#dc2626" : "#d1d5db" }} />
      {errors[name] && <p style={errStyle}>{errors[name]?.message}</p>}
    </div>
  );

  return (
    <div style={{ padding: "20px", maxWidth: "480px" }}>
      <h2>React Hook Form</h2>
      <form onSubmit={handleSubmit(onSubmit)} noValidate>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
          {inputField("firstName", "First Name", {
            required: "First name is required",
            minLength: { value: 2, message: "At least 2 characters" }
          }, "text", "John")}
          {inputField("lastName", "Last Name", {
            required: "Last name is required"
          }, "text", "Doe")}
        </div>

        {inputField("email", "Email", {
          required: "Email is required",
          pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: "Invalid email" }
        }, "email", "john@example.com")}

        {watchedEmail && (
          <p style={{ fontSize: "12px", color: "#6b7280" }}>
            Watching email: {watchedEmail}
          </p>
        )}

        {inputField("age", "Age", {
          required: "Age is required",
          min: { value: 18, message: "Must be at least 18" },
          max: { value: 120, message: "Invalid age" }
        }, "number")}

        <div style={{ marginBottom: "14px" }}>
          <label style={labelStyle}>Role</label>
          <select {...register("role")} style={fieldStyle}>
            <option value="user">User</option>
            <option value="admin">Admin</option>
            <option value="editor">Editor</option>
          </select>
        </div>

        <div style={{ marginBottom: "14px" }}>
          <label style={labelStyle}>Bio</label>
          <textarea {...register("bio", { maxLength: { value: 200, message: "Max 200 chars" } })}
            rows={3} style={{ ...fieldStyle, resize: "vertical" }} placeholder="Tell us about yourself" />
          {errors.bio && <p style={errStyle}>{errors.bio.message}</p>}
        </div>

        {/* Dynamic Fields with useFieldArray */}
        <div style={{ marginBottom: "14px" }}>
          <label style={labelStyle}>Skills</label>
          {fields.map((field, index) => (
            <div key={field.id} style={{ display: "flex", gap: "8px", marginTop: "6px" }}>
              <input
                {...register(`skills.${index}.name`, { required: "Skill name required" })}
                placeholder={`Skill ${index + 1}`} style={{ ...fieldStyle, margin: 0, flex: 1 }} />
              {fields.length > 1 && (
                <button type="button" onClick={() => remove(index)}
                  style={{ padding: "8px", background: "#ef4444", color: "white", border: "none", borderRadius: "6px" }}>
                  ×
                </button>
              )}
            </div>
          ))}
          <button type="button" onClick={() => append({ name: "" })}
            style={{ marginTop: "8px", padding: "6px 14px", background: "#f1f5f9",
                     border: "1px solid #d1d5db", borderRadius: "6px", cursor: "pointer" }}>
            + Add Skill
          </button>
        </div>

        <div style={{ display: "flex", gap: "10px" }}>
          <button type="submit" disabled={isSubmitting || !isValid}
            style={{ flex: 1, padding: "10px", background: isValid ? "#3b82f6" : "#94a3b8",
                     color: "white", border: "none", borderRadius: "6px", cursor: "pointer" }}>
            {isSubmitting ? "Submitting..." : "Submit"}
          </button>
          <button type="button" onClick={() => reset()}
            style={{ padding: "10px 20px", background: "#f1f5f9", border: "1px solid #d1d5db",
                     borderRadius: "6px", cursor: "pointer" }}>
            Reset
          </button>
        </div>

        {/* Form state indicators */}
        <div style={{ marginTop: "12px", fontSize: "12px", color: "#6b7280" }}>
          Valid: {isValid ? "✅" : "❌"} |
          Dirty fields: {Object.keys(dirtyFields).join(", ") || "none"} |
          Errors: {Object.keys(errors).length}
        </div>
      </form>
    </div>
  );
};

export default ReactHookForm;
