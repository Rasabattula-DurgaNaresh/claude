/**
 * TOPIC: Testing Redux — reducers, actions, async thunks, store
 */
import { configureStore } from "@reduxjs/toolkit";
import counterReducer, { increment, decrement, incrementByAmount, reset } from "../redux/02_ReduxToolkit/counterSlice";
import todosReducer, { addTodo, toggleTodo, deleteTodo } from "../redux/02_ReduxToolkit/todosSlice";

// ── Test Reducers ─────────────────────────────────────────────────────────────
describe("Counter Reducer", () => {
  const initial = { value: 0, step: 1, history: [] };

  test("returns initial state", () => {
    expect(counterReducer(undefined, { type: "@@INIT" })).toEqual(initial);
  });

  test("handles increment", () => {
    const state = counterReducer(initial, increment());
    expect(state.value).toBe(1);
  });

  test("handles decrement", () => {
    const state = counterReducer({ ...initial, value: 5 }, decrement());
    expect(state.value).toBe(4);
  });

  test("handles incrementByAmount", () => {
    const state = counterReducer(initial, incrementByAmount(10));
    expect(state.value).toBe(10);
  });

  test("handles reset", () => {
    const state = counterReducer({ value: 99, step: 5, history: [1,2,3] }, reset());
    expect(state).toEqual(initial);
  });
});

// ── Test Todo Reducer ─────────────────────────────────────────────────────────
describe("Todos Reducer", () => {
  const initial = { items: [], filter: "all" };

  test("adds todo", () => {
    const state = todosReducer(initial, addTodo("Buy groceries", "high"));
    expect(state.items).toHaveLength(1);
    expect(state.items[0].text).toBe("Buy groceries");
    expect(state.items[0].done).toBe(false);
  });

  test("toggles todo", () => {
    const withTodo = todosReducer(initial, addTodo("Test todo"));
    const id = withTodo.items[0].id;
    const toggled = todosReducer(withTodo, toggleTodo(id));
    expect(toggled.items[0].done).toBe(true);
  });

  test("deletes todo", () => {
    const withTodo = todosReducer(initial, addTodo("Delete me"));
    const id = withTodo.items[0].id;
    const deleted = todosReducer(withTodo, deleteTodo(id));
    expect(deleted.items).toHaveLength(0);
  });
});

// ── Test with full store ──────────────────────────────────────────────────────
describe("Counter Store Integration", () => {
  const makeStore = () => configureStore({
    reducer: { counter: counterReducer, todos: todosReducer }
  });

  test("dispatches actions and updates state", () => {
    const store = makeStore();
    store.dispatch(increment());
    store.dispatch(increment());
    store.dispatch(incrementByAmount(5));
    expect(store.getState().counter.value).toBe(7);
  });

  test("subscribes to state changes", () => {
    const store = makeStore();
    const listener = jest.fn();
    store.subscribe(listener);
    store.dispatch(increment());
    expect(listener).toHaveBeenCalledTimes(1);
  });
});
