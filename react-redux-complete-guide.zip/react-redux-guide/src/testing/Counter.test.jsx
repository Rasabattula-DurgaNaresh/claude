/**
 * TOPIC: Testing React Components
 * Using @testing-library/react for component tests.
 */
import React, { useState } from "react";
import { render, screen, fireEvent, waitFor, act } from "@testing-library/react";
import userEvent from "@testing-library/user-event";

// Component to test
const Counter = ({ initialValue = 0, step = 1 }) => {
  const [count, setCount] = useState(initialValue);
  return (
    <div>
      <h1>Counter: <span data-testid="count">{count}</span></h1>
      <button onClick={() => setCount(c => c + step)} aria-label="increment">+</button>
      <button onClick={() => setCount(c => c - step)} aria-label="decrement">-</button>
      <button onClick={() => setCount(initialValue)} aria-label="reset">Reset</button>
      {count > 10 && <p data-testid="warning">Count is high!</p>}
    </div>
  );
};

// ── Tests ─────────────────────────────────────────────────────────────────────
describe("Counter Component", () => {
  test("renders with initial value", () => {
    render(<Counter initialValue={5} />);
    expect(screen.getByTestId("count")).toHaveTextContent("5");
  });

  test("increments count when + button clicked", async () => {
    const user = userEvent.setup();
    render(<Counter />);
    await user.click(screen.getByRole("button", { name: /increment/i }));
    expect(screen.getByTestId("count")).toHaveTextContent("1");
  });

  test("decrements count when - button clicked", async () => {
    const user = userEvent.setup();
    render(<Counter initialValue={5} />);
    await user.click(screen.getByRole("button", { name: /decrement/i }));
    expect(screen.getByTestId("count")).toHaveTextContent("4");
  });

  test("resets to initial value", async () => {
    const user = userEvent.setup();
    render(<Counter initialValue={3} />);
    await user.click(screen.getByLabelText("increment"));
    await user.click(screen.getByLabelText("reset"));
    expect(screen.getByTestId("count")).toHaveTextContent("3");
  });

  test("shows warning when count > 10", async () => {
    const user = userEvent.setup();
    render(<Counter initialValue={10} />);
    expect(screen.queryByTestId("warning")).not.toBeInTheDocument();
    await user.click(screen.getByLabelText("increment"));
    expect(screen.getByTestId("warning")).toBeInTheDocument();
  });

  test("uses custom step", async () => {
    const user = userEvent.setup();
    render(<Counter step={5} />);
    await user.click(screen.getByLabelText("increment"));
    expect(screen.getByTestId("count")).toHaveTextContent("5");
  });
});

// ── Async component test ──────────────────────────────────────────────────────
const AsyncData = () => {
  const [data, setData] = React.useState(null);
  React.useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/posts/1")
      .then(r => r.json()).then(setData);
  }, []);
  if (!data) return <p>Loading...</p>;
  return <div data-testid="post-title">{data.title}</div>;
};

describe("AsyncData Component", () => {
  test("shows loading then data", async () => {
    global.fetch = jest.fn(() =>
      Promise.resolve({ json: () => Promise.resolve({ title: "Test Post" }) })
    );
    render(<AsyncData />);
    expect(screen.getByText("Loading...")).toBeInTheDocument();
    await waitFor(() => expect(screen.getByTestId("post-title")).toBeInTheDocument());
    expect(screen.getByTestId("post-title")).toHaveTextContent("Test Post");
  });
});

export { Counter };
