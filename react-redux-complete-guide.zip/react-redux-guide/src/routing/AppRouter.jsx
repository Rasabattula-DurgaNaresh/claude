/**
 * TOPIC: React Router v6 — Complete routing setup
 */
import React, { lazy, Suspense } from "react";
import { BrowserRouter, Routes, Route, Link, NavLink, Navigate,
         useParams, useNavigate, useLocation, Outlet } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

// Lazy-loaded pages for code splitting
const Home     = lazy(() => import("./pages/Home"));
const About    = lazy(() => import("./pages/About"));
const UserList = lazy(() => import("./pages/UserList"));
const UserDetail = lazy(() => import("./pages/UserDetail"));
const Dashboard  = lazy(() => import("./pages/Dashboard"));
const NotFound   = lazy(() => import("./pages/NotFound"));

// ── Protected Route ───────────────────────────────────────────────────────────
const ProtectedRoute = ({ children, redirectTo = "/login" }) => {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? children : <Navigate to={redirectTo} replace />;
};

// ── Layout with persistent nav ────────────────────────────────────────────────
const Layout = () => {
  const location = useLocation();
  const navStyle = ({ isActive }) => ({
    color: isActive ? "#3b82f6" : "#64748b",
    fontWeight: isActive ? "bold" : "normal",
    textDecoration: "none",
    padding: "8px 12px",
    borderBottom: isActive ? "2px solid #3b82f6" : "2px solid transparent",
  });

  return (
    <div>
      <nav style={{ display: "flex", gap: "8px", padding: "16px 20px",
                    background: "#f8fafc", borderBottom: "1px solid #e2e8f0" }}>
        <NavLink to="/"          style={navStyle} end>Home</NavLink>
        <NavLink to="/about"     style={navStyle}>About</NavLink>
        <NavLink to="/users"     style={navStyle}>Users</NavLink>
        <NavLink to="/dashboard" style={navStyle}>Dashboard</NavLink>
      </nav>
      <div style={{ padding: "20px" }}>
        <Outlet />  {/* Renders nested route content */}
      </div>
    </div>
  );
};

// ── Nested Routes ─────────────────────────────────────────────────────────────
const UsersLayout = () => (
  <div>
    <h2>Users Section</h2>
    <Outlet />  {/* UserList or UserDetail renders here */}
  </div>
);

// ── Main Router ───────────────────────────────────────────────────────────────
const AppRouter = () => (
  <BrowserRouter>
    <Suspense fallback={<div style={{ padding: "20px" }}>Loading page...</div>}>
      <Routes>
        <Route element={<Layout />}>
          <Route index         element={<Home />} />
          <Route path="about"  element={<About />} />

          {/* Nested routes */}
          <Route path="users" element={<UsersLayout />}>
            <Route index       element={<UserList />} />
            <Route path=":id"  element={<UserDetail />} />
          </Route>

          {/* Protected route */}
          <Route path="dashboard" element={
            <ProtectedRoute><Dashboard /></ProtectedRoute>
          } />
        </Route>

        {/* Redirect */}
        <Route path="/old-path" element={<Navigate to="/about" replace />} />

        {/* 404 */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Suspense>
  </BrowserRouter>
);

export default AppRouter;
