import React from "react"; import { Link } from "react-router-dom";
const Home = () => (<div><h1>Home Page</h1><p>Welcome!</p><Link to="/users">Browse Users</Link></div>);
export default Home;