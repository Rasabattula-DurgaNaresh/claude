import React from "react"; import { useParams, useNavigate } from "react-router-dom";
const UserDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  return (<div><h3>User #{id}</h3><p>Name: User {id}</p>
    <button onClick={() => navigate(-1)}>Back</button>
    <button onClick={() => navigate("/users")}>All Users</button>
  </div>);
};
export default UserDetail;