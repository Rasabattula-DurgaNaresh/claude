import React from "react"; import { Link } from "react-router-dom";
const UserList = () => {
  const users = [1,2,3,4,5].map(id => ({id, name: `User ${id}`}));
  return (<div><h3>User List</h3><ul>{users.map(u => (
    <li key={u.id}><Link to={`/users/${u.id}`}>{u.name}</Link></li>
  ))}</ul></div>);
};
export default UserList;