import React from "react";
const About = () => <div><h1>About Page</h1><p>React Router v6 demo.</p></div>;
export default About;