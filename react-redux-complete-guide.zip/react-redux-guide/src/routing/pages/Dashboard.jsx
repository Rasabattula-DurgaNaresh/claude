import React from "react";
const Dashboard = () => <div><h1>Dashboard</h1><p>Protected — only for logged-in users.</p></div>;
export default Dashboard;