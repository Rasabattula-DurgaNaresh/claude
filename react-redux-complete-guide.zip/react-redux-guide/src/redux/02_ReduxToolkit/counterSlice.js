/**
 * TOPIC: Redux Toolkit — createSlice, configureStore
 * RTK is the RECOMMENDED way to use Redux. Less boilerplate.
 */
import { createSlice } from "@reduxjs/toolkit";

// createSlice generates action types, action creators, AND the reducer
const counterSlice = createSlice({
  name: "counter",   // prefix for action types: "counter/increment"
  initialState: { value: 0, step: 1, history: [] },
  reducers: {
    // Each function becomes an action creator + handles that action type
    increment: (state) => {
      // Immer allows "mutating" syntax — actually creates new state immutably
      state.value += state.step;
      state.history.push({ type: "increment", value: state.value });
    },
    decrement: (state) => {
      state.value -= state.step;
      state.history.push({ type: "decrement", value: state.value });
    },
    incrementByAmount: (state, action) => {
      state.value += action.payload;
    },
    setStep: (state, action) => {
      state.step = action.payload;
    },
    reset: () => ({ value: 0, step: 1, history: [] }), // Full state replace
  },
});

// Named exports — action creators
export const { increment, decrement, incrementByAmount, setStep, reset } = counterSlice.actions;

// Selectors
export const selectCount   = (state) => state.counter.value;
export const selectStep    = (state) => state.counter.step;
export const selectHistory = (state) => state.counter.history;

export default counterSlice.reducer;
