/**
 * Redux Toolkit — configureStore (replaces createStore + combineReducers)
 */
import { configureStore } from "@reduxjs/toolkit";
import counterReducer from "./counterSlice";
import todosReducer   from "./todosSlice";

const store = configureStore({
  reducer: {
    counter: counterReducer,
    todos:   todosReducer,
    // Add more slices here
  },
  // RTK includes redux-thunk by default
  // Also includes Redux DevTools Extension automatically
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializabilityCheck: true,  // Warns about non-serializable state
    }),
  devTools: process.env.NODE_ENV !== "production",  // DevTools in dev only
});

export default store;
