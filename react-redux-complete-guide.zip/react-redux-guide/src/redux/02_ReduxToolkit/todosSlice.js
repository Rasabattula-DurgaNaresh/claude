/**
 * Redux Toolkit — Todos Slice with CRUD
 */
import { createSlice } from "@reduxjs/toolkit";

const todosSlice = createSlice({
  name: "todos",
  initialState: {
    items: [
      { id: 1, text: "Learn Redux Toolkit", done: true, priority: "high" },
      { id: 2, text: "Build a React app",   done: false, priority: "medium" },
    ],
    filter: "all",  // all | active | done
  },
  reducers: {
    addTodo: {
      reducer: (state, action) => { state.items.push(action.payload); },
      // prepare lets you transform the payload before it hits the reducer
      prepare: (text, priority = "medium") => ({
        payload: { id: Date.now(), text, done: false, priority, createdAt: new Date().toISOString() }
      }),
    },
    toggleTodo:  (state, action) => {
      const todo = state.items.find(t => t.id === action.payload);
      if (todo) todo.done = !todo.done;
    },
    deleteTodo:  (state, action) => {
      state.items = state.items.filter(t => t.id !== action.payload);
    },
    updateTodo:  (state, action) => {
      const idx = state.items.findIndex(t => t.id === action.payload.id);
      if (idx !== -1) state.items[idx] = { ...state.items[idx], ...action.payload };
    },
    setFilter:   (state, action) => { state.filter = action.payload; },
    clearDone:   (state)         => { state.items = state.items.filter(t => !t.done); },
  },
});

export const { addTodo, toggleTodo, deleteTodo, updateTodo, setFilter, clearDone } = todosSlice.actions;

// Selectors with filter logic
export const selectAllTodos    = (state) => state.todos.items;
export const selectFilter      = (state) => state.todos.filter;
export const selectFilteredTodos = (state) => {
  const { items, filter } = state.todos;
  if (filter === "active") return items.filter(t => !t.done);
  if (filter === "done")   return items.filter(t => t.done);
  return items;
};
export const selectTodoStats = (state) => ({
  total:   state.todos.items.length,
  done:    state.todos.items.filter(t => t.done).length,
  active:  state.todos.items.filter(t => !t.done).length,
});

export default todosSlice.reducer;
