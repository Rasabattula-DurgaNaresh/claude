/**
 * Redux Toolkit Counter — using useSelector and useDispatch
 */
import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { increment, decrement, incrementByAmount, setStep, reset,
         selectCount, selectStep, selectHistory } from "./counterSlice";

const Counter = () => {
  const count   = useSelector(selectCount);
  const step    = useSelector(selectStep);
  const history = useSelector(selectHistory);
  const dispatch = useDispatch();

  const btn = (handler, label, color = "#3b82f6") => (
    <button onClick={handler}
      style={{ padding: "8px 16px", margin: "4px", background: color,
               color: "white", border: "none", borderRadius: "6px", cursor: "pointer", fontSize: "16px" }}>
      {label}
    </button>
  );

  return (
    <div style={{ padding: "20px", maxWidth: "400px" }}>
      <h2>RTK Counter</h2>
      <div style={{ fontSize: "3rem", fontWeight: "bold", textAlign: "center", margin: "16px 0" }}>
        {count}
      </div>
      <div style={{ display: "flex", justifyContent: "center", flexWrap: "wrap" }}>
        {btn(() => dispatch(decrement()), `- ${step}`)}
        {btn(() => dispatch(increment()), `+ ${step}`, "#22c55e")}
        {btn(() => dispatch(reset()), "Reset", "#ef4444")}
        {btn(() => dispatch(incrementByAmount(10)), "+10")}
        {btn(() => dispatch(incrementByAmount(-10)), "-10", "#f59e0b")}
      </div>
      <div style={{ marginTop: "16px" }}>
        <label>Step: <input type="number" value={step} min={1} max={100}
          onChange={e => dispatch(setStep(Number(e.target.value)))}
          style={{ width: "60px", padding: "4px", marginLeft: "8px" }} /></label>
      </div>
      <div style={{ marginTop: "16px", background: "#f8fafc", borderRadius: "6px", padding: "10px" }}>
        <strong>History:</strong>
        <div style={{ fontFamily: "monospace", fontSize: "12px" }}>
          {history.slice(-5).map((h, i) => (
            <span key={i} style={{ marginRight: "8px", color: "#64748b" }}>
              {h.type}→{h.value}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Counter;
