/**
 * TOPIC: createAsyncThunk — Async operations with Redux Toolkit
 * Automatically dispatches: pending, fulfilled, rejected actions.
 */
import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

// ── Define async thunk ────────────────────────────────────────────────────────
export const fetchUsers = createAsyncThunk(
  "users/fetchAll",            // action type prefix
  async (_, { rejectWithValue }) => {
    try {
      const res = await fetch("https://jsonplaceholder.typicode.com/users?_limit=5");
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();  // becomes action.payload in fulfilled
    } catch (err) {
      return rejectWithValue(err.message);  // goes to rejected
    }
  }
);

export const fetchUserById = createAsyncThunk(
  "users/fetchById",
  async (userId, { rejectWithValue }) => {
    try {
      const res = await fetch(`https://jsonplaceholder.typicode.com/users/${userId}`);
      return await res.json();
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const createUser = createAsyncThunk(
  "users/create",
  async (userData, { rejectWithValue }) => {
    try {
      const res = await fetch("https://jsonplaceholder.typicode.com/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(userData),
      });
      return await res.json();
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

// ── Slice with extraReducers for async actions ────────────────────────────────
const usersSlice = createSlice({
  name: "users",
  initialState: {
    list:     [],
    selected: null,
    loading:  false,
    error:    null,
    status:   "idle",  // idle | loading | succeeded | failed
  },
  reducers: {
    clearSelected: (state) => { state.selected = null; },
    clearError:    (state) => { state.error = null; },
  },
  extraReducers: (builder) => {
    // fetchUsers
    builder
      .addCase(fetchUsers.pending, (state) => {
        state.loading = true;
        state.status  = "loading";
        state.error   = null;
      })
      .addCase(fetchUsers.fulfilled, (state, action) => {
        state.loading = false;
        state.status  = "succeeded";
        state.list    = action.payload;
      })
      .addCase(fetchUsers.rejected, (state, action) => {
        state.loading = false;
        state.status  = "failed";
        state.error   = action.payload;
      });

    // fetchUserById
    builder
      .addCase(fetchUserById.pending,    (state)          => { state.loading = true; })
      .addCase(fetchUserById.fulfilled,  (state, action)  => { state.loading = false; state.selected = action.payload; })
      .addCase(fetchUserById.rejected,   (state, action)  => { state.loading = false; state.error = action.payload; });

    // createUser
    builder
      .addCase(createUser.fulfilled, (state, action) => {
        state.list.unshift(action.payload);
      });
  },
});

export const { clearSelected, clearError } = usersSlice.actions;

// Selectors
export const selectUsers    = (state) => state.users.list;
export const selectSelected = (state) => state.users.selected;
export const selectLoading  = (state) => state.users.loading;
export const selectError    = (state) => state.users.error;
export const selectStatus   = (state) => state.users.status;

export default usersSlice.reducer;
