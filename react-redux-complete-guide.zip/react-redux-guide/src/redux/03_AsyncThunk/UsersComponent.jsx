/**
 * Async Thunk — Users List with loading/error states
 */
import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { fetchUsers, fetchUserById, createUser,
         selectUsers, selectLoading, selectError, selectSelected, clearSelected } from "./usersSlice";

const UsersComponent = () => {
  const dispatch  = useDispatch();
  const users     = useSelector(selectUsers);
  const loading   = useSelector(selectLoading);
  const error     = useSelector(selectError);
  const selected  = useSelector(selectSelected);
  const [newName, setNewName] = useState("");

  useEffect(() => {
    dispatch(fetchUsers());
  }, [dispatch]);

  const handleCreate = async () => {
    if (!newName.trim()) return;
    await dispatch(createUser({ name: newName, email: `${newName.toLowerCase()}@example.com` }));
    setNewName("");
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>Users (createAsyncThunk)</h2>

      {/* Create */}
      <div style={{ marginBottom: "16px", display: "flex", gap: "8px" }}>
        <input value={newName} onChange={e => setNewName(e.target.value)}
          placeholder="New user name" style={{ padding: "8px", flex: 1 }} />
        <button onClick={handleCreate} style={{ padding: "8px 16px", background: "#22c55e", color: "white", border: "none", borderRadius: "6px" }}>
          Add User
        </button>
        <button onClick={() => dispatch(fetchUsers())} style={{ padding: "8px 16px", background: "#3b82f6", color: "white", border: "none", borderRadius: "6px" }}>
          Refresh
        </button>
      </div>

      {/* Status */}
      {loading && <div style={{ padding: "12px", background: "#eff6ff", borderRadius: "6px" }}>⏳ Loading...</div>}
      {error   && <div style={{ padding: "12px", background: "#fef2f2", color: "red", borderRadius: "6px" }}>❌ {error}</div>}

      {/* Selected user detail */}
      {selected && (
        <div style={{ padding: "12px", background: "#f0fdf4", borderRadius: "6px", marginBottom: "12px" }}>
          <strong>{selected.name}</strong> — {selected.email}
          <button onClick={() => dispatch(clearSelected())} style={{ marginLeft: "12px" }}>×</button>
        </div>
      )}

      {/* User list */}
      <ul style={{ listStyle: "none", padding: 0 }}>
        {users.map(user => (
          <li key={user.id}
            onClick={() => dispatch(fetchUserById(user.id))}
            style={{ padding: "12px", marginBottom: "8px", background: "#f8fafc",
                     borderRadius: "8px", border: "1px solid #e2e8f0", cursor: "pointer" }}>
            <strong>{user.name}</strong>
            <span style={{ color: "#64748b", marginLeft: "12px" }}>{user.email}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default UsersComponent;
