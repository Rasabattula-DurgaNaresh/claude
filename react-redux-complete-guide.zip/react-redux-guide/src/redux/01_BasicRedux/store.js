/**
 * TOPIC: Basic Redux (Vanilla) — Store, Actions, Reducers
 * Redux = single source of truth. State is read-only. Changes via pure reducers.
 */
import { createStore, combineReducers, applyMiddleware } from "redux";
import { thunk } from "redux-thunk";  // For async actions

// ── 1. Action Types ───────────────────────────────────────────────────────────
export const ActionTypes = {
  // Counter
  INCREMENT:    "counter/INCREMENT",
  DECREMENT:    "counter/DECREMENT",
  INCREMENT_BY: "counter/INCREMENT_BY",
  RESET:        "counter/RESET",
  // Todo
  ADD_TODO:    "todos/ADD",
  TOGGLE_TODO: "todos/TOGGLE",
  DELETE_TODO: "todos/DELETE",
};

// ── 2. Action Creators ────────────────────────────────────────────────────────
export const increment    = ()        => ({ type: ActionTypes.INCREMENT });
export const decrement    = ()        => ({ type: ActionTypes.DECREMENT });
export const incrementBy  = (amount)  => ({ type: ActionTypes.INCREMENT_BY, payload: amount });
export const reset        = ()        => ({ type: ActionTypes.RESET });
export const addTodo      = (text)    => ({ type: ActionTypes.ADD_TODO,    payload: { id: Date.now(), text, done: false } });
export const toggleTodo   = (id)      => ({ type: ActionTypes.TOGGLE_TODO, payload: id });
export const deleteTodo   = (id)      => ({ type: ActionTypes.DELETE_TODO,  payload: id });

// Async action creator (thunk)
export const fetchUser = (userId) => async (dispatch) => {
  dispatch({ type: "user/FETCH_REQUEST" });
  try {
    const res  = await fetch(`https://jsonplaceholder.typicode.com/users/${userId}`);
    const user = await res.json();
    dispatch({ type: "user/FETCH_SUCCESS", payload: user });
  } catch (err) {
    dispatch({ type: "user/FETCH_FAILURE", payload: err.message });
  }
};

// ── 3. Reducers — pure functions (state, action) => newState ──────────────────
const counterInitial = { value: 0, history: [] };

const counterReducer = (state = counterInitial, action) => {
  switch (action.type) {
    case ActionTypes.INCREMENT:
      return { ...state, value: state.value + 1, history: [...state.history, "+1"] };
    case ActionTypes.DECREMENT:
      return { ...state, value: state.value - 1, history: [...state.history, "-1"] };
    case ActionTypes.INCREMENT_BY:
      return { ...state, value: state.value + action.payload, history: [...state.history, `+${action.payload}`] };
    case ActionTypes.RESET:
      return { ...counterInitial };
    default:
      return state;  // Always return state for unknown actions!
  }
};

const todosReducer = (state = [], action) => {
  switch (action.type) {
    case ActionTypes.ADD_TODO:
      return [...state, action.payload];
    case ActionTypes.TOGGLE_TODO:
      return state.map(t => t.id === action.payload ? { ...t, done: !t.done } : t);
    case ActionTypes.DELETE_TODO:
      return state.filter(t => t.id !== action.payload);
    default:
      return state;
  }
};

const userReducer = (state = { data: null, loading: false, error: null }, action) => {
  switch (action.type) {
    case "user/FETCH_REQUEST": return { ...state, loading: true, error: null };
    case "user/FETCH_SUCCESS": return { ...state, loading: false, data: action.payload };
    case "user/FETCH_FAILURE": return { ...state, loading: false, error: action.payload };
    default: return state;
  }
};

// ── 4. Root Reducer — combine all reducers ────────────────────────────────────
const rootReducer = combineReducers({
  counter: counterReducer,
  todos:   todosReducer,
  user:    userReducer,
});

// ── 5. Store — single store for entire app ────────────────────────────────────
const store = createStore(
  rootReducer,
  applyMiddleware(thunk)  // Enable async thunk actions
);

export default store;
