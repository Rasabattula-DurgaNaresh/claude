/**
 * TOPIC: Custom Redux Middleware
 * Middleware intercepts actions BETWEEN dispatch and reducer.
 * Signature: store => next => action => { ... }
 */

// ── 1. Logger Middleware — logs every action and state change ─────────────────
export const loggerMiddleware = (store) => (next) => (action) => {
  const prevState = store.getState();
  console.group(`Action: ${action.type}`);
  console.log("Prev State:", prevState);
  console.log("Action:", action);
  const result = next(action);  // Call next middleware / reducer
  console.log("Next State:", store.getState());
  console.groupEnd();
  return result;
};

// ── 2. Error Handler Middleware ───────────────────────────────────────────────
export const errorMiddleware = (store) => (next) => (action) => {
  try {
    return next(action);
  } catch (err) {
    console.error("Redux Error:", err);
    store.dispatch({ type: "app/GLOBAL_ERROR", payload: err.message });
    throw err;
  }
};

// ── 3. Analytics Middleware ───────────────────────────────────────────────────
export const analyticsMiddleware = (store) => (next) => (action) => {
  // Track certain actions to analytics service
  const trackedActions = ["user/login", "purchase/complete", "onboarding/step"];
  if (trackedActions.includes(action.type)) {
    console.log("[Analytics] Event tracked:", action.type, action.payload);
    // analyticsService.track(action.type, action.payload);
  }
  return next(action);
};

// ── 4. Rate Limiter Middleware ────────────────────────────────────────────────
const actionTimestamps = {};
export const rateLimiterMiddleware = (limitMs = 1000) => (store) => (next) => (action) => {
  const now = Date.now();
  const last = actionTimestamps[action.type] || 0;
  if (now - last < limitMs) {
    console.warn(`[RateLimit] Action ${action.type} throttled`);
    return;
  }
  actionTimestamps[action.type] = now;
  return next(action);
};

// ── 5. Persistence Middleware ─────────────────────────────────────────────────
export const persistenceMiddleware = (keys = []) => (store) => (next) => (action) => {
  const result = next(action);
  const state  = store.getState();
  const toSave = keys.reduce((acc, key) => ({ ...acc, [key]: state[key] }), {});
  localStorage.setItem("redux_persist", JSON.stringify(toSave));
  return result;
};

// ── Usage in store ────────────────────────────────────────────────────────────
// configureStore({
//   reducer: { ... },
//   middleware: (getDefault) => getDefault()
//     .concat(loggerMiddleware)
//     .concat(analyticsMiddleware)
//     .concat(persistenceMiddleware(["user", "settings"])),
// });
