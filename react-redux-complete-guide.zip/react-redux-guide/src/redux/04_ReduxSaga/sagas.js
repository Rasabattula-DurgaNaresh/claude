/**
 * TOPIC: Redux Saga — Generator-based async side effects
 * Sagas are "watchers" that intercept actions and handle side effects.
 * Uses ES6 generator functions (function*).
 */
import { call, put, takeEvery, takeLatest, select, all, fork, delay } from "redux-saga/effects";

// ── Action Types ──────────────────────────────────────────────────────────────
export const SAGA_ACTIONS = {
  FETCH_POSTS_REQUEST:  "saga/FETCH_POSTS_REQUEST",
  FETCH_POSTS_SUCCESS:  "saga/FETCH_POSTS_SUCCESS",
  FETCH_POSTS_FAILURE:  "saga/FETCH_POSTS_FAILURE",
  SEARCH_POSTS_REQUEST: "saga/SEARCH_POSTS_REQUEST",
};

// ── API calls ─────────────────────────────────────────────────────────────────
const api = {
  fetchPosts: (limit = 5) =>
    fetch(`https://jsonplaceholder.typicode.com/posts?_limit=${limit}`).then(r => r.json()),
  searchPosts: (query) =>
    fetch(`https://jsonplaceholder.typicode.com/posts?title_like=${query}`).then(r => r.json()),
};

// ── Worker Sagas (handle individual actions) ──────────────────────────────────
function* fetchPostsSaga(action) {
  try {
    // call — effect: calls an async function
    const posts = yield call(api.fetchPosts, action.payload?.limit || 5);
    // put — effect: dispatches an action
    yield put({ type: SAGA_ACTIONS.FETCH_POSTS_SUCCESS, payload: posts });
  } catch (error) {
    yield put({ type: SAGA_ACTIONS.FETCH_POSTS_FAILURE, payload: error.message });
  }
}

// debounced search using delay
function* searchPostsSaga(action) {
  yield delay(400);  // wait before firing (debounce)
  try {
    const posts = yield call(api.searchPosts, action.payload);
    yield put({ type: SAGA_ACTIONS.FETCH_POSTS_SUCCESS, payload: posts });
  } catch (error) {
    yield put({ type: SAGA_ACTIONS.FETCH_POSTS_FAILURE, payload: error.message });
  }
}

// ── Watcher Sagas ─────────────────────────────────────────────────────────────
function* watchFetchPosts() {
  // takeEvery: run saga for EVERY matching action (parallel)
  yield takeEvery(SAGA_ACTIONS.FETCH_POSTS_REQUEST, fetchPostsSaga);
}

function* watchSearchPosts() {
  // takeLatest: only run the LATEST, cancel previous (for search/debounce)
  yield takeLatest(SAGA_ACTIONS.SEARCH_POSTS_REQUEST, searchPostsSaga);
}

// ── Root Saga ─────────────────────────────────────────────────────────────────
export function* rootSaga() {
  // all — run multiple sagas in parallel
  yield all([
    fork(watchFetchPosts),
    fork(watchSearchPosts),
  ]);
}

// ── Action Creators ───────────────────────────────────────────────────────────
export const fetchPostsRequest  = (limit)  => ({ type: SAGA_ACTIONS.FETCH_POSTS_REQUEST, payload: { limit } });
export const searchPostsRequest = (query)  => ({ type: SAGA_ACTIONS.SEARCH_POSTS_REQUEST, payload: query });

export default rootSaga;
