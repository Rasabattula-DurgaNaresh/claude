/**
 * TOPIC: RTK Query — Automated Data Fetching & Caching
 * RTK Query eliminates manual loading/error states and caching logic.
 * It is the recommended approach for data fetching with Redux Toolkit.
 */
import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

export const postsApi = createApi({
  reducerPath: "postsApi",  // Key in Redux store
  baseQuery: fetchBaseQuery({
    baseUrl: "https://jsonplaceholder.typicode.com",
    // Global headers
    prepareHeaders: (headers, { getState }) => {
      const token = getState().auth?.token;
      if (token) headers.set("Authorization", `Bearer ${token}`);
      return headers;
    },
  }),
  // Cache invalidation tags
  tagTypes: ["Post", "User", "Comment"],

  endpoints: (builder) => ({
    // ── GET: Fetch all posts ─────────────────────────────────────────────────
    getPosts: builder.query({
      query: (limit = 5) => `/posts?_limit=${limit}`,
      providesTags: (result) =>
        result
          ? [...result.map(({ id }) => ({ type: "Post", id })), { type: "Post", id: "LIST" }]
          : [{ type: "Post", id: "LIST" }],
      // Transform response
      transformResponse: (posts) => posts.map(p => ({ ...p, title: p.title.toUpperCase() })),
    }),

    // ── GET: Fetch single post ────────────────────────────────────────────────
    getPostById: builder.query({
      query: (id) => `/posts/${id}`,
      providesTags: (result, error, id) => [{ type: "Post", id }],
    }),

    // ── POST: Create post ─────────────────────────────────────────────────────
    createPost: builder.mutation({
      query: (newPost) => ({
        url: "/posts",
        method: "POST",
        body: newPost,
      }),
      // Invalidate list cache after creating
      invalidatesTags: [{ type: "Post", id: "LIST" }],
    }),

    // ── PUT: Update post ──────────────────────────────────────────────────────
    updatePost: builder.mutation({
      query: ({ id, ...body }) => ({
        url: `/posts/${id}`,
        method: "PUT",
        body,
      }),
      invalidatesTags: (result, error, { id }) => [{ type: "Post", id }],
    }),

    // ── DELETE: Delete post ───────────────────────────────────────────────────
    deletePost: builder.mutation({
      query: (id) => ({ url: `/posts/${id}`, method: "DELETE" }),
      invalidatesTags: (result, error, id) => [{ type: "Post", id }, { type: "Post", id: "LIST" }],
    }),

    // ── GET: Users ────────────────────────────────────────────────────────────
    getUsers: builder.query({
      query: () => "/users?_limit=5",
      providesTags: ["User"],
    }),
  }),
});

// Auto-generated hooks — one per endpoint!
export const {
  useGetPostsQuery,
  useGetPostByIdQuery,
  useCreatePostMutation,
  useUpdatePostMutation,
  useDeletePostMutation,
  useGetUsersQuery,
} = postsApi;

export default postsApi;
