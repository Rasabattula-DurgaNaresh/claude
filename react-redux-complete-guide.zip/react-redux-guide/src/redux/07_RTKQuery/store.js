
import { configureStore } from "@reduxjs/toolkit";
import { postsApi } from "./apiSlice";
import counterReducer from "../02_ReduxToolkit/counterSlice";
import todosReducer   from "../02_ReduxToolkit/todosSlice";
import usersReducer   from "../03_AsyncThunk/usersSlice";

const store = configureStore({
  reducer: {
    counter:        counterReducer,
    todos:          todosReducer,
    users:          usersReducer,
    [postsApi.reducerPath]: postsApi.reducer,  // RTK Query cache reducer
  },
  middleware: (getDefault) => getDefault().concat(postsApi.middleware),
});

export default store;
