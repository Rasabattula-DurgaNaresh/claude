/**
 * RTK Query — Posts component using auto-generated hooks
 */
import React, { useState } from "react";
import { useGetPostsQuery, useCreatePostMutation, useDeletePostMutation } from "./apiSlice";

const PostsComponent = () => {
  const [limit, setLimit]   = useState(5);
  const [newTitle, setNewTitle] = useState("");

  // RTK Query hook — automatically handles loading, error, caching, refetching
  const {
    data: posts,
    isLoading,
    isFetching,  // true during background refetch
    isError,
    error,
    refetch,
  } = useGetPostsQuery(limit, {
    pollingInterval: 0,          // Set to ms for auto-refresh
    refetchOnFocus: false,       // Refetch when window focuses
    skip: false,                 // Set true to skip the query
  });

  const [createPost, { isLoading: creating }] = useCreatePostMutation();
  const [deletePost, { isLoading: deleting }] = useDeletePostMutation();

  const handleCreate = async () => {
    if (!newTitle.trim()) return;
    try {
      await createPost({ title: newTitle, body: "New post body", userId: 1 }).unwrap();
      setNewTitle("");
    } catch (err) {
      console.error("Create failed:", err);
    }
  };

  if (isLoading) return <div style={{ padding: "20px" }}>Loading posts...</div>;
  if (isError)   return <div style={{ padding: "20px", color: "red" }}>Error: {error?.message}</div>;

  return (
    <div style={{ padding: "20px", maxWidth: "600px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h2>Posts (RTK Query)</h2>
        <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
          <label>Limit: <select value={limit} onChange={e => setLimit(Number(e.target.value))}
            style={{ padding: "4px" }}>
            {[3,5,10].map(n => <option key={n} value={n}>{n}</option>)}
          </select></label>
          <button onClick={refetch} disabled={isFetching}
            style={{ padding: "6px 12px", background: "#3b82f6", color: "white", border: "none", borderRadius: "6px" }}>
            {isFetching ? "..." : "Refetch"}
          </button>
        </div>
      </div>

      {/* Create */}
      <div style={{ display: "flex", gap: "8px", marginBottom: "16px" }}>
        <input value={newTitle} onChange={e => setNewTitle(e.target.value)}
          placeholder="New post title" style={{ padding: "8px", flex: 1 }} />
        <button onClick={handleCreate} disabled={creating}
          style={{ padding: "8px 16px", background: "#22c55e", color: "white", border: "none", borderRadius: "6px" }}>
          {creating ? "..." : "Create"}
        </button>
      </div>

      {/* Posts list */}
      <ul style={{ listStyle: "none", padding: 0 }}>
        {posts?.map(post => (
          <li key={post.id} style={{ padding: "12px", marginBottom: "8px",
                                      background: "#f8fafc", borderRadius: "8px",
                                      border: "1px solid #e2e8f0",
                                      display: "flex", justifyContent: "space-between" }}>
            <div>
              <div style={{ fontWeight: 600, fontSize: "14px" }}>{post.title.slice(0, 50)}...</div>
              <div style={{ color: "#64748b", fontSize: "12px" }}>ID: {post.id}</div>
            </div>
            <button onClick={() => deletePost(post.id)} disabled={deleting}
              style={{ background: "#ef4444", color: "white", border: "none",
                       borderRadius: "4px", padding: "4px 10px", cursor: "pointer" }}>
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default PostsComponent;
