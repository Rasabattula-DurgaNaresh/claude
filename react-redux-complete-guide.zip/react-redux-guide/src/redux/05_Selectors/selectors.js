/**
 * TOPIC: Reselect — Memoized Selectors
 * Selectors compute derived data from state. createSelector memoizes the result.
 */
import { createSelector } from "reselect";

// ── Input Selectors (simple, non-memoized) ────────────────────────────────────
const selectTodosState  = (state) => state.todos.items;
const selectFilter      = (state) => state.todos.filter;
const selectCounter     = (state) => state.counter.value;

// ── Memoized Selectors — only recomputed when inputs change ───────────────────

// 1. Filter todos (recomputes only if todos or filter changes)
export const selectFilteredTodos = createSelector(
  [selectTodosState, selectFilter],
  (todos, filter) => {
    console.log("Computing filtered todos...");  // Only logs when inputs change
    switch (filter) {
      case "active": return todos.filter(t => !t.done);
      case "done":   return todos.filter(t => t.done);
      default:       return todos;
    }
  }
);

// 2. Stats selector
export const selectTodoStats = createSelector(
  [selectTodosState],
  (todos) => ({
    total:  todos.length,
    done:   todos.filter(t => t.done).length,
    active: todos.filter(t => !t.done).length,
    highPriority: todos.filter(t => t.priority === "high").length,
  })
);

// 3. Composed selectors — selectors using other selectors
export const selectActiveTodoCount = createSelector(
  [selectTodoStats],
  (stats) => stats.active
);

// 4. Parametric selector (using currying)
export const makeSelectTodoById = (id) =>
  createSelector(
    [selectTodosState],
    (todos) => todos.find(t => t.id === id)
  );

// 5. Complex derived data
export const selectTodosByPriority = createSelector(
  [selectTodosState],
  (todos) => ({
    high:   todos.filter(t => t.priority === "high"),
    medium: todos.filter(t => t.priority === "medium"),
    low:    todos.filter(t => t.priority === "low"),
  })
);
