/**
 * TOPIC: Axios Configuration — Base instance, interceptors, error handling
 */
import axios from "axios";

// Create base instance
const api = axios.create({
  baseURL: "https://jsonplaceholder.typicode.com",
  timeout: 10000,
  headers: {
    "Content-Type": "application/json",
    "Accept":       "application/json",
  },
});

// ── Request Interceptor ────────────────────────────────────────────────────────
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("auth_token");
    if (token) config.headers.Authorization = `Bearer ${token}`;
    config.metadata = { startTime: Date.now() };
    console.log(`[API] ${config.method?.toUpperCase()} ${config.url}`);
    return config;
  },
  (error) => Promise.reject(error)
);

// ── Response Interceptor ───────────────────────────────────────────────────────
api.interceptors.response.use(
  (response) => {
    const duration = Date.now() - response.config.metadata.startTime;
    console.log(`[API] ${response.status} ${response.config.url} (${duration}ms)`);
    return response;
  },
  async (error) => {
    const { response, config } = error;

    // Auto-retry once on 503
    if (response?.status === 503 && !config._retry) {
      config._retry = true;
      await new Promise(r => setTimeout(r, 1000));
      return api(config);
    }

    // Refresh token on 401
    if (response?.status === 401 && !config._refreshed) {
      config._refreshed = true;
      try {
        const newToken = await refreshToken();
        localStorage.setItem("auth_token", newToken);
        config.headers.Authorization = `Bearer ${newToken}`;
        return api(config);
      } catch {
        localStorage.removeItem("auth_token");
        window.location.href = "/login";
      }
    }

    return Promise.reject({
      message: response?.data?.message || error.message || "Network error",
      status:  response?.status,
      data:    response?.data,
    });
  }
);

const refreshToken = async () => {
  const res = await axios.post("/auth/refresh", {
    refreshToken: localStorage.getItem("refresh_token")
  });
  return res.data.accessToken;
};

export default api;
