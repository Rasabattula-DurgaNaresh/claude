/**
 * TOPIC: Service Layer — Clean API abstraction
 */
import api from "./axiosConfig";

// ── Generic CRUD factory ───────────────────────────────────────────────────────
const createService = (resource) => ({
  getAll:   (params = {}) => api.get(`/${resource}`, { params }),
  getById:  (id)          => api.get(`/${resource}/${id}`),
  create:   (data)        => api.post(`/${resource}`, data),
  update:   (id, data)    => api.put(`/${resource}/${id}`, data),
  patch:    (id, data)    => api.patch(`/${resource}/${id}`, data),
  delete:   (id)          => api.delete(`/${resource}/${id}`),
});

// ── Resource-specific services ─────────────────────────────────────────────────
export const postsService = {
  ...createService("posts"),
  getByUser: (userId) => api.get("/posts", { params: { userId } }),
  search:    (query)  => api.get("/posts", { params: { title_like: query } }),
};

export const usersService = {
  ...createService("users"),
  getProfile: ()      => api.get("/users/me"),
  updateProfile:(data)=> api.put("/users/me", data),
};

export const commentsService = createService("comments");

export default { postsService, usersService, commentsService };
