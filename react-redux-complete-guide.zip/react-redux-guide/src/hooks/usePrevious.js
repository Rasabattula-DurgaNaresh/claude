/**
 * Custom Hook: usePrevious — Track previous value of state/prop
 */
import { useRef, useEffect } from "react";

const usePrevious = (value) => {
  const ref = useRef(undefined);
  useEffect(() => { ref.current = value; }); // runs after render — captures previous
  return ref.current;
};

// Usage:
// const [count, setCount] = useState(0);
// const prevCount = usePrevious(count);
// <p>Prev: {prevCount}, Current: {count}</p>

export default usePrevious;
