/**
 * Demo: All Custom Hooks in action
 */
import React, { useState } from "react";
import useFetch from "./useFetch";
import useLocalStorage from "./useLocalStorage";
import useDebounce from "./useDebounce";
import usePrevious from "./usePrevious";
import useWindowSize from "./useWindowSize";

export const FetchDemo = () => {
  const { data, loading, error, refetch } =
    useFetch("https://jsonplaceholder.typicode.com/users?_limit=3");
  return (
    <div>
      <h3>useFetch</h3>
      <button onClick={refetch} disabled={loading}>
        {loading ? "Loading..." : "Refetch"}
      </button>
      {error && <p style={{ color: "red" }}>Error: {error}</p>}
      {data && <ul>{data.map(u => <li key={u.id}>{u.name} — {u.email}</li>)}</ul>}
    </div>
  );
};

export const LocalStorageDemo = () => {
  const [theme, setTheme, removeTheme] = useLocalStorage("app-theme", "light");
  return (
    <div>
      <h3>useLocalStorage</h3>
      <p>Current theme: <b>{theme}</b></p>
      <button onClick={() => setTheme(t => t === "light" ? "dark" : "light")}>Toggle</button>
      <button onClick={removeTheme} style={{ marginLeft: "8px" }}>Reset</button>
    </div>
  );
};

export const DebounceDemo = () => {
  const [search, setSearch] = useState("");
  const debounced = useDebounce(search, 400);
  return (
    <div>
      <h3>useDebounce</h3>
      <input value={search} onChange={e => setSearch(e.target.value)}
        placeholder="Type to search (debounced)" style={{ padding: "6px", width: "100%" }} />
      <p>Debounced value: <b>{debounced}</b></p>
    </div>
  );
};

export const PreviousDemo = () => {
  const [count, setCount] = useState(0);
  const prev = usePrevious(count);
  return (
    <div>
      <h3>usePrevious</h3>
      <p>Previous: <b>{prev ?? "none"}</b> → Current: <b>{count}</b></p>
      <button onClick={() => setCount(c => c + 1)}>Increment</button>
    </div>
  );
};

export const WindowSizeDemo = () => {
  const { width, height, isMobile, isTablet, isDesktop } = useWindowSize();
  return (
    <div>
      <h3>useWindowSize</h3>
      <p>Size: {width} × {height}</p>
      <p>Device: <b>{isMobile ? "Mobile" : isTablet ? "Tablet" : "Desktop"}</b></p>
    </div>
  );
};

const CustomHooksDemo = () => (
  <div style={{ padding: "20px" }}>
    <h1>Custom Hooks</h1>
    <FetchDemo />
    <LocalStorageDemo />
    <DebounceDemo />
    <PreviousDemo />
    <WindowSizeDemo />
  </div>
);

export default CustomHooksDemo;
