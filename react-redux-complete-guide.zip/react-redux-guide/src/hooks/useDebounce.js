/**
 * Custom Hook: useDebounce — Delay value update (useful for search)
 */
import { useState, useEffect } from "react";

const useDebounce = (value, delay = 500) => {
  const [debouncedValue, setDebouncedValue] = useState(value);

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(timer); // cleanup on value/delay change
  }, [value, delay]);

  return debouncedValue;
};

// Usage:
// const [search, setSearch] = useState("");
// const debouncedSearch = useDebounce(search, 300);
// useEffect(() => { fetchResults(debouncedSearch); }, [debouncedSearch]);

export default useDebounce;
