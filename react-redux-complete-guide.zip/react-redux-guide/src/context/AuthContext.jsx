/**
 * TOPIC: Context API — Auth Provider
 * Global auth state: user, login, logout, permissions.
 */
import React, { createContext, useContext, useState, useCallback } from "react";

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);

  const login = useCallback(async (credentials) => {
    setLoading(true);
    try {
      // Simulate API call
      await new Promise(r => setTimeout(r, 500));
      if (credentials.email === "admin@test.com" && credentials.password === "password") {
        setUser({ id: 1, name: "Admin User", email: credentials.email, role: "admin",
                  permissions: ["read", "write", "delete"] });
        return { success: true };
      }
      throw new Error("Invalid credentials");
    } catch (err) {
      return { success: false, error: err.message };
    } finally {
      setLoading(false);
    }
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    localStorage.removeItem("auth_token");
  }, []);

  const hasPermission = useCallback((permission) => {
    return user?.permissions?.includes(permission) ?? false;
  }, [user]);

  const value = { user, loading, login, logout, hasPermission,
                  isAuthenticated: !!user, isAdmin: user?.role === "admin" };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used within AuthProvider");
  return context;
};

// Protected route component
export const RequireAuth = ({ children, permission }) => {
  const { isAuthenticated, hasPermission } = useAuth();

  if (!isAuthenticated) return <p>Please log in to view this content.</p>;
  if (permission && !hasPermission(permission))
    return <p>You do not have permission to view this.</p>;

  return children;
};

export default AuthContext;
