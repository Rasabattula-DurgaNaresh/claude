/**
 * TOPIC: Context API — Theme Provider
 * Avoids prop drilling by making theme available to any nested component.
 */
import React, { createContext, useContext, useState } from "react";

// 1. Create context with default value
const ThemeContext = createContext({
  theme: "light",
  toggleTheme: () => {},
  colors: {},
});

// 2. Theme definitions
const themes = {
  light: { bg: "#ffffff", text: "#1e293b", primary: "#3b82f6",
           card: "#f8fafc", border: "#e2e8f0" },
  dark:  { bg: "#0f172a", text: "#e2e8f0", primary: "#60a5fa",
           card: "#1e293b", border: "#334155" },
};

// 3. Provider component
export const ThemeProvider = ({ children }) => {
  const [theme, setTheme] = useState("light");
  const toggleTheme = () => setTheme(t => t === "light" ? "dark" : "light");

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme, colors: themes[theme] }}>
      <div style={{ background: themes[theme].bg, color: themes[theme].text,
                    minHeight: "100vh", transition: "all 0.3s" }}>
        {children}
      </div>
    </ThemeContext.Provider>
  );
};

// 4. Custom hook for easy consumption
export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) throw new Error("useTheme must be used within ThemeProvider");
  return context;
};

// 5. Example consumers
export const ThemedCard = ({ title, children }) => {
  const { colors } = useTheme();
  return (
    <div style={{ background: colors.card, border: `1px solid ${colors.border}`,
                  borderRadius: "8px", padding: "16px", margin: "8px 0" }}>
      <h3 style={{ color: colors.primary, marginTop: 0 }}>{title}</h3>
      {children}
    </div>
  );
};

export const ThemeToggle = () => {
  const { theme, toggleTheme } = useTheme();
  return (
    <button onClick={toggleTheme}
      style={{ padding: "8px 16px", borderRadius: "6px", cursor: "pointer",
               background: theme === "dark" ? "#60a5fa" : "#1e293b",
               color: theme === "dark" ? "#0f172a" : "#e2e8f0", border: "none" }}>
      {theme === "light" ? "🌙 Dark" : "☀️ Light"}
    </button>
  );
};

export default ThemeContext;
