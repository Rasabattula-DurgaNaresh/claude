/**
 * Main App — Navigation through all topics
 */
import React, { useState } from "react";
import { Provider } from "react-redux";
import store from "./redux/02_ReduxToolkit/store";
import { ThemeProvider } from "./context/ThemeContext";
import { AuthProvider } from "./context/AuthContext";

import JSXExamples             from "./components/01_JSX/JSXExamples";
import FunctionalComponents    from "./components/02_FunctionalComponents/FunctionalComponents";
import ClassComponents         from "./components/03_ClassComponents/ClassComponents";
import HooksExamples           from "./components/04_Hooks/HooksExamples";
import EventHandling           from "./components/05_EventHandling/EventHandling";
import ConditionalRendering    from "./components/06_ConditionalRendering/ConditionalRendering";
import ListsAndKeys            from "./components/07_Lists/ListsAndKeys";
import Forms                   from "./components/08_Forms/Forms";
import CustomHooksDemo         from "./hooks/CustomHooksDemo";
import Counter                 from "./redux/02_ReduxToolkit/CounterComponent";
import UsersComponent          from "./redux/03_AsyncThunk/UsersComponent";
import PostsComponent          from "./redux/07_RTKQuery/PostsComponent";
import Memoization             from "./advanced/Memoization";
import CodeSplitting           from "./advanced/CodeSplitting";
import ErrorBoundaryDemo       from "./advanced/ErrorBoundary";
import HigherOrderComponents   from "./advanced/HigherOrderComponents";

const TOPICS = [
  { id: "jsx",          label: "1. JSX",                  Component: JSXExamples },
  { id: "functional",   label: "2. Functional Components", Component: FunctionalComponents },
  { id: "class",        label: "3. Class Components",      Component: ClassComponents },
  { id: "hooks",        label: "4. React Hooks",           Component: HooksExamples },
  { id: "events",       label: "5. Event Handling",        Component: EventHandling },
  { id: "conditional",  label: "6. Conditional Rendering", Component: ConditionalRendering },
  { id: "lists",        label: "7. Lists & Keys",          Component: ListsAndKeys },
  { id: "forms",        label: "8. Forms",                 Component: Forms },
  { id: "customhooks",  label: "9. Custom Hooks",          Component: CustomHooksDemo },
  { id: "rtk",          label: "10. Redux Toolkit",        Component: Counter },
  { id: "thunk",        label: "11. Async Thunk",          Component: UsersComponent },
  { id: "rtkquery",     label: "12. RTK Query",            Component: PostsComponent },
  { id: "memo",         label: "13. Memoization",          Component: Memoization },
  { id: "splitting",    label: "14. Code Splitting",       Component: CodeSplitting },
  { id: "errorboundary",label: "15. Error Boundary",       Component: ErrorBoundaryDemo },
  { id: "hoc",          label: "16. HOC Pattern",          Component: HigherOrderComponents },
];

const App = () => {
  const [active, setActive] = useState("jsx");
  const ActiveComponent = TOPICS.find(t => t.id === active)?.Component || JSXExamples;

  return (
    <Provider store={store}>
      <ThemeProvider>
        <AuthProvider>
          <div style={{ display: "flex", minHeight: "100vh", fontFamily: "system-ui, sans-serif" }}>
            {/* Sidebar */}
            <nav style={{ width: "220px", background: "#0f172a", padding: "16px 0",
                          overflowY: "auto", flexShrink: 0, position: "fixed",
                          top: 0, bottom: 0, left: 0 }}>
              <div style={{ padding: "16px 20px 20px", borderBottom: "1px solid #1e293b" }}>
                <div style={{ color: "#60a5fa", fontWeight: "bold", fontSize: "16px" }}>⚛️ React + Redux</div>
                <div style={{ color: "#475569", fontSize: "12px", marginTop: "4px" }}>Complete Guide</div>
              </div>
              {TOPICS.map(topic => (
                <button key={topic.id} onClick={() => setActive(topic.id)}
                  style={{
                    display: "block", width: "100%", textAlign: "left",
                    padding: "10px 20px", background: active === topic.id ? "#1e3a5f" : "transparent",
                    color: active === topic.id ? "#60a5fa" : "#94a3b8",
                    border: "none", cursor: "pointer", fontSize: "13px",
                    borderLeft: active === topic.id ? "3px solid #60a5fa" : "3px solid transparent",
                  }}>
                  {topic.label}
                </button>
              ))}
            </nav>

            {/* Content */}
            <main style={{ marginLeft: "220px", flex: 1, padding: "0", minHeight: "100vh" }}>
              <div style={{ background: "#f8fafc", padding: "12px 24px",
                            borderBottom: "1px solid #e2e8f0", position: "sticky", top: 0, zIndex: 10 }}>
                <span style={{ color: "#64748b", fontSize: "13px" }}>
                  {TOPICS.find(t => t.id === active)?.label}
                </span>
              </div>
              <div style={{ padding: "0" }}>
                <ActiveComponent />
              </div>
            </main>
          </div>
        </AuthProvider>
      </ThemeProvider>
    </Provider>
  );
};

export default App;
