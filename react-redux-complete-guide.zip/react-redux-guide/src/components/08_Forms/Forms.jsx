/**
 * TOPIC 8: Forms — Controlled vs Uncontrolled, Validation
 */
import React, { useState, useRef } from "react";

// 1. Controlled form — React controls value via state
const ControlledForm = () => {
  const [formData, setFormData] = useState({
    name: "", email: "", password: "", role: "user",
    agree: false, skills: [],
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const handle = (e) => {
    const { name, value, type, checked } = e.target;
    if (type === "checkbox" && name === "skills") {
      setFormData(f => ({
        ...f, skills: checked
          ? [...f.skills, value]
          : f.skills.filter(s => s !== value)
      }));
    } else {
      setFormData(f => ({ ...f, [name]: type === "checkbox" ? checked : value }));
    }
  };

  const validate = () => {
    const errs = {};
    if (!formData.name.trim()) errs.name = "Name is required";
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(formData.email)) errs.email = "Valid email required";
    if (formData.password.length < 8) errs.password = "Min 8 characters";
    if (!formData.agree) errs.agree = "Must agree to terms";
    return errs;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setErrors({});
    setSubmitted(true);
    console.log("Form submitted:", formData);
  };

  const inp = { padding: "8px", width: "100%", boxSizing: "border-box", marginTop: "4px" };
  const err = { color: "red", fontSize: "12px", marginTop: "2px" };

  if (submitted) return (
    <div style={{ padding: "16px", background: "#f0fdf4", borderRadius: "8px" }}>
      <h3>✅ Submitted!</h3>
      <pre>{JSON.stringify(formData, null, 2)}</pre>
      <button onClick={() => setSubmitted(false)}>Reset</button>
    </div>
  );

  return (
    <form onSubmit={handleSubmit} style={{ maxWidth: "400px" }}>
      <div style={{ marginBottom: "12px" }}>
        <label>Name:<input name="name" value={formData.name} onChange={handle} style={inp} /></label>
        {errors.name && <p style={err}>{errors.name}</p>}
      </div>
      <div style={{ marginBottom: "12px" }}>
        <label>Email:<input name="email" type="email" value={formData.email} onChange={handle} style={inp} /></label>
        {errors.email && <p style={err}>{errors.email}</p>}
      </div>
      <div style={{ marginBottom: "12px" }}>
        <label>Password:<input name="password" type="password" value={formData.password} onChange={handle} style={inp} /></label>
        {errors.password && <p style={err}>{errors.password}</p>}
      </div>
      <div style={{ marginBottom: "12px" }}>
        <label>Role:<select name="role" value={formData.role} onChange={handle} style={inp}>
          <option value="user">User</option>
          <option value="admin">Admin</option>
          <option value="moderator">Moderator</option>
        </select></label>
      </div>
      <div style={{ marginBottom: "12px" }}>
        <p>Skills:</p>
        {["React","Redux","TypeScript","Node.js"].map(skill => (
          <label key={skill} style={{ display: "block" }}>
            <input type="checkbox" name="skills" value={skill}
              checked={formData.skills.includes(skill)} onChange={handle} />
            {" "}{skill}
          </label>
        ))}
      </div>
      <div style={{ marginBottom: "12px" }}>
        <label>
          <input type="checkbox" name="agree" checked={formData.agree} onChange={handle} />
          {" "}I agree to terms
        </label>
        {errors.agree && <p style={err}>{errors.agree}</p>}
      </div>
      <button type="submit" style={{ padding: "10px 20px", background: "#3b82f6", color: "white",
        border: "none", borderRadius: "6px", cursor: "pointer", width: "100%" }}>
        Submit
      </button>
    </form>
  );
};

// 2. Uncontrolled form — DOM manages values, accessed via ref
const UncontrolledForm = () => {
  const nameRef = useRef();
  const emailRef = useRef();

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Name:", nameRef.current.value);
    console.log("Email:", emailRef.current.value);
    alert(`Submitted: ${nameRef.current.value}`);
  };

  return (
    <form onSubmit={handleSubmit}>
      <input ref={nameRef} defaultValue="Default Name" placeholder="Name"
        style={{ display: "block", padding: "8px", margin: "8px 0" }} />
      <input ref={emailRef} type="email" placeholder="Email"
        style={{ display: "block", padding: "8px", margin: "8px 0" }} />
      <button type="submit">Submit (check console)</button>
    </form>
  );
};

const Forms = () => (
  <div style={{ padding: "20px" }}>
    <h1>Forms</h1>
    <h2>1. Controlled Form (with validation)</h2>
    <ControlledForm />
    <h2>2. Uncontrolled Form (ref-based)</h2>
    <UncontrolledForm />
  </div>
);

export default Forms;
