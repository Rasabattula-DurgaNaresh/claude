/**
 * TOPIC 4: React Hooks — All Built-in Hooks
 * Hooks let functional components use state and lifecycle features.
 * Rules: Only call at the top level. Only call in React functions.
 */
import React, {
  useState, useEffect, useRef, useMemo, useCallback,
  useReducer, useContext, useLayoutEffect, useId,
  createContext
} from "react";

// ── 1. useState ───────────────────────────────────────────────────────────────
const UseStateDemo = () => {
  const [count, setCount] = useState(0);
  const [user, setUser] = useState({ name: "", email: "" });
  const [items, setItems] = useState(["Apple", "Banana"]);

  return (
    <div>
      {/* Primitive state */}
      <p>Count: {count}</p>
      <button onClick={() => setCount(c => c + 1)}>+</button>
      <button onClick={() => setCount(c => c - 1)}>-</button>
      <button onClick={() => setCount(0)}>Reset</button>

      {/* Object state — spread to preserve other fields */}
      <input
        placeholder="Name"
        value={user.name}
        onChange={e => setUser(u => ({ ...u, name: e.target.value }))} />
      <p>User: {JSON.stringify(user)}</p>

      {/* Array state */}
      <button onClick={() => setItems(arr => [...arr, `Item ${arr.length + 1}`])}>
        Add Item
      </button>
      <button onClick={() => setItems(arr => arr.slice(0, -1))}>Remove Last</button>
      <ul>{items.map((it, i) => <li key={i}>{it}</li>)}</ul>
    </div>
  );
};

// ── 2. useEffect ──────────────────────────────────────────────────────────────
const UseEffectDemo = () => {
  const [count, setCount] = useState(0);
  const [data, setData]   = useState(null);

  // Runs after every render
  useEffect(() => {
    document.title = `Count: ${count}`;
  });

  // Runs once (componentDidMount)
  useEffect(() => {
    console.log("Mounted!");
    return () => console.log("Unmounted!"); // cleanup
  }, []);

  // Runs when count changes (componentDidUpdate for count)
  useEffect(() => {
    if (count > 0) console.log("Count changed to:", count);
  }, [count]);

  // Async data fetching inside useEffect
  useEffect(() => {
    let cancelled = false;
    async function fetchData() {
      // Fake fetch
      await new Promise(r => setTimeout(r, 100));
      if (!cancelled) setData("Fetched: User list");
    }
    fetchData();
    return () => { cancelled = true; }; // Cancel on cleanup
  }, []);

  return (
    <div>
      <p>Count: {count} (title updated)</p>
      <button onClick={() => setCount(c => c + 1)}>Increment</button>
      <p>{data || "Loading..."}</p>
    </div>
  );
};

// ── 3. useRef ─────────────────────────────────────────────────────────────────
const UseRefDemo = () => {
  const inputRef   = useRef(null);
  const renderCount = useRef(0);    // Mutable value, no re-render
  const timerRef   = useRef(null);
  const [started, setStarted] = useState(false);

  renderCount.current += 1;

  const startTimer = () => {
    setStarted(true);
    timerRef.current = setInterval(() => console.log("tick"), 1000);
  };
  const stopTimer = () => {
    clearInterval(timerRef.current);
    setStarted(false);
  };

  return (
    <div>
      <input ref={inputRef} placeholder="Click Focus to focus me" />
      <button onClick={() => inputRef.current.focus()}>Focus Input</button>
      <p>Render count: {renderCount.current}</p>
      <button onClick={started ? stopTimer : startTimer}>
        {started ? "Stop" : "Start"} Timer
      </button>
    </div>
  );
};

// ── 4. useMemo — expensive computation caching ────────────────────────────────
const UseMemoDemo = () => {
  const [nums, setNums] = useState([1, 2, 3, 4, 5]);
  const [darkMode, setDarkMode] = useState(false);

  // Only recomputes when nums changes, not when darkMode toggles
  const total = useMemo(() => {
    console.log("Computing total...");
    return nums.reduce((a, b) => a + b, 0);
  }, [nums]);

  return (
    <div style={{ background: darkMode ? "#333" : "#fff", color: darkMode ? "#fff" : "#000", padding: "10px" }}>
      <p>Total: {total} (check console)</p>
      <button onClick={() => setNums(n => [...n, n.length + 1])}>Add Number</button>
      <button onClick={() => setDarkMode(d => !d)}>Toggle Dark Mode</button>
    </div>
  );
};

// ── 5. useCallback — memoize functions ────────────────────────────────────────
const Child = React.memo(({ onClick, name }) => {
  console.log(`${name} re-rendered`);
  return <button onClick={onClick}>{name}</button>;
});

const UseCallbackDemo = () => {
  const [countA, setCountA] = useState(0);
  const [countB, setCountB] = useState(0);

  // Without useCallback: new function every render → Child always re-renders
  // With useCallback: same function reference → Child only re-renders if deps change
  const incrementA = useCallback(() => setCountA(c => c + 1), []);
  const incrementB = useCallback(() => setCountB(c => c + 1), []);

  return (
    <div>
      <p>A: {countA} | B: {countB}</p>
      <Child onClick={incrementA} name="Increment A" />
      <Child onClick={incrementB} name="Increment B" />
    </div>
  );
};

// ── 6. useReducer — complex state logic ───────────────────────────────────────
const todoReducer = (state, action) => {
  switch (action.type) {
    case "ADD":
      return [...state, { id: Date.now(), text: action.payload, done: false }];
    case "TOGGLE":
      return state.map(t => t.id === action.payload ? { ...t, done: !t.done } : t);
    case "DELETE":
      return state.filter(t => t.id !== action.payload);
    default:
      return state;
  }
};

const UseReducerDemo = () => {
  const [todos, dispatch] = useReducer(todoReducer, []);
  const [text, setText] = useState("");

  return (
    <div>
      <input value={text} onChange={e => setText(e.target.value)} placeholder="New todo" />
      <button onClick={() => { dispatch({ type: "ADD", payload: text }); setText(""); }}>
        Add
      </button>
      <ul>
        {todos.map(t => (
          <li key={t.id} style={{ textDecoration: t.done ? "line-through" : "none" }}>
            <span onClick={() => dispatch({ type: "TOGGLE", payload: t.id })}>{t.text}</span>
            <button onClick={() => dispatch({ type: "DELETE", payload: t.id })}>❌</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

// ── 7. useContext ─────────────────────────────────────────────────────────────
const ThemeCtx = createContext({ theme: "light", toggle: () => {} });

const ThemeButton = () => {
  const { theme, toggle } = useContext(ThemeCtx);
  return (
    <button
      onClick={toggle}
      style={{ background: theme === "dark" ? "#333" : "#eee",
               color: theme === "dark" ? "#fff" : "#000" }}>
      Current: {theme} — Click to toggle
    </button>
  );
};

const UseContextDemo = () => {
  const [theme, setTheme] = useState("light");
  const toggle = () => setTheme(t => t === "light" ? "dark" : "light");
  return (
    <ThemeCtx.Provider value={{ theme, toggle }}>
      <div style={{ padding: "10px", background: theme === "dark" ? "#222" : "#f9f9f9" }}>
        <p>Theme Provider Demo</p>
        <ThemeButton />
      </div>
    </ThemeCtx.Provider>
  );
};

// ── 8. useId — generate unique IDs (React 18) ─────────────────────────────────
const FormField = ({ label, type = "text" }) => {
  const id = useId(); // Stable unique ID per component instance
  return (
    <div>
      <label htmlFor={id}>{label}:</label>
      <input id={id} type={type} style={{ marginLeft: "8px" }} />
    </div>
  );
};

// ── Main Export ───────────────────────────────────────────────────────────────
const HooksExamples = () => (
  <div style={{ padding: "20px", fontFamily: "sans-serif" }}>
    <h1>React Hooks</h1>
    <h2>1. useState</h2>           <UseStateDemo />
    <h2>2. useEffect</h2>          <UseEffectDemo />
    <h2>3. useRef</h2>             <UseRefDemo />
    <h2>4. useMemo</h2>            <UseMemoDemo />
    <h2>5. useCallback + memo</h2> <UseCallbackDemo />
    <h2>6. useReducer</h2>         <UseReducerDemo />
    <h2>7. useContext</h2>         <UseContextDemo />
    <h2>8. useId (React 18)</h2>
    <FormField label="Username" />
    <FormField label="Password" type="password" />
  </div>
);

export default HooksExamples;
