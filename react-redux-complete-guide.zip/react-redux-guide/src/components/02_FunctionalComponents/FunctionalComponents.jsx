/**
 * TOPIC 2: Functional Components & Props
 * Props = inputs passed from parent to child (read-only)
 */
import React from "react";
import PropTypes from "prop-types";

// 1. Basic functional component
const Hello = () => <h1>Hello, World!</h1>;

// 2. Props — data passed from parent
const Greeting = ({ name, age }) => (
  <p>Hello {name}, you are {age} years old.</p>
);

// 3. Default props
const Button = ({ label = "Click Me", color = "blue", onClick }) => (
  <button
    onClick={onClick}
    style={{ background: color, color: "white", padding: "8px 16px", borderRadius: "4px", border: "none", cursor: "pointer" }}>
    {label}
  </button>
);

// 4. PropTypes — runtime type checking
Button.propTypes = {
  label:   PropTypes.string,
  color:   PropTypes.string,
  onClick: PropTypes.func,
};

// 5. Children prop — pass JSX as content
const Card = ({ title, children, style = {} }) => (
  <div style={{ border: "1px solid #ccc", borderRadius: "8px", padding: "16px", margin: "8px", ...style }}>
    <h3 style={{ marginTop: 0 }}>{title}</h3>
    {children}
  </div>
);

// 6. Spread props
const Input = ({ label, ...rest }) => (
  <div>
    <label>{label}</label>
    <input {...rest} style={{ display: "block", padding: "6px", marginTop: "4px" }} />
  </div>
);

// 7. Destructured + renamed + default props
const UserCard = ({ user: { name = "Anonymous", email = "", role = "User" } = {} }) => (
  <Card title="User Profile">
    <p><b>Name:</b> {name}</p>
    <p><b>Email:</b> {email}</p>
    <p><b>Role:</b> {role}</p>
  </Card>
);

// 8. Render props pattern
const MouseTracker = ({ render }) => {
  const [pos, setPos] = React.useState({ x: 0, y: 0 });
  return (
    <div
      style={{ height: "100px", background: "#f0f0f0", position: "relative" }}
      onMouseMove={e => setPos({ x: e.clientX, y: e.clientY })}>
      {render(pos)}
    </div>
  );
};

const FunctionalComponents = () => (
  <div style={{ padding: "20px" }}>
    <Hello />
    <Greeting name="Bob" age={25} />
    <Button label="Submit" color="green" onClick={() => alert("Clicked!")} />
    <Card title="My Card">
      <p>This is card content passed as children.</p>
    </Card>
    <Input label="Email:" type="email" placeholder="Enter email" />
    <UserCard user={{ name: "Alice", email: "alice@example.com", role: "Admin" }} />
    <MouseTracker render={({ x, y }) => <p>Mouse: ({x}, {y})</p>} />
  </div>
);

export default FunctionalComponents;
