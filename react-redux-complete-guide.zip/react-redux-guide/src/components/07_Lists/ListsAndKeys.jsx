/**
 * TOPIC 7: Lists and Keys
 * Rendering arrays of data. Keys help React identify changed items.
 * KEY RULES: Must be unique among siblings, stable, not index (if possible).
 */
import React, { useState } from "react";

const ListsAndKeys = () => {
  const [fruits, setFruits] = useState([
    { id: 1, name: "Apple",  emoji: "🍎", price: 1.20 },
    { id: 2, name: "Banana", emoji: "🍌", price: 0.50 },
    { id: 3, name: "Cherry", emoji: "🍒", price: 3.00 },
    { id: 4, name: "Date",   emoji: "🌴", price: 5.00 },
    { id: 5, name: "Elderberry", emoji: "🫐", price: 4.50 },
  ]);
  const [filter, setFilter] = useState("");
  const [sortBy, setSortBy] = useState("name");
  const [newFruit, setNewFruit] = useState({ name: "", emoji: "🍓", price: "" });

  // Filter
  const filtered = fruits.filter(f =>
    f.name.toLowerCase().includes(filter.toLowerCase()));

  // Sort
  const sorted = [...filtered].sort((a, b) =>
    sortBy === "name" ? a.name.localeCompare(b.name) :
    sortBy === "price" ? a.price - b.price : 0);

  // CRUD
  const addFruit = () => {
    if (!newFruit.name) return;
    setFruits(f => [...f, { ...newFruit, id: Date.now(), price: parseFloat(newFruit.price) || 0 }]);
    setNewFruit({ name: "", emoji: "🍓", price: "" });
  };
  const removeFruit = (id) => setFruits(f => f.filter(fr => fr.id !== id));
  const toggleFavorite = (id) => setFruits(f =>
    f.map(fr => fr.id === id ? { ...fr, favorite: !fr.favorite } : fr));

  return (
    <div style={{ padding: "20px", maxWidth: "600px" }}>
      <h1>Lists & Keys</h1>

      {/* Controls */}
      <div style={{ display: "flex", gap: "8px", marginBottom: "16px" }}>
        <input value={filter} onChange={e => setFilter(e.target.value)}
          placeholder="Filter..." style={{ padding: "6px", flex: 1 }} />
        <select value={sortBy} onChange={e => setSortBy(e.target.value)} style={{ padding: "6px" }}>
          <option value="name">Sort by Name</option>
          <option value="price">Sort by Price</option>
        </select>
      </div>

      {/* List with proper keys */}
      <ul style={{ listStyle: "none", padding: 0 }}>
        {sorted.map(fruit => (
          <li key={fruit.id}  // USE STABLE UNIQUE ID, not index!
              style={{ display: "flex", alignItems: "center", gap: "12px",
                       padding: "10px", marginBottom: "8px",
                       background: fruit.favorite ? "#fef3c7" : "#f8fafc",
                       borderRadius: "8px", border: "1px solid #e2e8f0" }}>
            <span style={{ fontSize: "1.5rem" }}>{fruit.emoji}</span>
            <span style={{ flex: 1, fontWeight: 500 }}>{fruit.name}</span>
            <span style={{ color: "#64748b" }}>${fruit.price.toFixed(2)}</span>
            <button onClick={() => toggleFavorite(fruit.id)}>
              {fruit.favorite ? "★" : "☆"}
            </button>
            <button onClick={() => removeFruit(fruit.id)}
              style={{ background: "#ef4444", color: "white", border: "none",
                       borderRadius: "4px", padding: "4px 8px", cursor: "pointer" }}>
              ×
            </button>
          </li>
        ))}
      </ul>

      {sorted.length === 0 && <p style={{ color: "#94a3b8", textAlign: "center" }}>No fruits found.</p>}

      {/* Add new item */}
      <div style={{ display: "flex", gap: "8px", marginTop: "16px" }}>
        <input value={newFruit.name} onChange={e => setNewFruit(f => ({ ...f, name: e.target.value }))}
          placeholder="Fruit name" style={{ padding: "6px", flex: 2 }} />
        <input value={newFruit.price} onChange={e => setNewFruit(f => ({ ...f, price: e.target.value }))}
          placeholder="Price" type="number" style={{ padding: "6px", flex: 1 }} />
        <button onClick={addFruit}
          style={{ background: "#22c55e", color: "white", border: "none",
                   borderRadius: "4px", padding: "6px 14px", cursor: "pointer" }}>
          Add
        </button>
      </div>

      <p style={{ marginTop: "12px", color: "#64748b" }}>
        Showing {sorted.length} of {fruits.length} fruits
      </p>
    </div>
  );
};

export default ListsAndKeys;
