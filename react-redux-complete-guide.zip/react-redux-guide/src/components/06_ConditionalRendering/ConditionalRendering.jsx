/**
 * TOPIC 6: Conditional Rendering
 * All patterns for showing/hiding elements conditionally.
 */
import React, { useState } from "react";

const ConditionalRendering = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [count, setCount] = useState(0);
  const [status, setStatus] = useState("loading"); // loading|success|error

  // 1. if/else (outside JSX)
  const renderAuthMessage = () => {
    if (isLoggedIn) return <p style={{ color: "green" }}>Welcome back!</p>;
    else return <p style={{ color: "red" }}>Please log in.</p>;
  };

  return (
    <div style={{ padding: "20px" }}>
      <h1>Conditional Rendering</h1>

      <h3>1. if/else with function</h3>
      <button onClick={() => setIsLoggedIn(v => !v)}>Toggle Login</button>
      {renderAuthMessage()}

      <h3>2. Ternary operator</h3>
      <p>{isLoggedIn ? "✅ Logged in" : "❌ Logged out"}</p>

      <h3>3. Logical && (show if truthy)</h3>
      {count > 0 && <p style={{ color: "green" }}>Count is positive: {count}</p>}
      {count < 0 && <p style={{ color: "red" }}>Count is negative: {count}</p>}
      <button onClick={() => setCount(c => c + 1)}>+</button>
      <button onClick={() => setCount(c => c - 1)}>-</button>

      <h3>4. Logical || (fallback)</h3>
      {/* null/undefined || fallback */}
      <p>{null || "No data — showing fallback"}</p>

      <h3>5. Nullish coalescing ??</h3>
      <p>{0 ?? "default"}</p>   {/* 0 is not null/undefined, shows 0 */}
      <p>{null ?? "default"}</p> {/* null → shows "default" */}

      <h3>6. Switch-case pattern</h3>
      <div>
        {["loading","success","error"].map(s => (
          <button key={s} onClick={() => setStatus(s)} style={{ margin: "4px" }}>{s}</button>
        ))}
        {(() => {
          switch(status) {
            case "loading": return <p>⏳ Loading...</p>;
            case "success": return <p style={{ color: "green" }}>✅ Success!</p>;
            case "error":   return <p style={{ color: "red" }}>❌ Error occurred.</p>;
            default:        return <p>Unknown status</p>;
          }
        })()}
      </div>

      <h3>7. Enum pattern</h3>
      {(() => {
        const views = {
          loading: <div>Loading spinner...</div>,
          success: <div style={{ color: "green" }}>Data loaded!</div>,
          error:   <div style={{ color: "red" }}>Failed to load</div>,
        };
        return views[status] || null;
      })()}
    </div>
  );
};

export default ConditionalRendering;
