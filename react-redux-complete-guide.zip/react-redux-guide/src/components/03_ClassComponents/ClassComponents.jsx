/**
 * TOPIC 3: Class Components & Lifecycle Methods
 * Modern React prefers hooks, but class components are still important
 * for understanding legacy code and lifecycle methods.
 */
import React, { Component } from "react";

// 1. Basic class component
class SimpleCounter extends Component {
  constructor(props) {
    super(props);  // Always call super(props) first!
    this.state = { count: 0 };
    // Bind event handler (alternative: use arrow function)
    this.increment = this.increment.bind(this);
  }

  increment() {
    this.setState(prevState => ({ count: prevState.count + 1 }));
  }

  decrement = () => {  // Arrow function — auto-bound, no need to bind
    this.setState(prevState => ({ count: prevState.count - 1 }));
  };

  render() {
    return (
      <div>
        <h2>Count: {this.state.count}</h2>
        <button onClick={this.increment}>+</button>
        <button onClick={this.decrement}>-</button>
      </div>
    );
  }
}

// 2. Full Lifecycle Methods
class LifecycleDemo extends Component {
  constructor(props) {
    super(props);
    this.state = { data: null, loading: true };
    console.log("1. constructor — component created");
  }

  // Runs after component mounts (DOM is ready)
  componentDidMount() {
    console.log("3. componentDidMount — fetch data here");
    // Simulate API call
    setTimeout(() => {
      this.setState({ data: "Fetched Data!", loading: false });
    }, 1000);
  }

  // Called before each render to derive state from props
  static getDerivedStateFromProps(props, state) {
    console.log("2. getDerivedStateFromProps");
    return null;  // Return null for no state update
  }

  // Called after every update (not first render)
  componentDidUpdate(prevProps, prevState) {
    if (prevState.data !== this.state.data) {
      console.log("4. componentDidUpdate — data changed");
    }
  }

  // Cleanup — remove listeners, cancel requests
  componentWillUnmount() {
    console.log("5. componentWillUnmount — cleanup here");
  }

  // Optimize: skip re-render if relevant props/state unchanged
  shouldComponentUpdate(nextProps, nextState) {
    return this.state.count !== nextState.count ||
           this.state.data  !== nextState.data;
  }

  render() {
    console.log("render");
    const { loading, data } = this.state;
    return (
      <div>
        <h3>Lifecycle Demo</h3>
        {loading ? <p>Loading...</p> : <p>Data: {data}</p>}
      </div>
    );
  }
}

// 3. Class component with refs
class FocusInput extends Component {
  constructor(props) {
    super(props);
    this.inputRef = React.createRef();
  }

  focusInput = () => {
    this.inputRef.current.focus();
  };

  render() {
    return (
      <div>
        <input ref={this.inputRef} type="text" placeholder="Click button to focus me" />
        <button onClick={this.focusInput}>Focus Input</button>
      </div>
    );
  }
}

// 4. Error Boundary — class component that catches JS errors in child tree
class ErrorBoundaryClass extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, errorMsg: "" };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, errorMsg: error.message };
  }

  componentDidCatch(error, info) {
    console.error("Error caught by boundary:", error, info);
    // Log to error reporting service (Sentry, etc.)
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{ padding: "16px", background: "#fef2f2", border: "1px solid red", borderRadius: "8px" }}>
          <h3>Something went wrong!</h3>
          <p>{this.state.errorMsg}</p>
          <button onClick={() => this.setState({ hasError: false, errorMsg: "" })}>
            Try Again
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

const BuggyComponent = () => {
  throw new Error("Intentional error for demo!");
};

const ClassComponents = () => (
  <div style={{ padding: "20px" }}>
    <h1>Class Components</h1>
    <h2>1. Counter</h2>
    <SimpleCounter />
    <h2>2. Lifecycle Methods</h2>
    <LifecycleDemo />
    <h2>3. Refs</h2>
    <FocusInput />
    <h2>4. Error Boundary</h2>
    <ErrorBoundaryClass>
      <p>This content is safe.</p>
    </ErrorBoundaryClass>
  </div>
);

export default ClassComponents;
export { ErrorBoundaryClass };
