/**
 * TOPIC 5: Event Handling in React
 * React uses SyntheticEvents — cross-browser wrapper around native events.
 */
import React, { useState } from "react";

const EventHandling = () => {
  const [log, setLog] = useState([]);
  const addLog = msg => setLog(l => [...l.slice(-4), msg]);

  // 1. Click events
  const handleClick = (e) => {
    addLog(`Click at (${e.clientX}, ${e.clientY})`);
  };

  // 2. Keyboard events
  const handleKeyDown = (e) => {
    if (e.key === "Enter") addLog("Enter pressed!");
    if (e.ctrlKey && e.key === "s") { e.preventDefault(); addLog("Ctrl+S blocked!"); }
  };

  // 3. Form events
  const handleChange = (e) => addLog(`Input: ${e.target.value}`);

  // 4. Passing arguments to handlers
  const handleItemClick = (id, name) => addLog(`Item ${id}: ${name} clicked`);

  // 5. Prevent default + stop propagation
  const handleLink = (e) => { e.preventDefault(); addLog("Link prevented!"); };
  const handleParent = () => addLog("Parent clicked");
  const handleChildStop = (e) => { e.stopPropagation(); addLog("Child (stopped propagation)"); };

  // 6. Mouse events
  const [hovered, setHovered] = useState(false);

  return (
    <div style={{ padding: "20px" }}>
      <h1>Event Handling</h1>

      <h3>1. Click</h3>
      <button onClick={handleClick}>Click me</button>

      <h3>2. Keyboard</h3>
      <input onKeyDown={handleKeyDown} placeholder="Type Enter or Ctrl+S" style={{ padding: "6px" }} />

      <h3>3. onChange</h3>
      <input onChange={handleChange} placeholder="Type something" style={{ padding: "6px" }} />

      <h3>4. Passing Arguments</h3>
      {[{id:1,name:"Apple"},{id:2,name:"Banana"},{id:3,name:"Cherry"}].map(item => (
        <button key={item.id} onClick={() => handleItemClick(item.id, item.name)}
          style={{ margin: "4px", padding: "6px 12px" }}>
          {item.name}
        </button>
      ))}

      <h3>5. Prevent Default & Stop Propagation</h3>
      <a href="https://google.com" onClick={handleLink}>Prevented link</a>
      <div onClick={handleParent} style={{ background: "#eee", padding: "12px", marginTop: "8px" }}>
        Parent (click outer area)
        <button onClick={handleChildStop} style={{ margin: "8px", display: "block" }}>
          Child (stops propagation)
        </button>
      </div>

      <h3>6. Hover (Mouse Events)</h3>
      <div
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        style={{ padding: "12px", background: hovered ? "#3b82f6" : "#e5e7eb",
                 color: hovered ? "white" : "black", borderRadius: "6px",
                 transition: "all 0.2s", cursor: "pointer" }}>
        Hover over me!
      </div>

      <h3>Event Log</h3>
      <div style={{ background: "#1e293b", color: "#94d2bd", padding: "12px", borderRadius: "6px", fontFamily: "monospace" }}>
        {log.length === 0 ? <p>Interact above...</p> : log.map((l, i) => <div key={i}>{l}</div>)}
      </div>
    </div>
  );
};

export default EventHandling;
