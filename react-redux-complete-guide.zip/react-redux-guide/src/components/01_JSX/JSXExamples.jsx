/**
 * TOPIC 1: JSX — JavaScript XML
 * JSX lets you write HTML-like syntax inside JavaScript.
 * KEY RULES:
 *   - Single root element (or use Fragment <>)
 *   - className instead of class
 *   - camelCase attributes (onClick, htmlFor)
 *   - Self-close empty tags: <br />, <img />, <input />
 *   - JS expressions inside { }
 */
import React from "react";

// 1. Basic JSX expression embedding
const Expressions = () => {
  const name = "Alice";
  const age  = 30;
  const isAdmin = true;

  return (
    <div>
      <p>Name: {name}</p>
      <p>Age next year: {age + 1}</p>
      <p>Role: {isAdmin ? "Admin" : "User"}</p>
      <p>Time: {new Date().toLocaleTimeString()}</p>
      <p>Upper: {name.toUpperCase()}</p>
    </div>
  );
};

// 2. JSX Attributes — camelCase, className, htmlFor
const Attributes = () => {
  const style = { color: "blue", fontSize: "18px" };
  return (
    <div>
      <p className="highlight">styled paragraph</p>
      <label htmlFor="email">Email:</label>
      <input id="email" type="email" placeholder="Enter email" />
      <p style={style}>Inline styled text</p>
      <input type="checkbox" defaultChecked={true} />
      <button disabled={false}>Active</button>
    </div>
  );
};

// 3. Fragments — return multiple siblings without wrapper div
const FragmentExample = () => (
  <>
    <h2>First</h2>
    <p>Second</p>
    <span>Third</span>
  </>
);

// 4. JSX is compiled to React.createElement()
// <h1>Hello</h1>  ==  React.createElement("h1", null, "Hello")

const JSXExamples = () => (
  <div style={{ padding: "20px" }}>
    <h1>1. Expressions</h1>  <Expressions />
    <h1>2. Attributes</h1>   <Attributes />
    <h1>3. Fragment</h1>     <FragmentExample />
  </div>
);

export default JSXExamples;
