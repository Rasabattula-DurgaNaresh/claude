package com.eda.schema.consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchemaRegistryConsumerApplication {
    public static void main(String[] args) {
        SpringApplication.run(SchemaRegistryConsumerApplication.class, args);
    }
}

