# 100 In-Place Reversal of a Linked List — Complete Java Solutions

> **100 Problems · 4 Java files · 5 PNG diagrams · O(n) O(1) all core patterns**

---

## Diagram Index

| Diagram | Covers |
|---------|--------|
| `diagrams/01_iterative_reversal.png` | 6-step trace of iterative 3-pointer reversal |
| `diagrams/02_sublist_kgroup.png` | Sublist (m to n) + K-Group reversal with code |
| `diagrams/03_rotation_reorder.png` | Rotate right, Reorder List, Palindrome Check |
| `diagrams/04_recursive_doubly.png` | Recursive call stack + Doubly linked list reversal |
| `diagrams/05_decision_tree.png` | Complete decision guide → technique → complexity |

## Project Structure

```
linked-list-reversal-100/
├── pom.xml
├── diagrams/           ← 5 PNG flow diagrams
├── docs/               ← This guide
└── src/main/java/com/linkedlist/
    ├── utils/      ListNode.java              (shared: ListNode + DNode)
    ├── basic/      BasicReversal.java          (B1-B10)
    ├── sublist/    SublistKGroup.java          (S1-S10 + K1-K10)
    └── advanced/   AdvancedProblems.java       (A1-A10, R1-R10, AD1-AD10,
                                                  CD1-CD10, RC1-RC10,
                                                  LC1-LC10, IN1-IN10)
```

**Run:**
```bash
mvn compile exec:java -Dexec.mainClass="com.linkedlist.basic.BasicReversal"
mvn compile exec:java -Dexec.mainClass="com.linkedlist.sublist.SublistKGroup"
mvn compile exec:java -Dexec.mainClass="com.linkedlist.advanced.AdvancedProblems"
```

---

# Master Templates

## Template 1 — Iterative 3-Pointer (Most Used)
```java
// Reverse entire list — O(n) time, O(1) space
// See diagram: 01_iterative_reversal.png
ListNode prev = null, curr = head;
while (curr != null) {
    ListNode next = curr.next;  // 1. Save next node
    curr.next = prev;            // 2. Reverse the link
    prev = curr;                 // 3. Advance prev to curr
    curr = next;                 // 4. Advance curr to next
}
return prev; // prev is now the new head
```

## Template 2 — Recursive
```java
// O(n) time, O(n) space (call stack)
ListNode reverse(ListNode head) {
    if (head == null || head.next == null) return head;
    ListNode newHead = reverse(head.next); // reverse the rest
    head.next.next = head;  // node after head points back to head
    head.next = null;        // cut old forward link
    return newHead;          // propagate new head upward
}
```

## Template 3 — Reverse N Nodes (Building Block)
```java
// Reverse exactly n nodes; return [newHead, tail, nextNode]
ListNode[] reverseN(ListNode head, int n) {
    ListNode prev = null, curr = head;
    for (int i = 0; i < n && curr != null; i++) {
        ListNode next = curr.next;
        curr.next = prev; prev = curr; curr = next;
    }
    return new ListNode[]{prev, head, curr};
    //                    newHead  tail  nextAfter
}
```

## Template 4 — Sublist Reversal (m to n)
```java
// LeetCode 92 — Reverse positions m to n (1-indexed)
ListNode reverseBetween(ListNode head, int m, int n) {
    ListNode dummy = new ListNode(0); dummy.next = head;
    ListNode prev = dummy;
    for (int i = 1; i < m; i++) prev = prev.next; // walk to m-1
    ListNode start = prev.next, tail = start;
    for (int i = 0; i < n - m; i++) {
        ListNode next = tail.next;
        tail.next = next.next;
        next.next = prev.next;
        prev.next = next;        // insert next at front of sublist
    }
    return dummy.next;
}
```

## Template 5 — K-Group Reversal
```java
// LeetCode 25 — Reverse every k nodes; leave remainder as-is
ListNode reverseKGroup(ListNode head, int k) {
    // Check k nodes available
    ListNode check = head; int count = 0;
    while (check != null && count < k) { check = check.next; count++; }
    if (count < k) return head; // not enough, return as-is
    ListNode[] res = reverseN(head, k);
    res[1].next = reverseKGroup(res[2], k); // recurse on remainder
    return res[0]; // new head of reversed group
}
```

## Template 6 — Rotation
```java
// LeetCode 61 — Rotate right by k
ListNode rotateRight(ListNode head, int k) {
    int len = 1; ListNode tail = head;
    while (tail.next != null) { tail = tail.next; len++; }
    k %= len; if (k == 0) return head;
    tail.next = head;  // make circular
    // Find new tail: advance (len - k - 1) steps
    ListNode newTail = head;
    for (int i = 0; i < len - k - 1; i++) newTail = newTail.next;
    ListNode newHead = newTail.next;
    newTail.next = null; // cut
    return newHead;
}
```

## Template 7 — Reorder List
```java
// LeetCode 143 — [1,2,3,4,5] → [1,5,2,4,3]
void reorderList(ListNode head) {
    ListNode mid = findMiddle(head);     // Step 1: find middle
    ListNode second = reverse(mid.next); // Step 2: reverse second half
    mid.next = null;                      // Step 3: split
    // Step 4: interleave
    ListNode l = head, r = second;
    while (r != null) {
        ListNode lt = l.next, rt = r.next;
        l.next = r; r.next = lt; l = lt; r = rt;
    }
}
```

---

# BASIC REVERSAL (B1–B10)

## B1/B2. Reverse a Linked List (Iterative) ⭐
**LeetCode 206** — The fundamental 3-pointer technique.

```
Initial: null ← 1 → 2 → 3 → 4 → 5 → null
                prev  curr
After:   null ← 1 ← 2 ← 3 ← 4 ← 5
                                    ↑ new head = prev
```

**Why O(1) space:** Only 3 pointer variables needed, no auxiliary storage.

---

## B3. Reverse Linked List Recursively ⭐

```
reverse(1→2→3→4→5)
  → reverse(2→3→4→5)
    → reverse(3→4→5)
      → reverse(4→5)
        → reverse(5) = 5  [BASE CASE]
      ← 5.next=4, 4.next=null → 5→4
    ← 5→4→3
  ← 5→4→3→2
← 5→4→3→2→1
```

**Space:** O(n) call stack — worse than iterative!

---

## B4. Reverse Doubly Linked List
Swap `prev` and `next` for every node:

```java
// For each node: swap curr.next and curr.prev
DNode next = curr.next;
curr.next = curr.prev;
curr.prev = next;
// Return the last processed node (new head = old tail)
```

---

## B5. Reverse Circular Linked List
1. Find tail (tail.next == head)
2. Break circle: tail.next = null
3. Standard reverse
4. Restore circle: old head (now tail).next = newHead

---

## B7. Reverse Using Stack
```java
// Push all values, pop to rebuild — O(n) extra space
Deque<Integer> stack = new ArrayDeque<>();
for (ListNode c = head; c != null; c = c.next) stack.push(c.val);
// Rebuild: pop creates reversed order
```

---

## B10. Reverse Values Only
```java
// Collect values into array, fill backwards into same nodes
// Structure (next pointers) unchanged — only values reversed
int[] vals = ...; // collect
ListNode cur = head; int i = n-1;
while (cur != null) { cur.val = vals[i--]; cur = cur.next; }
```

---

# REVERSE SUBLIST (S1–S10)

## S1. Reverse Linked List II ⭐⭐
**LeetCode 92** — One pass, O(n) time, O(1) space.

```
[1→2→3→4→5]  m=2, n=4  →  [1→4→3→2→5]

prev points to node before m=2 (node 1)
"Insertion at front" trick:
  i=0: pull node 3 before 2: 1→3→2→4→5
  i=1: pull node 4 before 3: 1→4→3→2→5
```

---

## S3. Reverse First K Nodes
```java
// Use reverseN(head, k), connect tail to rest
ListNode[] res = reverseN(head, k);
res[1].next = res[2]; // tail → remaining
return res[0];        // new head
```

---

## S4. Reverse Last K Nodes
```java
// Find length n, reverse from position (n-k+1) to n
return reverseBetween(head, len-k+1, len);
```

---

## S5. Reverse Alternate K Nodes
```
[1,2,3,4,5,6,7,8]  k=2:
  reverse 2, skip 2, reverse 2, skip 2
→ [2,1,3,4,6,5,7,8]
```

---

## S6/K1. Reverse Every K-Group ⭐⭐⭐
**LeetCode 25** — Recursion: reverse k, recurse on rest.

```
[1,2,3,4,5]  k=2:  [2,1,4,3,5]
[1,2,3,4,5]  k=3:  [3,2,1,4,5]
              ↑ last group < k → leave as-is
```

---

## S7. Reverse Nodes in Even Length Groups ⭐⭐
**LeetCode 2074** — Groups: sizes 1,2,3,4,...
Reverse group only if actual size is even.

---

# ALTERNATE & PAIRWISE (A1–A10)

## A1/A2. Swap Nodes in Pairs ⭐⭐
**LeetCode 24** — [1,2,3,4] → [2,1,4,3]

```java
// Iterative with dummy head:
// For each pair (a, b): b.next=a, dummy.next=b
prev.next = b; a.next = b.next; b.next = a; prev = a;
```

---

## A7. Swap Pairs Recursively ⭐
```java
// Elegant: swap head with head.next, recurse on rest
ListNode b = head.next;
head.next = swapPairsRecursive(b.next);
b.next = head;
return b;
```

---

## A3/A5/A6. Alternate Node Reversal
Strategy: separate into odd and even position lists, optionally reverse one, then interleave back.

---

# ROTATION & REARRANGEMENT (R1–R10)

## R1/R2. Rotate Right by K ⭐
**LeetCode 61** — See Template 6.

```
[1,2,3,4,5] k=2 → [4,5,1,2,3]
len=5, k%5=2, newTail = node at position 5-2-1=2 (node 3)
newHead = node 4, cut after node 3
```

---

## R3. Rotate Left by K
```java
// Left rotation = Right rotation by (n-k)
return rotateRight(head, len - k % len);
```

---

## R4/R5. Reorder List ⭐⭐
**LeetCode 143** — See Template 7.

```
[1,2,3,4,5]:
  mid = node 3
  reverse [4,5] → [5,4]
  interleave: 1→5→2→4→3
```

---

## R9. Reverse and Merge Two Lists
Reverse both lists, then merge sorted.

---

# ADVANCED APPLICATIONS (AD1–AD10)

## AD1. Reverse Between Critical Points ⭐
**LeetCode 2058** — Find local min/max, reverse between first and last critical point.

---

## AD2. Reverse From Middle
Find middle with fast/slow, reverse second half in place.

---

## AD5. Reverse in Spiral Fashion
Alternately take from front and back of the list to create spiral order.

---

# CIRCULAR & DOUBLY (CD1–CD10)

## CD1. Reverse Circular Doubly Linked List
Swap `next` and `prev` for every node (same as doubly), then restore circular links.

---

## CD2. Reverse Doubly in Groups
Reverse groups of k nodes, maintaining bidirectional links within each group.

---

# RECURSIVE PATTERNS (RC1–RC10)

## RC1. Recursive K-Group
```java
ListNode reverseKGroupRecursive(ListNode head, int k) {
    // Count k nodes
    int count = 0; ListNode cur = head;
    while (cur != null && count < k) { cur = cur.next; count++; }
    if (count < k) return head; // base case
    ListNode[] res = reverseN(head, k);
    res[1].next = reverseKGroupRecursive(res[2], k);
    return res[0];
}
```

---

## RC5. Reverse First N Recursively
```java
// Uses a successor pointer to connect to remaining list
ListNode reverseFirstN(ListNode head, int n) {
    if (n == 1) { successor = head.next; return head; }
    ListNode nh = reverseFirstN(head.next, n-1);
    head.next.next = head;
    head.next = successor; // connect to rest
    return nh;
}
```

---

## RC6. Reverse Segment Recursively (Sublist m to n)
```java
ListNode reverseSegment(ListNode head, int m, int n) {
    if (m == 1) return reverseFirstN(head, n);
    head.next = reverseSegment(head.next, m-1, n-1);
    return head; // walk m-1 steps before reversing
}
```

---

# LEETCODE QUICK REFERENCE

| # | Problem | Core Technique | Time | Space |
|---|---------|---------------|------|-------|
| 206 | Reverse Linked List | 3-pointer iterative | O(n) | O(1) |
| 92  | Reverse Linked List II | Sublist insertion | O(n) | O(1) |
| 25  | Reverse in k-Group | reverseN + recurse | O(n) | O(n/k) |
| 24  | Swap Nodes in Pairs | Dummy + pair swap | O(n) | O(1) |
| 61  | Rotate List | Make circular, cut | O(n) | O(1) |
| 143 | Reorder List | Mid+Reverse+Merge | O(n) | O(1) |
| 234 | Palindrome Linked List | Mid+Rev+Compare | O(n) | O(1) |
| 445 | Add Two Numbers II | Reverse+Add+Reverse | O(n) | O(n) |
| 2074| Even Length Groups | Group traversal | O(n) | O(1) |
| 1721| Swapping Nodes | Two k-th pointer | O(n) | O(1) |

---

# INTERVIEW PROBLEMS (IN1–IN10)

| # | Scenario | Maps To | Technique |
|---|----------|---------|-----------|
| IN1 | Reverse train coaches | Full reversal | 3-pointer |
| IN2 | Reverse browser history | Full reversal | 3-pointer |
| IN3 | Reverse playlist | Full reversal | 3-pointer |
| IN4 | Reverse employee hierarchy | Full reversal | 3-pointer |
| IN5 | Reverse packet order | Full reversal | 3-pointer |
| IN6 | Reverse student roll groups | K-group | reverseKGroup |
| IN7 | Reverse last k undo ops | Last K reversal | reverseBetween |
| IN8 | Reverse memory blocks | K-group | reverseKGroup |
| IN9 | Reverse last k stream | Last K reversal | reverseList on suffix |
| IN10 | Reverse transactions m-n | Sublist m to n | reverseBetween |

---

# Pattern Selection Guide

```
Reverse the ENTIRE list?
  → 3-pointer iterative (Template 1)  — O(n) O(1) ✓
  → Recursive (Template 2)            — O(n) O(n) (stack)

Reverse PART of the list (positions m to n)?
  → Sublist reversal (Template 4)     — O(n) O(1) ✓
  → "Insertion at front" trick

Reverse every K nodes?
  → reverseN + recursion (Template 5) — O(n) O(n/k)
  → leave remainder if < k (LC 25)

ROTATE list right/left by K?
  → Make circular, find cut (Template 6) — O(n) O(1) ✓

REORDER list (interleave ends)?
  → Middle + Reverse + Merge (Template 7) — O(n) O(1) ✓

Check PALINDROME?
  → Middle + Reverse + Compare + Restore  — O(n) O(1) ✓

SWAP adjacent pairs?
  → Dummy head + pair reassignment  — O(n) O(1) ✓

Reverse alternate K nodes?
  → Reverse k, skip k, repeat        — O(n) O(1) ✓

Doubly linked list?
  → Swap each node's prev and next   — O(n) O(1) ✓

Circular linked list?
  → Break → reverse → restore        — O(n) O(1) ✓
```

---

# Complexity Summary

| Operation | Time | Space | Notes |
|-----------|------|-------|-------|
| Full reversal (iterative) | O(n) | O(1) | Preferred approach |
| Full reversal (recursive) | O(n) | O(n) | Call stack |
| Sublist reversal | O(n) | O(1) | Walk + insert |
| K-group reversal | O(n) | O(n/k) | Recursive groups |
| Swap pairs | O(n) | O(1) | Constant pointers |
| Rotate | O(n) | O(1) | Find tail + cut |
| Reorder | O(n) | O(1) | 3 phases |
| Palindrome check | O(n) | O(1) | With restoration |
| Reverse doubly | O(n) | O(1) | Swap prev/next |
| Add two numbers II | O(n) | O(n) | Reverse twice |

---

# The 4 Core Pointer Tricks

```
1. DUMMY HEAD      — ListNode dummy = new ListNode(0); dummy.next = head;
                     Handles edge cases when head itself changes.

2. SAVE NEXT       — ListNode next = curr.next; before modifying curr.next

3. FIND MIDDLE     — slow/fast pointers; fast moves 2x, slow moves 1x
                     When fast=null → slow=middle

4. IN-PLACE SPLICE — Pull tail.next to front of sublist without extra storage
                     Used in LC92 "insertion at front" technique
```

*100 In-Place Reversal of Linked List — Complete Java Solutions | O(n) Time | O(1) Space*
