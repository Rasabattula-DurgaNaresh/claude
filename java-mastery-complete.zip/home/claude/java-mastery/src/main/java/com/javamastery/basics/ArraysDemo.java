package com.javamastery.basics;

import java.util.Arrays;

/**
 * MODULE 1C: Arrays — 1D, 2D, Jagged, Sorting, Searching
 * Real-world: Stock market portfolio management
 */
public class ArraysDemo {

    public static void run() {
        System.out.println("\n══════════════════════════════════════════");
        System.out.println("  MODULE 1C: Arrays");
        System.out.println("══════════════════════════════════════════");

        // ── 1D Array — stock prices ──────────────────────────────────────
        String[] stocks  = {"AAPL", "GOOGL", "MSFT", "AMZN", "TSLA"};
        double[] prices  = {182.50, 141.20, 376.80, 178.90, 248.60};
        int[]    volumes = {45_200, 22_100, 31_500, 18_900, 67_800};

        System.out.println("Portfolio:");
        double portfolioValue = 0;
        for (int i = 0; i < stocks.length; i++) {
            double value = prices[i] * 10; // 10 shares each
            portfolioValue += value;
            System.out.printf("  %-6s $%6.2f × 10 = $%7.2f%n", stocks[i], prices[i], value);
        }
        System.out.printf("  Total Portfolio Value: $%,.2f%n", portfolioValue);

        // ── Array utilities ───────────────────────────────────────────────
        double[] sortedPrices = Arrays.copyOf(prices, prices.length);
        Arrays.sort(sortedPrices);
        System.out.println("\nPrices sorted (ASC): " + Arrays.toString(sortedPrices));

        // Binary search (array must be sorted first)
        int idx = Arrays.binarySearch(sortedPrices, 178.90);
        System.out.println("AMZN ($178.90) found at index: " + idx);

        // Statistics using array
        double max = sortedPrices[sortedPrices.length - 1];
        double min = sortedPrices[0];
        double sum = Arrays.stream(prices).sum();
        double avg = sum / prices.length;
        System.out.printf("Max: $%.2f | Min: $%.2f | Avg: $%.2f%n", max, min, avg);

        // ── 2D Array — weekly stock prices (5 stocks × 5 days) ───────────
        double[][] weeklyPrices = {
            {180.0, 181.5, 182.5, 184.0, 183.2}, // AAPL
            {140.0, 140.8, 141.2, 142.0, 141.5}, // GOOGL
            {375.0, 376.0, 376.8, 378.0, 377.5}, // MSFT
            {177.0, 178.0, 178.9, 180.0, 179.5}, // AMZN
            {245.0, 246.5, 248.6, 250.0, 249.5}  // TSLA
        };
        String[] days = {"Mon", "Tue", "Wed", "Thu", "Fri"};

        System.out.println("\nWeekly Price Matrix:");
        System.out.printf("  %-6s", "Stock");
        for (String day : days) System.out.printf("  %-7s", day);
        System.out.printf("  %-10s  %-10s%n", "Weekly+/-", "Return%");

        for (int s = 0; s < stocks.length; s++) {
            System.out.printf("  %-6s", stocks[s]);
            double startPrice = weeklyPrices[s][0];
            double endPrice   = weeklyPrices[s][4];
            for (int d = 0; d < 5; d++) {
                System.out.printf("  $%-6.1f", weeklyPrices[s][d]);
            }
            double change  = endPrice - startPrice;
            double returnPct = (change / startPrice) * 100;
            System.out.printf("  %+7.2f    %+5.2f%%%n", change, returnPct);
        }

        // ── Jagged Array — unequal quarters reporting ────────────────────
        System.out.println("\nQuarterly Revenue ($ millions):");
        double[][] quarterlyRevenue = {
            {45.2, 48.1, 52.3, 55.7},     // Year 1: 4 quarters
            {58.2, 61.5, 65.0},            // Year 2: 3 quarters (ongoing)
            {70.1}                          // Year 3: 1 quarter (just started)
        };

        for (int y = 0; y < quarterlyRevenue.length; y++) {
            double total = 0;
            System.out.printf("  Year %d: ", y + 1);
            for (double q : quarterlyRevenue[y]) {
                System.out.printf("Q=%.1fM ", q);
                total += q;
            }
            System.out.printf("| Total: $%.1fM%n", total);
        }

        // ── Array rotation (interview classic — useful for sliding windows) ─
        System.out.println("\nArray Rotation (Last N trading days first):");
        double[] recentPrices = Arrays.copyOf(prices, prices.length);
        int rotateBy = 2;
        rotateRight(recentPrices, rotateBy);
        System.out.println("  Original : " + Arrays.toString(prices));
        System.out.println("  Rotated  : " + Arrays.toString(recentPrices));
    }

    // Rotate array to the right by k positions
    static void rotateRight(double[] arr, int k) {
        int n = arr.length;
        k = k % n;
        reverse(arr, 0, n-1);
        reverse(arr, 0, k-1);
        reverse(arr, k, n-1);
    }

    static void reverse(double[] arr, int left, int right) {
        while (left < right) {
            double tmp = arr[left]; arr[left] = arr[right]; arr[right] = tmp;
            left++; right--;
        }
    }
}