package com.javamastery.algorithms;

import java.util.*;

/**
 * MODULE 9: Algorithms & Data Structures
 * Real-world: Search, sort, recursion, DP applied to practical scenarios
 */
public class AlgorithmsDemo {

    public static void run() {
        System.out.println("\n══════════════════════════════════════════");
        System.out.println("  MODULE 9: Algorithms");
        System.out.println("══════════════════════════════════════════");
        sortingDemo();
        searchingDemo();
        recursionDemo();
        dynamicProgrammingDemo();
        dataStructuresDemo();
    }

    // ── SORTING ────────────────────────────────────────────────────────────
    static void sortingDemo() {
        System.out.println("\n--- Sorting Algorithms ---");
        int[] data = {64, 34, 25, 12, 22, 11, 90, 45, 73, 18};

        // Bubble Sort O(n²)
        int[] bubble = Arrays.copyOf(data, data.length);
        for (int i = 0; i < bubble.length - 1; i++) {
            boolean swapped = false;
            for (int j = 0; j < bubble.length - i - 1; j++) {
                if (bubble[j] > bubble[j+1]) {
                    int tmp = bubble[j]; bubble[j] = bubble[j+1]; bubble[j+1] = tmp;
                    swapped = true;
                }
            }
            if (!swapped) break; // already sorted
        }
        System.out.println("  BubbleSort : " + Arrays.toString(bubble));

        // Merge Sort O(n log n)
        int[] merge = Arrays.copyOf(data, data.length);
        mergeSort(merge, 0, merge.length - 1);
        System.out.println("  MergeSort  : " + Arrays.toString(merge));

        // Custom sort: sort employees by salary desc, then name asc
        record Emp(String name, double salary) {}
        List<Emp> employees = new ArrayList<>(List.of(
            new Emp("Alice", 95000), new Emp("Bob", 85000),
            new Emp("Diana", 95000), new Emp("Eve", 60000)
        ));
        employees.sort(Comparator.comparingDouble(Emp::salary).reversed()
                                 .thenComparing(Emp::name));
        System.out.println("  Custom sort (salary desc, name asc):");
        employees.forEach(e -> System.out.printf("    %-8s $%,.0f%n", e.name(), e.salary()));
    }

    static void mergeSort(int[] arr, int l, int r) {
        if (l >= r) return;
        int mid = (l + r) / 2;
        mergeSort(arr, l, mid);
        mergeSort(arr, mid+1, r);
        merge(arr, l, mid, r);
    }

    static void merge(int[] arr, int l, int mid, int r) {
        int[] left  = Arrays.copyOfRange(arr, l, mid+1);
        int[] right = Arrays.copyOfRange(arr, mid+1, r+1);
        int i = 0, j = 0, k = l;
        while (i < left.length && j < right.length) {
            if (left[i] <= right[j]) arr[k++] = left[i++];
            else                     arr[k++] = right[j++];
        }
        while (i < left.length)  arr[k++] = left[i++];
        while (j < right.length) arr[k++] = right[j++];
    }

    // ── SEARCHING ──────────────────────────────────────────────────────────
    static void searchingDemo() {
        System.out.println("\n--- Searching ---");

        // Linear Search O(n) — unsorted data
        int[] prices = {299, 999, 49, 149, 79, 599, 199};
        int   target = 149;
        int   linIdx = -1;
        for (int i = 0; i < prices.length; i++) {
            if (prices[i] == target) { linIdx = i; break; }
        }
        System.out.println("  Linear search " + target + " → index " + linIdx);

        // Binary Search O(log n) — sorted data ONLY
        int[] sorted = Arrays.copyOf(prices, prices.length);
        Arrays.sort(sorted);
        int binIdx = Arrays.binarySearch(sorted, target);
        System.out.println("  Binary search " + target + " in sorted → index " + binIdx);

        // Two-pointer: find pair summing to target
        System.out.println("\n  Two-pointer: pairs summing to 400:");
        int[] nums = {50, 150, 200, 250, 300, 350, 400};
        int tgtSum = 400, left = 0, right = nums.length - 1;
        while (left < right) {
            int sum = nums[left] + nums[right];
            if      (sum == tgtSum) { System.out.println("    " + nums[left] + " + " + nums[right]); left++; right--; }
            else if (sum < tgtSum)  left++;
            else                    right--;
        }

        // Sliding window: max sum of k consecutive elements
        int[] revenue = {100, 200, 150, 300, 250, 400, 350};
        int   k = 3;
        int   windowSum = 0, maxSum = 0;
        for (int i = 0; i < k; i++) windowSum += revenue[i];
        maxSum = windowSum;
        for (int i = k; i < revenue.length; i++) {
            windowSum = windowSum - revenue[i-k] + revenue[i];
            maxSum = Math.max(maxSum, windowSum);
        }
        System.out.printf("  Sliding window (k=%d): max revenue = %d%n", k, maxSum);
    }

    // ── RECURSION ──────────────────────────────────────────────────────────
    static void recursionDemo() {
        System.out.println("\n--- Recursion ---");

        System.out.println("  Factorial(10)     = " + factorial(10));
        System.out.println("  Fibonacci(15)     = " + fib(15));
        System.out.println("  Power(2,10)       = " + power(2, 10));
        System.out.println("  GCD(48,18)        = " + gcd(48, 18));

        // Flatten nested org structure
        System.out.println("  Flatten org:      " + flattenOrg("CEO",
            Map.of("CEO", List.of("CTO","CFO"),
                   "CTO", List.of("Dev1","Dev2"),
                   "CFO", List.of("Acc1"))));
    }

    static long   factorial(int n) { return n <= 1 ? 1 : n * factorial(n-1); }
    static int    fib(int n)       { return n <= 1 ? n : fib(n-1) + fib(n-2); }
    static long   power(long b, int e) { return e == 0 ? 1 : b * power(b, e-1); }
    static int    gcd(int a, int b) { return b == 0 ? a : gcd(b, a%b); }

    static List<String> flattenOrg(String node, Map<String, List<String>> tree) {
        List<String> result = new ArrayList<>();
        result.add(node);
        List<String> children = tree.getOrDefault(node, List.of());
        for (String child : children) {
            result.addAll(flattenOrg(child, tree));
        }
        return result;
    }

    // ── DYNAMIC PROGRAMMING ────────────────────────────────────────────────
    static void dynamicProgrammingDemo() {
        System.out.println("\n--- Dynamic Programming ---");

        // 0/1 Knapsack: pick items within budget to maximise value
        int[]   weights = {2, 3, 4, 5, 9};
        int[]   values  = {3, 4, 5, 6, 10};
        int     capacity= 10;

        int n = weights.length;
        int[][] dp = new int[n+1][capacity+1];

        for (int i = 1; i <= n; i++) {
            for (int w = 0; w <= capacity; w++) {
                dp[i][w] = dp[i-1][w];
                if (weights[i-1] <= w) {
                    dp[i][w] = Math.max(dp[i][w], dp[i-1][w-weights[i-1]] + values[i-1]);
                }
            }
        }
        System.out.println("  Knapsack max value: " + dp[n][capacity]);

        // Fibonacci with memoisation (vs naive recursion)
        Map<Integer, Long> memo = new HashMap<>();
        System.out.println("  Fib(40) memoised: " + fibMemo(40, memo));

        // Longest Common Subsequence (string similarity)
        String s1 = "ABCBDAB", s2 = "BDCAB";
        System.out.println("  LCS("" + s1 + "","" + s2 + "") = " + lcs(s1, s2));

        // Coin change (minimum coins)
        int[] coins  = {1, 5, 10, 25};
        int   amount = 41;
        System.out.println("  MinCoins(" + amount + "¢) = " + minCoins(coins, amount));
    }

    static long fibMemo(int n, Map<Integer, Long> memo) {
        if (n <= 1) return n;
        if (memo.containsKey(n)) return memo.get(n);
        long result = fibMemo(n-1, memo) + fibMemo(n-2, memo);
        memo.put(n, result);
        return result;
    }

    static int lcs(String a, String b) {
        int m = a.length(), n = b.length();
        int[][] dp = new int[m+1][n+1];
        for (int i = 1; i <= m; i++)
            for (int j = 1; j <= n; j++)
                dp[i][j] = a.charAt(i-1) == b.charAt(j-1)
                    ? dp[i-1][j-1] + 1 : Math.max(dp[i-1][j], dp[i][j-1]);
        return dp[m][n];
    }

    static int minCoins(int[] coins, int amount) {
        int[] dp = new int[amount+1];
        Arrays.fill(dp, amount+1);
        dp[0] = 0;
        for (int i = 1; i <= amount; i++)
            for (int c : coins)
                if (c <= i) dp[i] = Math.min(dp[i], dp[i-c]+1);
        return dp[amount] > amount ? -1 : dp[amount];
    }

    // ── DATA STRUCTURES ────────────────────────────────────────────────────
    static void dataStructuresDemo() {
        System.out.println("\n--- Custom Data Structures ---");

        // Stack
        Stack<String> stack = new Stack<>();
        stack.push("("); stack.push("a"); stack.push(")");
        System.out.println("  Stack pop: " + stack.pop());

        // Simple HashMap with chaining (conceptual)
        System.out.println("  HashMap load factor 0.75 → resize at 75% capacity");
        System.out.println("  Bucket collision: chaining (Java 8: tree after 8 entries)");

        // Graph: adjacency list (e.g. social network)
        Map<String, List<String>> graph = new HashMap<>();
        graph.put("Alice",   List.of("Bob","Charlie","Diana"));
        graph.put("Bob",     List.of("Alice","Eve"));
        graph.put("Charlie", List.of("Alice","Frank"));
        graph.put("Diana",   List.of("Alice"));
        graph.put("Eve",     List.of("Bob","Frank"));
        graph.put("Frank",   List.of("Charlie","Eve"));

        // BFS — shortest path (degrees of separation)
        System.out.println("  BFS from Alice → Frank: " + bfs(graph, "Alice", "Frank") + " hops");
    }

    static int bfs(Map<String, List<String>> graph, String start, String target) {
        Queue<String> queue    = new LinkedList<>();
        Set<String>   visited  = new HashSet<>();
        Map<String,Integer> dist = new HashMap<>();
        queue.offer(start); visited.add(start); dist.put(start, 0);
        while (!queue.isEmpty()) {
            String node = queue.poll();
            if (node.equals(target)) return dist.get(node);
            for (String neighbor : graph.getOrDefault(node, List.of())) {
                if (!visited.contains(neighbor)) {
                    visited.add(neighbor);
                    dist.put(neighbor, dist.get(node) + 1);
                    queue.offer(neighbor);
                }
            }
        }
        return -1;
    }
}