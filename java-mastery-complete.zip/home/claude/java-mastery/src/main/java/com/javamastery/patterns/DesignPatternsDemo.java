package com.javamastery.patterns;

import java.util.*;

/**
 * MODULE 8: Design Patterns — Singleton, Builder, Factory, Observer, Strategy
 * Real-world: Configuration, HTTP client, notifications, event bus, sorting
 */
public class DesignPatternsDemo {

    // ── SINGLETON — Application Config ──────────────────────────────────────
    static class AppConfig {
        private static volatile AppConfig instance;
        private final Map<String, String> props = new HashMap<>();

        private AppConfig() {
            props.put("app.name",    "JavaMastery");
            props.put("app.version", "1.0.0");
            props.put("db.host",     "localhost");
            props.put("db.port",     "5432");
            System.out.println("  [AppConfig] Initialised (only once!)");
        }

        public static AppConfig getInstance() {
            if (instance == null) {
                synchronized (AppConfig.class) {
                    if (instance == null) instance = new AppConfig();
                }
            }
            return instance;
        }

        public String get(String key) { return props.getOrDefault(key, ""); }
        public String get(String key, String def) { return props.getOrDefault(key, def); }
        public void   set(String key, String val) { props.put(key, val); }
    }

    // ── BUILDER — HTTP Request ───────────────────────────────────────────────
    static class HttpRequest {
        private final String url, method;
        private final Map<String, String> headers;
        private final String body;
        private final int timeoutMs;
        private final boolean followRedirects;

        private HttpRequest(Builder b) {
            url = b.url; method = b.method; headers = Collections.unmodifiableMap(b.headers);
            body = b.body; timeoutMs = b.timeoutMs; followRedirects = b.followRedirects;
        }

        public static class Builder {
            private final String url;
            private String method = "GET", body;
            private final Map<String, String> headers = new LinkedHashMap<>();
            private int     timeoutMs = 30_000;
            private boolean followRedirects = true;

            public Builder(String url) { this.url = Objects.requireNonNull(url); }

            public Builder get()              { method = "GET";    return this; }
            public Builder post(String body)  { method = "POST";   this.body = body; return this; }
            public Builder put(String body)   { method = "PUT";    this.body = body; return this; }
            public Builder delete()           { method = "DELETE"; return this; }
            public Builder header(String k, String v) { headers.put(k, v); return this; }
            public Builder bearer(String token)       { return header("Authorization", "Bearer " + token); }
            public Builder json()             { return header("Content-Type", "application/json"); }
            public Builder timeout(int ms)    { timeoutMs = ms; return this; }
            public Builder noRedirects()      { followRedirects = false; return this; }
            public HttpRequest build()        { return new HttpRequest(this); }
        }

        @Override
        public String toString() {
            return String.format("%s %s\n    headers=%s timeout=%dms body=%s",
                    method, url, headers, timeoutMs, body != null ? body.substring(0, Math.min(40, body.length())) + "..." : "null");
        }
    }

    // ── FACTORY + ABSTRACT FACTORY — Notification System ────────────────────
    interface Notification {
        void send(String to, String subject, String body);
        String getChannel();
    }

    static class EmailNotification implements Notification {
        public void send(String to, String subj, String body) {
            System.out.printf("  [EMAIL → %s] %s%n  %s%n", to, subj, body);
        }
        public String getChannel() { return "EMAIL"; }
    }

    static class SmsNotification implements Notification {
        public void send(String to, String subj, String body) {
            String short_ = (subj + ": " + body);
            System.out.printf("  [SMS → %s] %s%n",
                    to, short_.substring(0, Math.min(160, short_.length())));
        }
        public String getChannel() { return "SMS"; }
    }

    static class PushNotification implements Notification {
        public void send(String to, String subj, String body) {
            System.out.printf("  [PUSH → %s] 🔔 %s%n", to, subj);
        }
        public String getChannel() { return "PUSH"; }
    }

    static class NotificationFactory {
        public static Notification create(String channel) {
            return switch (channel.toUpperCase()) {
                case "EMAIL" -> new EmailNotification();
                case "SMS"   -> new SmsNotification();
                case "PUSH"  -> new PushNotification();
                default -> throw new IllegalArgumentException("Unknown channel: " + channel);
            };
        }

        public static List<Notification> createAll() {
            return List.of(new EmailNotification(), new SmsNotification(), new PushNotification());
        }
    }

    // ── OBSERVER — Order Event System ────────────────────────────────────────
    interface OrderEventListener {
        void onOrderPlaced(String orderId, String product, double amount);
        String listenerName();
    }

    static class OrderEventBus {
        private final List<OrderEventListener> listeners = new ArrayList<>();
        private int publishCount = 0;

        public void subscribe(OrderEventListener l)   { listeners.add(l); }
        public void unsubscribe(OrderEventListener l) { listeners.remove(l); }

        public void publish(String orderId, String product, double amount) {
            System.out.printf("  [EventBus] Publishing ORDER_PLACED: %s%n", orderId);
            publishCount++;
            listeners.forEach(l -> {
                try { l.onOrderPlaced(orderId, product, amount); }
                catch (Exception e) { System.err.println("    Listener error: " + l.listenerName()); }
            });
        }
    }

    // ── STRATEGY — Discount Calculator ────────────────────────────────────────
    interface DiscountStrategy {
        double apply(double price, int quantity);
        String name();
    }

    static class NoDiscount implements DiscountStrategy {
        public double apply(double price, int qty) { return price * qty; }
        public String name() { return "No Discount"; }
    }

    static class BulkDiscount implements DiscountStrategy {
        public double apply(double price, int qty) {
            double discount = qty >= 100 ? 0.20 : qty >= 50 ? 0.10 : qty >= 10 ? 0.05 : 0;
            return price * qty * (1 - discount);
        }
        public String name() { return "Bulk Discount"; }
    }

    static class SeasonalDiscount implements DiscountStrategy {
        private final double pct;
        public SeasonalDiscount(double pct) { this.pct = pct; }
        public double apply(double price, int qty) { return price * qty * (1 - pct); }
        public String name() { return String.format("Seasonal %.0f%%", pct * 100); }
    }

    static class PricingEngine {
        private DiscountStrategy strategy;

        public void setStrategy(DiscountStrategy s) { this.strategy = s; }

        public double calculate(double price, int qty) {
            double total = strategy.apply(price, qty);
            System.out.printf("  [%s] $%.2f × %d → $%.2f%n",
                    strategy.name(), price, qty, total);
            return total;
        }
    }

    public static void run() {
        System.out.println("\n══════════════════════════════════════════");
        System.out.println("  MODULE 8: Design Patterns");
        System.out.println("══════════════════════════════════════════");

        // SINGLETON
        System.out.println("\n--- Singleton ---");
        AppConfig cfg1 = AppConfig.getInstance();
        AppConfig cfg2 = AppConfig.getInstance();
        System.out.println("  Same instance: " + (cfg1 == cfg2));
        System.out.println("  app.name: " + cfg1.get("app.name"));
        cfg1.set("feature.flag", "true");
        System.out.println("  flag via cfg2: " + cfg2.get("feature.flag")); // same obj!

        // BUILDER
        System.out.println("\n--- Builder ---");
        HttpRequest req = new HttpRequest.Builder("https://api.example.com/v1/orders")
            .post("{"product":"Laptop","qty":5}")
            .json()
            .bearer("eyJhbGciOiJIUzI1NiJ9.abc123")
            .header("X-Request-ID", UUID.randomUUID().toString())
            .header("X-Tenant-ID", "tenant-001")
            .timeout(5_000)
            .build();
        System.out.println("  " + req);

        // FACTORY
        System.out.println("\n--- Factory ---");
        String[] channels = {"EMAIL", "SMS", "PUSH"};
        for (String ch : channels) {
            Notification n = NotificationFactory.create(ch);
            n.send("user@example.com", "Order Shipped", "Your order #1234 is on the way!");
        }

        // OBSERVER
        System.out.println("\n--- Observer ---");
        OrderEventBus bus = new OrderEventBus();

        bus.subscribe(new OrderEventListener() {
            public void onOrderPlaced(String id, String product, double amt) {
                System.out.printf("    [InventoryService] Reserve %s for order %s%n", product, id);
            }
            public String listenerName() { return "InventoryService"; }
        });
        bus.subscribe(new OrderEventListener() {
            public void onOrderPlaced(String id, String product, double amt) {
                System.out.printf("    [EmailService]     Send confirmation for $%.2f%n", amt);
            }
            public String listenerName() { return "EmailService"; }
        });
        bus.subscribe(new OrderEventListener() {
            public void onOrderPlaced(String id, String product, double amt) {
                System.out.printf("    [AnalyticsService]  Log sale: %s $%.2f%n", product, amt);
            }
            public String listenerName() { return "AnalyticsService"; }
        });

        bus.publish("ORD-8821", "MacBook Pro", 2499.99);

        // STRATEGY
        System.out.println("\n--- Strategy ---");
        PricingEngine engine = new PricingEngine();
        double unitPrice = 49.99;

        engine.setStrategy(new NoDiscount());
        engine.calculate(unitPrice, 5);

        engine.setStrategy(new BulkDiscount());
        engine.calculate(unitPrice, 10);
        engine.calculate(unitPrice, 50);
        engine.calculate(unitPrice, 100);

        engine.setStrategy(new SeasonalDiscount(0.25));
        engine.calculate(unitPrice, 20);
    }
}