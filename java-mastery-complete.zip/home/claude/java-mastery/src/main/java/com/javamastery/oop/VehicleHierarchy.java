package com.javamastery.oop;

/**
 * MODULE 2B: OOP — Inheritance, Polymorphism, Method Overriding
 * Real-world: Vehicle fleet management system
 */
public class VehicleHierarchy {

    // ── Abstract base class ─────────────────────────────────────────────
    public static abstract class Vehicle {
        protected String make, model;
        protected int    year;
        protected double odometer; // km driven
        protected boolean engineOn;

        public Vehicle(String make, String model, int year) {
            this.make = make; this.model = model; this.year = year;
        }

        // Abstract: every vehicle starts differently
        public abstract String startEngine();
        public abstract double calculateMonthlyMaintenance();
        public abstract String getVehicleType();

        // Concrete: same for all vehicles
        public void drive(double km) {
            if (!engineOn) throw new IllegalStateException("Start engine first!");
            odometer += km;
            System.out.printf("  [%s %s] Drove %.1f km | Total: %.0f km%n",
                    make, model, km, odometer);
        }

        public final String getRegistration() { // final: cannot override
            return year + "-" + make.substring(0,2).toUpperCase() + "-" + model;
        }

        @Override
        public String toString() {
            return String.format("%s [%d %s %s | %.0f km]",
                    getVehicleType(), year, make, model, odometer);
        }
    }

    // ── Subclass: Car ───────────────────────────────────────────────────
    public static class Car extends Vehicle {
        private String transmission; // MANUAL, AUTO, CVT
        private int    numDoors;
        private double fuelLevel;    // 0.0 – 1.0

        public Car(String make, String model, int year, String transmission) {
            super(make, model, year);
            this.transmission = transmission;
            this.numDoors     = 4;
            this.fuelLevel    = 1.0;
        }

        @Override
        public String startEngine() {
            if (fuelLevel <= 0) return "Cannot start — tank empty!";
            engineOn = true;
            return make + " " + model + " started (" + transmission + ")";
        }

        @Override
        public double calculateMonthlyMaintenance() {
            return 150 + (odometer / 10000) * 50; // base + wear cost
        }

        @Override
        public String getVehicleType() { return "CAR"; }

        public void refuel(double litres) {
            fuelLevel = Math.min(1.0, fuelLevel + litres / 50.0);
            System.out.printf("  Refueled %.1fL | Tank: %.0f%%%n", litres, fuelLevel*100);
        }
    }

    // ── Subclass: ElectricCar extends Car ─────────────────────────────────
    public static class ElectricCar extends Car {
        private double batteryLevel;  // 0.0 – 1.0
        private int    rangeKm;

        public ElectricCar(String make, String model, int year, int rangeKm) {
            super(make, model, year, "AUTO");
            this.batteryLevel = 1.0;
            this.rangeKm      = rangeKm;
        }

        @Override
        public String startEngine() {
            engineOn = true;
            return make + " " + model + " electric motor activated (silent)";
        }

        @Override
        public double calculateMonthlyMaintenance() {
            return 80 + (odometer / 10000) * 20; // cheaper than ICE
        }

        @Override
        public String getVehicleType() { return "ELECTRIC CAR"; }

        public void charge(double hours) {
            batteryLevel = Math.min(1.0, batteryLevel + hours * 0.2);
            System.out.printf("  Charged %.1fh | Battery: %.0f%% | Range: %.0fkm%n",
                    hours, batteryLevel*100, batteryLevel*rangeKm);
        }
    }

    // ── Subclass: Truck ─────────────────────────────────────────────────
    public static class Truck extends Vehicle {
        private double payloadTonnes;
        private double currentLoad;

        public Truck(String make, String model, int year, double payloadTonnes) {
            super(make, model, year);
            this.payloadTonnes = payloadTonnes;
        }

        @Override
        public String startEngine() {
            engineOn = true;
            return make + " " + model + " diesel engine rumbles to life";
        }

        @Override
        public double calculateMonthlyMaintenance() {
            return 500 + (odometer / 5000) * 150 + currentLoad * 10;
        }

        @Override
        public String getVehicleType() { return "TRUCK"; }

        public boolean loadCargo(double tonnes) {
            if (currentLoad + tonnes > payloadTonnes) {
                System.out.println("  ✗ Overload! Max: " + payloadTonnes + "T");
                return false;
            }
            currentLoad += tonnes;
            System.out.printf("  Loaded %.1fT | Total: %.1fT / %.1fT%n",
                    tonnes, currentLoad, payloadTonnes);
            return true;
        }
    }

    public static void run() {
        System.out.println("\n══════════════════════════════════════════");
        System.out.println("  MODULE 2B: Inheritance & Polymorphism");
        System.out.println("══════════════════════════════════════════");

        // Polymorphism — Vehicle array holds all subtypes
        Vehicle[] fleet = {
            new Car("Toyota",  "Camry",   2022, "AUTO"),
            new Car("Honda",   "Civic",   2021, "MANUAL"),
            new ElectricCar("Tesla", "Model 3", 2023, 500),
            new ElectricCar("BMW",   "iX",      2023, 630),
            new Truck("Tata",  "Prima",  2020, 25.0),
        };

        System.out.println("Fleet Status:");
        for (Vehicle v : fleet) {
            System.out.println("  " + v);
            System.out.println("    Engine : " + v.startEngine());
            System.out.printf("    Maint  : $%.2f/month%n", v.calculateMonthlyMaintenance());

            // Pattern matching instanceof (Java 16+)
            if (v instanceof ElectricCar ev) {
                ev.charge(2.0);
            } else if (v instanceof Truck t) {
                t.loadCargo(15.5);
            }
            System.out.println("    Reg    : " + v.getRegistration());
            System.out.println();
        }

        // Runtime dispatch
        System.out.println("Maintenance Costs:");
        double totalMaint = 0;
        for (Vehicle v : fleet) {
            double cost = v.calculateMonthlyMaintenance(); // correct subclass called!
            totalMaint += cost;
            System.out.printf("  %-25s $%.2f/month%n", v.make + " " + v.model, cost);
        }
        System.out.printf("  FLEET TOTAL: $%.2f/month%n", totalMaint);
    }
}