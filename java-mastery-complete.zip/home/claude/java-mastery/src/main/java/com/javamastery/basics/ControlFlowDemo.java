package com.javamastery.basics;

import java.util.Random;

/**
 * MODULE 1B: Control Flow — if/else, switch, loops, break/continue
 * Real-world: ATM transaction processing & ticket booking system
 */
public class ControlFlowDemo {

    public static void run() {
        System.out.println("\n══════════════════════════════════════════");
        System.out.println("  MODULE 1B: Control Flow");
        System.out.println("══════════════════════════════════════════");

        // ── if / else if / else — loan eligibility ───────────────────────
        double salary     = 75_000;
        double loanAmount = 500_000;
        double ratio      = loanAmount / salary;

        String eligibility;
        if (salary < 25_000)      eligibility = "REJECTED — Below minimum salary";
        else if (ratio > 10)      eligibility = "REJECTED — Loan amount too high";
        else if (salary < 50_000) eligibility = "CONDITIONAL — Guarantor required";
        else if (ratio > 6)       eligibility = "PARTIAL — Max 60% of requested";
        else                      eligibility = "APPROVED";

        System.out.println("Loan Eligibility: " + eligibility);

        // ── Switch Expression (Java 14+) — account type fees ────────────
        String[] accountTypes = {"SAVINGS", "CURRENT", "SALARY", "NRE", "UNKNOWN"};
        for (String type : accountTypes) {
            double fee = switch (type) {
                case "SAVINGS" -> 0.0;
                case "CURRENT" -> 500.0;
                case "SALARY"  -> 0.0;
                case "NRE"     -> 250.0;
                default        -> { System.out.println("  Unknown: " + type); yield -1.0; }
            };
            if (fee >= 0) System.out.printf("  %-10s maintenance fee: $%.2f%n", type, fee);
        }

        // ── for loop — EMI calculation ────────────────────────────────────
        System.out.println("\nEMI Schedule (12 months, $12000, 8.5% p.a.):");
        double principal    = 12_000;
        double monthlyRate  = 0.085 / 12;
        int    months       = 12;
        double emi          = (principal * monthlyRate * Math.pow(1+monthlyRate, months))
                            / (Math.pow(1+monthlyRate, months) - 1);
        double outstanding  = principal;

        for (int m = 1; m <= months; m++) {
            double interest   = outstanding * monthlyRate;
            double principalP = emi - interest;
            outstanding      -= principalP;
            System.out.printf("  Month %2d: EMI=$%.2f  Interest=$%.2f  Principal=$%.2f  Balance=$%.2f%n",
                    m, emi, interest, principalP, Math.max(0, outstanding));
        }

        // ── while — OTP retry loop ────────────────────────────────────────
        System.out.println("\nOTP Verification:");
        int correctOTP = 847291;
        int maxAttempts= 3;
        int attempts   = 0;
        boolean verified = false;
        int[] userInputs = {111111, 222222, 847291}; // simulated inputs

        while (attempts < maxAttempts && !verified) {
            int enteredOTP = userInputs[attempts];
            attempts++;
            if (enteredOTP == correctOTP) {
                verified = true;
                System.out.println("  Attempt " + attempts + ": OTP Verified!");
            } else {
                System.out.println("  Attempt " + attempts + ": Wrong OTP. "
                        + (maxAttempts - attempts) + " attempts left");
            }
        }
        if (!verified) System.out.println("  Account LOCKED after " + maxAttempts + " failed attempts");

        // ── do-while — always runs at least once (menu loop) ─────────────
        System.out.println("\nTransaction Menu Simulation:");
        int[] menuChoices = {1, 2, 3, 0}; // simulated selections
        int choiceIdx = 0;
        do {
            int choice = menuChoices[choiceIdx++];
            switch (choice) {
                case 1 -> System.out.println("  [1] Check Balance → $12,500.00");
                case 2 -> System.out.println("  [2] Mini Statement → last 5 txns");
                case 3 -> System.out.println("  [3] Fund Transfer → amount entered");
                case 0 -> System.out.println("  [0] Exit menu");
            }
        } while (choiceIdx < menuChoices.length && menuChoices[choiceIdx-1] != 0);

        // ── break & continue — fraud detection ────────────────────────────
        System.out.println("\nFraud Detection (skip < $10, flag > $9000):");
        double[] transactions = {5.0, 250.0, 9500.0, 8.0, 1200.0, 15000.0, 450.0};
        double totalFlagged = 0;
        for (double tx : transactions) {
            if (tx < 10.0)    { continue; }  // skip micro-transactions
            if (tx > 10000.0) {
                System.out.println("  🚨 BLOCK: $" + tx + " exceeds limit");
                break; // stop processing after blocking
            }
            if (tx > 9000.0) {
                System.out.println("  ⚠️  FLAG: $" + tx);
                totalFlagged += tx;
            }
        }
        System.out.printf("  Total flagged: $%.2f%n", totalFlagged);
    }
}