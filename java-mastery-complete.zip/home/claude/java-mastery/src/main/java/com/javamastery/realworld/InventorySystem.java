package com.javamastery.realworld;

import java.util.*;
import java.util.stream.*;
import java.util.function.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/**
 * MODULE 10: Real-World Mini Project — Inventory Management System
 *
 * Combines EVERY concept:
 *   OOP (classes, inheritance, interfaces)
 *   Collections (HashMap, ArrayList, TreeMap)
 *   Generics (Result<T>, Repository<T>)
 *   Functional (Lambda, Streams, Optional)
 *   Concurrency (AtomicLong, ConcurrentHashMap)
 *   Design Patterns (Singleton, Observer, Builder, Strategy)
 *   Exception Handling (custom exceptions)
 */
public class InventorySystem {

    // ── Domain Model ──────────────────────────────────────────────────────

    public enum Category { ELECTRONICS, CLOTHING, FOOD, BOOKS, SPORTS }

    public record Product(
        String   sku,
        String   name,
        Category category,
        double   price,
        int      stock,
        String   supplierId
    ) {
        public double totalValue() { return price * stock; }

        // Builder-style factory
        public static ProductBuilder builder(String sku, String name) {
            return new ProductBuilder(sku, name);
        }
    }

    public static class ProductBuilder {
        private final String sku, name;
        private Category category = Category.ELECTRONICS;
        private double   price    = 0;
        private int      stock    = 0;
        private String   supplierId = "DEFAULT";

        ProductBuilder(String sku, String name) { this.sku = sku; this.name = name; }

        public ProductBuilder category(Category c) { category = c; return this; }
        public ProductBuilder price(double p)       { price = p;    return this; }
        public ProductBuilder stock(int s)          { stock = s;    return this; }
        public ProductBuilder supplier(String id)   { supplierId = id; return this; }

        public Product build() {
            if (price < 0) throw new IllegalArgumentException("Price cannot be negative");
            if (stock < 0) throw new IllegalArgumentException("Stock cannot be negative");
            return new Product(sku, name, category, price, stock, supplierId);
        }
    }

    // ── Custom Exception Hierarchy ─────────────────────────────────────────
    static class InventoryException extends RuntimeException {
        private final String code;
        InventoryException(String code, String msg)          { super(msg); this.code = code; }
        InventoryException(String code, String msg, Throwable c){ super(msg, c); this.code = code; }
        String getCode() { return code; }
    }

    static class ProductNotFoundException  extends InventoryException {
        ProductNotFoundException(String sku) { super("PRODUCT_NOT_FOUND", "Product not found: " + sku); }
    }

    static class InsufficientStockException extends InventoryException {
        InsufficientStockException(String sku, int requested, int available) {
            super("INSUFFICIENT_STOCK",
                String.format("SKU %s: requested %d but only %d available", sku, requested, available));
        }
    }

    // ── Result<T> — generic result wrapper ────────────────────────────────
    static class Result<T> {
        private final T data; private final boolean ok; private final String msg; private final String code;
        private Result(T d, boolean ok, String msg, String code) {
            this.data = d; this.ok = ok; this.msg = msg; this.code = code;
        }
        static <T> Result<T> success(T data)              { return new Result<>(data, true,  "OK",  "200"); }
        static <T> Result<T> success(T data, String msg)  { return new Result<>(data, true,  msg,   "200"); }
        static <T> Result<T> failure(String code, String msg) { return new Result<>(null, false, msg, code); }
        boolean isSuccess() { return ok; }
        T       getData()   { return data; }
        String  getMessage(){ return msg;  }
        @Override public String toString() { return ok ? "OK[" + msg + "]" : "FAIL[" + code + ":" + msg + "]"; }
    }

    // ── Inventory Repository ───────────────────────────────────────────────
    static class InventoryRepository {
        // ConcurrentHashMap: thread-safe without full locking
        private final ConcurrentHashMap<String, Product> products = new ConcurrentHashMap<>();
        private final AtomicLong txCount = new AtomicLong(0);

        public Result<Product> save(Product product) {
            products.put(product.sku(), product);
            txCount.incrementAndGet();
            return Result.success(product, "Saved: " + product.sku());
        }

        public Result<Product> findBySku(String sku) {
            Product p = products.get(sku);
            return p != null ? Result.success(p) : Result.failure("NOT_FOUND", "SKU: " + sku);
        }

        public Result<List<Product>> findAll() {
            return Result.success(new ArrayList<>(products.values()));
        }

        public Result<List<Product>> findByCategory(Category cat) {
            List<Product> list = products.values().stream()
                .filter(p -> p.category() == cat)
                .sorted(Comparator.comparing(Product::name))
                .collect(Collectors.toList());
            return Result.success(list);
        }

        public Result<Product> updateStock(String sku, int delta) {
            Product p = products.get(sku);
            if (p == null) throw new ProductNotFoundException(sku);
            int newStock = p.stock() + delta;
            if (newStock < 0) throw new InsufficientStockException(sku, -delta, p.stock());
            Product updated = new Product(p.sku(), p.name(), p.category(),
                    p.price(), newStock, p.supplierId());
            products.put(sku, updated);
            txCount.incrementAndGet();
            return Result.success(updated);
        }

        public long getTransactionCount() { return txCount.get(); }
        public int  getProductCount()     { return products.size(); }
    }

    // ── Event System (Observer pattern) ──────────────────────────────────
    interface InventoryEvent { String type(); String sku(); }
    record StockLowEvent(String sku, int currentStock) implements InventoryEvent {
        public String type() { return "STOCK_LOW"; }
    }
    record RestockEvent(String sku, int qty) implements InventoryEvent {
        public String type() { return "RESTOCK"; }
    }

    @FunctionalInterface
    interface EventListener<E extends InventoryEvent> {
        void handle(E event);
    }

    static class EventBus {
        private final Map<String, List<EventListener<InventoryEvent>>> handlers = new HashMap<>();

        @SuppressWarnings("unchecked")
        public <E extends InventoryEvent> void on(String type, EventListener<E> listener) {
            handlers.computeIfAbsent(type, k -> new ArrayList<>())
                    .add((EventListener<InventoryEvent>) listener);
        }

        public void emit(InventoryEvent event) {
            handlers.getOrDefault(event.type(), List.of())
                    .forEach(h -> h.handle(event));
        }
    }

    // ── Inventory Service ─────────────────────────────────────────────────
    static class InventoryService {
        private final InventoryRepository repo;
        private final EventBus            bus;
        static final int LOW_STOCK_THRESHOLD = 10;

        InventoryService(InventoryRepository repo, EventBus bus) {
            this.repo = repo; this.bus = bus;
        }

        public Result<Product> addProduct(Product product) {
            Result<Product> result = repo.save(product);
            System.out.println("  ✓ Added: " + product.name() + " (SKU:" + product.sku() + ")");
            return result;
        }

        public Result<Product> sell(String sku, int qty) {
            try {
                Result<Product> updated = repo.updateStock(sku, -qty);
                Product p = updated.getData();
                System.out.printf("  ✓ Sold %d × %-20s | Stock: %d%n", qty, p.name(), p.stock());
                if (p.stock() < LOW_STOCK_THRESHOLD) {
                    bus.emit(new StockLowEvent(sku, p.stock()));
                }
                return updated;
            } catch (InventoryException e) {
                System.err.println("  ✗ Sale failed [" + e.getCode() + "]: " + e.getMessage());
                return Result.failure(e.getCode(), e.getMessage());
            }
        }

        public Result<Product> restock(String sku, int qty) {
            Result<Product> updated = repo.updateStock(sku, qty);
            bus.emit(new RestockEvent(sku, qty));
            System.out.printf("  ✓ Restocked %d × %s%n", qty, sku);
            return updated;
        }

        // Analytics using Streams
        public void printDashboard() {
            List<Product> all = repo.findAll().getData();
            System.out.println("\n  ══ INVENTORY DASHBOARD ══");

            // Total value
            double totalValue = all.stream().mapToDouble(Product::totalValue).sum();
            System.out.printf("  Total Products: %d  |  Total Value: $%,.2f%n",
                    all.size(), totalValue);

            // By category
            Map<Category, DoubleSummaryStatistics> byCategory = all.stream()
                .collect(Collectors.groupingBy(Product::category,
                         Collectors.summarizingDouble(Product::totalValue)));
            System.out.println("\n  Value by Category:");
            byCategory.entrySet().stream()
                .sorted(Map.Entry.<Category, DoubleSummaryStatistics>comparingByValue(
                    Comparator.comparingDouble(DoubleSummaryStatistics::getSum)).reversed())
                .forEach(e -> System.out.printf("    %-12s $%,.2f  (%d products)%n",
                    e.getKey(), e.getValue().getSum(), (long)e.getValue().getCount()));

            // Low stock alert
            List<Product> lowStock = all.stream()
                .filter(p -> p.stock() < LOW_STOCK_THRESHOLD)
                .sorted(Comparator.comparingInt(Product::stock))
                .collect(Collectors.toList());
            if (!lowStock.isEmpty()) {
                System.out.println("\n  ⚠ LOW STOCK ALERTS:");
                lowStock.forEach(p -> System.out.printf("    %-25s SKU:%-10s Stock:%d%n",
                        p.name(), p.sku(), p.stock()));
            }

            // Top 3 by value
            System.out.println("\n  Top 3 Products by Total Value:");
            all.stream()
                .sorted(Comparator.comparingDouble(Product::totalValue).reversed())
                .limit(3)
                .forEach(p -> System.out.printf("    %-25s $%,.2f (%d units @ $%.2f)%n",
                        p.name(), p.totalValue(), p.stock(), p.price()));

            System.out.printf("\n  Transactions processed: %d%n", repo.getTransactionCount());
        }

        // Strategy pattern: different search strategies
        public List<Product> search(Predicate<Product> filter, Comparator<Product> sorter) {
            return repo.findAll().getData().stream()
                .filter(filter)
                .sorted(sorter)
                .collect(Collectors.toList());
        }
    }

    // ── Main Entry ────────────────────────────────────────────────────────
    public static void run() {
        System.out.println("\n══════════════════════════════════════════");
        System.out.println("  MODULE 10: Real-World Inventory System");
        System.out.println("══════════════════════════════════════════");

        // Bootstrap
        InventoryRepository repo    = new InventoryRepository();
        EventBus            bus     = new EventBus();
        InventoryService    service = new InventoryService(repo, bus);

        // Register event handlers
        bus.on("STOCK_LOW", (StockLowEvent e) ->
            System.out.printf("  🔔 [PurchaseSystem] Auto-reorder triggered for %s (stock=%d)%n",
                    e.sku(), e.currentStock()));
        bus.on("STOCK_LOW", (StockLowEvent e) ->
            System.out.printf("  📧 [EmailAlert] Notified buyer: %s needs restocking%n", e.sku()));
        bus.on("RESTOCK", (RestockEvent e) ->
            System.out.printf("  📊 [Analytics] Restock logged: %s +%d units%n", e.sku(), e.qty()));

        // Seed products using Builder pattern
        System.out.println("\nAdding products:");
        List<Product> catalogue = List.of(
            Product.builder("ELEC-001","MacBook Pro 14"")     .category(Category.ELECTRONICS).price(1999.99).stock(50)  .supplier("APPLE").build(),
            Product.builder("ELEC-002","Sony WH-1000XM5")      .category(Category.ELECTRONICS).price(349.99) .stock(120) .supplier("SONY").build(),
            Product.builder("ELEC-003","Samsung 4K Monitor")   .category(Category.ELECTRONICS).price(499.99) .stock(35)  .supplier("SAMSUNG").build(),
            Product.builder("BOOK-001","Clean Code")           .category(Category.BOOKS)       .price(45.99)  .stock(200) .supplier("OREILLY").build(),
            Product.builder("BOOK-002","Effective Java")       .category(Category.BOOKS)       .price(55.99)  .stock(150) .supplier("OREILLY").build(),
            Product.builder("CLTH-001","Nike Air Max 2024")    .category(Category.CLOTHING)    .price(129.99) .stock(300) .supplier("NIKE").build(),
            Product.builder("SPRT-001","Wilson Tennis Racket") .category(Category.SPORTS)      .price(89.99)  .stock(75)  .supplier("WILSON").build(),
            Product.builder("FOOD-001","Organic Green Tea")    .category(Category.FOOD)        .price(12.99)  .stock(500) .supplier("LOCAL").build()
        );
        catalogue.forEach(service::addProduct);

        // Simulate sales
        System.out.println("\nProcessing sales:");
        service.sell("ELEC-001", 10);
        service.sell("BOOK-001", 50);
        service.sell("ELEC-003", 30);  // will trigger low stock
        service.sell("ELEC-999", 5);   // non-existent SKU
        service.sell("ELEC-003", 10);  // will fail — insufficient stock

        // Restock
        System.out.println("\nRestocking:");
        service.restock("ELEC-003", 100);

        // Dashboard
        service.printDashboard();

        // Custom search
        System.out.println("\n  Search: Electronics under $500, sorted by price:");
        List<Product> results = service.search(
            p -> p.category() == Category.ELECTRONICS && p.price() < 500,
            Comparator.comparingDouble(Product::price)
        );
        results.forEach(p -> System.out.printf("    %-30s $%.2f%n", p.name(), p.price()));

        // Concurrent stock updates simulation
        System.out.println("\n  Concurrent stock updates (thread-safety test):");
        ExecutorService exec = Executors.newFixedThreadPool(4);
        AtomicInteger failCount = new AtomicInteger(0);
        CountDownLatch latch = new CountDownLatch(20);

        for (int i = 0; i < 20; i++) {
            exec.submit(() -> {
                try {
                    service.restock("BOOK-002", 1);
                } catch (Exception e) {
                    failCount.incrementAndGet();
                } finally {
                    latch.countDown();
                }
            });
        }

        try { latch.await(5, TimeUnit.SECONDS); } catch (InterruptedException e) {}
        exec.shutdown();

        Result<Product> book = repo.findBySku("BOOK-002");
        if (book.isSuccess()) {
            System.out.printf("  BOOK-002 final stock: %d (20 concurrent +1 ops, %d fails)%n",
                    book.getData().stock(), failCount.get());
        }
    }
}