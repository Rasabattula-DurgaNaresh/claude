package com.javamastery.collections;

import java.util.*;
import java.util.stream.*;

/**
 * MODULE 3: Java Collections Framework
 * Real-world: E-commerce order & inventory management
 */
public class CollectionsDemo {

    public static void run() {
        System.out.println("\n══════════════════════════════════════════");
        System.out.println("  MODULE 3: Collections Framework");
        System.out.println("══════════════════════════════════════════");
        listDemo();
        setDemo();
        mapDemo();
        queueDemo();
    }

    static void listDemo() {
        System.out.println("\n--- ArrayList & LinkedList ---");

        // ArrayList: fast random access O(1), slow mid-insert O(n)
        List<String> cart = new ArrayList<>();
        cart.add("Laptop"); cart.add("Mouse"); cart.add("Keyboard"); cart.add("Mouse");
        cart.add(1, "Monitor");      // insert at index
        cart.remove("Mouse");        // removes first occurrence
        System.out.println("Cart: " + cart);

        // Sorting with Comparator
        List<Integer> prices = new ArrayList<>(Arrays.asList(999, 29, 79, 299, 149));
        prices.sort(Comparator.naturalOrder());
        System.out.println("Sorted prices: " + prices);
        prices.sort(Comparator.reverseOrder());
        System.out.println("Reverse prices: " + prices);

        // Immutable list (Java 9+)
        List<String> fixed = List.of("Red","Green","Blue");
        System.out.println("Immutable: " + fixed);

        // LinkedList as queue
        LinkedList<String> orders = new LinkedList<>();
        orders.offer("Order-001"); orders.offer("Order-002"); orders.offer("Order-003");
        System.out.println("Processing: " + orders.poll()); // removes head
        System.out.println("Next up   : " + orders.peek()); // peek without remove

        // subList, contains, indexOf
        List<Integer> nums = new ArrayList<>(Arrays.asList(10,20,30,40,50,60));
        System.out.println("Sub(1,4): " + nums.subList(1, 4)); // [20,30,40]
        Collections.shuffle(nums, new Random(42));
        System.out.println("Shuffled: " + nums);
        Collections.sort(nums);
        System.out.println("Sorted  : " + nums);
        System.out.println("Max     : " + Collections.max(nums));
        System.out.println("Min     : " + Collections.min(nums));
    }

    static void setDemo() {
        System.out.println("\n--- HashSet / LinkedHashSet / TreeSet ---");

        // HashSet: O(1) add/contains, no order
        Set<String> tags = new HashSet<>(Arrays.asList("java","spring","java","docker","kafka"));
        System.out.println("HashSet (no dupes, no order): " + tags);

        // LinkedHashSet: insertion order preserved
        Set<String> orderedTags = new LinkedHashSet<>(tags);
        orderedTags.add("kubernetes");
        System.out.println("LinkedHashSet (insertion order): " + orderedTags);

        // TreeSet: sorted alphabetically
        Set<String> sortedTags = new TreeSet<>(tags);
        System.out.println("TreeSet (sorted): " + sortedTags);

        // Set operations — skill gap analysis
        Set<String> required = new HashSet<>(Arrays.asList("Java","Spring","SQL","Docker","Kafka","Redis"));
        Set<String> candidate= new HashSet<>(Arrays.asList("Java","Spring","SQL","Python","Docker"));

        Set<String> has     = new HashSet<>(required); has.retainAll(candidate);
        Set<String> missing = new HashSet<>(required); missing.removeAll(candidate);
        Set<String> extra   = new HashSet<>(candidate); extra.removeAll(required);

        System.out.println("\nSkill Analysis:");
        System.out.println("  Has     : " + has);
        System.out.println("  Missing : " + missing);
        System.out.println("  Extra   : " + extra);
    }

    static void mapDemo() {
        System.out.println("\n--- HashMap / LinkedHashMap / TreeMap ---");

        // HashMap: most common, O(1) get/put
        Map<String, Double> inventory = new HashMap<>();
        inventory.put("Laptop", 999.99);
        inventory.put("Mouse",   29.99);
        inventory.put("Keyboard",79.99);
        inventory.put("Monitor",299.99);

        // Safe access
        System.out.printf("Laptop price: $%.2f%n", inventory.get("Laptop"));
        System.out.printf("Tablet price: $%.2f (default)%n", inventory.getOrDefault("Tablet", 0.0));

        // putIfAbsent / compute / merge
        inventory.putIfAbsent("Mouse", 39.99);           // won't replace $29.99
        inventory.compute("Laptop", (k, v) -> v * 0.9); // 10% discount
        inventory.merge("Mouse", 5.0, Double::sum);      // add $5 surcharge

        System.out.println("Updated inventory:");
        inventory.entrySet().stream()
            .sorted(Map.Entry.comparingByKey())
            .forEach(e -> System.out.printf("  %-10s $%.2f%n", e.getKey(), e.getValue()));

        // TreeMap: sorted by key
        Map<Integer, String> statusCodes = new TreeMap<>();
        statusCodes.put(404, "Not Found"); statusCodes.put(200, "OK");
        statusCodes.put(500, "Error");     statusCodes.put(201, "Created");
        System.out.println("HTTP codes (sorted): " + statusCodes);

        // Nested map: department → employee → salary
        Map<String, Map<String, Double>> orgChart = new LinkedHashMap<>();
        orgChart.put("Engineering", new LinkedHashMap<>());
        orgChart.put("Marketing",   new LinkedHashMap<>());
        orgChart.get("Engineering").put("Alice", 95000.0);
        orgChart.get("Engineering").put("Bob",   85000.0);
        orgChart.get("Marketing").put("Charlie", 65000.0);

        System.out.println("\nOrg Chart:");
        orgChart.forEach((dept, emps) -> {
            double avg = emps.values().stream().mapToDouble(Double::doubleValue).average().orElse(0);
            System.out.printf("  %-15s count=%d  avgSalary=$%,.0f%n", dept, emps.size(), avg);
        });
    }

    static void queueDemo() {
        System.out.println("\n--- Queue / PriorityQueue / Deque ---");

        // PriorityQueue: min-heap — lowest priority value = served first
        Queue<int[]> taskQueue = new PriorityQueue<>(Comparator.comparingInt(a -> a[0]));
        taskQueue.offer(new int[]{3, 101}); // [priority, taskId]
        taskQueue.offer(new int[]{1, 102}); // URGENT
        taskQueue.offer(new int[]{5, 103}); // LOW
        taskQueue.offer(new int[]{2, 104}); // HIGH

        System.out.println("Processing tasks by priority:");
        while (!taskQueue.isEmpty()) {
            int[] task = taskQueue.poll();
            System.out.printf("  Priority %d → Task-%d%n", task[0], task[1]);
        }

        // ArrayDeque as Stack (browser back/forward)
        Deque<String> backStack    = new ArrayDeque<>();
        Deque<String> forwardStack = new ArrayDeque<>();

        String[] pages = {"/home", "/products", "/cart", "/checkout"};
        for (String page : pages) {
            backStack.push(page);
            System.out.println("Navigate to: " + page);
        }

        System.out.println("\nBack button:");
        System.out.println("  Current: " + backStack.pop());
        System.out.println("  Back to: " + backStack.peek());

        // BlockingQueue simulation (producer-consumer hint)
        System.out.println("\nLinkedList as FIFO Queue:");
        Queue<String> fifo = new LinkedList<>();
        fifo.offer("Req-1"); fifo.offer("Req-2"); fifo.offer("Req-3");
        while (!fifo.isEmpty()) {
            System.out.println("  Processing: " + fifo.poll());
        }
    }
}