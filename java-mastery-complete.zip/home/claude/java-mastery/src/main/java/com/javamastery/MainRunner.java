package com.javamastery;

import com.javamastery.basics.*;
import com.javamastery.oop.*;
import com.javamastery.collections.*;
import com.javamastery.generics.*;
import com.javamastery.functional.*;
import com.javamastery.concurrency.*;
import com.javamastery.io.*;
import com.javamastery.patterns.*;
import com.javamastery.algorithms.*;
import com.javamastery.realworld.*;

import java.util.*;

/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║         JAVA MASTERY — Complete Core Java Project            ║
 * ║         From Basics to Advanced — All Concepts               ║
 * ╚══════════════════════════════════════════════════════════════╝
 *
 * Modules:
 *   1. Basics       — Data Types, Control Flow, Arrays
 *   2. OOP          — Encapsulation, Inheritance, Polymorphism, Interfaces
 *   3. Collections  — List, Set, Map, Queue
 *   4. Generics     — Generic classes, methods, wildcards
 *   5. Functional   — Lambda, Streams, Optional
 *   6. Concurrency  — Threads, ExecutorService, CompletableFuture
 *   7. File I/O     — Traditional IO, NIO, CSV
 *   8. Patterns     — Singleton, Builder, Factory, Observer, Strategy
 *   9. Algorithms   — Sort, Search, Recursion, Dynamic Programming
 *  10. Real-World   — Inventory Management System (all concepts combined)
 */
public class MainRunner {

    public static void main(String[] args) throws Exception {
        printBanner();

        Scanner scanner = new Scanner(System.in);
        Map<Integer, Runnable> modules = createModules();

        if (args.length > 0 && args[0].equalsIgnoreCase("all")) {
            System.out.println("Running ALL modules...\n");
            for (int i = 1; i <= modules.size(); i++) {
                runModule(modules, i);
            }
            printSummary();
            return;
        }

        // Interactive menu
        while (true) {
            printMenu();
            System.out.print("\nEnter module number (0 = ALL, -1 = EXIT): ");

            int choice;
            try {
                choice = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine();
                continue;
            }

            if (choice == -1) {
                System.out.println("\nThank you for using Java Mastery!");
                break;
            }

            if (choice == 0) {
                for (int i = 1; i <= modules.size(); i++) runModule(modules, i);
                printSummary();
            } else if (modules.containsKey(choice)) {
                runModule(modules, choice);
            } else {
                System.out.println("Invalid choice. Try 1-" + modules.size());
            }
        }

        scanner.close();
    }

    static Map<Integer, Runnable> createModules() {
        Map<Integer, Runnable> m = new LinkedHashMap<>();
        m.put(1,  () -> { DataTypesDemo.run(); ControlFlowDemo.run(); ArraysDemo.run(); });
        m.put(2,  () -> { VehicleHierarchy.run(); PaymentSystem.run(); });
        m.put(3,  CollectionsDemo::run);
        m.put(4,  GenericsDemo::run);
        m.put(5,  FunctionalDemo::run);
        m.put(6,  () -> { try { ConcurrencyDemo.run(); } catch (Exception e) { e.printStackTrace(); } });
        m.put(7,  () -> { try { FileIODemo.run(); } catch (Exception e) { e.printStackTrace(); } });
        m.put(8,  DesignPatternsDemo::run);
        m.put(9,  AlgorithmsDemo::run);
        m.put(10, InventorySystem::run);
        return m;
    }

    static void runModule(Map<Integer, Runnable> modules, int num) {
        System.out.println("\n▶ Running Module " + num + "...");
        long start = System.currentTimeMillis();
        try {
            modules.get(num).run();
        } catch (Exception e) {
            System.err.println("Module " + num + " error: " + e.getMessage());
        }
        System.out.printf("\n  ⏱ Module %d completed in %dms%n", num, System.currentTimeMillis() - start);
    }

    static void printBanner() {
        System.out.println("╔══════════════════════════════════════════════════════╗");
        System.out.println("║          JAVA MASTERY — CORE JAVA PROJECT            ║");
        System.out.println("║          From Basics to Advanced                     ║");
        System.out.println("║          Java 17 | Maven | 10 Modules | 15 Files     ║");
        System.out.println("╚══════════════════════════════════════════════════════╝");
        System.out.printf("  Java version : %s%n", System.getProperty("java.version"));
        System.out.printf("  CPUs          : %d%n", Runtime.getRuntime().availableProcessors());
        System.out.printf("  Max memory    : %,dMB%n", Runtime.getRuntime().maxMemory()/1_048_576);
    }

    static void printMenu() {
        System.out.println("\n┌─────────────────────────────────────────────┐");
        System.out.println("│              MODULE MENU                    │");
        System.out.println("├─────────────────────────────────────────────┤");
        System.out.println("│  1. Basics         (DataTypes, Control, Arrays) │");
        System.out.println("│  2. OOP            (Inheritance, Polymorphism)  │");
        System.out.println("│  3. Collections    (List, Set, Map, Queue)      │");
        System.out.println("│  4. Generics       (Result<T>, Repository)      │");
        System.out.println("│  5. Functional     (Lambda, Streams, Optional)  │");
        System.out.println("│  6. Concurrency    (Threads, CF, Atomic)        │");
        System.out.println("│  7. File I/O       (NIO, CSV, Properties)       │");
        System.out.println("│  8. Patterns       (Builder, Observer, Strategy) │");
        System.out.println("│  9. Algorithms     (Sort, Search, DP)           │");
        System.out.println("│ 10. Real-World     (Inventory System)           │");
        System.out.println("│  0. Run ALL modules                             │");
        System.out.println("│ -1. Exit                                        │");
        System.out.println("└─────────────────────────────────────────────┘");
    }

    static void printSummary() {
        System.out.println("\n╔══════════════════════════════════════════════════════╗");
        System.out.println("║  ✓ ALL MODULES COMPLETED                             ║");
        System.out.println("║                                                      ║");
        System.out.println("║  Concepts demonstrated:                              ║");
        System.out.println("║  • Primitive types, type casting, overflow           ║");
        System.out.println("║  • Encapsulation, inheritance, polymorphism          ║");
        System.out.println("║  • Interfaces, abstract classes, default methods     ║");
        System.out.println("║  • Exception handling (checked/unchecked/custom)     ║");
        System.out.println("║  • ArrayList, LinkedList, HashSet, TreeMap, PQ       ║");
        System.out.println("║  • Generic classes, methods, bounded wildcards       ║");
        System.out.println("║  • Lambda, Predicate, Function, Consumer, Supplier   ║");
        System.out.println("║  • Stream filter/map/reduce/collect/groupingBy       ║");
        System.out.println("║  • Optional, method references                       ║");
        System.out.println("║  • Thread, Runnable, ExecutorService, Future         ║");
        System.out.println("║  • CompletableFuture, AtomicLong, volatile           ║");
        System.out.println("║  • CountDownLatch, Semaphore, ConcurrentHashMap      ║");
        System.out.println("║  • BufferedReader/Writer, NIO Files, CSV processing  ║");
        System.out.println("║  • Singleton, Builder, Factory, Observer, Strategy   ║");
        System.out.println("║  • Bubble/Merge sort, Binary search, DP, BFS        ║");
        System.out.println("║  • Records, var, sealed concepts, switch expressions ║");
        System.out.println("╚══════════════════════════════════════════════════════╝");
    }
}