package com.javamastery.basics;

/**
 * MODULE 1A: Data Types, Variables, Type Casting
 * Real-world: Banking system — account management primitives
 */
public class DataTypesDemo {

    static final double ANNUAL_INTEREST = 0.0825; // 8.25%
    static final long   MAX_TRANSFER    = 10_000_000L;

    public static void run() {
        System.out.println("\n══════════════════════════════════════════");
        System.out.println("  MODULE 1A: Data Types & Variables");
        System.out.println("══════════════════════════════════════════");

        // Primitive types — bank account context
        byte    tier       = 3;
        short   branchCode = 1047;
        int     accountNum = 987654321;
        long    txTimestamp= System.currentTimeMillis();
        double  balance    = 1_52_347.89;
        boolean isActive   = true;
        char    currency   = '$';

        System.out.printf("Account  : %d%n", accountNum);
        System.out.printf("Balance  : %c%,.2f%n", currency, balance);
        System.out.println("Active   : " + isActive);

        // INTEGER DIVISION pitfall
        int paidEMI = 5, totalEMI = 12;
        int    wrong = paidEMI / totalEMI;          // 0 — WRONG!
        double right = (double) paidEMI / totalEMI; // 0.4167
        System.out.printf("EMI Progress: %.1f%%%n", right * 100);

        // Overflow — common bug in financial systems
        int  maxInt   = Integer.MAX_VALUE;
        int  overflow = maxInt + 1;          // wraps to -2147483648!
        long safeCalc = (long) maxInt + 1;   // 2147483648
        System.out.println("Overflow (int) : " + overflow + " ← DANGER");
        System.out.println("Safe    (long) : " + safeCalc + " ← CORRECT");

        // Type casting
        double exactAmt   = 1547.89;
        int    truncated  = (int) exactAmt;          // 1547 (drops decimal)
        long   rounded    = Math.round(exactAmt);    // 1548
        System.out.printf("Cast: %.2f → truncate=%d, round=%d%n", exactAmt, truncated, rounded);

        // String operations — real-world: phone number normalisation
        String rawPhone = "  +91-98765-43210  ";
        String cleaned  = rawPhone.trim().replace("-","").replace("+91","");
        System.out.println("Cleaned phone: " + cleaned);

        // StringBuilder for receipt generation (mutable, fast)
        StringBuilder receipt = new StringBuilder();
        receipt.append("──── TRANSACTION RECEIPT ────\n");
        receipt.append(String.format("  Amount : $%,.2f%n", 15_000.50));
        receipt.append(String.format("  Status : %s%n", "SUCCESS"));
        receipt.append("─────────────────────────────");
        System.out.println(receipt);
    }
}