package com.javamastery.generics;

import java.util.*;
import java.util.function.*;

/**
 * MODULE 4: Generics — Type-safe containers, methods, wildcards
 * Real-world: Generic API Result, Repository pattern, Pair/Triple
 */
public class GenericsDemo {

    // ── Generic class: Result<T> ──────────────────────────────────────────
    public static class Result<T> {
        private final T       data;
        private final boolean success;
        private final String  message;
        private final int     code;

        private Result(T data, boolean success, String message, int code) {
            this.data = data; this.success = success;
            this.message = message; this.code = code;
        }

        public static <T> Result<T> ok(T data)            { return new Result<>(data, true, "OK", 200); }
        public static <T> Result<T> ok(T data, String msg){ return new Result<>(data, true, msg, 200); }
        public static <T> Result<T> fail(int code, String msg){ return new Result<>(null, false, msg, code); }

        public boolean isSuccess() { return success; }
        public T       getData()   { return data; }
        public String  getMessage(){ return message; }
        public int     getCode()   { return code; }

        public <R> Result<R> map(Function<T, R> mapper) {
            if (!success) return Result.fail(code, message);
            return Result.ok(mapper.apply(data));
        }

        @Override
        public String toString() {
            return success ? "Result.ok(" + data + ")" : "Result.fail(" + code + ": " + message + ")";
        }
    }

    // ── Generic Pair<A, B> ────────────────────────────────────────────────
    public static class Pair<A, B> {
        public final A first;
        public final B second;
        public Pair(A first, B second) { this.first = first; this.second = second; }
        public static <A, B> Pair<A, B> of(A a, B b) { return new Pair<>(a, b); }
        @Override public String toString() { return "(" + first + ", " + second + ")"; }
    }

    // ── Generic Repository ────────────────────────────────────────────────
    public interface Repository<T, ID extends Comparable<ID>> {
        Result<T>       save(T entity);
        Result<T>       findById(ID id);
        Result<List<T>> findAll();
        Result<Void>    delete(ID id);
        boolean         exists(ID id);
        long            count();
    }

    // ── Concrete In-Memory Store ──────────────────────────────────────────
    public static class InMemoryStore<T> implements Repository<T, Long> {
        private final Map<Long, T> store = new LinkedHashMap<>();
        private long idCounter = 1;
        private final String entityName;

        public InMemoryStore(String entityName) { this.entityName = entityName; }

        @Override
        public Result<T> save(T entity) {
            long id = idCounter++;
            store.put(id, entity);
            return Result.ok(entity, entityName + " saved with id=" + id);
        }

        @Override
        public Result<T> findById(Long id) {
            T e = store.get(id);
            return e != null ? Result.ok(e) : Result.fail(404, entityName + " not found: " + id);
        }

        @Override
        public Result<List<T>> findAll() {
            return Result.ok(new ArrayList<>(store.values()));
        }

        @Override
        public Result<Void> delete(Long id) {
            if (!store.containsKey(id)) return Result.fail(404, "Not found: " + id);
            store.remove(id);
            return Result.ok(null, "Deleted id=" + id);
        }

        @Override public boolean exists(Long id) { return store.containsKey(id); }
        @Override public long    count()          { return store.size(); }
    }

    // ── Generic methods ────────────────────────────────────────────────────
    // Bounded type: T must be Comparable
    public static <T extends Comparable<T>> T max(T a, T b) {
        return a.compareTo(b) >= 0 ? a : b;
    }

    public static <T extends Comparable<T>> T clamp(T value, T min, T max) {
        if (value.compareTo(min) < 0) return min;
        if (value.compareTo(max) > 0) return max;
        return value;
    }

    // Wildcard: accepts List<Integer>, List<Double>, List<Float>
    public static double sum(List<? extends Number> list) {
        return list.stream().mapToDouble(Number::doubleValue).sum();
    }

    public static double average(List<? extends Number> list) {
        return list.isEmpty() ? 0 : sum(list) / list.size();
    }

    // Lower-bounded wildcard: accepts List<Number> or List<Object>
    public static void addDefaults(List<? super Integer> list, int count) {
        for (int i = 0; i < count; i++) list.add(0);
    }

    // Generic swap
    public static <T> void swap(List<T> list, int i, int j) {
        T temp = list.get(i); list.set(i, list.get(j)); list.set(j, temp);
    }

    public static void run() {
        System.out.println("\n══════════════════════════════════════════");
        System.out.println("  MODULE 4: Generics");
        System.out.println("══════════════════════════════════════════");

        // Result<T>
        Result<String>  r1 = Result.ok("User created");
        Result<Integer> r2 = Result.fail(404, "User not found");
        Result<String>  r3 = r1.map(String::toUpperCase);
        System.out.println("r1: " + r1);
        System.out.println("r2: " + r2);
        System.out.println("r3: " + r3);

        // Pair
        Pair<String, Double> stock = Pair.of("AAPL", 182.50);
        System.out.println("Stock: " + stock.first + " @ $" + stock.second);

        // Generic Repository
        InMemoryStore<String> userStore = new InMemoryStore<>("User");
        userStore.save("Alice");
        userStore.save("Bob");
        userStore.save("Charlie");

        Result<String> found = userStore.findById(2L);
        System.out.println("Find id=2: " + found);
        System.out.println("All: " + userStore.findAll().getData());
        System.out.println("Delete: " + userStore.delete(1L));
        System.out.println("Count: " + userStore.count());

        // Generic methods
        System.out.println("max(10,20): " + max(10, 20));
        System.out.println("max('a','z'): " + max('a', 'z'));
        System.out.println("clamp(150, 0, 100): " + clamp(150, 0, 100));

        List<Integer> ints    = Arrays.asList(1, 2, 3, 4, 5);
        List<Double>  doubles = Arrays.asList(1.5, 2.5, 3.5);
        System.out.printf("sum(ints): %.1f  avg(ints): %.1f%n", sum(ints), average(ints));
        System.out.printf("sum(doubles): %.1f%n", sum(doubles));

        List<Integer> data = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5));
        swap(data, 0, 4);
        System.out.println("After swap(0,4): " + data);
    }
}