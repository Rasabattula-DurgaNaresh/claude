package com.javamastery.concurrency;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/**
 * MODULE 6: Multithreading & Concurrency
 * Real-world: Stock trading order processing engine
 */
public class ConcurrencyDemo {

    // ── Atomic counters (lock-free) ────────────────────────────────────────
    static final AtomicLong    ORDER_ID_GEN   = new AtomicLong(10_000);
    static final AtomicInteger ORDERS_PROCESSED = new AtomicInteger(0);
    static final AtomicLong    TOTAL_REVENUE    = new AtomicLong(0);

    // ── Thread-safe order book ─────────────────────────────────────────────
    static class OrderBook {
        private final String symbol;
        private final java.util.concurrent.ConcurrentLinkedQueue<long[]> buyOrders  = new ConcurrentLinkedQueue<>();
        private final java.util.concurrent.ConcurrentLinkedQueue<long[]> sellOrders = new ConcurrentLinkedQueue<>();
        private volatile double lastTradePrice = 0;

        OrderBook(String symbol) { this.symbol = symbol; }

        // Synchronized critical section — matching buy/sell
        synchronized boolean tryMatch() {
            if (buyOrders.isEmpty() || sellOrders.isEmpty()) return false;
            long[] buy  = buyOrders.peek();
            long[] sell = sellOrders.peek();
            if (buy[0] >= sell[0]) { // buy price >= sell price → MATCH
                buyOrders.poll(); sellOrders.poll();
                lastTradePrice = (buy[0] + sell[0]) / 2.0 / 100.0;
                TOTAL_REVENUE.addAndGet((long) lastTradePrice * 100);
                ORDERS_PROCESSED.addAndGet(2);
                System.out.printf("  [%s] TRADE: $%.2f%n", symbol, lastTradePrice);
                return true;
            }
            return false;
        }

        void placeBuyOrder(long priceInCents, long qty) {
            buyOrders.offer(new long[]{priceInCents, qty, ORDER_ID_GEN.getAndIncrement()});
        }
        void placeSellOrder(long priceInCents, long qty) {
            sellOrders.offer(new long[]{priceInCents, qty, ORDER_ID_GEN.getAndIncrement()});
        }
        double getLastTradePrice() { return lastTradePrice; }
    }

    public static void run() throws Exception {
        System.out.println("\n══════════════════════════════════════════");
        System.out.println("  MODULE 6: Concurrency");
        System.out.println("══════════════════════════════════════════");
        threadBasicsDemo();
        executorDemo();
        completableFutureDemo();
        synchronisationDemo();
        countDownLatchDemo();
    }

    static void threadBasicsDemo() throws InterruptedException {
        System.out.println("\n--- Thread Basics ---");

        // 1. Extend Thread
        Thread t1 = new Thread("Worker-1") {
            @Override public void run() {
                System.out.println("  [" + getName() + "] started");
                try { Thread.sleep(50); } catch (InterruptedException e) { interrupt(); }
                System.out.println("  [" + getName() + "] done");
            }
        };

        // 2. Implement Runnable (preferred)
        Runnable task = () -> System.out.println("  [Runnable] running on: " +
                Thread.currentThread().getName());

        // 3. Daemon thread — dies when main thread exits
        Thread daemon = new Thread(() -> {
            while (!Thread.currentThread().isInterrupted()) {
                try { Thread.sleep(200); } catch (InterruptedException e) { break; }
            }
            System.out.println("  [Daemon] stopped");
        }, "Heartbeat");
        daemon.setDaemon(true);

        t1.start();
        new Thread(task, "Worker-2").start();
        daemon.start();

        t1.join();  // wait for t1 to finish
        System.out.printf("  Thread states: t1=%s%n", t1.getState());
    }

    static void executorDemo() throws Exception {
        System.out.println("\n--- ExecutorService ---");
        OrderBook book = new OrderBook("AAPL");

        ExecutorService pool = Executors.newFixedThreadPool(4,
            r -> { Thread t = new Thread(r); t.setName("Trader-" + t.getId()); return t; });

        // Submit Callable tasks (return a result)
        List<Future<String>> futures = new ArrayList<>();
        Random rng = new Random(42);

        for (int i = 0; i < 10; i++) {
            final int id = i;
            futures.add(pool.submit(() -> {
                long price = 18000 + rng.nextInt(500); // 180.00–185.00
                if (id % 2 == 0) book.placeBuyOrder(price, 100);
                else             book.placeSellOrder(price, 100);
                book.tryMatch();
                Thread.sleep(10);
                return "Order-" + id + " placed by " + Thread.currentThread().getName();
            }));
        }

        for (Future<String> f : futures) {
            try { System.out.println("  " + f.get(2, TimeUnit.SECONDS)); }
            catch (TimeoutException e) { System.err.println("  Timeout!"); }
        }

        pool.shutdown();
        pool.awaitTermination(5, TimeUnit.SECONDS);
        System.out.println("  Orders processed: " + ORDERS_PROCESSED.get());
        System.out.printf("  Last AAPL price : $%.2f%n", book.getLastTradePrice());

        // ScheduledExecutorService — periodic tasks
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
        AtomicInteger ticks = new AtomicInteger(0);
        ScheduledFuture<?> priceFeed = scheduler.scheduleAtFixedRate(() -> {
            if (ticks.incrementAndGet() <= 3)
                System.out.printf("  [PriceFeed] AAPL: $%.2f%n",
                        182.5 + new Random().nextGaussian());
        }, 0, 100, TimeUnit.MILLISECONDS);

        Thread.sleep(350);
        priceFeed.cancel(false);
        scheduler.shutdown();
    }

    static void completableFutureDemo() throws Exception {
        System.out.println("\n--- CompletableFuture Pipeline ---");

        // Async order processing pipeline
        CompletableFuture<String> pipeline = CompletableFuture
            .supplyAsync(() -> {
                System.out.println("  [Step 1] Validating order...");
                return "ORDER-" + ORDER_ID_GEN.getAndIncrement();
            })
            .thenApplyAsync(orderId -> {
                System.out.println("  [Step 2] Processing payment for " + orderId);
                return orderId + "|PAID";
            })
            .thenApplyAsync(result -> {
                System.out.println("  [Step 3] Updating inventory...");
                return result + "|STOCK_OK";
            })
            .thenApply(result -> {
                System.out.println("  [Step 4] Sending confirmation...");
                return result + "|NOTIFIED";
            })
            .exceptionally(ex -> "FAILED: " + ex.getMessage());

        System.out.println("  Result: " + pipeline.get(3, TimeUnit.SECONDS));

        // Combine independent async tasks
        CompletableFuture<Double>  priceF = CompletableFuture.supplyAsync(() -> 182.50);
        CompletableFuture<Integer> stockF = CompletableFuture.supplyAsync(() -> 1_500_000);
        CompletableFuture<String>  newsF  = CompletableFuture.supplyAsync(() -> "POSITIVE");

        CompletableFuture<String> combined = priceF
            .thenCombine(stockF, (price, stock) -> String.format("Price=$%.2f Vol=%d", price, stock))
            .thenCombine(newsF,  (prev, news)   -> prev + " Sentiment=" + news);

        System.out.println("  Combined: " + combined.get());

        // allOf — wait for ALL
        List<CompletableFuture<String>> tasks = List.of(
            CompletableFuture.supplyAsync(() -> { try{Thread.sleep(50);}catch(Exception e){} return "A"; }),
            CompletableFuture.supplyAsync(() -> { try{Thread.sleep(30);}catch(Exception e){} return "B"; }),
            CompletableFuture.supplyAsync(() -> { try{Thread.sleep(70);}catch(Exception e){} return "C"; })
        );
        CompletableFuture.allOf(tasks.toArray(new CompletableFuture[0])).join();
        String results = tasks.stream().map(CompletableFuture::join).collect(java.util.stream.Collectors.joining(","));
        System.out.println("  AllOf results: " + results);
    }

    static void synchronisationDemo() {
        System.out.println("\n--- Synchronisation & Volatile ---");

        // volatile — visible across threads without locking
        class MarketStatus {
            volatile boolean marketOpen  = false;
            volatile double  lastPrice   = 0;
        }

        MarketStatus market = new MarketStatus();

        Thread marketControl = new Thread(() -> {
            market.marketOpen = true;
            market.lastPrice  = 182.50;
            System.out.println("  [Control] Market OPEN at $" + market.lastPrice);
            try { Thread.sleep(100); } catch (InterruptedException e) {}
            market.marketOpen = false;
            System.out.println("  [Control] Market CLOSED");
        });

        Thread trader = new Thread(() -> {
            while (!market.marketOpen) Thread.yield(); // spin until open
            System.out.printf("  [Trader]  Trading at $%.2f%n", market.lastPrice);
        });

        trader.start(); marketControl.start();
        try { marketControl.join(); trader.join(); } catch (InterruptedException e) {}
    }

    static void countDownLatchDemo() throws InterruptedException {
        System.out.println("\n--- CountDownLatch (startup barrier) ---");

        CountDownLatch latch = new CountDownLatch(3);
        String[] services = {"DatabaseService", "CacheService", "MessageBroker"};

        ExecutorService exec = Executors.newFixedThreadPool(3);
        for (String svc : services) {
            exec.submit(() -> {
                try {
                    Thread.sleep((long)(Math.random() * 300 + 100));
                    System.out.println("  ✓ " + svc + " ready");
                    latch.countDown();
                } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            });
        }

        System.out.println("  Waiting for all services...");
        latch.await(5, TimeUnit.SECONDS);
        System.out.println("  All services UP — application started!");
        exec.shutdown();
    }
}