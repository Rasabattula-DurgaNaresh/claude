package com.javamastery.functional;

import java.util.*;
import java.util.function.*;
import java.util.stream.*;

/**
 * MODULE 5: Functional Programming — Lambda, Streams, Optional, Method Refs
 * Real-world: Employee analytics, order processing pipeline
 */
public class FunctionalDemo {

    record Employee(String name, String dept, double salary, int age, boolean active) {}
    record Order(String id, String product, double amount, String status) {}

    public static void run() {
        System.out.println("\n══════════════════════════════════════════");
        System.out.println("  MODULE 5: Functional Programming");
        System.out.println("══════════════════════════════════════════");
        lambdaDemo();
        streamDemo();
        optionalDemo();
    }

    static void lambdaDemo() {
        System.out.println("\n--- Lambda & Functional Interfaces ---");

        // Predicate<T>
        Predicate<Employee> isActive    = Employee::active;
        Predicate<Employee> isEngineering = e -> e.dept().equals("Engineering");
        Predicate<Employee> highSalary   = e -> e.salary() > 90_000;
        Predicate<Employee> seniorEng    = isActive.and(isEngineering).and(highSalary);

        // Function<T,R>
        Function<Employee, String> getSummary =
            e -> String.format("%-10s %-15s $%,.0f", e.name(), e.dept(), e.salary());
        Function<String, String> addBorder = s -> "| " + s + " |";
        Function<Employee, String> withBorder = getSummary.andThen(addBorder);

        // Consumer<T>
        Consumer<Employee> printRow    = e -> System.out.println("  " + getSummary.apply(e));
        Consumer<Employee> printSalary = e -> System.out.printf("  %s earns $%,.0f%n", e.name(), e.salary());
        Consumer<Employee> both        = printRow.andThen(e -> System.out.println("    ^--- senior"));

        // Supplier<T>
        Supplier<List<Employee>> freshList = ArrayList::new;

        // BiFunction<T,U,R>
        BiFunction<Employee, Double, Double> applyBonus = (emp, pct) -> emp.salary() * (1 + pct);

        // UnaryOperator
        UnaryOperator<Double> addTax = amount -> amount * 1.18;
        UnaryOperator<Double> discount = amount -> amount * 0.9;
        Function<Double, Double> priceCalc = addTax.andThen(discount);

        System.out.printf("Price after tax+discount: $%.2f%n", priceCalc.apply(1000.0));

        // Method references: 4 types
        List<String> names = Arrays.asList("Charlie", "Alice", "Bob", "Diana");
        names.sort(String::compareToIgnoreCase);  // static method ref
        names.forEach(System.out::println);        // instance method ref (specific)
        names.stream().map(String::toUpperCase)    // instance method ref (arbitrary)
             .forEach(s -> {});
        List<ArrayList<String>> lists = Stream.generate(ArrayList::new) // constructor ref
            .limit(3).collect(Collectors.toList());
    }

    static void streamDemo() {
        System.out.println("\n--- Streams ---");

        List<Employee> employees = List.of(
            new Employee("Alice",   "Engineering", 95000, 32, true),
            new Employee("Bob",     "Engineering", 85000, 28, true),
            new Employee("Charlie", "Marketing",   65000, 35, false),
            new Employee("Diana",   "Engineering", 105000,40, true),
            new Employee("Eve",     "HR",          60000, 27, true),
            new Employee("Frank",   "Marketing",   72000, 45, true),
            new Employee("Grace",   "HR",          58000, 30, false)
        );

        // filter + map + sorted + collect
        List<String> activeNames = employees.stream()
            .filter(Employee::active)
            .map(Employee::name)
            .sorted()
            .collect(Collectors.toList());
        System.out.println("Active employees: " + activeNames);

        // Statistics
        DoubleSummaryStatistics stats = employees.stream()
            .filter(Employee::active)
            .mapToDouble(Employee::salary)
            .summaryStatistics();
        System.out.printf("Salary: count=%d avg=$%,.0f max=$%,.0f min=$%,.0f total=$%,.0f%n",
            stats.getCount(), stats.getAverage(), stats.getMax(),
            stats.getMin(), stats.getSum());

        // groupingBy
        Map<String, List<Employee>> byDept = employees.stream()
            .collect(Collectors.groupingBy(Employee::dept));
        System.out.println("\nBy department:");
        byDept.forEach((dept, emps) -> {
            double avg = emps.stream().mapToDouble(Employee::salary).average().orElse(0);
            System.out.printf("  %-15s count=%d  avg=$%,.0f%n", dept, emps.size(), avg);
        });

        // partitioningBy
        Map<Boolean, List<Employee>> partition = employees.stream()
            .collect(Collectors.partitioningBy(Employee::active));
        System.out.println("Active: " + partition.get(true).size() +
                           " | Inactive: " + partition.get(false).size());

        // flatMap — flatten skills
        List<List<String>> skillSets = List.of(
            List.of("Java","Spring","SQL"),
            List.of("Python","Django"),
            List.of("Java","Docker","Kubernetes")
        );
        List<String> allSkills = skillSets.stream()
            .flatMap(Collection::stream)
            .distinct().sorted()
            .collect(Collectors.toList());
        System.out.println("All unique skills: " + allSkills);

        // reduce
        double totalPayroll = employees.stream()
            .filter(Employee::active)
            .mapToDouble(Employee::salary)
            .reduce(0, Double::sum);
        System.out.printf("Total payroll: $%,.0f%n", totalPayroll);

        // collect to map: name → salary
        Map<String, Double> salaryMap = employees.stream()
            .collect(Collectors.toMap(Employee::name, Employee::salary));

        // joining
        String nameList = employees.stream()
            .map(Employee::name)
            .collect(Collectors.joining(", ", "[", "]"));
        System.out.println("Names: " + nameList);

        // Order processing pipeline
        System.out.println("\n--- Order Processing Pipeline ---");
        List<Order> orders = List.of(
            new Order("O1","Laptop",    999.99, "PENDING"),
            new Order("O2","Mouse",      29.99, "SHIPPED"),
            new Order("O3","Keyboard",   79.99, "PENDING"),
            new Order("O4","Monitor",   299.99, "DELIVERED"),
            new Order("O5","Webcam",     89.99, "PENDING")
        );

        double pendingRevenue = orders.stream()
            .filter(o -> o.status().equals("PENDING"))
            .mapToDouble(Order::amount)
            .sum();
        System.out.printf("Pending revenue: $%,.2f%n", pendingRevenue);

        Map<String, Long> byStatus = orders.stream()
            .collect(Collectors.groupingBy(Order::status, Collectors.counting()));
        byStatus.forEach((s,c) -> System.out.printf("  %-12s %d orders%n", s, c));
    }

    static void optionalDemo() {
        System.out.println("\n--- Optional ---");

        Optional<String> name    = Optional.of("Alice");
        Optional<String> empty   = Optional.empty();
        Optional<String> nullOpt = Optional.ofNullable(null);

        // Safe chaining
        String upper = name.map(String::toUpperCase).orElse("UNKNOWN");
        String def   = empty.orElse("DEFAULT");
        String gen   = empty.orElseGet(() -> "GENERATED_" + System.nanoTime());

        System.out.println("upper   : " + upper);
        System.out.println("default : " + def);

        // ifPresent / ifPresentOrElse
        name.ifPresent(n -> System.out.println("Found   : " + n));
        empty.ifPresentOrElse(
            n  -> System.out.println("Value: " + n),
            () -> System.out.println("No value — running fallback")
        );

        // filter + map chain
        Optional<Integer> len = name
            .filter(n -> n.length() > 3)
            .map(String::length);
        System.out.println("Length if >3: " + len.orElse(-1));

        // orElseThrow
        try {
            empty.orElseThrow(() -> new RuntimeException("Value required!"));
        } catch (RuntimeException e) {
            System.out.println("Caught: " + e.getMessage());
        }
    }
}