package com.javamastery.oop;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * MODULE 2C: OOP — Interfaces, Abstract Classes, Multiple Interfaces
 * Real-world: Payment gateway system
 */
public class PaymentSystem {

    // ── Interface 1: PaymentProcessor ─────────────────────────────────
    public interface PaymentProcessor {
        String processPayment(double amount, String currency);
        boolean refund(String txId, double amount);
        default String getReceipt(String txId, double amount) {
            return String.format("RECEIPT[%s]: $%.2f via %s", txId, amount, getGatewayName());
        }
        String getGatewayName();
        int MAX_RETRY = 3; // implicitly public static final
    }

    // ── Interface 2: FraudDetectable ──────────────────────────────────
    public interface FraudDetectable {
        boolean isSuspicious(double amount, String country);
        default void flagTransaction(String txId) {
            System.out.println("  🚨 FRAUD ALERT: " + txId + " flagged for review");
        }
    }

    // ── Interface 3: Auditable ─────────────────────────────────────────
    public interface Auditable {
        List<String> getAuditTrail();
        default void printAuditTrail() {
            System.out.println("  Audit Trail:");
            getAuditTrail().forEach(log -> System.out.println("    • " + log));
        }
    }

    // ── Abstract gateway (partial implementation) ──────────────────────
    public static abstract class BaseGateway
            implements PaymentProcessor, FraudDetectable, Auditable {

        protected final String gatewayName;
        protected final List<String> auditLogs = new ArrayList<>();
        protected int txCount = 0;

        public BaseGateway(String name) { this.gatewayName = name; }

        // Concrete — shared logic
        protected String generateTxId() {
            return gatewayName.substring(0,3).toUpperCase()
                    + String.format("%06d", ++txCount);
        }

        protected void audit(String event) {
            auditLogs.add(java.time.LocalTime.now() + " | " + event);
        }

        @Override public String      getGatewayName()   { return gatewayName; }
        @Override public List<String> getAuditTrail()   { return auditLogs; }

        // Abstract — each gateway implements differently
        protected abstract boolean callExternalAPI(double amount, String currency);
    }

    // ── Concrete: StripeGateway ────────────────────────────────────────
    public static class StripeGateway extends BaseGateway {
        private double dailyVolume = 0;
        private static final double DAILY_LIMIT = 100_000;

        public StripeGateway() { super("Stripe"); }

        @Override
        public String processPayment(double amount, String currency) {
            if (dailyVolume + amount > DAILY_LIMIT) {
                audit("PAYMENT REJECTED — daily limit exceeded");
                return "REJECTED";
            }
            if (isSuspicious(amount, "XX")) {
                String txId = generateTxId();
                flagTransaction(txId);
                audit("SUSPICIOUS PAYMENT: $" + amount);
                return "FLAGGED:" + txId;
            }
            boolean ok = callExternalAPI(amount, currency);
            String txId = generateTxId();
            dailyVolume += amount;
            audit(ok ? "PAYMENT_OK: " + txId + " $" + amount
                     : "PAYMENT_FAIL: " + txId);
            System.out.printf("  [Stripe] %s $%.2f %s → %s%n",
                    currency, amount, txId, ok ? "APPROVED" : "DECLINED");
            return ok ? "OK:" + txId : "FAIL:" + txId;
        }

        @Override
        public boolean refund(String txId, double amount) {
            audit("REFUND: " + txId + " $" + amount);
            System.out.printf("  [Stripe] Refund $%.2f for %s → OK%n", amount, txId);
            return true;
        }

        @Override
        public boolean isSuspicious(double amount, String country) {
            return amount > 50_000 || "NG,XX,ZZ".contains(country);
        }

        @Override
        protected boolean callExternalAPI(double amount, String currency) {
            return amount < DAILY_LIMIT; // simulate: all valid amounts approved
        }
    }

    // ── Concrete: PayPalGateway ────────────────────────────────────────
    public static class PayPalGateway extends BaseGateway {
        public PayPalGateway() { super("PayPal"); }

        @Override
        public String processPayment(double amount, String currency) {
            boolean ok = callExternalAPI(amount, currency);
            String txId = generateTxId();
            audit("PAYMENT: " + txId + " $" + amount);
            System.out.printf("  [PayPal] %s $%.2f → %s%n",
                    currency, amount, ok ? "OK:" + txId : "FAIL");
            return ok ? "OK:" + txId : "FAIL";
        }

        @Override
        public boolean refund(String txId, double amount) {
            audit("REFUND: " + txId);
            return true;
        }

        @Override
        public boolean isSuspicious(double amount, String country) {
            return amount > 10_000;
        }

        @Override
        protected boolean callExternalAPI(double amount, String currency) {
            return amount <= 50_000;
        }
    }

    public static void run() {
        System.out.println("\n══════════════════════════════════════════");
        System.out.println("  MODULE 2C: Interfaces & Abstract Classes");
        System.out.println("══════════════════════════════════════════");

        PaymentProcessor[] gateways = { new StripeGateway(), new PayPalGateway() };

        double[] amounts = {299.99, 55_000.0, 1500.0};
        String currency  = "USD";

        for (PaymentProcessor gw : gateways) {
            System.out.println("\nGateway: " + gw.getGatewayName());
            for (double amount : amounts) {
                String result = gw.processPayment(amount, currency);
                if (result.startsWith("OK:")) {
                    String txId = result.substring(3);
                    System.out.println("    " + gw.getReceipt(txId, amount));
                }
            }
            if (gw instanceof Auditable a) a.printAuditTrail();
        }

        // BankAccount demo
        System.out.println("\n─── Bank Account Demo ───");
        BankAccount acc1 = new BankAccount("Alice Johnson", 5000);
        BankAccount acc2 = new BankAccount("Bob Smith", BankAccount.AccountType.CURRENT, 10000);

        acc1.deposit(2000);
        acc1.withdraw(500);
        BankAccount.transfer(acc1, acc2, 1000);
        System.out.println("  " + acc1);
        System.out.println("  " + acc2);
        System.out.println("  Total accounts: " + BankAccount.getTotalAccountsCreated());
        System.out.printf("  Total deposits: $%,.2f%n", BankAccount.getTotalDepositsEver());
    }
}