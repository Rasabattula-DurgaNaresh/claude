package com.javamastery.io;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.*;

/**
 * MODULE 7: File I/O & NIO
 * Real-world: Sales report generation, CSV processing, log management
 */
public class FileIODemo {

    private static final Path BASE_DIR = Paths.get(System.getProperty("java.io.tmpdir"), "java-mastery");

    public static void run() throws IOException {
        System.out.println("\n══════════════════════════════════════════");
        System.out.println("  MODULE 7: File I/O & NIO");
        System.out.println("══════════════════════════════════════════");

        Files.createDirectories(BASE_DIR);
        traditionalIODemo();
        nioDemo();
        csvDemo();
        System.out.println("  Output dir: " + BASE_DIR);
    }

    static void traditionalIODemo() throws IOException {
        System.out.println("\n--- Traditional I/O ---");
        Path report = BASE_DIR.resolve("sales_report.txt");

        // Write with BufferedWriter (try-with-resources = auto-close)
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(report.toFile()))) {
            bw.write("=== MONTHLY SALES REPORT ===");
            bw.newLine();
            String[] products = {"Laptop", "Mouse", "Keyboard", "Monitor", "Webcam"};
            double[] sales    = {45_200, 8_900, 12_300, 22_100, 6_750};
            for (int i = 0; i < products.length; i++) {
                bw.write(String.format("%-10s  $%,.2f", products[i], sales[i]));
                bw.newLine();
            }
            bw.write(String.format("TOTAL      $%,.2f", Arrays.stream(sales).sum()));
        }
        System.out.println("  Written: " + report);

        // Read with BufferedReader
        try (BufferedReader br = new BufferedReader(new FileReader(report.toFile()))) {
            String line;
            int lines = 0;
            while ((line = br.readLine()) != null) {
                System.out.println("  " + line);
                lines++;
            }
            System.out.println("  (" + lines + " lines read)");
        }
    }

    static void nioDemo() throws IOException {
        System.out.println("\n--- NIO (java.nio.file) ---");
        Path config = BASE_DIR.resolve("app_config.properties");

        // Write (overwrites entirely)
        List<String> lines = List.of(
            "# Application Configuration",
            "db.host=localhost",
            "db.port=5432",
            "db.name=production_db",
            "cache.ttl=3600",
            "max.connections=20"
        );
        Files.write(config, lines);

        // Read entire file as String (Java 11+)
        String content = Files.readString(config);
        System.out.println("  Config contents:");
        System.out.println("  " + content.replace("\n", "\n  ").trim());

        // Stream lines lazily (memory-efficient for large files)
        try (Stream<String> stream = Files.lines(config)) {
            long keyCount = stream
                .filter(l -> !l.startsWith("#") && l.contains("="))
                .count();
            System.out.println("  Config keys: " + keyCount);
        }

        // Parse properties
        Properties props = new Properties();
        try (InputStream is = Files.newInputStream(config)) {
            props.load(is);
        }
        System.out.println("  db.host   = " + props.getProperty("db.host"));
        System.out.println("  db.port   = " + props.getProperty("db.port"));
        System.out.println("  max.conn  = " + props.getProperty("max.connections"));

        // File metadata
        System.out.printf("  File size : %d bytes%n", Files.size(config));
        System.out.println("  Exists    : " + Files.exists(config));

        // Copy
        Path backup = BASE_DIR.resolve("app_config.bak");
        Files.copy(config, backup, StandardCopyOption.REPLACE_EXISTING);
        System.out.println("  Backed up to: " + backup.getFileName());

        // Walk directory
        System.out.println("  Files in temp dir:");
        try (Stream<Path> walk = Files.walk(BASE_DIR, 1)) {
            walk.filter(Files::isRegularFile)
                .forEach(p -> System.out.println("    " + p.getFileName()));
        }
    }

    static void csvDemo() throws IOException {
        System.out.println("\n--- CSV Processing ---");
        Path csv = BASE_DIR.resolve("employees.csv");

        // Write CSV
        List<String[]> data = new ArrayList<>();
        data.add(new String[]{"id","name","department","salary","active"});
        data.add(new String[]{"1","Alice","Engineering","95000","true"});
        data.add(new String[]{"2","Bob","Marketing","65000","true"});
        data.add(new String[]{"3","Charlie","HR","60000","false"});
        data.add(new String[]{"4","Diana","Engineering","105000","true"});
        data.add(new String[]{"5","Eve","Marketing","72000","true"});

        try (PrintWriter pw = new PrintWriter(new FileWriter(csv.toFile()))) {
            data.forEach(row -> pw.println(String.join(",", row)));
        }
        System.out.println("  CSV written: " + csv.getFileName());

        // Read and process CSV with Stream
        System.out.println("  Engineering employees earning > $80k:");
        try (Stream<String> lines = Files.lines(csv)) {
            lines.skip(1)  // skip header
                .map(line -> line.split(","))
                .filter(col -> col[2].equals("Engineering")
                            && Double.parseDouble(col[3]) > 80_000
                            && Boolean.parseBoolean(col[4]))
                .forEach(col -> System.out.printf("    %-10s $%s%n", col[1], col[3]));
        }

        // Aggregate: average salary per department
        System.out.println("  Avg salary by dept:");
        Map<String, DoubleSummaryStatistics> deptStats;
        try (Stream<String> lines = Files.lines(csv)) {
            deptStats = lines.skip(1)
                .map(l -> l.split(","))
                .collect(Collectors.groupingBy(
                    col -> col[2],
                    Collectors.summarizingDouble(col -> Double.parseDouble(col[3]))));
        }
        deptStats.forEach((dept, stats) ->
            System.out.printf("    %-15s count=%d avg=$%,.0f%n",
                    dept, stats.getCount(), stats.getAverage()));
    }
}