package com.javamastery.oop;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

/**
 * MODULE 2A: OOP — Encapsulation
 * Real-world: Full BankAccount class with proper encapsulation
 */
public class BankAccount {

    // ── Enums (inner) ──────────────────────────────────────────────────
    public enum Status { ACTIVE, FROZEN, CLOSED }
    public enum AccountType { SAVINGS, CURRENT, SALARY }

    // ── Immutable fields (set once in constructor) ──────────────────────
    private final String accountId;
    private final String ownerName;
    private final AccountType type;
    private final LocalDateTime openedAt;

    // ── Mutable fields (controlled via methods) ─────────────────────────
    private double balance;
    private Status status;
    private int    failedPinAttempts;
    private final List<String> transactionLog;

    // ── Class-level (shared) ────────────────────────────────────────────
    private static int    totalAccountsCreated = 0;
    private static double totalDepositsEver    = 0;
    static final double   MINIMUM_BALANCE      = 500.0;
    static final int      MAX_PIN_ATTEMPTS     = 3;

    // ── Primary Constructor ─────────────────────────────────────────────
    public BankAccount(String ownerName, AccountType type, double initialDeposit) {
        if (ownerName == null || ownerName.isBlank())
            throw new IllegalArgumentException("Owner name cannot be blank");
        if (initialDeposit < MINIMUM_BALANCE)
            throw new IllegalArgumentException(
                "Initial deposit must be >= $" + MINIMUM_BALANCE);

        this.accountId      = "AC" + String.format("%08d", ++totalAccountsCreated);
        this.ownerName      = ownerName.trim();
        this.type           = type;
        this.balance        = initialDeposit;
        this.status         = Status.ACTIVE;
        this.openedAt       = LocalDateTime.now();
        this.failedPinAttempts = 0;
        this.transactionLog = new ArrayList<>();
        totalDepositsEver  += initialDeposit;

        log("ACCOUNT_OPEN", initialDeposit);
    }

    // ── Convenience constructor ─────────────────────────────────────────
    public BankAccount(String ownerName, double initialDeposit) {
        this(ownerName, AccountType.SAVINGS, initialDeposit);
    }

    // ── Business Methods ────────────────────────────────────────────────
    public boolean deposit(double amount) {
        validateActive();
        if (amount <= 0) throw new IllegalArgumentException("Deposit must be > 0");
        balance += amount;
        totalDepositsEver += amount;
        log("DEPOSIT", amount);
        System.out.printf("  ✓ Deposited $%.2f | New balance: $%.2f%n", amount, balance);
        return true;
    }

    public boolean withdraw(double amount) {
        validateActive();
        if (amount <= 0) throw new IllegalArgumentException("Amount must be > 0");
        if (balance - amount < MINIMUM_BALANCE)
            throw new IllegalStateException(
                "Insufficient funds. Min balance $" + MINIMUM_BALANCE + " required.");
        balance -= amount;
        log("WITHDRAWAL", amount);
        System.out.printf("  ✓ Withdrew $%.2f | New balance: $%.2f%n", amount, balance);
        return true;
    }

    public static boolean transfer(BankAccount from, BankAccount to, double amount) {
        System.out.printf("  Transfer: $%.2f from %s to %s%n",
                amount, from.accountId, to.accountId);
        from.withdraw(amount);
        to.deposit(amount);
        return true;
    }

    public void freeze() {
        this.status = Status.FROZEN;
        log("ACCOUNT_FROZEN", 0);
        System.out.println("  ⚠ Account " + accountId + " FROZEN");
    }

    // ── Private helpers ─────────────────────────────────────────────────
    private void validateActive() {
        if (status != Status.ACTIVE)
            throw new IllegalStateException("Account is " + status);
    }

    private void log(String type, double amount) {
        transactionLog.add(String.format("[%s] %s: $%.2f",
                LocalDateTime.now().toLocalTime(), type, amount));
    }

    // ── Getters (no setters for critical fields) ────────────────────────
    public String      getAccountId()    { return accountId; }
    public String      getOwnerName()    { return ownerName; }
    public AccountType getType()         { return type; }
    public double      getBalance()      { return balance; }
    public Status      getStatus()       { return status; }
    public List<String> getTransactionLog() {
        return Collections.unmodifiableList(transactionLog); // defensive copy
    }

    // ── Static getters ──────────────────────────────────────────────────
    public static int    getTotalAccountsCreated() { return totalAccountsCreated; }
    public static double getTotalDepositsEver()    { return totalDepositsEver; }

    // ── toString / equals / hashCode ─────────────────────────────────────
    @Override
    public String toString() {
        return String.format("BankAccount{id='%s', owner='%s', type=%s, balance=$%.2f, status=%s}",
                accountId, ownerName, type, balance, status);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof BankAccount)) return false;
        return accountId.equals(((BankAccount)o).accountId);
    }

    @Override
    public int hashCode() { return accountId.hashCode(); }
}