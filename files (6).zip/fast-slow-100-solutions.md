# 100 Fast & Slow Pointer Problems — Complete Java Solutions

> **100 Programs · 6 Java files · 5 PNG diagrams · Floyd's Algorithm + All variants**

---

## Diagram Index

| Diagram | Topic |
|---------|-------|
| `diagrams/01_floyds_algorithm.png` | Floyd's cycle detection + phase 2 entry finding |
| `diagrams/02_middle_palindrome.png` | Middle finding (odd/even) + palindrome check |
| `diagrams/03_happy_number_array.png` | Happy number sequence + array duplicate detection |
| `diagrams/04_reorder_advanced.png` | Reorder list 3-step + circular array loop |
| `diagrams/05_decision_tree.png` | Master decision tree for all patterns |

## Project Structure

```
fast-slow-100/
├── pom.xml
├── diagrams/           ← 5 PNG diagrams
├── docs/               ← This guide
└── src/main/java/com/fastslow/
    ├── utils/      ListNode.java + FastSlowUtils.java  (shared utils + P99-100)
    ├── beginner/   BeginnerProblems.java               (P1-20)
    ├── easymedium/ EasyMediumProblems.java             (P21-40)
    ├── medium/     MediumProblems.java                  (P41-60)
    └── hard/       HardProblems.java                    (P61-100)
```

**Run:**
```bash
mvn compile exec:java -Dexec.mainClass="com.fastslow.beginner.BeginnerProblems"
mvn compile exec:java -Dexec.mainClass="com.fastslow.hard.HardProblems"
```

---

# Core Algorithm — Floyd's Cycle Detection (Tortoise & Hare)

> **See diagram:** `diagrams/01_floyds_algorithm.png`

## The Two-Phase Algorithm

```java
// ═══════════════════════════════════════════════════════════
// PHASE 1: Detect if cycle exists
// ═══════════════════════════════════════════════════════════
ListNode slow = head, fast = head;
while (fast != null && fast.next != null) {
    slow = slow.next;        // moves 1 step
    fast = fast.next.next;   // moves 2 steps
    if (slow == fast) break; // CYCLE FOUND — they meet inside cycle
}
// If fast reaches null: NO cycle (acyclic list)

// ═══════════════════════════════════════════════════════════
// PHASE 2: Find cycle ENTRY node
// ═══════════════════════════════════════════════════════════
slow = head; // reset slow to head
while (slow != fast) {
    slow = slow.next; // both move 1 step
    fast = fast.next;
}
// slow == fast == CYCLE ENTRY NODE ✓
```

## Why Phase 2 Works — Mathematical Proof

```
Let F = distance from head to cycle entry
    C = cycle length
    k = meeting point distance from cycle entry

When they meet:
  slow traveled: F + k
  fast traveled: F + k + n*C (went around cycle n times)

Since fast = 2 * slow:
  F + k + n*C = 2(F + k)
  n*C = F + k
  F = n*C - k

After reset: both travel F steps to meet at entry.
The one starting at head walks F.
The one at meeting point walks F = n*C - k steps = arrives at entry!
```

## Complexity

| Pattern | Time | Space |
|---------|------|-------|
| Detect cycle | O(n) | O(1) |
| Find cycle entry | O(n) | O(1) |
| Find cycle length | O(n) | O(1) |
| Find middle | O(n) | O(1) |
| Happy number | O(log n) | O(1) |
| Find duplicate | O(n) | O(1) |

---

# Core Templates

## Template 1 — Cycle Detection
```java
public boolean hasCycle(ListNode head) {
    ListNode slow = head, fast = head;
    while (fast != null && fast.next != null) {
        slow = slow.next;
        fast = fast.next.next;
        if (slow == fast) return true;
    }
    return false;
}
```

## Template 2 — Cycle Entry
```java
public ListNode detectCycleStart(ListNode head) {
    ListNode slow = head, fast = head;
    // Phase 1
    while (fast != null && fast.next != null) {
        slow = slow.next; fast = fast.next.next;
        if (slow == fast) break;
    }
    if (fast == null || fast.next == null) return null;
    // Phase 2
    slow = head;
    while (slow != fast) { slow = slow.next; fast = fast.next; }
    return slow;
}
```

## Template 3 — Find Middle
```java
// Returns SECOND middle for even-length lists
public ListNode findMiddle(ListNode head) {
    ListNode slow = head, fast = head;
    while (fast != null && fast.next != null) {
        slow = slow.next;
        fast = fast.next.next;
    }
    return slow; // middle node
}

// Returns FIRST middle for even-length lists
public ListNode findFirstMiddle(ListNode head) {
    ListNode slow = head, fast = head;
    while (fast.next != null && fast.next.next != null) {
        slow = slow.next;
        fast = fast.next.next;
    }
    return slow;
}
```

## Template 4 — Happy Number / Sequence Cycle
```java
// Apply Floyd's to any function f(n) → next state
public boolean isHappy(int n) {
    int slow = n, fast = n;
    do {
        slow = f(slow);        // f applied once
        fast = f(f(fast));     // f applied twice
    } while (slow != fast);
    return slow == 1; // if cycle bottoms at 1 → happy
}
```

## Template 5 — Array as Linked List (Duplicate Finding)
```java
// Treat value as pointer to next index: i → nums[i]
public int findDuplicate(int[] nums) {
    int slow = nums[0], fast = nums[0];
    // Phase 1: detect
    do { slow = nums[slow]; fast = nums[nums[fast]]; }
    while (slow != fast);
    // Phase 2: find entry (= duplicate value)
    slow = nums[0];
    while (slow != fast) { slow = nums[slow]; fast = nums[fast]; }
    return slow;
}
```

## Template 6 — Reorder List (Middle + Reverse + Merge)
```java
public void reorderList(ListNode head) {
    // Step 1: Find first middle
    ListNode slow = head, fast = head;
    while (fast.next != null && fast.next.next != null) {
        slow = slow.next; fast = fast.next.next;
    }
    // Step 2: Reverse second half
    ListNode second = reverse(slow.next);
    slow.next = null; // split
    // Step 3: Interleave
    ListNode l = head, r = second;
    while (r != null) {
        ListNode lt = l.next, rt = r.next;
        l.next = r; r.next = lt;
        l = lt; r = rt;
    }
}
```

---

# BEGINNER LEVEL (P1–P20)

## P1. Middle of Linked List
**LeetCode 876** — Classic fast/slow. Fast at 2× speed; when it stops, slow is at middle.

```java
ListNode slow=head, fast=head;
while(fast!=null && fast.next!=null){ slow=slow.next; fast=fast.next.next; }
return slow; // [1,2,3,4,5] → node(3)  [1,2,3,4] → node(3) [second middle]
```

---

## P2. Second Middle (even-length)
Default `findMiddle()` — when even, fast lands on last node, slow at second middle.

`[1,2,3,4]` → node(3) is second middle.

---

## P3. First Middle (even-length)
Stop one step earlier: `while(fast.next != null && fast.next.next != null)`

`[1,2,3,4]` → node(2) is first middle.

---

## P4. Detect Cycle in Linked List ⭐
**LeetCode 141** — Fundamental Floyd's detection.

```java
if(slow==fast) return true; // they meet inside the cycle
```

**Why it works:** fast gains on slow by 1 step per iteration. In a cycle of length C, they must meet within C steps.

---

## P5. Find Cycle Start Node ⭐⭐
**LeetCode 142** — Phase 2 of Floyd's.

```java
// After phase 1 (meeting point found):
slow = head;
while(slow != fast){ slow=slow.next; fast=fast.next; }
return slow; // = cycle entry
```

---

## P6. Find Cycle Length
After phase 1 meeting, count steps until back to meeting point:

```java
int len=1; ListNode cur=slow.next;
while(cur!=slow){ cur=cur.next; len++; }
```

---

## P7. Remove Cycle
Find cycle entry, then find the node just before it (the tail). Set `tail.next = null`.

---

## P8. Check Circular Linked List
Cycle exists AND cycle entry is head node.

---

## P9. Happy Number ⭐
**LeetCode 202** — Apply Floyd's on the `sumSquaredDigits(n)` function.

```java
// 19→82→68→100→1→1 (happy!)
// 4→16→37→58→89→145→42→20→4 (cycle, not happy)
int slow=n, fast=n;
do{ slow=f(slow); fast=f(f(fast)); } while(slow!=fast);
return slow==1;
```

---

## P10. Happy Number Cycle Length
After detection, count steps back to meeting point.

---

## P11. Find Duplicate Number ⭐⭐
**LeetCode 287** — Array values as pointers. O(n) time, O(1) space.

```java
// [1,3,4,2,2]: 0→1→3→2→4→2 (cycle at 2!)
// Phase 1: detect, Phase 2: find entry = duplicate
```

---

## P12. Find Repeated Element
Same as P11 — Floyd's on array indices.

---

## P13. Middle of Doubly Linked List
Same fast/slow logic — works on any bidirectional linked structure.

---

## P14. Split Linked List into Two Halves
Find first middle, cut at mid.next:

```java
ListNode mid = findFirstMiddle(head);
ListNode second = mid.next;
mid.next = null; // split here
```

---

## P15. Count Nodes Before Cycle
Walk from head to cycle entry, counting steps.

---

## P16. Count Nodes Inside Cycle
= P6 (cycle length).

---

## P17. Reverse Second Half
Find first middle, then `reverse(mid.next)`.

---

## P18. Palindrome Linked List ⭐⭐
**LeetCode 234** — Find middle, reverse second half, compare, restore.

```java
// [1,2,2,1]: mid→node(2)  reversed-second:[1,2]
// Compare: 1==1, 2==2 → true
// Time O(n), Space O(1)
```

---

## P19. Restore List After Palindrome Check
After comparison, reverse the second half again to restore original order.

---

## P20. Find Kth Node From Middle
Find middle, advance k more steps.

---

# EASY-MEDIUM LEVEL (P21–P40)

## P21. Reorder List ⭐⭐⭐
**LeetCode 143** — 3-step: middle → reverse second → interleave.

```
[1,2,3,4,5] → [1,5,2,4,3]
Step 1: mid at node(3)
Step 2: reverse [4,5] → [5,4]
Step 3: interleave [1,2,3] with [5,4]
```

---

## P22. Fold a Linked List
= P21 reorder (same operation).

---

## P23. Unfold a Folded Linked List
Extract alternating elements back into two separate lists.

---

## P24. Find Meeting Point of Two Pointers in Cycle
= Phase 1 of Floyd's — return the meeting node.

---

## P25. Intersection of Two Linked Lists
**LeetCode 160** — Switch pointer to other list's head when reaching null:

```java
ListNode a=headA, b=headB;
while(a!=b){ a=(a==null)?headB:a.next; b=(b==null)?headA:b.next; }
return a; // intersection or null
// Both travel lenA + lenB total, equalizing paths
```

---

## P26. Rotate Linked List ⭐
**LeetCode 61** — Find tail, make circular, advance to `len-k-1` position, cut.

---

## P27. Rotate Circular Linked List
Similar to P26 but start already circular.

---

## P28. Remove Nth Node From End ⭐⭐
**LeetCode 19** — Fast starts n+1 ahead; when fast=null, slow is just before target.

```java
// n=2: [1,2,3,4,5] → [1,2,3,5]
// fast starts 3 steps ahead, then both walk to end
```

---

## P29. Find Kth Node From End
Fast starts k steps ahead; when fast=null, slow is at kth from end.

---

## P30. Pair Sum in Sorted Linked List
Convert to array, use two-pointer approach on values.

---

## P31. Twin Sum of Linked List ⭐
**LeetCode 2130** — Find middle, reverse second half, pair up values:

```java
// [4,2,2,3]: mid after [4,2] | second [2,3] reversed [3,2]
// pairs: (4,3)=7, (2,2)=4 → max=7
```

---

## P32. Odd-Even Indexed Nodes ⭐
**LeetCode 328** — Chain odds, chain evens, join. O(n) time, O(1) space.

---

## P33-35. Segregate Lists
Use dummy heads for each category, build separate chains, join at end.

---

## P36. Detect Cycle in Array Jumps
Track visited indices; if revisited → cycle.

---

## P37. Find Duplicate and Missing Numbers
Use sum formulas: `missing - dup = expected_sum - actual_sum`, solve system.

---

## P38. Circular Array Loop ⭐⭐
**LeetCode 457** — For each unvisited start, run fast/slow with direction constraint:
- All moves in same direction only
- Cycle length > 1 (no self-loops)

---

## P39. Even or Odd Length
Fast pointer: if lands on null → even; on last node → odd.

```java
while(fast!=null && fast.next!=null) fast=fast.next.next;
return fast==null; // true=even, false=odd
```

---

## P40. Find Node Before Cycle Start
Walk from head tracking previous node, stop when reaching cycle entry.

---

# MEDIUM LEVEL (P41–P60)

## P41. Reverse Between Pointers
Find middle with fast/slow, reverse the first segment.

---

## P42. Reverse Alternate Halves
Find first middle, reverse second half in place.

---

## P43. Merge First Half + Reversed Second Half
Split at middle, reverse second, interleave both halves.

---

## P44. Reverse Linked List in Groups After Middle
Find middle, reverse second half in groups of K.

---

## P45. Split Circular Linked List
Use fast/slow to find middle of circular list, break into two circles.

---

## P46. Median of Linked List
Find length (O(n)), then advance to middle positions for median.

---

## P48. Find Longest Cycle in Array
**LeetCode 2065** — DFS from each unvisited node; track when revisiting same traversal.

---

## P54. Find Duplicate (No Modify) ⭐⭐⭐
**LeetCode 287** — Floyd's on array indices:

```java
// [1,3,4,2,2]: index jumps form a ρ-shaped graph
// The duplicate is the cycle entry node
// O(n) time, O(1) space — beats HashSet O(n) space approach
```

---

## P55. Find All Duplicates
**LeetCode 442** — Negate visited indices:

```java
int idx = Math.abs(n) - 1;
if(nums[idx] < 0) result.add(Math.abs(n)); // seen before
else nums[idx] = -nums[idx];               // mark seen
```

---

## P56. First Missing Positive (Cyclic Sort) ⭐
**LeetCode 41** — Place each value at index val-1, then find first mismatch.

```java
// Cyclic sort: while(nums[i]>0 && nums[i]<=n && nums[nums[i]-1]!=nums[i]) swap
// Then: first i where nums[i]!=i+1 → answer = i+1
```

---

# HARD / LEETCODE CLASSICS (P81–P100)

## P81. LeetCode 141 — Linked List Cycle
Classic detection. See Template 1.

---

## P82. LeetCode 142 — Linked List Cycle II ⭐⭐⭐
Classic entry finding. See Template 2. The key insight: `F = n*C - k`.

---

## P83. LeetCode 202 — Happy Number ⭐
Apply Floyd's on the `sumSquaredDigits` function. See Template 4.

---

## P84. LeetCode 287 — Find the Duplicate Number ⭐⭐⭐
Array as linked list (values as pointers). See Template 5.

Why it has a cycle: n+1 numbers in [1..n] → pigeonhole → duplicate → two indices point to same next → cycle.

---

## P85. LeetCode 234 — Palindrome Linked List ⭐⭐
Middle + reverse + compare + restore. O(n) time, O(1) space.

---

## P86. LeetCode 143 — Reorder List ⭐⭐⭐
Middle + reverse second half + interleave. See Template 6.

---

## P87. LeetCode 457 — Circular Array Loop ⭐⭐
Fast/slow with constraints:
1. All moves must be in same direction (all positive or all negative)
2. Cycle length must be > 1 (no self-loops)

---

## P88. LeetCode 876 — Middle of Linked List ⭐
See Template 3.

---

## P89. LeetCode 19 — Remove Nth Node From End ⭐⭐
Fast pointer n+1 ahead. When fast=null, slow.next = target to remove.

---

## P90. LeetCode 2130 — Twin Sum ⭐⭐
Middle + reverse second + max(first[i] + reversed[i]).

---

## P91-100. Real-World Applications

| # | Scenario | Fast/Slow Application |
|---|----------|----------------------|
| 91 | Streaming data | Detect cycle in hash chain (O(1) space) |
| 92 | Finite automata | Find repeated state in state machine |
| 93 | Blockchain | Detect hash reference loops |
| 94 | Memory leaks | Detect circular reference chains |
| 95 | Browser redirects | Find redirect loop entry URL |
| 96 | Deadlocks | Detect cycle in process wait-for graph |
| 97 | Dependencies | Detect circular dependency |
| 98 | Simulations | Find eventual stable fixed point |
| 99 | Utility library | `FastSlowUtils` reusable methods |
| 100 | Problem toolkit | Complete pattern guide (this document) |

---

# Pattern Decision Guide

```
Is it a linked list?
├── Need to check for cycle?          → Floyd's Cycle Detection (Template 1)
├── Need cycle START node?            → Floyd's Phase 2 (Template 2)
├── Need cycle LENGTH?                → Count after meeting
├── Need MIDDLE node?                 → Fast/Slow middle finding (Template 3)
├── Need PALINDROME check?            → Middle + Reverse + Compare (P18, P85)
├── Need REORDER/FOLD?               → Middle + Reverse + Interleave (P21, P86)
├── Need Nth FROM END?               → Fast n ahead (P28, P29, P89)
└── Need TWIN SUM?                   → Middle + Reverse + Pair (P31, P90)

Is it a number/sequence?
├── Happy number?                     → Fast/Slow on sumSquaredDigits (P9, P83)
├── Array as implicit list?           → Value = next index pointer (P11, P84)
└── Circular array loop?             → Direction-constrained fast/slow (P38, P87)

Is it a general function/mapping?
├── Detect if f(x) cycles?           → Fast/Slow on f (Template 4)
├── Find WHERE it cycles?            → Phase 2 (Template 2 generalized)
└── Find CYCLE LENGTH?               → Count after phase 1
```

---

# FastSlowUtils Library (P99)

```java
// Drop-in utility — all O(n) time, O(1) space
FastSlowUtils.hasCycle(head)          // boolean
FastSlowUtils.cycleStart(head)        // ListNode (cycle entry)
FastSlowUtils.findMiddle(head)        // ListNode (second middle)
FastSlowUtils.findFirstMiddle(head)   // ListNode (first middle)
FastSlowUtils.reverse(head)           // ListNode (reversed list)
FastSlowUtils.cycleLength(head)       // int
FastSlowUtils.kthFromEnd(head, k)     // ListNode
FastSlowUtils.removeCycle(head)       // void
FastSlowUtils.happyNext(n)            // int (sum of squared digits)
FastSlowUtils.floydOnFunction(start, fn) // int (meeting value)
```

---

## Quick Reference — Complexity

| Problem | Time | Space | Key Idea |
|---------|------|-------|----------|
| Detect Cycle | O(n) | O(1) | Fast=2×, meet inside cycle |
| Find Entry | O(n) | O(1) | Reset slow, advance both 1× |
| Find Middle | O(n) | O(1) | Fast=2×, stop when null |
| Happy Number | O(log n) | O(1) | f(n)=sumSq, detect cycle |
| Find Duplicate | O(n) | O(1) | Array as implicit LL |
| Palindrome | O(n) | O(1) | Middle+Reverse+Compare |
| Reorder List | O(n) | O(1) | Middle+Reverse+Interleave |
| Twin Sum | O(n) | O(1) | Middle+Reverse+Pair |
| Nth From End | O(n) | O(1) | Fast n ahead |
| Circular Array | O(n) | O(1) | Direction-constrained |

*100 Fast & Slow Pointer Programs — Complete Java Solutions*
