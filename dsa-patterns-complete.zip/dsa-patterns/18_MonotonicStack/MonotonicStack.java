/**
 * PATTERN 18: MONOTONIC STACK
 * ============================
 * Use when: next greater/smaller element, span problems, histogram
 * Key insight: maintain stack in monotonic order
 *   Monotonic decreasing stack → find next greater element
 *   Monotonic increasing stack → find next smaller element
 *
 * Template (next greater element):
 *   Stack<Integer> stack = new Stack<>();  // stores indices
 *   for (int i = 0; i < n; i++) {
 *       while (!stack.isEmpty() && nums[stack.peek()] < nums[i])
 *           result[stack.pop()] = nums[i];  // i is next greater for popped
 *       stack.push(i);
 *   }
 *
 * Time: O(n) — each element pushed/popped once
 */
import java.util.*;

public class MonotonicStack {

    // 1. Next greater element I
    static int[] nextGreaterElement(int[] nums) {
        int n = nums.length;
        int[] result = new int[n]; Arrays.fill(result, -1);
        Deque<Integer> stack = new ArrayDeque<>(); // indices
        for (int i = 0; i < n; i++) {
            while (!stack.isEmpty() && nums[stack.peek()] < nums[i])
                result[stack.pop()] = nums[i];
            stack.push(i);
        }
        return result;
    }

    // 2. Next greater element (circular array)
    static int[] nextGreaterCircular(int[] nums) {
        int n = nums.length;
        int[] result = new int[n]; Arrays.fill(result, -1);
        Deque<Integer> stack = new ArrayDeque<>();
        for (int i = 0; i < 2 * n; i++) { // traverse twice for circular
            while (!stack.isEmpty() && nums[stack.peek()] < nums[i % n])
                result[stack.pop()] = nums[i % n];
            if (i < n) stack.push(i);
        }
        return result;
    }

    // 3. Daily temperatures — how many days to wait for warmer
    static int[] dailyTemperatures(int[] temps) {
        int n = temps.length;
        int[] result = new int[n];
        Deque<Integer> stack = new ArrayDeque<>();
        for (int i = 0; i < n; i++) {
            while (!stack.isEmpty() && temps[stack.peek()] < temps[i])
                result[stack.peek()] = i - stack.pop();
            stack.push(i);
        }
        return result;
    }

    // 4. Largest rectangle in histogram
    static int largestRectangleArea(int[] heights) {
        int n = heights.length, maxArea = 0;
        Deque<Integer> stack = new ArrayDeque<>();
        for (int i = 0; i <= n; i++) {
            int curHeight = (i == n) ? 0 : heights[i];
            while (!stack.isEmpty() && heights[stack.peek()] > curHeight) {
                int h = heights[stack.pop()];
                int w = stack.isEmpty() ? i : i - stack.peek() - 1;
                maxArea = Math.max(maxArea, h * w);
            }
            stack.push(i);
        }
        return maxArea;
    }

    // 5. Maximal rectangle in binary matrix
    static int maximalRectangle(char[][] matrix) {
        if (matrix.length == 0) return 0;
        int maxArea = 0;
        int[] heights = new int[matrix[0].length];
        for (char[] row : matrix) {
            for (int j = 0; j < heights.length; j++)
                heights[j] = row[j] == '1' ? heights[j] + 1 : 0;
            maxArea = Math.max(maxArea, largestRectangleArea(heights));
        }
        return maxArea;
    }

    // 6. Trapping rain water (monotonic stack approach)
    static int trapRainWater(int[] height) {
        int water = 0;
        Deque<Integer> stack = new ArrayDeque<>();
        for (int i = 0; i < height.length; i++) {
            while (!stack.isEmpty() && height[stack.peek()] < height[i]) {
                int bottom = height[stack.pop()];
                if (stack.isEmpty()) break;
                int left = stack.peek();
                int width = i - left - 1;
                int bounded = Math.min(height[left], height[i]) - bottom;
                water += bounded * width;
            }
            stack.push(i);
        }
        return water;
    }

    // 7. Stock span problem
    static int[] stockSpan(int[] prices) {
        int n = prices.length;
        int[] span = new int[n];
        Deque<Integer> stack = new ArrayDeque<>(); // monotonic decreasing
        for (int i = 0; i < n; i++) {
            while (!stack.isEmpty() && prices[stack.peek()] <= prices[i]) stack.pop();
            span[i] = stack.isEmpty() ? i + 1 : i - stack.peek();
            stack.push(i);
        }
        return span;
    }

    // 8. Remove k digits to make smallest number
    static String removeKdigits(String num, int k) {
        Deque<Character> stack = new ArrayDeque<>();
        for (char c : num.toCharArray()) {
            while (k > 0 && !stack.isEmpty() && stack.peek() > c) { stack.pop(); k--; }
            stack.push(c);
        }
        while (k-- > 0) stack.pop(); // remove from end
        StringBuilder sb = new StringBuilder();
        boolean leadingZero = true;
        for (char c : stack) {
            if (leadingZero && c == '0') continue;
            leadingZero = false; sb.append(c);
        }
        return sb.length() == 0 ? "0" : sb.reverse().toString();
    }

    public static void main(String[] args) {
        System.out.println("===== MONOTONIC STACK PATTERN =====\n");

        int[] a = {2,1,2,4,3};
        System.out.println("1. nextGreater([2,1,2,4,3])     = " + Arrays.toString(nextGreaterElement(a)));
        System.out.println("2. nextGreaterCircular([1,2,1])  = " + Arrays.toString(nextGreaterCircular(new int[]{1,2,1})));

        int[] temps = {73,74,75,71,69,72,76,73};
        System.out.println("3. dailyTemperatures             = " + Arrays.toString(dailyTemperatures(temps)));

        int[] heights = {2,1,5,6,2,3};
        System.out.println("4. largestRectangle([2,1,5,6,2,3]) = " + largestRectangleArea(heights));

        char[][] matrix = {{'1','0','1','0','0'},{'1','0','1','1','1'},{'1','1','1','1','1'},{'1','0','0','1','0'}};
        System.out.println("5. maximalRectangle             = " + maximalRectangle(matrix));

        int[] water = {0,1,0,2,1,0,1,3,2,1,2,1};
        System.out.println("6. trapRainWater                = " + trapRainWater(water));

        int[] prices = {100,80,60,70,60,75,85};
        System.out.println("7. stockSpan                    = " + Arrays.toString(stockSpan(prices)));

        System.out.println("8. removeKdigits(1432219,3)     = " + removeKdigits("1432219", 3));
    }
}
