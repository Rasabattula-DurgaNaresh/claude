/**
 * PATTERN 11: BINARY SEARCH
 * ==========================
 * Use when: sorted array, search space can be halved each step
 * Key insight: define search space, shrink by half each iteration
 *
 * Three templates:
 *   Classic:    while l <= r, check mid exactly
 *   Left bound: find first position satisfying condition
 *   Right bound: find last position satisfying condition
 *
 * "Binary search on answer": when answer has monotonic property
 *   (e.g., "can we do X with mid capacity?")
 *
 * Time: O(log n)  Space: O(1)
 */
import java.util.*;

public class BinarySearch {

    // 1. Classic binary search
    static int search(int[] nums, int target) {
        int l = 0, r = nums.length - 1;
        while (l <= r) {
            int mid = l + (r - l) / 2; // avoid overflow
            if (nums[mid] == target) return mid;
            if (nums[mid] < target) l = mid + 1; else r = mid - 1;
        }
        return -1;
    }

    // 2. First bad version (leftmost true)
    static int firstBadVersion(int n, int bad) {
        int l = 1, r = n;
        while (l < r) {
            int mid = l + (r - l) / 2;
            if (mid >= bad) r = mid;   // might be first bad
            else l = mid + 1;
        }
        return l;
    }

    // 3. Find first and last position of target
    static int[] searchRange(int[] nums, int target) {
        return new int[]{findFirst(nums, target), findLast(nums, target)};
    }
    static int findFirst(int[] nums, int target) {
        int l = 0, r = nums.length - 1, idx = -1;
        while (l <= r) {
            int mid = l + (r - l) / 2;
            if (nums[mid] == target) { idx = mid; r = mid - 1; } // keep going left
            else if (nums[mid] < target) l = mid + 1; else r = mid - 1;
        }
        return idx;
    }
    static int findLast(int[] nums, int target) {
        int l = 0, r = nums.length - 1, idx = -1;
        while (l <= r) {
            int mid = l + (r - l) / 2;
            if (nums[mid] == target) { idx = mid; l = mid + 1; } // keep going right
            else if (nums[mid] < target) l = mid + 1; else r = mid - 1;
        }
        return idx;
    }

    // 4. Search in rotated sorted array
    static int searchRotated(int[] nums, int target) {
        int l = 0, r = nums.length - 1;
        while (l <= r) {
            int mid = l + (r - l) / 2;
            if (nums[mid] == target) return mid;
            if (nums[l] <= nums[mid]) { // left half sorted
                if (target >= nums[l] && target < nums[mid]) r = mid - 1;
                else l = mid + 1;
            } else { // right half sorted
                if (target > nums[mid] && target <= nums[r]) l = mid + 1;
                else r = mid - 1;
            }
        }
        return -1;
    }

    // 5. Find minimum in rotated sorted array
    static int findMin(int[] nums) {
        int l = 0, r = nums.length - 1;
        while (l < r) {
            int mid = l + (r - l) / 2;
            if (nums[mid] > nums[r]) l = mid + 1; // min is in right half
            else r = mid; // min is in left half including mid
        }
        return nums[l];
    }

    // 6. Find peak element
    static int findPeakElement(int[] nums) {
        int l = 0, r = nums.length - 1;
        while (l < r) {
            int mid = l + (r - l) / 2;
            if (nums[mid] > nums[mid + 1]) r = mid; // peak on left side
            else l = mid + 1; // peak on right side
        }
        return l;
    }

    // 7. Sqrt(x) — integer square root
    static int mySqrt(int x) {
        if (x < 2) return x;
        int l = 1, r = x / 2;
        while (l <= r) {
            long mid = l + (r - l) / 2;
            if (mid * mid == x) return (int) mid;
            if (mid * mid < x) l = (int) mid + 1; else r = (int) mid - 1;
        }
        return r; // floor
    }

    // 8. Koko eating bananas — binary search on answer
    static int minEatingSpeed(int[] piles, int h) {
        int l = 1, r = Arrays.stream(piles).max().getAsInt();
        while (l < r) {
            int mid = l + (r - l) / 2;
            long hours = 0;
            for (int p : piles) hours += (p + mid - 1) / mid; // ceil(p/mid)
            if (hours <= h) r = mid; else l = mid + 1;
        }
        return l;
    }

    // 9. Ship packages within D days — binary search on answer
    static int shipWithinDays(int[] weights, int days) {
        int l = Arrays.stream(weights).max().getAsInt(); // min capacity = heaviest
        int r = Arrays.stream(weights).sum();            // max capacity = all in one day
        while (l < r) {
            int mid = l + (r - l) / 2;
            int daysNeeded = 1, curLoad = 0;
            for (int w : weights) {
                if (curLoad + w > mid) { daysNeeded++; curLoad = 0; }
                curLoad += w;
            }
            if (daysNeeded <= days) r = mid; else l = mid + 1;
        }
        return l;
    }

    // 10. Median of two sorted arrays — O(log(min(m,n)))
    static double findMedianSortedArrays(int[] A, int[] B) {
        if (A.length > B.length) return findMedianSortedArrays(B, A); // ensure A is smaller
        int m = A.length, n = B.length;
        int l = 0, r = m;
        while (l <= r) {
            int partA = l + (r - l) / 2;
            int partB = (m + n + 1) / 2 - partA;
            int maxLeftA  = partA == 0 ? Integer.MIN_VALUE : A[partA - 1];
            int minRightA = partA == m ? Integer.MAX_VALUE : A[partA];
            int maxLeftB  = partB == 0 ? Integer.MIN_VALUE : B[partB - 1];
            int minRightB = partB == n ? Integer.MAX_VALUE : B[partB];
            if (maxLeftA <= minRightB && maxLeftB <= minRightA) {
                if ((m + n) % 2 == 0) return (Math.max(maxLeftA,maxLeftB) + Math.min(minRightA,minRightB)) / 2.0;
                return Math.max(maxLeftA, maxLeftB);
            } else if (maxLeftA > minRightB) r = partA - 1;
            else l = partA + 1;
        }
        return -1;
    }

    public static void main(String[] args) {
        System.out.println("===== BINARY SEARCH PATTERN =====\n");

        int[] sorted = {-1,0,3,5,9,12};
        System.out.println("1. search(9)  = " + search(sorted, 9));
        System.out.println("   search(2)  = " + search(sorted, 2));
        System.out.println("2. firstBad(n=5, bad=4) = " + firstBadVersion(5, 4));

        int[] range = {5,7,7,8,8,10};
        System.out.println("3. searchRange([5,7,7,8,8,10], 8) = " + Arrays.toString(searchRange(range, 8)));

        int[] rotated = {4,5,6,7,0,1,2};
        System.out.println("4. searchRotated(0) = " + searchRotated(rotated, 0));
        System.out.println("5. findMin([3,4,5,1,2]) = " + findMin(new int[]{3,4,5,1,2}));
        System.out.println("6. findPeakElement([1,2,3,1]) = " + findPeakElement(new int[]{1,2,3,1}));
        System.out.println("7. mySqrt(8) = " + mySqrt(8));

        int[] piles = {3,6,7,11};
        System.out.println("8. minEatingSpeed(h=8) = " + minEatingSpeed(piles, 8));

        int[] weights = {1,2,3,4,5,6,7,8,9,10};
        System.out.println("9. shipWithinDays(days=5) = " + shipWithinDays(weights, 5));

        System.out.println("10.medianSortedArrays([1,3],[2]) = " + findMedianSortedArrays(new int[]{1,3}, new int[]{2}));
        System.out.println("   medianSortedArrays([1,2],[3,4]) = " + findMedianSortedArrays(new int[]{1,2}, new int[]{3,4}));
    }
}
