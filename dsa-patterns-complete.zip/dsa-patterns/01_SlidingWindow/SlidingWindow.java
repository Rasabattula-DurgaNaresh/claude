/**
 * PATTERN 01: SLIDING WINDOW
 * ===========================
 * Use when: contiguous subarray/substring problems
 * Key insight: avoid recomputing overlapping work by sliding a window
 *
 * Types:
 *   Fixed size window  : window size k is given
 *   Variable size window: find smallest/largest window satisfying condition
 *
 * Template:
 *   int left = 0;
 *   for (int right = 0; right < n; right++) {
 *       // expand window: add nums[right]
 *       while (window invalid) { // shrink
 *           // remove nums[left]; left++;
 *       }
 *       // update answer
 *   }
 *
 * Time: O(n)  Space: O(1) or O(k)
 */
import java.util.*;

public class SlidingWindow {

    // ─────────────────────────────────────────────────────────────
    // FIXED SIZE WINDOW
    // ─────────────────────────────────────────────────────────────

    // 1. Maximum sum of subarray of size k
    static int maxSumSubarray(int[] nums, int k) {
        int sum = 0;
        for (int i = 0; i < k; i++) sum += nums[i];
        int max = sum;
        for (int i = k; i < nums.length; i++) {
            sum += nums[i] - nums[i - k];
            max = Math.max(max, sum);
        }
        return max;
    }

    // 2. Maximum of each window of size k  (Deque approach)
    static int[] maxSlidingWindow(int[] nums, int k) {
        int n = nums.length;
        int[] result = new int[n - k + 1];
        Deque<Integer> dq = new ArrayDeque<>(); // stores indices, front = max
        for (int i = 0; i < n; i++) {
            // remove elements outside window
            while (!dq.isEmpty() && dq.peekFirst() < i - k + 1) dq.pollFirst();
            // remove smaller elements (they'll never be max)
            while (!dq.isEmpty() && nums[dq.peekLast()] < nums[i]) dq.pollLast();
            dq.offerLast(i);
            if (i >= k - 1) result[i - k + 1] = nums[dq.peekFirst()];
        }
        return result;
    }

    // 3. Average of all subarrays of size k
    static double[] avgSubarray(int[] nums, int k) {
        double[] result = new double[nums.length - k + 1];
        double sum = 0;
        for (int i = 0; i < k; i++) sum += nums[i];
        result[0] = sum / k;
        for (int i = k; i < nums.length; i++) {
            sum += nums[i] - nums[i - k];
            result[i - k + 1] = sum / k;
        }
        return result;
    }

    // ─────────────────────────────────────────────────────────────
    // VARIABLE SIZE WINDOW
    // ─────────────────────────────────────────────────────────────

    // 4. Longest substring without repeating characters
    static int lengthOfLongestSubstring(String s) {
        Map<Character, Integer> lastSeen = new HashMap<>();
        int left = 0, maxLen = 0;
        for (int right = 0; right < s.length(); right++) {
            char c = s.charAt(right);
            if (lastSeen.containsKey(c) && lastSeen.get(c) >= left)
                left = lastSeen.get(c) + 1;
            lastSeen.put(c, right);
            maxLen = Math.max(maxLen, right - left + 1);
        }
        return maxLen;
    }

    // 5. Longest substring with at most K distinct characters
    static int longestSubstringKDistinct(String s, int k) {
        Map<Character, Integer> freq = new HashMap<>();
        int left = 0, maxLen = 0;
        for (int right = 0; right < s.length(); right++) {
            freq.merge(s.charAt(right), 1, Integer::sum);
            while (freq.size() > k) {
                char lc = s.charAt(left++);
                freq.merge(lc, -1, Integer::sum);
                if (freq.get(lc) == 0) freq.remove(lc);
            }
            maxLen = Math.max(maxLen, right - left + 1);
        }
        return maxLen;
    }

    // 6. Minimum window substring containing all chars of t
    static String minWindowSubstring(String s, String t) {
        Map<Character, Integer> need = new HashMap<>();
        for (char c : t.toCharArray()) need.merge(c, 1, Integer::sum);
        int left = 0, have = 0, required = need.size();
        int minLen = Integer.MAX_VALUE, minStart = 0;
        Map<Character, Integer> window = new HashMap<>();
        for (int right = 0; right < s.length(); right++) {
            char c = s.charAt(right);
            window.merge(c, 1, Integer::sum);
            if (need.containsKey(c) && window.get(c).equals(need.get(c))) have++;
            while (have == required) {
                if (right - left + 1 < minLen) { minLen = right - left + 1; minStart = left; }
                char lc = s.charAt(left++);
                window.merge(lc, -1, Integer::sum);
                if (need.containsKey(lc) && window.get(lc) < need.get(lc)) have--;
            }
        }
        return minLen == Integer.MAX_VALUE ? "" : s.substring(minStart, minStart + minLen);
    }

    // 7. Longest subarray with sum <= k
    static int longestSubarraySumK(int[] nums, int k) {
        int left = 0, sum = 0, maxLen = 0;
        for (int right = 0; right < nums.length; right++) {
            sum += nums[right];
            while (sum > k) sum -= nums[left++];
            maxLen = Math.max(maxLen, right - left + 1);
        }
        return maxLen;
    }

    // 8. Number of subarrays with product < k
    static int numSubarrayProductLessThanK(int[] nums, int k) {
        if (k <= 1) return 0;
        int left = 0, product = 1, count = 0;
        for (int right = 0; right < nums.length; right++) {
            product *= nums[right];
            while (product >= k) product /= nums[left++];
            count += right - left + 1; // all subarrays ending at right
        }
        return count;
    }

    // 9. Longest repeating character replacement (at most k replacements)
    static int characterReplacement(String s, int k) {
        int[] freq = new int[26];
        int left = 0, maxFreq = 0, maxLen = 0;
        for (int right = 0; right < s.length(); right++) {
            freq[s.charAt(right) - 'A']++;
            maxFreq = Math.max(maxFreq, freq[s.charAt(right) - 'A']);
            // window invalid: (windowSize - maxFreq) > k
            if (right - left + 1 - maxFreq > k) {
                freq[s.charAt(left++) - 'A']--;
            }
            maxLen = Math.max(maxLen, right - left + 1);
        }
        return maxLen;
    }

    // 10. Find all anagrams in a string
    static List<Integer> findAnagrams(String s, String p) {
        List<Integer> result = new ArrayList<>();
        if (s.length() < p.length()) return result;
        int[] pCount = new int[26], sCount = new int[26];
        for (char c : p.toCharArray()) pCount[c - 'a']++;
        for (int i = 0; i < p.length(); i++) sCount[s.charAt(i) - 'a']++;
        if (Arrays.equals(pCount, sCount)) result.add(0);
        for (int i = p.length(); i < s.length(); i++) {
            sCount[s.charAt(i) - 'a']++;
            sCount[s.charAt(i - p.length()) - 'a']--;
            if (Arrays.equals(pCount, sCount)) result.add(i - p.length() + 1);
        }
        return result;
    }

    public static void main(String[] args) {
        System.out.println("===== SLIDING WINDOW PATTERN =====\n");

        int[] a = {2,1,5,1,3,2};
        System.out.println("1. maxSumSubarray([2,1,5,1,3,2], k=3) = " + maxSumSubarray(a, 3));

        int[] b = {1,3,-1,-3,5,3,6,7};
        System.out.println("2. maxSlidingWindow([1,3,-1,-3,5,3,6,7], k=3) = " + Arrays.toString(maxSlidingWindow(b, 3)));

        int[] c = {1,3,2,6,-1,4,1,8,2};
        System.out.println("3. avgSubarray([1,3,2,6,-1,4,1,8,2], k=5) = " + Arrays.toString(avgSubarray(c, 5)));

        System.out.println("4. longestSubstring(\"abcabcbb\") = " + lengthOfLongestSubstring("abcabcbb"));
        System.out.println("5. longestKDistinct(\"araaci\", k=2) = " + longestSubstringKDistinct("araaci", 2));
        System.out.println("6. minWindowSubstring(\"ADOBECODEBANC\",\"ABC\") = " + minWindowSubstring("ADOBECODEBANC","ABC"));

        int[] d = {1,2,3,4,5};
        System.out.println("7. longestSubarraySumK(k=7) = " + longestSubarraySumK(d, 7));

        int[] e = {10,5,2,6};
        System.out.println("8. productLessThan100 = " + numSubarrayProductLessThanK(e, 100));

        System.out.println("9. characterReplacement(\"AABABBA\", k=1) = " + characterReplacement("AABABBA", 1));
        System.out.println("10.findAnagrams(\"cbaebabacd\",\"abc\") = " + findAnagrams("cbaebabacd", "abc"));
    }
}
