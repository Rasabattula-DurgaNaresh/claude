/**
 * PATTERN 12: BITWISE XOR
 * ========================
 * Use when: find single element, missing number, pairs
 * Key XOR properties:
 *   a ^ 0 = a           (identity)
 *   a ^ a = 0           (self-inverse)
 *   a ^ b ^ a = b       (commutative + associative)
 *   XOR all: duplicates cancel, unique remains
 *
 * Time: O(n)  Space: O(1)
 */
import java.util.*;

public class BitwiseXOR {

    // 1. Single number — every other appears twice
    static int singleNumber(int[] nums) {
        int result = 0;
        for (int n : nums) result ^= n;
        return result;
    }

    // 2. Single number II — every other appears three times
    static int singleNumberII(int[] nums) {
        int ones = 0, twos = 0;
        for (int n : nums) {
            ones = (ones ^ n) & ~twos;
            twos = (twos ^ n) & ~ones;
        }
        return ones;
    }

    // 3. Two single numbers — two numbers appear once, others twice
    static int[] singleNumberIII(int[] nums) {
        int xor = 0;
        for (int n : nums) xor ^= n; // xor of the two uniques
        int diffBit = xor & (-xor);  // rightmost set bit (differs between the two)
        int a = 0, b = 0;
        for (int n : nums) {
            if ((n & diffBit) != 0) a ^= n;
            else                    b ^= n;
        }
        return new int[]{a, b};
    }

    // 4. Missing number [0..n]
    static int missingNumber(int[] nums) {
        int result = nums.length; // XOR with n
        for (int i = 0; i < nums.length; i++) result ^= i ^ nums[i];
        return result;
    }

    // 5. Flip and complement of base-10 integer
    // For a given number, flip all bits in its binary representation
    static int bitwiseComplement(int n) {
        if (n == 0) return 1;
        int bit = 1;
        while (bit <= n) bit <<= 1;
        return (bit - 1) ^ n; // mask of same length XOR n
    }

    // 6. Find XOR from L to R efficiently
    // XOR(1 to n):
    //   n%4==0: n
    //   n%4==1: 1
    //   n%4==2: n+1
    //   n%4==3: 0
    static int xorRange(int l, int r) {
        return xorTo(r) ^ xorTo(l - 1);
    }
    static int xorTo(int n) {
        if (n < 0) return 0;
        switch (n % 4) {
            case 0: return n;
            case 1: return 1;
            case 2: return n + 1;
            default: return 0;
        }
    }

    // 7. Swap without temp using XOR
    static int[] swapXOR(int a, int b) {
        a ^= b; b ^= a; a ^= b;
        return new int[]{a, b};
    }

    // 8. Check if power of 2
    static boolean isPowerOfTwo(int n) {
        return n > 0 && (n & (n - 1)) == 0;
    }

    // 9. Count set bits (Hamming weight)
    static int hammingWeight(int n) {
        int count = 0;
        while (n != 0) { count += n & 1; n >>>= 1; }
        return count;
        // Alternative: Integer.bitCount(n)
    }

    // 10. Hamming distance between two integers
    static int hammingDistance(int x, int y) {
        return Integer.bitCount(x ^ y);
    }

    // 11. Reverse bits of 32-bit unsigned integer
    static int reverseBits(int n) {
        int result = 0;
        for (int i = 0; i < 32; i++) {
            result = (result << 1) | (n & 1);
            n >>>= 1;
        }
        return result;
    }

    // 12. Find all numbers from 1 to 2^n XOR'd with position
    static int[] encode(int n) {
        int size = 1 << n; // 2^n
        int[] result = new int[size];
        for (int i = 0; i < size; i++) result[i] = i ^ (i >> 1); // Gray code
        return result;
    }

    public static void main(String[] args) {
        System.out.println("===== BITWISE XOR PATTERN =====\n");

        System.out.println("1. singleNumber([2,2,1])             = " + singleNumber(new int[]{2,2,1}));
        System.out.println("2. singleNumberII([2,2,3,2])         = " + singleNumberII(new int[]{2,2,3,2}));
        System.out.println("3. singleNumberIII([1,2,1,3,2,5])   = " + Arrays.toString(singleNumberIII(new int[]{1,2,1,3,2,5})));
        System.out.println("4. missingNumber([3,0,1])            = " + missingNumber(new int[]{3,0,1}));
        System.out.println("5. bitwiseComplement(5=101)          = " + bitwiseComplement(5) + " (010=2)");
        System.out.println("6. xorRange(3,7)                     = " + xorRange(3, 7));
        System.out.println("7. swap(5,9)                         = " + Arrays.toString(swapXOR(5, 9)));
        System.out.println("8. isPowerOfTwo(16)                  = " + isPowerOfTwo(16));
        System.out.println("   isPowerOfTwo(13)                  = " + isPowerOfTwo(13));
        System.out.println("9. hammingWeight(11=1011)            = " + hammingWeight(11));
        System.out.println("10.hammingDistance(1,4)              = " + hammingDistance(1, 4));
        System.out.println("11.reverseBits(43261596)             = " + reverseBits(43261596));
        System.out.println("12.GrayCode(n=3)                     = " + Arrays.toString(encode(3)));

        // Useful bit tricks summary
        System.out.println("\n=== BIT TRICKS REFERENCE ===");
        System.out.println("n & 1        : check if odd");
        System.out.println("n & (n-1)    : clear lowest set bit / check power of 2");
        System.out.println("n | (1<<k)   : set k-th bit");
        System.out.println("n & ~(1<<k)  : clear k-th bit");
        System.out.println("n ^ (1<<k)   : toggle k-th bit");
        System.out.println("n >> 1       : divide by 2");
        System.out.println("n << 1       : multiply by 2");
        System.out.println("n & (-n)     : isolate lowest set bit");
    }
}
