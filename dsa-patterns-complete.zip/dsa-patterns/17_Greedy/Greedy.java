/**
 * PATTERN 17: GREEDY ALGORITHMS
 * ===============================
 * Use when: locally optimal choice leads to globally optimal solution
 * Key insight: no backtracking — make the best available choice at each step
 * Proof: exchange argument or staying-ahead argument
 *
 * Common greedy patterns:
 *   - Sort first, then greedily pick
 *   - Interval scheduling (sort by end time)
 *   - Huffman coding (min heap)
 *   - Jump game (track max reach)
 *
 * Time: O(n log n) with sorting, O(n) without
 */
import java.util.*;

public class Greedy {

    // 1. Activity selection — max non-overlapping intervals
    static int maxActivities(int[][] intervals) {
        Arrays.sort(intervals, (a, b) -> a[1] - b[1]); // sort by end time!
        int count = 1, end = intervals[0][1];
        for (int i = 1; i < intervals.length; i++)
            if (intervals[i][0] >= end) { count++; end = intervals[i][1]; }
        return count;
    }

    // 2. Jump Game I — can reach end?
    static boolean canJump(int[] nums) {
        int maxReach = 0;
        for (int i = 0; i < nums.length; i++) {
            if (i > maxReach) return false;
            maxReach = Math.max(maxReach, i + nums[i]);
        }
        return true;
    }

    // 3. Jump Game II — minimum jumps to reach end
    static int minJumps(int[] nums) {
        int jumps = 0, curEnd = 0, farthest = 0;
        for (int i = 0; i < nums.length - 1; i++) {
            farthest = Math.max(farthest, i + nums[i]);
            if (i == curEnd) { jumps++; curEnd = farthest; }
        }
        return jumps;
    }

    // 4. Gas station — circular route
    static int canCompleteCircuit(int[] gas, int[] cost) {
        int total = 0, tank = 0, start = 0;
        for (int i = 0; i < gas.length; i++) {
            tank += gas[i] - cost[i];
            total += gas[i] - cost[i];
            if (tank < 0) { start = i + 1; tank = 0; }
        }
        return total >= 0 ? start : -1;
    }

    // 5. Assign cookies — maximize content children
    static int findContentChildren(int[] greed, int[] size) {
        Arrays.sort(greed); Arrays.sort(size);
        int child = 0, cookie = 0;
        while (child < greed.length && cookie < size.length) {
            if (size[cookie] >= greed[child]) child++;
            cookie++;
        }
        return child;
    }

    // 6. Partition labels — partition so each letter in at most one part
    static List<Integer> partitionLabels(String s) {
        int[] last = new int[26];
        for (int i = 0; i < s.length(); i++) last[s.charAt(i)-'a'] = i;
        List<Integer> result = new ArrayList<>();
        int start = 0, end = 0;
        for (int i = 0; i < s.length(); i++) {
            end = Math.max(end, last[s.charAt(i)-'a']);
            if (i == end) { result.add(end - start + 1); start = i + 1; }
        }
        return result;
    }

    // 7. Boats to save people (each boat carries at most 2, weight <= limit)
    static int numRescueBoats(int[] people, int limit) {
        Arrays.sort(people);
        int l = 0, r = people.length - 1, boats = 0;
        while (l <= r) {
            if (people[l] + people[r] <= limit) l++;
            r--; boats++;
        }
        return boats;
    }

    // 8. Two city scheduling — send n people to city A, n to city B, minimize cost
    static int twoCitySchedCost(int[][] costs) {
        // Sort by (costA - costB): if positive, cheaper to send to B
        Arrays.sort(costs, (a, b) -> (a[0]-a[1]) - (b[0]-b[1]));
        int n = costs.length / 2, total = 0;
        for (int i = 0;   i < n; i++) total += costs[i][0];   // first half to A
        for (int i = n; i < 2*n; i++) total += costs[i][1];   // second half to B
        return total;
    }

    // 9. Minimum number of arrows to burst balloons
    static int findMinArrowShots(int[][] points) {
        Arrays.sort(points, (a, b) -> Integer.compare(a[1], b[1])); // sort by end
        int arrows = 1, end = points[0][1];
        for (int i = 1; i < points.length; i++)
            if (points[i][0] > end) { arrows++; end = points[i][1]; }
        return arrows;
    }

    // 10. Candy — kids rated higher than neighbor get more candy
    static int candy(int[] ratings) {
        int n = ratings.length;
        int[] candies = new int[n]; Arrays.fill(candies, 1);
        for (int i = 1; i < n; i++) if (ratings[i] > ratings[i-1]) candies[i] = candies[i-1]+1;
        for (int i = n-2; i >= 0; i--) if (ratings[i] > ratings[i+1]) candies[i] = Math.max(candies[i], candies[i+1]+1);
        int sum = 0; for (int c : candies) sum += c;
        return sum;
    }

    public static void main(String[] args) {
        System.out.println("===== GREEDY PATTERN =====\n");

        int[][] intervals = {{1,4},{3,5},{0,6},{5,7},{3,9},{5,9},{6,10},{8,11},{8,12},{2,14},{12,16}};
        System.out.println("1.  maxActivities = " + maxActivities(intervals));
        System.out.println("2.  canJump([2,3,1,1,4]) = " + canJump(new int[]{2,3,1,1,4}));
        System.out.println("    canJump([3,2,1,0,4]) = " + canJump(new int[]{3,2,1,0,4}));
        System.out.println("3.  minJumps([2,3,1,1,4]) = " + minJumps(new int[]{2,3,1,1,4}));
        System.out.println("4.  gasStation([1,2,3,4,5],[3,4,5,1,2]) = " + canCompleteCircuit(new int[]{1,2,3,4,5},new int[]{3,4,5,1,2}));
        System.out.println("5.  cookies([1,2,3],[1,1]) = " + findContentChildren(new int[]{1,2,3},new int[]{1,1}));
        System.out.println("6.  partitionLabels(ababcbacadefegdehijhklij) = " + partitionLabels("ababcbacadefegdehijhklij"));
        System.out.println("7.  rescueBoats([3,5,3,4],5) = " + numRescueBoats(new int[]{3,5,3,4},5));
        System.out.println("8.  twoCityCost = " + twoCitySchedCost(new int[][]{{10,20},{30,200},{400,50},{30,20}}));
        System.out.println("9.  minArrows = " + findMinArrowShots(new int[][]{{10,16},{2,8},{1,6},{7,12}}));
        System.out.println("10. candy([1,0,2]) = " + candy(new int[]{1,0,2}));
    }
}
