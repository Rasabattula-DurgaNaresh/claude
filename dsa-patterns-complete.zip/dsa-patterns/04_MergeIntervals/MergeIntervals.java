/**
 * PATTERN 04: MERGE INTERVALS
 * ============================
 * Use when: overlapping intervals, scheduling, range problems
 * Key insight: sort by start time, then merge greedily
 *
 * Overlap condition: a.start <= b.end (after sorting by start)
 * Merge: [a.start, max(a.end, b.end)]
 *
 * Time: O(n log n)  Space: O(n)
 */
import java.util.*;

public class MergeIntervals {

    // 1. Merge overlapping intervals
    static int[][] merge(int[][] intervals) {
        if (intervals.length <= 1) return intervals;
        Arrays.sort(intervals, (a, b) -> a[0] - b[0]);
        List<int[]> merged = new ArrayList<>();
        int[] cur = intervals[0];
        for (int i = 1; i < intervals.length; i++) {
            if (intervals[i][0] <= cur[1])           // overlap
                cur[1] = Math.max(cur[1], intervals[i][1]);
            else { merged.add(cur); cur = intervals[i]; }
        }
        merged.add(cur);
        return merged.toArray(new int[0][]);
    }

    // 2. Insert interval into sorted non-overlapping list
    static int[][] insert(int[][] intervals, int[] newInterval) {
        List<int[]> result = new ArrayList<>();
        int i = 0, n = intervals.length;
        // Add all intervals that end before newInterval starts
        while (i < n && intervals[i][1] < newInterval[0]) result.add(intervals[i++]);
        // Merge overlapping
        while (i < n && intervals[i][0] <= newInterval[1]) {
            newInterval[0] = Math.min(newInterval[0], intervals[i][0]);
            newInterval[1] = Math.max(newInterval[1], intervals[i][1]);
            i++;
        }
        result.add(newInterval);
        // Add remaining
        while (i < n) result.add(intervals[i++]);
        return result.toArray(new int[0][]);
    }

    // 3. Meeting rooms I — can attend all? (no overlaps)
    static boolean canAttendMeetings(int[][] intervals) {
        Arrays.sort(intervals, (a, b) -> a[0] - b[0]);
        for (int i = 1; i < intervals.length; i++)
            if (intervals[i][0] < intervals[i - 1][1]) return false;
        return true;
    }

    // 4. Meeting rooms II — min conference rooms needed
    static int minMeetingRooms(int[][] intervals) {
        int[] starts = new int[intervals.length], ends = new int[intervals.length];
        for (int i = 0; i < intervals.length; i++) { starts[i]=intervals[i][0]; ends[i]=intervals[i][1]; }
        Arrays.sort(starts); Arrays.sort(ends);
        int rooms = 0, endPtr = 0;
        for (int start : starts) {
            if (start < ends[endPtr]) rooms++;
            else endPtr++;
        }
        return rooms;
    }

    // 5. Interval list intersections
    static int[][] intervalIntersection(int[][] A, int[][] B) {
        List<int[]> result = new ArrayList<>();
        int i = 0, j = 0;
        while (i < A.length && j < B.length) {
            int lo = Math.max(A[i][0], B[j][0]);
            int hi = Math.min(A[i][1], B[j][1]);
            if (lo <= hi) result.add(new int[]{lo, hi});
            if (A[i][1] < B[j][1]) i++; else j++;
        }
        return result.toArray(new int[0][]);
    }

    // 6. Non-overlapping intervals — min removals to make non-overlapping
    static int eraseOverlapIntervals(int[][] intervals) {
        if (intervals.length == 0) return 0;
        Arrays.sort(intervals, (a, b) -> a[1] - b[1]); // sort by end!
        int count = 0, end = intervals[0][1];
        for (int i = 1; i < intervals.length; i++) {
            if (intervals[i][0] < end) count++; // overlap → remove
            else end = intervals[i][1];
        }
        return count;
    }

    // 7. Employee free time — find free slots across all employees
    static List<int[]> employeeFreeTime(List<List<int[]>> schedule) {
        List<int[]> all = new ArrayList<>();
        for (List<int[]> emp : schedule) all.addAll(emp);
        all.sort((a, b) -> a[0] - b[0]);
        List<int[]> free = new ArrayList<>();
        int end = all.get(0)[1];
        for (int[] iv : all) {
            if (iv[0] > end) free.add(new int[]{end, iv[0]});
            end = Math.max(end, iv[1]);
        }
        return free;
    }

    static String fmt(int[][] arr) {
        StringBuilder sb = new StringBuilder("[");
        for (int[] a : arr) sb.append(Arrays.toString(a));
        return sb.append("]").toString();
    }

    public static void main(String[] args) {
        System.out.println("===== MERGE INTERVALS PATTERN =====\n");

        int[][] a = {{1,3},{2,6},{8,10},{15,18}};
        System.out.println("1. merge([[1,3],[2,6],[8,10],[15,18]]) = " + fmt(merge(a)));

        int[][] b = {{1,3},{6,9}};
        System.out.println("2. insert([1,3],[6,9] + [2,5]) = " + fmt(insert(b, new int[]{2,5})));

        int[][] meetings = {{0,30},{5,10},{15,20}};
        System.out.println("3. canAttendMeetings = " + canAttendMeetings(meetings));

        int[][] rooms = {{0,30},{5,10},{15,20}};
        System.out.println("4. minMeetingRooms = " + minMeetingRooms(rooms));

        int[][] A = {{0,2},{5,10},{13,23},{24,25}};
        int[][] B = {{1,5},{8,12},{15,24},{25,26}};
        System.out.println("5. intervalIntersection = " + fmt(intervalIntersection(A, B)));

        int[][] c = {{1,2},{2,3},{3,4},{1,3}};
        System.out.println("6. eraseOverlapIntervals = " + eraseOverlapIntervals(c));

        List<List<int[]>> sched = Arrays.asList(
            Arrays.asList(new int[]{1,3}, new int[]{6,7}),
            Arrays.asList(new int[]{2,4}),
            Arrays.asList(new int[]{2,5}, new int[]{9,12})
        );
        System.out.println("7. employeeFreeTime = ");
        for (int[] slot : employeeFreeTime(sched)) System.out.println("   " + Arrays.toString(slot));
    }
}
