/**
 * PATTERN 19: PREFIX SUM
 * =======================
 * Use when: range sum queries, subarray sum equals k, 2D range sums
 * Key insight: prefix[i] = sum of first i elements
 *              rangeSum(l,r) = prefix[r+1] - prefix[l]
 *
 * With HashMap: subarray sum = k → use prefix sum with hashmap
 *   count subarrays where prefix[j] - prefix[i] = k
 *   → prefix[i] = prefix[j] - k
 *
 * Time: O(n) build, O(1) query
 */
import java.util.*;

public class PrefixSum {

    // 1. Range sum query — immutable
    static class NumArray {
        int[] prefix;
        NumArray(int[] nums) {
            prefix = new int[nums.length + 1];
            for (int i = 0; i < nums.length; i++) prefix[i+1] = prefix[i] + nums[i];
        }
        int sumRange(int l, int r) { return prefix[r+1] - prefix[l]; }
    }

    // 2. Subarray sum equals k — count subarrays
    static int subarraySum(int[] nums, int k) {
        Map<Integer, Integer> countMap = new HashMap<>();
        countMap.put(0, 1); // empty prefix
        int count = 0, prefixSum = 0;
        for (int n : nums) {
            prefixSum += n;
            count += countMap.getOrDefault(prefixSum - k, 0);
            countMap.merge(prefixSum, 1, Integer::sum);
        }
        return count;
    }

    // 3. Continuous subarray sum (multiple of k)
    static boolean checkSubarraySum(int[] nums, int k) {
        Map<Integer, Integer> map = new HashMap<>();
        map.put(0, -1); // remainder 0 seen before index 0
        int sum = 0;
        for (int i = 0; i < nums.length; i++) {
            sum = (sum + nums[i]) % k;
            if (map.containsKey(sum)) {
                if (i - map.get(sum) >= 2) return true;
            } else map.put(sum, i);
        }
        return false;
    }

    // 4. Longest subarray with sum = 0
    static int longestSubarraySumZero(int[] nums) {
        Map<Integer, Integer> firstSeen = new HashMap<>();
        firstSeen.put(0, -1);
        int prefixSum = 0, maxLen = 0;
        for (int i = 0; i < nums.length; i++) {
            prefixSum += nums[i];
            if (firstSeen.containsKey(prefixSum)) maxLen = Math.max(maxLen, i - firstSeen.get(prefixSum));
            else firstSeen.put(prefixSum, i);
        }
        return maxLen;
    }

    // 5. Number of subarrays with even sum
    static int numSubarraysWithEvenSum(int[] nums) {
        int even = 1, odd = 0, prefix = 0, count = 0;
        for (int n : nums) {
            prefix += n;
            if (prefix % 2 == 0) { count += even; even++; }
            else                  { count += odd;  odd++;  }
        }
        return count;
    }

    // 6. 2D prefix sum — range sum in matrix
    static class NumMatrix {
        int[][] prefix;
        NumMatrix(int[][] matrix) {
            int m = matrix.length, n = matrix[0].length;
            prefix = new int[m+1][n+1];
            for (int i = 1; i <= m; i++)
                for (int j = 1; j <= n; j++)
                    prefix[i][j] = matrix[i-1][j-1] + prefix[i-1][j] + prefix[i][j-1] - prefix[i-1][j-1];
        }
        int sumRegion(int r1, int c1, int r2, int c2) {
            return prefix[r2+1][c2+1] - prefix[r1][c2+1] - prefix[r2+1][c1] + prefix[r1][c1];
        }
    }

    // 7. Product of array except self (using prefix and suffix products)
    static int[] productExceptSelf(int[] nums) {
        int n = nums.length;
        int[] result = new int[n];
        result[0] = 1;
        for (int i = 1; i < n; i++) result[i] = result[i-1] * nums[i-1]; // prefix product
        int suffix = 1;
        for (int i = n-1; i >= 0; i--) { result[i] *= suffix; suffix *= nums[i]; }
        return result;
    }

    // 8. Pivot index — left sum == right sum
    static int pivotIndex(int[] nums) {
        int total = 0; for (int n : nums) total += n;
        int leftSum = 0;
        for (int i = 0; i < nums.length; i++) {
            if (leftSum == total - leftSum - nums[i]) return i;
            leftSum += nums[i];
        }
        return -1;
    }

    // 9. Find max length subarray with equal 0s and 1s
    static int findMaxLengthEqualZeroOne(int[] nums) {
        // Replace 0 with -1, then find longest subarray with sum 0
        int[] modified = Arrays.copyOf(nums, nums.length);
        for (int i = 0; i < modified.length; i++) if (modified[i] == 0) modified[i] = -1;
        return longestSubarraySumZero(modified);
    }

    // 10. Count subarrays with k odd numbers
    static int numberOfSubarrays(int[] nums, int k) {
        Map<Integer, Integer> map = new HashMap<>();
        map.put(0, 1);
        int oddCount = 0, result = 0;
        for (int n : nums) {
            if (n % 2 == 1) oddCount++;
            result += map.getOrDefault(oddCount - k, 0);
            map.merge(oddCount, 1, Integer::sum);
        }
        return result;
    }

    public static void main(String[] args) {
        System.out.println("===== PREFIX SUM PATTERN =====\n");

        int[] a = {-2,0,3,-5,2,-1};
        NumArray na = new NumArray(a);
        System.out.println("1. sumRange(0,2)=" + na.sumRange(0,2) + " sumRange(2,5)=" + na.sumRange(2,5));

        int[] b = {1,1,1};
        System.out.println("2. subarraySum([1,1,1], k=2) = " + subarraySum(b, 2));

        int[] c = {23,2,4,6,7};
        System.out.println("3. checkSubarraySum(k=6) = " + checkSubarraySum(c, 6));

        int[] d = {15,-2,2,-8,1,7,10,23};
        System.out.println("4. longestSubarraySumZero = " + longestSubarraySumZero(d));

        int[] e = {1,2,3,4};
        System.out.println("5. numSubarraysEvenSum = " + numSubarraysWithEvenSum(e));

        int[][] matrix = {{3,0,1,4,2},{5,6,3,2,1},{1,2,0,1,5},{4,1,0,1,7},{1,0,3,0,5}};
        NumMatrix nm = new NumMatrix(matrix);
        System.out.println("6. sumRegion(2,1,4,3) = " + nm.sumRegion(2,1,4,3));

        int[] f = {1,2,3,4,5};
        System.out.println("7. productExceptSelf = " + Arrays.toString(productExceptSelf(f)));

        int[] g = {1,7,3,6,5,6};
        System.out.println("8. pivotIndex = " + pivotIndex(g));

        int[] h = {0,1,0,0,1,0,1,1,0};
        System.out.println("9. maxLengthEqual01 = " + findMaxLengthEqualZeroOne(h));

        int[] j = {1,1,2,1,1};
        System.out.println("10.subarraysWithKOdds(k=3) = " + numberOfSubarrays(j, 3));
    }
}
