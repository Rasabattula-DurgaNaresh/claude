/**
 * PATTERN 06: IN-PLACE REVERSAL OF LINKED LIST
 * ==============================================
 * Use when: reverse a linked list or portion of it
 * Key insight: change .next pointers iteratively using 3 pointers
 *
 * Template (reverse full list):
 *   prev=null, cur=head
 *   while cur != null:
 *     next = cur.next
 *     cur.next = prev
 *     prev = cur
 *     cur = next
 *   return prev
 *
 * Time: O(n)  Space: O(1)
 */
import java.util.*;

public class InPlaceReversal {

    static class ListNode {
        int val; ListNode next;
        ListNode(int v) { val = v; }
        static ListNode of(int... vals) {
            ListNode dummy = new ListNode(0), cur = dummy;
            for (int v : vals) { cur.next = new ListNode(v); cur = cur.next; }
            return dummy.next;
        }
        static String str(ListNode h) {
            StringBuilder sb = new StringBuilder();
            while (h != null) { sb.append(h.val); if(h.next!=null) sb.append("->"); h=h.next; }
            return sb.toString();
        }
    }

    // 1. Reverse entire linked list
    static ListNode reverse(ListNode head) {
        ListNode prev = null, cur = head;
        while (cur != null) {
            ListNode next = cur.next;
            cur.next = prev;
            prev = cur;
            cur = next;
        }
        return prev;
    }

    // 2. Reverse sublist from position left to right (1-indexed)
    static ListNode reverseBetween(ListNode head, int left, int right) {
        ListNode dummy = new ListNode(0); dummy.next = head;
        ListNode prev = dummy;
        for (int i = 1; i < left; i++) prev = prev.next;
        ListNode cur = prev.next, tail = cur;
        ListNode reversePrev = null;
        for (int i = left; i <= right; i++) {
            ListNode next = cur.next; cur.next = reversePrev; reversePrev = cur; cur = next;
        }
        prev.next = reversePrev;
        tail.next = cur;
        return dummy.next;
    }

    // 3. Reverse every k nodes
    static ListNode reverseKGroup(ListNode head, int k) {
        ListNode cur = head;
        int count = 0;
        while (cur != null && count < k) { cur = cur.next; count++; }
        if (count < k) return head;
        // reverse k nodes
        ListNode prev = null, curr = head;
        for (int i = 0; i < k; i++) {
            ListNode next = curr.next; curr.next = prev; prev = curr; curr = next;
        }
        head.next = reverseKGroup(curr, k); // head is now tail of reversed group
        return prev;
    }

    // 4. Reverse alternating k nodes (reverse k, skip k, ...)
    static ListNode reverseAlternateKNodes(ListNode head, int k) {
        if (head == null) return null;
        ListNode prev = null, cur = head;
        // Reverse k nodes
        for (int i = 0; i < k && cur != null; i++) {
            ListNode next = cur.next; cur.next = prev; prev = cur; cur = next;
        }
        head.next = cur; // head is now last of reversed portion
        // Skip k nodes
        for (int i = 0; i < k && cur != null; i++) { head = cur; cur = cur.next; }
        head.next = reverseAlternateKNodes(cur, k);
        return prev;
    }

    // 5. Rotate list by k positions to the right
    static ListNode rotateRight(ListNode head, int k) {
        if (head == null || head.next == null) return head;
        int len = 1; ListNode tail = head;
        while (tail.next != null) { tail = tail.next; len++; }
        k %= len;
        if (k == 0) return head;
        tail.next = head; // make circular
        int stepsToNewTail = len - k;
        ListNode newTail = head;
        for (int i = 1; i < stepsToNewTail; i++) newTail = newTail.next;
        ListNode newHead = newTail.next;
        newTail.next = null;
        return newHead;
    }

    // 6. Check palindrome using in-place reversal
    static boolean isPalindrome(ListNode head) {
        ListNode slow = head, fast = head;
        while (fast != null && fast.next != null) { slow = slow.next; fast = fast.next.next; }
        ListNode secondHalf = reverse(slow);
        ListNode copy = secondHalf;
        boolean result = true;
        ListNode left = head;
        while (copy != null) { if (left.val != copy.val) { result = false; break; } left=left.next; copy=copy.next; }
        reverse(secondHalf); // restore
        return result;
    }

    // 7. Swap nodes in pairs
    static ListNode swapPairs(ListNode head) {
        ListNode dummy = new ListNode(0); dummy.next = head;
        ListNode prev = dummy;
        while (prev.next != null && prev.next.next != null) {
            ListNode a = prev.next, b = prev.next.next;
            prev.next = b; a.next = b.next; b.next = a;
            prev = a;
        }
        return dummy.next;
    }

    public static void main(String[] args) {
        System.out.println("===== IN-PLACE REVERSAL PATTERN =====\n");

        System.out.println("1. reverse([1->2->3->4->5]) = " + ListNode.str(reverse(ListNode.of(1,2,3,4,5))));
        System.out.println("2. reverseBetween([1..5], 2,4) = " + ListNode.str(reverseBetween(ListNode.of(1,2,3,4,5), 2, 4)));
        System.out.println("3. reverseKGroup([1..6], k=2) = " + ListNode.str(reverseKGroup(ListNode.of(1,2,3,4,5,6), 2)));
        System.out.println("4. reverseAlternateK([1..8], k=2) = " + ListNode.str(reverseAlternateKNodes(ListNode.of(1,2,3,4,5,6,7,8), 2)));
        System.out.println("5. rotateRight([1..5], k=2) = " + ListNode.str(rotateRight(ListNode.of(1,2,3,4,5), 2)));
        System.out.println("6. isPalindrome([1,2,2,1]) = " + isPalindrome(ListNode.of(1,2,2,1)));
        System.out.println("   isPalindrome([1,2,3])   = " + isPalindrome(ListNode.of(1,2,3)));
        System.out.println("7. swapPairs([1->2->3->4]) = " + ListNode.str(swapPairs(ListNode.of(1,2,3,4))));
    }
}
