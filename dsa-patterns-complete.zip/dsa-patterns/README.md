# DSA Patterns — Complete Java Reference
## 20 Patterns × Multiple Problems Each

---

## PATTERN INDEX

| # | Pattern | When to Use | Key Data Structure | Time |
|---|---------|------------|-------------------|------|
| 01 | **Sliding Window** | Contiguous subarray/substring | Two pointers + window state | O(n) |
| 02 | **Two Pointers** | Sorted array, pairs, partition | Two indices | O(n) |
| 03 | **Fast & Slow Pointers** | Cycle detection, middle, nth from end | Two pointers at different speeds | O(n) |
| 04 | **Merge Intervals** | Overlapping intervals, scheduling | Sort + greedy merge | O(n log n) |
| 05 | **Cyclic Sort** | Array with values [1..n] | In-place swap | O(n) |
| 06 | **In-Place Reversal** | Reverse linked list portions | Three pointers | O(n) |
| 07 | **BFS** | Level order, shortest path, islands | Queue | O(V+E) |
| 08 | **DFS** | All paths, cycle detection, topo sort | Stack/Recursion | O(V+E) |
| 09 | **Two Heaps** | Find median, partition data | maxHeap + minHeap | O(log n) |
| 10 | **Subsets** | Generate all subsets, permutations | BFS expansion / Backtrack | O(2^n) |
| 11 | **Binary Search** | Sorted array, search space halving | Two pointers | O(log n) |
| 12 | **Bitwise XOR** | Find unique, missing number, pairs | XOR properties | O(n) |
| 13 | **Top K Elements** | K largest/smallest/frequent | Min/Max Heap | O(n log k) |
| 14 | **K-Way Merge** | Merge k sorted lists/arrays | Min Heap | O(n log k) |
| 15 | **Dynamic Programming** | Optimal subproblems, overlapping | Array/2D array | varies |
| 16 | **Backtracking** | N-Queens, Sudoku, all solutions | Recursion + undo | O(k^n) |
| 17 | **Greedy** | Locally optimal = globally optimal | Sort + scan | O(n log n) |
| 18 | **Monotonic Stack** | Next greater/smaller, histogram | Stack (monotonic) | O(n) |
| 19 | **Prefix Sum** | Range queries, subarray sum = k | Array + HashMap | O(n) build |
| 20 | **Union-Find** | Connected components, cycle detect | Parent array | O(α(n)) |

---

## HOW TO RECOGNIZE PATTERNS

```
Contiguous subarray/substring   → Sliding Window
Sorted array + pairs            → Two Pointers
Linked list cycle/middle        → Fast & Slow Pointers
Overlapping intervals           → Merge Intervals
Array values = [1..n]           → Cyclic Sort
Reverse linked list in-place    → In-Place Reversal
Level-by-level / shortest path  → BFS
All paths / cycle / topo        → DFS
Find median / partition halves  → Two Heaps
Generate all combinations       → Subsets + Backtracking
Sorted search / yes-no answer   → Binary Search
Find unique / missing           → XOR
K largest/smallest/frequent     → Top K + Heap
Merge k sorted sources          → K-Way Merge
Optimal overlapping choices     → Dynamic Programming
Constraint satisfaction         → Backtracking
Locally greedy works            → Greedy
Next greater/smaller element    → Monotonic Stack
Range sum / subarray sum = k    → Prefix Sum
Groups / connectivity           → Union-Find
```

---

## COMPLEXITY QUICK REFERENCE

### Sorting Algorithms
| Algorithm | Best | Average | Worst | Space |
|-----------|------|---------|-------|-------|
| Bubble Sort | O(n) | O(n²) | O(n²) | O(1) |
| Selection Sort | O(n²) | O(n²) | O(n²) | O(1) |
| Insertion Sort | O(n) | O(n²) | O(n²) | O(1) |
| Merge Sort | O(n log n) | O(n log n) | O(n log n) | O(n) |
| Quick Sort | O(n log n) | O(n log n) | O(n²) | O(log n) |
| Heap Sort | O(n log n) | O(n log n) | O(n log n) | O(1) |
| Counting Sort | O(n+k) | O(n+k) | O(n+k) | O(k) |

### Data Structures
| Structure | Access | Search | Insert | Delete |
|-----------|--------|--------|--------|--------|
| Array | O(1) | O(n) | O(n) | O(n) |
| Stack | O(n) | O(n) | O(1) | O(1) |
| Queue | O(n) | O(n) | O(1) | O(1) |
| HashMap | O(1) | O(1) | O(1) | O(1) |
| TreeMap | O(log n) | O(log n) | O(log n) | O(log n) |
| BST | O(log n) | O(log n) | O(log n) | O(log n) |
| Heap (PQ) | O(1) peek | O(n) | O(log n) | O(log n) |

---

## BINARY SEARCH TEMPLATES

```java
// Template 1: Find exact match
int l = 0, r = n - 1;
while (l <= r) {
    int mid = l + (r - l) / 2;
    if (arr[mid] == target) return mid;
    if (arr[mid] < target) l = mid + 1; else r = mid - 1;
}

// Template 2: Find first true (leftmost)
int l = 0, r = n;
while (l < r) {
    int mid = l + (r - l) / 2;
    if (condition(mid)) r = mid; else l = mid + 1;
}
return l; // first index where condition is true

// Template 3: Binary search on answer
int l = minPossible, r = maxPossible;
while (l < r) {
    int mid = l + (r - l) / 2;
    if (canAchieve(mid)) r = mid; else l = mid + 1;
}
return l;
```

---

## DP DECISION FRAMEWORK

```
1. Can I make the choice at each step?
   YES → Greedy (if provably correct)

2. Does solution depend on previous subproblems?
   YES → Dynamic Programming

3. Do I need ALL solutions?
   YES → Backtracking

DP State definition:
  dp[i]       = answer for first i elements
  dp[i][j]    = answer using i items with capacity j
  dp[i][j]    = answer for substring s[i..j]

DP Transitions:
  Linear:   dp[i] = f(dp[i-1], dp[i-2], ...)
  Knapsack: dp[w] = max(dp[w], dp[w-weight]+value)
  String:   dp[i][j] = f(dp[i-1][j-1], dp[i][j-1], dp[i-1][j])
```

---

## GRAPH ALGORITHM CHEAT SHEET

```java
// BFS — shortest path, level order
Queue<Integer> q = new LinkedList<>();
boolean[] visited = new boolean[n];
q.offer(start); visited[start] = true;
while (!q.isEmpty()) {
    int cur = q.poll();
    for (int next : graph.get(cur))
        if (!visited[next]) { visited[next]=true; q.offer(next); }
}

// DFS — detect cycle, topo sort, all paths
void dfs(int node) {
    visited[node] = true;
    for (int next : graph.get(node))
        if (!visited[next]) dfs(next);
}

// Topological Sort (Kahn's Algorithm — BFS)
int[] indegree = new int[n];
Queue<Integer> q = new LinkedList<>();
for (int i = 0; i < n; i++) if (indegree[i] == 0) q.offer(i);
while (!q.isEmpty()) {
    int cur = q.poll();
    result.add(cur);
    for (int next : graph.get(cur))
        if (--indegree[next] == 0) q.offer(next);
}

// Dijkstra — shortest path (weighted)
PriorityQueue<int[]> pq = new PriorityQueue<>(Comparator.comparingInt(a->a[1]));
int[] dist = new int[n]; Arrays.fill(dist, Integer.MAX_VALUE);
dist[src] = 0; pq.offer(new int[]{src, 0});
while (!pq.isEmpty()) {
    int[] cur = pq.poll();
    for (int[] edge : graph.get(cur[0])) {
        int newDist = dist[cur[0]] + edge[1];
        if (newDist < dist[edge[0]]) { dist[edge[0]]=newDist; pq.offer(new int[]{edge[0],newDist}); }
    }
}
```

---

## TOP INTERVIEW PROBLEMS BY PATTERN

| Pattern | Must-Know Problems |
|---------|-------------------|
| Sliding Window | Max sum subarray k, Longest substring no repeat, Min window substring |
| Two Pointers | 3Sum, Container with most water, Trapping rain water |
| Fast/Slow | Linked list cycle, Find duplicate, Happy number |
| Merge Intervals | Merge intervals, Insert interval, Meeting rooms II |
| Binary Search | Search rotated, Find peak, Koko bananas, Ship packages |
| Top K | K closest points, Top K frequent, Task scheduler |
| DP | LIS, Edit distance, Knapsack, Coin change, Word break |
| Backtracking | N-Queens, Sudoku, Word search, Palindrome partitioning |
| Greedy | Jump game, Gas station, Candy, Partition labels |
| Union-Find | Number of islands, Redundant connection, Accounts merge |

---

*Study tip: master the template for each pattern, then practice variations.*
