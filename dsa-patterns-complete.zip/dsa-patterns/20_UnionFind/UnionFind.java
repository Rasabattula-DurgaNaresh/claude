/**
 * PATTERN 20: UNION-FIND (DISJOINT SET UNION)
 * ============================================
 * Use when: connected components, cycle detection in undirected graph,
 *           grouping elements, Kruskal's MST
 * Key insight: parent array tracks group membership
 *   find(): locate root (with path compression)
 *   union(): merge two groups (by rank for balance)
 *
 * Path compression + union by rank → nearly O(1) amortized (α(n))
 * Time: O(α(n)) per operation  Space: O(n)
 */
import java.util.*;

public class UnionFind {

    // Core Union-Find structure
    static class DSU {
        int[] parent, rank;
        int components;

        DSU(int n) {
            parent = new int[n]; rank = new int[n]; components = n;
            for (int i = 0; i < n; i++) parent[i] = i;
        }

        int find(int x) {
            if (parent[x] != x) parent[x] = find(parent[x]); // path compression
            return parent[x];
        }

        boolean union(int x, int y) {
            int px = find(x), py = find(y);
            if (px == py) return false; // already same component
            if (rank[px] < rank[py]) { int t=px; px=py; py=t; }
            parent[py] = px;
            if (rank[px] == rank[py]) rank[px]++;
            components--;
            return true;
        }

        boolean connected(int x, int y) { return find(x) == find(y); }
        int count() { return components; }
    }

    // 1. Number of connected components (undirected graph)
    static int countComponents(int n, int[][] edges) {
        DSU dsu = new DSU(n);
        for (int[] e : edges) dsu.union(e[0], e[1]);
        return dsu.count();
    }

    // 2. Number of islands (Union-Find approach)
    static int numIslands(char[][] grid) {
        if (grid == null || grid.length == 0) return 0;
        int rows = grid.length, cols = grid[0].length;
        DSU dsu = new DSU(rows * cols);
        int waterCells = 0;
        for (int r = 0; r < rows; r++) for (int c = 0; c < cols; c++) {
            if (grid[r][c] == '0') { waterCells++; continue; }
            int idx = r * cols + c;
            if (r+1 < rows && grid[r+1][c]=='1') dsu.union(idx, (r+1)*cols+c);
            if (c+1 < cols && grid[r][c+1]=='1') dsu.union(idx, r*cols+c+1);
        }
        return dsu.count() - waterCells;
    }

    // 3. Redundant connection (detect cycle, return extra edge)
    static int[] findRedundantConnection(int[][] edges) {
        DSU dsu = new DSU(edges.length + 1);
        for (int[] e : edges) if (!dsu.union(e[0], e[1])) return e;
        return new int[]{};
    }

    // 4. Accounts merge (group emails by same person)
    static List<List<String>> accountsMerge(List<List<String>> accounts) {
        Map<String, Integer> emailToId = new HashMap<>();
        int[] parent = new int[accounts.size()];
        for (int i = 0; i < parent.length; i++) parent[i] = i;

        java.util.function.Function<Integer, Integer> find = null;
        // Use array trick for recursive lambda
        int[][] parentRef = {parent};

        for (int i = 0; i < accounts.size(); i++) {
            for (int j = 1; j < accounts.get(i).size(); j++) {
                String email = accounts.get(i).get(j);
                if (!emailToId.containsKey(email)) { emailToId.put(email, i); continue; }
                // Union i with existing owner
                int a = i, b = emailToId.get(email);
                while (parent[a] != a) a = parent[a];
                while (parent[b] != b) b = parent[b];
                if (a != b) parent[a] = b;
            }
        }

        Map<Integer, TreeSet<String>> groups = new HashMap<>();
        for (Map.Entry<String, Integer> e : emailToId.entrySet()) {
            int id = e.getValue();
            while (parent[id] != id) id = parent[id];
            groups.computeIfAbsent(id, k -> new TreeSet<>()).add(e.getKey());
        }

        List<List<String>> result = new ArrayList<>();
        for (Map.Entry<Integer, TreeSet<String>> e : groups.entrySet()) {
            List<String> account = new ArrayList<>();
            account.add(accounts.get(e.getKey()).get(0)); // name
            account.addAll(e.getValue());
            result.add(account);
        }
        return result;
    }

    // 5. Satisfiability of equality equations (a==b, c!=d)
    static boolean equationsPossible(String[] equations) {
        DSU dsu = new DSU(26);
        // First pass: union all equalities
        for (String eq : equations) if (eq.charAt(1) == '=') dsu.union(eq.charAt(0)-'a', eq.charAt(3)-'a');
        // Second pass: check inequalities
        for (String eq : equations) if (eq.charAt(1) == '!') {
            if (dsu.connected(eq.charAt(0)-'a', eq.charAt(3)-'a')) return false;
        }
        return true;
    }

    // 6. Smallest string with swaps — reachable strings after k swaps
    static String smallestStringWithSwaps(String s, List<List<Integer>> pairs) {
        int n = s.length();
        DSU dsu = new DSU(n);
        for (List<Integer> p : pairs) dsu.union(p.get(0), p.get(1));
        Map<Integer, List<Integer>> groups = new HashMap<>();
        for (int i = 0; i < n; i++) groups.computeIfAbsent(dsu.find(i), k -> new ArrayList<>()).add(i);
        char[] result = new char[n];
        for (List<Integer> indices : groups.values()) {
            List<Character> chars = new ArrayList<>();
            for (int idx : indices) chars.add(s.charAt(idx));
            Collections.sort(chars); Collections.sort(indices);
            for (int i = 0; i < indices.size(); i++) result[indices.get(i)] = chars.get(i);
        }
        return new String(result);
    }

    // 7. Kruskal's MST (minimum spanning tree)
    static int kruskalMST(int n, int[][] edges) {
        Arrays.sort(edges, (a, b) -> a[2] - b[2]); // sort by weight
        DSU dsu = new DSU(n);
        int totalWeight = 0, edgesUsed = 0;
        for (int[] e : edges) {
            if (dsu.union(e[0], e[1])) {
                totalWeight += e[2]; edgesUsed++;
                System.out.println("  Add edge " + e[0] + "-" + e[1] + " weight=" + e[2]);
                if (edgesUsed == n-1) break;
            }
        }
        return totalWeight;
    }

    public static void main(String[] args) {
        System.out.println("===== UNION-FIND PATTERN =====\n");

        int[][] edges1 = {{0,1},{1,2},{3,4}};
        System.out.println("1. countComponents(5, edges) = " + countComponents(5, edges1));

        char[][] grid = {{'1','1','0','0','0'},{'1','1','0','0','0'},{'0','0','1','0','0'},{'0','0','0','1','1'}};
        System.out.println("2. numIslands = " + numIslands(grid));

        int[][] redundant = {{1,2},{1,3},{2,3}};
        System.out.println("3. redundantConnection = " + Arrays.toString(findRedundantConnection(redundant)));

        String[] equations = {"a==b","b!=c","b==c"};
        System.out.println("5. equationsPossible = " + equationsPossible(equations));

        String s = "dcab";
        List<List<Integer>> pairs = Arrays.asList(Arrays.asList(0,3), Arrays.asList(1,2));
        System.out.println("6. smallestStringSwaps = " + smallestStringWithSwaps(s, pairs));

        // Graph: 4 nodes, edges: [u,v,weight]
        int[][] mstEdges = {{0,1,10},{0,2,6},{0,3,5},{1,3,15},{2,3,4}};
        System.out.println("7. Kruskal MST:");
        System.out.println("   Total MST weight = " + kruskalMST(4, mstEdges));

        // DSU direct usage
        System.out.println("\n=== DSU DEMO ===");
        DSU dsu = new DSU(6);
        dsu.union(0,1); dsu.union(2,3); dsu.union(4,5);
        System.out.println("After 3 unions: components = " + dsu.count());
        System.out.println("0 and 1 connected? " + dsu.connected(0,1));
        System.out.println("0 and 2 connected? " + dsu.connected(0,2));
        dsu.union(0,2);
        System.out.println("After union(0,2): 0 and 3 connected? " + dsu.connected(0,3));
    }
}
