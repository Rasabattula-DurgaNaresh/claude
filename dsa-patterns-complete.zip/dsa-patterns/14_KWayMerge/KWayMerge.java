/**
 * PATTERN 14: K-WAY MERGE
 * ========================
 * Use when: merge k sorted arrays/lists, find kth smallest across k lists
 * Key insight: minHeap tracks the current minimum across all k lists
 *   - Add first element of each list to heap
 *   - Poll min, add next element from same list
 *
 * Time: O(n log k)  Space: O(k)
 */
import java.util.*;

public class KWayMerge {

    static class ListNode {
        int val; ListNode next;
        ListNode(int v) { val = v; }
        static ListNode of(int... vals) {
            ListNode dummy=new ListNode(0),cur=dummy;
            for(int v:vals){cur.next=new ListNode(v);cur=cur.next;}
            return dummy.next;
        }
        static String str(ListNode h){
            StringBuilder sb=new StringBuilder();
            while(h!=null){sb.append(h.val);if(h.next!=null)sb.append("->");h=h.next;}
            return sb.toString();
        }
    }

    // 1. Merge k sorted linked lists
    static ListNode mergeKLists(ListNode[] lists) {
        PriorityQueue<ListNode> minHeap = new PriorityQueue<>(Comparator.comparingInt(n -> n.val));
        for (ListNode head : lists) if (head != null) minHeap.offer(head);
        ListNode dummy = new ListNode(0), cur = dummy;
        while (!minHeap.isEmpty()) {
            ListNode node = minHeap.poll();
            cur.next = node; cur = cur.next;
            if (node.next != null) minHeap.offer(node.next);
        }
        return dummy.next;
    }

    // 2. Kth smallest element from k sorted lists
    static int kthSmallestInKLists(int[][] lists, int k) {
        // [value, listIndex, elementIndex]
        PriorityQueue<int[]> minHeap = new PriorityQueue<>(Comparator.comparingInt(a -> a[0]));
        for (int i = 0; i < lists.length; i++)
            if (lists[i].length > 0) minHeap.offer(new int[]{lists[i][0], i, 0});
        int count = 0;
        while (!minHeap.isEmpty()) {
            int[] cur = minHeap.poll();
            count++;
            if (count == k) return cur[0];
            int nextIdx = cur[2] + 1;
            if (nextIdx < lists[cur[1]].length)
                minHeap.offer(new int[]{lists[cur[1]][nextIdx], cur[1], nextIdx});
        }
        return -1;
    }

    // 3. Kth smallest in sorted matrix (each row & col sorted)
    static int kthSmallestMatrix(int[][] matrix, int k) {
        int n = matrix.length;
        PriorityQueue<int[]> minHeap = new PriorityQueue<>(Comparator.comparingInt(a -> a[0]));
        for (int i = 0; i < Math.min(n, k); i++) minHeap.offer(new int[]{matrix[i][0], i, 0});
        int count = 0;
        while (!minHeap.isEmpty()) {
            int[] cur = minHeap.poll();
            count++;
            if (count == k) return cur[0];
            if (cur[2] + 1 < n) minHeap.offer(new int[]{matrix[cur[1]][cur[2]+1], cur[1], cur[2]+1});
        }
        return -1;
    }

    // 4. Find smallest range covering at least one from each list
    static int[] smallestRange(List<List<Integer>> nums) {
        PriorityQueue<int[]> minHeap = new PriorityQueue<>(Comparator.comparingInt(a -> a[0]));
        int maxVal = Integer.MIN_VALUE;
        for (int i = 0; i < nums.size(); i++) {
            minHeap.offer(new int[]{nums.get(i).get(0), i, 0});
            maxVal = Math.max(maxVal, nums.get(i).get(0));
        }
        int[] result = new int[]{0, Integer.MAX_VALUE};
        while (!minHeap.isEmpty()) {
            int[] cur = minHeap.poll();
            if (maxVal - cur[0] < result[1] - result[0]) result = new int[]{cur[0], maxVal};
            int nextIdx = cur[2] + 1;
            if (nextIdx >= nums.get(cur[1]).size()) break; // one list exhausted
            int nextVal = nums.get(cur[1]).get(nextIdx);
            maxVal = Math.max(maxVal, nextVal);
            minHeap.offer(new int[]{nextVal, cur[1], nextIdx});
        }
        return result;
    }

    // 5. Merge k sorted arrays into one
    static int[] mergeKArrays(int[][] arrays) {
        PriorityQueue<int[]> minHeap = new PriorityQueue<>(Comparator.comparingInt(a -> a[0]));
        int total = 0;
        for (int i = 0; i < arrays.length; i++) {
            total += arrays[i].length;
            if (arrays[i].length > 0) minHeap.offer(new int[]{arrays[i][0], i, 0});
        }
        int[] result = new int[total]; int idx = 0;
        while (!minHeap.isEmpty()) {
            int[] cur = minHeap.poll();
            result[idx++] = cur[0];
            int nextIdx = cur[2] + 1;
            if (nextIdx < arrays[cur[1]].length)
                minHeap.offer(new int[]{arrays[cur[1]][nextIdx], cur[1], nextIdx});
        }
        return result;
    }

    public static void main(String[] args) {
        System.out.println("===== K-WAY MERGE PATTERN =====\n");

        ListNode[] lists = {ListNode.of(1,4,5), ListNode.of(1,3,4), ListNode.of(2,6)};
        System.out.println("1. mergeKLists = " + ListNode.str(mergeKLists(lists)));

        int[][] kLists = {{1,5,9},{2,4,8},{3,7,10}};
        System.out.println("2. kthSmallestInKLists(k=5) = " + kthSmallestInKLists(kLists, 5));

        int[][] matrix = {{1,5,9},{10,11,13},{12,13,15}};
        System.out.println("3. kthSmallestMatrix(k=8) = " + kthSmallestMatrix(matrix, 8));

        List<List<Integer>> nums = Arrays.asList(
            Arrays.asList(4,10,15,24,26), Arrays.asList(0,9,12,20), Arrays.asList(5,18,22,30));
        System.out.println("4. smallestRange = " + Arrays.toString(smallestRange(nums)));

        int[][] arrays = {{1,3,5},{2,4,6},{7,8,9}};
        System.out.println("5. mergeKArrays = " + Arrays.toString(mergeKArrays(arrays)));
    }
}
