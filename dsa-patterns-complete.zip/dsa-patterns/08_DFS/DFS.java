/**
 * PATTERN 08: DEPTH-FIRST SEARCH (DFS)
 * ======================================
 * Use when: path existence, all paths, cycle detection, topological sort,
 *           connected components, tree problems (height, diameter, LCA)
 * Key insight: Stack (or recursion) — go deep before exploring siblings
 *
 * Template (recursive):
 *   void dfs(Node cur, ...state...) {
 *       if (base case) { record; return; }
 *       for (Node next : neighbors) {
 *           if (!visited) {
 *               visited.add(next);
 *               dfs(next, ...state...);
 *               visited.remove(next); // backtrack if needed
 *           }
 *       }
 *   }
 *
 * Time: O(V+E)  Space: O(V) recursion stack
 */
import java.util.*;

public class DFS {

    static class TreeNode {
        int val; TreeNode left, right;
        TreeNode(int v) { val = v; }
    }

    static TreeNode buildBST(int... vals) {
        TreeNode root = null;
        for (int v : vals) root = insertBST(root, v);
        return root;
    }
    static TreeNode insertBST(TreeNode r, int v) {
        if (r == null) return new TreeNode(v);
        if (v < r.val) r.left = insertBST(r.left, v); else r.right = insertBST(r.right, v);
        return r;
    }

    // 1. Max depth of binary tree
    static int maxDepth(TreeNode root) {
        if (root == null) return 0;
        return 1 + Math.max(maxDepth(root.left), maxDepth(root.right));
    }

    // 2. Path sum — does root-to-leaf path sum to target?
    static boolean hasPathSum(TreeNode root, int target) {
        if (root == null) return false;
        if (root.left == null && root.right == null) return root.val == target;
        return hasPathSum(root.left, target - root.val) || hasPathSum(root.right, target - root.val);
    }

    // 3. All root-to-leaf paths with target sum
    static List<List<Integer>> pathSumII(TreeNode root, int target) {
        List<List<Integer>> result = new ArrayList<>();
        dfsPath(root, target, new ArrayList<>(), result);
        return result;
    }
    static void dfsPath(TreeNode node, int remaining, List<Integer> path, List<List<Integer>> result) {
        if (node == null) return;
        path.add(node.val);
        if (node.left == null && node.right == null && remaining == node.val) result.add(new ArrayList<>(path));
        dfsPath(node.left,  remaining - node.val, path, result);
        dfsPath(node.right, remaining - node.val, path, result);
        path.remove(path.size() - 1); // backtrack
    }

    // 4. Maximum path sum (any node to any node)
    static int maxPathSum;
    static int maxPathSum(TreeNode root) {
        maxPathSum = Integer.MIN_VALUE;
        dfsMaxPath(root);
        return maxPathSum;
    }
    static int dfsMaxPath(TreeNode node) {
        if (node == null) return 0;
        int left  = Math.max(0, dfsMaxPath(node.left));
        int right = Math.max(0, dfsMaxPath(node.right));
        maxPathSum = Math.max(maxPathSum, node.val + left + right); // path through root
        return node.val + Math.max(left, right); // only one branch goes up
    }

    // 5. Diameter of binary tree
    static int diameter;
    static int diameterOfBinaryTree(TreeNode root) {
        diameter = 0; heightForDiameter(root); return diameter;
    }
    static int heightForDiameter(TreeNode node) {
        if (node == null) return 0;
        int left = heightForDiameter(node.left), right = heightForDiameter(node.right);
        diameter = Math.max(diameter, left + right);
        return 1 + Math.max(left, right);
    }

    // 6. Lowest Common Ancestor (BST)
    static TreeNode lcaBST(TreeNode root, int p, int q) {
        while (root != null) {
            if (p < root.val && q < root.val) root = root.left;
            else if (p > root.val && q > root.val) root = root.right;
            else return root;
        }
        return null;
    }

    // 7. LCA of Binary Tree (not BST)
    static TreeNode lcaBT(TreeNode root, int p, int q) {
        if (root == null || root.val == p || root.val == q) return root;
        TreeNode left = lcaBT(root.left, p, q), right = lcaBT(root.right, p, q);
        if (left != null && right != null) return root; // p and q on opposite sides
        return left != null ? left : right;
    }

    // 8. Number of islands — DFS flood fill
    static int numIslandsDFS(char[][] grid) {
        int count = 0, rows = grid.length, cols = grid[0].length;
        for (int r = 0; r < rows; r++) for (int c = 0; c < cols; c++)
            if (grid[r][c] == '1') { dfsIsland(grid, r, c, rows, cols); count++; }
        return count;
    }
    static void dfsIsland(char[][] g, int r, int c, int rows, int cols) {
        if (r<0||r>=rows||c<0||c>=cols||g[r][c]!='1') return;
        g[r][c] = '0';
        dfsIsland(g,r+1,c,rows,cols); dfsIsland(g,r-1,c,rows,cols);
        dfsIsland(g,r,c+1,rows,cols); dfsIsland(g,r,c-1,rows,cols);
    }

    // 9. Course schedule — detect cycle (topological sort DFS)
    static boolean canFinish(int n, int[][] prereqs) {
        List<List<Integer>> graph = new ArrayList<>();
        for (int i = 0; i < n; i++) graph.add(new ArrayList<>());
        for (int[] p : prereqs) graph.get(p[1]).add(p[0]);
        int[] state = new int[n]; // 0=unvisited, 1=visiting, 2=done
        for (int i = 0; i < n; i++) if (!dfsTopSort(graph, state, i)) return false;
        return true;
    }
    static boolean dfsTopSort(List<List<Integer>> g, int[] state, int node) {
        if (state[node] == 1) return false; // cycle!
        if (state[node] == 2) return true;
        state[node] = 1; // visiting
        for (int next : g.get(node)) if (!dfsTopSort(g, state, next)) return false;
        state[node] = 2; return true;
    }

    // 10. Topological sort order
    static int[] topoSort(int n, int[][] prereqs) {
        List<List<Integer>> graph = new ArrayList<>();
        for (int i = 0; i < n; i++) graph.add(new ArrayList<>());
        for (int[] p : prereqs) graph.get(p[1]).add(p[0]);
        int[] state = new int[n];
        Deque<Integer> stack = new ArrayDeque<>();
        for (int i = 0; i < n; i++) dfsTopoStack(graph, state, i, stack);
        return stack.stream().mapToInt(Integer::intValue).toArray();
    }
    static void dfsTopoStack(List<List<Integer>> g, int[] state, int node, Deque<Integer> stack) {
        if (state[node] != 0) return;
        state[node] = 1;
        for (int next : g.get(node)) dfsTopoStack(g, state, next, stack);
        stack.push(node);
    }

    public static void main(String[] args) {
        System.out.println("===== DFS PATTERN =====\n");

        TreeNode tree = buildBST(10,5,20,3,7,15,25);
        System.out.println("1. maxDepth = " + maxDepth(tree));
        System.out.println("2. hasPathSum(target=18) = " + hasPathSum(tree, 18));
        System.out.println("3. pathSumII(target=18) = " + pathSumII(tree, 18));
        System.out.println("4. maxPathSum = " + maxPathSum(tree));
        System.out.println("5. diameter = " + diameterOfBinaryTree(tree));
        System.out.println("6. lcaBST(3,7) = " + lcaBST(tree, 3, 7).val);
        System.out.println("7. lcaBT(3,7)  = " + lcaBT(tree, 3, 7).val);

        char[][] grid = {{'1','1','0'},{'0','1','0'},{'0','0','1'}};
        System.out.println("8. numIslands = " + numIslandsDFS(grid));

        int[][] prereqs = {{1,0},{2,1},{3,2}};
        System.out.println("9. canFinish(4, prereqs) = " + canFinish(4, prereqs));
        System.out.println("10.topoSort = " + Arrays.toString(topoSort(4, prereqs)));
    }
}
