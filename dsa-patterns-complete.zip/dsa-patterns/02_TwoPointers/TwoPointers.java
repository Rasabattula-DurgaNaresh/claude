/**
 * PATTERN 02: TWO POINTERS
 * ==========================
 * Use when: sorted array/string, find pairs/triplets, partition
 * Key insight: use two indices moving toward each other or same direction
 *
 * Variants:
 *   Opposite ends  : left=0, right=n-1, move based on condition
 *   Same direction : slow & fast pointer on same array
 *   Partition      : Dutch National Flag, in-place operations
 *
 * Time: O(n)  Space: O(1)
 */
import java.util.*;

public class TwoPointers {

    // 1. Two Sum II (sorted array) → pair summing to target
    static int[] twoSumSorted(int[] nums, int target) {
        int l = 0, r = nums.length - 1;
        while (l < r) {
            int sum = nums[l] + nums[r];
            if (sum == target) return new int[]{l + 1, r + 1}; // 1-indexed
            if (sum < target) l++; else r--;
        }
        return new int[]{-1, -1};
    }

    // 2. Three Sum → all unique triplets summing to 0
    static List<List<Integer>> threeSum(int[] nums) {
        Arrays.sort(nums);
        List<List<Integer>> result = new ArrayList<>();
        for (int i = 0; i < nums.length - 2; i++) {
            if (i > 0 && nums[i] == nums[i - 1]) continue; // skip duplicates
            int l = i + 1, r = nums.length - 1;
            while (l < r) {
                int sum = nums[i] + nums[l] + nums[r];
                if (sum == 0) {
                    result.add(Arrays.asList(nums[i], nums[l], nums[r]));
                    while (l < r && nums[l] == nums[l + 1]) l++;
                    while (l < r && nums[r] == nums[r - 1]) r--;
                    l++; r--;
                } else if (sum < 0) l++;
                else r--;
            }
        }
        return result;
    }

    // 3. Three Sum Closest
    static int threeSumClosest(int[] nums, int target) {
        Arrays.sort(nums);
        int closest = nums[0] + nums[1] + nums[2];
        for (int i = 0; i < nums.length - 2; i++) {
            int l = i + 1, r = nums.length - 1;
            while (l < r) {
                int sum = nums[i] + nums[l] + nums[r];
                if (Math.abs(sum - target) < Math.abs(closest - target)) closest = sum;
                if (sum < target) l++; else r--;
            }
        }
        return closest;
    }

    // 4. Container with most water
    static int maxArea(int[] height) {
        int l = 0, r = height.length - 1, max = 0;
        while (l < r) {
            max = Math.max(max, (r - l) * Math.min(height[l], height[r]));
            if (height[l] < height[r]) l++; else r--;
        }
        return max;
    }

    // 5. Remove duplicates from sorted array in-place
    static int removeDuplicates(int[] nums) {
        int slow = 1;
        for (int fast = 1; fast < nums.length; fast++)
            if (nums[fast] != nums[fast - 1]) nums[slow++] = nums[fast];
        return slow; // new length
    }

    // 6. Move zeros to end
    static void moveZeroes(int[] nums) {
        int slow = 0;
        for (int fast = 0; fast < nums.length; fast++)
            if (nums[fast] != 0) nums[slow++] = nums[fast];
        while (slow < nums.length) nums[slow++] = 0;
    }

    // 7. Sort colors (Dutch National Flag — 0s, 1s, 2s)
    static void sortColors(int[] nums) {
        int low = 0, mid = 0, high = nums.length - 1;
        while (mid <= high) {
            if      (nums[mid] == 0) { int t=nums[low];nums[low++]=nums[mid];nums[mid++]=t; }
            else if (nums[mid] == 1) mid++;
            else                     { int t=nums[mid];nums[mid]=nums[high];nums[high--]=t; }
        }
    }

    // 8. Valid palindrome (ignore non-alphanumeric)
    static boolean isPalindrome(String s) {
        int l = 0, r = s.length() - 1;
        while (l < r) {
            while (l < r && !Character.isLetterOrDigit(s.charAt(l))) l++;
            while (l < r && !Character.isLetterOrDigit(s.charAt(r))) r--;
            if (Character.toLowerCase(s.charAt(l)) != Character.toLowerCase(s.charAt(r))) return false;
            l++; r--;
        }
        return true;
    }

    // 9. Squares of sorted array (result also sorted)
    static int[] sortedSquares(int[] nums) {
        int n = nums.length;
        int[] result = new int[n];
        int l = 0, r = n - 1, pos = n - 1;
        while (l <= r) {
            int sl = nums[l] * nums[l], sr = nums[r] * nums[r];
            if (sl > sr) { result[pos--] = sl; l++; }
            else         { result[pos--] = sr; r--; }
        }
        return result;
    }

    // 10. Trapping rain water
    static int trap(int[] height) {
        int l = 0, r = height.length - 1, leftMax = 0, rightMax = 0, water = 0;
        while (l < r) {
            if (height[l] <= height[r]) {
                if (height[l] >= leftMax) leftMax = height[l];
                else water += leftMax - height[l];
                l++;
            } else {
                if (height[r] >= rightMax) rightMax = height[r];
                else water += rightMax - height[r];
                r--;
            }
        }
        return water;
    }

    public static void main(String[] args) {
        System.out.println("===== TWO POINTERS PATTERN =====\n");

        int[] a = {1,2,3,4,6};
        System.out.println("1. twoSumSorted([1,2,3,4,6], target=6) = " + Arrays.toString(twoSumSorted(a, 6)));

        int[] b = {-1,0,1,2,-1,-4};
        System.out.println("2. threeSum([-1,0,1,2,-1,-4]) = " + threeSum(b));

        int[] c = {-1,2,1,-4};
        System.out.println("3. threeSumClosest(target=1) = " + threeSumClosest(c, 1));

        int[] d = {1,8,6,2,5,4,8,3,7};
        System.out.println("4. maxArea = " + maxArea(d));

        int[] e = {0,0,1,1,1,2,2,3,3,4};
        System.out.println("5. removeDuplicates = " + removeDuplicates(e));

        int[] f = {0,1,0,3,12};
        moveZeroes(f);
        System.out.println("6. moveZeroes = " + Arrays.toString(f));

        int[] g = {2,0,2,1,1,0};
        sortColors(g);
        System.out.println("7. sortColors = " + Arrays.toString(g));

        System.out.println("8. isPalindrome(\"A man a plan a canal Panama\") = " + isPalindrome("A man a plan a canal Panama"));

        int[] h = {-4,-1,0,3,10};
        System.out.println("9. sortedSquares = " + Arrays.toString(sortedSquares(h)));

        int[] i = {0,1,0,2,1,0,1,3,2,1,2,1};
        System.out.println("10.trap = " + trap(i));
    }
}
