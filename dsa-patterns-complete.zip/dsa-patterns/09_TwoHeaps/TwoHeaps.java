/**
 * PATTERN 09: TWO HEAPS
 * ======================
 * Use when: find median, partition data into two halves
 * Key insight: maxHeap for lower half, minHeap for upper half
 *              keep sizes balanced (diff <= 1)
 *
 * Median = maxHeap.peek() if sizes unequal
 *        = avg(maxHeap.peek(), minHeap.peek()) if equal
 *
 * Time: O(log n) insert, O(1) median
 */
import java.util.*;

public class TwoHeaps {

    // 1. Median finder (data stream)
    static class MedianFinder {
        PriorityQueue<Integer> maxHeap = new PriorityQueue<>(Collections.reverseOrder()); // lower half
        PriorityQueue<Integer> minHeap = new PriorityQueue<>();                           // upper half

        void addNum(int num) {
            maxHeap.offer(num);
            minHeap.offer(maxHeap.poll()); // balance: push max of lower to upper
            if (minHeap.size() > maxHeap.size()) maxHeap.offer(minHeap.poll()); // keep lower >= upper
        }

        double findMedian() {
            if (maxHeap.size() > minHeap.size()) return maxHeap.peek();
            return (maxHeap.peek() + minHeap.peek()) / 2.0;
        }
    }

    // 2. Sliding window median
    static double[] medianSlidingWindow(int[] nums, int k) {
        double[] result = new double[nums.length - k + 1];
        PriorityQueue<Integer> maxH = new PriorityQueue<>(Collections.reverseOrder());
        PriorityQueue<Integer> minH = new PriorityQueue<>();

        for (int i = 0; i < nums.length; i++) {
            // Add
            if (maxH.isEmpty() || nums[i] <= maxH.peek()) maxH.offer(nums[i]);
            else minH.offer(nums[i]);
            // Rebalance
            while (maxH.size() > minH.size() + 1) minH.offer(maxH.poll());
            while (minH.size() > maxH.size())      maxH.offer(minH.poll());
            // Record median once window full
            if (i >= k - 1) {
                result[i - k + 1] = maxH.size() == minH.size()
                    ? (maxH.peek() / 2.0 + minH.peek() / 2.0)
                    : maxH.peek();
                // Remove outgoing element
                int out = nums[i - k + 1];
                if (out <= maxH.peek()) maxH.remove(out); else minH.remove(out);
                while (maxH.size() > minH.size() + 1) minH.offer(maxH.poll());
                while (minH.size() > maxH.size())      maxH.offer(minH.poll());
            }
        }
        return result;
    }

    // 3. IPO — maximize capital: k projects, limited capital
    static int findMaximizedCapital(int k, int W, int[] profits, int[] capital) {
        int n = profits.length;
        PriorityQueue<int[]> minCapPQ = new PriorityQueue<>((a,b) -> a[0]-b[0]); // by capital
        PriorityQueue<Integer> maxProfPQ = new PriorityQueue<>(Collections.reverseOrder());
        for (int i = 0; i < n; i++) minCapPQ.offer(new int[]{capital[i], profits[i]});
        for (int i = 0; i < k; i++) {
            while (!minCapPQ.isEmpty() && minCapPQ.peek()[0] <= W)
                maxProfPQ.offer(minCapPQ.poll()[1]);
            if (maxProfPQ.isEmpty()) break;
            W += maxProfPQ.poll();
        }
        return W;
    }

    // 4. Find right interval (start/end matching with two heaps)
    static int[] findRightInterval(int[][] intervals) {
        int n = intervals.length;
        int[] result = new int[n];
        // Map from start -> original index
        TreeMap<Integer, Integer> startMap = new TreeMap<>();
        for (int i = 0; i < n; i++) startMap.put(intervals[i][0], i);
        for (int i = 0; i < n; i++) {
            Map.Entry<Integer, Integer> e = startMap.ceilingEntry(intervals[i][1]);
            result[i] = (e == null) ? -1 : e.getValue();
        }
        return result;
    }

    public static void main(String[] args) {
        System.out.println("===== TWO HEAPS PATTERN =====\n");

        MedianFinder mf = new MedianFinder();
        int[] stream = {5,15,1,3,8,7,9,2,6};
        System.out.print("1. Median stream: ");
        for (int n : stream) { mf.addNum(n); System.out.printf("%.1f ", mf.findMedian()); }
        System.out.println();

        int[] nums = {1,3,-1,-3,5,3,6,7};
        System.out.println("2. medianSlidingWindow(k=3) = " + Arrays.toString(medianSlidingWindow(nums, 3)));

        int[] profits = {1,2,3}, capital = {0,1,1};
        System.out.println("3. maximizedCapital(k=2,W=0) = " + findMaximizedCapital(2, 0, profits, capital));

        int[][] intervals = {{3,4},{2,3},{1,2}};
        System.out.println("4. findRightInterval = " + Arrays.toString(findRightInterval(intervals)));
    }
}
