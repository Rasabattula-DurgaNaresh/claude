/**
 * PATTERN 05: CYCLIC SORT
 * ========================
 * Use when: array contains numbers in range [1..n] or [0..n]
 * Key insight: each number belongs at index (num-1); swap to correct place
 *
 * Template:
 *   int i = 0;
 *   while (i < n) {
 *       int correct = nums[i] - 1;
 *       if (nums[i] != nums[correct]) swap(i, correct);
 *       else i++;
 *   }
 *   // Now find misplaced elements
 *
 * Time: O(n)  Space: O(1)
 */
import java.util.*;

public class CyclicSort {

    static void swap(int[] a, int i, int j) { int t=a[i]; a[i]=a[j]; a[j]=t; }

    // 1. Cyclic sort: sort array with numbers [1..n]
    static void cyclicSort(int[] nums) {
        int i = 0;
        while (i < nums.length) {
            int correct = nums[i] - 1;
            if (nums[i] != nums[correct]) swap(nums, i, correct);
            else i++;
        }
    }

    // 2. Find missing number [0..n]
    static int missingNumber(int[] nums) {
        int i = 0;
        while (i < nums.length) {
            int correct = nums[i];
            if (nums[i] < nums.length && nums[i] != nums[correct]) swap(nums, i, correct);
            else i++;
        }
        for (int j = 0; j < nums.length; j++) if (nums[j] != j) return j;
        return nums.length;
    }

    // 3. Find all missing numbers [1..n], can have duplicates
    static List<Integer> findAllMissing(int[] nums) {
        int i = 0;
        while (i < nums.length) {
            int correct = nums[i] - 1;
            if (nums[i] != nums[correct]) swap(nums, i, correct);
            else i++;
        }
        List<Integer> missing = new ArrayList<>();
        for (int j = 0; j < nums.length; j++) if (nums[j] != j + 1) missing.add(j + 1);
        return missing;
    }

    // 4. Find duplicate number [1..n], one duplicate
    static int findDuplicate(int[] nums) {
        int i = 0;
        while (i < nums.length) {
            int correct = nums[i] - 1;
            if (nums[i] != i + 1) {
                if (nums[i] != nums[correct]) swap(nums, i, correct);
                else return nums[i]; // duplicate found
            } else i++;
        }
        return -1;
    }

    // 5. Find all duplicates
    static List<Integer> findAllDuplicates(int[] nums) {
        int i = 0;
        while (i < nums.length) {
            int correct = nums[i] - 1;
            if (nums[i] != nums[correct]) swap(nums, i, correct);
            else i++;
        }
        List<Integer> dups = new ArrayList<>();
        for (int j = 0; j < nums.length; j++) if (nums[j] != j + 1) dups.add(nums[j]);
        return dups;
    }

    // 6. Find the corrupt pair [duplicate, missing]
    static int[] findCorruptPair(int[] nums) {
        int i = 0;
        while (i < nums.length) {
            int correct = nums[i] - 1;
            if (nums[i] != nums[correct]) swap(nums, i, correct);
            else i++;
        }
        for (int j = 0; j < nums.length; j++)
            if (nums[j] != j + 1) return new int[]{nums[j], j + 1};
        return new int[]{-1, -1};
    }

    // 7. First missing positive (unsorted, can have negatives)
    static int firstMissingPositive(int[] nums) {
        int n = nums.length, i = 0;
        while (i < n) {
            int correct = nums[i] - 1;
            if (nums[i] > 0 && nums[i] <= n && nums[i] != nums[correct]) swap(nums, i, correct);
            else i++;
        }
        for (int j = 0; j < n; j++) if (nums[j] != j + 1) return j + 1;
        return n + 1;
    }

    // 8. First k missing positives
    static List<Integer> firstKMissing(int[] nums, int k) {
        int n = nums.length, i = 0;
        while (i < n) {
            int correct = nums[i] - 1;
            if (nums[i] > 0 && nums[i] <= n && nums[i] != nums[correct]) swap(nums, i, correct);
            else i++;
        }
        List<Integer> missing = new ArrayList<>();
        Set<Integer> extra = new HashSet<>();
        for (int j = 0; j < n; j++) {
            if (missing.size() < k) {
                if (nums[j] != j + 1) { missing.add(j + 1); extra.add(nums[j]); }
            }
        }
        int next = n + 1;
        while (missing.size() < k) {
            if (!extra.contains(next)) missing.add(next);
            next++;
        }
        return missing;
    }

    public static void main(String[] args) {
        System.out.println("===== CYCLIC SORT PATTERN =====\n");

        int[] a = {3,1,5,4,2};
        cyclicSort(a);
        System.out.println("1. cyclicSort([3,1,5,4,2]) = " + Arrays.toString(a));

        int[] b = {3,0,1};
        System.out.println("2. missingNumber([3,0,1]) = " + missingNumber(b));

        int[] c = {2,3,1,8,2,3,5,1};
        System.out.println("3. findAllMissing = " + findAllMissing(c));

        int[] d = {1,4,4,3,2};
        System.out.println("4. findDuplicate = " + findDuplicate(d));

        int[] e = {3,4,4,5,5};
        System.out.println("5. findAllDuplicates = " + findAllDuplicates(e));

        int[] f = {3,1,2,5,2};
        System.out.println("6. corruptPair = " + Arrays.toString(findCorruptPair(f)));

        int[] g = {3,4,-1,1};
        System.out.println("7. firstMissingPositive = " + firstMissingPositive(g));

        int[] h = {3,4,-1,1};
        System.out.println("8. firstKMissing([3,4,-1,1], k=3) = " + firstKMissing(h, 3));
    }
}
