/**
 * PATTERN 03: FAST & SLOW POINTERS (Floyd's Tortoise & Hare)
 * ============================================================
 * Use when: detect cycles, find middle, find nth from end
 * Key insight: fast moves 2x speed of slow; they meet at cycle
 *
 * Template (cycle detection):
 *   slow = slow.next
 *   fast = fast.next.next
 *   if slow == fast → cycle exists
 *
 * Finding cycle start:
 *   After meeting, reset one pointer to head
 *   Move both 1 step at a time → meet at cycle start
 *
 * Time: O(n)  Space: O(1)
 */
import java.util.*;

public class FastSlowPointers {

    static class ListNode {
        int val; ListNode next;
        ListNode(int v) { val = v; }
        static ListNode of(int... vals) {
            ListNode dummy = new ListNode(0), cur = dummy;
            for (int v : vals) { cur.next = new ListNode(v); cur = cur.next; }
            return dummy.next;
        }
    }

    // 1. Detect cycle in linked list
    static boolean hasCycle(ListNode head) {
        ListNode slow = head, fast = head;
        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
            if (slow == fast) return true;
        }
        return false;
    }

    // 2. Find cycle start node
    static ListNode detectCycleStart(ListNode head) {
        ListNode slow = head, fast = head;
        while (fast != null && fast.next != null) {
            slow = slow.next; fast = fast.next.next;
            if (slow == fast) {
                slow = head; // reset one to head
                while (slow != fast) { slow = slow.next; fast = fast.next; }
                return slow; // cycle start
            }
        }
        return null;
    }

    // 3. Find middle of linked list
    static ListNode findMiddle(ListNode head) {
        ListNode slow = head, fast = head;
        while (fast != null && fast.next != null) {
            slow = slow.next; fast = fast.next.next;
        }
        return slow; // slow is at middle
    }

    // 4. Check if linked list is palindrome
    static boolean isPalindrome(ListNode head) {
        // Step 1: find middle
        ListNode slow = head, fast = head;
        while (fast != null && fast.next != null) { slow = slow.next; fast = fast.next.next; }
        // Step 2: reverse second half
        ListNode prev = null, cur = slow;
        while (cur != null) { ListNode next = cur.next; cur.next = prev; prev = cur; cur = next; }
        // Step 3: compare
        ListNode left = head, right = prev;
        while (right != null) { if (left.val != right.val) return false; left = left.next; right = right.next; }
        return true;
    }

    // 5. Happy Number (cycle detection on numbers)
    static boolean isHappy(int n) {
        int slow = n, fast = sumOfSquaredDigits(n);
        while (fast != 1 && slow != fast) {
            slow = sumOfSquaredDigits(slow);
            fast = sumOfSquaredDigits(sumOfSquaredDigits(fast));
        }
        return fast == 1;
    }
    static int sumOfSquaredDigits(int n) {
        int sum = 0;
        while (n > 0) { int d = n % 10; sum += d * d; n /= 10; }
        return sum;
    }

    // 6. Find duplicate number (array as linked list, Floyd's)
    // Array values [1..n], one duplicate — treat val as pointer
    static int findDuplicate(int[] nums) {
        int slow = nums[0], fast = nums[0];
        do { slow = nums[slow]; fast = nums[nums[fast]]; } while (slow != fast);
        slow = nums[0];
        while (slow != fast) { slow = nums[slow]; fast = nums[fast]; }
        return slow;
    }

    // 7. Nth node from end
    static ListNode nthFromEnd(ListNode head, int n) {
        ListNode fast = head, slow = head;
        for (int i = 0; i < n; i++) fast = fast.next;
        while (fast != null) { slow = slow.next; fast = fast.next; }
        return slow;
    }

    // 8. Reorder list: L0→L1→…→Ln → L0→Ln→L1→Ln-1→…
    static void reorderList(ListNode head) {
        if (head == null) return;
        // Find middle
        ListNode slow = head, fast = head;
        while (fast.next != null && fast.next.next != null) { slow = slow.next; fast = fast.next.next; }
        // Reverse second half
        ListNode prev = null, cur = slow.next; slow.next = null;
        while (cur != null) { ListNode next = cur.next; cur.next = prev; prev = cur; cur = next; }
        // Merge two halves
        ListNode first = head, second = prev;
        while (second != null) {
            ListNode t1 = first.next, t2 = second.next;
            first.next = second; second.next = t1;
            first = t1; second = t2;
        }
    }

    static String listToString(ListNode head) {
        StringBuilder sb = new StringBuilder("[");
        while (head != null) { sb.append(head.val); if(head.next!=null) sb.append("->"); head=head.next; }
        return sb.append("]").toString();
    }

    public static void main(String[] args) {
        System.out.println("===== FAST & SLOW POINTERS =====\n");

        ListNode list = ListNode.of(1,2,3,4,5);
        System.out.println("1. hasCycle (no cycle) = " + hasCycle(list));

        // Create cycle: 5 -> 3
        ListNode cycleList = ListNode.of(1,2,3,4,5);
        ListNode node3 = cycleList.next.next; // node with val=3
        ListNode tail = cycleList;
        while (tail.next != null) tail = tail.next;
        tail.next = node3; // cycle
        System.out.println("   hasCycle (with cycle) = " + hasCycle(cycleList));
        System.out.println("   cycleStart.val = " + detectCycleStart(cycleList).val);

        ListNode mid = ListNode.of(1,2,3,4,5);
        System.out.println("3. findMiddle([1,2,3,4,5]) = " + findMiddle(mid).val);

        ListNode pal = ListNode.of(1,2,3,2,1);
        System.out.println("4. isPalindrome([1,2,3,2,1]) = " + isPalindrome(pal));

        System.out.println("5. isHappy(19) = " + isHappy(19));
        System.out.println("   isHappy(2)  = " + isHappy(2));

        int[] dup = {1,3,4,2,2};
        System.out.println("6. findDuplicate([1,3,4,2,2]) = " + findDuplicate(dup));

        ListNode nth = ListNode.of(1,2,3,4,5);
        System.out.println("7. 2nd from end = " + nthFromEnd(nth, 2).val);

        ListNode reorder = ListNode.of(1,2,3,4,5);
        reorderList(reorder);
        System.out.println("8. reorderList = " + listToString(reorder));
    }
}
