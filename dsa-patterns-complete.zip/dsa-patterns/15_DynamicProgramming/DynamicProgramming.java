/**
 * PATTERN 15: DYNAMIC PROGRAMMING
 * =================================
 * Use when: overlapping subproblems + optimal substructure
 * Key insight: cache results of subproblems; build bottom-up or top-down
 *
 * Categories:
 *   Linear DP        : Fibonacci, climbing stairs, house robber
 *   Interval DP      : matrix chain, palindrome partitioning
 *   Knapsack         : 0/1, unbounded, subset sum
 *   String DP        : LCS, edit distance, regex matching
 *   Grid DP          : unique paths, minimum path sum
 *   State machine DP : stock buy-sell with cooldown
 *   Digit DP        : count numbers with property
 *
 * Time: varies  Space: O(n) or O(n*m) → often reduce to O(1) or O(n)
 */
import java.util.*;

public class DynamicProgramming {

    // ──── LINEAR DP ────

    // 1. Climbing stairs (1 or 2 steps at a time) — Fibonacci variant
    static int climbStairs(int n) {
        if (n <= 2) return n;
        int a = 1, b = 2;
        for (int i = 3; i <= n; i++) { int c = a + b; a = b; b = c; }
        return b;
    }

    // 2. House Robber (no two adjacent houses)
    static int rob(int[] nums) {
        int prev = 0, curr = 0;
        for (int n : nums) { int temp = Math.max(curr, prev + n); prev = curr; curr = temp; }
        return curr;
    }

    // 3. House Robber II (circular: first and last adjacent)
    static int robII(int[] nums) {
        int n = nums.length;
        if (n == 1) return nums[0];
        return Math.max(robRange(nums, 0, n-2), robRange(nums, 1, n-1));
    }
    static int robRange(int[] nums, int l, int r) {
        int prev = 0, curr = 0;
        for (int i = l; i <= r; i++) { int t = Math.max(curr, prev + nums[i]); prev = curr; curr = t; }
        return curr;
    }

    // 4. Longest Increasing Subsequence (LIS)
    static int lengthOfLIS(int[] nums) {
        int[] tails = new int[nums.length]; int size = 0;
        for (int n : nums) {
            int l = 0, r = size;
            while (l < r) { int m = (l+r)/2; if (tails[m] < n) l=m+1; else r=m; }
            tails[l] = n; if (l == size) size++;
        }
        return size;
    }

    // 5. Maximum sum subarray (Kadane's)
    static int maxSubArray(int[] nums) {
        int maxSum = nums[0], curSum = nums[0];
        for (int i = 1; i < nums.length; i++) {
            curSum = Math.max(nums[i], curSum + nums[i]);
            maxSum = Math.max(maxSum, curSum);
        }
        return maxSum;
    }

    // ──── KNAPSACK ────

    // 6. 0/1 Knapsack
    static int knapsack01(int[] weights, int[] values, int capacity) {
        int n = weights.length;
        int[] dp = new int[capacity + 1];
        for (int i = 0; i < n; i++)
            for (int w = capacity; w >= weights[i]; w--) // traverse backward!
                dp[w] = Math.max(dp[w], dp[w - weights[i]] + values[i]);
        return dp[capacity];
    }

    // 7. Unbounded Knapsack (items can be reused)
    static int knapsackUnbounded(int[] weights, int[] values, int capacity) {
        int[] dp = new int[capacity + 1];
        for (int w = 1; w <= capacity; w++)
            for (int i = 0; i < weights.length; i++)
                if (weights[i] <= w) dp[w] = Math.max(dp[w], dp[w - weights[i]] + values[i]);
        return dp[capacity];
    }

    // 8. Subset sum — can we partition array into two equal-sum subsets?
    static boolean canPartition(int[] nums) {
        int total = 0; for (int n : nums) total += n;
        if (total % 2 != 0) return false;
        int target = total / 2;
        boolean[] dp = new boolean[target + 1];
        dp[0] = true;
        for (int n : nums)
            for (int j = target; j >= n; j--) dp[j] |= dp[j - n];
        return dp[target];
    }

    // 9. Coin Change — minimum coins
    static int coinChange(int[] coins, int amount) {
        int[] dp = new int[amount + 1];
        Arrays.fill(dp, amount + 1);
        dp[0] = 0;
        for (int i = 1; i <= amount; i++)
            for (int coin : coins) if (coin <= i) dp[i] = Math.min(dp[i], dp[i-coin] + 1);
        return dp[amount] > amount ? -1 : dp[amount];
    }

    // 10. Coin Change II — number of combinations
    static int coinChangeII(int[] coins, int amount) {
        int[] dp = new int[amount + 1];
        dp[0] = 1;
        for (int coin : coins) for (int j = coin; j <= amount; j++) dp[j] += dp[j - coin];
        return dp[amount];
    }

    // ──── STRING DP ────

    // 11. Longest Common Subsequence
    static int lcs(String s1, String s2) {
        int m = s1.length(), n = s2.length();
        int[][] dp = new int[m+1][n+1];
        for (int i = 1; i <= m; i++)
            for (int j = 1; j <= n; j++)
                dp[i][j] = s1.charAt(i-1)==s2.charAt(j-1) ? dp[i-1][j-1]+1 : Math.max(dp[i-1][j],dp[i][j-1]);
        return dp[m][n];
    }

    // 12. Edit distance (Levenshtein)
    static int editDistance(String word1, String word2) {
        int m = word1.length(), n = word2.length();
        int[][] dp = new int[m+1][n+1];
        for (int i = 0; i <= m; i++) dp[i][0] = i;
        for (int j = 0; j <= n; j++) dp[0][j] = j;
        for (int i = 1; i <= m; i++)
            for (int j = 1; j <= n; j++)
                dp[i][j] = word1.charAt(i-1)==word2.charAt(j-1)
                    ? dp[i-1][j-1]
                    : 1 + Math.min(dp[i-1][j-1], Math.min(dp[i-1][j], dp[i][j-1]));
        return dp[m][n];
    }

    // 13. Longest Palindromic Subsequence
    static int longestPalSubseq(String s) {
        int n = s.length();
        int[][] dp = new int[n][n];
        for (int i = 0; i < n; i++) dp[i][i] = 1;
        for (int len = 2; len <= n; len++)
            for (int i = 0; i <= n-len; i++) {
                int j = i + len - 1;
                dp[i][j] = s.charAt(i)==s.charAt(j)
                    ? dp[i+1][j-1]+2
                    : Math.max(dp[i+1][j], dp[i][j-1]);
            }
        return dp[0][n-1];
    }

    // ──── GRID DP ────

    // 14. Unique paths in m×n grid
    static int uniquePaths(int m, int n) {
        int[] dp = new int[n]; Arrays.fill(dp, 1);
        for (int i = 1; i < m; i++) for (int j = 1; j < n; j++) dp[j] += dp[j-1];
        return dp[n-1];
    }

    // 15. Minimum path sum
    static int minPathSum(int[][] grid) {
        int m = grid.length, n = grid[0].length;
        int[] dp = new int[n];
        dp[0] = grid[0][0];
        for (int j = 1; j < n; j++) dp[j] = dp[j-1] + grid[0][j];
        for (int i = 1; i < m; i++) {
            dp[0] += grid[i][0];
            for (int j = 1; j < n; j++) dp[j] = Math.min(dp[j], dp[j-1]) + grid[i][j];
        }
        return dp[n-1];
    }

    // ──── STATE MACHINE ────

    // 16. Best time to buy/sell stock with cooldown
    static int maxProfitCooldown(int[] prices) {
        int hold = Integer.MIN_VALUE, sold = 0, rest = 0;
        for (int p : prices) {
            int prevSold = sold;
            sold = hold + p;
            hold = Math.max(hold, rest - p);
            rest = Math.max(rest, prevSold);
        }
        return Math.max(sold, rest);
    }

    // 17. Burst Balloons (interval DP)
    static int maxCoins(int[] nums) {
        int n = nums.length;
        int[] balloons = new int[n+2]; balloons[0] = balloons[n+1] = 1;
        for (int i = 0; i < n; i++) balloons[i+1] = nums[i];
        int m = balloons.length;
        int[][] dp = new int[m][m];
        for (int len = 2; len < m; len++)
            for (int l = 0; l < m-len; l++) {
                int r = l + len;
                for (int k = l+1; k < r; k++)
                    dp[l][r] = Math.max(dp[l][r], balloons[l]*balloons[k]*balloons[r]+dp[l][k]+dp[k][r]);
            }
        return dp[0][m-1];
    }

    // 18. Word break
    static boolean wordBreak(String s, List<String> wordDict) {
        Set<String> dict = new HashSet<>(wordDict);
        boolean[] dp = new boolean[s.length()+1]; dp[0] = true;
        for (int i = 1; i <= s.length(); i++)
            for (int j = 0; j < i; j++)
                if (dp[j] && dict.contains(s.substring(j, i))) { dp[i] = true; break; }
        return dp[s.length()];
    }

    public static void main(String[] args) {
        System.out.println("===== DYNAMIC PROGRAMMING PATTERN =====\n");

        System.out.println("1.  climbStairs(10)        = " + climbStairs(10));
        System.out.println("2.  rob([2,7,9,3,1])       = " + rob(new int[]{2,7,9,3,1}));
        System.out.println("3.  robII([2,3,2])          = " + robII(new int[]{2,3,2}));
        System.out.println("4.  LIS([10,9,2,5,3,7,101])= " + lengthOfLIS(new int[]{10,9,2,5,3,7,101,18}));
        System.out.println("5.  maxSubArray([-2,1,-3,4,-1,2,1,-5,4]) = " + maxSubArray(new int[]{-2,1,-3,4,-1,2,1,-5,4}));
        System.out.println("6.  knapsack01(cap=10)     = " + knapsack01(new int[]{2,3,4,5}, new int[]{3,4,5,6}, 10));
        System.out.println("7.  knapsackUnbounded      = " + knapsackUnbounded(new int[]{1,3,4,5}, new int[]{1,4,5,7}, 7));
        System.out.println("8.  canPartition([1,5,11,5]) = " + canPartition(new int[]{1,5,11,5}));
        System.out.println("9.  coinChange([1,5,10,25],41) = " + coinChange(new int[]{1,5,10,25}, 41));
        System.out.println("10. coinChangeII([1,2,5],5) = " + coinChangeII(new int[]{1,2,5}, 5));
        System.out.println("11. LCS(ABCBDAB,BDCAB)    = " + lcs("ABCBDAB","BDCAB"));
        System.out.println("12. editDistance(horse,ros) = " + editDistance("horse","ros"));
        System.out.println("13. longestPalSubseq(bbbab)= " + longestPalSubseq("bbbab"));
        System.out.println("14. uniquePaths(3,7)       = " + uniquePaths(3,7));
        System.out.println("15. minPathSum             = " + minPathSum(new int[][]{{1,3,1},{1,5,1},{4,2,1}}));
        System.out.println("16. maxProfitCooldown      = " + maxProfitCooldown(new int[]{1,2,3,0,2}));
        System.out.println("17. burstBalloons([3,1,5,8]) = " + maxCoins(new int[]{3,1,5,8}));
        System.out.println("18. wordBreak(leetcode)    = " + wordBreak("leetcode", Arrays.asList("leet","code")));
    }
}
