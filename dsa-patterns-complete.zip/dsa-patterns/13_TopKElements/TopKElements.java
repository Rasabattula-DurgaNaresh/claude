/**
 * PATTERN 13: TOP K ELEMENTS
 * ============================
 * Use when: find k largest/smallest, k most frequent, k closest
 * Key insight: use a heap of size k
 *   - k largest:   minHeap of size k (poll when size > k)
 *   - k smallest:  maxHeap of size k (poll when size > k)
 *   - k most freq: minHeap by frequency
 *
 * Why heap over sort? O(n log k) vs O(n log n)
 *
 * Time: O(n log k)  Space: O(k)
 */
import java.util.*;
import java.util.stream.*;

public class TopKElements {

    // 1. K largest elements
    static int[] kLargest(int[] nums, int k) {
        PriorityQueue<Integer> minHeap = new PriorityQueue<>(); // minHeap of size k
        for (int n : nums) {
            minHeap.offer(n);
            if (minHeap.size() > k) minHeap.poll(); // remove smallest
        }
        return minHeap.stream().mapToInt(Integer::intValue).toArray();
    }

    // 2. Kth largest element (QuickSelect — O(n) avg)
    static int kthLargest(int[] nums, int k) {
        int l = 0, r = nums.length - 1, target = nums.length - k;
        while (l <= r) {
            int pivot = partition(nums, l, r);
            if (pivot == target) return nums[pivot];
            if (pivot < target)  l = pivot + 1; else r = pivot - 1;
        }
        return -1;
    }
    static int partition(int[] nums, int l, int r) {
        int pivot = nums[r], i = l;
        for (int j = l; j < r; j++) if (nums[j] <= pivot) { int t=nums[i];nums[i++]=nums[j];nums[j]=t; }
        int t=nums[i];nums[i]=nums[r];nums[r]=t;
        return i;
    }

    // 3. K most frequent elements
    static int[] topKFrequent(int[] nums, int k) {
        Map<Integer, Integer> freq = new HashMap<>();
        for (int n : nums) freq.merge(n, 1, Integer::sum);
        PriorityQueue<Map.Entry<Integer,Integer>> minHeap =
            new PriorityQueue<>(Comparator.comparingInt(Map.Entry::getValue));
        for (Map.Entry<Integer,Integer> e : freq.entrySet()) {
            minHeap.offer(e);
            if (minHeap.size() > k) minHeap.poll();
        }
        return minHeap.stream().mapToInt(Map.Entry::getKey).toArray();
    }

    // 4. K closest points to origin
    static int[][] kClosest(int[][] points, int k) {
        // maxHeap by distance — keep k smallest
        PriorityQueue<int[]> maxHeap = new PriorityQueue<>((a, b) ->
            (b[0]*b[0]+b[1]*b[1]) - (a[0]*a[0]+a[1]*a[1]));
        for (int[] p : points) {
            maxHeap.offer(p);
            if (maxHeap.size() > k) maxHeap.poll();
        }
        return maxHeap.toArray(new int[0][]);
    }

    // 5. Sort characters by frequency
    static String frequencySort(String s) {
        Map<Character, Integer> freq = new HashMap<>();
        for (char c : s.toCharArray()) freq.merge(c, 1, Integer::sum);
        PriorityQueue<Map.Entry<Character,Integer>> maxHeap =
            new PriorityQueue<>((a, b) -> b.getValue() - a.getValue());
        maxHeap.addAll(freq.entrySet());
        StringBuilder sb = new StringBuilder();
        while (!maxHeap.isEmpty()) {
            Map.Entry<Character,Integer> e = maxHeap.poll();
            sb.append(String.valueOf(e.getKey()).repeat(e.getValue()));
        }
        return sb.toString();
    }

    // 6. K closest numbers in sorted array to X
    static List<Integer> findClosestElements(int[] arr, int k, int x) {
        int l = 0, r = arr.length - k;
        while (l < r) {
            int mid = l + (r - l) / 2;
            // Compare distance of left edge vs right edge of window
            if (x - arr[mid] > arr[mid + k] - x) l = mid + 1; else r = mid;
        }
        List<Integer> result = new ArrayList<>();
        for (int i = l; i < l + k; i++) result.add(arr[i]);
        return result;
    }

    // 7. Task scheduler — minimum intervals with cooldown
    static int leastInterval(char[] tasks, int n) {
        int[] freq = new int[26];
        for (char c : tasks) freq[c - 'A']++;
        PriorityQueue<Integer> maxHeap = new PriorityQueue<>(Collections.reverseOrder());
        for (int f : freq) if (f > 0) maxHeap.offer(f);
        int time = 0;
        while (!maxHeap.isEmpty()) {
            List<Integer> temp = new ArrayList<>();
            for (int i = 0; i <= n; i++) {
                if (!maxHeap.isEmpty()) temp.add(maxHeap.poll() - 1);
            }
            for (int t : temp) if (t > 0) maxHeap.offer(t);
            time += maxHeap.isEmpty() ? temp.size() : n + 1;
        }
        return time;
    }

    // 8. Reorganize string (no adjacent same chars)
    static String reorganizeString(String s) {
        int[] freq = new int[26];
        for (char c : s.toCharArray()) freq[c - 'a']++;
        PriorityQueue<int[]> maxHeap = new PriorityQueue<>((a, b) -> b[1] - a[1]);
        for (int i = 0; i < 26; i++) if (freq[i] > 0) maxHeap.offer(new int[]{i, freq[i]});
        StringBuilder sb = new StringBuilder();
        while (maxHeap.size() >= 2) {
            int[] a = maxHeap.poll(), b = maxHeap.poll();
            sb.append((char)('a' + a[0])); sb.append((char)('a' + b[0]));
            if (--a[1] > 0) maxHeap.offer(a);
            if (--b[1] > 0) maxHeap.offer(b);
        }
        if (!maxHeap.isEmpty()) {
            if (maxHeap.peek()[1] > 1) return ""; // impossible
            sb.append((char)('a' + maxHeap.poll()[0]));
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        System.out.println("===== TOP K ELEMENTS PATTERN =====\n");

        int[] a = {3,2,1,5,6,4};
        System.out.println("1. kLargest([3,2,1,5,6,4], k=2) = " + Arrays.toString(kLargest(a, 2)));
        System.out.println("2. kthLargest([3,2,1,5,6,4], k=2) = " + kthLargest(a.clone(), 2));

        int[] b = {1,1,1,2,2,3};
        System.out.println("3. topKFrequent([1,1,1,2,2,3], k=2) = " + Arrays.toString(topKFrequent(b, 2)));

        int[][] points = {{1,3},{-2,2},{5,8},{0,1}};
        System.out.println("4. kClosest(k=2) = " + Arrays.deepToString(kClosest(points, 2)));
        System.out.println("5. frequencySort(\"tree\") = " + frequencySort("tree"));

        int[] arr = {1,2,3,4,5};
        System.out.println("6. findClosestElements(k=4,x=3) = " + findClosestElements(arr, 4, 3));

        char[] tasks = {'A','A','A','B','B','B'};
        System.out.println("7. leastInterval(n=2) = " + leastInterval(tasks, 2));
        System.out.println("8. reorganizeString(\"aab\") = " + reorganizeString("aab"));
        System.out.println("   reorganizeString(\"aaab\") = " + reorganizeString("aaab"));
    }
}
