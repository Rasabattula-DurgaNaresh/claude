/**
 * PATTERN 07: BREADTH-FIRST SEARCH (BFS)
 * ========================================
 * Use when: level-order traversal, shortest path (unweighted),
 *           connected components, minimum steps
 * Key insight: Queue — explore all neighbors before going deeper
 *
 * Template:
 *   Queue<Node> q = new LinkedList<>();
 *   q.offer(start);
 *   visited.add(start);
 *   while (!q.isEmpty()) {
 *       int size = q.size();        // for level-by-level
 *       for (int i = 0; i < size; i++) {
 *           Node cur = q.poll();
 *           for (Node neighbor : cur.neighbors)
 *               if (!visited) { q.offer(neighbor); visited.add; }
 *       }
 *       level++;
 *   }
 *
 * Time: O(V+E)  Space: O(V)
 */
import java.util.*;

public class BFS {

    // ──── TREE NODE ────
    static class TreeNode {
        int val; TreeNode left, right;
        TreeNode(int v) { val = v; }
    }

    static TreeNode buildTree(Integer... vals) {
        if (vals.length == 0) return null;
        TreeNode root = new TreeNode(vals[0]);
        Queue<TreeNode> q = new LinkedList<>(); q.offer(root);
        int i = 1;
        while (!q.isEmpty() && i < vals.length) {
            TreeNode cur = q.poll();
            if (i < vals.length && vals[i] != null) { cur.left = new TreeNode(vals[i]); q.offer(cur.left); } i++;
            if (i < vals.length && vals[i] != null) { cur.right = new TreeNode(vals[i]); q.offer(cur.right); } i++;
        }
        return root;
    }

    // 1. Level order traversal
    static List<List<Integer>> levelOrder(TreeNode root) {
        List<List<Integer>> result = new ArrayList<>();
        if (root == null) return result;
        Queue<TreeNode> q = new LinkedList<>(); q.offer(root);
        while (!q.isEmpty()) {
            int size = q.size();
            List<Integer> level = new ArrayList<>();
            for (int i = 0; i < size; i++) {
                TreeNode cur = q.poll();
                level.add(cur.val);
                if (cur.left  != null) q.offer(cur.left);
                if (cur.right != null) q.offer(cur.right);
            }
            result.add(level);
        }
        return result;
    }

    // 2. Right side view of tree
    static List<Integer> rightSideView(TreeNode root) {
        List<Integer> result = new ArrayList<>();
        if (root == null) return result;
        Queue<TreeNode> q = new LinkedList<>(); q.offer(root);
        while (!q.isEmpty()) {
            int size = q.size();
            for (int i = 0; i < size; i++) {
                TreeNode cur = q.poll();
                if (i == size - 1) result.add(cur.val); // rightmost
                if (cur.left  != null) q.offer(cur.left);
                if (cur.right != null) q.offer(cur.right);
            }
        }
        return result;
    }

    // 3. Level averages
    static List<Double> levelAverages(TreeNode root) {
        List<Double> result = new ArrayList<>();
        if (root == null) return result;
        Queue<TreeNode> q = new LinkedList<>(); q.offer(root);
        while (!q.isEmpty()) {
            int size = q.size(); double sum = 0;
            for (int i = 0; i < size; i++) {
                TreeNode cur = q.poll(); sum += cur.val;
                if (cur.left  != null) q.offer(cur.left);
                if (cur.right != null) q.offer(cur.right);
            }
            result.add(sum / size);
        }
        return result;
    }

    // 4. Minimum depth of binary tree
    static int minDepth(TreeNode root) {
        if (root == null) return 0;
        Queue<TreeNode> q = new LinkedList<>(); q.offer(root); int depth = 0;
        while (!q.isEmpty()) {
            depth++;
            for (int i = 0, size = q.size(); i < size; i++) {
                TreeNode cur = q.poll();
                if (cur.left == null && cur.right == null) return depth; // first leaf
                if (cur.left  != null) q.offer(cur.left);
                if (cur.right != null) q.offer(cur.right);
            }
        }
        return depth;
    }

    // 5. Zigzag level order
    static List<List<Integer>> zigzagLevelOrder(TreeNode root) {
        List<List<Integer>> result = new ArrayList<>();
        if (root == null) return result;
        Queue<TreeNode> q = new LinkedList<>(); q.offer(root); boolean leftToRight = true;
        while (!q.isEmpty()) {
            int size = q.size();
            LinkedList<Integer> level = new LinkedList<>();
            for (int i = 0; i < size; i++) {
                TreeNode cur = q.poll();
                if (leftToRight) level.addLast(cur.val); else level.addFirst(cur.val);
                if (cur.left  != null) q.offer(cur.left);
                if (cur.right != null) q.offer(cur.right);
            }
            result.add(level); leftToRight = !leftToRight;
        }
        return result;
    }

    // ──── GRAPH BFS ────

    // 6. Shortest path in unweighted graph
    static int shortestPath(Map<Integer, List<Integer>> graph, int src, int dst) {
        if (src == dst) return 0;
        Queue<Integer> q = new LinkedList<>(); Set<Integer> visited = new HashSet<>();
        q.offer(src); visited.add(src); int steps = 0;
        while (!q.isEmpty()) {
            steps++;
            for (int i = 0, size = q.size(); i < size; i++) {
                int cur = q.poll();
                for (int next : graph.getOrDefault(cur, List.of())) {
                    if (next == dst) return steps;
                    if (visited.add(next)) q.offer(next);
                }
            }
        }
        return -1;
    }

    // 7. Number of islands (grid BFS)
    static int numIslands(char[][] grid) {
        int count = 0;
        int rows = grid.length, cols = grid[0].length;
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                if (grid[r][c] == '1') {
                    count++;
                    Queue<int[]> q = new LinkedList<>();
                    q.offer(new int[]{r, c}); grid[r][c] = '0';
                    while (!q.isEmpty()) {
                        int[] cell = q.poll();
                        int[][] dirs = {{1,0},{-1,0},{0,1},{0,-1}};
                        for (int[] d : dirs) {
                            int nr = cell[0]+d[0], nc = cell[1]+d[1];
                            if (nr>=0&&nr<rows&&nc>=0&&nc<cols&&grid[nr][nc]=='1') {
                                grid[nr][nc]='0'; q.offer(new int[]{nr, nc});
                            }
                        }
                    }
                }
            }
        }
        return count;
    }

    // 8. Word ladder — shortest transformation sequence
    static int ladderLength(String begin, String end, List<String> wordList) {
        Set<String> wordSet = new HashSet<>(wordList);
        if (!wordSet.contains(end)) return 0;
        Queue<String> q = new LinkedList<>(); q.offer(begin); int steps = 1;
        Set<String> visited = new HashSet<>(); visited.add(begin);
        while (!q.isEmpty()) {
            steps++;
            for (int i = 0, size = q.size(); i < size; i++) {
                char[] word = q.poll().toCharArray();
                for (int j = 0; j < word.length; j++) {
                    char orig = word[j];
                    for (char c = 'a'; c <= 'z'; c++) {
                        word[j] = c;
                        String next = new String(word);
                        if (next.equals(end)) return steps;
                        if (wordSet.contains(next) && visited.add(next)) q.offer(next);
                    }
                    word[j] = orig;
                }
            }
        }
        return 0;
    }

    // 9. Rotten oranges — minimum time to rot all
    static int orangesRotting(int[][] grid) {
        int rows = grid.length, cols = grid[0].length, fresh = 0, time = 0;
        Queue<int[]> q = new LinkedList<>();
        for (int r = 0; r < rows; r++) for (int c = 0; c < cols; c++) {
            if (grid[r][c] == 2) q.offer(new int[]{r, c});
            else if (grid[r][c] == 1) fresh++;
        }
        int[][] dirs = {{1,0},{-1,0},{0,1},{0,-1}};
        while (!q.isEmpty() && fresh > 0) {
            time++;
            for (int i = 0, size = q.size(); i < size; i++) {
                int[] cell = q.poll();
                for (int[] d : dirs) {
                    int nr = cell[0]+d[0], nc = cell[1]+d[1];
                    if (nr>=0&&nr<rows&&nc>=0&&nc<cols&&grid[nr][nc]==1) {
                        grid[nr][nc]=2; fresh--; q.offer(new int[]{nr,nc});
                    }
                }
            }
        }
        return fresh == 0 ? time : -1;
    }

    public static void main(String[] args) {
        System.out.println("===== BFS PATTERN =====\n");

        TreeNode tree = buildTree(3,9,20,null,null,15,7);
        System.out.println("1. levelOrder = " + levelOrder(tree));
        System.out.println("2. rightSideView = " + rightSideView(tree));
        System.out.println("3. levelAverages = " + levelAverages(tree));
        System.out.println("4. minDepth = " + minDepth(tree));
        System.out.println("5. zigzagLevelOrder = " + zigzagLevelOrder(tree));

        Map<Integer,List<Integer>> g = new HashMap<>();
        g.put(1, Arrays.asList(2,3)); g.put(2, Arrays.asList(4));
        g.put(3, Arrays.asList(4,5)); g.put(4, Arrays.asList(6)); g.put(5, List.of()); g.put(6, List.of());
        System.out.println("6. shortestPath(1->6) = " + shortestPath(g,1,6));

        char[][] grid = {{'1','1','0','0','0'},{'1','1','0','0','0'},{'0','0','1','0','0'},{'0','0','0','1','1'}};
        System.out.println("7. numIslands = " + numIslands(grid));

        List<String> words = Arrays.asList("hot","dot","dog","lot","log","cog");
        System.out.println("8. ladderLength(hit->cog) = " + ladderLength("hit","cog", words));

        int[][] oranges = {{2,1,1},{1,1,0},{0,1,1}};
        System.out.println("9. orangesRotting = " + orangesRotting(oranges));
    }
}
