/**
 * PATTERN 16: BACKTRACKING
 * =========================
 * Use when: generate all solutions, constraint satisfaction (N-Queens, Sudoku)
 * Key insight: try all options, undo when invalid ("backtrack")
 *
 * Template:
 *   void backtrack(state, choices) {
 *       if (done) { record; return; }
 *       for each choice:
 *           if valid:
 *               make choice
 *               backtrack(next state, remaining choices)
 *               undo choice   ← BACKTRACK
 *   }
 *
 * Pruning: skip invalid choices early to improve performance
 * Time: O(k^n) worst case, heavily pruned by constraints
 */
import java.util.*;

public class Backtracking {

    // 1. N-Queens — place N queens on N×N board
    static List<List<String>> solveNQueens(int n) {
        List<List<String>> result = new ArrayList<>();
        char[][] board = new char[n][n];
        for (char[] row : board) Arrays.fill(row, '.');
        btNQueens(board, 0, new HashSet<>(), new HashSet<>(), new HashSet<>(), result);
        return result;
    }
    static void btNQueens(char[][] board, int row, Set<Integer> cols,
                           Set<Integer> diag1, Set<Integer> diag2, List<List<String>> result) {
        if (row == board.length) {
            List<String> solution = new ArrayList<>();
            for (char[] r : board) solution.add(new String(r));
            result.add(solution); return;
        }
        for (int col = 0; col < board.length; col++) {
            int d1 = row - col, d2 = row + col;
            if (cols.contains(col) || diag1.contains(d1) || diag2.contains(d2)) continue;
            board[row][col] = 'Q'; cols.add(col); diag1.add(d1); diag2.add(d2);
            btNQueens(board, row+1, cols, diag1, diag2, result);
            board[row][col] = '.'; cols.remove(col); diag1.remove(d1); diag2.remove(d2);
        }
    }

    // 2. Sudoku Solver
    static boolean solveSudoku(char[][] board) {
        for (int r = 0; r < 9; r++) for (int c = 0; c < 9; c++) {
            if (board[r][c] != '.') continue;
            for (char d = '1'; d <= '9'; d++) {
                if (isValidSudoku(board, r, c, d)) {
                    board[r][c] = d;
                    if (solveSudoku(board)) return true;
                    board[r][c] = '.';
                }
            }
            return false; // no valid digit found
        }
        return true; // all cells filled
    }
    static boolean isValidSudoku(char[][] b, int row, int col, char d) {
        for (int i = 0; i < 9; i++) {
            if (b[row][i] == d) return false;
            if (b[i][col] == d) return false;
            int r = 3*(row/3) + i/3, c = 3*(col/3) + i%3;
            if (b[r][c] == d) return false;
        }
        return true;
    }

    // 3. Word search in grid
    static boolean exist(char[][] board, String word) {
        int rows = board.length, cols = board[0].length;
        for (int r = 0; r < rows; r++) for (int c = 0; c < cols; c++)
            if (dfsWord(board, word, r, c, 0, rows, cols)) return true;
        return false;
    }
    static boolean dfsWord(char[][] b, String w, int r, int c, int idx, int rows, int cols) {
        if (idx == w.length()) return true;
        if (r<0||r>=rows||c<0||c>=cols||b[r][c]!=w.charAt(idx)) return false;
        char temp = b[r][c]; b[r][c] = '#'; // mark visited
        boolean found = dfsWord(b,w,r+1,c,idx+1,rows,cols) || dfsWord(b,w,r-1,c,idx+1,rows,cols)
                     || dfsWord(b,w,r,c+1,idx+1,rows,cols) || dfsWord(b,w,r,c-1,idx+1,rows,cols);
        b[r][c] = temp; // restore
        return found;
    }

    // 4. Palindrome partitioning
    static List<List<String>> partition(String s) {
        List<List<String>> result = new ArrayList<>();
        btPartition(s, 0, new ArrayList<>(), result);
        return result;
    }
    static void btPartition(String s, int start, List<String> path, List<List<String>> result) {
        if (start == s.length()) { result.add(new ArrayList<>(path)); return; }
        for (int end = start+1; end <= s.length(); end++) {
            String sub = s.substring(start, end);
            if (isPalin(sub)) {
                path.add(sub);
                btPartition(s, end, path, result);
                path.remove(path.size()-1);
            }
        }
    }
    static boolean isPalin(String s) {
        int l=0, r=s.length()-1;
        while (l<r) if (s.charAt(l++)!=s.charAt(r--)) return false;
        return true;
    }

    // 5. Letter combinations of phone number
    static List<String> letterCombinations(String digits) {
        if (digits.isEmpty()) return new ArrayList<>();
        String[] map = {"","","abc","def","ghi","jkl","mno","pqrs","tuv","wxyz"};
        List<String> result = new ArrayList<>();
        btPhone(digits, 0, map, new StringBuilder(), result);
        return result;
    }
    static void btPhone(String digits, int idx, String[] map, StringBuilder cur, List<String> result) {
        if (idx == digits.length()) { result.add(cur.toString()); return; }
        for (char c : map[digits.charAt(idx)-'0'].toCharArray()) {
            cur.append(c);
            btPhone(digits, idx+1, map, cur, result);
            cur.deleteCharAt(cur.length()-1);
        }
    }

    // 6. Restore IP addresses
    static List<String> restoreIpAddresses(String s) {
        List<String> result = new ArrayList<>();
        btIP(s, 0, new ArrayList<>(), result);
        return result;
    }
    static void btIP(String s, int start, List<String> parts, List<String> result) {
        if (parts.size()==4 && start==s.length()) { result.add(String.join(".",parts)); return; }
        if (parts.size()==4 || start==s.length()) return;
        for (int len=1; len<=3 && start+len<=s.length(); len++) {
            String part = s.substring(start, start+len);
            if (part.length()>1 && part.charAt(0)=='0') break; // no leading zeros
            if (Integer.parseInt(part) > 255) break;
            parts.add(part);
            btIP(s, start+len, parts, result);
            parts.remove(parts.size()-1);
        }
    }

    // 7. Expression add operators (+, -, *)
    static List<String> addOperators(String num, int target) {
        List<String> result = new ArrayList<>();
        btOps(num, target, 0, 0, 0, new StringBuilder(), result);
        return result;
    }
    static void btOps(String num, int target, int idx, long eval, long mult, StringBuilder path, List<String> result) {
        if (idx == num.length()) { if (eval == target) result.add(path.toString()); return; }
        for (int len = 1; len <= num.length()-idx; len++) {
            String cur = num.substring(idx, idx+len);
            if (cur.length()>1 && cur.charAt(0)=='0') break;
            long n = Long.parseLong(cur);
            int pathLen = path.length();
            if (idx == 0) {
                btOps(num, target, len, n, n, path.append(cur), result);
            } else {
                btOps(num, target, idx+len, eval+n,    n,   path.append('+').append(cur), result); path.setLength(pathLen);
                btOps(num, target, idx+len, eval-n,   -n,   path.append('-').append(cur), result); path.setLength(pathLen);
                btOps(num, target, idx+len, eval-mult+mult*n, mult*n, path.append('*').append(cur), result);
            }
            path.setLength(pathLen);
        }
    }

    public static void main(String[] args) {
        System.out.println("===== BACKTRACKING PATTERN =====\n");

        List<List<String>> queens = solveNQueens(4);
        System.out.println("1. N-Queens(4): " + queens.size() + " solutions");
        queens.get(0).forEach(row -> System.out.println("   " + row));

        char[][] sudoku = {
            {'5','3','.','.','7','.','.','.','.'},{'6','.','.','1','9','5','.','.','.'},
            {'.','9','8','.','.','.','.','6','.'},{'8','.','.','.','6','.','.','.','3'},
            {'4','.','.','8','.','3','.','.','1'},{'7','.','.','.','2','.','.','.','6'},
            {'.','6','.','.','.','.','2','8','.'},{'.','.','.','4','1','9','.','.','5'},
            {'.','.','.','.','8','.','.','7','9'}
        };
        solveSudoku(sudoku);
        System.out.println("2. Sudoku solved first row: " + new String(sudoku[0]));

        char[][] wordBoard = {{'A','B','C','E'},{'S','F','C','S'},{'A','D','E','E'}};
        System.out.println("3. wordSearch(ABCCED) = " + exist(wordBoard, "ABCCED"));
        System.out.println("   wordSearch(ABCB)   = " + exist(wordBoard, "ABCB"));

        System.out.println("4. partition(aab) = " + partition("aab"));
        System.out.println("5. letterCombinations(23) = " + letterCombinations("23"));
        System.out.println("6. restoreIpAddresses(25525511135) = " + restoreIpAddresses("25525511135"));
        System.out.println("7. addOperators(\"123\", 6) = " + addOperators("123", 6));
    }
}
