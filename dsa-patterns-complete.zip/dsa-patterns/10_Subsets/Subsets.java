/**
 * PATTERN 10: SUBSETS / COMBINATIONS (BFS Expansion)
 * ====================================================
 * Use when: generate all subsets, permutations, combinations
 * Key insight (BFS): for each element, add to all existing subsets
 * Key insight (DFS/backtrack): explore include/exclude at each step
 *
 * BFS Template:
 *   result = [[]]
 *   for each num:
 *       newSubsets = for each existing subset: add num to copy
 *       result.addAll(newSubsets)
 *
 * Time: O(2^n)  Space: O(2^n)
 */
import java.util.*;

public class Subsets {

    // 1. All subsets (no duplicates)
    static List<List<Integer>> subsets(int[] nums) {
        List<List<Integer>> result = new ArrayList<>();
        result.add(new ArrayList<>());
        for (int num : nums) {
            int size = result.size();
            for (int i = 0; i < size; i++) {
                List<Integer> sub = new ArrayList<>(result.get(i));
                sub.add(num);
                result.add(sub);
            }
        }
        return result;
    }

    // 2. Subsets with duplicates
    static List<List<Integer>> subsetsWithDup(int[] nums) {
        Arrays.sort(nums);
        List<List<Integer>> result = new ArrayList<>();
        result.add(new ArrayList<>());
        int start = 0, end = 0;
        for (int i = 0; i < nums.length; i++) {
            start = (i > 0 && nums[i] == nums[i - 1]) ? end : 0; // skip dup, only add to last batch
            end = result.size();
            for (int j = start; j < end; j++) {
                List<Integer> sub = new ArrayList<>(result.get(j));
                sub.add(nums[i]);
                result.add(sub);
            }
        }
        return result;
    }

    // 3. Permutations (no duplicates)
    static List<List<Integer>> permute(int[] nums) {
        List<List<Integer>> result = new ArrayList<>();
        backtrackPermute(nums, new boolean[nums.length], new ArrayList<>(), result);
        return result;
    }
    static void backtrackPermute(int[] nums, boolean[] used, List<Integer> cur, List<List<Integer>> result) {
        if (cur.size() == nums.length) { result.add(new ArrayList<>(cur)); return; }
        for (int i = 0; i < nums.length; i++) {
            if (used[i]) continue;
            used[i] = true; cur.add(nums[i]);
            backtrackPermute(nums, used, cur, result);
            used[i] = false; cur.remove(cur.size() - 1);
        }
    }

    // 4. Permutations with duplicates
    static List<List<Integer>> permuteUnique(int[] nums) {
        Arrays.sort(nums);
        List<List<Integer>> result = new ArrayList<>();
        backtrackPermuteUnique(nums, new boolean[nums.length], new ArrayList<>(), result);
        return result;
    }
    static void backtrackPermuteUnique(int[] nums, boolean[] used, List<Integer> cur, List<List<Integer>> result) {
        if (cur.size() == nums.length) { result.add(new ArrayList<>(cur)); return; }
        for (int i = 0; i < nums.length; i++) {
            if (used[i]) continue;
            if (i > 0 && nums[i] == nums[i-1] && !used[i-1]) continue; // skip dup
            used[i] = true; cur.add(nums[i]);
            backtrackPermuteUnique(nums, used, cur, result);
            used[i] = false; cur.remove(cur.size() - 1);
        }
    }

    // 5. Combinations: choose k from 1..n
    static List<List<Integer>> combine(int n, int k) {
        List<List<Integer>> result = new ArrayList<>();
        backtrackCombine(1, n, k, new ArrayList<>(), result);
        return result;
    }
    static void backtrackCombine(int start, int n, int k, List<Integer> cur, List<List<Integer>> result) {
        if (cur.size() == k) { result.add(new ArrayList<>(cur)); return; }
        for (int i = start; i <= n - (k - cur.size()) + 1; i++) { // pruning
            cur.add(i);
            backtrackCombine(i + 1, n, k, cur, result);
            cur.remove(cur.size() - 1);
        }
    }

    // 6. Combination sum (can reuse elements)
    static List<List<Integer>> combinationSum(int[] candidates, int target) {
        Arrays.sort(candidates);
        List<List<Integer>> result = new ArrayList<>();
        backtrackCombSum(candidates, 0, target, new ArrayList<>(), result);
        return result;
    }
    static void backtrackCombSum(int[] c, int start, int remaining, List<Integer> cur, List<List<Integer>> result) {
        if (remaining == 0) { result.add(new ArrayList<>(cur)); return; }
        for (int i = start; i < c.length && c[i] <= remaining; i++) {
            cur.add(c[i]);
            backtrackCombSum(c, i, remaining - c[i], cur, result); // i not i+1 (reuse allowed)
            cur.remove(cur.size() - 1);
        }
    }

    // 7. Combination sum II (no reuse, may have dups)
    static List<List<Integer>> combinationSum2(int[] candidates, int target) {
        Arrays.sort(candidates);
        List<List<Integer>> result = new ArrayList<>();
        backtrackCombSum2(candidates, 0, target, new ArrayList<>(), result);
        return result;
    }
    static void backtrackCombSum2(int[] c, int start, int rem, List<Integer> cur, List<List<Integer>> result) {
        if (rem == 0) { result.add(new ArrayList<>(cur)); return; }
        for (int i = start; i < c.length && c[i] <= rem; i++) {
            if (i > start && c[i] == c[i-1]) continue; // skip dups at same level
            cur.add(c[i]);
            backtrackCombSum2(c, i + 1, rem - c[i], cur, result);
            cur.remove(cur.size() - 1);
        }
    }

    // 8. Generate all valid parentheses
    static List<String> generateParentheses(int n) {
        List<String> result = new ArrayList<>();
        backtrackParens(n, 0, 0, new StringBuilder(), result);
        return result;
    }
    static void backtrackParens(int n, int open, int close, StringBuilder cur, List<String> result) {
        if (cur.length() == 2 * n) { result.add(cur.toString()); return; }
        if (open < n)      { cur.append('('); backtrackParens(n, open+1, close, cur, result); cur.deleteCharAt(cur.length()-1); }
        if (close < open)  { cur.append(')'); backtrackParens(n, open, close+1, cur, result); cur.deleteCharAt(cur.length()-1); }
    }

    public static void main(String[] args) {
        System.out.println("===== SUBSETS PATTERN =====\n");

        System.out.println("1. subsets([1,2,3]) = " + subsets(new int[]{1,2,3}));
        System.out.println("2. subsetsWithDup([1,3,3]) = " + subsetsWithDup(new int[]{1,3,3}));
        System.out.println("3. permute([1,2,3]).size = " + permute(new int[]{1,2,3}).size());
        System.out.println("   permute([1,2,3]) = " + permute(new int[]{1,2,3}));
        System.out.println("4. permuteUnique([1,1,2]) = " + permuteUnique(new int[]{1,1,2}));
        System.out.println("5. combine(4,2) = " + combine(4, 2));
        System.out.println("6. combinationSum([2,3,6,7], 7) = " + combinationSum(new int[]{2,3,6,7}, 7));
        System.out.println("7. combinationSum2([10,1,2,7,6,5], 8) = " + combinationSum2(new int[]{10,1,2,7,6,5}, 8));
        System.out.println("8. generateParentheses(3) = " + generateParentheses(3));
    }
}
