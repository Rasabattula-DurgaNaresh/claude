# 100 Tree DFS Problems — Complete Java Solutions

> **100 Problems · 5 Java files · 5 PNG diagrams · O(n) O(h) all core patterns**

---

## Diagram Index

| Diagram | Covers |
|---------|--------|
| `diagrams/01_three_dfs_orders.png` | Side-by-side preorder/inorder/postorder with numbered visit order |
| `diagrams/02_path_backtracking.png` | Path Sum II backtracking template + Max Path Sum gain concept |
| `diagrams/03_lca_diameter_bst.png` | LCA algorithm, Diameter with path highlight, BST range validation |
| `diagrams/04_modifications_advanced.png` | Flatten to linked list, House Robber III DP, Serialize/Deserialize |
| `diagrams/05_decision_tree.png` | Complete decision guide: traversal→path→modification→LCA patterns |

## Project Structure

```
tree-dfs-100/
├── pom.xml
├── diagrams/           ← 5 PNG flow diagrams
├── docs/               ← This guide
└── src/main/java/com/treedfs/
    ├── utils/      TreeNode.java          (shared: TreeNode + NaryNode + DLLNode)
    ├── basic/      BasicDFS.java          (B1-10: traversals + Morris)
    ├── path/       PathProblems.java      (P1-10 paths + D1-10 depth)
    ├── ancestor/   AncestorBacktrack.java (A1-10 + BT1-10 + BST1-10)
    └── modify/     ModifyAdvanced.java    (M1-10 + AD1-10 + LC1-10 + IN1-10)
```

**Run:**
```bash
mvn compile exec:java -Dexec.mainClass="com.treedfs.basic.BasicDFS"
mvn compile exec:java -Dexec.mainClass="com.treedfs.path.PathProblems"
mvn compile exec:java -Dexec.mainClass="com.treedfs.ancestor.AncestorBacktrack"
mvn compile exec:java -Dexec.mainClass="com.treedfs.modify.ModifyAdvanced"
```

---

# Core DFS Templates

## Template 1 — Recursive DFS (void, collect result)
```java
// TIME: O(n)  SPACE: O(h) call stack  h=height
void dfs(TreeNode node, /* context */ ...) {
    if (node == null) return;         // base case

    // PREORDER: process HERE → visit before children
    process(node);

    dfs(node.left,  /* ... */);
    dfs(node.right, /* ... */);

    // POSTORDER: process HERE → visit after children
    // process(node);
}
```

## Template 2 — Backtracking (path collection)
```java
void dfs(TreeNode node, List<Integer> path, List<List<Integer>> result) {
    if (node == null) return;
    path.add(node.val);              // CHOOSE

    if (isLeaf(node)) result.add(new ArrayList<>(path)); // snapshot
    else {
        dfs(node.left,  path, result);
        dfs(node.right, path, result);
    }

    path.remove(path.size() - 1);   // UNCHOOSE (backtrack)
}
```

## Template 3 — Return Value (post-order bottom-up)
```java
int dfs(TreeNode node) {
    if (node == null) return 0;       // base value
    int left  = dfs(node.left);       // compute from below
    int right = dfs(node.right);
    // Combine left + right + node to produce result
    globalMax = Math.max(globalMax, left + right + node.val);
    return node.val + Math.max(left, right); // return to parent
}
```

## Template 4 — Path Sum with Prefix Sums
```java
// Count paths (not necessarily root-to-leaf) summing to target
Map<Long, Integer> prefix = new HashMap<>();
prefix.put(0L, 1);

int dfs(TreeNode node, long curr, int target) {
    if (node == null) return 0;
    curr += node.val;
    int count = prefix.getOrDefault(curr - target, 0);
    prefix.merge(curr, 1, Integer::sum);   // add
    count += dfs(node.left, curr, target) + dfs(node.right, curr, target);
    prefix.merge(curr, -1, Integer::sum);  // backtrack (remove)
    return count;
}
```

## Template 5 — LCA Pattern
```java
TreeNode lca(TreeNode node, TreeNode p, TreeNode q) {
    if (node == null || node == p || node == q) return node;
    TreeNode left  = lca(node.left,  p, q);
    TreeNode right = lca(node.right, p, q);
    if (left != null && right != null) return node; // p on left, q on right
    return left != null ? left : right;             // found on one side
}
```

## Template 6 — BST Range Validation
```java
boolean isValidBST(TreeNode node, long min, long max) {
    if (node == null) return true;
    if (node.val <= min || node.val >= max) return false;
    return isValidBST(node.left,  min, node.val) &&
           isValidBST(node.right, node.val, max);
}
// Call: isValidBST(root, Long.MIN_VALUE, Long.MAX_VALUE)
```

---

# BASIC DFS TRAVERSALS (B1–B10)

## B1. Preorder Traversal ⭐
**LeetCode 144** — Root → Left → Right.

```
Tree: 1(root), 2(left), 3(right), 4,5 (children of 2), 6,7 (children of 3)
Preorder: [1,2,4,5,3,6,7]
```

**Uses:** Serialize tree, clone tree, prefix expressions, top-down processing.

---

## B2. Inorder Traversal ⭐
**LeetCode 94** — Left → Root → Right.

```
Inorder: [4,2,5,1,6,3,7]
BST inorder = SORTED sequence (fundamental BST property!)
```

---

## B3. Postorder Traversal ⭐
**LeetCode 145** — Left → Right → Root.

```
Postorder: [4,5,2,6,7,3,1]
```

**Uses:** Delete nodes (process children before parent), evaluate expressions, bottom-up computations.

---

## B5. Iterative Preorder ⭐
```java
// Push RIGHT first so LEFT is processed first (LIFO)
stack.push(root);
while (!stack.isEmpty()) {
    node = stack.pop();
    result.add(node.val);
    if (node.right != null) stack.push(node.right); // push right FIRST
    if (node.left  != null) stack.push(node.left);  // push left SECOND → processed first
}
```

---

## B6. Iterative Inorder ⭐⭐
```java
// Go as far left as possible, then pop, visit, go right
TreeNode curr = root;
while (curr != null || !stack.isEmpty()) {
    while (curr != null) { stack.push(curr); curr = curr.left; } // go left
    curr = stack.pop(); result.add(curr.val);                     // visit
    curr = curr.right;                                             // go right
}
```

---

## B7. Morris Inorder — O(1) Space ⭐⭐⭐
No stack, no recursion! Temporarily threads predecessor's right pointer.

```
For each node:
  If no left child → visit, go right
  Else: find inorder predecessor (rightmost in left subtree)
    If pred.right == null  → thread (pred.right=curr), go left
    If pred.right == curr  → unthread, visit, go right
Time: O(n)  Space: O(1)
```

---

## B9. N-ary Tree DFS
```java
void dfs(NaryNode node) {
    if (node == null) return;
    visit(node);                               // preorder
    for (NaryNode child : node.children)
        dfs(child);                            // recurse all children
}
```

---

# ROOT-TO-LEAF PATH PROBLEMS (P1–P10)

## P1. Binary Tree Paths ⭐
**LeetCode 257** — All paths as strings "1->2->5".

```java
// Accumulate path string, add to result at leaves
pathHelper(node, path + node.val + "->", result);
```

---

## P2. Path Sum ⭐
**LeetCode 112** — Does any root-to-leaf path sum to target?

```java
// At leaf: check remain == 0
// Recurse: pass remain - node.val
if (isLeaf) return node.val == target;
return hasPathSum(left, target-node.val) || hasPathSum(right, target-node.val);
```

---

## P3. Path Sum II ⭐⭐
**LeetCode 113** — All paths summing to target. Uses **backtracking**.

```
path.add(node.val)   ← choose
  [recurse left]
  [recurse right]
path.remove(last)    ← unchoose
```

---

## P4. Path Sum III ⭐⭐⭐
**LeetCode 437** — Count ANY paths (not necessarily root-to-leaf) summing to target.

**Key:** Prefix sum + HashMap. For each node, `count += prefix[curr - target]`.

```
curr = running sum from root
If (curr - target) was seen before → there's a subpath with that sum!
```

---

## P5. Sum Root to Leaf Numbers ⭐
**LeetCode 129** — Each path forms a number (e.g., 1→2→3 = 123).

```java
curr = curr*10 + node.val; // shift and add digit
if (isLeaf) return curr;
```

---

## P6. Root to Leaf Binary Numbers ⭐
**LeetCode 1022** — Binary values instead of decimal.

```java
curr = curr*2 + node.val; // shift left and OR bit
```

---

## P8/P9. Max/Min Root to Leaf Sum
```java
// Max: propagate max choice at each node
return node.val + Math.max(maxSum(left), maxSum(right));
// Min: propagate min choice
return node.val + Math.min(minSum(left), minSum(right));
```

---

# TREE DEPTH & HEIGHT (D1–D10)

## D1. Maximum Depth ⭐
**LeetCode 104** — `1 + max(depth(left), depth(right))`

---

## D2. Minimum Depth ⭐
**LeetCode 111** — CRITICAL: handle single-child nodes!

```java
if (left  == null) return 1 + minDepth(right); // no left → must go right
if (right == null) return 1 + minDepth(left);  // no right → must go left
return 1 + Math.min(minDepth(left), minDepth(right));
```

**Common mistake:** `1 + min(depth(left), depth(right))` gives wrong answer for single-child nodes!

---

## D4. Diameter of Binary Tree ⭐⭐
**LeetCode 543** — Longest path between ANY two nodes.

```java
// At each node: diameter candidate = left_height + right_height
// Return: 1 + max(left, right) for parent
int diameter = 0; // global
int height(node) {
    int l = height(left), r = height(right);
    diameter = max(diameter, l + r); // update global
    return 1 + max(l, r);
}
```

---

## D5. Balanced Binary Tree ⭐
**LeetCode 110** — Return -1 for unbalanced (early termination).

```java
// Return height if balanced, -1 if not
int balancedHeight(node) {
    int l = balancedHeight(left);  if (l == -1) return -1; // propagate failure
    int r = balancedHeight(right); if (r == -1) return -1;
    if (Math.abs(l-r) > 1) return -1; // unbalanced here
    return 1 + max(l, r);
}
```

---

## D8. Maximum Width ⭐⭐
**LeetCode 662** — BFS with index tracking. `width = last_idx - first_idx + 1`.

---

## D10. Tree Tilt ⭐
**LeetCode 563** — `tilt(node) = |sum(left) - sum(right)|`. Post-order accumulation.

---

# ANCESTOR & RELATIONSHIP (A1–A10)

## A1. LCA of BST ⭐
**LeetCode 235** — Use BST property directly (no need to search both sides).

```java
if (p < node && q < node) → LCA in left subtree
if (p > node && q > node) → LCA in right subtree
else → current node IS the LCA (split point)
```

---

## A2. LCA of Binary Tree ⭐⭐
**LeetCode 236** — Post-order: if both sides return non-null → current is LCA.

```java
TreeNode left  = lca(node.left,  p, q);
TreeNode right = lca(node.right, p, q);
if (left != null && right != null) return node; // LCA!
return left != null ? left : right;
```

---

## A4. Distance Between Two Nodes
`dist(p, q) = depth(p) + depth(q) - 2 * depth(LCA(p,q))`

---

## A9. Subtree of Another Tree ⭐
**LeetCode 572** — For each node in root, check if it matches subRoot using isSameTree.

---

## A10. Same Tree ⭐
**LeetCode 100** — Check structure AND values simultaneously.

```java
if (p == null && q == null) return true;
if (p == null || q == null || p.val != q.val) return false;
return isSameTree(p.left, q.left) && isSameTree(p.right, q.right);
```

---

# DFS WITH BACKTRACKING (BT1–BT10)

## BT3. Binary Tree Maximum Path Sum ⭐⭐⭐
**LeetCode 124** — Most important DFS problem!

```java
// At each node: "gain" = max(0, left_gain) + max(0, right_gain) + node.val
// Update global max with gain through this node
// Return to parent: node.val + max(left_gain, right_gain, 0)

int maxGain(node) {
    int left  = Math.max(0, maxGain(left));   // discard if negative
    int right = Math.max(0, maxGain(right));
    globalMax = max(globalMax, left + right + node.val);
    return node.val + Math.max(left, right);  // single branch to parent
}
```

---

## BT4. Smallest String From Leaf ⭐⭐
**LeetCode 988** — Prepend character at each step (building string from leaf upward).

---

## BT5. Pseudo-Palindromic Paths ⭐⭐
**LeetCode 1457** — Use bitmask to track digit parity. Path is palindromic iff at most one bit set.

```java
bitmask ^= (1 << node.val);  // toggle bit
if (isLeaf) return (bitmask & (bitmask-1)) == 0 ? 1 : 0; // at most one bit
```

---

# BST SPECIFIC DFS (BST1–BST10)

## BST1. Validate BST ⭐⭐
**LeetCode 98** — Pass valid range `[min, max]` downward.

```
Left child gets: [min, node.val]
Right child gets: [node.val, max]
```

---

## BST2. Recover BST ⭐⭐⭐
**LeetCode 99** — Inorder DFS finds exactly two violations in a swapped BST.

```
Sorted: [1,2,3,4,5,6,7]
Swapped 2 and 6: [1,6,3,4,5,2,7]
Violation 1: prev(6) > curr(3) → first = 6
Violation 2: prev(5) > curr(2) → second = 2
Swap first.val with second.val
```

---

## BST3. Sorted Array to BST ⭐
**LeetCode 108** — Always pick middle as root → guaranteed height-balanced.

---

## BST6. Kth Smallest ⭐
**LeetCode 230** — Inorder gives sorted order; stop at kth.

---

## BST8. Range Sum of BST ⭐
**LeetCode 938** — Prune branches outside [lo, hi] range.

```java
if (node.val < lo)  return rangeSumBST(right, lo, hi); // skip entire left
if (node.val > hi)  return rangeSumBST(left,  lo, hi); // skip entire right
return node.val + rangeSumBST(left, lo, hi) + rangeSumBST(right, lo, hi);
```

---

## BST10. Delete Node in BST ⭐⭐
**LeetCode 450** — Three cases:
1. Node is leaf → return null
2. One child → return that child
3. Two children → replace with inorder successor (min of right subtree)

---

# TREE MODIFICATION (M1–M10)

## M1. Invert Binary Tree ⭐
**LeetCode 226** — Swap children at every node.

```java
TreeNode tmp = root.left; root.left = root.right; root.right = tmp;
invertTree(root.left); invertTree(root.right);
```

---

## M2. Flatten Binary Tree to Linked List ⭐⭐
**LeetCode 114** — Preorder sequence → right-only linked list.

```java
// Iterative: for each node, find rightmost of left subtree
// Thread: rightmost.right = node.right
// Then: node.right = node.left, node.left = null
```

---

## M3/M4. Serialize/Deserialize ⭐⭐⭐
**LeetCode 297** — Preorder DFS with "#" for null.

```java
// Serialize: root val + serialize(left) + serialize(right)
// Deserialize: queue of tokens, recursively build
// "1,2,#,#,3,#,#," → tree
```

---

## M7. Trim BST ⭐
**LeetCode 669** — Prune recursively.

```java
if (node.val < low)  return trimBST(node.right, low, high); // entire left is too small
if (node.val > high) return trimBST(node.left,  low, high); // entire right is too large
```

---

# ADVANCED DFS (AD1–AD10)

## AD1. House Robber III ⭐⭐
**LeetCode 337** — Tree DP: return pair `[rob_this, skip_this]`.

```java
int[] robDP(TreeNode node) {
    if (node == null) return {0, 0};
    int[] l = robDP(left), r = robDP(right);
    int rob  = node.val + l[1] + r[1];            // rob here, skip children
    int skip = max(l[0],l[1]) + max(r[0],r[1]);   // skip here, best of children
    return {rob, skip};
}
return max(result[0], result[1]);
```

---

## AD2. Maximum Product Split ⭐⭐
**LeetCode 1339** — Try every edge cut. `product = subtree_sum × (total - subtree_sum)`.

---

## AD3. Count Complete Tree Nodes ⭐⭐
**LeetCode 222** — O(log²n): if left height == right height → perfect subtree (2^h-1 nodes).

---

## AD4. Find Duplicate Subtrees ⭐⭐
**LeetCode 652** — Serialize each subtree, store in HashMap. Report when count == 2.

---

## AD5. Binary Tree Cameras ⭐⭐⭐
**LeetCode 968** — Greedy post-order. States: 0=uncovered, 1=has camera, 2=covered.

```
if child is 0 (uncovered) → place camera here (return 1)
if child is 1 (has camera) → covered (return 2)
else (covered) → wait for parent (return 0)
```

---

## AD6. Distribute Coins ⭐⭐
**LeetCode 979** — Excess coins must travel. `moves += |excess_left| + |excess_right|`.

```java
int excess = node.val - 1 + excess_from_left + excess_from_right;
moves += Math.abs(excess_left) + Math.abs(excess_right);
```

---

## AD8. Construct from Pre+Inorder ⭐⭐⭐
**LeetCode 105** — Root from preorder, find in inorder to split left/right.

---

# LEETCODE QUICK REFERENCE

| # | Problem | Pattern | Time | Space |
|---|---------|---------|------|-------|
| 94  | Inorder Traversal | Recursive / Iterative / Morris | O(n) | O(h)/O(1) |
| 104 | Max Depth | DFS return int | O(n) | O(h) |
| 110 | Balanced Tree | DFS return -1 if unbalanced | O(n) | O(h) |
| 112 | Path Sum | DFS subtract target | O(n) | O(h) |
| 113 | Path Sum II | Backtracking | O(n²) | O(n) |
| 124 | Max Path Sum | Post-order global max | O(n) | O(h) |
| 236 | LCA Binary Tree | Post-order return early | O(n) | O(h) |
| 98  | Validate BST | Range DFS | O(n) | O(h) |
| 114 | Flatten | Reverse post-order | O(n) | O(h) |
| 543 | Diameter | Height DFS + global | O(n) | O(h) |
| 437 | Path Sum III | Prefix sum + hashmap | O(n) | O(n) |
| 297 | Serialize/Deser | Preorder DFS | O(n) | O(n) |
| 337 | House Robber III | Tree DP pair | O(n) | O(h) |
| 652 | Duplicate Subtrees | Serialize + map | O(n²) | O(n) |
| 968 | Binary Cameras | Greedy post-order | O(n) | O(h) |

---

# INTERVIEW PROBLEMS (IN1–IN10)

| # | Scenario | Maps To | Key |
|---|----------|---------|-----|
| IN1 | Employee hierarchy | N-ary preorder | DFS levels |
| IN2 | Folder structure | N-ary DFS path | Track full path |
| IN3 | Org chart reporting | N-ary subtree | Find + DFS k levels |
| IN4 | File system traversal | N-ary DFS | Leaves = files |
| IN5 | DOM tree traversal | N-ary preorder | Build HTML string |
| IN6 | Decision tree eval | Binary post-order | AND/OR nodes |
| IN7 | Game skill tree | N-ary BFS/DFS | Level cap |
| IN8 | Family tree | Ancestor DFS | Relationship depth |
| IN9 | XML/JSON parsing | N-ary DFS | Serialize |
| IN10 | Menu navigation | N-ary search | Find + path |

---

# DFS vs BFS Decision

```
Choose DFS when:
  ✓ Path from root to leaf needed (all root-to-leaf problems)
  ✓ Height/depth computation (recursive bottom-up)
  ✓ BST operations (ordered properties, inorder)
  ✓ Ancestor relationships (LCA, parent tracking)
  ✓ Tree modification (flatten, invert, delete)
  ✓ Backtracking problems
  ✓ Tree DP (House Robber, Max Path Sum)

Choose BFS when:
  ✓ Level-by-level output needed
  ✓ Right/Left side view (per level)
  ✓ Minimum depth (stop at first leaf)
  ✓ Next right pointers
  ✓ Multi-source spread (burn tree)
```

---

# Traversal Order Selection

```
PREORDER  (Root→L→R): serialize, clone, prefix, top-down DP
INORDER   (L→Root→R): BST → sorted, recover BST, kth element
POSTORDER (L→R→Root): delete, evaluate, height, diameter, LCA
```

*100 Tree DFS Problems — Complete Java Solutions | O(n) Time | O(h) Space*
