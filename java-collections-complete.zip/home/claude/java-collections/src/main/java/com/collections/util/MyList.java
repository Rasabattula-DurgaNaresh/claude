package com.collections.util;

/**
 * Ordered, index-based collection — mirrors java.util.List
 */
public interface MyList<E> extends MyCollection<E> {
    void    add(E element);
    void    add(int index, E element);
    E       get(int index);
    E       set(int index, E element);
    E       remove(int index);
    boolean remove(Object o);
    int     indexOf(Object o);
    int     lastIndexOf(Object o);
    MyList<E> subList(int from, int to);
    void    sort();          // natural ordering
}