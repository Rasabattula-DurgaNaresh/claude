package com.collections.map;

import com.collections.util.MyMap;
import java.util.*;

/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  MyHashMap<K,V> — Hash Table with Separate Chaining                 ║
 * ╠══════════════════════════════════════════════════════════════════════╣
 * ║  INTERNAL STRUCTURE:                                                 ║
 * ║    Entry<K,V>[] table  — array of linked lists (buckets)            ║
 * ║    float loadFactor    — resize when size > capacity * loadFactor   ║
 * ║    int capacity        — number of buckets (always power of 2)      ║
 * ║                                                                      ║
 * ║  HOW IT WORKS:                                                       ║
 * ║    put(key, val):                                                    ║
 * ║      1. hash = spread(key.hashCode())                               ║
 * ║      2. bucket = hash & (capacity - 1)      ← fast modulo           ║
 * ║      3. Walk chain in bucket[hash]                                  ║
 * ║         a. If key exists: update value                               ║
 * ║         b. Else: prepend new entry to chain                         ║
 * ║      4. If size > capacity * loadFactor: resize to capacity * 2    ║
 * ║                                                                      ║
 * ║  HASH SPREADING (Java 8 trick):                                     ║
 * ║    h = key.hashCode()                                               ║
 * ║    h ^= (h >>> 16)   ← mix high bits into low bits                 ║
 * ║    This reduces collisions when capacity is a power of 2           ║
 * ║                                                                      ║
 * ║  TIME COMPLEXITY:                                                    ║
 * ║    put/get/remove  O(1) average, O(n) worst (all keys same bucket) ║
 * ║    keySet/values   O(n)                                             ║
 * ║                                                                      ║
 * ║  SPACE: O(n + capacity)                                             ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 */
@SuppressWarnings("unchecked")
public class MyHashMap<K, V> implements MyMap<K, V> {

    // ── Inner Entry (linked-list node per bucket) ─────────────────────────
    static class Entry<K, V> implements MyMap.Entry<K, V> {
        final K   key;
        final int hash;   // cached hash (avoids recompute on resize)
        V         value;
        Entry<K,V> next;  // chain within bucket

        Entry(K key, int hash, V value, Entry<K, V> next) {
            this.key = key; this.hash = hash;
            this.value = value; this.next = next;
        }

        @Override public K getKey()        { return key; }
        @Override public V getValue()      { return value; }
        @Override public V setValue(V v)   { V old = value; value = v; return old; }
        @Override public String toString() { return key + "=" + value; }
    }

    // ── Constants ─────────────────────────────────────────────────────────
    private static final int   DEFAULT_CAPACITY    = 16;
    private static final float DEFAULT_LOAD_FACTOR = 0.75f;
    private static final int   MAX_CAPACITY        = 1 << 30;

    // ── Fields ────────────────────────────────────────────────────────────
    private Entry<K,V>[] table;
    private int          size;
    private final float  loadFactor;
    private int          threshold;    // next resize at this size
    private int          resizeCount;  // for diagnostics

    public MyHashMap() {
        this(DEFAULT_CAPACITY, DEFAULT_LOAD_FACTOR);
    }

    public MyHashMap(int initialCapacity) {
        this(initialCapacity, DEFAULT_LOAD_FACTOR);
    }

    public MyHashMap(int initialCapacity, float loadFactor) {
        this.loadFactor = loadFactor;
        int cap = nextPowerOfTwo(initialCapacity);
        this.table     = new Entry[cap];
        this.threshold = (int)(cap * loadFactor);
    }

    // ── Core operations ───────────────────────────────────────────────────

    @Override
    public V put(K key, V value) {
        int hash   = spread(key == null ? 0 : key.hashCode());
        int bucket = hash & (table.length - 1);    // fast: equivalent to hash % capacity

        // Search chain for existing key
        for (Entry<K, V> e = table[bucket]; e != null; e = e.next) {
            if (e.hash == hash && (e.key == key || (key != null && key.equals(e.key)))) {
                V old = e.value;
                e.value = value;   // update existing
                return old;
            }
        }

        // Prepend new entry to chain (O(1) — no need to walk to end)
        table[bucket] = new Entry<>(key, hash, value, table[bucket]);
        size++;

        if (size > threshold) resize();
        return null;
    }

    @Override
    public V get(K key) {
        Entry<K, V> e = getEntry(key);
        return e == null ? null : e.value;
    }

    @Override
    public V remove(K key) {
        int hash   = spread(key == null ? 0 : key.hashCode());
        int bucket = hash & (table.length - 1);
        Entry<K, V> prev = null;

        for (Entry<K, V> e = table[bucket]; e != null; prev = e, e = e.next) {
            if (e.hash == hash && (e.key == key || (key != null && key.equals(e.key)))) {
                if (prev == null) table[bucket] = e.next;
                else              prev.next = e.next;
                size--;
                return e.value;
            }
        }
        return null;
    }

    @Override
    public boolean containsKey(K key) { return getEntry(key) != null; }

    @Override
    public boolean containsValue(V value) {
        for (Entry<K, V> bucket : table) {
            for (Entry<K, V> e = bucket; e != null; e = e.next) {
                if (value == null ? e.value == null : value.equals(e.value)) return true;
            }
        }
        return false;
    }

    @Override
    public V getOrDefault(K key, V defaultValue) {
        Entry<K, V> e = getEntry(key);
        return e == null ? defaultValue : e.value;
    }

    private Entry<K, V> getEntry(K key) {
        int hash   = spread(key == null ? 0 : key.hashCode());
        int bucket = hash & (table.length - 1);
        for (Entry<K, V> e = table[bucket]; e != null; e = e.next) {
            if (e.hash == hash && (e.key == key || (key != null && key.equals(e.key))))
                return e;
        }
        return null;
    }

    // ── Resize ────────────────────────────────────────────────────────────

    /**
     * Double capacity and rehash all entries.
     * O(n) — each entry rehashed once.
     * After resize: threshold updated for next resize.
     */
    private void resize() {
        int newCap = table.length >= MAX_CAPACITY ? MAX_CAPACITY : table.length * 2;
        Entry<K, V>[] newTable = new Entry[newCap];

        for (Entry<K, V> bucket : table) {
            for (Entry<K, V> e = bucket; e != null; ) {
                Entry<K, V> next    = e.next;
                int newBucket       = e.hash & (newCap - 1);
                e.next              = newTable[newBucket];  // prepend
                newTable[newBucket] = e;
                e = next;
            }
        }

        table     = newTable;
        threshold = newCap >= MAX_CAPACITY ? Integer.MAX_VALUE : (int)(newCap * loadFactor);
        resizeCount++;
    }

    /**
     * Hash spreading — mixes high bits into low bits.
     * Reduces clustering when keys differ only in high bits.
     * Java 8 HashMap uses exact same technique.
     */
    private static int spread(int h) {
        return h ^ (h >>> 16);
    }

    /** Round up to nearest power of two. */
    private static int nextPowerOfTwo(int n) {
        if (n <= 1) return 1;
        n--;
        n |= n >> 1;  n |= n >> 2;  n |= n >> 4;
        n |= n >> 8;  n |= n >> 16;
        return n + 1;
    }

    // ── Views ─────────────────────────────────────────────────────────────
    @Override
    public Set<K> keySet() {
        Set<K> keys = new HashSet<>();
        for (Entry<K,V> b : table)
            for (Entry<K,V> e = b; e != null; e = e.next) keys.add(e.key);
        return keys;
    }

    @Override
    public Collection<V> values() {
        List<V> vals = new ArrayList<>();
        for (Entry<K,V> b : table)
            for (Entry<K,V> e = b; e != null; e = e.next) vals.add(e.value);
        return vals;
    }

    @Override
    public Set<MyMap.Entry<K,V>> entrySet() {
        Set<MyMap.Entry<K,V>> entries = new HashSet<>();
        for (Entry<K,V> b : table)
            for (Entry<K,V> e = b; e != null; e = e.next) entries.add(e);
        return entries;
    }

    @Override
    public int  size()      { return size; }
    @Override
    public boolean isEmpty(){ return size == 0; }

    @Override
    public void clear() {
        Arrays.fill(table, null);
        size = 0;
    }

    // ── Diagnostics ───────────────────────────────────────────────────────
    public String toDebugString() {
        int maxChain = 0;
        int usedBuckets = 0;
        for (Entry<K,V> b : table) {
            if (b != null) {
                usedBuckets++;
                int len = 0;
                for (Entry<K,V> e = b; e != null; e = e.next) len++;
                maxChain = Math.max(maxChain, len);
            }
        }
        return String.format("MyHashMap{size=%d, capacity=%d, loadFactor=%.2f, " +
            "usedBuckets=%d/%-3d (%.0f%%), maxChain=%d, resizes=%d}",
            size, table.length, loadFactor,
            usedBuckets, table.length,
            usedBuckets * 100.0 / table.length,
            maxChain, resizeCount);
    }

    @Override
    public String toString() {
        if (size == 0) return "{}";
        StringBuilder sb = new StringBuilder("{");
        boolean first = true;
        for (Entry<K,V> b : table) {
            for (Entry<K,V> e = b; e != null; e = e.next) {
                if (!first) sb.append(", ");
                sb.append(e.key).append("=").append(e.value);
                first = false;
            }
        }
        return sb.append("}").toString();
    }
}