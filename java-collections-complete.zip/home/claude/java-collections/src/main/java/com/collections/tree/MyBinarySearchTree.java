package com.collections.tree;

import java.util.*;

/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  MyBinarySearchTree<K extends Comparable<K>, V>                     ║
 * ╠══════════════════════════════════════════════════════════════════════╣
 * ║  BST PROPERTY: left < node < right at every node                   ║
 * ║                                                                      ║
 * ║  TIME COMPLEXITY:                                                    ║
 * ║    Average case: O(log n) for search/insert/delete                 ║
 * ║    Worst case:   O(n) if tree degenerates (sorted input)           ║
 * ║    (Use TreeMap / AVLTree for guaranteed O(log n))                 ║
 * ║                                                                      ║
 * ║  TRAVERSALS: In-order, Pre-order, Post-order, Level-order (BFS)   ║
 * ║  OPERATIONS: height, depth, isBST, LCA, kthSmallest               ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 */
public class MyBinarySearchTree<K extends Comparable<K>, V> {

    // ── Node ─────────────────────────────────────────────────────────────
    public static class Node<K, V> {
        K key; V value;
        Node<K,V> left, right;

        Node(K key, V value) { this.key = key; this.value = value; }

        @Override public String toString() { return key + "=" + value; }
    }

    protected Node<K,V> root;
    protected int size;

    // ── Insert ────────────────────────────────────────────────────────────
    public void put(K key, V value) {
        root = putRec(root, key, value);
    }

    private Node<K,V> putRec(Node<K,V> node, K key, V value) {
        if (node == null) { size++; return new Node<>(key, value); }
        int cmp = key.compareTo(node.key);
        if      (cmp < 0) node.left  = putRec(node.left,  key, value);
        else if (cmp > 0) node.right = putRec(node.right, key, value);
        else              node.value = value;   // update existing
        return node;
    }

    // ── Search ────────────────────────────────────────────────────────────
    public V get(K key) {
        Node<K,V> n = root;
        while (n != null) {
            int cmp = key.compareTo(n.key);
            if      (cmp < 0) n = n.left;
            else if (cmp > 0) n = n.right;
            else              return n.value;
        }
        return null;
    }

    public boolean containsKey(K key) { return get(key) != null; }

    // ── Delete ────────────────────────────────────────────────────────────
    public void remove(K key) {
        root = removeRec(root, key);
    }

    private Node<K,V> removeRec(Node<K,V> node, K key) {
        if (node == null) return null;
        int cmp = key.compareTo(node.key);
        if      (cmp < 0) { node.left  = removeRec(node.left,  key); }
        else if (cmp > 0) { node.right = removeRec(node.right, key); }
        else {
            size--;
            if (node.left  == null) return node.right;  // Case 1: no left child
            if (node.right == null) return node.left;   // Case 2: no right child
            // Case 3: two children — replace with in-order successor
            Node<K,V> successor = minNode(node.right);
            node.key   = successor.key;
            node.value = successor.value;
            node.right = removeRec(node.right, successor.key);
            size++;   // compensate for decrement in recursive call
        }
        return node;
    }

    private Node<K,V> minNode(Node<K,V> n) {
        while (n.left != null) n = n.left;
        return n;
    }

    // ── Min / Max ─────────────────────────────────────────────────────────
    public K minKey() { if (root==null) throw new NoSuchElementException(); return minNode(root).key; }
    public K maxKey() {
        if (root == null) throw new NoSuchElementException();
        Node<K,V> n = root;
        while (n.right != null) n = n.right;
        return n.key;
    }

    // ── Traversals ────────────────────────────────────────────────────────

    /** In-order: LEFT → ROOT → RIGHT  → gives sorted output */
    public List<K> inOrder() {
        List<K> result = new ArrayList<>();
        inOrderRec(root, result);
        return result;
    }
    private void inOrderRec(Node<K,V> n, List<K> list) {
        if (n == null) return;
        inOrderRec(n.left, list);
        list.add(n.key);
        inOrderRec(n.right, list);
    }

    /** Pre-order: ROOT → LEFT → RIGHT  → used for tree copy / serialise */
    public List<K> preOrder() {
        List<K> result = new ArrayList<>();
        preOrderRec(root, result);
        return result;
    }
    private void preOrderRec(Node<K,V> n, List<K> list) {
        if (n == null) return;
        list.add(n.key);
        preOrderRec(n.left, list);
        preOrderRec(n.right, list);
    }

    /** Post-order: LEFT → RIGHT → ROOT  → used for tree deletion */
    public List<K> postOrder() {
        List<K> result = new ArrayList<>();
        postOrderRec(root, result);
        return result;
    }
    private void postOrderRec(Node<K,V> n, List<K> list) {
        if (n == null) return;
        postOrderRec(n.left, list);
        postOrderRec(n.right, list);
        list.add(n.key);
    }

    /** Level-order (BFS) — returns nodes level by level */
    public List<List<K>> levelOrder() {
        List<List<K>> result = new ArrayList<>();
        if (root == null) return result;
        Queue<Node<K,V>> queue = new LinkedList<>();
        queue.offer(root);
        while (!queue.isEmpty()) {
            int levelSize = queue.size();
            List<K> level = new ArrayList<>();
            for (int i = 0; i < levelSize; i++) {
                Node<K,V> n = queue.poll();
                level.add(n.key);
                if (n.left  != null) queue.offer(n.left);
                if (n.right != null) queue.offer(n.right);
            }
            result.add(level);
        }
        return result;
    }

    // ── Tree Properties ────────────────────────────────────────────────────

    /** Height = longest path from root to leaf. Empty tree = -1. */
    public int height() { return heightRec(root); }
    private int heightRec(Node<K,V> n) {
        if (n == null) return -1;
        return 1 + Math.max(heightRec(n.left), heightRec(n.right));
    }

    /** Depth of a key — distance from root. -1 if not found. */
    public int depth(K key) {
        Node<K,V> curr = root;
        int d = 0;
        while (curr != null) {
            int cmp = key.compareTo(curr.key);
            if (cmp == 0) return d;
            curr = (cmp < 0) ? curr.left : curr.right;
            d++;
        }
        return -1;
    }

    /** Count of leaf nodes. */
    public int leafCount() { return leafCountRec(root); }
    private int leafCountRec(Node<K,V> n) {
        if (n == null) return 0;
        if (n.left == null && n.right == null) return 1;
        return leafCountRec(n.left) + leafCountRec(n.right);
    }

    /** Validate BST property (in-order must be strictly ascending). */
    public boolean isBST() {
        List<K> keys = inOrder();
        for (int i = 1; i < keys.size(); i++) {
            if (keys.get(i).compareTo(keys.get(i-1)) <= 0) return false;
        }
        return true;
    }

    /** Kth smallest element (1-based). */
    public K kthSmallest(int k) {
        int[] count = {0};
        K[]   result = (K[]) new Comparable[1];
        kthSmallestRec(root, k, count, result);
        if (result[0] == null) throw new NoSuchElementException("k=" + k + " out of bounds");
        return result[0];
    }
    private void kthSmallestRec(Node<K,V> n, int k, int[] count, K[] result) {
        if (n == null || count[0] >= k) return;
        kthSmallestRec(n.left, k, count, result);
        if (++count[0] == k) { result[0] = n.key; return; }
        kthSmallestRec(n.right, k, count, result);
    }

    /** Lowest Common Ancestor of two keys. */
    public K lca(K a, K b) {
        Node<K,V> curr = root;
        while (curr != null) {
            if (a.compareTo(curr.key) < 0 && b.compareTo(curr.key) < 0)
                curr = curr.left;
            else if (a.compareTo(curr.key) > 0 && b.compareTo(curr.key) > 0)
                curr = curr.right;
            else
                return curr.key;   // divergence point = LCA
        }
        return null;
    }

    public int  size()    { return size; }
    public boolean isEmpty(){ return size == 0; }
    public void clear()   { root = null; size = 0; }

    /** Pretty-print tree structure. */
    public String toTreeString() {
        if (root == null) return "(empty)";
        StringBuilder sb = new StringBuilder();
        printTree(sb, root, "", false);
        return sb.toString();
    }
    private void printTree(StringBuilder sb, Node<K,V> n, String prefix, boolean isRight) {
        if (n == null) return;
        sb.append(prefix).append(isRight ? "├── " : "└── ").append(n.key).append("\n");
        String child = prefix + (isRight ? "│   " : "    ");
        printTree(sb, n.right, child, true);
        printTree(sb, n.left,  child, false);
    }
}