package com.collections.list;

import com.collections.util.MyList;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  MyLinkedList<E> — Doubly Linked List (like java.util.LinkedList)   ║
 * ╠══════════════════════════════════════════════════════════════════════╣
 * ║  INTERNAL STRUCTURE:                                                 ║
 * ║    Node<E> { data, prev, next }   — each element is a heap object   ║
 * ║    Node<E> head  — sentinel/dummy head (no data, simplifies logic)  ║
 * ║    Node<E> tail  — sentinel/dummy tail                              ║
 * ║    int size                                                          ║
 * ║                                                                      ║
 * ║  Using sentinel nodes means we NEVER need null checks for           ║
 * ║  head/tail — head.next = first real node, tail.prev = last          ║
 * ║                                                                      ║
 * ║  TIME COMPLEXITY:                                                    ║
 * ║    addFirst/addLast   O(1) — just pointer manipulation              ║
 * ║    add(E)             O(1) — add to tail                            ║
 * ║    add(i, E)          O(n) — must walk to index i                   ║
 * ║    get(i)             O(n) — must walk from head or tail            ║
 * ║    remove(0)/getLast  O(1) — head/tail direct access               ║
 * ║    remove(i)          O(n) — walk to node, then O(1) unlink        ║
 * ║    contains(E)        O(n) — linear scan                            ║
 * ║                                                                      ║
 * ║  SPACE: O(n) — more overhead than ArrayList (each node = 3 fields) ║
 * ║  vs ArrayList: better for frequent insertions at head/middle,      ║
 * ║                worse for random access                              ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 */
public class MyLinkedList<E> implements MyList<E> {

    // ── Inner Node class ──────────────────────────────────────────────────
    private static class Node<E> {
        E       data;
        Node<E> prev;
        Node<E> next;

        Node(E data, Node<E> prev, Node<E> next) {
            this.data = data;
            this.prev = prev;
            this.next = next;
        }
    }

    // ── Internal state ────────────────────────────────────────────────────
    private final Node<E> head;   // sentinel head — data = null, always present
    private final Node<E> tail;   // sentinel tail — data = null, always present
    private int size;

    public MyLinkedList() {
        head = new Node<>(null, null, null);  // dummy head
        tail = new Node<>(null, head, null);  // dummy tail
        head.next = tail;
    }

    // ── Append & Prepend ──────────────────────────────────────────────────

    /** Add element at tail — O(1). */
    @Override
    public void add(E element) {
        addLast(element);
    }

    /** O(1) — link new node between tail.prev and tail. */
    public void addLast(E element) {
        linkBefore(element, tail);
    }

    /** O(1) — link new node between head and head.next. */
    public void addFirst(E element) {
        linkBefore(element, head.next);
    }

    /**
     * Core link operation: insert newData before 'succ' node.
     * head ↔ ... ↔ pred ↔ succ  becomes  head ↔ ... ↔ pred ↔ newNode ↔ succ
     */
    private void linkBefore(E data, Node<E> succ) {
        Node<E> pred    = succ.prev;
        Node<E> newNode = new Node<>(data, pred, succ);
        pred.next = newNode;
        succ.prev = newNode;
        size++;
    }

    /**
     * Unlink a node from the list.
     * pred ↔ node ↔ succ  becomes  pred ↔ succ
     */
    private E unlink(Node<E> node) {
        E data       = node.data;
        node.prev.next = node.next;
        node.next.prev = node.prev;
        node.data = null;   // help GC
        node.prev = null;
        node.next = null;
        size--;
        return data;
    }

    @Override
    public void add(int index, E element) {
        checkIndexForAdd(index);
        linkBefore(element, nodeAt(index));
    }

    public E removeFirst() {
        if (isEmpty()) throw new NoSuchElementException("List is empty");
        return unlink(head.next);
    }

    public E removeLast() {
        if (isEmpty()) throw new NoSuchElementException("List is empty");
        return unlink(tail.prev);
    }

    public E getFirst() {
        if (isEmpty()) throw new NoSuchElementException();
        return head.next.data;
    }

    public E getLast() {
        if (isEmpty()) throw new NoSuchElementException();
        return tail.prev.data;
    }

    // ── Index-based access ─────────────────────────────────────────────────

    /**
     * Navigate to node at index.
     * Optimisation: start from head if index < size/2, else from tail.
     * Halves the traversal on average — still O(n) worst case.
     */
    private Node<E> nodeAt(int index) {
        if (index < size / 2) {
            Node<E> curr = head.next;
            for (int i = 0; i < index; i++) curr = curr.next;
            return curr;
        } else {
            Node<E> curr = tail.prev;
            for (int i = size - 1; i > index; i--) curr = curr.prev;
            return curr;
        }
    }

    @Override
    public E get(int index) {
        checkIndex(index);
        return nodeAt(index).data;
    }

    @Override
    public E set(int index, E element) {
        checkIndex(index);
        Node<E> node = nodeAt(index);
        E old = node.data;
        node.data = element;
        return old;
    }

    @Override
    public E remove(int index) {
        checkIndex(index);
        return unlink(nodeAt(index));
    }

    @Override
    public boolean remove(Object o) {
        // Walk from head to find first match, then unlink
        for (Node<E> curr = head.next; curr != tail; curr = curr.next) {
            if (o == null ? curr.data == null : o.equals(curr.data)) {
                unlink(curr);
                return true;
            }
        }
        return false;
    }

    @Override
    public int indexOf(Object o) {
        int idx = 0;
        for (Node<E> curr = head.next; curr != tail; curr = curr.next, idx++) {
            if (o == null ? curr.data == null : o.equals(curr.data)) return idx;
        }
        return -1;
    }

    @Override
    public int lastIndexOf(Object o) {
        int idx = size - 1;
        for (Node<E> curr = tail.prev; curr != head; curr = curr.prev, idx--) {
            if (o == null ? curr.data == null : o.equals(curr.data)) return idx;
        }
        return -1;
    }

    @Override
    public boolean contains(Object o) { return indexOf(o) != -1; }

    @Override
    public int  size()        { return size; }
    @Override
    public boolean isEmpty()  { return size == 0; }

    @Override
    public void clear() {
        // Null out all node references to help GC
        for (Node<E> curr = head.next; curr != tail; ) {
            Node<E> next = curr.next;
            curr.data = null; curr.prev = null; curr.next = null;
            curr = next;
        }
        head.next = tail;
        tail.prev = head;
        size = 0;
    }

    @Override
    public Object[] toArray() {
        Object[] result = new Object[size];
        int i = 0;
        for (Node<E> curr = head.next; curr != tail; curr = curr.next) result[i++] = curr.data;
        return result;
    }

    @Override
    public MyList<E> subList(int from, int to) {
        if (from < 0 || to > size || from > to)
            throw new IndexOutOfBoundsException();
        MyLinkedList<E> sub = new MyLinkedList<>();
        Node<E> curr = nodeAt(from);
        for (int i = from; i < to; i++, curr = curr.next) sub.add(curr.data);
        return sub;
    }

    /** Insertion sort — O(n²) but stable. Good for nearly-sorted lists. */
    @Override
    public void sort() {
        if (size <= 1) return;
        // Collect to array, sort, rewrite
        Object[] arr = toArray();
        java.util.Arrays.sort(arr, (a, b) -> ((Comparable) a).compareTo(b));
        Node<E> curr = head.next;
        for (Object o : arr) { curr.data = (E) o; curr = curr.next; }
    }

    // ── Reverse ─────────────────────────────────────────────────────────────
    public void reverse() {
        Node<E> curr = head.next;
        while (curr != tail) {
            // Swap prev and next
            Node<E> tmp = curr.prev;
            curr.prev = curr.next;
            curr.next = tmp;
            curr = curr.prev; // move to what was next
        }
        // Fix sentinel pointers
        Node<E> tmp = head.next;
        head.next = tail.prev;
        tail.prev = tmp;
        head.next.prev = head;
        tail.prev.next = tail;
    }

    // ── Iterator ────────────────────────────────────────────────────────────
    @Override
    public Iterator<E> iterator() {
        return new Iterator<E>() {
            Node<E> cursor = head.next;
            @Override public boolean hasNext() { return cursor != tail; }
            @Override public E next() {
                if (!hasNext()) throw new NoSuchElementException();
                E data = cursor.data;
                cursor = cursor.next;
                return data;
            }
        };
    }

    /** Descending iterator — walks from tail to head. */
    public Iterator<E> descendingIterator() {
        return new Iterator<E>() {
            Node<E> cursor = tail.prev;
            @Override public boolean hasNext() { return cursor != head; }
            @Override public E next() {
                if (!hasNext()) throw new NoSuchElementException();
                E data = cursor.data;
                cursor = cursor.prev;
                return data;
            }
        };
    }

    @Override
    public String toString() {
        if (size == 0) return "[]";
        StringBuilder sb = new StringBuilder("[");
        for (Node<E> curr = head.next; curr != tail; curr = curr.next) {
            sb.append(curr.data);
            if (curr.next != tail) sb.append(" <-> ");
        }
        return sb.append("]").toString();
    }

    @Override
    public String toDebugString() {
        return String.format("MyLinkedList{size=%d, head.next=%s, tail.prev=%s}",
            size,
            head.next != tail ? head.next.data : "null",
            tail.prev != head ? tail.prev.data : "null");
    }

    private void checkIndex(int i) {
        if (i < 0 || i >= size) throw new IndexOutOfBoundsException("Index " + i + ", size " + size);
    }
    private void checkIndexForAdd(int i) {
        if (i < 0 || i > size) throw new IndexOutOfBoundsException("Index " + i + ", size " + size);
    }
}