package com.collections.set;

import com.collections.tree.MyTreeMap;
import java.util.*;

/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  MyTreeSet<E> — Sorted Set backed by MyTreeMap (Red-Black Tree)     ║
 * ╠══════════════════════════════════════════════════════════════════════╣
 * ║  All elements kept in SORTED (natural) order.                      ║
 * ║  add/remove/contains: O(log n) guaranteed.                         ║
 * ║  Useful for: sorted unique elements, range queries, floor/ceiling  ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 */
public class MyTreeSet<E extends Comparable<E>> implements Iterable<E> {

    private static final Object PRESENT = new Object();
    private final MyTreeMap<E, Object> map;

    public MyTreeSet() { map = new MyTreeMap<>(); }

    public boolean add(E e)           { return map.put(e, PRESENT) == null; }
    public boolean remove(E e)        { return map.remove(e) == PRESENT; }
    public boolean contains(Object o) { return map.containsKey((E) o); }
    public int     size()             { return map.size(); }
    public boolean isEmpty()          { return map.isEmpty(); }
    public void    clear()            { map.clear(); }
    public E       first()            { return map.firstKey(); }
    public E       last()             { return map.lastKey(); }

    @Override
    public Iterator<E> iterator()     { return map.keySet().iterator(); }

    @Override
    public String toString()          { return map.keySet().toString(); }
}