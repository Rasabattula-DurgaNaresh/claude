package com.collections.queue;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  MyDeque<E> — Double-Ended Queue (Doubly Linked List based)         ║
 * ╠══════════════════════════════════════════════════════════════════════╣
 * ║  Supports O(1) add/remove at BOTH front and rear.                  ║
 * ║  Can function as both Stack (push/pop) and Queue (offer/poll).     ║
 * ║                                                                      ║
 * ║  REAL-WORLD USES:                                                    ║
 * ║    • Sliding window problems (max/min in window)                    ║
 * ║    • LRU cache eviction (add to rear, evict from front)            ║
 * ║    • Palindrome check                                               ║
 * ║    • Work-stealing scheduler (ForkJoinPool uses deque per thread)   ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 */
public class MyDeque<E> implements Iterable<E> {

    private static class Node<E> {
        E data; Node<E> prev, next;
        Node(E d, Node<E> p, Node<E> n) { data=d; prev=p; next=n; }
    }

    private final Node<E> head;
    private final Node<E> tail;
    private int size;

    public MyDeque() {
        head = new Node<>(null, null, null);
        tail = new Node<>(null, head, null);
        head.next = tail;
    }

    // ── Front operations ──────────────────────────────────────────────────
    public void addFirst(E e)  { linkAfter(head, e); }
    public E    removeFirst()  { if (isEmpty()) throw new NoSuchElementException(); return unlink(head.next); }
    public E    peekFirst()    { if (isEmpty()) throw new NoSuchElementException(); return head.next.data; }

    // ── Rear operations ───────────────────────────────────────────────────
    public void addLast(E e)   { linkBefore(tail, e); }
    public E    removeLast()   { if (isEmpty()) throw new NoSuchElementException(); return unlink(tail.prev); }
    public E    peekLast()     { if (isEmpty()) throw new NoSuchElementException(); return tail.prev.data; }

    // ── Queue aliases ─────────────────────────────────────────────────────
    public boolean offer(E e)  { addLast(e); return true; }
    public E       poll()      { return isEmpty() ? null : removeFirst(); }
    public E       peek()      { return isEmpty() ? null : head.next.data; }

    // ── Stack aliases ─────────────────────────────────────────────────────
    public void push(E e)      { addFirst(e); }
    public E    pop()          { return removeFirst(); }

    public boolean isEmpty()   { return size == 0; }
    public int     size()      { return size; }

    private void linkAfter(Node<E> pred, E data) {
        Node<E> succ = pred.next;
        Node<E> n    = new Node<>(data, pred, succ);
        pred.next = n;
        succ.prev = n;
        size++;
    }

    private void linkBefore(Node<E> succ, E data) {
        linkAfter(succ.prev, data);
    }

    private E unlink(Node<E> n) {
        E data = n.data;
        n.prev.next = n.next;
        n.next.prev = n.prev;
        n.data = null; n.prev = null; n.next = null;
        size--;
        return data;
    }

    @Override
    public Iterator<E> iterator() {
        return new Iterator<E>() {
            Node<E> curr = head.next;
            @Override public boolean hasNext() { return curr != tail; }
            @Override public E next() {
                if (!hasNext()) throw new NoSuchElementException();
                E d = curr.data; curr = curr.next; return d;
            }
        };
    }

    @Override
    public String toString() {
        if (isEmpty()) return "FRONT [] REAR";
        StringBuilder sb = new StringBuilder("FRONT [");
        for (Node<E> n = head.next; n != tail; n = n.next) {
            sb.append(n.data);
            if (n.next != tail) sb.append(" <-> ");
        }
        return sb.append("] REAR").toString();
    }

    /** Sliding window maximum using monotonic deque — O(n). */
    public static int[] slidingWindowMax(int[] nums, int k) {
        MyDeque<Integer> dq = new MyDeque<>();  // stores indices
        int[] result = new int[nums.length - k + 1];
        for (int i = 0; i < nums.length; i++) {
            // Remove indices out of window
            while (!dq.isEmpty() && dq.peekFirst() < i - k + 1) dq.removeFirst();
            // Remove smaller elements — they'll never be the max
            while (!dq.isEmpty() && nums[dq.peekLast()] <= nums[i]) dq.removeLast();
            dq.addLast(i);
            if (i >= k - 1) result[i - k + 1] = nums[dq.peekFirst()];
        }
        return result;
    }
}