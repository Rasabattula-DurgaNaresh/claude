package com.collections.queue;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  MyPriorityQueue<E> — Binary Min-Heap                               ║
 * ╠══════════════════════════════════════════════════════════════════════╣
 * ║  HEAP PROPERTY: data[parent] <= data[child]  (min-heap)            ║
 * ║                                                                      ║
 * ║  ARRAY MAPPING:                                                      ║
 * ║    parent(i)  = (i - 1) / 2                                        ║
 * ║    leftChild  = 2*i + 1                                            ║
 * ║    rightChild = 2*i + 2                                            ║
 * ║                                                                      ║
 * ║  Visualisation (heap of 7 elements):                               ║
 * ║         1          data[0]                                         ║
 * ║       /   \                                                         ║
 * ║      3     5       data[1], data[2]                                ║
 * ║     / \ / \                                                        ║
 * ║    4  7 6  8       data[3..6]                                      ║
 * ║                                                                      ║
 * ║  TIME COMPLEXITY:                                                    ║
 * ║    offer(E)    O(log n) — sift up                                  ║
 * ║    poll()      O(log n) — sift down                                ║
 * ║    peek()      O(1)    — root access                               ║
 * ║    contains    O(n)    — linear scan (no index)                    ║
 * ║    heapify     O(n)    — build from array (not 2*O(n log n))       ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 */
@SuppressWarnings("unchecked")
public class MyPriorityQueue<E> implements Iterable<E> {

    private Object[]   data;
    private int        size;
    private final Comparator<? super E> comparator;   // null = natural order

    public MyPriorityQueue() {
        this(16, null);
    }

    public MyPriorityQueue(Comparator<? super E> comparator) {
        this(16, comparator);
    }

    public MyPriorityQueue(int capacity, Comparator<? super E> comparator) {
        this.data       = new Object[Math.max(1, capacity)];
        this.comparator = comparator;
    }

    /**
     * Insert element — add at end, then sift up to restore heap property.
     * O(log n) — sift up at most log n levels.
     */
    public void offer(E element) {
        if (size == data.length) grow();
        data[size] = element;
        siftUp(size);
        size++;
    }

    /**
     * Remove and return minimum — O(log n).
     * 1. Swap root with last element
     * 2. Remove last (was root)
     * 3. Sift down new root to restore heap property
     */
    public E poll() {
        if (isEmpty()) throw new NoSuchElementException("Queue is empty");
        E min = (E) data[0];
        data[0] = data[--size];  // move last to root
        data[size] = null;        // help GC
        if (size > 0) siftDown(0);
        return min;
    }

    /** Peek at minimum without removing — O(1). */
    public E peek() {
        if (isEmpty()) throw new NoSuchElementException();
        return (E) data[0];
    }

    public boolean isEmpty()   { return size == 0; }
    public int     size()      { return size; }

    /**
     * Sift element at index UP until heap property restored.
     * Used after inserting at end.
     */
    private void siftUp(int idx) {
        while (idx > 0) {
            int parent = (idx - 1) / 2;
            if (compare(idx, parent) >= 0) break;  // heap property satisfied
            swap(idx, parent);
            idx = parent;
        }
    }

    /**
     * Sift element at index DOWN until heap property restored.
     * Used after removing root.
     */
    private void siftDown(int idx) {
        int half = size / 2;  // first leaf index
        while (idx < half) {
            int left  = 2 * idx + 1;
            int right = 2 * idx + 2;
            int smallest = idx;

            if (left  < size && compare(left,  smallest) < 0) smallest = left;
            if (right < size && compare(right, smallest) < 0) smallest = right;

            if (smallest == idx) break;  // heap property already satisfied
            swap(idx, smallest);
            idx = smallest;
        }
    }

    /** Build heap from existing array — O(n). */
    public static <E> MyPriorityQueue<E> heapify(E[] array) {
        MyPriorityQueue<E> pq = new MyPriorityQueue<>(array.length, null);
        System.arraycopy(array, 0, pq.data, 0, array.length);
        pq.size = array.length;
        // Sift down from last internal node to root
        for (int i = pq.size / 2 - 1; i >= 0; i--) {
            pq.siftDown(i);
        }
        return pq;
    }

    /** Heap sort — O(n log n), in-place. Returns sorted array ascending. */
    public static int[] heapSort(int[] array) {
        // Build max-heap
        int n = array.length;
        for (int i = n/2 - 1; i >= 0; i--) heapSortDown(array, n, i);
        // Extract max repeatedly
        for (int i = n - 1; i > 0; i--) {
            int tmp = array[0]; array[0] = array[i]; array[i] = tmp;
            heapSortDown(array, i, 0);
        }
        return array;
    }

    private static void heapSortDown(int[] arr, int n, int i) {
        int largest = i, l = 2*i+1, r = 2*i+2;
        if (l < n && arr[l] > arr[largest]) largest = l;
        if (r < n && arr[r] > arr[largest]) largest = r;
        if (largest != i) {
            int tmp = arr[i]; arr[i] = arr[largest]; arr[largest] = tmp;
            heapSortDown(arr, n, largest);
        }
    }

    private int compare(int i, int j) {
        if (comparator != null) return comparator.compare((E)data[i], (E)data[j]);
        return ((Comparable<E>) data[i]).compareTo((E) data[j]);
    }

    private void swap(int i, int j) {
        Object tmp = data[i]; data[i] = data[j]; data[j] = tmp;
    }

    private void grow() {
        data = Arrays.copyOf(data, data.length * 2);
    }

    public void clear()      { Arrays.fill(data, 0, size, null); size = 0; }

    @Override
    public Iterator<E> iterator() {
        // NOTE: iterator does NOT return elements in priority order
        // To drain in order, poll() repeatedly
        return new Iterator<E>() {
            int cursor = 0;
            @Override public boolean hasNext() { return cursor < size; }
            @Override public E next() {
                if (!hasNext()) throw new NoSuchElementException();
                return (E) data[cursor++];
            }
        };
    }

    @Override
    public String toString() {
        if (isEmpty()) return "[]";
        // Return in heap-array order, not priority order
        StringBuilder sb = new StringBuilder("MinHeap[");
        for (int i = 0; i < size; i++) {
            sb.append(data[i]);
            if (i < size - 1) sb.append(", ");
        }
        return sb.append("]").toString();
    }

    public String toHeapTree() {
        if (isEmpty()) return "(empty)";
        StringBuilder sb = new StringBuilder();
        printTree(sb, 0, "", false);
        return sb.toString();
    }

    private void printTree(StringBuilder sb, int idx, String prefix, boolean isRight) {
        if (idx >= size) return;
        sb.append(prefix).append(isRight ? "├── " : "└── ").append(data[idx]).append("\n");
        int l = 2*idx+1, r = 2*idx+2;
        if (l < size || r < size) {
            printTree(sb, r, prefix + (isRight ? "│   " : "    "), true);
            printTree(sb, l, prefix + (isRight ? "│   " : "    "), false);
        }
    }
}