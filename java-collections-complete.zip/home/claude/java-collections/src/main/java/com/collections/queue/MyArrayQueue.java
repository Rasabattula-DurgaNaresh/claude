package com.collections.queue;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  MyArrayQueue<E> — FIFO Queue using Circular Buffer                 ║
 * ╠══════════════════════════════════════════════════════════════════════╣
 * ║  INTERNAL STRUCTURE:                                                 ║
 * ║    Object[] data  — fixed-size ring buffer                          ║
 * ║    int head       — index of front element                          ║
 * ║    int tail       — index of next empty slot                        ║
 * ║    int size       — element count                                   ║
 * ║                                                                      ║
 * ║  CIRCULAR BUFFER TRICK:                                             ║
 * ║    Instead of shifting on dequeue (O(n)), we just advance head.     ║
 * ║    When pointers reach array end, they wrap around to 0.            ║
 * ║    tail = (tail + 1) % capacity                                     ║
 * ║                                                                      ║
 * ║  Example: capacity=5, head=3, tail=1 (wrapped)                     ║
 * ║    [E, _, _, A, B]   head=3 tail=1                                 ║
 * ║     ^         ^                                                      ║
 * ║     tail      head                                                  ║
 * ║                                                                      ║
 * ║  TIME COMPLEXITY:                                                    ║
 * ║    enqueue/offer  O(1)                                              ║
 * ║    dequeue/poll   O(1) — no shift! just advance head                ║
 * ║    peek           O(1)                                              ║
 * ║    resize         O(n) — only when full                             ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 */
@SuppressWarnings("unchecked")
public class MyArrayQueue<E> implements Iterable<E> {

    private Object[] data;
    private int head = 0;   // front of queue (dequeue from here)
    private int tail = 0;   // rear  of queue (enqueue to here)
    private int size = 0;

    public MyArrayQueue()              { this(16); }
    public MyArrayQueue(int capacity)  { this.data = new Object[Math.max(1, capacity)]; }

    /** Add to rear — O(1) amortized. */
    public void enqueue(E element) {
        if (size == data.length) resize();
        data[tail] = element;
        tail = (tail + 1) % data.length;   // circular wrap
        size++;
    }

    /** Remove from front — O(1) (circular trick). */
    public E dequeue() {
        if (isEmpty()) throw new NoSuchElementException("Queue is empty");
        E elem = (E) data[head];
        data[head] = null;                 // help GC
        head = (head + 1) % data.length;  // circular wrap
        size--;
        return elem;
    }

    /** Peek at front without removing — O(1). */
    public E peek() {
        if (isEmpty()) throw new NoSuchElementException("Queue is empty");
        return (E) data[head];
    }

    /** java.util.Queue-style aliases. */
    public boolean offer(E e)  { enqueue(e); return true; }
    public E       poll()      { return isEmpty() ? null : dequeue(); }
    public E       element()   { return peek(); }

    public boolean isEmpty()   { return size == 0; }
    public int     size()      { return size; }

    public void clear() {
        // Null out logically active slots
        for (int i = 0; i < size; i++) data[(head + i) % data.length] = null;
        head = tail = size = 0;
    }

    /**
     * Resize: copy elements to new array in correct order (head → tail).
     * After resize: head=0, tail=size, no wrap-around.
     */
    private void resize() {
        Object[] newData = new Object[data.length * 2];
        for (int i = 0; i < size; i++) {
            newData[i] = data[(head + i) % data.length];
        }
        head = 0;
        tail = size;
        data = newData;
    }

    @Override
    public Iterator<E> iterator() {
        return new Iterator<E>() {
            int count = 0;
            @Override public boolean hasNext() { return count < size; }
            @Override public E next() {
                if (!hasNext()) throw new NoSuchElementException();
                return (E) data[(head + count++) % data.length];
            }
        };
    }

    @Override
    public String toString() {
        if (isEmpty()) return "FRONT [] REAR";
        StringBuilder sb = new StringBuilder("FRONT [");
        for (int i = 0; i < size; i++) {
            sb.append(data[(head + i) % data.length]);
            if (i < size - 1) sb.append(", ");
        }
        return sb.append("] REAR").toString();
    }
}