package com.collections.set;

import java.util.Iterator;
import java.util.LinkedHashMap;

/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  MyLinkedHashSet<E> — HashSet with Insertion-Order Iteration        ║
 * ╠══════════════════════════════════════════════════════════════════════╣
 * ║  Maintains a doubly-linked list through all entries, so iteration  ║
 * ║  happens in the order elements were inserted.                       ║
 * ║  No duplicates.                                                     ║
 * ║  add/remove/contains: O(1) average                                  ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 */
public class MyLinkedHashSet<E> implements Iterable<E> {

    private static final Object PRESENT = new Object();
    // Uses java LinkedHashMap to preserve insertion order
    private final LinkedHashMap<E, Object> map;

    public MyLinkedHashSet()             { map = new LinkedHashMap<>(); }
    public MyLinkedHashSet(int capacity) { map = new LinkedHashMap<>(capacity); }

    public boolean add(E e)              { return map.put(e, PRESENT) == null; }
    public boolean remove(Object o)      { return map.remove(o) == PRESENT; }
    public boolean contains(Object o)    { return map.containsKey(o); }
    public int     size()                { return map.size(); }
    public boolean isEmpty()             { return map.isEmpty(); }
    public void    clear()               { map.clear(); }

    @Override
    public Iterator<E> iterator()        { return map.keySet().iterator(); }

    @Override
    public String toString()             { return map.keySet().toString(); }
}