package com.collections.stack;

import java.util.EmptyStackException;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  MyStack<E> — LIFO Stack backed by dynamic array                    ║
 * ╠══════════════════════════════════════════════════════════════════════╣
 * ║  All operations O(1) amortized.                                     ║
 * ║                                                                      ║
 * ║  REAL-WORLD USES:                                                    ║
 * ║    • Function call stack (recursion)                                 ║
 * ║    • Undo/Redo in editors                                           ║
 * ║    • Browser history back button                                     ║
 * ║    • Expression evaluation (postfix, infix)                         ║
 * ║    • DFS graph traversal                                            ║
 * ║    • Balanced parentheses checking                                  ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 */
@SuppressWarnings("unchecked")
public class MyStack<E> implements Iterable<E> {

    private Object[] data;
    private int      top;       // points to next empty slot (= size)

    public MyStack() {
        this.data = new Object[16];
        this.top  = 0;
    }

    /** Push element onto top — O(1) amortized. */
    public void push(E element) {
        if (top == data.length) grow();
        data[top++] = element;
    }

    /** Remove and return top element — O(1). */
    public E pop() {
        if (isEmpty()) throw new EmptyStackException();
        E elem = (E) data[--top];
        data[top] = null;   // allow GC
        return elem;
    }

    /** Return top element without removing — O(1). */
    public E peek() {
        if (isEmpty()) throw new EmptyStackException();
        return (E) data[top - 1];
    }

    /** Return element at position from top (0 = top, 1 = second from top). */
    public E peek(int fromTop) {
        if (fromTop < 0 || fromTop >= top)
            throw new IndexOutOfBoundsException("fromTop=" + fromTop + ", size=" + top);
        return (E) data[top - 1 - fromTop];
    }

    public boolean isEmpty() { return top == 0; }
    public int     size()    { return top; }

    public void clear() {
        for (int i = 0; i < top; i++) data[i] = null;
        top = 0;
    }

    public boolean contains(Object o) {
        for (int i = 0; i < top; i++) {
            if (o == null ? data[i] == null : o.equals(data[i])) return true;
        }
        return false;
    }

    /** Distance from top (0 = top). -1 if not found. */
    public int search(Object o) {
        for (int i = top - 1; i >= 0; i--) {
            if (o == null ? data[i] == null : o.equals(data[i]))
                return top - 1 - i;
        }
        return -1;
    }

    private void grow() {
        data = java.util.Arrays.copyOf(data, data.length * 2);
    }

    /** Iterator from top to bottom. */
    @Override
    public Iterator<E> iterator() {
        return new Iterator<E>() {
            int cursor = top - 1;
            @Override public boolean hasNext() { return cursor >= 0; }
            @Override public E next() {
                if (!hasNext()) throw new NoSuchElementException();
                return (E) data[cursor--];
            }
        };
    }

    @Override
    public String toString() {
        if (isEmpty()) return "[]";
        StringBuilder sb = new StringBuilder("TOP → [");
        for (int i = top - 1; i >= 0; i--) {
            sb.append(data[i]);
            if (i > 0) sb.append(", ");
        }
        return sb.append("] ← BOTTOM").toString();
    }

    // ── Applications ─────────────────────────────────────────────────────────

    /** Check if parentheses are balanced: (), [], {} */
    public static boolean isBalanced(String expr) {
        MyStack<Character> stack = new MyStack<>();
        for (char c : expr.toCharArray()) {
            if (c == '(' || c == '[' || c == '{') {
                stack.push(c);
            } else if (c == ')' || c == ']' || c == '}') {
                if (stack.isEmpty()) return false;
                char open = stack.pop();
                if (!matches(open, c)) return false;
            }
        }
        return stack.isEmpty();
    }

    private static boolean matches(char open, char close) {
        return (open == '(' && close == ')') ||
               (open == '[' && close == ']') ||
               (open == '{' && close == '}');
    }

    /** Evaluate postfix (Reverse Polish Notation) expression. */
    public static double evalPostfix(String expr) {
        MyStack<Double> stack = new MyStack<>();
        for (String token : expr.trim().split("\\s+")) {
            switch (token) {
                case "+" -> { double b=stack.pop(), a=stack.pop(); stack.push(a+b); }
                case "-" -> { double b=stack.pop(), a=stack.pop(); stack.push(a-b); }
                case "*" -> { double b=stack.pop(), a=stack.pop(); stack.push(a*b); }
                case "/" -> { double b=stack.pop(), a=stack.pop(); stack.push(a/b); }
                default  -> stack.push(Double.parseDouble(token));
            }
        }
        return stack.pop();
    }
}