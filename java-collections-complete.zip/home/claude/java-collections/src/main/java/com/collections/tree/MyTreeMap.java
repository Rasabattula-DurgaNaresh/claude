package com.collections.tree;

import com.collections.util.MyMap;
import java.util.*;

/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  MyTreeMap<K,V> — Red-Black Tree (Self-Balancing BST)               ║
 * ╠══════════════════════════════════════════════════════════════════════╣
 * ║  RED-BLACK TREE PROPERTIES:                                         ║
 * ║    1. Every node is RED or BLACK                                    ║
 * ║    2. Root is always BLACK                                          ║
 * ║    3. Every leaf (NIL sentinel) is BLACK                           ║
 * ║    4. If a node is RED, both children are BLACK (no 2 reds in row) ║
 * ║    5. All paths from any node to its NIL descendants                ║
 * ║       have the same number of BLACK nodes (black-height)           ║
 * ║                                                                      ║
 * ║  GUARANTEES:                                                         ║
 * ║    Longest path ≤ 2 × shortest path → height ≤ 2*log₂(n+1)       ║
 * ║                                                                      ║
 * ║  TIME COMPLEXITY: All operations O(log n) guaranteed               ║
 * ║    vs BST: O(n) worst case, O(h) average                           ║
 * ║    vs HashMap: O(log n) but sorted order                           ║
 * ║                                                                      ║
 * ║  ROTATIONS:                                                          ║
 * ║    Left rotation on X:          Right rotation on Y:               ║
 * ║      X              Y              Y               X               ║
 * ║     / \           / \            / \             / \             ║
 * ║    A   Y    →   X   C          X   C    →      A   Y             ║
 * ║       / \      / \           / \                  / \           ║
 * ║      B   C    A   B          A   B               B   C           ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 */
@SuppressWarnings("unchecked")
public class MyTreeMap<K extends Comparable<K>, V> implements MyMap<K, V> {

    private static final boolean RED   = true;
    private static final boolean BLACK = false;

    // ── Node ─────────────────────────────────────────────────────────────
    private static class Node<K, V> implements MyMap.Entry<K, V> {
        K     key;
        V     value;
        Node<K,V> left, right, parent;
        boolean   color;   // RED or BLACK

        Node(K key, V value, boolean color, Node<K,V> parent) {
            this.key = key; this.value = value;
            this.color = color; this.parent = parent;
        }

        @Override public K getKey()      { return key; }
        @Override public V getValue()    { return value; }
        @Override public V setValue(V v) { V old = value; value = v; return old; }
        @Override public String toString(){ return key + "=" + value + (color==RED?"(R)":"(B)"); }
    }

    private Node<K,V> root;
    private int       size;

    // ── Put (insert or update) ────────────────────────────────────────────
    @Override
    public V put(K key, V value) {
        if (root == null) {
            root = new Node<>(key, value, BLACK, null);
            size++;
            return null;
        }

        Node<K,V> parent = null;
        Node<K,V> curr   = root;
        int       cmp    = 0;

        while (curr != null) {
            parent = curr;
            cmp = key.compareTo(curr.key);
            if      (cmp < 0) curr = curr.left;
            else if (cmp > 0) curr = curr.right;
            else { V old = curr.value; curr.value = value; return old; }
        }

        // Insert new RED node
        Node<K,V> newNode = new Node<>(key, value, RED, parent);
        if (cmp < 0) parent.left  = newNode;
        else         parent.right = newNode;
        size++;

        fixInsert(newNode);   // restore RB properties
        return null;
    }

    /**
     * Fix Red-Black property after insertion.
     * Three cases (and their mirrors):
     *  Case 1: Uncle is RED → recolor parent, uncle, grandparent
     *  Case 2: Node is inner grandchild → rotate parent
     *  Case 3: Node is outer grandchild → rotate grandparent, recolor
     */
    private void fixInsert(Node<K,V> z) {
        while (z.parent != null && z.parent.color == RED) {
            Node<K,V> parent = z.parent;
            Node<K,V> grand  = parent.parent;

            if (parent == grand.left) {
                Node<K,V> uncle = grand.right;
                if (uncle != null && uncle.color == RED) {
                    // Case 1: Uncle RED — recolor
                    parent.color = BLACK;
                    uncle.color  = BLACK;
                    grand.color  = RED;
                    z = grand;
                } else {
                    if (z == parent.right) {
                        // Case 2: Triangle → convert to case 3 via rotation
                        rotateLeft(parent);
                        z = parent;
                        parent = z.parent;
                    }
                    // Case 3: Line → single rotation + recolor
                    parent.color = BLACK;
                    grand.color  = RED;
                    rotateRight(grand);
                }
            } else {
                // Mirror cases (parent is right child)
                Node<K,V> uncle = grand.left;
                if (uncle != null && uncle.color == RED) {
                    parent.color = BLACK;
                    uncle.color  = BLACK;
                    grand.color  = RED;
                    z = grand;
                } else {
                    if (z == parent.left) {
                        rotateRight(parent);
                        z = parent;
                        parent = z.parent;
                    }
                    parent.color = BLACK;
                    grand.color  = RED;
                    rotateLeft(grand);
                }
            }
        }
        root.color = BLACK;   // Property 2: root always black
    }

    /**
     * Left rotation around x:     x              y
     *   Before:  x         →   After: y         / \
     *           / \                            x   C
     *          A   y                          / \
     *             / \                        A   B
     *            B   C
     */
    private void rotateLeft(Node<K,V> x) {
        Node<K,V> y  = x.right;
        x.right      = y.left;
        if (y.left != null) y.left.parent = x;
        y.parent     = x.parent;
        if (x.parent == null)      root = y;
        else if (x == x.parent.left) x.parent.left  = y;
        else                         x.parent.right = y;
        y.left       = x;
        x.parent     = y;
    }

    private void rotateRight(Node<K,V> y) {
        Node<K,V> x  = y.left;
        y.left       = x.right;
        if (x.right != null) x.right.parent = y;
        x.parent     = y.parent;
        if (y.parent == null)      root = x;
        else if (y == y.parent.right) y.parent.right = x;
        else                          y.parent.left  = x;
        x.right      = y;
        y.parent     = x;
    }

    // ── Get ───────────────────────────────────────────────────────────────
    @Override
    public V get(K key) {
        Node<K,V> n = find(key);
        return n == null ? null : n.value;
    }

    private Node<K,V> find(K key) {
        Node<K,V> curr = root;
        while (curr != null) {
            int cmp = key.compareTo(curr.key);
            if      (cmp < 0) curr = curr.left;
            else if (cmp > 0) curr = curr.right;
            else              return curr;
        }
        return null;
    }

    // ── Remove (simplified — omitting full RB delete for brevity) ─────────
    @Override
    public V remove(K key) {
        Node<K,V> n = find(key);
        if (n == null) return null;
        V old = n.value;
        deleteNode(n);
        size--;
        return old;
    }

    private void deleteNode(Node<K,V> z) {
        // Standard BST delete with simplified RB fix
        if (z.left != null && z.right != null) {
            // Find in-order successor (smallest in right subtree)
            Node<K,V> successor = minimum(z.right);
            z.key   = successor.key;
            z.value = successor.value;
            z = successor;
        }
        Node<K,V> child = (z.left != null) ? z.left : z.right;
        if (child != null) {
            child.parent = z.parent;
            if (z.parent == null)           root = child;
            else if (z == z.parent.left)    z.parent.left = child;
            else                             z.parent.right = child;
            if (z.color == BLACK) child.color = BLACK;
        } else if (z.parent == null) {
            root = null;
        } else {
            if (z.parent != null) {
                if (z == z.parent.left)  z.parent.left  = null;
                else                     z.parent.right = null;
                z.parent = null;
            }
        }
    }

    private Node<K,V> minimum(Node<K,V> n) {
        while (n.left != null) n = n.left;
        return n;
    }

    // ── SortedMap features ────────────────────────────────────────────────
    public K firstKey() {
        if (root == null) throw new NoSuchElementException();
        return minimum(root).key;
    }

    public K lastKey() {
        if (root == null) throw new NoSuchElementException();
        Node<K,V> curr = root;
        while (curr.right != null) curr = curr.right;
        return curr.key;
    }

    /** In-order traversal gives keys in sorted ascending order. */
    private void inOrder(Node<K,V> n, List<K> keys) {
        if (n == null) return;
        inOrder(n.left, keys);
        keys.add(n.key);
        inOrder(n.right, keys);
    }

    @Override
    public boolean containsKey(K key)  { return find(key) != null; }
    @Override
    public boolean containsValue(V v)  {
        for (V val : values()) if (Objects.equals(v, val)) return true;
        return false;
    }
    @Override public int     size()    { return size; }
    @Override public boolean isEmpty() { return size == 0; }
    @Override public void    clear()   { root = null; size = 0; }

    @Override
    public Set<K> keySet() {
        List<K> keys = new ArrayList<>();
        inOrder(root, keys);
        return new LinkedHashSet<>(keys);   // preserves sorted order
    }

    @Override
    public Collection<V> values() {
        List<V> vals = new ArrayList<>();
        inOrderValues(root, vals);
        return vals;
    }

    private void inOrderValues(Node<K,V> n, List<V> vals) {
        if (n == null) return;
        inOrderValues(n.left, vals);
        vals.add(n.value);
        inOrderValues(n.right, vals);
    }

    @Override
    public Set<MyMap.Entry<K,V>> entrySet() {
        Set<MyMap.Entry<K,V>> entries = new LinkedHashSet<>();
        inOrderEntries(root, entries);
        return entries;
    }

    private void inOrderEntries(Node<K,V> n, Set<MyMap.Entry<K,V>> entries) {
        if (n == null) return;
        inOrderEntries(n.left, entries);
        entries.add(n);
        inOrderEntries(n.right, entries);
    }

    @Override
    public V getOrDefault(K key, V def) { V v = get(key); return v != null ? v : def; }

    // ── Visual tree print ─────────────────────────────────────────────────
    public String toTreeString() {
        if (root == null) return "(empty)";
        StringBuilder sb = new StringBuilder();
        printTree(sb, root, "", false);
        return sb.toString();
    }

    private void printTree(StringBuilder sb, Node<K,V> n, String prefix, boolean isRight) {
        if (n == null) return;
        sb.append(prefix).append(isRight ? "├── " : "└── ")
          .append(n.key).append(n.color == RED ? "[R]" : "[B]").append("\n");
        String child = prefix + (isRight ? "│   " : "    ");
        printTree(sb, n.right, child, true);
        printTree(sb, n.left,  child, false);
    }

    @Override
    public String toString() {
        List<String> pairs = new ArrayList<>();
        for (MyMap.Entry<K,V> e : entrySet()) pairs.add(e.getKey() + "=" + e.getValue());
        return "{" + String.join(", ", pairs) + "}";
    }
}