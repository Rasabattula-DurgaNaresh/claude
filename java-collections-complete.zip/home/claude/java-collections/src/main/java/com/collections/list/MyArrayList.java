package com.collections.list;

import com.collections.util.MyList;
import java.util.Arrays;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  MyArrayList<E> — Dynamic Array (like java.util.ArrayList)          ║
 * ╠══════════════════════════════════════════════════════════════════════╣
 * ║  INTERNAL STRUCTURE:                                                 ║
 * ║    Object[] data  — backing array, doubles when full                 ║
 * ║    int size       — number of logical elements                       ║
 * ║    int modCount   — modification counter (fail-fast iterator)        ║
 * ║                                                                      ║
 * ║  TIME COMPLEXITY:                                                    ║
 * ║    add(E)         O(1) amortized — O(n) when resize                 ║
 * ║    add(i, E)      O(n) — must shift elements right                  ║
 * ║    get(i)         O(1) — direct array access                        ║
 * ║    remove(i)      O(n) — must shift elements left                   ║
 * ║    contains(E)    O(n) — linear scan                                ║
 * ║    indexOf(E)     O(n) — linear scan                                ║
 * ║                                                                      ║
 * ║  SPACE: O(n) — capacity grows as 1.5x or 2x (here 2x)              ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 */
@SuppressWarnings("unchecked")
public class MyArrayList<E> implements MyList<E> {

    // ── Internal state ────────────────────────────────────────────────────
    private static final int DEFAULT_CAPACITY = 10;
    private Object[]  data;        // backing array (raw array — no generics at runtime)
    private int       size;        // logical element count
    private int       modCount;    // mutation counter for fail-fast iteration

    // ── Constructors ──────────────────────────────────────────────────────
    public MyArrayList() {
        this.data = new Object[DEFAULT_CAPACITY];
        this.size = 0;
    }

    public MyArrayList(int initialCapacity) {
        if (initialCapacity < 0) throw new IllegalArgumentException("Capacity: " + initialCapacity);
        this.data = new Object[initialCapacity == 0 ? 1 : initialCapacity];
    }

    // ── Core operations ───────────────────────────────────────────────────

    /**
     * Append element to end.
     * Amortized O(1): copy only when capacity exhausted.
     */
    @Override
    public void add(E element) {
        ensureCapacity(size + 1);
        data[size++] = element;
        modCount++;
    }

    /**
     * Insert at index — shifts all subsequent elements right.
     * O(n) worst case (insert at index 0).
     */
    @Override
    public void add(int index, E element) {
        checkIndexForAdd(index);
        ensureCapacity(size + 1);
        // Shift elements[index..size-1] one position right
        System.arraycopy(data, index, data, index + 1, size - index);
        data[index] = element;
        size++;
        modCount++;
    }

    /**
     * Direct array access — O(1).
     */
    @Override
    public E get(int index) {
        checkIndex(index);
        return (E) data[index];
    }

    /**
     * Replace element at index, return old value — O(1).
     */
    @Override
    public E set(int index, E element) {
        checkIndex(index);
        E old = (E) data[index];
        data[index] = element;
        return old;
    }

    /**
     * Remove by index — shifts elements left.
     * O(n) worst case (remove at index 0).
     */
    @Override
    public E remove(int index) {
        checkIndex(index);
        E old = (E) data[index];
        int numShifted = size - index - 1;
        if (numShifted > 0) {
            System.arraycopy(data, index + 1, data, index, numShifted);
        }
        data[--size] = null;   // allow GC to reclaim removed element
        modCount++;
        return old;
    }

    /**
     * Remove first occurrence of element — O(n) scan + O(n) shift.
     */
    @Override
    public boolean remove(Object o) {
        int idx = indexOf(o);
        if (idx == -1) return false;
        remove(idx);
        return true;
    }

    /**
     * Linear scan for first occurrence — O(n).
     * Handles null correctly.
     */
    @Override
    public int indexOf(Object o) {
        for (int i = 0; i < size; i++) {
            if (o == null ? data[i] == null : o.equals(data[i])) return i;
        }
        return -1;
    }

    @Override
    public int lastIndexOf(Object o) {
        for (int i = size - 1; i >= 0; i--) {
            if (o == null ? data[i] == null : o.equals(data[i])) return i;
        }
        return -1;
    }

    @Override
    public boolean contains(Object o) { return indexOf(o) != -1; }

    @Override
    public int size()        { return size; }

    @Override
    public boolean isEmpty() { return size == 0; }

    @Override
    public void clear() {
        Arrays.fill(data, 0, size, null); // help GC
        size = 0;
        modCount++;
    }

    @Override
    public Object[] toArray() {
        return Arrays.copyOf(data, size);
    }

    /**
     * Sublist view — backed by underlying array section.
     * Modifications to sublist reflect in original (like java.util.List.subList).
     */
    @Override
    public MyList<E> subList(int from, int to) {
        if (from < 0 || to > size || from > to)
            throw new IndexOutOfBoundsException("from=" + from + " to=" + to);
        MyArrayList<E> sub = new MyArrayList<>(to - from);
        for (int i = from; i < to; i++) sub.add(get(i));
        return sub;
    }

    /**
     * In-place merge sort — O(n log n), stable.
     * Requires elements to implement Comparable.
     */
    @Override
    public void sort() {
        mergeSort(0, size - 1);
        modCount++;
    }

    private void mergeSort(int left, int right) {
        if (left >= right) return;
        int mid = (left + right) / 2;
        mergeSort(left, mid);
        mergeSort(mid + 1, right);
        merge(left, mid, right);
    }

    private void merge(int left, int mid, int right) {
        Object[] temp = Arrays.copyOfRange(data, left, right + 1);
        int i = 0, j = mid - left + 1, k = left;
        while (i <= mid - left && j <= right - left) {
            Comparable<Object> ci = (Comparable<Object>) temp[i];
            if (ci.compareTo(temp[j]) <= 0) data[k++] = temp[i++];
            else                             data[k++] = temp[j++];
        }
        while (i <= mid - left) data[k++] = temp[i++];
        while (j <= right - left) data[k++] = temp[j++];
    }

    // ── Capacity management ────────────────────────────────────────────────

    /**
     * Grow array to at least minCapacity.
     * New capacity = max(minCapacity, current * 2).
     */
    private void ensureCapacity(int minCapacity) {
        if (minCapacity <= data.length) return;
        int newCapacity = Math.max(minCapacity, data.length * 2);
        data = Arrays.copyOf(data, newCapacity);
    }

    /** Shrink backing array to fit actual size (useful after many removes). */
    public void trimToSize() {
        if (size < data.length) data = Arrays.copyOf(data, size);
    }

    public int capacity() { return data.length; }

    // ── Validation ──────────────────────────────────────────────────────────
    private void checkIndex(int i) {
        if (i < 0 || i >= size)
            throw new IndexOutOfBoundsException("Index " + i + ", size " + size);
    }
    private void checkIndexForAdd(int i) {
        if (i < 0 || i > size)
            throw new IndexOutOfBoundsException("Index " + i + ", size " + size);
    }

    // ── Iterator (fail-fast) ────────────────────────────────────────────────
    @Override
    public Iterator<E> iterator() {
        return new FailFastIterator();
    }

    private class FailFastIterator implements Iterator<E> {
        private int    cursor      = 0;
        private int    lastRet     = -1;
        private final int expectedMod = modCount;  // snapshot at creation

        @Override
        public boolean hasNext() { return cursor < size; }

        @Override
        public E next() {
            checkForConcurrentMod();
            if (!hasNext()) throw new NoSuchElementException();
            lastRet = cursor;
            return (E) data[cursor++];
        }

        @Override
        public void remove() {
            if (lastRet < 0) throw new IllegalStateException();
            checkForConcurrentMod();
            MyArrayList.this.remove(lastRet);
            cursor = lastRet;
            lastRet = -1;
            // modCount already updated; update expectedMod to match
        }

        private void checkForConcurrentMod() {
            if (modCount != expectedMod)
                throw new ConcurrentModificationException(
                    "List was modified during iteration");
        }
    }

    // ── Debug / toString ────────────────────────────────────────────────────
    @Override
    public String toString() {
        if (size == 0) return "[]";
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < size; i++) {
            sb.append(data[i]);
            if (i < size - 1) sb.append(", ");
        }
        return sb.append("]").toString();
    }

    @Override
    public String toDebugString() {
        return String.format("MyArrayList{size=%d, capacity=%d, data=%s}",
            size, data.length, toString());
    }
}