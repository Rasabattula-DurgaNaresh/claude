package com.collections;

import com.collections.graph.MyGraph;
import com.collections.list.MyArrayList;
import com.collections.list.MyLinkedList;
import com.collections.map.LRUCache;
import com.collections.map.MyHashMap;
import com.collections.queue.MyArrayQueue;
import com.collections.queue.MyDeque;
import com.collections.queue.MyPriorityQueue;
import com.collections.set.MyHashSet;
import com.collections.set.MyLinkedHashSet;
import com.collections.set.MyTreeSet;
import com.collections.stack.MyStack;
import com.collections.tree.MyAVLTree;
import com.collections.tree.MyBinarySearchTree;
import com.collections.tree.MyTreeMap;
import com.collections.tree.MyTrie;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * ╔══════════════════════════════════════════════════════════════════════════╗
 * ║           JAVA COLLECTIONS — Complete Custom Implementations            ║
 * ╠══════════════════════════════════════════════════════════════════════════╣
 * ║  20 Collection Classes built from scratch:                              ║
 * ║                                                                          ║
 * ║  LISTS                                                                  ║
 * ║    01. MyArrayList     — Dynamic array, O(1) get, O(n) insert          ║
 * ║    02. MyLinkedList    — Doubly linked, O(1) addFirst/Last, O(n) get   ║
 * ║                                                                          ║
 * ║  STACK / QUEUE                                                          ║
 * ║    03. MyStack         — LIFO, array-backed, O(1) push/pop             ║
 * ║    04. MyArrayQueue    — FIFO, circular buffer, O(1) enqueue/dequeue   ║
 * ║    05. MyDeque         — Double-ended, O(1) both ends                  ║
 * ║    06. MyPriorityQueue — Binary min-heap, O(log n) offer/poll          ║
 * ║                                                                          ║
 * ║  MAPS                                                                   ║
 * ║    07. MyHashMap       — Hash table, separate chaining, O(1) avg       ║
 * ║    08. MyLinkedHashMap — HashMap + insertion-order list                 ║
 * ║    09. MyTreeMap       — Red-Black Tree, O(log n) sorted order         ║
 * ║    10. LRUCache        — HashMap + DLL, O(1) get/put, evicts LRU       ║
 * ║                                                                          ║
 * ║  SETS                                                                   ║
 * ║    11. MyHashSet       — HashMap-backed, O(1) add/contains             ║
 * ║    12. MyLinkedHashSet — Insertion-order, O(1) add/contains            ║
 * ║    13. MyTreeSet       — TreeMap-backed, O(log n) sorted order         ║
 * ║                                                                          ║
 * ║  TREES                                                                  ║
 * ║    14. MyBinarySearchTree — BST, in/pre/post/level-order, LCA, kth     ║
 * ║    15. MyAVLTree          — Self-balancing, 4 rotation cases            ║
 * ║    16. MyTreeMap          — Red-Black Tree (full RB properties)         ║
 * ║    17. MyTrie             — Prefix tree, autocomplete, LCP              ║
 * ║                                                                          ║
 * ║  GRAPH                                                                  ║
 * ║    18. MyGraph            — BFS, DFS, Dijkstra, cycle, topo sort       ║
 * ║                                                                          ║
 * ║  UTILITIES                                                              ║
 * ║    19. MyCollection (interface)                                         ║
 * ║    20. MyList / MyMap (interfaces)                                      ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 */
public class CollectionsDemo {

    // ── Banner ────────────────────────────────────────────────────────────────
    static void header(String title) {
        System.out.println();
        System.out.println("╔══════════════════════════════════════════════════════════╗");
        System.out.printf( "║  %-56s║%n", title);
        System.out.println("╚══════════════════════════════════════════════════════════╝");
    }

    static void section(String title) {
        System.out.println("\n  ── " + title + " " + "─".repeat(Math.max(0, 50 - title.length())));
    }

    // ═════════════════════════════════════════════════════════════════════════
    // MODULE 1 — ARRAYLIST
    // ═════════════════════════════════════════════════════════════════════════
    static void demoArrayList() {
        header("01. MyArrayList — Dynamic Array");

        MyArrayList<Integer> list = new MyArrayList<>();

        section("Basic add / get / set");
        for (int i = 1; i <= 8; i++) list.add(i * 10);
        System.out.println("  After add(10..80) : " + list);
        System.out.println("  get(0)            : " + list.get(0));
        System.out.println("  get(7)            : " + list.get(7));
        System.out.println("  set(3, 999)       : old=" + list.set(3, 999) + " → " + list);

        section("Insert / Remove at index");
        list.add(2, 55);
        System.out.println("  add(2, 55)        : " + list);
        list.remove(2);
        System.out.println("  remove(2)         : " + list);
        list.remove(Integer.valueOf(999));
        System.out.println("  remove(999)       : " + list);

        section("Search");
        System.out.println("  indexOf(60)       : " + list.indexOf(60));
        System.out.println("  contains(30)      : " + list.contains(30));
        System.out.println("  contains(999)     : " + list.contains(999));

        section("SubList + Sort");
        System.out.println("  subList(1,4)      : " + list.subList(1, 4));
        MyArrayList<Integer> nums = new MyArrayList<>();
        new java.util.Random(42).ints(8, 1, 100).forEach(nums::add);
        System.out.println("  Before sort       : " + nums);
        nums.sort();
        System.out.println("  After mergeSort   : " + nums);

        section("Fail-Fast Iterator");
        try {
            for (Integer x : list) {
                if (x == 20) list.add(999); // should throw ConcurrentModificationException
            }
        } catch (java.util.ConcurrentModificationException e) {
            System.out.println("  ConcurrentModificationException caught ✓");
        }

        section("Capacity management");
        System.out.println("  " + list.toDebugString());
        list.trimToSize();
        System.out.println("  After trimToSize  : " + list.toDebugString());
    }

    // ═════════════════════════════════════════════════════════════════════════
    // MODULE 2 — LINKEDLIST
    // ═════════════════════════════════════════════════════════════════════════
    static void demoLinkedList() {
        header("02. MyLinkedList — Doubly Linked List (Sentinel Nodes)");

        MyLinkedList<String> list = new MyLinkedList<>();

        section("AddFirst / AddLast / Add at index");
        list.addLast("C");
        list.addLast("D");
        list.addFirst("B");
        list.addFirst("A");
        list.add(2, "X");
        System.out.println("  [A, B, X, C, D]   : " + list);
        System.out.println("  getFirst()         : " + list.getFirst());
        System.out.println("  getLast()          : " + list.getLast());
        System.out.println("  get(2)             : " + list.get(2));

        section("Remove / indexOf");
        list.remove("X");
        System.out.println("  After remove(X)    : " + list);
        list.removeFirst();
        System.out.println("  After removeFirst  : " + list);
        list.removeLast();
        System.out.println("  After removeLast   : " + list);
        System.out.println("  indexOf(C)         : " + list.indexOf("C"));

        section("Reverse");
        list.addFirst("A"); list.addLast("D");
        System.out.println("  Before reverse     : " + list);
        list.reverse();
        System.out.println("  After reverse      : " + list);

        section("Descending iterator");
        System.out.print("  Desc iter          : ");
        java.util.Iterator<String> desc = list.descendingIterator();
        while (desc.hasNext()) System.out.print(desc.next() + " ");
        System.out.println();

        section("Debug info");
        System.out.println("  " + list.toDebugString());
    }

    // ═════════════════════════════════════════════════════════════════════════
    // MODULE 3 — STACK
    // ═════════════════════════════════════════════════════════════════════════
    static void demoStack() {
        header("03. MyStack — LIFO Stack (Array-backed)");

        MyStack<Integer> stack = new MyStack<>();

        section("Push / Pop / Peek");
        for (int v : new int[]{10, 20, 30, 40, 50}) {
            stack.push(v);
            System.out.printf("  push(%-2d) → %s%n", v, stack);
        }
        System.out.println("  peek()    = " + stack.peek());
        System.out.println("  pop()     = " + stack.pop() + " → " + stack);
        System.out.println("  peek(0)   = " + stack.peek(0) + " (top)");
        System.out.println("  peek(1)   = " + stack.peek(1) + " (second from top)");
        System.out.println("  search(20)= " + stack.search(20));

        section("Balanced Parentheses Checker");
        String[] exprs = {"(a+b)*[c-{d/e}]", "(()", "()[]{}", "([)]", ""};
        for (String e : exprs)
            System.out.printf("  %-20s → %s%n", "\"" + e + "\"", MyStack.isBalanced(e) ? "BALANCED ✓" : "UNBALANCED ✗");

        section("Postfix (RPN) Evaluation");
        String[] rpn = {"3 4 +", "5 1 2 + 4 * + 3 -", "2 3 4 * +"};
        for (String expr : rpn)
            System.out.printf("  %-20s = %.1f%n", expr, MyStack.evalPostfix(expr));
    }

    // ═════════════════════════════════════════════════════════════════════════
    // MODULE 4 — QUEUE (Circular Buffer)
    // ═════════════════════════════════════════════════════════════════════════
    static void demoQueue() {
        header("04. MyArrayQueue — Circular Buffer FIFO");

        MyArrayQueue<Integer> q = new MyArrayQueue<>(4);

        section("Enqueue / Dequeue (circular wrap)");
        q.enqueue(1); q.enqueue(2); q.enqueue(3); q.enqueue(4);
        System.out.println("  After enqueue 1-4  : " + q);
        System.out.println("  dequeue()          = " + q.dequeue());
        System.out.println("  dequeue()          = " + q.dequeue());
        System.out.println("  After 2 dequeues   : " + q);
        q.enqueue(5); q.enqueue(6);
        System.out.println("  After enqueue 5,6  : " + q + "  (head wrapped around)");
        System.out.println("  peek()             = " + q.peek());

        section("Resize during circular state");
        q.enqueue(7); q.enqueue(8); q.enqueue(9);
        System.out.println("  After resize+enqueue 7-9 : " + q);

        section("Drain");
        while (!q.isEmpty()) System.out.print("  poll=" + q.poll() + " ");
        System.out.println("\n  isEmpty() = " + q.isEmpty());
    }

    // ═════════════════════════════════════════════════════════════════════════
    // MODULE 5 — DEQUE
    // ═════════════════════════════════════════════════════════════════════════
    static void demoDeque() {
        header("05. MyDeque — Double-Ended Queue");

        MyDeque<Integer> dq = new MyDeque<>();

        section("AddFirst / AddLast");
        dq.addLast(3); dq.addLast(4); dq.addFirst(2); dq.addFirst(1);
        System.out.println("  [1,2,3,4]     : " + dq);
        System.out.println("  peekFirst()   = " + dq.peekFirst());
        System.out.println("  peekLast()    = " + dq.peekLast());
        dq.removeFirst(); dq.removeLast();
        System.out.println("  After rm first+last : " + dq);

        section("As Stack (LIFO)");
        MyDeque<String> stack = new MyDeque<>();
        stack.push("A"); stack.push("B"); stack.push("C");
        System.out.println("  push A,B,C     : " + stack);
        System.out.println("  pop()          = " + stack.pop() + " → " + stack);

        section("As Queue (FIFO)");
        MyDeque<String> queue = new MyDeque<>();
        queue.offer("X"); queue.offer("Y"); queue.offer("Z");
        System.out.println("  offer X,Y,Z    : " + queue);
        System.out.println("  poll()         = " + queue.poll() + " → " + queue);

        section("Sliding Window Maximum (Monotonic Deque)");
        int[] nums = {1, 3, -1, -3, 5, 3, 6, 7};
        int   k    = 3;
        int[] result = MyDeque.slidingWindowMax(nums, k);
        System.out.println("  nums           = " + Arrays.toString(nums));
        System.out.printf( "  k=%d window max = %s%n", k, Arrays.toString(result));
    }

    // ═════════════════════════════════════════════════════════════════════════
    // MODULE 6 — PRIORITY QUEUE (Min-Heap)
    // ═════════════════════════════════════════════════════════════════════════
    static void demoPriorityQueue() {
        header("06. MyPriorityQueue — Binary Min-Heap");

        section("Basic offer / poll");
        MyPriorityQueue<Integer> pq = new MyPriorityQueue<>();
        for (int v : new int[]{5, 1, 8, 3, 9, 2, 7, 4, 6}) {
            pq.offer(v);
        }
        System.out.println("  Heap array     : " + pq);
        System.out.print(  "  Poll order     : ");
        while (!pq.isEmpty()) System.out.print(pq.poll() + " ");
        System.out.println("  ← always ascending (min first)");

        section("Heapify from array — O(n)");
        Integer[] arr = {10, 4, 15, 1, 7, 3, 8};
        MyPriorityQueue<Integer> heapified = MyPriorityQueue.heapify(arr);
        System.out.println("  Input array    : " + Arrays.toString(arr));
        System.out.println("  After heapify  : " + heapified);
        System.out.println("  Min (peek)     : " + heapified.peek());

        section("Heap Tree Structure");
        MyPriorityQueue<Integer> viz = new MyPriorityQueue<>();
        for (int v : new int[]{5, 10, 3, 8, 1, 7}) viz.offer(v);
        System.out.println(viz.toHeapTree());

        section("Custom comparator — Max-Heap");
        MyPriorityQueue<Integer> maxPQ = new MyPriorityQueue<>(java.util.Comparator.reverseOrder());
        for (int v : new int[]{5, 1, 8, 3, 9}) maxPQ.offer(v);
        System.out.print("  Max-heap poll  : ");
        while (!maxPQ.isEmpty()) System.out.print(maxPQ.poll() + " ");
        System.out.println("  ← always descending");

        section("Heap Sort (in-place) — O(n log n)");
        int[] toSort = {64, 34, 25, 12, 22, 11, 90};
        System.out.println("  Before         : " + Arrays.toString(toSort));
        MyPriorityQueue.heapSort(toSort);
        System.out.println("  After heapSort : " + Arrays.toString(toSort));
    }

    // ═════════════════════════════════════════════════════════════════════════
    // MODULE 7 — HASHMAP
    // ═════════════════════════════════════════════════════════════════════════
    static void demoHashMap() {
        header("07. MyHashMap — Hash Table (Separate Chaining)");

        MyHashMap<String, Integer> map = new MyHashMap<>();

        section("Put / Get / Contains");
        String[] words = {"apple","banana","cherry","date","elderberry","fig","grape"};
        for (int i = 0; i < words.length; i++) map.put(words[i], i + 1);
        System.out.println("  get(apple)     = " + map.get("apple"));
        System.out.println("  get(missing)   = " + map.get("missing"));
        System.out.println("  getOrDefault   = " + map.getOrDefault("missing", -1));
        System.out.println("  containsKey    = " + map.containsKey("banana"));
        System.out.println("  size()         = " + map.size());

        section("Update / Remove");
        map.put("apple", 100);
        System.out.println("  put(apple,100) : get=" + map.get("apple"));
        map.remove("fig");
        System.out.println("  remove(fig)    : size=" + map.size());

        section("Null key support");
        map.put(null, 0);
        System.out.println("  put(null,0)    : get(null)=" + map.get(null));

        section("Keys / Values");
        System.out.println("  keySet()       : " + map.keySet().stream().sorted().toList());

        section("Internal diagnostics");
        MyHashMap<Integer, String> big = new MyHashMap<>(4);
        for (int i = 0; i < 20; i++) big.put(i, "v" + i);
        System.out.println("  " + big.toDebugString());
    }

    // ═════════════════════════════════════════════════════════════════════════
    // MODULE 8 — TREEMAP (Red-Black Tree)
    // ═════════════════════════════════════════════════════════════════════════
    static void demoTreeMap() {
        header("08. MyTreeMap — Red-Black Tree (Sorted Map)");

        MyTreeMap<Integer, String> map = new MyTreeMap<>();

        section("Put (self-balancing after each insert)");
        int[] keys = {50, 30, 70, 20, 40, 60, 80, 10, 25, 35};
        for (int k : keys) map.put(k, "v" + k);

        section("Sorted key iteration (in-order)");
        System.out.println("  keySet()       : " + map.keySet());
        System.out.println("  firstKey()     : " + map.firstKey());
        System.out.println("  lastKey()      : " + map.lastKey());
        System.out.println("  get(30)        : " + map.get(30));
        System.out.println("  size()         : " + map.size());

        section("Red-Black Tree visualisation");
        System.out.println(map.toTreeString());

        section("Remove + rebalance");
        map.remove(30);
        System.out.println("  After remove(30) : " + map.keySet());
    }

    // ═════════════════════════════════════════════════════════════════════════
    // MODULE 9 — LRU CACHE
    // ═════════════════════════════════════════════════════════════════════════
    static void demoLRUCache() {
        header("09. LRUCache — O(1) HashMap + Doubly Linked List");

        LRUCache<Integer, String> cache = new LRUCache<>(4);

        section("Put operations");
        cache.put(1, "one");   System.out.println("  put(1) : " + cache);
        cache.put(2, "two");   System.out.println("  put(2) : " + cache);
        cache.put(3, "three"); System.out.println("  put(3) : " + cache);
        cache.put(4, "four");  System.out.println("  put(4) : " + cache);

        section("Get (moves to MRU)");
        System.out.println("  get(1)=" + cache.get(1) + " → " + cache);
        System.out.println("  get(3)=" + cache.get(3) + " → " + cache);

        section("Eviction when full");
        cache.put(5, "five");
        System.out.println("  put(5) evicts LRU : " + cache);
        System.out.println("  2 was evicted, get(2)=" + cache.get(2));

        section("Update existing key");
        cache.put(1, "ONE-updated");
        System.out.println("  update(1)  : " + cache);

        section("Hit/Miss stats");
        System.out.printf("  Hits=%d  Misses=%d  HitRatio=%.0f%%%n",
            cache.hits(), cache.misses(), cache.hitRatio() * 100);
    }

    // ═════════════════════════════════════════════════════════════════════════
    // MODULE 10 — SETS
    // ═════════════════════════════════════════════════════════════════════════
    static void demoSets() {
        header("10. MyHashSet / MyLinkedHashSet / MyTreeSet");

        section("MyHashSet — no duplicates, no order");
        MyHashSet<String> hs = new MyHashSet<>();
        for (String s : new String[]{"banana","apple","cherry","apple","date"}) hs.add(s);
        System.out.println("  add(banana,apple,cherry,apple,date) : " + hs);
        System.out.println("  contains(apple)   = " + hs.contains("apple"));
        hs.remove("cherry");
        System.out.println("  after remove(cherry) : " + hs);

        section("Set operations — union / intersection / difference");
        MyHashSet<Integer> A = new MyHashSet<>();
        MyHashSet<Integer> B = new MyHashSet<>();
        for (int v : new int[]{1,2,3,4,5}) A.add(v);
        for (int v : new int[]{3,4,5,6,7}) B.add(v);

        MyHashSet<Integer> union = new MyHashSet<>(); union.addAll(A); union.addAll(B);
        MyHashSet<Integer> inter = new MyHashSet<>(); inter.addAll(A); inter.retainAll(B);
        MyHashSet<Integer> diff  = new MyHashSet<>(); diff.addAll(A);  diff.removeAll(B);
        System.out.println("  A = " + A);
        System.out.println("  B = " + B);
        System.out.println("  A ∪ B = " + union);
        System.out.println("  A ∩ B = " + inter);
        System.out.println("  A − B = " + diff);

        section("MyLinkedHashSet — insertion order preserved");
        MyLinkedHashSet<String> lhs = new MyLinkedHashSet<>();
        for (String s : new String[]{"z","m","a","b","z","q"}) lhs.add(s);
        System.out.println("  Insert z,m,a,b,z,q : " + lhs + "  (z deduped)");

        section("MyTreeSet — sorted (Red-Black Tree)");
        MyTreeSet<Integer> ts = new MyTreeSet<>();
        for (int v : new int[]{5,1,8,3,9,2,7,4,6}) ts.add(v);
        System.out.println("  Insert 5,1,8,3,9,2,7,4,6 : " + ts + " ← sorted!");
        System.out.println("  first()=" + ts.first() + "  last()=" + ts.last());
        ts.remove(5);
        System.out.println("  After remove(5)    : " + ts);
    }

    // ═════════════════════════════════════════════════════════════════════════
    // MODULE 11 — BINARY SEARCH TREE
    // ═════════════════════════════════════════════════════════════════════════
    static void demoBST() {
        header("11. MyBinarySearchTree — BST with Full Operations");

        MyBinarySearchTree<Integer, String> bst = new MyBinarySearchTree<>();
        int[] keys = {50, 30, 70, 20, 40, 60, 80, 10, 25};
        for (int k : keys) bst.put(k, "v" + k);

        section("Tree structure");
        System.out.println(bst.toTreeString());

        section("Traversals");
        System.out.println("  In-order  (sorted): " + bst.inOrder());
        System.out.println("  Pre-order (copy)  : " + bst.preOrder());
        System.out.println("  Post-order(delete): " + bst.postOrder());
        System.out.println("  Level-order (BFS) : " + bst.levelOrder());

        section("Tree metrics");
        System.out.println("  height()          = " + bst.height());
        System.out.println("  size()            = " + bst.size());
        System.out.println("  leafCount()       = " + bst.leafCount());
        System.out.println("  depth(25)         = " + bst.depth(25));
        System.out.println("  isBST()           = " + bst.isBST());

        section("Advanced queries");
        System.out.println("  kthSmallest(1)    = " + bst.kthSmallest(1));
        System.out.println("  kthSmallest(3)    = " + bst.kthSmallest(3));
        System.out.println("  kthSmallest(9)    = " + bst.kthSmallest(9));
        System.out.println("  lca(20,40)        = " + bst.lca(20, 40));
        System.out.println("  lca(10,25)        = " + bst.lca(10, 25));
        System.out.println("  lca(10,80)        = " + bst.lca(10, 80));

        section("Delete");
        bst.remove(30);
        System.out.println("  After remove(30)  : " + bst.inOrder());
        bst.remove(50);
        System.out.println("  After remove(50)  : " + bst.inOrder() + "  isBST=" + bst.isBST());
    }

    // ═════════════════════════════════════════════════════════════════════════
    // MODULE 12 — AVL TREE
    // ═════════════════════════════════════════════════════════════════════════
    static void demoAVL() {
        header("12. MyAVLTree — Self-Balancing BST (4 Rotation Cases)");

        MyAVLTree<Integer, String> avl = new MyAVLTree<>();

        section("LL Case — inserting 3,2,1 triggers RIGHT rotation");
        avl.put(3, "c"); avl.put(2, "b"); avl.put(1, "a");
        System.out.println("  insert 3,2,1 (LL case → rotateRight):");
        System.out.println(avl.toTreeString());
        System.out.println("  height=" + avl.height() + "  (would be 2 without balancing)");

        section("RR Case — inserting 1,2,3 triggers LEFT rotation");
        MyAVLTree<Integer, String> avl2 = new MyAVLTree<>();
        avl2.put(1,"a"); avl2.put(2,"b"); avl2.put(3,"c");
        System.out.println("  insert 1,2,3 (RR case → rotateLeft):");
        System.out.println(avl2.toTreeString());

        section("Full balanced tree");
        MyAVLTree<Integer, String> full = new MyAVLTree<>();
        int[] vals = {10, 20, 30, 40, 50, 25};
        for (int v : vals) full.put(v, "v"+v);
        System.out.println("  Insert 10,20,30,40,50,25:");
        System.out.println(full.toTreeString());
        System.out.println("  In-order (must be sorted): " + full.inOrder());
        System.out.println("  height=" + full.height());

        section("Delete + rebalance");
        full.remove(20);
        System.out.println("  After remove(20):");
        System.out.println(full.toTreeString());
    }

    // ═════════════════════════════════════════════════════════════════════════
    // MODULE 13 — TRIE
    // ═════════════════════════════════════════════════════════════════════════
    static void demoTrie() {
        header("13. MyTrie — Prefix Tree");

        MyTrie trie = new MyTrie();

        section("Insert words");
        String[] words = {"apple","app","application","apply","apt","bat","ball","ban","band"};
        for (String w : words) trie.insert(w);
        System.out.println("  Inserted: " + Arrays.toString(words));
        System.out.println("  size()   = " + trie.size());

        section("Search / startsWith");
        System.out.println("  search(apple)  = " + trie.search("apple"));
        System.out.println("  search(app)    = " + trie.search("app"));
        System.out.println("  search(ap)     = " + trie.search("ap")   + "  (not inserted)");
        System.out.println("  startsWith(ap) = " + trie.startsWith("ap"));
        System.out.println("  startsWith(ba) = " + trie.startsWith("ba"));
        System.out.println("  startsWith(xy) = " + trie.startsWith("xy"));

        section("Autocomplete");
        System.out.println("  autocomplete(app): " + trie.autocomplete("app"));
        System.out.println("  autocomplete(ba) : " + trie.autocomplete("ba"));
        System.out.println("  autocomplete(b)  : " + trie.autocomplete("b"));

        section("Count words with prefix");
        System.out.println("  count(app)       = " + trie.countWordsWithPrefix("app"));
        System.out.println("  count(ba)        = " + trie.countWordsWithPrefix("ba"));

        section("Delete");
        trie.delete("app");
        System.out.println("  After delete(app): search(app)=" + trie.search("app")
            + "  search(apple)=" + trie.search("apple"));

        section("Longest common prefix");
        MyTrie trie2 = new MyTrie();
        for (String w : new String[]{"flower","flow","flight"}) trie2.insert(w);
        System.out.println("  LCP of flower,flow,flight = \"" + trie2.longestCommonPrefix() + "\"");
    }

    // ═════════════════════════════════════════════════════════════════════════
    // MODULE 14 — GRAPH
    // ═════════════════════════════════════════════════════════════════════════
    static void demoGraph() {
        header("14. MyGraph — BFS / DFS / Dijkstra / Topo Sort");

        section("Undirected graph — BFS shortest path");
        MyGraph<String> ug = new MyGraph<>(false);
        String[][] edges = {{"A","B"},{"A","C"},{"B","D"},{"B","E"},{"C","F"},{"D","G"},{"E","G"}};
        for (String[] e : edges) ug.addEdge(e[0], e[1]);
        System.out.println(ug);

        Map<String, Integer> bfsDist = ug.bfs("A");
        System.out.println("  BFS distances from A: " + bfsDist);
        List<String> path = ug.shortestPath("A", "G");
        System.out.println("  Shortest path A→G  : " + path + " (" + (path.size()-1) + " hops)");

        section("DFS traversal");
        System.out.println("  DFS from A         : " + ug.dfs("A"));

        section("Directed graph — Topological Sort");
        MyGraph<String> dag = new MyGraph<>(true);
        dag.addEdge("Course-A", "Course-C");
        dag.addEdge("Course-B", "Course-C");
        dag.addEdge("Course-C", "Course-D");
        dag.addEdge("Course-D", "Course-E");
        dag.addEdge("Course-B", "Course-D");
        System.out.println("  DAG: " + dag);
        System.out.println("  Topological order  : " + dag.topologicalSort());

        section("Cycle detection");
        System.out.println("  DAG has cycle      : " + dag.hasCycle());
        dag.addEdge("Course-E", "Course-A");   // create cycle
        System.out.println("  After adding cycle : " + dag.hasCycle());

        section("Weighted graph — Dijkstra shortest path");
        MyGraph<String> wg = new MyGraph<>(true);
        wg.addEdge("S", "A", 4); wg.addEdge("S", "B", 2);
        wg.addEdge("A", "C", 3); wg.addEdge("B", "A", 1);
        wg.addEdge("B", "C", 5); wg.addEdge("C", "D", 2);
        System.out.println("  Graph: " + wg);
        System.out.println("  Dijkstra from S    : " + wg.dijkstra("S"));
        System.out.println("  Shortest path S→D  : " + wg.dijkstraPath("S", "D") +
            "  cost=" + wg.dijkstra("S").get("D"));
    }

    // ═════════════════════════════════════════════════════════════════════════
    // MAIN
    // ═════════════════════════════════════════════════════════════════════════
    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════════════════════════╗");
        System.out.println("║     JAVA COLLECTIONS — CUSTOM IMPLEMENTATIONS FROM SCRATCH  ║");
        System.out.println("║     20 Collection Classes  •  All Major Data Structures     ║");
        System.out.println("╚══════════════════════════════════════════════════════════════╝");

        demoArrayList();
        demoLinkedList();
        demoStack();
        demoQueue();
        demoDeque();
        demoPriorityQueue();
        demoHashMap();
        demoTreeMap();
        demoLRUCache();
        demoSets();
        demoBST();
        demoAVL();
        demoTrie();
        demoGraph();

        System.out.println("\n╔══════════════════════════════════════════════════════════════╗");
        System.out.println("║  ALL 20 COLLECTIONS DEMONSTRATED SUCCESSFULLY ✓              ║");
        System.out.println("╚══════════════════════════════════════════════════════════════╝");
    }
}