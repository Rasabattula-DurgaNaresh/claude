package com.collections.map;

import java.util.HashMap;
import java.util.Map;

/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  LRUCache<K, V> — Least Recently Used Cache                         ║
 * ╠══════════════════════════════════════════════════════════════════════╣
 * ║  INTERNAL STRUCTURE:                                                 ║
 * ║    HashMap<K, Node>       — O(1) lookup by key                     ║
 * ║    DoublyLinkedList       — O(1) move-to-front and evict-from-back  ║
 * ║                                                                      ║
 * ║  INVARIANT:                                                          ║
 * ║    Most recently used = head.next                                  ║
 * ║    Least recently used = tail.prev  (evicted when full)            ║
 * ║                                                                      ║
 * ║  TIME COMPLEXITY: O(1) for get AND put.                            ║
 * ║                                                                      ║
 * ║  OPERATIONS:                                                         ║
 * ║    get(key):  find in map → move node to head → return value        ║
 * ║    put(key):  exists? update + move to head                         ║
 * ║               new?    add to head + add to map                      ║
 * ║               full?   remove tail.prev (LRU) from map + list        ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 */
public class LRUCache<K, V> {

    // ── Node ─────────────────────────────────────────────────────────────
    private static class Node<K, V> {
        K key; V value;
        Node<K,V> prev, next;
        Node(K k, V v) { key = k; value = v; }
    }

    private final int                 capacity;
    private final Map<K, Node<K,V>>   map  = new HashMap<>();
    private final Node<K,V>           head = new Node<>(null, null);  // sentinel MRU
    private final Node<K,V>           tail = new Node<>(null, null);  // sentinel LRU
    private       int                 size = 0;
    private       int                 hits = 0, misses = 0;

    public LRUCache(int capacity) {
        if (capacity <= 0) throw new IllegalArgumentException("capacity must be > 0");
        this.capacity = capacity;
        head.next = tail;
        tail.prev = head;
    }

    // ── Get ───────────────────────────────────────────────────────────────
    /**
     * O(1): HashMap lookup + move to MRU position.
     */
    public V get(K key) {
        Node<K,V> node = map.get(key);
        if (node == null) { misses++; return null; }
        hits++;
        moveToFront(node);   // mark as recently used
        return node.value;
    }

    // ── Put ───────────────────────────────────────────────────────────────
    /**
     * O(1): update existing or insert new.
     * If at capacity, evict the LRU entry (tail.prev).
     */
    public void put(K key, V value) {
        Node<K,V> node = map.get(key);
        if (node != null) {
            // Update existing
            node.value = value;
            moveToFront(node);
            return;
        }

        // Evict LRU if at capacity
        if (size == capacity) {
            Node<K,V> lru = tail.prev;
            remove(lru);
            map.remove(lru.key);
            size--;
        }

        // Insert new at MRU position
        Node<K,V> newNode = new Node<>(key, value);
        addToFront(newNode);
        map.put(key, newNode);
        size++;
    }

    // ── Helpers ───────────────────────────────────────────────────────────
    private void addToFront(Node<K,V> node) {
        node.next = head.next;
        node.prev = head;
        head.next.prev = node;
        head.next = node;
    }

    private void remove(Node<K,V> node) {
        node.prev.next = node.next;
        node.next.prev = node.prev;
    }

    private void moveToFront(Node<K,V> node) {
        remove(node);
        addToFront(node);
    }

    public boolean containsKey(K key) { return map.containsKey(key); }
    public int  size()        { return size; }
    public int  capacity()    { return capacity; }
    public int  hits()        { return hits; }
    public int  misses()      { return misses; }
    public double hitRatio()  { return (hits + misses) == 0 ? 0 : (double) hits / (hits + misses); }

    /** Returns keys from MRU to LRU order. */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("LRU[MRU→LRU: ");
        for (Node<K,V> curr = head.next; curr != tail; curr = curr.next) {
            sb.append(curr.key).append("=").append(curr.value);
            if (curr.next != tail) sb.append(", ");
        }
        return sb.append(String.format("] hits=%d misses=%d (%.0f%%)", hits, misses, hitRatio()*100)).toString();
    }
}