package com.collections.tree;

import java.util.*;

/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  MyAVLTree<K extends Comparable<K>, V>                              ║
 * ╠══════════════════════════════════════════════════════════════════════╣
 * ║  AVL PROPERTY: |height(left) - height(right)| <= 1 at every node  ║
 * ║                                                                      ║
 * ║  Maintains balance via 4 rotation cases triggered after insert:    ║
 * ║                                                                      ║
 * ║  Case 1 — Left-Left (LL):                                          ║
 * ║      z               y                                             ║
 * ║     / \            /   \                                           ║
 * ║    y   T4   →     x     z       Single RIGHT rotation on z        ║
 * ║   / \           / \   / \                                         ║
 * ║  x   T3        T1 T2 T3 T4                                        ║
 * ║                                                                      ║
 * ║  Case 2 — Left-Right (LR):                                         ║
 * ║      z             z              x                                ║
 * ║     / \           / \           /   \                              ║
 * ║    y   T4  →     x   T4   →   y     z   LEFT(y) then RIGHT(z)    ║
 * ║   / \           / \          / \   / \                            ║
 * ║  T1   x        y   T3       T1 T2 T3 T4                          ║
 * ║      / \      / \                                                  ║
 * ║     T2  T3   T1  T2                                                ║
 * ║                                                                      ║
 * ║  Case 3 — Right-Right (RR): mirror of LL → single LEFT on z       ║
 * ║  Case 4 — Right-Left (RL):  mirror of LR → RIGHT(y) then LEFT(z) ║
 * ║                                                                      ║
 * ║  TIME: All ops O(log n) guaranteed. Height ≤ 1.44 log₂(n+2)     ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 */
public class MyAVLTree<K extends Comparable<K>, V> {

    private static class Node<K, V> {
        K key; V value;
        Node<K,V> left, right;
        int height;

        Node(K key, V value) { this.key = key; this.value = value; this.height = 1; }
    }

    private Node<K,V> root;
    private int size;

    // ── Height helpers ────────────────────────────────────────────────────
    private int h(Node<K,V> n)             { return n == null ? 0 : n.height; }
    private int balanceFactor(Node<K,V> n) { return h(n.left) - h(n.right); }
    private void updateHeight(Node<K,V> n) { n.height = 1 + Math.max(h(n.left), h(n.right)); }

    // ── Rotations ─────────────────────────────────────────────────────────
    /**
     * Right rotation: used in LL case.
     *       z                 y
     *      / \              /   \
     *     y   T3    →      x     z
     *    / \              /\    /\
     *   x  T2            T1 T2 T2 T3   (simplified)
     */
    private Node<K,V> rotateRight(Node<K,V> z) {
        Node<K,V> y = z.left;
        Node<K,V> T2 = y.right;
        y.right = z;
        z.left  = T2;
        updateHeight(z);
        updateHeight(y);
        return y;   // y is new root of this subtree
    }

    /** Left rotation: used in RR case (mirror of right rotation). */
    private Node<K,V> rotateLeft(Node<K,V> z) {
        Node<K,V> y = z.right;
        Node<K,V> T2 = y.left;
        y.left  = z;
        z.right = T2;
        updateHeight(z);
        updateHeight(y);
        return y;
    }

    // ── Insert ────────────────────────────────────────────────────────────
    public void put(K key, V value) {
        root = insert(root, key, value);
    }

    private Node<K,V> insert(Node<K,V> node, K key, V value) {
        // 1. Standard BST insert
        if (node == null) { size++; return new Node<>(key, value); }
        int cmp = key.compareTo(node.key);
        if      (cmp < 0) node.left  = insert(node.left,  key, value);
        else if (cmp > 0) node.right = insert(node.right, key, value);
        else              { node.value = value; return node; }  // update

        // 2. Update height
        updateHeight(node);

        // 3. Get balance factor and fix if unbalanced
        int bf = balanceFactor(node);

        // LL Case: left heavy, new node in LEFT  subtree of left  child
        if (bf >  1 && key.compareTo(node.left.key) < 0)
            return rotateRight(node);

        // RR Case: right heavy, new node in RIGHT subtree of right child
        if (bf < -1 && key.compareTo(node.right.key) > 0)
            return rotateLeft(node);

        // LR Case: left heavy, new node in RIGHT subtree of left  child
        if (bf >  1 && key.compareTo(node.left.key) > 0) {
            node.left = rotateLeft(node.left);
            return rotateRight(node);
        }

        // RL Case: right heavy, new node in LEFT  subtree of right child
        if (bf < -1 && key.compareTo(node.right.key) < 0) {
            node.right = rotateRight(node.right);
            return rotateLeft(node);
        }

        return node;  // already balanced
    }

    // ── Delete ────────────────────────────────────────────────────────────
    public void remove(K key) { root = delete(root, key); }

    private Node<K,V> delete(Node<K,V> node, K key) {
        if (node == null) return null;
        int cmp = key.compareTo(node.key);
        if      (cmp < 0) node.left  = delete(node.left,  key);
        else if (cmp > 0) node.right = delete(node.right, key);
        else {
            size--;
            if (node.left  == null) return node.right;
            if (node.right == null) return node.left;
            // In-order successor
            Node<K,V> successor = node.right;
            while (successor.left != null) successor = successor.left;
            node.key   = successor.key;
            node.value = successor.value;
            node.right = delete(node.right, successor.key);
            size++;  // compensate
        }

        updateHeight(node);
        int bf = balanceFactor(node);

        if (bf >  1 && balanceFactor(node.left)  >= 0) return rotateRight(node);
        if (bf >  1 && balanceFactor(node.left)  <  0) { node.left = rotateLeft(node.left);   return rotateRight(node); }
        if (bf < -1 && balanceFactor(node.right) <= 0) return rotateLeft(node);
        if (bf < -1 && balanceFactor(node.right) >  0) { node.right= rotateRight(node.right); return rotateLeft(node); }
        return node;
    }

    // ── Search ────────────────────────────────────────────────────────────
    public V get(K key) {
        Node<K,V> curr = root;
        while (curr != null) {
            int cmp = key.compareTo(curr.key);
            if      (cmp < 0) curr = curr.left;
            else if (cmp > 0) curr = curr.right;
            else              return curr.value;
        }
        return null;
    }

    public boolean containsKey(K key) { return get(key) != null; }
    public int     height()           { return h(root); }
    public int     size()             { return size; }
    public boolean isEmpty()          { return size == 0; }
    public void    clear()            { root = null; size = 0; }

    /** In-order traversal — sorted ascending. */
    public List<K> inOrder() {
        List<K> list = new ArrayList<>();
        inOrderRec(root, list);
        return list;
    }
    private void inOrderRec(Node<K,V> n, List<K> l) {
        if (n == null) return;
        inOrderRec(n.left, l);
        l.add(n.key);
        inOrderRec(n.right, l);
    }

    /** Visual tree with heights and balance factors. */
    public String toTreeString() {
        if (root == null) return "(empty)";
        StringBuilder sb = new StringBuilder();
        printTree(sb, root, "", false);
        return sb.toString();
    }
    private void printTree(StringBuilder sb, Node<K,V> n, String prefix, boolean isRight) {
        if (n == null) return;
        sb.append(prefix).append(isRight ? "├── " : "└── ")
          .append(n.key).append(" (h=").append(n.height).append(", bf=").append(balanceFactor(n)).append(")\n");
        String child = prefix + (isRight ? "│   " : "    ");
        printTree(sb, n.right, child, true);
        printTree(sb, n.left,  child, false);
    }
}