package com.collections.util;

import java.util.Set;
import java.util.Collection;

/**
 * Key-value mapping — mirrors java.util.Map
 */
public interface MyMap<K, V> {
    V       put(K key, V value);
    V       get(K key);
    V       remove(K key);
    boolean containsKey(K key);
    boolean containsValue(V value);
    int     size();
    boolean isEmpty();
    void    clear();
    Set<K>  keySet();
    Collection<V> values();
    Set<Entry<K,V>> entrySet();
    V       getOrDefault(K key, V defaultValue);

    interface Entry<K, V> {
        K getKey();
        V getValue();
        V setValue(V value);
    }
}