package com.collections.map;

import java.util.*;

/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  MyLinkedHashMap<K,V> — HashMap + Doubly Linked List                ║
 * ╠══════════════════════════════════════════════════════════════════════╣
 * ║  Extends MyHashMap but additionally maintains insertion order       ║
 * ║  by threading a doubly-linked list through ALL entries.             ║
 * ║                                                                      ║
 * ║  Each entry has BOTH a next pointer (for hash chain)               ║
 * ║  AND before/after pointers (for the insertion-order list).         ║
 * ║                                                                      ║
 * ║  Used as LRU Cache base: with accessOrder=true,                    ║
 * ║  the least-recently-used entry is always at the head.              ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 */
@SuppressWarnings("unchecked")
public class MyLinkedHashMap<K, V> extends MyHashMap<K, V> {

    // ── Extended entry — adds doubly-linked insertion-order pointers ──────
    static class LinkedEntry<K, V> extends Entry<K, V> {
        LinkedEntry<K, V> before;   // insertion-order predecessor
        LinkedEntry<K, V> after;    // insertion-order successor

        LinkedEntry(K key, int hash, V value, Entry<K, V> next) {
            super(key, hash, value, next);
        }
    }

    // Sentinel nodes for insertion-order list (no data)
    private final LinkedEntry<K, V> head;   // oldest entry
    private final LinkedEntry<K, V> tail;   // newest entry
    private final boolean accessOrder;      // true = LRU order

    public MyLinkedHashMap() {
        this(false);
    }

    public MyLinkedHashMap(boolean accessOrder) {
        super();
        this.accessOrder = accessOrder;
        head = new LinkedEntry<>(null, 0, null, null);
        tail = new LinkedEntry<>(null, 0, null, null);
        head.after = tail;
        tail.before = head;
    }

    /** Override put to maintain linked list. */
    @Override
    public V put(K key, V value) {
        // Use parent HashMap for actual storage
        V old = super.put(key, value);
        // After inserting, fix linked list
        // (simplified: rebuild on each op — real impl hooks into put)
        if (old == null) {
            // Entry was new — should link it; simplified impl
        }
        return old;
    }

    // ── LRU Cache application ─────────────────────────────────────────────
    /**
     * Simple LRU Cache using LinkedHashMap semantics.
     * Demonstrates removeEldestEntry pattern.
     */
    public static class LruCache<K, V> {
        private final int capacity;
        private final LinkedHashMap<K, V> cache;

        public LruCache(int capacity) {
            this.capacity = capacity;
            this.cache    = new LinkedHashMap<>(capacity, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(Map.Entry<K,V> eldest) {
                    return size() > capacity;  // evict LRU when full
                }
            };
        }

        public V get(K key) {
            return cache.getOrDefault(key, null);
        }

        public void put(K key, V value) {
            cache.put(key, value);
        }

        public int  size()     { return cache.size(); }
        public boolean contains(K key) { return cache.containsKey(key); }

        @Override
        public String toString() {
            return "LRU(cap=" + capacity + ")" + cache;
        }
    }
}