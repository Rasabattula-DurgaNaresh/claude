package com.collections.util;

import java.util.Iterator;

/**
 * Base interface for all custom collection implementations.
 * Mirrors java.util.Collection without inheriting it.
 */
public interface MyCollection<E> extends Iterable<E> {
    int     size();
    boolean isEmpty();
    boolean contains(Object o);
    void    clear();
    Object[] toArray();
    String   toDebugString(); // shows internal structure
}