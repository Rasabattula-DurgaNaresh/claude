package com.collections.tree;

import java.util.*;

/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  MyTrie — Prefix Tree (Digital Search Tree)                         ║
 * ╠══════════════════════════════════════════════════════════════════════╣
 * ║  Each node represents ONE character. Path from root to node        ║
 * ║  spells a prefix. Leaf (isEnd=true) = complete word.              ║
 * ║                                                                      ║
 * ║  Node structure: children[26] for a-z (or HashMap for Unicode)    ║
 * ║                                                                      ║
 * ║  TIME COMPLEXITY:                                                    ║
 * ║    insert/search/startsWith  O(L) where L = word length            ║
 * ║    (independent of n — number of words!)                           ║
 * ║  SPACE: O(ALPHABET × n × L) worst case                             ║
 * ║                                                                      ║
 * ║  REAL-WORLD USES:                                                    ║
 * ║    • Autocomplete / search suggestions                              ║
 * ║    • Spell checker                                                  ║
 * ║    • IP routing (longest prefix match)                             ║
 * ║    • Word games, boggle solvers                                    ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 */
public class MyTrie {

    private static class TrieNode {
        private final TrieNode[] children = new TrieNode[26];
        private boolean isEnd    = false;
        private int     wordCount = 0;    // how many words end here or pass through
        private String  word      = null; // full word if isEnd=true

        boolean hasChild(char c)       { return children[c - 'a'] != null; }
        TrieNode getChild(char c)      { return children[c - 'a']; }
        void setChild(char c, TrieNode n){ children[c - 'a'] = n; }
    }

    private final TrieNode root = new TrieNode();
    private int wordCount = 0;

    // ── Insert ────────────────────────────────────────────────────────────
    public void insert(String word) {
        if (word == null || word.isEmpty()) return;
        TrieNode curr = root;
        for (char c : word.toLowerCase().toCharArray()) {
            if (!curr.hasChild(c)) curr.setChild(c, new TrieNode());
            curr = curr.getChild(c);
            curr.wordCount++;
        }
        if (!curr.isEnd) {
            curr.isEnd = true;
            curr.word  = word;
            wordCount++;
        }
    }

    // ── Search (exact match) ──────────────────────────────────────────────
    public boolean search(String word) {
        TrieNode node = findNode(word);
        return node != null && node.isEnd;
    }

    // ── Prefix check ──────────────────────────────────────────────────────
    public boolean startsWith(String prefix) {
        return findNode(prefix) != null;
    }

    // ── Delete ────────────────────────────────────────────────────────────
    public boolean delete(String word) {
        if (!search(word)) return false;
        deleteRec(root, word, 0);
        wordCount--;
        return true;
    }

    private boolean deleteRec(TrieNode curr, String word, int idx) {
        if (idx == word.length()) {
            if (!curr.isEnd) return false;
            curr.isEnd = false;
            return allChildrenNull(curr);  // safe to delete if no children
        }
        char c = Character.toLowerCase(word.charAt(idx));
        TrieNode child = curr.getChild(c);
        if (child == null) return false;

        boolean shouldDeleteChild = deleteRec(child, word, idx + 1);
        if (shouldDeleteChild) curr.setChild(c, null);
        return !curr.isEnd && allChildrenNull(curr);
    }

    private boolean allChildrenNull(TrieNode n) {
        for (TrieNode child : n.children) if (child != null) return false;
        return true;
    }

    // ── Autocomplete ──────────────────────────────────────────────────────

    /** Return all words with given prefix (for autocomplete). */
    public List<String> autocomplete(String prefix) {
        List<String> results = new ArrayList<>();
        TrieNode node = findNode(prefix);
        if (node == null) return results;
        collectWords(node, results);
        return results;
    }

    /** Return top-k suggestions by wordCount (most popular prefixes). */
    public List<String> topSuggestions(String prefix, int k) {
        List<String> all = autocomplete(prefix);
        // In a real system, nodes would store frequency; simplified here
        return all.subList(0, Math.min(k, all.size()));
    }

    private void collectWords(TrieNode node, List<String> results) {
        if (node.isEnd) results.add(node.word);
        for (TrieNode child : node.children) {
            if (child != null) collectWords(child, results);
        }
    }

    // ── Count words with prefix ───────────────────────────────────────────
    public int countWordsWithPrefix(String prefix) {
        TrieNode node = findNode(prefix);
        return node == null ? 0 : node.wordCount;
    }

    // ── Longest common prefix ─────────────────────────────────────────────
    public String longestCommonPrefix() {
        StringBuilder sb = new StringBuilder();
        TrieNode curr = root;
        while (true) {
            int childCount = 0;
            TrieNode onlyChild = null;
            char onlyChar = 0;
            for (int i = 0; i < 26; i++) {
                if (curr.children[i] != null) {
                    childCount++;
                    onlyChild = curr.children[i];
                    onlyChar  = (char)('a' + i);
                }
            }
            if (childCount != 1 || curr.isEnd) break;
            sb.append(onlyChar);
            curr = onlyChild;
        }
        return sb.toString();
    }

    private TrieNode findNode(String s) {
        TrieNode curr = root;
        for (char c : s.toLowerCase().toCharArray()) {
            curr = curr.getChild(c);
            if (curr == null) return null;
        }
        return curr;
    }

    public int  size()    { return wordCount; }
    public boolean isEmpty(){ return wordCount == 0; }

    @Override
    public String toString() {
        List<String> words = new ArrayList<>();
        collectWords(root, words);
        return "Trie" + words;
    }
}