package com.collections.set;

import com.collections.map.MyHashMap;
import java.util.Iterator;

/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  MyHashSet<E> — Hash Set backed by MyHashMap                        ║
 * ╠══════════════════════════════════════════════════════════════════════╣
 * ║  Uses the "Map trick": stores elements as MAP KEYS with a           ║
 * ║  dummy value. This is exactly how java.util.HashSet works.         ║
 * ║                                                                      ║
 * ║  TIME COMPLEXITY:                                                    ║
 * ║    add/remove/contains  O(1) average                               ║
 * ║    iteration            O(n + capacity)                             ║
 * ║  NO duplicates, NO ordering guarantee.                             ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 */
public class MyHashSet<E> implements Iterable<E> {

    private static final Object PRESENT = new Object();   // dummy value
    private final MyHashMap<E, Object> map;

    public MyHashSet()              { map = new MyHashMap<>(); }
    public MyHashSet(int capacity)  { map = new MyHashMap<>(capacity); }

    /** Add element — returns true if newly added, false if already present. */
    public boolean add(E element) {
        return map.put(element, PRESENT) == null;
    }

    /** Returns true if element was present and removed. */
    public boolean remove(Object o) {
        return map.remove((E) o) == PRESENT;
    }

    public boolean contains(Object o) { return map.containsKey((E) o); }
    public int     size()              { return map.size(); }
    public boolean isEmpty()           { return map.isEmpty(); }
    public void    clear()             { map.clear(); }

    /** Set union — adds all elements of other into this. */
    public void addAll(MyHashSet<E> other) {
        for (E e : other) add(e);
    }

    /** Set intersection — keeps only elements present in both. */
    public void retainAll(MyHashSet<E> other) {
        for (E e : map.keySet()) {
            if (!other.contains(e)) remove(e);
        }
    }

    /** Set difference — removes all elements of other from this. */
    public void removeAll(MyHashSet<E> other) {
        for (E e : other) remove(e);
    }

    @Override
    public Iterator<E> iterator() {
        return map.keySet().iterator();
    }

    @Override
    public String toString() {
        return map.keySet().toString();
    }
}