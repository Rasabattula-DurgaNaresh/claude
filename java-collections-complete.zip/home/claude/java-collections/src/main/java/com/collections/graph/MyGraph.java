package com.collections.graph;

import java.util.*;

/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  MyGraph<V> — Weighted Directed/Undirected Graph                    ║
 * ╠══════════════════════════════════════════════════════════════════════╣
 * ║  REPRESENTATIONS:                                                    ║
 * ║    Adjacency List (used here): HashMap<V, List<Edge>>              ║
 * ║      Space: O(V + E)   — efficient for sparse graphs               ║
 * ║    Adjacency Matrix:           int[V][V]                           ║
 * ║      Space: O(V²)      — efficient for dense graphs                ║
 * ║                                                                      ║
 * ║  ALGORITHMS IMPLEMENTED:                                            ║
 * ║    BFS     — shortest path (unweighted), level-order traversal     ║
 * ║    DFS     — connectivity, cycle detection, topological sort       ║
 * ║    Dijkstra — shortest path (non-negative weights)                 ║
 * ║    Cycle Detection — directed & undirected                         ║
 * ║    Topological Sort — DAG ordering                                 ║
 * ║    Connected Components                                            ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 */
public class MyGraph<V> {

    // ── Edge ─────────────────────────────────────────────────────────────
    public record Edge<V>(V to, double weight) {
        @Override public String toString() { return "-(" + weight + ")-> " + to; }
    }

    // ── Fields ────────────────────────────────────────────────────────────
    private final Map<V, List<Edge<V>>> adjList = new LinkedHashMap<>();
    private final boolean directed;
    private int edgeCount = 0;

    public MyGraph(boolean directed) { this.directed = directed; }

    // ── Build graph ───────────────────────────────────────────────────────
    public void addVertex(V v) {
        adjList.putIfAbsent(v, new ArrayList<>());
    }

    public void addEdge(V from, V to, double weight) {
        addVertex(from); addVertex(to);
        adjList.get(from).add(new Edge<>(to, weight));
        if (!directed) adjList.get(to).add(new Edge<>(from, weight));
        edgeCount++;
    }

    public void addEdge(V from, V to) { addEdge(from, to, 1.0); }

    public List<Edge<V>> neighbors(V v) {
        return adjList.getOrDefault(v, Collections.emptyList());
    }

    public Set<V> vertices() { return adjList.keySet(); }
    public int    vertexCount(){ return adjList.size(); }
    public int    edgeCount()  { return edgeCount; }

    // ── BFS ───────────────────────────────────────────────────────────────
    /**
     * Breadth-First Search from source.
     * Returns: map of vertex → shortest distance (hop count) from source.
     * Time: O(V + E)
     */
    public Map<V, Integer> bfs(V source) {
        Map<V, Integer> dist    = new LinkedHashMap<>();
        Queue<V>        queue   = new LinkedList<>();
        dist.put(source, 0);
        queue.offer(source);

        while (!queue.isEmpty()) {
            V curr = queue.poll();
            for (Edge<V> edge : neighbors(curr)) {
                if (!dist.containsKey(edge.to())) {
                    dist.put(edge.to(), dist.get(curr) + 1);
                    queue.offer(edge.to());
                }
            }
        }
        return dist;
    }

    /**
     * BFS shortest path — returns path as list or empty if unreachable.
     */
    public List<V> shortestPath(V source, V target) {
        Map<V, V> parent = new HashMap<>();
        Queue<V>  queue  = new LinkedList<>();
        parent.put(source, null);
        queue.offer(source);

        while (!queue.isEmpty()) {
            V curr = queue.poll();
            if (curr.equals(target)) break;
            for (Edge<V> e : neighbors(curr)) {
                if (!parent.containsKey(e.to())) {
                    parent.put(e.to(), curr);
                    queue.offer(e.to());
                }
            }
        }

        if (!parent.containsKey(target)) return Collections.emptyList();
        List<V> path = new ArrayList<>();
        for (V v = target; v != null; v = parent.get(v)) path.add(0, v);
        return path;
    }

    // ── DFS ───────────────────────────────────────────────────────────────
    /** DFS traversal from source — returns visited order. Time: O(V + E) */
    public List<V> dfs(V source) {
        List<V>  order   = new ArrayList<>();
        Set<V>   visited = new LinkedHashSet<>();
        dfsRec(source, visited, order);
        return order;
    }

    private void dfsRec(V curr, Set<V> visited, List<V> order) {
        visited.add(curr);
        order.add(curr);
        for (Edge<V> e : neighbors(curr)) {
            if (!visited.contains(e.to())) dfsRec(e.to(), visited, order);
        }
    }

    // ── Cycle Detection ───────────────────────────────────────────────────
    public boolean hasCycle() {
        return directed ? hasCycleDirected() : hasCycleUndirected();
    }

    private boolean hasCycleDirected() {
        // DFS with 3-color marking: WHITE=unvisited, GRAY=in-stack, BLACK=done
        Set<V> white = new HashSet<>(adjList.keySet());
        Set<V> gray  = new HashSet<>();
        Set<V> black = new HashSet<>();

        for (V v : adjList.keySet()) {
            if (white.contains(v) && dfsHasCycleDir(v, white, gray, black)) return true;
        }
        return false;
    }

    private boolean dfsHasCycleDir(V v, Set<V> white, Set<V> gray, Set<V> black) {
        white.remove(v); gray.add(v);
        for (Edge<V> e : neighbors(v)) {
            if (gray.contains(e.to())) return true;   // back edge = cycle!
            if (!black.contains(e.to()) && dfsHasCycleDir(e.to(), white, gray, black)) return true;
        }
        gray.remove(v); black.add(v);
        return false;
    }

    private boolean hasCycleUndirected() {
        Set<V> visited = new HashSet<>();
        for (V v : adjList.keySet()) {
            if (!visited.contains(v) && dfsHasCycleUndir(v, null, visited)) return true;
        }
        return false;
    }

    private boolean dfsHasCycleUndir(V curr, V parent, Set<V> visited) {
        visited.add(curr);
        for (Edge<V> e : neighbors(curr)) {
            if (!visited.contains(e.to()))   { if (dfsHasCycleUndir(e.to(), curr, visited)) return true; }
            else if (!e.to().equals(parent)) return true;
        }
        return false;
    }

    // ── Topological Sort (Kahn's BFS algorithm) ───────────────────────────
    /**
     * Returns topological ordering of vertices (DAG only).
     * Returns empty list if graph has a cycle.
     * Time: O(V + E)
     */
    public List<V> topologicalSort() {
        if (!directed) throw new UnsupportedOperationException("Only for directed graphs");
        Map<V, Integer> inDegree = new HashMap<>();
        for (V v : adjList.keySet()) inDegree.put(v, 0);
        for (V v : adjList.keySet())
            for (Edge<V> e : neighbors(v))
                inDegree.merge(e.to(), 1, Integer::sum);

        Queue<V> queue = new LinkedList<>();
        inDegree.forEach((v, d) -> { if (d == 0) queue.offer(v); });

        List<V> result = new ArrayList<>();
        while (!queue.isEmpty()) {
            V curr = queue.poll();
            result.add(curr);
            for (Edge<V> e : neighbors(curr)) {
                inDegree.merge(e.to(), -1, Integer::sum);
                if (inDegree.get(e.to()) == 0) queue.offer(e.to());
            }
        }
        return result.size() == adjList.size() ? result : Collections.emptyList();
    }

    // ── Dijkstra ──────────────────────────────────────────────────────────
    /**
     * Single-source shortest path (non-negative weights).
     * Uses PriorityQueue for efficient extraction of min-dist vertex.
     * Time: O((V + E) log V)
     */
    public Map<V, Double> dijkstra(V source) {
        Map<V, Double>   dist  = new HashMap<>();
        PriorityQueue<V> pq    = new PriorityQueue<>(Comparator.comparingDouble(dist::get));

        for (V v : adjList.keySet()) dist.put(v, Double.MAX_VALUE);
        dist.put(source, 0.0);
        pq.offer(source);

        while (!pq.isEmpty()) {
            V curr = pq.poll();
            double currDist = dist.get(curr);

            for (Edge<V> e : neighbors(curr)) {
                double newDist = currDist + e.weight();
                if (newDist < dist.getOrDefault(e.to(), Double.MAX_VALUE)) {
                    dist.put(e.to(), newDist);
                    pq.offer(e.to());
                }
            }
        }
        return dist;
    }

    /**
     * Dijkstra with path reconstruction.
     */
    public List<V> dijkstraPath(V source, V target) {
        Map<V, Double> dist   = new HashMap<>();
        Map<V, V>      parent = new HashMap<>();
        PriorityQueue<V> pq   = new PriorityQueue<>(Comparator.comparingDouble(v -> dist.getOrDefault(v, Double.MAX_VALUE)));

        for (V v : adjList.keySet()) dist.put(v, Double.MAX_VALUE);
        dist.put(source, 0.0);
        parent.put(source, null);
        pq.offer(source);

        while (!pq.isEmpty()) {
            V curr = pq.poll();
            if (curr.equals(target)) break;
            for (Edge<V> e : neighbors(curr)) {
                double d = dist.get(curr) + e.weight();
                if (d < dist.getOrDefault(e.to(), Double.MAX_VALUE)) {
                    dist.put(e.to(), d);
                    parent.put(e.to(), curr);
                    pq.offer(e.to());
                }
            }
        }

        if (!parent.containsKey(target)) return Collections.emptyList();
        List<V> path = new ArrayList<>();
        for (V v = target; v != null; v = parent.get(v)) path.add(0, v);
        return path;
    }

    // ── Connected components ───────────────────────────────────────────────
    public List<Set<V>> connectedComponents() {
        Set<V>        visited    = new HashSet<>();
        List<Set<V>>  components = new ArrayList<>();
        for (V v : adjList.keySet()) {
            if (!visited.contains(v)) {
                Set<V> component = new LinkedHashSet<>();
                dfsRec(v, visited, new ArrayList<>());
                component.addAll(dfs(v));
                components.add(component);
            }
        }
        return components;
    }

    // ── Print ─────────────────────────────────────────────────────────────
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(directed ? "Directed" : "Undirected").append(" Graph:\n");
        adjList.forEach((v, edges) -> {
            sb.append("  ").append(v).append(" → ");
            edges.forEach(e -> sb.append(e.to()).append("(").append(e.weight()).append(") "));
            sb.append("\n");
        });
        return sb.toString();
    }
}