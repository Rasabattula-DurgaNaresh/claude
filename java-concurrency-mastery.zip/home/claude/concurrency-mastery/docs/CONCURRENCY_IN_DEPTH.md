# Java Concurrency In Depth — Complete Tutorial

> **18 runnable demos · 15 PNG flow diagrams · 35 topics · Interview Q&A**

---

## Table of Contents

1. [Introduction to Concurrency](#1-introduction-to-concurrency)
2. [Concurrency vs Parallelism](#2-concurrency-vs-parallelism)
3. [Process vs Thread](#3-process-vs-thread)
4. [Creating Threads in Java](#4-creating-threads-in-java)
5. [Thread Lifecycle](#5-thread-lifecycle)
6. [Race Conditions](#6-race-conditions)
7. [Synchronization](#7-synchronization)
8. [Monitor Locks](#8-monitor-locks)
9. [Deadlock, Starvation, Livelock](#9-deadlock-starvation-livelock)
10. [volatile Keyword](#10-volatile-keyword)
11. [Atomic Classes](#11-atomic-classes)
12. [CAS — Compare And Swap](#12-cas--compare-and-swap)
13. [ReentrantLock](#13-reentrantlock)
14. [ReadWriteLock & StampedLock](#14-readwritelock--stampedlock)
15. [Producer-Consumer Problem](#15-producer-consumer-problem)
16. [BlockingQueue](#16-blockingqueue)
17. [Thread Pools](#17-thread-pools)
18. [Executor Framework](#18-executor-framework)
19. [Callable and Future](#19-callable-and-future)
20. [CompletableFuture](#20-completablefuture)
21. [ForkJoinPool](#21-forkjoinpool)
22. [Concurrent Collections](#22-concurrent-collections)
23. [ConcurrentHashMap Deep Dive](#23-concurrenthashmap-deep-dive)
24. [ThreadLocal](#24-threadlocal)
25. [Java Memory Model (JMM)](#25-java-memory-model-jmm)
26. [Happens-Before Relationship](#26-happens-before-relationship)
27. [synchronized vs volatile](#27-synchronized-vs-volatile)
28. [CPU-Level Concepts](#28-cpu-level-concepts)
29. [Advanced Synchronizers](#29-advanced-synchronizers)
30. [Real-World Use Cases](#30-real-world-use-cases)
31. [Performance Optimization](#31-performance-optimization)
32. [Best Practices](#32-best-practices)
33. [Practice Problems](#33-practice-problems)
34. [Interview Questions & Answers](#34-interview-questions--answers)
35. [Final Summary & Cheat Sheet](#35-final-summary--cheat-sheet)

---

## Flow Diagrams Index

| Diagram | File | Topic |
|---------|------|-------|
| 01 | `diagrams/01_thread_lifecycle.png` | Thread state machine |
| 02 | `diagrams/02_race_condition.png` | Race condition vs synchronized |
| 03 | `diagrams/03_deadlock.png` | Circular wait visualisation |
| 04 | `diagrams/04_volatile_jmm.png` | CPU cache vs main memory |
| 05 | `diagrams/05_cas_atomic.png` | CAS success/failure paths |
| 06 | `diagrams/06_locks_comparison.png` | synchronized vs ReentrantLock vs RWLock |
| 07 | `diagrams/07_producer_consumer.png` | BlockingQueue implementations |
| 08 | `diagrams/08_thread_pool_executor.png` | Thread pool architecture |
| 09 | `diagrams/09_completable_future.png` | Async pipeline |
| 10 | `diagrams/10_concurrent_collections.png` | ConcurrentHashMap & CopyOnWrite |
| 11 | `diagrams/11_synchronizers.png` | Semaphore, Latch, Barrier, Phaser |
| 12 | `diagrams/12_jmm_happens_before.png` | JMM & happens-before rules |
| 13 | `diagrams/13_forkjoinpool.png` | Divide & conquer + work stealing |
| 14 | `diagrams/14_thread_local.png` | Per-thread storage |
| 15 | `diagrams/15_cheat_sheet.png` | Complete reference cheat sheet |

---

## 1. Introduction to Concurrency

**Concurrency** means multiple tasks making progress during overlapping time periods. It is about *dealing with* many things at once — not necessarily *doing* them at exactly the same time.

### Why Concurrency?

| Benefit | Example |
|---------|---------|
| **Responsiveness** | UI stays interactive while data loads |
| **Throughput** | Web server handles 10,000 requests/sec |
| **Resource utilisation** | CPU used during I/O waits |
| **Scalability** | Add cores, get more performance |

### Real-world systems that require concurrency

```
Web Servers        → handle thousands of simultaneous HTTP requests
Databases          → concurrent reads/writes with ACID guarantees
Banking Systems    → parallel transactions, account locking
Trading Platforms  → microsecond-latency order matching
Game Servers       → physics, AI, networking on separate threads
Chat Applications  → broadcast to millions concurrently
```

### The Fundamental Challenge

Concurrency introduces **non-determinism** — the program's behaviour depends on the order threads execute. This makes bugs intermittent, hard to reproduce, and difficult to debug.

```java
// This looks simple but has 3 possible outcomes with 2 threads
counter++; // NOT atomic: read → increment → write
```

---

## 2. Concurrency vs Parallelism

```
Concurrency                           Parallelism
─────────────────────────────────     ─────────────────────────────────
Task A ████░░░░████░░░░████           Task A ████████████████
Task B ░░░░████░░░░████░░░░           Task B ████████████████
        Single CPU, interleaved               Multi-core, simultaneous
```

| Aspect | Concurrency | Parallelism |
|--------|-------------|-------------|
| Definition | Multiple tasks progressing together | Multiple tasks executing at exactly the same instant |
| CPU requirement | Works on 1 core | Requires multiple cores |
| Focus | Coordination & structure | Raw execution speed |
| Goal | Responsiveness | Throughput |
| Example | One chef managing multiple dishes | Multiple chefs, one dish each |

### Key Insight

> Concurrency is about the **design** of a program. Parallelism is about the **execution**.
> A concurrent program *may or may not* run in parallel depending on available hardware.

---

## 3. Process vs Thread

### Process

- Independent execution unit with its own **address space**
- Separate heap, stack, code, and data segments
- Inter-process communication (IPC) is expensive (pipes, sockets, shared memory)
- Crash in one process does NOT crash others
- Example: Chrome opens each tab as a separate process

```
Process A                     Process B
┌─────────────────────┐       ┌─────────────────────┐
│ Code  │ Data  │ Heap│       │ Code  │ Data  │ Heap│
│ Stack │       │     │       │ Stack │       │     │
└─────────────────────┘       └─────────────────────┘
     Isolated memory                Isolated memory
```

### Thread

- Lightweight execution unit **within** a process
- Shares heap, code, and data with other threads in the same process
- Has its own **stack** and **program counter**
- Communication via shared memory (fast, but dangerous)
- Crash in one thread can crash the entire process

```
Process (JVM)
┌──────────────────────────────────────────┐
│  Shared: Heap, Method Area, Literals      │
│                                           │
│  Thread-1     Thread-2     Thread-3       │
│  ┌────────┐   ┌────────┐   ┌────────┐    │
│  │ Stack  │   │ Stack  │   │ Stack  │    │
│  │ PC     │   │ PC     │   │ PC     │    │
│  └────────┘   └────────┘   └────────┘    │
└──────────────────────────────────────────┘
```

### Comparison Table

| Aspect | Process | Thread |
|--------|---------|--------|
| Memory | Separate | Shared |
| Creation time | Slow (100ms+) | Fast (1ms) |
| Context switch | Expensive | Cheap |
| Communication | IPC (complex) | Shared memory (simple) |
| Crash impact | Isolated | Whole process |
| Example in Java | `ProcessBuilder` | `new Thread()` |

---

## 4. Creating Threads in Java

> **See:** `basics/ThreadCreation.java`

### Method 1: Extend Thread

```java
class MyThread extends Thread {
    @Override
    public void run() {
        System.out.println("Running: " + Thread.currentThread().getName());
    }
}

MyThread t = new MyThread();
t.setName("WorkerThread");
t.start(); // creates new OS thread and calls run()
// t.run();  ← WRONG: runs in current thread, no new thread created!
```

### Method 2: Implement Runnable (Preferred)

```java
class PrintTask implements Runnable {
    private final int id;
    PrintTask(int id) { this.id = id; }

    @Override
    public void run() {
        System.out.println("Task " + id + " on " + Thread.currentThread().getName());
    }
}

Thread t = new Thread(new PrintTask(42), "TaskThread");
t.start();
```

**Why prefer Runnable?** Separates *task logic* from *thread management*. Java allows only single inheritance, so extending Thread prevents extending other classes.

### Method 3: Lambda Expression (Java 8+)

```java
Runnable r = () -> System.out.println("Lambda thread: " + Thread.currentThread().getName());
new Thread(r, "LambdaThread").start();
```

### Method 4: Callable + FutureTask

```java
Callable<Long> task = () -> {
    long sum = 0;
    for (long i = 1; i <= 1_000_000; i++) sum += i;
    return sum;
};

FutureTask<Long> future = new FutureTask<>(task);
new Thread(future, "ComputeThread").start();
Long result = future.get(); // blocks until done
System.out.println("Sum = " + result);
```

### Thread Properties

```java
Thread t = Thread.currentThread();
t.getName();        // thread name
t.getId();          // unique ID
t.getPriority();    // 1(MIN) to 10(MAX), default 5
t.isDaemon();       // daemon threads don't prevent JVM exit
t.getState();       // NEW, RUNNABLE, BLOCKED, WAITING, TIMED_WAITING, TERMINATED
t.isAlive();        // true if started and not terminated
t.isInterrupted();  // check interrupt flag
```

### Daemon Threads

```java
Thread daemon = new Thread(() -> {
    while (true) { /* background work */ }
});
daemon.setDaemon(true); // MUST set before start()!
daemon.start();
// When only daemon threads remain, JVM exits
```

---

## 5. Thread Lifecycle

> **See diagram:** `diagrams/01_thread_lifecycle.png`
> **See:** `basics/ThreadLifecycle.java`

```
                    start()
  NEW ─────────────────────────────► RUNNABLE
                                         │
              ┌──────────────────────────┤
              │                          │
              ▼                          │  run() completes
         BLOCKED              ◄──────────┼──────► TERMINATED
    (waiting for monitor)                │
              │                          │
              ▼                          │
         WAITING              wait() / join() / park()
    (indefinite wait)                    │
              │                          │
              ▼                          │
       TIMED_WAITING          sleep(ms) / wait(ms)
    (bounded wait)
```

### State Descriptions

| State | Cause | How to exit |
|-------|-------|-------------|
| `NEW` | `new Thread()` | `start()` |
| `RUNNABLE` | `start()` called | JVM schedules to CPU |
| `BLOCKED` | Waiting for synchronized lock | Lock becomes available |
| `WAITING` | `wait()`, `join()`, `park()` | `notify()`, `notifyAll()`, `unpark()` |
| `TIMED_WAITING` | `sleep(ms)`, `wait(ms)`, `join(ms)` | Timeout or signal |
| `TERMINATED` | `run()` completes or exception | — |

### Key Methods

```java
Thread t = new Thread(task);
t.start();                    // NEW → RUNNABLE

Thread.sleep(1000);           // TIMED_WAITING for 1s (releases CPU, NOT lock)
t.join();                     // caller waits for t to TERMINATE
t.join(500);                  // caller waits max 500ms

t.interrupt();                // sets interrupt flag; wakes sleeping/waiting thread
Thread.currentThread().isInterrupted(); // check flag
Thread.interrupted();         // check AND clear flag

Object o = new Object();
synchronized(o) {
    o.wait();                 // WAITING — releases lock!
    o.wait(1000);             // TIMED_WAITING — releases lock
    o.notify();               // wake ONE thread waiting on o
    o.notifyAll();            // wake ALL threads waiting on o
}
```

### Critical: sleep() vs wait()

| `sleep()` | `wait()` |
|-----------|----------|
| Does NOT release the monitor lock | Releases the monitor lock |
| `Thread.sleep(ms)` — static method | `obj.wait()` — instance method |
| Resumes after timeout | Must be notified |
| `InterruptedException` | `InterruptedException` |

---

## 6. Race Conditions

> **See diagram:** `diagrams/02_race_condition.png`
> **See:** `basics/RaceConditionDemo.java`

A race condition occurs when:
1. Multiple threads access **shared mutable data**
2. At least one thread **writes**
3. No proper **synchronization** exists

### The Classic Example

```java
// counter++ is THREE operations — NOT atomic!
class Counter {
    int count = 0;
    void increment() { count++; }  // BUG!
}

// Thread-1         Thread-2
// READ  count=0
//                  READ  count=0    ← STALE READ
// count = 0+1 = 1
//                  count = 0+1 = 1  ← OVERWRITES T1's write!
// WRITE count=1
//                  WRITE count=1
// Expected: 2   Got: 1 ← DATA CORRUPTION
```

### Check-Then-Act Pattern (Another Race)

```java
// UNSAFE — check and act are NOT atomic
if (!map.containsKey(key)) {     // Thread-1 checks: false
    map.put(key, value);          // Thread-2 also checks: false
}                                 // BOTH insert! → duplicate!

// SAFE — use ConcurrentHashMap atomic operation
map.putIfAbsent(key, value);     // atomic check-and-insert
```

### Read-Modify-Write Pattern

```java
// All these look safe but aren't:
count++;          // read, modify, write
count += 5;       // read, modify, write
if (x > max) max = x;  // read, compare, write

// Safe alternatives:
AtomicInteger counter = new AtomicInteger(0);
counter.incrementAndGet();        // atomic
counter.addAndGet(5);             // atomic
counter.updateAndGet(x -> Math.max(x, newVal)); // atomic
```

---

## 7. Synchronization

> **See:** `synchronization/SynchronizationDemo.java`

Synchronization restricts concurrent access to ensure only **one thread** executes the **critical section** at a time.

### Synchronized Method

```java
class BankAccount {
    private double balance;

    // Entire method is critical section
    // Locks on 'this' instance
    public synchronized void deposit(double amount) {
        balance += amount; // safe — only one thread at a time
    }

    public synchronized void withdraw(double amount) {
        if (balance >= amount) balance -= amount;
    }

    // Read also needs sync — otherwise stale reads
    public synchronized double getBalance() { return balance; }
}
```

### Synchronized Block (Preferred — finer scope)

```java
class Inventory {
    private int stock = 0;
    private final Object lock = new Object(); // explicit lock object

    void addStock(int qty) {
        // Only lock what's necessary — rest can run concurrently
        synchronized(lock) {
            stock += qty;
        }
        // logging, events, etc. can happen here without holding lock
    }
}
```

### Static Synchronized (Class-level lock)

```java
class IdGenerator {
    private static long nextId = 1000;

    // Locks on IdGenerator.class — one lock for ALL instances!
    public static synchronized long generate() {
        return nextId++;
    }
}
```

### wait() and notify() — Coordination

```java
class MessageQueue {
    private String message;
    private boolean hasMessage = false;

    synchronized void send(String msg) throws InterruptedException {
        while (hasMessage) wait();  // release lock, wait for consumer
        message    = msg;
        hasMessage = true;
        notifyAll();               // wake all waiting threads
    }

    synchronized String receive() throws InterruptedException {
        while (!hasMessage) wait(); // wait for producer
        hasMessage = false;
        notifyAll();
        return message;
    }
}
```

**Always use `while` not `if` for wait conditions** — spurious wakeups can occur!

---

## 8. Monitor Locks

Every Java object has an associated **monitor** (intrinsic lock). The monitor has:
- **Entry set** — threads trying to acquire the lock (BLOCKED)
- **Wait set** — threads that called wait() (WAITING)
- **Owner** — the thread currently holding the lock

```
           synchronized block entered
Thread ──────────────────────────────►
                                      Monitor Lock (on obj)
                                      ┌─────────────────────┐
                                      │ Owner: Thread-1      │
                                      │ Entry set: [T2, T3]  │
                                      │ Wait set:  [T4]      │
                                      └─────────────────────┘
                                           ▲
                                           │ T4 called obj.wait()
                                           │ (releases lock, moves to wait set)
```

### Reentrancy

A thread that already holds a lock can acquire the **same** lock again (reentrant):

```java
class Parent {
    synchronized void method1() {
        method2(); // already holds lock on 'this' — OK!
    }

    synchronized void method2() {
        // Same lock — reentrant, no deadlock
        System.out.println("method2");
    }
}
```

---

## 9. Deadlock, Starvation, Livelock

> **See diagram:** `diagrams/03_deadlock.png`
> **See:** `synchronization/DeadlockDemo.java`

### Deadlock

Four **necessary conditions** (all must hold simultaneously):

1. **Mutual Exclusion** — resource held exclusively
2. **Hold and Wait** — thread holds one resource, waits for another
3. **No Preemption** — resource can't be forcibly taken
4. **Circular Wait** — cycle in wait-for graph

```java
// Classic deadlock
Thread-1: synchronized(lockA) { synchronized(lockB) { ... } }
Thread-2: synchronized(lockB) { synchronized(lockA) { ... } }
//         T1 holds A, wants B ↕ T2 holds B, wants A — forever!
```

### Deadlock Prevention

```java
// Fix 1: Lock ordering — always acquire in same order
Thread-1: synchronized(lockA) { synchronized(lockB) { ... } }
Thread-2: synchronized(lockA) { synchronized(lockB) { ... } } // same!

// Fix 2: tryLock with timeout
if (lockA.tryLock(100, MILLISECONDS)) {
    try {
        if (lockB.tryLock(100, MILLISECONDS)) {
            try {
                // critical section
            } finally { lockB.unlock(); }
        } else {
            // retry later
        }
    } finally { lockA.unlock(); }
}

// Fix 3: Lock ordering by identity
void transfer(Account from, Account to, int amount) {
    Account first  = System.identityHashCode(from) < System.identityHashCode(to) ? from : to;
    Account second = first == from ? to : from;
    synchronized(first) { synchronized(second) { /* safe */ } }
}
```

### Starvation

A thread is perpetually denied access because other threads always get priority.

```java
// Causes of starvation:
// 1. High-priority threads monopolise CPU
// 2. Non-fair locks — same threads keep winning
// 3. Thread calling notify() when wait() expects notifyAll()

// Fix: fair lock
ReentrantLock fairLock = new ReentrantLock(true); // fair=true → FIFO ordering
```

### Livelock

Threads are active but keep responding to each other, making no progress (like two people in a hallway both stepping aside at the same time).

```java
// Livelock example
while (true) {
    if (lockA.tryLock()) {
        if (lockB.tryLock()) { /* work */ break; }
        else { lockA.unlock(); Thread.sleep(random()); } // retry
    }
}
// If both threads always retry at the same time → livelock
// Fix: randomised backoff, or prioritise one thread
```

---

## 10. volatile Keyword

> **See diagram:** `diagrams/04_volatile_jmm.png`
> **See:** `synchronization/AtomicAndVolatileDemo.java`

### The Problem: CPU Caches

Modern CPUs have multiple levels of cache. Without `volatile`, a thread may read a **stale cached copy** of a variable rather than the latest value in main memory.

```
Without volatile:
┌──────────┐         ┌──────────┐
│ CPU-1    │         │ CPU-2    │
│ L1 cache │         │ L1 cache │
│ flag=true│         │flag=false│ ← stale!
└────┬─────┘         └────┬─────┘
     │                    │
     └────────┬───────────┘
         Main Memory
          flag=true
```

### volatile Guarantees

1. **Visibility** — writes immediately flushed to main memory; reads always from main memory
2. **Ordering** — prevents instruction reordering around volatile accesses (happens-before)

```java
// Pattern: volatile flag for stopping threads
volatile boolean running = true;

Thread worker = new Thread(() -> {
    while (running) {  // reads from main memory every iteration
        doWork();
    }
    System.out.println("Stopped!");
});
worker.start();

Thread.sleep(1000);
running = false;  // immediately visible to worker thread
worker.join();
```

### When volatile is NOT enough

```java
volatile int count = 0;
count++;  // STILL NOT THREAD SAFE!
// volatile only ensures visibility, not atomicity of compound operations

// read(count) → increment → write(count)
// Two threads can interleave these three steps!

// Fix: use AtomicInteger or synchronized
```

### volatile vs synchronized

| | `volatile` | `synchronized` |
|-|------------|----------------|
| Visibility | ✅ Yes | ✅ Yes |
| Atomicity (compound ops) | ❌ No | ✅ Yes |
| Blocking | ❌ Never blocks | ✅ Blocks waiting threads |
| Performance | 🔥 Faster | 🐢 Slower |
| Use case | Simple flags, state | Complex critical sections |

---

## 11. Atomic Classes

> **See:** `synchronization/AtomicAndVolatileDemo.java`

Atomic classes provide **lock-free thread safety** using CPU-level CAS instructions.

### Available Classes

```
java.util.concurrent.atomic
├── AtomicBoolean
├── AtomicInteger     ← most common
├── AtomicLong
├── AtomicReference<V>
├── AtomicIntegerArray
├── AtomicLongArray
├── AtomicReferenceArray<E>
├── LongAdder          ← better than AtomicLong under high contention
├── LongAccumulator
├── DoubleAdder
└── DoubleAccumulator
```

### AtomicInteger

```java
AtomicInteger count = new AtomicInteger(0);

count.get();                    // read
count.set(10);                  // write
count.getAndSet(20);            // read then write

count.incrementAndGet();        // ++count (returns new value)
count.getAndIncrement();        // count++ (returns old value)
count.decrementAndGet();        // --count
count.addAndGet(5);             // count += 5

// Conditional update
count.compareAndSet(expected, newValue); // returns true if updated

// Functional updates (Java 8+)
count.updateAndGet(v -> v * 2);                       // apply fn atomically
count.accumulateAndGet(5, Integer::sum);              // combine atomically
```

### LongAdder — Better Under Contention

```java
// AtomicLong: all threads contend on single variable
AtomicLong atomicLong = new AtomicLong(0);

// LongAdder: uses multiple "cells", each thread updates its own cell
// sum() combines them at read time — much less contention!
LongAdder longAdder = new LongAdder();
longAdder.increment();
longAdder.add(5);
long total = longAdder.sum();   // may not be accurate during concurrent writes

// Use AtomicLong when you need exact real-time value
// Use LongAdder when you need high-frequency writes and occasional reads
```

### AtomicReference — Lock-Free Data Structures

```java
// Lock-free stack
AtomicReference<Node<T>> head = new AtomicReference<>(null);

void push(T value) {
    Node<T> newNode, oldHead;
    do {
        oldHead = head.get();
        newNode = new Node<>(value, oldHead);
    } while (!head.compareAndSet(oldHead, newNode)); // retry if another pushed
}
```

---

## 12. CAS — Compare And Swap

> **See diagram:** `diagrams/05_cas_atomic.png`

CAS is a **single atomic CPU instruction** that enables lock-free synchronization.

### Algorithm

```
CAS(memory_location, expected_value, new_value):
    if *memory_location == expected_value:
        *memory_location = new_value
        return SUCCESS
    else:
        return FAILURE (caller should retry with fresh read)
```

### Java implementation

```java
// Internally, AtomicInteger.incrementAndGet() does:
public final int incrementAndGet() {
    int current, next;
    do {
        current = get();           // read current
        next    = current + 1;     // compute new value
    } while (!compareAndSet(current, next)); // retry if concurrent write
    return next;
}

// This is the spin-lock / optimistic concurrency pattern
```

### CAS Properties

| Property | Description |
|----------|-------------|
| **Non-blocking** | Threads never sleep waiting — they retry |
| **Lock-free** | System makes progress even if individual threads fail |
| **ABA Problem** | A→B→A: CAS sees A, thinks no change, but state has changed |
| **ABA Fix** | `AtomicStampedReference` — adds version counter |

### ABA Problem & Fix

```java
// ABA Problem:
// Thread-1 reads head=A
// Thread-2: A→B→A (value returns to A)
// Thread-1 CAS: sees A, thinks no change → succeeds incorrectly!

// Fix: AtomicStampedReference
AtomicStampedReference<Node> head = new AtomicStampedReference<>(node, 0);

int[] stamp = new int[1];
Node current = head.get(stamp);
head.compareAndSet(current, newNode, stamp[0], stamp[0] + 1); // check version too
```

### When to Use CAS vs Locks

| Use CAS | Use Locks |
|---------|-----------|
| Simple counters | Complex multi-step operations |
| Short critical sections | Long-running critical sections |
| High contention with simple ops | Low contention |
| Lock-free data structures | When fairness is required |

---

## 13. ReentrantLock

> **See:** `locks/ReentrantLockDemo.java`

`ReentrantLock` provides the same mutual exclusion as `synchronized` but with more capabilities.

### Basic Usage

```java
ReentrantLock lock = new ReentrantLock();

lock.lock();          // acquire (blocks if not available)
try {
    // critical section
} finally {
    lock.unlock();    // ALWAYS in finally — never skip!
}
```

### tryLock — Non-Blocking

```java
if (lock.tryLock()) {                    // immediate: true if got lock
    try { /* work */ } finally { lock.unlock(); }
}

if (lock.tryLock(500, MILLISECONDS)) {  // wait up to 500ms
    try { /* work */ } finally { lock.unlock(); }
} else {
    // could not acquire — handle gracefully
}
```

### Interruptible Lock

```java
lock.lockInterruptibly();   // throws InterruptedException if interrupted while waiting
try {
    // critical section
} finally {
    lock.unlock();
}
```

### Fair Lock

```java
ReentrantLock fairLock = new ReentrantLock(true); // FIFO ordering
// Prevents starvation but has lower throughput than unfair lock
```

### Condition Variables (Multiple wait sets)

```java
ReentrantLock lock       = new ReentrantLock();
Condition     notFull    = lock.newCondition();  // separate wait set!
Condition     notEmpty   = lock.newCondition();

void put(T item) throws InterruptedException {
    lock.lock();
    try {
        while (buffer.size() == capacity) notFull.await();  // wait for space
        buffer.add(item);
        notEmpty.signalAll();  // wake consumers specifically
    } finally { lock.unlock(); }
}

T take() throws InterruptedException {
    lock.lock();
    try {
        while (buffer.isEmpty()) notEmpty.await();  // wait for items
        T item = buffer.remove();
        notFull.signalAll();   // wake producers specifically
        return item;
    } finally { lock.unlock(); }
}
```

### Diagnostic Methods

```java
lock.isLocked();          // is held by any thread?
lock.isHeldByCurrentThread(); // does current thread hold it?
lock.getHoldCount();      // times current thread has locked (reentrancy depth)
lock.getQueueLength();    // threads waiting to acquire
lock.hasQueuedThreads();  // any threads waiting?
```

---

## 14. ReadWriteLock & StampedLock

> **See diagram:** `diagrams/06_locks_comparison.png`
> **See:** `locks/ReadWriteLockDemo.java`

### ReadWriteLock — Optimise Read-Heavy Access

```java
ReadWriteLock rwLock    = new ReentrantReadWriteLock(true); // fair
Lock          readLock  = rwLock.readLock();
Lock          writeLock = rwLock.writeLock();

// Multiple concurrent readers — no blocking between them
void read() {
    readLock.lock();
    try { /* read data */ }
    finally { readLock.unlock(); }
}

// Exclusive writer — blocks all readers AND writers
void write(String key, Object val) {
    writeLock.lock();
    try { /* modify data */ }
    finally { writeLock.unlock(); }
}
```

### When Does ReadWriteLock Help?

```
ReadWriteLock benefit = (readTime * readCount) vs writeLock overhead
Best for: reads >> writes AND read operations are slow
          (cache lookups, complex queries, large data structures)
Not for: equal reads and writes (overhead not worth it)
```

### StampedLock (Java 8+) — Optimistic Reading

```java
StampedLock sl = new StampedLock();

double distanceFromOrigin() {
    // Try optimistic read first (zero cost if no write)
    long stamp = sl.tryOptimisticRead();
    double curX = x, curY = y;

    if (!sl.validate(stamp)) {
        // A write occurred! Fall back to full read lock
        stamp = sl.readLock();
        try { curX = x; curY = y; }
        finally { sl.unlockRead(stamp); }
    }

    return Math.sqrt(curX*curX + curY*curY);
}
```

### Lock Comparison

| | `synchronized` | `ReentrantLock` | `ReadWriteLock` | `StampedLock` |
|-|----------------|-----------------|-----------------|---------------|
| Simplicity | ✅ Simple | ⚠️ Manual unlock | ⚠️ Two locks | ❌ Complex |
| tryLock | ❌ | ✅ | ✅ | ✅ |
| Fairness | ❌ | ✅ | ✅ | ❌ |
| Conditions | 1 | Multiple | Per lock | ❌ |
| Read concurrency | ❌ | ❌ | ✅ | ✅ (optimistic) |
| Performance | Good | Good | Read-heavy | Best |

---

## 15. Producer-Consumer Problem

> **See diagram:** `diagrams/07_producer_consumer.png`
> **See:** `problems/ProducerConsumer.java`

Classic concurrency problem: producers generate data items; consumers process them. Need to coordinate so consumers don't read from an empty buffer and producers don't write to a full one.

### Pattern 1: wait() / notify()

```java
class BoundedBuffer {
    private final Queue<Integer> queue = new LinkedList<>();
    private final int capacity;

    BoundedBuffer(int capacity) { this.capacity = capacity; }

    synchronized void produce(int val) throws InterruptedException {
        while (queue.size() == capacity) wait();  // block when full
        queue.add(val);
        notifyAll();  // wake consumers
    }

    synchronized int consume() throws InterruptedException {
        while (queue.isEmpty()) wait();  // block when empty
        int val = queue.remove();
        notifyAll();  // wake producers
        return val;
    }
}
```

**Common mistake:** Using `if` instead of `while` — always `while` to guard against spurious wakeups!

### Pattern 2: BlockingQueue (Preferred)

```java
// Java handles all synchronization internally
BlockingQueue<Task> queue = new ArrayBlockingQueue<>(100);

// Producer
Thread producer = new Thread(() -> {
    queue.put(createTask());  // blocks when full — no sync code needed!
});

// Consumer
Thread consumer = new Thread(() -> {
    Task t = queue.take();    // blocks when empty — clean and simple!
    process(t);
});
```

---

## 16. BlockingQueue

> **See:** `collections/ConcurrentCollectionsDemo.java`

`BlockingQueue` is the cornerstone of producer-consumer in Java. It handles all synchronization internally.

### Operations

| | Throws Exception | Returns value | Blocks | Times out |
|-|-----------------|---------------|--------|-----------|
| **Insert** | `add(e)` | `offer(e)` | `put(e)` | `offer(e, time, unit)` |
| **Remove** | `remove()` | `poll()` | `take()` | `poll(time, unit)` |
| **Examine** | `element()` | `peek()` | — | — |

### Implementations

```java
// Bounded FIFO (most common)
BlockingQueue<T> q = new ArrayBlockingQueue<>(100, true); // fair

// Unbounded (uses linked nodes, slightly better throughput)
BlockingQueue<T> q = new LinkedBlockingQueue<>();         // unbounded
BlockingQueue<T> q = new LinkedBlockingQueue<>(100);      // bounded

// Priority ordering
BlockingQueue<T> q = new PriorityBlockingQueue<>();       // unbounded + sorted

// Synchronous handoff — zero capacity, direct producer→consumer
BlockingQueue<T> q = new SynchronousQueue<>();            // pairs threads directly

// Delayed elements — only available after delay
BlockingQueue<T> q = new DelayQueue<>();                  // elements implement Delayed
```

---

## 17. Thread Pools

Creating a new thread for every task is expensive:
- OS thread creation: ~100μs
- JVM stack allocation: 256KB–1MB per thread
- Context switching overhead

**Thread pools** pre-create a set of threads that wait for work, dramatically reducing latency and memory usage.

```
Without pool: New thread for each request
  Request-1 → [Create Thread] → Run → [Destroy Thread]
  Request-2 → [Create Thread] → Run → [Destroy Thread]
  Cost: O(n) thread creations

With pool: Reuse threads
  Request-1 → Worker-1 (reuse) → work → Wait for next
  Request-2 → Worker-2 (reuse) → work → Wait for next
  Cost: O(pool_size) thread creations total
```

### Thread Pool Sizing Rules

```
CPU-bound tasks:    poolSize = CPU_cores + 1
                    (extra 1 for when a thread pauses for GC/page fault)

I/O-bound tasks:    poolSize = CPU_cores × (1 + wait_time / compute_time)
                    (while one thread waits for I/O, others use the CPU)

Example: 4 cores, tasks that wait 90% of the time:
  poolSize = 4 × (1 + 9/1) = 40 threads
```

---

## 18. Executor Framework

> **See diagram:** `diagrams/08_thread_pool_executor.png`
> **See:** `executors/ExecutorDemo.java`

The Executor Framework (Java 5+) separates task submission from execution mechanics.

```
Executor
└── ExecutorService
    ├── AbstractExecutorService
    │   └── ThreadPoolExecutor         ← heart of the framework
    │       └── ScheduledThreadPoolExecutor
    └── ForkJoinPool                   ← work-stealing pool
```

### Factory Methods (Executors class)

```java
// Fixed: always N threads (no more, no less)
ExecutorService fixed = Executors.newFixedThreadPool(4);

// Cached: scales up/down, idle threads die after 60s
ExecutorService cached = Executors.newCachedThreadPool();

// Single: one thread, sequential FIFO
ExecutorService single = Executors.newSingleThreadExecutor();

// Scheduled: delayed/periodic tasks
ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(2);

// Work-stealing (Java 8+): uses all available cores
ExecutorService workStealing = Executors.newWorkStealingPool();
```

### ThreadPoolExecutor — Full Control

```java
ThreadPoolExecutor pool = new ThreadPoolExecutor(
    2,                              // corePoolSize: always alive
    8,                              // maximumPoolSize: max during burst
    60L, TimeUnit.SECONDS,         // keepAliveTime: extra threads idle time
    new ArrayBlockingQueue<>(100), // workQueue: task queue
    new ThreadFactory() {           // threadFactory: how to create threads
        int n = 0;
        public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "MyPool-" + ++n);
            t.setDaemon(false);
            return t;
        }
    },
    new ThreadPoolExecutor.CallerRunsPolicy() // rejectedHandler: when queue full
);
```

### Rejection Policies

| Policy | Behaviour |
|--------|-----------|
| `AbortPolicy` (default) | Throw `RejectedExecutionException` |
| `CallerRunsPolicy` | Run task in caller's thread (slows producer naturally) |
| `DiscardPolicy` | Silently drop task |
| `DiscardOldestPolicy` | Drop oldest queued task, retry new one |

### Scheduling

```java
ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(2);

// One-time delay
scheduler.schedule(task, 500, MILLISECONDS);

// Fixed rate — starts every N ms from initial start (regardless of task duration)
scheduler.scheduleAtFixedRate(task, 0, 1000, MILLISECONDS);

// Fixed delay — N ms gap between end of one run and start of next
scheduler.scheduleWithFixedDelay(task, 0, 1000, MILLISECONDS);
```

---

## 19. Callable and Future

> **See:** `executors/ExecutorDemo.java`

`Runnable.run()` returns `void` and cannot throw checked exceptions.
`Callable.call()` returns a result and can throw `Exception`.

```java
// Callable — like Runnable but with return value
Callable<Integer> sumTask = () -> {
    int sum = 0;
    for (int i = 1; i <= 100; i++) sum += i;
    return sum;
};

ExecutorService pool = Executors.newFixedThreadPool(4);

// submit() returns a Future<T>
Future<Integer> future = pool.submit(sumTask);

// Do other work while computation runs...

// get() blocks until result ready
int result = future.get();           // blocks indefinitely
int result2 = future.get(5, SECONDS); // blocks with timeout → TimeoutException

future.isDone();       // true if completed (success or exception)
future.isCancelled();  // true if cancelled
future.cancel(true);   // cancel (true = interrupt if running)
```

### invokeAll — Parallel Batch

```java
List<Callable<String>> tasks = List.of(
    () -> fetchFromService("A"),
    () -> fetchFromService("B"),
    () -> fetchFromService("C")
);

// Submits all, waits for ALL to complete
List<Future<String>> results = pool.invokeAll(tasks);  // blocks until all done

for (Future<String> f : results) {
    System.out.println(f.get());  // already done, get() returns immediately
}
```

### invokeAny — First Wins

```java
// Submit all, return result of first to succeed, cancel the rest
String fastest = pool.invokeAny(List.of(
    () -> queryServer("primary"),
    () -> queryServer("replica1"),
    () -> queryServer("replica2")
));
// Returns whichever server responds first
```

---

## 20. CompletableFuture

> **See diagram:** `diagrams/09_completable_future.png`
> **See:** `async/CompletableFutureDemo.java`

`CompletableFuture` (Java 8+) enables composable, non-blocking async programming.

### Starting an Async Operation

```java
// supplyAsync — returns a value
CompletableFuture<String> cf = CompletableFuture
    .supplyAsync(() -> fetchUser(42));             // uses ForkJoinPool.commonPool()

CompletableFuture<String> cf2 = CompletableFuture
    .supplyAsync(() -> fetchUser(42), customPool); // use custom executor

// runAsync — no return value
CompletableFuture<Void> cf3 = CompletableFuture
    .runAsync(() -> sendEmail("user@example.com"));
```

### Chaining (Pipeline)

```java
CompletableFuture<Double> result = CompletableFuture
    .supplyAsync(() -> fetchUser(42))          // String
    .thenApply(user -> getUserOrders(user))    // String (sync, same thread)
    .thenApplyAsync(orders -> parse(orders))   // List<Order> (async, pool)
    .thenApply(orders -> calculateTotal(orders)); // Double
```

### Combining

```java
// thenCombine — two independent CFs, combine when both done
CompletableFuture<String> user    = CompletableFuture.supplyAsync(() -> getUser(1));
CompletableFuture<String> orders  = CompletableFuture.supplyAsync(() -> getOrders(1));
CompletableFuture<String> combined = user.thenCombine(orders, (u, o) -> u + ":" + o);

// allOf — wait for ALL (returns CF<Void>)
CompletableFuture<Void> allDone = CompletableFuture.allOf(cf1, cf2, cf3);
allDone.get(); // blocks until all complete

// anyOf — complete when ANY finishes
CompletableFuture<Object> first = CompletableFuture.anyOf(cf1, cf2, cf3);
Object winner = first.get();
```

### Error Handling

```java
CompletableFuture<String> result = CompletableFuture
    .supplyAsync(() -> riskyOperation())       // may throw
    .exceptionally(ex -> {
        log.error("Failed: {}", ex.getMessage());
        return "fallback value";               // recover
    });

// handle — receives (result, exception) — only one is non-null
CompletableFuture<String> result2 = CompletableFuture
    .supplyAsync(() -> riskyOperation())
    .handle((value, ex) -> ex != null ? "error: " + ex : "ok: " + value);

// whenComplete — side effect, does not change result
CompletableFuture<String> result3 = CompletableFuture
    .supplyAsync(() -> getData())
    .whenComplete((value, ex) -> logResult(value, ex));
```

### thenCompose — flatMap

```java
// WRONG — produces CF<CF<String>>
CompletableFuture<CompletableFuture<String>> wrong =
    cf.thenApply(user -> asyncFetchProfile(user));

// CORRECT — produces CF<String>
CompletableFuture<String> right =
    cf.thenCompose(user -> asyncFetchProfile(user)); // flatMap!
```

---

## 21. ForkJoinPool

> **See diagram:** `diagrams/13_forkjoinpool.png`
> **See:** `async/ForkJoinDemo.java`

`ForkJoinPool` is designed for recursive divide-and-conquer tasks using **work-stealing**.

### Divide and Conquer Pattern

```java
class ParallelSum extends RecursiveTask<Long> {
    static final int THRESHOLD = 10_000;
    final long[] array;
    final int from, to;

    ParallelSum(long[] array, int from, int to) { /* ... */ }

    @Override
    protected Long compute() {
        if (to - from <= THRESHOLD) {
            // Base case: compute directly
            long sum = 0;
            for (int i = from; i < to; i++) sum += array[i];
            return sum;
        }

        // Divide
        int mid = (from + to) / 2;
        ParallelSum left  = new ParallelSum(array, from, mid);
        ParallelSum right = new ParallelSum(array, mid,  to);

        left.fork();                // submit left asynchronously
        long rightResult = right.compute(); // compute right in current thread
        long leftResult  = left.join();     // wait for left

        // Conquer: combine results
        return leftResult + rightResult;
    }
}

// Usage
ForkJoinPool pool   = ForkJoinPool.commonPool();
long         result = pool.invoke(new ParallelSum(data, 0, data.length));
```

### Work-Stealing Algorithm

```
Thread-1 deque: [T1, T2, T3, T4]   Thread-1 processes from front
Thread-2 deque: [T5]
Thread-3 deque: [T6, T7, T8, T9]
Thread-4 deque: []                   Thread-4 IDLE

Thread-4 steals T9 from Thread-3's BACK (minimises contention at front)
```

### RecursiveAction (no return value)

```java
class ParallelSort extends RecursiveAction {
    @Override
    protected void compute() {
        if (to - from <= THRESHOLD) {
            Arrays.sort(array, from, to); // base case
            return;
        }
        int mid = (from + to) / 2;
        invokeAll(new ParallelSort(array, from, mid),
                  new ParallelSort(array, mid,  to));  // fork both, wait both
        merge(array, from, mid, to);
    }
}
```

### parallelStream — uses ForkJoinPool internally

```java
// Automatically uses ForkJoinPool.commonPool()
long sum = LongStream.rangeClosed(1, 1_000_000)
    .parallel()
    .sum();

// Custom pool for parallelStream
ForkJoinPool customPool = new ForkJoinPool(4);
customPool.submit(() ->
    list.parallelStream()
        .filter(x -> x > 0)
        .mapToLong(Long::parseLong)
        .sum()
).get();
```

---

## 22. Concurrent Collections

> **See diagram:** `diagrams/10_concurrent_collections.png`
> **See:** `collections/ConcurrentCollectionsDemo.java`

Standard Java collections (`HashMap`, `ArrayList`) are NOT thread-safe. The `java.util.concurrent` package provides safe alternatives.

### Quick Reference

| Unsafe | Synchronized Wrapper | Concurrent (Preferred) |
|--------|---------------------|------------------------|
| `HashMap` | `Collections.synchronizedMap()` | `ConcurrentHashMap` |
| `ArrayList` | `Collections.synchronizedList()` | `CopyOnWriteArrayList` |
| `LinkedList` | `Collections.synchronizedList()` | `ConcurrentLinkedQueue` |
| `HashSet` | `Collections.synchronizedSet()` | `ConcurrentSkipListSet` |
| `TreeMap` | `Collections.synchronizedSortedMap()` | `ConcurrentSkipListMap` |
| `LinkedList` (as queue) | — | `ArrayBlockingQueue` |

### Why NOT synchronizedXxx Wrappers?

```java
Map<String, Integer> map = Collections.synchronizedMap(new HashMap<>());

// Each individual operation is thread-safe...
map.put("key", 1);       // safe
map.get("key");          // safe

// ...but compound operations are NOT!
if (!map.containsKey("key")) {    // Thread-1 checks
    map.put("key", 1);            // Thread-2 also checks and inserts
}                                 // Thread-1 inserts too → duplicate!

// Also: iterating requires external synchronization!
synchronized(map) {
    for (Map.Entry<K,V> e : map.entrySet()) { ... } // safe
}
```

### CopyOnWriteArrayList

```java
CopyOnWriteArrayList<String> list = new CopyOnWriteArrayList<>();
list.add("Alice");

// Every write creates a FULL COPY of the underlying array
// Reads are ALWAYS lock-free (they read the current stable snapshot)

// SAFE to iterate while writing — no ConcurrentModificationException!
for (String s : list) {     // reads snapshot from before loop start
    list.add("Bob");         // creates new copy — doesn't affect iteration
}

// Best for: event listeners, small lists with rare writes
// Avoid for: large lists or high-frequency writes (copy is O(n) each time)
```

---

## 23. ConcurrentHashMap Deep Dive

> **See:** `collections/ConcurrentCollectionsDemo.java`

`ConcurrentHashMap` is the gold standard for concurrent maps.

### Internals (Java 8+)

- Array of **Node** entries (like HashMap)
- **No locks for empty buckets** — CAS to insert first element
- **Synchronized on bucket head** for chains (only one bucket locked at a time)
- **Reads are always lock-free** (volatile node reads)
- Default concurrency level: **number of CPUs**

```
Segment 0:  A──B──C     ← only this segment locked during write to A/B/C
Segment 1:  D──E         ← Thread-2 can read/write concurrently
Segment 2:  (empty)
...
Segment 15: X──Y──Z
```

### Atomic Operations (Java 8+)

```java
ConcurrentHashMap<String, Integer> map = new ConcurrentHashMap<>();

// putIfAbsent — atomic check-then-insert
map.putIfAbsent("alice", 100);

// compute — atomically update based on current value
map.compute("alice", (key, currentVal) ->
    currentVal == null ? 1 : currentVal + 1);  // atomic increment

// computeIfAbsent — create only if missing (lazy initialization!)
map.computeIfAbsent("alice", key -> expensiveInit(key));  // called at most once per key

// computeIfPresent — update only if present
map.computeIfPresent("alice", (key, val) -> val * 2);

// merge — combine new and existing values
map.merge("alice", 50, Integer::sum);  // alice += 50, or alice = 50 if missing

// Bulk operations (parallel when > threshold)
map.forEach(1, (k, v) -> process(k, v));
map.search(1, (k, v) -> v > 100 ? v : null);  // find first matching value
long total = map.reduceValues(1, Long::sum);    // aggregate
```

### size() Warning

```java
// size() is approximate under concurrent modification!
map.size();        // may not reflect in-flight puts/removes

// For accurate counting under concurrency:
LongAdder counter = new LongAdder();
// increment on put, decrement on remove
// counter.sum() gives exact count
```

---

## 24. ThreadLocal

> **See diagram:** `diagrams/14_thread_local.png`
> **See:** `advanced/AdvancedSynchronizersDemo.java`

`ThreadLocal` gives each thread its **own independent copy** of a variable. No synchronization needed because threads never share the same object.

### How it works internally

```
ThreadLocal<Integer> userId = new ThreadLocal<>();

Thread-1: userId.set(101) → stored in Thread-1's ThreadLocalMap
Thread-2: userId.set(202) → stored in Thread-2's ThreadLocalMap
Thread-3: userId.set(303) → stored in Thread-3's ThreadLocalMap

userId.get() in Thread-1 → returns 101 (not 202 or 303!)
```

### Usage

```java
// Typical request-scoped context
public class RequestContext {
    private static final ThreadLocal<String> userId =
        ThreadLocal.withInitial(() -> "anonymous");

    private static final ThreadLocal<String> traceId =
        ThreadLocal.withInitial(() -> UUID.randomUUID().toString());

    public static void setUserId(String id) { userId.set(id); }
    public static String getUserId()         { return userId.get(); }
    public static String getTraceId()        { return traceId.get(); }

    // ALWAYS call in finally block — critical in thread pools!
    public static void clear() { userId.remove(); traceId.remove(); }
}

// In a filter/interceptor:
try {
    RequestContext.setUserId(extractUserId(request));
    chain.doFilter(request, response);
} finally {
    RequestContext.clear();  // thread returns to pool — must clean up!
}
```

### Memory Leak Warning

```java
// Thread pools REUSE threads — old ThreadLocal values persist!
// If you don't call remove(), the next request on the same thread
// sees leftover data from the previous request!

// ALWAYS in a finally block:
threadLocal.remove();

// ThreadLocalMap holds a WeakReference to ThreadLocal key
// but a STRONG reference to the value
// → If ThreadLocal is GC'd but thread lives on → value leaks!
```

### Use Cases

| Use Case | Why ThreadLocal |
|----------|----------------|
| User session context | Each request thread has its own user |
| Database connections | Per-thread connection (no pooling overhead) |
| `SimpleDateFormat` | Not thread-safe — one per thread avoids synchronization |
| Spring `@Transactional` | Transaction bound to current thread |
| MDC logging | Per-thread request ID in log messages |

---

## 25. Java Memory Model (JMM)

> **See diagram:** `diagrams/12_jmm_happens_before.png`

The JMM defines the legal interactions between threads with respect to memory visibility and ordering.

### The Hardware Reality

Modern CPUs and JIT compilers aggressively optimise:
1. **CPU caching** — each core has L1/L2 cache; may not flush to main memory
2. **Write buffering** — writes go to buffer before reaching main memory
3. **Out-of-order execution** — CPU reorders instructions for efficiency
4. **JIT reordering** — compiler reorders statements for optimisation

```
Thread-1 writes:    a = 1; ready = true;  // may be reordered to: ready=true; a=1;
Thread-2 reads:     if (ready) use(a);    // may see ready=true but a=0!
```

### JMM Guarantees

The JMM provides an **abstraction** that lets programmers reason about memory without understanding hardware details. It defines what values threads are allowed to see.

**Key concept:** Without synchronization, threads can see **any previously written value** — not necessarily the latest.

### Atomicity under JMM

```java
// Atomic (single operation):
int read/write        ← atomic (except long/double on 32-bit JVM!)
boolean read/write
object reference read/write

// NOT atomic:
long/double read/write  ← two 32-bit operations on some platforms
compound operations: count++, if(x)x++

// Guaranteed atomic:
volatile long/double   ← volatile fixes the long/double split
AtomicLong             ← CAS-based atomicity
```

---

## 26. Happens-Before Relationship

The JMM defines **happens-before (HB)** — a guarantee that if action A happens-before action B, then:
- All effects of A are **visible** to B
- A is **ordered** before B

### Six Happens-Before Rules

```
Rule 1: Within a thread
        Statement-1 HB Statement-2 (program order within same thread)

Rule 2: Monitor unlock / lock
        unlock(monitor) HB lock(monitor)
        → All writes before unlock are visible to thread after lock

Rule 3: volatile write / read
        write(volatile_var) HB read(volatile_var)
        → volatile write immediately visible to all subsequent reads

Rule 4: Thread start
        Thread.start() HB any action in started thread
        → Writes before start() are visible inside the new thread

Rule 5: Thread termination
        All thread actions HB Thread.join() returning
        → After join(), all writes from the thread are visible

Rule 6: Transitivity
        If A HB B and B HB C, then A HB C
        → Chain of HB guarantees compose!
```

### Practical Example

```java
int x = 0;
volatile boolean ready = false;

// Thread-1:
x = 42;          // write x
ready = true;    // volatile write (HB all subsequent volatile reads)

// Thread-2:
if (ready) {     // volatile read
    // HB guarantees: Thread-2 MUST see x=42 here!
    // (because: write(x) HB write(ready) HB read(ready) HB read(x))
    System.out.println(x);  // guaranteed to print 42
}
```

---

## 27. synchronized vs volatile

| | `synchronized` | `volatile` |
|-|----------------|------------|
| **Visibility** | ✅ Yes | ✅ Yes |
| **Mutual Exclusion** | ✅ Yes | ❌ No |
| **Atomic compound ops** | ✅ Yes | ❌ No |
| **Blocks threads** | ✅ Yes | ❌ No |
| **Performance** | Medium | Fast |
| **Can cause deadlock** | ✅ Yes | ❌ No |

### Decision Guide

```
Is the operation a single read or write?
    YES → volatile (if visibility is the only concern)
    NO  → synchronized / Atomic

Does multiple threads write?
    YES → need atomicity: synchronized or Atomic
    NO  (one writer, many readers) → volatile

Example good use of volatile:
    volatile boolean isShutdown = false;  // written once, read by many

Example requiring synchronized:
    // Both read AND modify
    if (balance >= amount) balance -= amount;  // need synchronized!
```

---

## 28. CPU-Level Concepts

### Memory Hierarchy (Latency)

```
CPU Registers          < 1 ns    ← fastest, tiny (bytes)
L1 Cache               1-2 ns    ← per core, ~32-64 KB
L2 Cache               3-10 ns   ← per core, ~256 KB
L3 Cache (LLC)         30-40 ns  ← shared, ~4-32 MB
DRAM (Main Memory)     60-100 ns ← gigabytes
SSD Storage            100 μs    ← terabytes
HDD Storage            10 ms     ← slowest
```

### False Sharing

Two threads on different cores modify different variables that happen to be on the same **cache line** (typically 64 bytes). The cache line bounces between cores, causing massive overhead.

```java
// Bad — x and y likely on same cache line!
class Counter {
    volatile long x;  // Thread-1 updates
    volatile long y;  // Thread-2 updates
}

// Fix — pad to separate cache lines
class Counter {
    volatile long x;
    long p1, p2, p3, p4, p5, p6, p7;  // 56 bytes padding
    volatile long y;                   // now on different cache line
}

// Java 8+: @Contended annotation (add -XX:-RestrictContended JVM flag)
@Contended volatile long x;
@Contended volatile long y;
```

### Memory Barriers (Fences)

Hardware instructions that prevent CPU from reordering memory operations across the barrier:

```
LoadLoad:   No load can be reordered with a subsequent load
StoreStore: No store can be reordered with a subsequent store
LoadStore:  No load can be reordered with a subsequent store
StoreLoad:  Most expensive — prevents all reordering
```

`volatile` in Java compiles to `StoreLoad` barriers, ensuring full ordering.

---

## 29. Advanced Synchronizers

> **See diagram:** `diagrams/11_synchronizers.png`
> **See:** `advanced/AdvancedSynchronizersDemo.java`

### Semaphore — Counting Permits

```java
Semaphore pool = new Semaphore(3, true); // 3 permits, fair

// Acquire permit (blocks if 0 available)
pool.acquire();
try {
    useResource();
} finally {
    pool.release();  // return permit
}

// Non-blocking
if (pool.tryAcquire()) { ... }
if (pool.tryAcquire(100, MILLISECONDS)) { ... }

pool.availablePermits();  // current count
pool.getQueueLength();    // waiting threads
```

### CountDownLatch — One-Time Barrier

```java
CountDownLatch latch = new CountDownLatch(3); // count = 3

// Workers
new Thread(() -> {
    doSetup();
    latch.countDown();    // count → 2
}).start();

// ... 2 more workers call countDown()

// Main thread waits
latch.await();            // blocks until count == 0
latch.await(5, SECONDS);  // timeout version

// NOT reusable! After count reaches 0, it stays 0.
// Use case: service startup, test coordination, one-time gate
```

### CyclicBarrier — Reusable Checkpoint

```java
CyclicBarrier barrier = new CyclicBarrier(3, () -> {
    // Runs when all 3 threads arrive — before releasing
    System.out.println("All arrived! Starting next phase...");
});

// Each worker
barrier.await();   // block until all N threads call await()
// After all arrive → all released simultaneously → barrier resets for next use!
// await() returns arrival order (0 = last, N-1 = first in Java's impl)

// Use case: parallel simulation phases, parallel algorithm steps
```

### Phaser — Flexible Multi-Phase

```java
Phaser phaser = new Phaser(3); // 3 registered parties

// Dynamic registration
phaser.register();             // add party at runtime
phaser.arriveAndDeregister();  // leave after current phase

// Arrive and wait for others
phaser.arriveAndAwaitAdvance(); // like CyclicBarrier but more flexible

// Check phase
phaser.getPhase();             // current phase number (0, 1, 2, ...)
phaser.getRegisteredParties(); // total registered

// Override to control advancement
Phaser p = new Phaser() {
    @Override
    protected boolean onAdvance(int phase, int parties) {
        return phase >= 2 || parties == 0; // terminate after 3 phases
    }
};
```

### Exchanger — Two-Thread Data Swap

```java
Exchanger<List<Integer>> exchanger = new Exchanger<>();

// Thread-1 (producer)
Thread t1 = new Thread(() -> {
    List<Integer> buffer = fillBuffer();
    List<Integer> emptyBuf = exchanger.exchange(buffer); // hands off, gets empty buffer
    // continue with emptyBuf
});

// Thread-2 (consumer)
Thread t2 = new Thread(() -> {
    List<Integer> toFill = new ArrayList<>();
    List<Integer> fullBuf = exchanger.exchange(toFill); // gets full buffer
    process(fullBuf);
});
```

---

## 30. Real-World Use Cases

### Banking System

```java
// Transfer between accounts — need to lock BOTH accounts atomically
class BankService {
    void transfer(Account from, Account to, BigDecimal amount) {
        // Lock ordering by ID prevents deadlock
        Account first  = from.getId() < to.getId() ? from : to;
        Account second = first == from ? to : from;

        synchronized(first) {
            synchronized(second) {
                from.debit(amount);
                to.credit(amount);
                auditLog.record(from, to, amount);
            }
        }
    }
}
```

### Web Server — Request Handling

```java
// Handles thousands of concurrent requests
ThreadPoolExecutor webPool = new ThreadPoolExecutor(
    10,                          // 10 core threads
    200,                         // scale up to 200 during traffic spikes
    60, SECONDS,                 // idle threads die after 60s
    new ArrayBlockingQueue<>(500), // queue 500 more
    new ThreadPoolExecutor.CallerRunsPolicy() // apply backpressure
);

// Rate limiter per user
ConcurrentHashMap<String, TokenBucketRateLimiter> limiters = new ConcurrentHashMap<>();
limiters.computeIfAbsent(userId, id -> new TokenBucketRateLimiter(100, 10));
```

### Cache Pattern

```java
class AsyncCache<K, V> {
    private final ConcurrentHashMap<K, CompletableFuture<V>> cache = new ConcurrentHashMap<>();
    private final Function<K, CompletableFuture<V>> loader;

    CompletableFuture<V> get(K key) {
        return cache.computeIfAbsent(key, k -> {
            CompletableFuture<V> future = loader.apply(k);
            // Remove from cache on failure — don't cache errors
            future.exceptionally(ex -> { cache.remove(k); return null; });
            return future;
        });
    }
}
```

---

## 31. Performance Optimization

### Measure First

```java
// Use JMH (Java Microbenchmark Harness) for accurate benchmarks
@Benchmark
@BenchmarkMode(Mode.Throughput)
@Threads(8)
public void benchmark(Blackhole bh) {
    bh.consume(counter.incrementAndGet());
}
```

### Reduce Lock Contention

```java
// 1. Reduce lock scope — hold lock for minimum time
synchronized(this) {
    validateInput();    // ← don't need lock for this
    updateState();      // ← only this needs lock
    notifyListeners();  // ← don't need lock for this
}

// Better:
validateInput();
synchronized(this) { updateState(); }
notifyListeners();

// 2. Lock striping — different locks for different data
Map<Integer, Lock> locks = new ConcurrentHashMap<>();
Lock getLock(int key) {
    return locks.computeIfAbsent(key % 16, k -> new ReentrantLock());
}

// 3. Read-write separation
ReadWriteLock rwLock = new ReentrantReadWriteLock();
```

### Thread Pool Tuning

```java
// Monitor pool metrics
ThreadPoolExecutor pool = (ThreadPoolExecutor) executor;
System.out.println("Active:    " + pool.getActiveCount());
System.out.println("Queue:     " + pool.getQueue().size());
System.out.println("Completed: " + pool.getCompletedTaskCount());
System.out.println("Largest:   " + pool.getLargestPoolSize());

// Tuning guidelines:
// If active == max and queue growing → increase max or reduce task time
// If threads idle most of the time → reduce pool size
// If queue always full → use CallerRunsPolicy or increase queue
```

---

## 32. Best Practices

### DO

```java
// 1. Prefer immutability
final class Money {
    private final BigDecimal amount;
    private final Currency currency;
    // No setters — thread-safe by design!
}

// 2. Use concurrent collections over synchronizedXxx
ConcurrentHashMap   // not Collections.synchronizedMap()
CopyOnWriteArrayList // not Collections.synchronizedList()

// 3. Minimise lock scope
synchronized(lock) { state = newValue; }  // tiny scope

// 4. Always unlock in finally
lock.lock();
try { /* work */ } finally { lock.unlock(); }

// 5. Use thread pools — not raw threads
ExecutorService pool = Executors.newFixedThreadPool(4);
pool.submit(task);

// 6. Prefer high-level APIs
CompletableFuture.supplyAsync(...)
    .thenApply(...)
    .exceptionally(...);

// 7. Use AtomicXxx for simple counters
AtomicInteger count = new AtomicInteger(0);
count.incrementAndGet();

// 8. ThreadLocal: always remove()
try { threadLocal.set(value); doWork(); }
finally { threadLocal.remove(); }
```

### AVOID

```java
// 1. Don't synchronize everything
public synchronized void getX() { return x; }  // unnecessary if x is volatile

// 2. Don't create threads manually
new Thread(task).start();  // use executor instead

// 3. Don't hold locks too long
synchronized(this) {
    Thread.sleep(1000);   // TERRIBLE — holds lock while sleeping!
}

// 4. Don't call external code while holding lock
synchronized(this) {
    callback.onEvent(this);  // may try to acquire another lock → deadlock risk
}

// 5. Don't use double-checked locking without volatile (pre-Java 5)
// CORRECT in Java 5+:
private volatile Instance instance;
if (instance == null) {
    synchronized(this) {
        if (instance == null) instance = new Instance();
    }
}

// SIMPLER: use static initialiser or enum singleton
```

---

## 33. Practice Problems

### Beginner

1. **Print 1 to 100 alternating between two threads** — Thread-1 prints odds, Thread-2 prints evens in order
2. **Thread-safe counter** — implement with synchronized, AtomicInteger, and LongAdder
3. **Simple producer-consumer** — bounded buffer with 2 producers, 3 consumers

### Intermediate

4. **Blocking queue from scratch** — implement put() and take() with wait/notify
5. **Read-write cache** — cache with ReadWriteLock that expires entries
6. **Rate limiter** — token bucket with burst support
7. **Parallel word count** — count words in large file using ForkJoin or parallelStream
8. **Connection pool** — thread-safe pool of DB connections using Semaphore

### Advanced

9. **Custom thread pool** — implement ThreadPoolExecutor from scratch
10. **Concurrent LRU cache** — O(1) get/put, thread-safe, with stats
11. **Lock-free queue** — Michael-Scott algorithm with CAS
12. **Async pipeline** — chain of CompletableFutures with error handling and timeout
13. **Work-stealing scheduler** — divide tasks among workers, steal when idle
14. **Non-blocking rate limiter** — no locks, CAS-based

### See implementations in:
- `problems/ProducerConsumer.java`
- `problems/LRUCacheWithLock.java`
- `problems/CustomThreadPool.java`
- `problems/RateLimiter.java`
- `problems/LockFreeQueue.java`

---

## 34. Interview Questions & Answers

### Q1: What is the difference between process and thread?

**A:** A process is an independent execution unit with its own memory space (heap, stack, code, data). A thread is a lightweight unit of execution *within* a process that shares the process's heap and code but has its own stack and program counter. Creating threads is ~100x faster than creating processes, and inter-thread communication via shared memory is much faster than inter-process communication.

### Q2: What is a race condition? Give an example.

**A:** A race condition occurs when multiple threads access shared mutable data without synchronization, causing incorrect results depending on thread interleaving. Classic example: `count++` is three non-atomic operations (read, increment, write). If Thread-1 reads 0, Thread-2 reads 0, both compute 1, and both write 1 — the result is 1, not 2. Fix: `synchronized void increment()` or `AtomicInteger.incrementAndGet()`.

### Q3: How does `synchronized` work internally?

**A:** Every Java object has an intrinsic lock (monitor). `synchronized` acquires this monitor lock before entering the block and releases it on exit. The JVM uses `MONITORENTER`/`MONITOREXIT` bytecodes. Only one thread holds the monitor at a time; others block in the entry set. The same thread can acquire the lock multiple times (reentrancy). The monitor also has a wait set for threads that called `wait()`.

### Q4: What is the Java Memory Model (JMM)?

**A:** The JMM defines legal interactions between threads with respect to memory visibility and ordering. Without synchronization, threads may see stale values due to CPU caches, write buffers, and instruction reordering. The JMM provides a contract: if you use synchronization correctly (volatile, synchronized, happens-before), you get guaranteed visibility. Key rules: volatile write HB volatile read; unlock HB lock; Thread.start() HB thread execution; thread execution HB Thread.join().

### Q5: What is the difference between volatile and AtomicInteger?

**A:** `volatile` ensures visibility (reads always see latest writes) and prevents instruction reordering, but does NOT provide atomicity for compound operations like `count++`. `AtomicInteger` provides both visibility AND atomic compound operations via CAS. Use `volatile` for simple flags (single read/write); use `AtomicInteger` for counters and read-modify-write operations.

### Q6: Explain CAS and the ABA problem.

**A:** CAS (Compare-And-Swap) is a hardware instruction: atomically update a memory location from `expected` to `new` if current value equals `expected`, otherwise fail. Used by AtomicInteger, ConcurrentHashMap, etc. The ABA problem: Thread-1 reads A, pauses. Thread-2 changes A→B→A. Thread-1 resumes, CAS sees A, assumes no change, and proceeds — but state has actually changed. Fix: `AtomicStampedReference` adds a version counter.

### Q7: How does ConcurrentHashMap work?

**A:** Java 8: Array of Node entries, like HashMap. Empty bucket insert uses CAS (no lock). Non-empty bucket: synchronized on the bucket's head node (fine-grained — only one bucket locked at a time). Reads are always lock-free (volatile node references). The effective concurrency is proportional to the number of buckets, not a fixed segment count. Operations like `compute()` and `merge()` are fully atomic.

### Q8: What causes deadlock? How do you prevent it?

**A:** Deadlock requires four conditions: mutual exclusion, hold-and-wait, no preemption, and circular wait. Prevention strategies: (1) **Lock ordering** — always acquire locks in the same order across all threads; (2) **tryLock with timeout** — `lock.tryLock(100, MILLISECONDS)` returns instead of blocking forever; (3) **Lock-free design** — use atomic operations instead of locks; (4) **Deadlock detection** — thread dump analysis, JConsole.

### Q9: What is the difference between wait() and sleep()?

**A:** `Thread.sleep(ms)` pauses the thread for a duration **without releasing** any monitor locks. `Object.wait()` releases the monitor lock, puts the thread in the wait set, and waits until `notify()` or `notifyAll()` is called. Both throw `InterruptedException`. `sleep()` must be called on a Thread reference; `wait()` must be called inside a `synchronized` block on the object being waited on.

### Q10: When would you use CompletableFuture vs ExecutorService?

**A:** Use `ExecutorService` for simple task submission where you just need results or fire-and-forget. Use `CompletableFuture` when you need: async pipeline chaining (`.thenApply().thenApply()`), combining multiple async operations (`.thenCombine()`, `.allOf()`), non-blocking exception handling (`.exceptionally()`), or reactive-style programming. CompletableFuture is composable and avoids blocking `Future.get()` calls.

### Q11: What is ThreadLocal? What are its dangers?

**A:** `ThreadLocal` provides per-thread storage — each thread has its own independent copy of a variable, so no synchronization is needed. Common uses: request context (user ID, trace ID), per-thread SimpleDateFormat, Spring transaction context. Danger: **memory leaks** in thread pools. Thread pool threads are reused, so if you don't call `threadLocal.remove()`, the next request on the same thread sees leftover data. The ThreadLocalMap holds a strong reference to values even after the ThreadLocal key is GC'd.

### Q12: Explain the Executor Framework hierarchy.

**A:** `Executor` (interface) → `ExecutorService` (adds submit, shutdown) → `AbstractExecutorService` → `ThreadPoolExecutor` (core implementation with corePoolSize, maxPoolSize, queue, rejection policy). `ScheduledExecutorService` extends `ExecutorService` for delayed/periodic tasks. `ForkJoinPool` also implements `ExecutorService` but uses work-stealing. Factory methods in `Executors`: `newFixedThreadPool`, `newCachedThreadPool`, `newSingleThreadExecutor`, `newScheduledThreadPool`.

### Q13: What is ForkJoinPool and work-stealing?

**A:** `ForkJoinPool` is designed for divide-and-conquer tasks. Each worker thread has a **deque** (double-ended queue) of tasks. Threads process their own tasks from the front. When a thread's deque is empty, it **steals** tasks from the back of another thread's deque. This minimises contention (owner pushes/pops from front, thieves steal from back). Used by `parallelStream()` and `Arrays.parallelSort()`. Use `RecursiveTask<T>` for tasks with return values and `RecursiveAction` for void tasks.

### Q14: How do you avoid memory leaks with concurrent code?

**A:** (1) Always call `threadLocal.remove()` in a finally block, especially in thread pools. (2) Use `WeakHashMap` or `WeakReference` for caches where GC should reclaim entries. (3) Cancel futures and shut down executor services to avoid threads running indefinitely. (4) Don't store large objects in thread-local storage. (5) Use `ConcurrentHashMap` instead of `HashMap` with `Collections.synchronizedMap()` — the latter holds a reference to the map even when the map is not referenced elsewhere.

---

## 35. Final Summary & Cheat Sheet

> **See diagram:** `diagrams/15_cheat_sheet.png`

### Decision Tree

```
Need thread safety?
│
├── Single value, simple read/write?
│   ├── One writer, many readers → volatile
│   └── Multiple writers → AtomicInteger/AtomicLong
│
├── Complex critical section (multiple operations)?
│   ├── Simple case → synchronized
│   └── Need tryLock/fair/interruptible → ReentrantLock
│
├── Read-heavy (reads >> writes)?
│   └── ReadWriteLock or StampedLock
│
├── Map/Collection?
│   ├── Key-value map → ConcurrentHashMap
│   ├── List, rare writes → CopyOnWriteArrayList
│   └── Queue/deque → ArrayBlockingQueue, ConcurrentLinkedQueue
│
├── Async/non-blocking?
│   ├── Simple task → ExecutorService + Future
│   ├── Pipeline/chaining → CompletableFuture
│   └── Divide & conquer → ForkJoinPool
│
└── Coordination?
    ├── Limit concurrent access → Semaphore
    ├── Wait for N tasks → CountDownLatch
    ├── Cyclic synchronization → CyclicBarrier
    └── Per-request context → ThreadLocal (+remove()!)
```

### API Quick Reference

```java
// THREAD CREATION
new Thread(runnable).start();
ExecutorService pool = Executors.newFixedThreadPool(4);
pool.submit(runnable);
pool.submit(callable);  // returns Future<T>

// SYNCHRONIZATION
synchronized(obj) { ... }                       // monitor lock
lock.lock(); try{ } finally{ lock.unlock(); }   // ReentrantLock

// ATOMIC
AtomicInteger n = new AtomicInteger(0);
n.incrementAndGet();
n.compareAndSet(expected, newValue);
n.updateAndGet(x -> x * 2);

// VOLATILE
volatile boolean flag = false;  // visibility, no atomicity

// COMPLETABLEFUTURE
CompletableFuture.supplyAsync(() -> compute())
    .thenApply(result -> transform(result))
    .thenCombine(other, (a, b) -> merge(a, b))
    .exceptionally(ex -> fallback())
    .get();

// BLOCKING QUEUE
BlockingQueue<T> q = new ArrayBlockingQueue<>(100);
q.put(item);    // blocks when full
q.take();       // blocks when empty

// SYNCHRONIZERS
new Semaphore(3).acquire();         // limit concurrent access to 3
new CountDownLatch(n).await();      // wait for n countdowns
new CyclicBarrier(n).await();       // all wait until all arrive

// CONCURRENT COLLECTIONS
ConcurrentHashMap<K,V> map = new ConcurrentHashMap<>();
map.compute(key, (k,v) -> v == null ? 1 : v+1);  // atomic
map.computeIfAbsent(key, k -> new ArrayList<>());  // lazy init

// FORKJOIN
ForkJoinPool.commonPool().invoke(new MyRecursiveTask(data));
list.parallelStream().mapToLong(Long::parseLong).sum();
```

### Performance Hierarchy (fastest to slowest)

```
1. Immutable objects            — no synchronization needed!
2. ThreadLocal                  — no sharing, no synchronization
3. Lock-free (CAS, Atomic)      — no blocking, spin retry
4. volatile                     — visibility only, no mutex
5. synchronized (uncontended)   — JVM optimises to thin lock
6. synchronized (contended)     — OS mutex, expensive
7. ReentrantLock (fair)         — most overhead, most features
```

---

## Project Structure

```
concurrency-mastery/
├── pom.xml                           Maven build
├── run-all.sh                        Run all demos
├── diagrams/                         15 PNG flow diagrams
│   ├── 01_thread_lifecycle.png
│   ├── 02_race_condition.png
│   ├── 03_deadlock.png
│   ├── 04_volatile_jmm.png
│   ├── 05_cas_atomic.png
│   ├── 06_locks_comparison.png
│   ├── 07_producer_consumer.png
│   ├── 08_thread_pool_executor.png
│   ├── 09_completable_future.png
│   ├── 10_concurrent_collections.png
│   ├── 11_synchronizers.png
│   ├── 12_jmm_happens_before.png
│   ├── 13_forkjoinpool.png
│   ├── 14_thread_local.png
│   └── 15_cheat_sheet.png
└── src/main/java/com/concurrency/
    ├── basics/
    │   ├── ThreadCreation.java       4 ways to create threads
    │   ├── ThreadLifecycle.java      All 6 states demonstrated
    │   └── RaceConditionDemo.java    10 threads × 10K increments
    ├── synchronization/
    │   ├── SynchronizationDemo.java  Method, block, static, wait/notify
    │   ├── DeadlockDemo.java         Deadlock + 2 prevention strategies
    │   └── AtomicAndVolatileDemo.java  CAS, AtomicInteger, LongAdder
    ├── locks/
    │   ├── ReentrantLockDemo.java    tryLock, conditions, reentrancy
    │   └── ReadWriteLockDemo.java    RWLock + StampedLock optimistic
    ├── executors/
    │   └── ExecutorDemo.java         All pool types, invokeAll/Any, scheduled
    ├── async/
    │   ├── CompletableFutureDemo.java  Pipeline, combine, error handling
    │   └── ForkJoinDemo.java          RecursiveTask, RecursiveAction
    ├── collections/
    │   └── ConcurrentCollectionsDemo.java  CHM, COWAL, BQ, CLQ
    ├── advanced/
    │   └── AdvancedSynchronizersDemo.java  Semaphore, Latch, Barrier, TL
    └── problems/
        ├── ProducerConsumer.java     wait/notify + BlockingQueue
        ├── LRUCacheWithLock.java     synchronized + ReadWriteLock
        ├── CustomThreadPool.java     From-scratch thread pool
        ├── RateLimiter.java          Token bucket + sliding window
        └── LockFreeQueue.java        Michael-Scott CAS queue
```

---

*Built from the "Concurrency in Depth" tutorial. Run `mvn compile exec:java -Dexec.mainClass="com.concurrency.basics.ThreadCreation"` to get started.*
