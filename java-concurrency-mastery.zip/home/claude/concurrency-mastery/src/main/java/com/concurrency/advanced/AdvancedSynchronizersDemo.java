package com.concurrency.advanced;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/**
 * TOPIC: Advanced synchronizers
 *
 * Semaphore    — count-based permits (parking lot, connection pool)
 * CountDownLatch — one-time countdown (startup barrier, test coordination)
 * CyclicBarrier — reusable barrier (phased simulation, parallel processing)
 * Phaser       — flexible multi-phase coordination (replaces both above)
 * Exchanger    — two-thread data exchange point
 */
public class AdvancedSynchronizersDemo {

    // ── Semaphore — connection pool ───────────────────────────────────────
    static void semaphoreDemo() throws InterruptedException {
        System.out.println("--- Semaphore (connection pool) ---");
        Semaphore permits = new Semaphore(3, true); // 3 permits, fair ordering

        ExecutorService pool = Executors.newFixedThreadPool(8);
        CountDownLatch latch = new CountDownLatch(8);

        for (int i = 1; i <= 8; i++) {
            final int id = i;
            pool.submit(() -> {
                try {
                    System.out.printf("[T%d] Waiting for connection (available: %d)%n",
                        id, permits.availablePermits());
                    permits.acquire(); // block until permit available
                    try {
                        System.out.printf("[T%d] Got connection! (available: %d)%n",
                            id, permits.availablePermits());
                        Thread.sleep(200); // simulate DB work
                    } finally {
                        permits.release();
                        System.out.printf("[T%d] Released connection%n", id);
                    }
                } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                finally { latch.countDown(); }
            });
        }
        latch.await(); pool.shutdown();
        System.out.println("Max concurrent connections seen: 3 (enforced by Semaphore)");
    }

    // ── CountDownLatch — startup coordination ─────────────────────────────
    static void countDownLatchDemo() throws InterruptedException {
        System.out.println("\n--- CountDownLatch (startup barrier) ---");
        int SERVICE_COUNT = 3;
        CountDownLatch startupLatch = new CountDownLatch(SERVICE_COUNT);
        CountDownLatch shutdownLatch = new CountDownLatch(SERVICE_COUNT);

        String[] services = {"Database", "Kafka", "RedisCache"};
        ExecutorService pool = Executors.newFixedThreadPool(SERVICE_COUNT);

        for (int i = 0; i < SERVICE_COUNT; i++) {
            final String name = services[i];
            final int delay  = (i + 1) * 200;
            pool.submit(() -> {
                try {
                    System.out.println("[" + name + "] Starting...");
                    Thread.sleep(delay); // simulate startup time
                    System.out.println("[" + name + "] Ready!");
                    startupLatch.countDown(); // signal: I'm ready

                    // Simulate service work
                    Thread.sleep(500);
                    System.out.println("[" + name + "] Shutting down");
                } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                finally { shutdownLatch.countDown(); }
            });
        }

        System.out.println("[Main] Waiting for all services to be ready...");
        startupLatch.await(); // wait until count reaches 0
        System.out.println("[Main] ALL services ready! Starting application...");

        shutdownLatch.await();
        pool.shutdown();
        System.out.println("[Main] Application shutdown complete");
    }

    // ── CyclicBarrier — parallel processing phases ────────────────────────
    static void cyclicBarrierDemo() throws Exception {
        System.out.println("\n--- CyclicBarrier (reusable phases) ---");
        int WORKERS = 3;
        int[][] matrix = {{1,2,3},{4,5,6},{7,8,9}};
        int[][] result = new int[3][3];

        // Barrier action runs when all threads reach the barrier
        CyclicBarrier barrier = new CyclicBarrier(WORKERS, () -> {
            System.out.println("[Barrier] All workers completed phase — advancing!");
        });

        ExecutorService pool = Executors.newFixedThreadPool(WORKERS);
        CountDownLatch done = new CountDownLatch(WORKERS);

        for (int w = 0; w < WORKERS; w++) {
            final int worker = w;
            pool.submit(() -> {
                try {
                    // Phase 1: compute row sums
                    int rowSum = 0;
                    for (int j = 0; j < 3; j++) rowSum += matrix[worker][j];
                    System.out.printf("[W%d] Phase 1: row sum = %d%n", worker, rowSum);
                    result[worker][0] = rowSum;
                    barrier.await(); // wait for all workers at phase 1

                    // Phase 2: compute squared sums
                    result[worker][1] = rowSum * rowSum;
                    System.out.printf("[W%d] Phase 2: squared = %d%n", worker, rowSum*rowSum);
                    barrier.await(); // wait for all at phase 2 (barrier RESETS!)

                    // Phase 3: print final
                    System.out.printf("[W%d] Phase 3: row=%d, rowSq=%d%n",
                        worker, result[worker][0], result[worker][1]);

                } catch (Exception e) { Thread.currentThread().interrupt(); }
                finally { done.countDown(); }
            });
        }

        done.await(); pool.shutdown();
    }

    // ── ThreadLocal ────────────────────────────────────────────────────────
    static void threadLocalDemo() throws InterruptedException {
        System.out.println("\n--- ThreadLocal (per-thread context) ---");

        // Each thread gets its own copy, initialised to 0
        ThreadLocal<Integer> userId = ThreadLocal.withInitial(() -> 0);
        ThreadLocal<List<String>> auditLog = ThreadLocal.withInitial(ArrayList::new);

        ExecutorService pool = Executors.newFixedThreadPool(3);
        CountDownLatch latch = new CountDownLatch(3);

        for (int i = 1; i <= 3; i++) {
            final int id = i * 100;
            pool.submit(() -> {
                try {
                    userId.set(id);   // each thread has its OWN copy
                    auditLog.get().add("Login:" + id);
                    auditLog.get().add("Action:" + id);

                    Thread.sleep(100);

                    System.out.printf("[%s] userId=%d, log=%s%n",
                        Thread.currentThread().getName(),
                        userId.get(), auditLog.get());
                } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                finally {
                    userId.remove();   // ALWAYS remove in thread pools!
                    auditLog.remove(); // prevents memory leaks
                    latch.countDown();
                }
            });
        }
        latch.await(); pool.shutdown();
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== Advanced Synchronizers Demo ===\n");
        semaphoreDemo();
        countDownLatchDemo();
        cyclicBarrierDemo();
        threadLocalDemo();
        System.out.println("\nDone!");
    }
}