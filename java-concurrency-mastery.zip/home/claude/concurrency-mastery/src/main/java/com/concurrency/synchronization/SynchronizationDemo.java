package com.concurrency.synchronization;

import java.util.concurrent.*;

/**
 * TOPIC: Synchronization — synchronized method, block, static
 *
 * Monitor lock:
 *   - synchronized(this)         → instance lock
 *   - synchronized(ClassName.class) → class-level lock
 *   - synchronized method        → same as synchronized(this)
 *
 * Only ONE thread holds the lock at a time.
 * Other threads BLOCK until the lock is released.
 */
public class SynchronizationDemo {

    // ── Example 1: Synchronized method ────────────────────────────────────
    static class BankAccount {
        private double balance;
        private final String accountId;

        BankAccount(String id, double initialBalance) {
            this.accountId = id;
            this.balance   = initialBalance;
        }

        // Entire method locked on 'this'
        public synchronized void deposit(double amount) {
            if (amount <= 0) throw new IllegalArgumentException("Amount must be positive");
            double old = balance;
            // Simulate multi-step operation
            balance += amount;
            System.out.printf("[%s] Deposit: %.0f → %.0f (by %s)%n",
                accountId, old, balance, Thread.currentThread().getName());
        }

        public synchronized boolean withdraw(double amount) {
            if (amount <= 0) throw new IllegalArgumentException("Amount must be positive");
            if (balance < amount) {
                System.out.printf("[%s] Withdraw FAILED (insufficient): %.0f < %.0f%n",
                    accountId, balance, amount);
                return false;
            }
            double old = balance;
            balance -= amount;
            System.out.printf("[%s] Withdraw: %.0f → %.0f (by %s)%n",
                accountId, old, balance, Thread.currentThread().getName());
            return true;
        }

        public synchronized double getBalance() { return balance; }
    }

    // ── Example 2: Synchronized block (finer control) ─────────────────────
    static class InventoryManager {
        private int stock;
        private int reservations;
        private final Object stockLock = new Object();
        private final Object reserveLock = new Object();

        InventoryManager(int initial) { this.stock = initial; }

        void reserveItem() {
            // Only lock what's needed
            synchronized (reserveLock) {
                reservations++;
                System.out.printf("[%s] Reserved. Total reservations: %d%n",
                    Thread.currentThread().getName(), reservations);
            }
        }

        boolean sellItem() {
            synchronized (stockLock) {   // different lock from reserveLock
                if (stock <= 0) return false;
                stock--;
                System.out.printf("[%s] Sold. Stock remaining: %d%n",
                    Thread.currentThread().getName(), stock);
                return true;
            }
        }
    }

    // ── Example 3: Static synchronized — class-level lock ─────────────────
    static class IdGenerator {
        private static long nextId = 1000;

        // Locks on IdGenerator.class — shared across ALL instances
        public static synchronized long generateId() {
            return nextId++;
        }
    }

    // ── Example 4: wait() and notify() ────────────────────────────────────
    static class SignalDemo {
        private boolean dataReady = false;
        private String data;

        synchronized void produce(String value) throws InterruptedException {
            while (dataReady) wait(); // wait if not consumed yet
            data = value;
            dataReady = true;
            System.out.println("[Producer] Produced: " + value);
            notifyAll();
        }

        synchronized String consume() throws InterruptedException {
            while (!dataReady) wait(); // wait until data ready
            dataReady = false;
            System.out.println("[Consumer] Consumed: " + data);
            notifyAll();
            return data;
        }
    }

    public static void main(String[] args) throws InterruptedException {
        System.out.println("=== Synchronization Demo ===\n");

        // Test BankAccount
        System.out.println("--- Bank Account (synchronized methods) ---");
        BankAccount account = new BankAccount("ACC-001", 1000);
        ExecutorService pool = Executors.newFixedThreadPool(4);
        CountDownLatch latch = new CountDownLatch(6);

        for (int i = 0; i < 3; i++) {
            pool.submit(() -> {
                try { account.deposit(100); }
                finally { latch.countDown(); }
            });
            pool.submit(() -> {
                try { account.withdraw(50); }
                finally { latch.countDown(); }
            });
        }
        latch.await();
        System.out.printf("Final balance: %.0f (expected: 1150)%n", account.getBalance());

        // Test IdGenerator
        System.out.println("\n--- ID Generator (static synchronized) ---");
        CountDownLatch idLatch = new CountDownLatch(5);
        for (int i = 0; i < 5; i++) {
            pool.submit(() -> {
                System.out.println("Generated ID: " + IdGenerator.generateId());
                idLatch.countDown();
            });
        }
        idLatch.await();

        // Test wait/notify
        System.out.println("\n--- wait() and notify() ---");
        SignalDemo signal = new SignalDemo();
        Thread producer = new Thread(() -> {
            try {
                for (String msg : new String[]{"Hello", "World", "Done"})
                    signal.produce(msg);
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }, "Producer");
        Thread consumer = new Thread(() -> {
            try {
                for (int i = 0; i < 3; i++) signal.consume();
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }, "Consumer");
        producer.start(); consumer.start();
        producer.join(); consumer.join();

        pool.shutdown();
        System.out.println("\nDone!");
    }
}