package com.concurrency.problems;

import java.util.concurrent.atomic.*;
import java.util.concurrent.*;

/**
 * PROBLEM: Lock-Free Queue using CAS
 *
 * Michael-Scott Non-Blocking Queue algorithm.
 *
 * Key idea:
 *  - Head: dequeue from here (dummy sentinel node)
 *  - Tail: enqueue here
 *  - CAS: atomically update head/tail without locks
 *
 * ABA Problem:
 *  - A thread reads head=A, pauses
 *  - Another: A→B→A (value back to A)
 *  - First resumes: sees head=A, CAS succeeds incorrectly
 *  Fix: AtomicStampedReference (version counter)
 */
public class LockFreeQueue<T> {

    private static class Node<T> {
        final T value;
        final AtomicReference<Node<T>> next;

        Node(T value) {
            this.value = value;
            this.next  = new AtomicReference<>(null);
        }
    }

    private final AtomicReference<Node<T>> head;
    private final AtomicReference<Node<T>> tail;
    private final AtomicInteger size = new AtomicInteger(0);

    public LockFreeQueue() {
        Node<T> sentinel = new Node<>(null); // dummy head
        head = new AtomicReference<>(sentinel);
        tail = new AtomicReference<>(sentinel);
    }

    // ── Enqueue — O(1) ────────────────────────────────────────────────────
    public void enqueue(T value) {
        Node<T> newNode = new Node<>(value);
        while (true) {
            Node<T> currentTail = tail.get();
            Node<T> tailNext    = currentTail.next.get();

            // Consistent snapshot check
            if (currentTail == tail.get()) {
                if (tailNext == null) {
                    // Tail is pointing to last node — try to link new node
                    if (currentTail.next.compareAndSet(null, newNode)) {
                        // Success — advance tail (may fail, that's OK — next enqueue fixes it)
                        tail.compareAndSet(currentTail, newNode);
                        size.incrementAndGet();
                        return;
                    }
                } else {
                    // Tail not pointing to last — advance it
                    tail.compareAndSet(currentTail, tailNext);
                }
            }
        }
    }

    // ── Dequeue — O(1) ────────────────────────────────────────────────────
    public T dequeue() {
        while (true) {
            Node<T> currentHead = head.get();
            Node<T> currentTail = tail.get();
            Node<T> headNext    = currentHead.next.get();

            if (currentHead == head.get()) { // consistent snapshot
                if (currentHead == currentTail) {
                    // Queue appears empty
                    if (headNext == null) return null; // truly empty
                    // Tail is lagging — advance it
                    tail.compareAndSet(currentTail, headNext);
                } else {
                    // Read value BEFORE CAS (another thread may dequeue)
                    T value = headNext.value;
                    // Advance head (headNext becomes new dummy)
                    if (head.compareAndSet(currentHead, headNext)) {
                        size.decrementAndGet();
                        return value;
                    }
                }
            }
        }
    }

    public boolean isEmpty() { return size.get() == 0; }
    public int     size()    { return size.get(); }

    // ── Test ──────────────────────────────────────────────────────────────
    public static void main(String[] args) throws InterruptedException {
        System.out.println("=== Lock-Free Queue Demo ===\n");

        LockFreeQueue<Integer> queue = new LockFreeQueue<>();
        int PRODUCERS = 4, CONSUMERS = 4, ITEMS_EACH = 1000;

        CountDownLatch prodLatch = new CountDownLatch(PRODUCERS);
        CountDownLatch consLatch = new CountDownLatch(CONSUMERS);
        AtomicInteger  produced  = new AtomicInteger(0);
        AtomicInteger  consumed  = new AtomicInteger(0);

        ExecutorService pool = Executors.newFixedThreadPool(PRODUCERS + CONSUMERS);

        // Producers
        for (int p = 0; p < PRODUCERS; p++) {
            final int base = p * ITEMS_EACH;
            pool.submit(() -> {
                for (int i = base; i < base + ITEMS_EACH; i++) {
                    queue.enqueue(i);
                    produced.incrementAndGet();
                }
                prodLatch.countDown();
            });
        }

        // Consumers
        AtomicBoolean producingDone = new AtomicBoolean(false);
        for (int c = 0; c < CONSUMERS; c++) {
            pool.submit(() -> {
                while (!producingDone.get() || !queue.isEmpty()) {
                    Integer val = queue.dequeue();
                    if (val != null) consumed.incrementAndGet();
                }
                consLatch.countDown();
            });
        }

        prodLatch.await();
        producingDone.set(true);
        consLatch.await();
        pool.shutdown();

        System.out.printf("Produced: %d, Consumed: %d, Queue empty: %b%n",
            produced.get(), consumed.get(), queue.isEmpty());
        System.out.println("Data integrity: " + (produced.get() == consumed.get() ?
            "PASS ✓" : "FAIL ✗"));
    }
}