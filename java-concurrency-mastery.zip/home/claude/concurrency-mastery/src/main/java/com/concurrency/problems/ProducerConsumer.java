package com.concurrency.problems;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/**
 * PROBLEM: Producer-Consumer
 *
 * Classic concurrency problem: producers generate data, consumers process it.
 *
 * Implementations shown:
 *   1. wait()/notify()      — classic Java, verbose
 *   2. BlockingQueue        — modern, preferred
 *   3. CompletableFuture    — reactive style
 */
public class ProducerConsumer {

    // ── Implementation 1: wait() / notify() ──────────────────────────────
    static class SharedQueue {
        private final Queue<Integer> queue = new LinkedList<>();
        private final int capacity;

        SharedQueue(int capacity) { this.capacity = capacity; }

        synchronized void produce(int value) throws InterruptedException {
            while (queue.size() == capacity) {
                System.out.println("[Producer] Queue full, waiting...");
                wait();
            }
            queue.add(value);
            System.out.printf("[Producer] Produced: %d (size=%d)%n", value, queue.size());
            notifyAll();
        }

        synchronized int consume() throws InterruptedException {
            while (queue.isEmpty()) {
                System.out.println("[Consumer] Queue empty, waiting...");
                wait();
            }
            int val = queue.remove();
            System.out.printf("[Consumer] Consumed: %d (size=%d)%n", val, queue.size());
            notifyAll();
            return val;
        }
    }

    // ── Implementation 2: BlockingQueue (preferred) ────────────────────────
    static class OrderProcessor {
        private final BlockingQueue<String> orders;
        private final AtomicBoolean running = new AtomicBoolean(true);
        private final AtomicInteger processed = new AtomicInteger(0);

        OrderProcessor(int capacity) {
            this.orders = new ArrayBlockingQueue<>(capacity);
        }

        void submitOrder(String order) throws InterruptedException {
            orders.put(order); // blocks if queue full
        }

        void startConsumers(int count) {
            ExecutorService pool = Executors.newFixedThreadPool(count);
            for (int i = 0; i < count; i++) {
                final int id = i + 1;
                pool.submit(() -> {
                    while (running.get() || !orders.isEmpty()) {
                        try {
                            String order = orders.poll(100, TimeUnit.MILLISECONDS);
                            if (order != null) {
                                processOrder(id, order);
                                processed.incrementAndGet();
                            }
                        } catch (InterruptedException e) {
                            Thread.currentThread().interrupt();
                            return;
                        }
                    }
                });
            }
            pool.shutdown();
        }

        void stop() { running.set(false); }
        int getProcessed() { return processed.get(); }

        private void processOrder(int consumerId, String order) {
            System.out.printf("[Consumer-%d] Processing: %s%n", consumerId, order);
        }
    }

    public static void main(String[] args) throws InterruptedException {
        System.out.println("=== Producer-Consumer Patterns ===\n");

        // Pattern 1: wait/notify
        System.out.println("--- Pattern 1: wait()/notify() ---");
        SharedQueue shared = new SharedQueue(3);
        Thread producer1 = new Thread(() -> {
            try {
                for (int i = 1; i <= 5; i++) shared.produce(i);
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }, "Producer");
        Thread consumer1 = new Thread(() -> {
            try {
                for (int i = 0; i < 5; i++) { Thread.sleep(80); shared.consume(); }
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }, "Consumer");
        producer1.start(); consumer1.start();
        producer1.join(); consumer1.join();

        // Pattern 2: BlockingQueue
        System.out.println("\n--- Pattern 2: BlockingQueue ---");
        OrderProcessor processor = new OrderProcessor(10);
        processor.startConsumers(3);

        for (int i = 1; i <= 9; i++) {
            processor.submitOrder("ORDER-" + i);
        }
        Thread.sleep(500);
        processor.stop();
        Thread.sleep(200);
        System.out.println("Total processed: " + processor.getProcessed());
    }
}