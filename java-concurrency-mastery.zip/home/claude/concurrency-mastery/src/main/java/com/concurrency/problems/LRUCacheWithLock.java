package com.concurrency.problems;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;

/**
 * PROBLEM: Concurrent LRU Cache
 *
 * Approach 1: Synchronized + LinkedHashMap (simple)
 * Approach 2: ReadWriteLock + LinkedHashMap (better read performance)
 * Approach 3: ConcurrentHashMap + Doubly-Linked List (maximum performance)
 *
 * LRU = Least Recently Used:
 *   - Get:  mark as recently used (move to head)
 *   - Put:  add to head; evict tail if over capacity
 */
public class LRUCacheWithLock {

    // ── Approach 1: Simple synchronized LRU ──────────────────────────────
    static class SimpleLRUCache<K, V> {
        private final int capacity;
        private final LinkedHashMap<K, V> map;

        SimpleLRUCache(int capacity) {
            this.capacity = capacity;
            this.map = new LinkedHashMap<>(capacity, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(Map.Entry<K, V> eldest) {
                    return size() > capacity; // auto-evict LRU
                }
            };
        }

        synchronized V get(K key) { return map.get(key); }

        synchronized void put(K key, V value) { map.put(key, value); }

        synchronized int size() { return map.size(); }

        @Override
        public synchronized String toString() { return map.toString(); }
    }

    // ── Approach 2: ReadWriteLock LRU ─────────────────────────────────────
    static class RWLRUCache<K, V> {
        private final int capacity;
        private final LinkedHashMap<K, V> map;
        private final ReentrantReadWriteLock rwLock = new ReentrantReadWriteLock();
        private final Lock rLock = rwLock.readLock();
        private final Lock wLock = rwLock.writeLock();
        private int hits, misses;

        RWLRUCache(int capacity) {
            this.capacity = capacity;
            this.map = new LinkedHashMap<>(capacity, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(Map.Entry<K, V> eldest) {
                    return size() > capacity;
                }
            };
        }

        V get(K key) {
            wLock.lock(); // need write lock because get() modifies access order
            try {
                V val = map.get(key);
                if (val != null) hits++; else misses++;
                return val;
            } finally { wLock.unlock(); }
        }

        void put(K key, V value) {
            wLock.lock();
            try { map.put(key, value); }
            finally { wLock.unlock(); }
        }

        void printStats() {
            System.out.printf("Cache stats — hits: %d, misses: %d, ratio: %.0f%%%n",
                hits, misses, 100.0 * hits / (hits + misses));
        }
    }

    public static void main(String[] args) throws InterruptedException {
        System.out.println("=== Concurrent LRU Cache Demo ===\n");

        // Simple LRU test
        System.out.println("--- SimpleLRUCache (capacity=3) ---");
        SimpleLRUCache<Integer, String> cache = new SimpleLRUCache<>(3);
        cache.put(1, "one"); cache.put(2, "two"); cache.put(3, "three");
        System.out.println("After 1,2,3: " + cache);
        cache.get(1);        // access 1 → becomes MRU
        cache.put(4, "four"); // evicts LRU (2)
        System.out.println("After get(1), put(4): " + cache);
        System.out.println("Contains 2: " + (cache.get(2) != null)); // evicted

        // Concurrent test
        System.out.println("\n--- Concurrent LRU (read/write competition) ---");
        RWLRUCache<Integer, String> rwCache = new RWLRUCache<>(100);

        // Pre-populate
        for (int i = 0; i < 50; i++) rwCache.put(i, "value-" + i);

        ExecutorService pool = Executors.newFixedThreadPool(8);
        CountDownLatch latch = new CountDownLatch(8);
        Random rng = new Random(42);

        // 6 readers, 2 writers
        for (int i = 0; i < 6; i++) {
            pool.submit(() -> {
                try {
                    for (int j = 0; j < 1000; j++)
                        rwCache.get(rng.nextInt(60)); // some misses (50-60)
                } finally { latch.countDown(); }
            });
        }
        for (int i = 0; i < 2; i++) {
            pool.submit(() -> {
                try {
                    for (int j = 0; j < 200; j++)
                        rwCache.put(rng.nextInt(120), "v-" + j);
                } finally { latch.countDown(); }
            });
        }

        latch.await();
        rwCache.printStats();
        pool.shutdown();
    }
}