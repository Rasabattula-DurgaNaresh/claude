package com.concurrency.executors;

import java.util.*;
import java.util.concurrent.*;

/**
 * TOPIC: ExecutorService, Callable, Future — the Executor Framework
 *
 * Key interfaces:
 *   Executor         — execute(Runnable)
 *   ExecutorService  — submit(), invokeAll(), invokeAny(), shutdown()
 *   ScheduledExecutorService — schedule(), scheduleAtFixedRate()
 *
 * Thread pool types:
 *   Fixed   — predictable concurrency, CPU-bound
 *   Cached  — auto-scaling, I/O-bound, short-lived
 *   Single  — sequential, ordered execution
 *   Scheduled — periodic / delayed tasks
 */
public class ExecutorDemo {

    static int computeFibonacci(int n) {
        if (n <= 1) return n;
        return computeFibonacci(n-1) + computeFibonacci(n-2);
    }

    // ── Callable + Future ──────────────────────────────────────────────────
    static void callableAndFuture() throws Exception {
        System.out.println("--- Callable and Future ---");
        ExecutorService pool = Executors.newFixedThreadPool(4);

        // Submit Callable — returns Future
        Future<Integer> fib35 = pool.submit(() -> computeFibonacci(35));
        Future<Integer> fib36 = pool.submit(() -> computeFibonacci(36));

        System.out.println("Tasks submitted, doing other work...");

        // future.get() blocks until result ready
        System.out.println("Fib(35) = " + fib35.get());
        System.out.println("Fib(36) = " + fib36.get());

        // isDone / cancel
        Future<Integer> slow = pool.submit(() -> {
            Thread.sleep(5000);
            return 42;
        });
        Thread.sleep(100);
        System.out.println("Is done: " + slow.isDone()); // false
        slow.cancel(true); // cancel with interrupt
        System.out.println("Cancelled: " + slow.isCancelled()); // true

        pool.shutdown();
    }

    // ── invokeAll — run all, wait for all ─────────────────────────────────
    static void invokeAllDemo() throws Exception {
        System.out.println("\n--- invokeAll (parallel batch) ---");
        ExecutorService pool = Executors.newFixedThreadPool(4);

        List<Callable<String>> tasks = List.of(
            () -> { Thread.sleep(200); return "Task-A"; },
            () -> { Thread.sleep(100); return "Task-B"; },
            () -> { Thread.sleep(300); return "Task-C"; },
            () -> { Thread.sleep( 50); return "Task-D"; }
        );

        long start = System.currentTimeMillis();
        List<Future<String>> futures = pool.invokeAll(tasks);
        long elapsed = System.currentTimeMillis() - start;

        System.out.printf("All %d tasks completed in %dms (longest was 300ms)%n",
            futures.size(), elapsed);

        for (Future<String> f : futures) {
            System.out.println("Result: " + f.get());
        }
        pool.shutdown();
    }

    // ── invokeAny — return first to complete ──────────────────────────────
    static void invokeAnyDemo() throws Exception {
        System.out.println("\n--- invokeAny (first wins) ---");
        ExecutorService pool = Executors.newFixedThreadPool(3);

        List<Callable<String>> tasks = List.of(
            () -> { Thread.sleep(300); return "Slow server"; },
            () -> { Thread.sleep(100); return "Fast server"; },  // wins!
            () -> { Thread.sleep(200); return "Medium server"; }
        );

        long start = System.currentTimeMillis();
        String winner = pool.invokeAny(tasks);
        long elapsed = System.currentTimeMillis() - start;

        System.out.printf("Winner: '%s' in %dms%n", winner, elapsed);
        pool.shutdown();
    }

    // ── ScheduledExecutorService ───────────────────────────────────────────
    static void scheduledDemo() throws InterruptedException {
        System.out.println("\n--- ScheduledExecutorService ---");
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(2);

        // One-time delay
        scheduler.schedule(
            () -> System.out.println("Delayed task (500ms)"),
            500, TimeUnit.MILLISECONDS
        );

        // Periodic — fixed rate (from start of previous execution)
        int[] count = {0};
        ScheduledFuture<?> periodic = scheduler.scheduleAtFixedRate(
            () -> System.out.println("Periodic #" + ++count[0]),
            0, 200, TimeUnit.MILLISECONDS
        );

        Thread.sleep(700);
        periodic.cancel(false);
        scheduler.shutdown();
        scheduler.awaitTermination(1, TimeUnit.SECONDS);
    }

    // ── Graceful shutdown ──────────────────────────────────────────────────
    static void shutdownDemo() throws InterruptedException {
        System.out.println("\n--- Graceful Shutdown ---");
        ExecutorService pool = Executors.newFixedThreadPool(2);

        // Submit long-running tasks
        for (int i = 0; i < 4; i++) {
            final int id = i;
            pool.submit(() -> {
                try {
                    System.out.println("Task " + id + " started");
                    Thread.sleep(200);
                    System.out.println("Task " + id + " done");
                } catch (InterruptedException e) {
                    System.out.println("Task " + id + " interrupted");
                    Thread.currentThread().interrupt();
                }
            });
        }

        pool.shutdown(); // no new tasks accepted, existing tasks finish
        System.out.println("Shutdown initiated...");

        boolean completed = pool.awaitTermination(2, TimeUnit.SECONDS);
        System.out.println("All tasks completed: " + completed);

        if (!completed) {
            List<Runnable> pending = pool.shutdownNow(); // interrupt running tasks
            System.out.println("Forced shutdown. Pending tasks: " + pending.size());
        }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== Executor Framework Demo ===\n");
        callableAndFuture();
        invokeAllDemo();
        invokeAnyDemo();
        scheduledDemo();
        shutdownDemo();
    }
}