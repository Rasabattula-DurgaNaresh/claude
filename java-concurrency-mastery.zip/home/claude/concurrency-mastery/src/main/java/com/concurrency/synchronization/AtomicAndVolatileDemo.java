package com.concurrency.synchronization;

import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/**
 * TOPIC: volatile, AtomicXxx, and CAS (Compare-And-Swap)
 *
 * volatile:
 *   - Guarantees VISIBILITY (no stale cache)
 *   - Does NOT prevent race conditions on compound operations
 *   - Prevents instruction reordering
 *
 * AtomicInteger/Long/Boolean/Reference:
 *   - Lock-free using CAS hardware instruction
 *   - Safe for compound operations (incrementAndGet, compareAndSet)
 *   - Much faster than synchronized
 *
 * CAS:
 *   - if (current == expected) { current = newValue; return true; }
 *   - else { return false; } // retry
 */
public class AtomicAndVolatileDemo {

    // ── volatile — visibility only ─────────────────────────────────────────
    static volatile boolean stopFlag = false;

    static void demonstrateVolatile() throws InterruptedException {
        System.out.println("--- volatile flag demo ---");
        Thread worker = new Thread(() -> {
            int iterations = 0;
            while (!stopFlag) {  // reads from main memory every time
                iterations++;
            }
            System.out.println("Worker stopped after " + iterations + " iterations");
        }, "Worker");
        worker.start();
        Thread.sleep(10);
        stopFlag = true;  // write visible to all threads immediately
        worker.join(1000);
        stopFlag = false; // reset for next demo
    }

    // ── AtomicInteger — lock-free counter ─────────────────────────────────
    static void demonstrateAtomicInteger() throws InterruptedException {
        System.out.println("\n--- AtomicInteger (lock-free) ---");
        AtomicInteger counter = new AtomicInteger(0);
        int THREADS    = 10;
        int PER_THREAD = 10_000;

        ExecutorService pool = Executors.newFixedThreadPool(THREADS);
        CountDownLatch latch = new CountDownLatch(THREADS);
        for (int i = 0; i < THREADS; i++) {
            pool.submit(() -> {
                try {
                    for (int j = 0; j < PER_THREAD; j++)
                        counter.incrementAndGet(); // atomic CAS operation
                } finally { latch.countDown(); }
            });
        }
        latch.await(); pool.shutdown();

        System.out.printf("Expected: %d, Got: %d, Correct: %b%n",
            THREADS * PER_THREAD, counter.get(),
            counter.get() == THREADS * PER_THREAD);
    }

    // ── AtomicReference with CAS ───────────────────────────────────────────
    static void demonstrateAtomicReference() throws InterruptedException {
        System.out.println("\n--- AtomicReference — lock-free node swap ---");
        record Node(int value, Node next) {}

        AtomicReference<Node> head = new AtomicReference<>(null);

        // Lock-free stack push using CAS
        Runnable pushTask = () -> {
            for (int i = 0; i < 5; i++) {
                Node newHead, oldHead;
                do {
                    oldHead = head.get();
                    newHead = new Node(i, oldHead);
                } while (!head.compareAndSet(oldHead, newHead)); // retry if CAS fails
            }
        };

        Thread t1 = new Thread(pushTask, "T1");
        Thread t2 = new Thread(pushTask, "T2");
        t1.start(); t2.start();
        t1.join(); t2.join();

        // Count nodes
        int count = 0;
        Node curr = head.get();
        while (curr != null) { count++; curr = curr.next(); }
        System.out.println("Lock-free stack size: " + count + " (expected 10)");
    }

    // ── LongAdder — better than AtomicLong under high contention ──────────
    static void demonstrateLongAdder() throws InterruptedException {
        System.out.println("\n--- LongAdder vs AtomicLong performance ---");
        int THREADS = 20; int OPS = 100_000;

        // AtomicLong
        AtomicLong atomicLong = new AtomicLong();
        long t1 = System.nanoTime();
        runCounterTest(atomicLong::incrementAndGet, THREADS, OPS);
        long atomicTime = System.nanoTime() - t1;

        // LongAdder (reduces CAS contention via striped cells)
        LongAdder longAdder = new LongAdder();
        long t2 = System.nanoTime();
        runCounterTest(() -> { longAdder.increment(); return 0L; }, THREADS, OPS);
        long adderTime = System.nanoTime() - t2;

        System.out.printf("AtomicLong: %6.1fms, LongAdder: %6.1fms (%.1fx faster)%n",
            atomicTime / 1e6, adderTime / 1e6,
            (double) atomicTime / adderTime);
    }

    private static void runCounterTest(java.util.function.LongSupplier op,
                                       int threads, int opsPerThread) throws InterruptedException {
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        CountDownLatch latch = new CountDownLatch(threads);
        CountDownLatch go    = new CountDownLatch(1);
        for (int i = 0; i < threads; i++) {
            pool.submit(() -> {
                try {
                    go.await();
                    for (int j = 0; j < opsPerThread; j++) op.getAsLong();
                } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                finally { latch.countDown(); }
            });
        }
        go.countDown();
        latch.await();
        pool.shutdown();
    }

    // ── compareAndSet — custom CAS patterns ───────────────────────────────
    static void demonstrateCAS() {
        System.out.println("\n--- CAS (compareAndSet) ---");
        AtomicInteger val = new AtomicInteger(5);

        // Only update if value is still 5
        boolean success1 = val.compareAndSet(5, 10);
        System.out.println("CAS(5→10): " + success1 + ", value=" + val.get());

        boolean success2 = val.compareAndSet(5, 20); // will fail — val is now 10
        System.out.println("CAS(5→20): " + success2 + ", value=" + val.get());

        // getAndUpdate — apply function atomically
        int old = val.getAndUpdate(v -> v * 2);
        System.out.println("getAndUpdate(*2): was=" + old + ", now=" + val.get());

        // accumulateAndGet — binary accumulate
        val.accumulateAndGet(5, Integer::sum);
        System.out.println("accumulateAndGet(+5): " + val.get());
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== Atomic & Volatile Demo ===\n");
        demonstrateVolatile();
        demonstrateAtomicInteger();
        demonstrateAtomicReference();
        demonstrateLongAdder();
        demonstrateCAS();
    }
}