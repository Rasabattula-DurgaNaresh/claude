package com.concurrency.basics;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * TOPIC: Race Condition — demonstrating the problem and fix
 *
 * count++ is NOT atomic! Internally it is:
 *   1. Read:  temp = count
 *   2. Add:   temp = temp + 1
 *   3. Write: count = temp
 *
 * Two threads can interleave these steps → lost updates!
 *
 * Fix: synchronize the compound operation
 */
public class RaceConditionDemo {

    // ── UNSAFE counter ─────────────────────────────────────────────────────
    static class UnsafeCounter {
        private int count = 0;

        void increment() {
            count++;  // NOT atomic — race condition!
        }

        int getCount() { return count; }
    }

    // ── SAFE counter ───────────────────────────────────────────────────────
    static class SafeCounter {
        private int count = 0;

        synchronized void increment() {
            count++;  // atomic under monitor lock
        }

        synchronized int getCount() { return count; }
    }

    static void runTest(String label, Runnable task, int[] counter,
                        int threads, int perThread) throws InterruptedException {
        CountDownLatch latch = new CountDownLatch(1);
        CountDownLatch done  = new CountDownLatch(threads);
        ExecutorService pool = Executors.newFixedThreadPool(threads);

        for (int i = 0; i < threads; i++) {
            pool.submit(() -> {
                try {
                    latch.await(); // start all together
                    for (int j = 0; j < perThread; j++) task.run();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                } finally {
                    done.countDown();
                }
            });
        }

        latch.countDown(); // release all threads simultaneously
        done.await();
        pool.shutdown();

        int expected = threads * perThread;
        System.out.printf("%-20s Expected: %6d  Got: %6d  %s%n",
            label, expected, counter[0],
            counter[0] == expected ? "✓ CORRECT" : "✗ RACE CONDITION!");
    }

    public static void main(String[] args) throws InterruptedException {
        System.out.println("=== Race Condition Demo ===\n");

        int THREADS    = 10;
        int PER_THREAD = 10_000;

        // Unsafe
        UnsafeCounter unsafe = new UnsafeCounter();
        int[] unsafeResult = {0};
        Runnable unsafeTask = () -> { unsafe.increment(); unsafeResult[0] = unsafe.getCount(); };
        // Re-create for clean test
        UnsafeCounter u2 = new UnsafeCounter();
        CountDownLatch ul = new CountDownLatch(1);
        CountDownLatch ud = new CountDownLatch(THREADS);
        ExecutorService up = Executors.newFixedThreadPool(THREADS);
        for (int i=0; i<THREADS; i++) up.submit(() -> {
            try { ul.await(); for (int j=0;j<PER_THREAD;j++) u2.increment(); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            finally { ud.countDown(); }
        });
        ul.countDown(); ud.await(); up.shutdown();
        int expected = THREADS * PER_THREAD;
        System.out.printf("%-20s Expected: %6d  Got: %6d  %s%n",
            "UnsafeCounter", expected, u2.getCount(),
            u2.getCount() == expected ? "CORRECT" : "RACE CONDITION!");

        // Safe
        SafeCounter safe = new SafeCounter();
        CountDownLatch sl = new CountDownLatch(1);
        CountDownLatch sd = new CountDownLatch(THREADS);
        ExecutorService sp = Executors.newFixedThreadPool(THREADS);
        for (int i=0; i<THREADS; i++) sp.submit(() -> {
            try { sl.await(); for (int j=0;j<PER_THREAD;j++) safe.increment(); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            finally { sd.countDown(); }
        });
        sl.countDown(); sd.await(); sp.shutdown();
        System.out.printf("%-20s Expected: %6d  Got: %6d  %s%n",
            "SafeCounter", expected, safe.getCount(),
            safe.getCount() == expected ? "CORRECT" : "RACE CONDITION!");

        System.out.println("\nRun multiple times — UnsafeCounter result changes!");
    }
}