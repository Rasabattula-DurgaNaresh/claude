package com.concurrency.problems;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.concurrent.locks.*;

/**
 * PROBLEM: Thread-Safe Rate Limiter
 *
 * Algorithms:
 *  1. Token Bucket   — allows bursts up to bucket size
 *  2. Leaky Bucket   — smooths out traffic to fixed rate
 *  3. Sliding Window — precise rate per window
 *  4. Fixed Window   — simple but bursty at window edges
 *
 * Real-world use:
 *  - API rate limiting
 *  - Throttling DB calls
 *  - DDoS protection
 */
public class RateLimiter {

    // ── 1. Token Bucket ────────────────────────────────────────────────────
    static class TokenBucketRateLimiter {
        private final long capacity;          // max tokens
        private final long refillRate;        // tokens per second
        private volatile long tokens;         // current tokens
        private volatile long lastRefillTime; // epoch ms
        private final ReentrantLock lock = new ReentrantLock();

        TokenBucketRateLimiter(long capacity, long refillPerSecond) {
            this.capacity        = capacity;
            this.refillRate      = refillPerSecond;
            this.tokens          = capacity; // start full
            this.lastRefillTime  = System.currentTimeMillis();
        }

        boolean tryAcquire() {
            return tryAcquire(1);
        }

        boolean tryAcquire(int requested) {
            lock.lock();
            try {
                refill();
                if (tokens >= requested) {
                    tokens -= requested;
                    return true;
                }
                return false; // not enough tokens
            } finally {
                lock.unlock();
            }
        }

        // Block until token available
        void acquire() throws InterruptedException {
            while (!tryAcquire()) {
                Thread.sleep(50); // wait and retry
            }
        }

        private void refill() {
            long now     = System.currentTimeMillis();
            long elapsed = now - lastRefillTime;
            long newTokens = elapsed * refillRate / 1000; // scale to seconds
            if (newTokens > 0) {
                tokens = Math.min(capacity, tokens + newTokens);
                lastRefillTime = now;
            }
        }

        long getTokens() {
            lock.lock();
            try { refill(); return tokens; }
            finally { lock.unlock(); }
        }

        @Override
        public String toString() {
            return String.format("TokenBucket{capacity=%d, rate=%d/s, tokens=%d}",
                capacity, refillRate, tokens);
        }
    }

    // ── 2. Sliding Window Rate Limiter ────────────────────────────────────
    static class SlidingWindowRateLimiter {
        private final int     maxRequests;    // allowed per window
        private final long    windowMs;       // window duration
        private final Deque<Long> timestamps; // request timestamps
        private final ReentrantLock lock = new ReentrantLock();

        SlidingWindowRateLimiter(int maxRequests, long windowMs) {
            this.maxRequests = maxRequests;
            this.windowMs    = windowMs;
            this.timestamps  = new ArrayDeque<>();
        }

        boolean tryAcquire() {
            lock.lock();
            try {
                long now    = System.currentTimeMillis();
                long cutoff = now - windowMs;

                // Remove old entries outside the window
                while (!timestamps.isEmpty() && timestamps.peekFirst() < cutoff) {
                    timestamps.pollFirst();
                }

                if (timestamps.size() < maxRequests) {
                    timestamps.addLast(now);
                    return true;
                }
                return false; // rate limit exceeded
            } finally {
                lock.unlock();
            }
        }

        int getCurrentCount() {
            lock.lock();
            try {
                long cutoff = System.currentTimeMillis() - windowMs;
                while (!timestamps.isEmpty() && timestamps.peekFirst() < cutoff) {
                    timestamps.pollFirst();
                }
                return timestamps.size();
            } finally { lock.unlock(); }
        }
    }

    // ── 3. Fixed Window Counter ────────────────────────────────────────────
    static class FixedWindowRateLimiter {
        private final int    limit;
        private final long   windowMs;
        private AtomicInteger counter = new AtomicInteger(0);
        private volatile long windowStart = System.currentTimeMillis();
        private final ReentrantLock lock = new ReentrantLock();

        FixedWindowRateLimiter(int limit, long windowMs) {
            this.limit    = limit;
            this.windowMs = windowMs;
        }

        boolean tryAcquire() {
            lock.lock();
            try {
                long now = System.currentTimeMillis();
                if (now - windowStart >= windowMs) {
                    windowStart = now;
                    counter.set(0);
                }
                if (counter.get() < limit) {
                    counter.incrementAndGet();
                    return true;
                }
                return false;
            } finally { lock.unlock(); }
        }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== Rate Limiter Demo ===\n");

        // Token Bucket: 5 capacity, 2 tokens/second
        System.out.println("--- Token Bucket (capacity=5, rate=2/s) ---");
        TokenBucketRateLimiter tokenBucket = new TokenBucketRateLimiter(5, 2);

        ExecutorService pool = Executors.newFixedThreadPool(8);
        AtomicInteger allowed  = new AtomicInteger(0);
        AtomicInteger rejected = new AtomicInteger(0);
        CountDownLatch latch   = new CountDownLatch(15);

        for (int i = 1; i <= 15; i++) {
            final int id = i;
            pool.submit(() -> {
                try {
                    boolean ok = tokenBucket.tryAcquire();
                    if (ok) {
                        System.out.printf("[Request-%02d] ALLOWED  (tokens=%d)%n",
                            id, tokenBucket.getTokens());
                        allowed.incrementAndGet();
                    } else {
                        System.out.printf("[Request-%02d] REJECTED%n", id);
                        rejected.incrementAndGet();
                    }
                } finally { latch.countDown(); }
            });
            Thread.sleep(50); // requests spaced 50ms apart
        }
        latch.await();
        System.out.printf("Allowed: %d, Rejected: %d%n", allowed.get(), rejected.get());

        // Sliding Window: 5 requests per 500ms
        System.out.println("\n--- Sliding Window (5 req / 500ms) ---");
        SlidingWindowRateLimiter sliding = new SlidingWindowRateLimiter(5, 500);
        allowed.set(0); rejected.set(0);
        CountDownLatch latch2 = new CountDownLatch(10);

        for (int i = 1; i <= 10; i++) {
            final int id = i;
            pool.submit(() -> {
                boolean ok = sliding.tryAcquire();
                System.out.printf("[Req-%02d] %s (window=%d)%n",
                    id, ok ? "OK" : "REJECTED", sliding.getCurrentCount());
                if (ok) allowed.incrementAndGet(); else rejected.incrementAndGet();
                latch2.countDown();
            });
            Thread.sleep(80);
        }
        latch2.await();
        System.out.printf("Allowed: %d, Rejected: %d%n", allowed.get(), rejected.get());

        pool.shutdown();
    }
}