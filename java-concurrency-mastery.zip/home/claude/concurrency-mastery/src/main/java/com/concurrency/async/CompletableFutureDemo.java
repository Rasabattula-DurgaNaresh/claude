package com.concurrency.async;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Supplier;

/**
 * TOPIC: CompletableFuture — modern async programming
 *
 * Key stages:
 *   supplyAsync   — start async, return value
 *   runAsync      — start async, no return
 *   thenApply     — transform result (sync, same thread)
 *   thenApplyAsync— transform result (async, different thread)
 *   thenAccept    — consume result, return void
 *   thenCompose   — flatMap: result -> new CompletableFuture
 *   thenCombine   — combine two CFs when both complete
 *   exceptionally — recover from exception
 *   handle        — handle result OR exception
 *   allOf         — wait for all CFs
 *   anyOf         — complete when first CF completes
 */
public class CompletableFutureDemo {

    // Simulate slow services
    static String fetchUser(int id) {
        sleep(100);
        return "User-" + id;
    }

    static String fetchOrders(String userId) {
        sleep(150);
        return "Orders[" + userId + ": 3 orders]";
    }

    static double calculateDiscount(String orders) {
        sleep(50);
        return 0.15; // 15% discount
    }

    static void sleep(int ms) {
        try { Thread.sleep(ms); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    // ── Basic pipeline ─────────────────────────────────────────────────────
    static void basicPipeline() throws Exception {
        System.out.println("--- Basic async pipeline ---");
        long start = System.currentTimeMillis();

        CompletableFuture<Double> pipeline = CompletableFuture
            .supplyAsync(() -> fetchUser(42))                // 100ms
            .thenApply(user  -> fetchOrders(user))           // +150ms (sync — same thread pool)
            .thenApply(orders -> calculateDiscount(orders))  // +50ms
            .thenApply(discount -> {
                System.out.println("Final discount: " + (discount * 100) + "%");
                return discount;
            });

        Double result = pipeline.get();
        System.out.printf("Pipeline done in %dms (sequential: 300ms)%n",
            System.currentTimeMillis() - start);
    }

    // ── Parallel combining ─────────────────────────────────────────────────
    static void combineParallel() throws Exception {
        System.out.println("\n--- Parallel combining (thenCombine) ---");
        long start = System.currentTimeMillis();

        CompletableFuture<String> userFuture =
            CompletableFuture.supplyAsync(() -> fetchUser(42));      // 100ms

        CompletableFuture<String> orderFuture =
            CompletableFuture.supplyAsync(() -> fetchOrders("42")); // 150ms (parallel!)

        CompletableFuture<String> combined = userFuture.thenCombine(
            orderFuture,
            (user, orders) -> user + " | " + orders  // combine when both done
        );

        System.out.println("Combined: " + combined.get());
        System.out.printf("Done in %dms (expected ~150ms, not 250ms)%n",
            System.currentTimeMillis() - start);
    }

    // ── allOf — wait for multiple ─────────────────────────────────────────
    static void allOfDemo() throws Exception {
        System.out.println("\n--- allOf (wait for all) ---");
        long start = System.currentTimeMillis();

        List<CompletableFuture<String>> futures = new ArrayList<>();
        for (int i = 1; i <= 5; i++) {
            final int id = i;
            futures.add(CompletableFuture.supplyAsync(() -> {
                sleep(id * 20);
                return "Result-" + id;
            }));
        }

        CompletableFuture<Void> allDone = CompletableFuture.allOf(
            futures.toArray(new CompletableFuture[0])
        );
        allDone.get(); // blocks until ALL complete

        List<String> results = futures.stream()
            .map(CompletableFuture::join) // join() — no checked exception
            .toList();
        System.out.println("All results: " + results);
        System.out.printf("Completed in %dms (longest was 100ms)%n",
            System.currentTimeMillis() - start);
    }

    // ── Exception handling ────────────────────────────────────────────────
    static void exceptionHandling() throws Exception {
        System.out.println("\n--- Exception handling ---");
        AtomicInteger retries = new AtomicInteger(0);

        // exceptionally — recover from exception
        CompletableFuture<String> cf1 = CompletableFuture
            .supplyAsync(() -> {
                if (Math.random() > 0.5) throw new RuntimeException("Service unavailable");
                return "Success!";
            })
            .exceptionally(ex -> {
                System.out.println("Exception caught: " + ex.getMessage());
                return "Fallback response"; // recovery value
            });
        System.out.println("Result with fallback: " + cf1.get());

        // handle — handle both success and failure
        CompletableFuture<String> cf2 = CompletableFuture
            .supplyAsync(() -> { throw new RuntimeException("Error!"); })
            .handle((result, ex) -> {
                if (ex != null) {
                    return "Handled error: " + ex.getMessage();
                }
                return "Success: " + result;
            });
        System.out.println("Handle result: " + cf2.get());

        // whenComplete — side effects (doesn't change result)
        CompletableFuture<String> cf3 = CompletableFuture
            .supplyAsync(() -> "Hello")
            .whenComplete((result, ex) -> {
                if (ex == null) System.out.println("Completed with: " + result);
                else System.out.println("Failed with: " + ex);
            });
        cf3.get();
    }

    // ── thenCompose — flatMap for CF ──────────────────────────────────────
    static void thenComposeDemo() throws Exception {
        System.out.println("\n--- thenCompose (flatMap) ---");

        // If fetchOrders returned CF, use thenCompose (not thenApply)
        CompletableFuture<String> result = CompletableFuture
            .supplyAsync(() -> fetchUser(99))
            .thenCompose(user -> CompletableFuture.supplyAsync(() ->
                user + " → " + fetchOrders(user)
            ));

        System.out.println("Composed: " + result.get());
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== CompletableFuture Demo ===\n");
        basicPipeline();
        combineParallel();
        allOfDemo();
        exceptionHandling();
        thenComposeDemo();
        System.out.println("\nAll done!");
    }
}