package com.concurrency.synchronization;

import java.util.concurrent.*;
import java.util.concurrent.locks.*;

/**
 * TOPIC: Deadlock — detection, prevention, recovery
 *
 * Deadlock conditions (ALL four must hold):
 *  1. Mutual Exclusion — resource held exclusively
 *  2. Hold and Wait    — holding one, waiting for another
 *  3. No Preemption    — resource not forcibly taken
 *  4. Circular Wait    — circular dependency of locks
 *
 * Prevention strategies:
 *  A. Lock ordering    — always acquire in same order
 *  B. tryLock timeout  — avoid indefinite blocking
 *  C. Deadlock detection algorithm
 */
public class DeadlockDemo {

    private static final Object LOCK_A = new Object();
    private static final Object LOCK_B = new Object();

    // ── DEADLOCK scenario ──────────────────────────────────────────────────
    static void deadlockScenario() {
        Thread t1 = new Thread(() -> {
            synchronized (LOCK_A) {
                System.out.println("[T1] Holds Lock-A, waiting for Lock-B...");
                try { Thread.sleep(100); } catch (InterruptedException e) {}
                synchronized (LOCK_B) {           // T1 waits here
                    System.out.println("[T1] Got both locks!");
                }
            }
        }, "Thread-1");

        Thread t2 = new Thread(() -> {
            synchronized (LOCK_B) {
                System.out.println("[T2] Holds Lock-B, waiting for Lock-A...");
                try { Thread.sleep(100); } catch (InterruptedException e) {}
                synchronized (LOCK_A) {           // T2 waits here → DEADLOCK!
                    System.out.println("[T2] Got both locks!");
                }
            }
        }, "Thread-2");

        t1.start(); t2.start();

        try {
            // Wait 1 second — if no output, deadlock occurred
            t1.join(1000); t2.join(1000);
            if (t1.isAlive() || t2.isAlive()) {
                System.out.println("DEADLOCK DETECTED! Threads are stuck.");
                t1.interrupt(); t2.interrupt(); // attempt recovery
            }
        } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    // ── FIX 1: Lock ordering ───────────────────────────────────────────────
    static void fixByLockOrdering() throws InterruptedException {
        System.out.println("\n--- Fix 1: Lock Ordering ---");

        Thread t1 = new Thread(() -> {
            // Always lock A before B — consistent order!
            synchronized (LOCK_A) {
                synchronized (LOCK_B) {
                    System.out.println("[T1] Got A then B — success!");
                }
            }
        });

        Thread t2 = new Thread(() -> {
            // Same order: A before B — no deadlock possible
            synchronized (LOCK_A) {
                synchronized (LOCK_B) {
                    System.out.println("[T2] Got A then B — success!");
                }
            }
        });

        t1.start(); t2.start();
        t1.join(); t2.join();
    }

    // ── FIX 2: tryLock with timeout ────────────────────────────────────────
    static void fixByTryLock() throws InterruptedException {
        System.out.println("\n--- Fix 2: tryLock with Timeout ---");

        ReentrantLock lockA = new ReentrantLock();
        ReentrantLock lockB = new ReentrantLock();

        Runnable task = (String name, ReentrantLock first, ReentrantLock second) -> {
            throw new AssertionError(); // lambda can't throw checked
        };

        // Explicitly written:
        Thread t1 = new Thread(() -> {
            try {
                if (lockA.tryLock(100, TimeUnit.MILLISECONDS)) {
                    try {
                        System.out.println("[T1] Got Lock-A");
                        Thread.sleep(50);
                        if (lockB.tryLock(100, TimeUnit.MILLISECONDS)) {
                            try {
                                System.out.println("[T1] Got Lock-B — success!");
                            } finally { lockB.unlock(); }
                        } else {
                            System.out.println("[T1] Could not get Lock-B — retry later");
                        }
                    } finally { lockA.unlock(); }
                }
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        });

        Thread t2 = new Thread(() -> {
            try {
                if (lockB.tryLock(100, TimeUnit.MILLISECONDS)) {
                    try {
                        System.out.println("[T2] Got Lock-B");
                        Thread.sleep(50);
                        if (lockA.tryLock(100, TimeUnit.MILLISECONDS)) {
                            try {
                                System.out.println("[T2] Got Lock-A — success!");
                            } finally { lockA.unlock(); }
                        } else {
                            System.out.println("[T2] Could not get Lock-A — retry later");
                        }
                    } finally { lockB.unlock(); }
                }
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        });

        t1.start(); t2.start();
        t1.join(500); t2.join(500);
        System.out.println("No deadlock! (tryLock returned instead of blocking)");
    }

    public static void main(String[] args) throws InterruptedException {
        System.out.println("=== Deadlock Demo ===\n");

        System.out.println("--- Demonstrating Deadlock (1s timeout) ---");
        deadlockScenario();
        fixByLockOrdering();
        fixByTryLock();

        System.out.println("\nDone!");
    }
}