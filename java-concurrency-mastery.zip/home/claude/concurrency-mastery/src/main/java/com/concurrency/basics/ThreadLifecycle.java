package com.concurrency.basics;

import java.util.concurrent.TimeUnit;

/**
 * TOPIC: Thread Lifecycle — demonstrating all states
 *
 * NEW → RUNNABLE → RUNNING → (BLOCKED | WAITING | TIMED_WAITING) → TERMINATED
 *
 * Key methods:
 *   start()   — NEW → RUNNABLE
 *   sleep()   — RUNNING → TIMED_WAITING
 *   wait()    — RUNNING → WAITING (releases lock)
 *   join()    — caller waits for this thread to terminate
 *   interrupt()— signal a waiting/sleeping thread
 */
public class ThreadLifecycle {

    private static final Object LOCK = new Object();

    public static void main(String[] args) throws InterruptedException {
        System.out.println("=== Thread Lifecycle Demo ===\n");

        // ── NEW state ─────────────────────────────────────────────────────
        Thread t = new Thread(() -> {
            try {
                // TIMED_WAITING
                System.out.println("[Worker] sleeping (TIMED_WAITING)...");
                Thread.sleep(200);

                // WAITING
                synchronized (LOCK) {
                    System.out.println("[Worker] waiting for notify (WAITING)...");
                    LOCK.wait(500);
                }

                System.out.println("[Worker] finishing (RUNNABLE → TERMINATED)");
            } catch (InterruptedException e) {
                System.out.println("[Worker] interrupted!");
                Thread.currentThread().interrupt();
            }
        }, "WorkerThread");

        System.out.println("Before start: " + t.getState());   // NEW
        t.start();
        Thread.sleep(50);
        System.out.println("After start:  " + t.getState());   // RUNNABLE or TIMED_WAITING

        Thread.sleep(300);
        System.out.println("While waiting: " + t.getState());  // WAITING

        synchronized (LOCK) {
            LOCK.notifyAll();
        }

        t.join();
        System.out.println("After join:   " + t.getState());   // TERMINATED

        // ── Daemon thread ──────────────────────────────────────────────────
        System.out.println("\n--- Daemon Thread ---");
        Thread daemon = new Thread(() -> {
            while (true) {
                try { Thread.sleep(50); }
                catch (InterruptedException e) { break; }
                // JVM exits even if daemon is running
            }
        }, "DaemonThread");
        daemon.setDaemon(true);  // MUST set before start()
        daemon.start();
        System.out.println("Daemon alive: " + daemon.isAlive());
        System.out.println("Is daemon:    " + daemon.isDaemon());

        // ── Interrupt ─────────────────────────────────────────────────────
        System.out.println("\n--- Thread Interrupt ---");
        Thread interruptable = new Thread(() -> {
            for (int i = 0; i < 10; i++) {
                if (Thread.currentThread().isInterrupted()) {
                    System.out.println("[Interruptable] Interrupt flag detected, stopping.");
                    return;
                }
                System.out.println("[Interruptable] Working... " + i);
                try { Thread.sleep(30); }
                catch (InterruptedException e) {
                    System.out.println("[Interruptable] Interrupted during sleep!");
                    Thread.currentThread().interrupt(); // restore interrupt flag
                    return;
                }
            }
        }, "Interruptable");

        interruptable.start();
        Thread.sleep(80);
        interruptable.interrupt();
        interruptable.join();

        System.out.println("\nAll done!");
    }
}