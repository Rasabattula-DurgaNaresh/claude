package com.concurrency.locks;

import java.util.concurrent.*;
import java.util.concurrent.locks.*;

/**
 * TOPIC: ReentrantLock — more flexible than synchronized
 *
 * Advantages over synchronized:
 *   - tryLock() — non-blocking attempt
 *   - tryLock(timeout) — bounded wait
 *   - lockInterruptibly() — can be interrupted while waiting
 *   - Fair ordering — FIFO waiting (prevents starvation)
 *   - Multiple Condition variables (replaces wait/notify)
 *   - isLocked(), getQueueLength() — diagnostic
 *
 * MUST unlock() in finally block!
 */
public class ReentrantLockDemo {

    // ── Basic ReentrantLock usage ──────────────────────────────────────────
    static class SafeStack<T> {
        private final java.util.ArrayDeque<T> stack = new java.util.ArrayDeque<>();
        private final ReentrantLock lock = new ReentrantLock(true); // fair=true

        void push(T item) {
            lock.lock();
            try {
                stack.push(item);
            } finally {
                lock.unlock(); // ALWAYS unlock in finally!
            }
        }

        T pop() {
            lock.lock();
            try {
                return stack.isEmpty() ? null : stack.pop();
            } finally {
                lock.unlock();
            }
        }

        boolean tryPush(T item) {
            if (lock.tryLock()) { // non-blocking
                try {
                    stack.push(item);
                    return true;
                } finally {
                    lock.unlock();
                }
            }
            return false; // lock not available — don't wait
        }

        int size() {
            lock.lock();
            try { return stack.size(); }
            finally { lock.unlock(); }
        }
    }

    // ── Condition variables (replacement for wait/notify) ─────────────────
    static class BoundedBuffer<T> {
        private final java.util.ArrayDeque<T> buffer;
        private final int capacity;
        private final ReentrantLock lock = new ReentrantLock();
        private final Condition notFull  = lock.newCondition();
        private final Condition notEmpty = lock.newCondition();

        BoundedBuffer(int capacity) {
            this.capacity = capacity;
            this.buffer   = new java.util.ArrayDeque<>(capacity);
        }

        void put(T item) throws InterruptedException {
            lock.lock();
            try {
                while (buffer.size() == capacity) {
                    System.out.println("[" + Thread.currentThread().getName()
                        + "] Buffer full — waiting...");
                    notFull.await(); // releases lock, waits for signal
                }
                buffer.offer(item);
                System.out.println("[" + Thread.currentThread().getName()
                    + "] Put: " + item + " (size=" + buffer.size() + ")");
                notEmpty.signalAll(); // wake consumers
            } finally {
                lock.unlock();
            }
        }

        T take() throws InterruptedException {
            lock.lock();
            try {
                while (buffer.isEmpty()) {
                    System.out.println("[" + Thread.currentThread().getName()
                        + "] Buffer empty — waiting...");
                    notEmpty.await(); // releases lock, waits for signal
                }
                T item = buffer.poll();
                System.out.println("[" + Thread.currentThread().getName()
                    + "] Took: " + item + " (size=" + buffer.size() + ")");
                notFull.signalAll(); // wake producers
                return item;
            } finally {
                lock.unlock();
            }
        }
    }

    // ── Reentrancy — same thread can acquire lock multiple times ───────────
    static class ReentrantExample {
        private final ReentrantLock lock = new ReentrantLock();

        void outerMethod() {
            lock.lock();
            try {
                System.out.println("Outer method — hold count: " + lock.getHoldCount());
                innerMethod(); // same thread acquires lock again — OK!
            } finally {
                lock.unlock();
            }
        }

        void innerMethod() {
            lock.lock(); // reentrant — doesn't block!
            try {
                System.out.println("Inner method — hold count: " + lock.getHoldCount());
            } finally {
                lock.unlock();
            }
        }
    }

    public static void main(String[] args) throws InterruptedException {
        System.out.println("=== ReentrantLock Demo ===\n");

        // Safe stack
        System.out.println("--- SafeStack with ReentrantLock ---");
        SafeStack<Integer> stack = new SafeStack<>();
        ExecutorService pool = Executors.newFixedThreadPool(4);
        CountDownLatch latch = new CountDownLatch(8);

        for (int i = 1; i <= 8; i++) {
            final int val = i;
            pool.submit(() -> { stack.push(val); latch.countDown(); });
        }
        latch.await();
        System.out.println("Stack size: " + stack.size());

        // Bounded buffer
        System.out.println("\n--- BoundedBuffer with Conditions ---");
        BoundedBuffer<String> buf = new BoundedBuffer<>(3);
        Thread prod = new Thread(() -> {
            try {
                for (String s : new String[]{"A","B","C","D","E"})
                    buf.put(s);
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }, "Producer");
        Thread cons = new Thread(() -> {
            try {
                for (int i=0; i<5; i++) { Thread.sleep(80); buf.take(); }
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }, "Consumer");
        prod.start(); cons.start();
        prod.join(); cons.join();

        // Reentrancy
        System.out.println("\n--- Reentrancy Demo ---");
        new ReentrantExample().outerMethod();

        pool.shutdown();
    }
}