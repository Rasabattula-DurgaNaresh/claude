package com.concurrency.collections;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/**
 * TOPIC: Thread-safe collections
 *
 * ConcurrentHashMap:
 *   - Java 7: 16 lock segments (striping)
 *   - Java 8: CAS on individual nodes, fine-grained locking only on collision
 *   - compute(), merge(), computeIfAbsent() are atomic
 *
 * CopyOnWriteArrayList:
 *   - Every write creates a new array copy
 *   - Reads are ALWAYS lock-free (read the current snapshot)
 *   - Best for: event listeners, rarely-changing small lists
 *
 * BlockingQueue:
 *   - put() blocks when full
 *   - take() blocks when empty
 *   - Thread-safe, no external synchronization needed
 */
public class ConcurrentCollectionsDemo {

    // ── ConcurrentHashMap ─────────────────────────────────────────────────
    static void concurrentHashMapDemo() throws InterruptedException {
        System.out.println("--- ConcurrentHashMap ---");
        ConcurrentHashMap<String, AtomicInteger> wordCount = new ConcurrentHashMap<>();

        String[] words = {"apple","banana","apple","cherry","banana","apple","date","cherry"};
        List<Thread> threads = new ArrayList<>();

        // Multiple threads counting words concurrently
        for (int t = 0; t < 4; t++) {
            final int start = t * 2;
            Thread thread = new Thread(() -> {
                for (int i = start; i < Math.min(start + 2, words.length); i++) {
                    // computeIfAbsent is atomic — only one thread creates the counter
                    wordCount.computeIfAbsent(words[i], k -> new AtomicInteger(0))
                             .incrementAndGet();
                }
            });
            threads.add(thread);
            thread.start();
        }
        for (Thread t : threads) t.join();

        System.out.println("Word counts: " + wordCount);

        // Atomic compute operations
        ConcurrentHashMap<String, Integer> scores = new ConcurrentHashMap<>();
        scores.put("Alice", 100);
        scores.put("Bob",   200);

        // merge — combine existing and new value
        scores.merge("Alice", 50, Integer::sum);  // Alice: 150
        scores.merge("Carol", 75, Integer::sum);  // Carol: 75 (new entry)
        System.out.println("Scores after merge: " + scores);

        // compute — update atomically
        scores.compute("Bob", (key, val) -> val == null ? 10 : val + 50);
        System.out.println("After compute (Bob+50): " + scores.get("Bob"));

        // forEach with parallelism threshold
        System.out.print("Parallel forEach: ");
        scores.forEach(1, (k, v) -> System.out.print(k + "=" + v + " "));
        System.out.println();
    }

    // ── CopyOnWriteArrayList ──────────────────────────────────────────────
    static void copyOnWriteDemo() throws InterruptedException {
        System.out.println("\n--- CopyOnWriteArrayList ---");
        CopyOnWriteArrayList<String> listeners = new CopyOnWriteArrayList<>();

        // Register listeners
        listeners.add("EmailListener");
        listeners.add("SMSListener");
        listeners.add("LogListener");

        // Concurrent modification while iterating is safe!
        Thread reader = new Thread(() -> {
            // Snapshot at iterator creation — no ConcurrentModificationException
            for (String listener : listeners) {
                System.out.println("[Reader] Processing: " + listener);
                try { Thread.sleep(50); } catch (InterruptedException e) {}
            }
        });

        Thread writer = new Thread(() -> {
            try {
                Thread.sleep(30);
                listeners.add("PushListener");       // adds to NEW copy
                System.out.println("[Writer] Added PushListener");
                listeners.remove("LogListener");      // creates NEW copy
                System.out.println("[Writer] Removed LogListener");
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        });

        reader.start(); writer.start();
        reader.join(); writer.join();
        System.out.println("Final listeners: " + listeners);
    }

    // ── BlockingQueue ─────────────────────────────────────────────────────
    static void blockingQueueDemo() throws InterruptedException {
        System.out.println("\n--- BlockingQueue (producer-consumer) ---");
        BlockingQueue<Integer> queue = new ArrayBlockingQueue<>(5);
        AtomicBoolean done = new AtomicBoolean(false);

        Thread producer = new Thread(() -> {
            try {
                for (int i = 1; i <= 8; i++) {
                    queue.put(i);  // blocks when queue is full
                    System.out.printf("[Producer] Put %d (size=%d)%n", i, queue.size());
                    Thread.sleep(50);
                }
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            finally { done.set(true); }
        }, "Producer");

        Thread consumer = new Thread(() -> {
            try {
                while (!done.get() || !queue.isEmpty()) {
                    Integer val = queue.poll(200, TimeUnit.MILLISECONDS);
                    if (val != null) {
                        System.out.printf("[Consumer] Got %d (size=%d)%n", val, queue.size());
                        Thread.sleep(100);
                    }
                }
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }, "Consumer");

        producer.start(); consumer.start();
        producer.join(); consumer.join();

        // Priority queue
        System.out.println("\n--- PriorityBlockingQueue ---");
        PriorityBlockingQueue<Task> pq = new PriorityBlockingQueue<>();
        pq.add(new Task("Low",    3));
        pq.add(new Task("High",   1));
        pq.add(new Task("Medium", 2));
        pq.add(new Task("Urgent", 0));

        while (!pq.isEmpty()) {
            System.out.println("Processing: " + pq.take());
        }
    }

    record Task(String name, int priority) implements Comparable<Task> {
        @Override
        public int compareTo(Task other) {
            return Integer.compare(this.priority, other.priority);
        }
        @Override public String toString() {
            return name + "(priority=" + priority + ")";
        }
    }

    // ── ConcurrentLinkedQueue — lock-free ─────────────────────────────────
    static void lockFreeQueueDemo() throws InterruptedException {
        System.out.println("\n--- ConcurrentLinkedQueue (lock-free) ---");
        ConcurrentLinkedQueue<String> queue = new ConcurrentLinkedQueue<>();
        CountDownLatch latch = new CountDownLatch(4);
        ExecutorService pool = Executors.newFixedThreadPool(4);

        // 2 producers
        for (int i = 0; i < 2; i++) {
            final int id = i;
            pool.submit(() -> {
                try {
                    for (int j = 0; j < 5; j++) {
                        queue.offer("P" + id + "-Item" + j);
                        Thread.sleep(10);
                    }
                } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                finally { latch.countDown(); }
            });
        }

        // 2 consumers
        AtomicInteger consumed = new AtomicInteger(0);
        for (int i = 0; i < 2; i++) {
            pool.submit(() -> {
                try {
                    while (!queue.isEmpty() || consumed.get() < 10) {
                        String item = queue.poll();
                        if (item != null) consumed.incrementAndGet();
                        Thread.sleep(5);
                    }
                } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                finally { latch.countDown(); }
            });
        }

        latch.await();
        System.out.println("Total items consumed: " + consumed.get());
        pool.shutdown();
    }

    public static void main(String[] args) throws InterruptedException {
        System.out.println("=== Concurrent Collections Demo ===\n");
        concurrentHashMapDemo();
        copyOnWriteDemo();
        blockingQueueDemo();
        lockFreeQueueDemo();
        System.out.println("\nAll done!");
    }
}