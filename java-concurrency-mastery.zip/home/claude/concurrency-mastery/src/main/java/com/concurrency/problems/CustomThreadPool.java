package com.concurrency.problems;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.concurrent.locks.*;

/**
 * PROBLEM: Build a Custom Thread Pool from scratch.
 *
 * Internals of ThreadPoolExecutor:
 *  - Worker threads pull tasks from a BlockingQueue
 *  - corePoolSize: threads always alive
 *  - maximumPoolSize: max when queue full
 *  - keepAliveTime: how long extra threads idle before dying
 *  - RejectedExecutionHandler: what to do when full
 *
 * States: RUNNING → SHUTDOWN → STOP → TIDYING → TERMINATED
 */
public class CustomThreadPool {

    // ── Custom ThreadPool Implementation ──────────────────────────────────
    static class MyThreadPool {

        // Pool state constants
        private static final int RUNNING   = 0;
        private static final int SHUTDOWN  = 1;
        private static final int STOPPED   = 2;

        private final BlockingQueue<Runnable> taskQueue;
        private final List<Worker>            workers;
        private final int                     coreSize;
        private final String                  name;
        private volatile int                  state = RUNNING;
        private final AtomicInteger           completedTasks = new AtomicInteger(0);
        private final ReentrantLock           mainLock = new ReentrantLock();

        MyThreadPool(int coreSize, int queueCapacity, String name) {
            this.coreSize  = coreSize;
            this.name      = name;
            this.taskQueue = new ArrayBlockingQueue<>(queueCapacity);
            this.workers   = new ArrayList<>(coreSize);

            // Pre-start core threads
            for (int i = 0; i < coreSize; i++) {
                Worker worker = new Worker(i);
                workers.add(worker);
                worker.start();
            }
            System.out.printf("[%s] Pool started with %d threads%n", name, coreSize);
        }

        // ── Worker thread ─────────────────────────────────────────────────
        private class Worker extends Thread {
            private final int id;
            private Runnable currentTask;
            private long tasksCompleted = 0;

            Worker(int id) {
                super(name + "-Worker-" + id);
                this.id = id;
                setDaemon(false);
            }

            @Override
            public void run() {
                System.out.printf("[%s] Worker-%d started%n", name, id);
                try {
                    while (state == RUNNING || (state == SHUTDOWN && !taskQueue.isEmpty())) {
                        // Poll with timeout so we can check state periodically
                        Runnable task = taskQueue.poll(100, TimeUnit.MILLISECONDS);
                        if (task != null) {
                            currentTask = task;
                            try {
                                task.run();
                                tasksCompleted++;
                                completedTasks.incrementAndGet();
                            } catch (Exception e) {
                                System.err.printf("[%s] Worker-%d task threw: %s%n",
                                    name, id, e.getMessage());
                            } finally {
                                currentTask = null;
                            }
                        }
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                } finally {
                    System.out.printf("[%s] Worker-%d stopped (completed %d tasks)%n",
                        name, id, tasksCompleted);
                }
            }

            long getTasksCompleted() { return tasksCompleted; }
        }

        // ── Submit task ───────────────────────────────────────────────────
        boolean submit(Runnable task) {
            if (state != RUNNING) {
                System.out.println("[" + name + "] Pool is shutting down, task rejected!");
                return false;
            }
            boolean added = taskQueue.offer(task);
            if (!added) {
                System.out.println("[" + name + "] Queue full! Task rejected (use CallerRunsPolicy?)");
                // CallerRunsPolicy: task.run(); // run in caller thread
            }
            return added;
        }

        // ── Graceful shutdown ─────────────────────────────────────────────
        void shutdown() {
            state = SHUTDOWN;
            System.out.printf("[%s] Shutdown initiated (queued: %d tasks)%n",
                name, taskQueue.size());
        }

        void shutdownNow() {
            state = STOPPED;
            taskQueue.clear();
            workers.forEach(Thread::interrupt);
            System.out.println("[" + name + "] Forced shutdown!");
        }

        boolean awaitTermination(long timeout, TimeUnit unit) throws InterruptedException {
            long deadline = System.currentTimeMillis() + unit.toMillis(timeout);
            for (Worker w : workers) {
                long remaining = deadline - System.currentTimeMillis();
                if (remaining <= 0) return false;
                w.join(remaining);
            }
            return workers.stream().noneMatch(Thread::isAlive);
        }

        // ── Diagnostics ───────────────────────────────────────────────────
        void printStats() {
            System.out.printf("[%s] Stats: threads=%d, queued=%d, completed=%d%n",
                name, coreSize, taskQueue.size(), completedTasks.get());
            workers.forEach(w ->
                System.out.printf("  Worker-%d: completed=%d, alive=%b%n",
                    w.id, w.getTasksCompleted(), w.isAlive()));
        }
    }

    // ── ThreadPoolExecutor tuning guide ──────────────────────────────────
    static void threadPoolExecutorDemo() throws InterruptedException {
        System.out.println("\n--- ThreadPoolExecutor (built-in) tuning ---");

        ThreadPoolExecutor pool = new ThreadPoolExecutor(
            2,                                    // corePoolSize
            8,                                    // maximumPoolSize
            60L, TimeUnit.SECONDS,               // keepAliveTime
            new ArrayBlockingQueue<>(100),        // workQueue
            r -> {
                Thread t = new Thread(r);
                t.setName("CustomPool-" + t.getId());
                t.setDaemon(false);
                return t;
            },                                    // threadFactory
            new ThreadPoolExecutor.CallerRunsPolicy() // rejection: run in caller
        );

        pool.allowCoreThreadTimeOut(false); // keep core threads alive

        // Submit tasks
        for (int i = 1; i <= 10; i++) {
            final int id = i;
            pool.submit(() -> {
                try {
                    System.out.printf("[Task-%02d] Running on %s%n",
                        id, Thread.currentThread().getName());
                    Thread.sleep(50);
                } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            });
        }

        pool.shutdown();
        pool.awaitTermination(5, TimeUnit.SECONDS);

        System.out.println("Pool stats:");
        System.out.println("  Completed tasks: " + pool.getCompletedTaskCount());
        System.out.println("  Largest pool:    " + pool.getLargestPoolSize());
        System.out.println("  Task count:      " + pool.getTaskCount());
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== Custom Thread Pool Demo ===\n");

        // Test custom pool
        MyThreadPool pool = new MyThreadPool(3, 20, "MyPool");

        CountDownLatch latch = new CountDownLatch(10);
        for (int i = 1; i <= 10; i++) {
            final int id = i;
            pool.submit(() -> {
                try {
                    System.out.printf("[Task-%02d] Running on %s%n",
                        id, Thread.currentThread().getName());
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                } finally {
                    latch.countDown();
                }
            });
        }

        latch.await();
        pool.printStats();
        pool.shutdown();
        pool.awaitTermination(3, TimeUnit.SECONDS);

        threadPoolExecutorDemo();
        System.out.println("\nDone!");
    }
}