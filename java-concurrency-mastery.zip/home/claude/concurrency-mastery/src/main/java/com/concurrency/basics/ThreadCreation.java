package com.concurrency.basics;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

/**
 * TOPIC: Creating Threads — 4 ways
 *
 * 1. Extend Thread class
 * 2. Implement Runnable (preferred — separates task from thread)
 * 3. Lambda expression (Java 8+)
 * 4. Callable + FutureTask (returns a result)
 */
public class ThreadCreation {

    // ── 1. Extend Thread ──────────────────────────────────────────────────
    static class MyThread extends Thread {
        private final String message;

        MyThread(String message) { this.message = message; }

        @Override
        public void run() {
            System.out.printf("[%s] %s%n", Thread.currentThread().getName(), message);
        }
    }

    // ── 2. Implement Runnable ──────────────────────────────────────────────
    static class PrintTask implements Runnable {
        private final int id;

        PrintTask(int id) { this.id = id; }

        @Override
        public void run() {
            System.out.printf("[%s] Task-%d running%n",
                Thread.currentThread().getName(), id);
        }
    }

    // ── 4. Callable — returns a value ──────────────────────────────────────
    static class SumCallable implements Callable<Long> {
        private final long from, to;

        SumCallable(long from, long to) { this.from = from; this.to = to; }

        @Override
        public Long call() {
            long sum = 0;
            for (long i = from; i <= to; i++) sum += i;
            System.out.printf("[%s] Sum(%d..%d) = %d%n",
                Thread.currentThread().getName(), from, to, sum);
            return sum;
        }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== Thread Creation Demo ===\n");

        // ── Way 1: extend Thread ──────────────────────────────────────────
        System.out.println("--- 1. Extending Thread ---");
        MyThread t1 = new MyThread("Hello from extended thread");
        t1.setName("ExtendedThread");
        t1.start();
        t1.join(); // wait for completion

        // ── Way 2: Runnable ───────────────────────────────────────────────
        System.out.println("\n--- 2. Runnable interface ---");
        Thread t2 = new Thread(new PrintTask(42), "RunnableThread");
        t2.start();
        t2.join();

        // ── Way 3: Lambda ──────────────────────────────────────────────────
        System.out.println("\n--- 3. Lambda expression ---");
        Runnable lambda = () ->
            System.out.printf("[%s] Lambda thread!%n", Thread.currentThread().getName());
        Thread t3 = new Thread(lambda, "LambdaThread");
        t3.start();
        t3.join();

        // ── Way 4: Callable + FutureTask ──────────────────────────────────
        System.out.println("\n--- 4. Callable + FutureTask ---");
        FutureTask<Long> futureTask = new FutureTask<>(new SumCallable(1, 100));
        Thread t4 = new Thread(futureTask, "CallableThread");
        t4.start();
        Long result = futureTask.get(); // blocks until result ready
        System.out.println("Result from Callable: " + result);

        // ── Thread info ───────────────────────────────────────────────────
        System.out.println("\n--- Thread Information ---");
        Thread current = Thread.currentThread();
        System.out.println("Name:      " + current.getName());
        System.out.println("ID:        " + current.getId());
        System.out.println("Priority:  " + current.getPriority());
        System.out.println("Daemon:    " + current.isDaemon());
        System.out.println("State:     " + current.getState());
        System.out.println("Alive:     " + current.isAlive());
    }
}