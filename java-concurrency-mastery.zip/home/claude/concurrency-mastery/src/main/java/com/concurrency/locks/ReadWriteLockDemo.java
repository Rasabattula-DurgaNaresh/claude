package com.concurrency.locks;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;

/**
 * TOPIC: ReadWriteLock — optimal for read-heavy workloads
 *
 * Allows:
 *   - MULTIPLE concurrent readers  (no blocking between readers)
 *   - SINGLE exclusive writer      (blocks all readers AND writers)
 *
 * Use cases:
 *   - Configuration caches
 *   - Look-up tables
 *   - Rarely-updated shared data
 *
 * StampedLock (Java 8+): even more optimistic — try read first,
 *   validate, only fall back to read lock if write occurred.
 */
public class ReadWriteLockDemo {

    // ── Thread-safe cache with ReadWriteLock ──────────────────────────────
    static class ConfigCache {
        private final Map<String, String> cache = new HashMap<>();
        private final ReadWriteLock rwLock = new ReentrantReadWriteLock(true);
        private final Lock readLock  = rwLock.readLock();
        private final Lock writeLock = rwLock.writeLock();
        private int readCount  = 0;
        private int writeCount = 0;

        // READ — multiple threads can read simultaneously
        String get(String key) {
            readLock.lock();
            try {
                readCount++;
                Thread.sleep(5); // simulate read time
                return cache.get(key);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return null;
            } finally {
                readLock.unlock();
            }
        }

        // WRITE — exclusive, blocks all readers
        void put(String key, String value) {
            writeLock.lock();
            try {
                writeCount++;
                System.out.printf("[%s] Writing: %s=%s%n",
                    Thread.currentThread().getName(), key, value);
                Thread.sleep(20); // simulate write time
                cache.put(key, value);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } finally {
                writeLock.unlock();
            }
        }

        Map<String, String> snapshot() {
            readLock.lock();
            try { return new HashMap<>(cache); }
            finally { readLock.unlock(); }
        }

        void printStats() {
            System.out.printf("Reads: %d, Writes: %d%n", readCount, writeCount);
        }
    }

    // ── StampedLock — optimistic reading ─────────────────────────────────
    static class PointWithStampedLock {
        private double x, y;
        private final StampedLock sl = new StampedLock();

        void move(double deltaX, double deltaY) {
            long stamp = sl.writeLock();
            try {
                x += deltaX;
                y += deltaY;
            } finally {
                sl.unlockWrite(stamp);
            }
        }

        // Optimistic read — zero cost if no write occurred
        double distanceFromOrigin() {
            long stamp = sl.tryOptimisticRead();
            double curX = x, curY = y;

            if (!sl.validate(stamp)) {
                // Write occurred — fall back to full read lock
                stamp = sl.readLock();
                try {
                    curX = x; curY = y;
                } finally {
                    sl.unlockRead(stamp);
                }
            }
            return Math.sqrt(curX * curX + curY * curY);
        }
    }

    public static void main(String[] args) throws InterruptedException {
        System.out.println("=== ReadWriteLock Demo ===\n");

        ConfigCache config = new ConfigCache();
        config.put("host", "localhost");
        config.put("port", "8080");
        config.put("db",   "postgres");

        ExecutorService pool = Executors.newFixedThreadPool(8);
        CountDownLatch latch = new CountDownLatch(20);
        long start = System.currentTimeMillis();

        // 15 readers — all can run simultaneously
        for (int i = 0; i < 15; i++) {
            pool.submit(() -> {
                try {
                    String[] keys = {"host","port","db"};
                    String v = config.get(keys[new Random().nextInt(3)]);
                } finally { latch.countDown(); }
            });
        }

        // 5 writers — exclusive
        for (int i = 0; i < 5; i++) {
            final int id = i;
            pool.submit(() -> {
                try {
                    config.put("key-" + id, "value-" + id);
                } finally { latch.countDown(); }
            });
        }

        latch.await();
        long elapsed = System.currentTimeMillis() - start;
        System.out.printf("Completed in %dms%n", elapsed);
        config.printStats();
        System.out.println("Final cache: " + config.snapshot());

        // StampedLock
        System.out.println("\n--- StampedLock (optimistic read) ---");
        PointWithStampedLock point = new PointWithStampedLock();
        point.move(3, 4);
        System.out.printf("Distance from origin: %.1f (expected 5.0)%n",
            point.distanceFromOrigin());

        pool.shutdown();
    }
}