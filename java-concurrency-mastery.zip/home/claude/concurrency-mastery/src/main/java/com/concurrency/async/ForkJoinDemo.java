package com.concurrency.async;

import java.util.*;
import java.util.concurrent.*;

/**
 * TOPIC: ForkJoinPool — divide and conquer
 *
 * RecursiveTask<T>  — returns a result
 * RecursiveAction   — no return (side-effect only)
 *
 * Work-stealing:
 *   Each worker thread has its own deque of tasks.
 *   Idle threads STEAL tasks from the back of busy threads' deques.
 *   This maximises CPU utilisation.
 *
 * Used by:
 *   - parallelStream()
 *   - Arrays.parallelSort()
 *   - CompletableFuture.supplyAsync() (default pool)
 */
public class ForkJoinDemo {

    // ── Parallel sum — RecursiveTask ──────────────────────────────────────
    static class ParallelSum extends RecursiveTask<Long> {
        private static final int THRESHOLD = 10_000; // base case cutoff
        private final long[] array;
        private final int from, to;

        ParallelSum(long[] array, int from, int to) {
            this.array = array;
            this.from  = from;
            this.to    = to;
        }

        @Override
        protected Long compute() {
            int size = to - from;

            if (size <= THRESHOLD) {
                // Base case — compute directly (no more splitting)
                long sum = 0;
                for (int i = from; i < to; i++) sum += array[i];
                return sum;
            }

            // Divide: split in half
            int mid = (from + to) / 2;
            ParallelSum left  = new ParallelSum(array, from, mid);
            ParallelSum right = new ParallelSum(array, mid,  to);

            left.fork();          // execute left asynchronously
            long rightResult = right.compute(); // execute right inline
            long leftResult  = left.join();     // wait for left

            return leftResult + rightResult;   // Conquer: combine
        }
    }

    // ── Parallel merge sort — RecursiveAction ─────────────────────────────
    static class ParallelMergeSort extends RecursiveAction {
        private static final int THRESHOLD = 1000;
        private final int[] array;
        private final int from, to;

        ParallelMergeSort(int[] array, int from, int to) {
            this.array = array;
            this.from  = from;
            this.to    = to;
        }

        @Override
        protected void compute() {
            if (to - from <= THRESHOLD) {
                Arrays.sort(array, from, to); // sequential base case
                return;
            }

            int mid = (from + to) / 2;
            ParallelMergeSort left  = new ParallelMergeSort(array, from, mid);
            ParallelMergeSort right = new ParallelMergeSort(array, mid,  to);

            invokeAll(left, right); // fork both, wait for both
            merge(array, from, mid, to);
        }

        private void merge(int[] arr, int from, int mid, int to) {
            int[] temp = Arrays.copyOfRange(arr, from, to);
            int l = 0, r = mid - from, k = from;
            while (l < mid - from && r < to - from) {
                arr[k++] = (temp[l] <= temp[r]) ? temp[l++] : temp[r++];
            }
            while (l < mid - from) arr[k++] = temp[l++];
            while (r < to - from)  arr[k++] = temp[r++];
        }
    }

    // ── Custom ForkJoinPool ────────────────────────────────────────────────
    static void customPoolDemo() throws Exception {
        System.out.println("\n--- Custom ForkJoinPool ---");

        // Custom pool — don't pollute commonPool
        ForkJoinPool customPool = new ForkJoinPool(
            4,                                    // parallelism
            ForkJoinPool.defaultForkJoinWorkerThreadFactory,
            (t, e) -> System.err.println("UncaughtEx: " + e), // exception handler
            false                                 // asyncMode
        );

        long[] data = new long[1_000_000];
        Arrays.fill(data, 1L); // sum should be 1,000,000

        long result = customPool.submit(new ParallelSum(data, 0, data.length)).get();
        System.out.println("Sum: " + result + " (expected 1000000)");

        customPool.shutdown();
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== ForkJoinPool Demo ===\n");

        // Sum via ForkJoin
        System.out.println("--- Parallel Sum (RecursiveTask) ---");
        ForkJoinPool pool = ForkJoinPool.commonPool();
        System.out.println("Pool parallelism: " + pool.getParallelism()
            + " (= # CPU cores - 1)");

        long[] data = new long[100_000_000];
        Arrays.fill(data, 1L);

        // Sequential
        long start = System.nanoTime();
        long seqSum = 0; for (long v : data) seqSum += v;
        long seqTime = System.nanoTime() - start;

        // Parallel
        start = System.nanoTime();
        long parSum = pool.invoke(new ParallelSum(data, 0, data.length));
        long parTime = System.nanoTime() - start;

        System.out.printf("Sequential: %,d (%.0fms)%n", seqSum, seqTime/1e6);
        System.out.printf("Parallel:   %,d (%.0fms) — %.1fx speedup%n",
            parSum, parTime/1e6, (double)seqTime/parTime);

        // Merge sort
        System.out.println("\n--- Parallel MergeSort (RecursiveAction) ---");
        int[] arr = new Random(42).ints(100_000).toArray();
        int[] arrCopy = arr.clone();

        start = System.nanoTime();
        Arrays.sort(arrCopy);
        long seqSort = System.nanoTime() - start;

        start = System.nanoTime();
        pool.invoke(new ParallelMergeSort(arr, 0, arr.length));
        long parSort = System.nanoTime() - start;

        System.out.printf("Arrays.sort: %.0fms%n", seqSort/1e6);
        System.out.printf("ParallelSort:%.0fms%n", parSort/1e6);
        System.out.println("Arrays.equals: " + Arrays.equals(arr, arrCopy));

        // parallelStream (uses commonPool internally)
        System.out.println("\n--- parallelStream (uses ForkJoinPool) ---");
        long sum = java.util.stream.LongStream.rangeClosed(1, 1_000_000)
            .parallel()
            .sum();
        System.out.println("parallelStream sum: " + sum);

        customPoolDemo();
    }
}