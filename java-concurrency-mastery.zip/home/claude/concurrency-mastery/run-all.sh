#!/bin/bash
# Run all concurrency demos

mvn compile -q

CLASSES=(
  "com.concurrency.basics.ThreadCreation"
  "com.concurrency.basics.ThreadLifecycle"
  "com.concurrency.basics.RaceConditionDemo"
  "com.concurrency.synchronization.SynchronizationDemo"
  "com.concurrency.synchronization.DeadlockDemo"
  "com.concurrency.synchronization.AtomicAndVolatileDemo"
  "com.concurrency.locks.ReentrantLockDemo"
  "com.concurrency.locks.ReadWriteLockDemo"
  "com.concurrency.executors.ExecutorDemo"
  "com.concurrency.async.CompletableFutureDemo"
  "com.concurrency.async.ForkJoinDemo"
  "com.concurrency.collections.ConcurrentCollectionsDemo"
  "com.concurrency.advanced.AdvancedSynchronizersDemo"
  "com.concurrency.problems.ProducerConsumer"
  "com.concurrency.problems.LRUCacheWithLock"
  "com.concurrency.problems.CustomThreadPool"
  "com.concurrency.problems.RateLimiter"
  "com.concurrency.problems.LockFreeQueue"
)

for cls in "${CLASSES[@]}"; do
  echo ""
  echo "========================================"
  echo "Running: $cls"
  echo "========================================"
  mvn exec:java -Dexec.mainClass="$cls" -q 2>&1
done