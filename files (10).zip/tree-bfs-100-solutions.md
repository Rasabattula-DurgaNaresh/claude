# 100 Tree BFS Problems — Complete Java Solutions

> **100 Problems · 4 Java files · 5 PNG diagrams · O(n) all core patterns**

---

## Diagram Index

| Diagram | Covers |
|---------|--------|
| `diagrams/01_bfs_core.png` | Queue state trace per step + master template code |
| `diagrams/02_traversal_variations.png` | 8 variations: right/left view, zigzag, reverse, max/min/avg per level |
| `diagrams/03_next_pointers_distK.png` | Next pointers + zigzag deque trick + Distance K algorithm |
| `diagrams/04_path_sum_nary.png` | Path sum tracking + N-ary tree BFS + burn tree animation |
| `diagrams/05_decision_tree.png` | Complete guide: problem → algorithm → complexity |

## Project Structure

```
tree-bfs-100/
├── pom.xml
├── diagrams/           ← 5 PNG flow diagrams
├── docs/               ← This guide
└── src/main/java/com/treebfs/
    ├── utils/      TreeNode.java          (shared: TreeNode + NaryNode)
    ├── basic/      BasicBFS.java          (B1-10: core level order)
    ├── traversal/  TraversalVariations.java (T1-10 + D1-10)
    └── advanced/   AdvancedBFS.java       (C1-10, P1-10, B1-10,
                                             N1-10, G1-10, LC1-10, IN1-10)
```

**Run:**
```bash
mvn compile exec:java -Dexec.mainClass="com.treebfs.basic.BasicBFS"
mvn compile exec:java -Dexec.mainClass="com.treebfs.traversal.TraversalVariations"
mvn compile exec:java -Dexec.mainClass="com.treebfs.advanced.AdvancedBFS"
```

---

# Master Template — Core BFS

```java
// TIME: O(n)  SPACE: O(w) where w = max width of tree
Queue<TreeNode> queue = new LinkedList<>();
queue.offer(root);

while (!queue.isEmpty()) {
    int size = queue.size();     // ← CRITICAL: capture before processing
    List<Integer> level = new ArrayList<>();

    for (int i = 0; i < size; i++) {
        TreeNode node = queue.poll();
        level.add(node.val);

        if (node.left  != null) queue.offer(node.left);
        if (node.right != null) queue.offer(node.right);
    }

    result.add(level);           // one complete level processed
}
```

**Why capture `size` at start?** Because we'll be adding new nodes during the loop. `size` represents exactly the nodes at the CURRENT level before any children are added.

---

# All BFS Variants

## Variant 1 — Standard Level Order
```java
// result = [[1],[2,3],[4,5,6,7]]
Queue<TreeNode> q = new LinkedList<>();
q.offer(root);
while (!q.isEmpty()) { /* size loop */ }
```

## Variant 2 — Reverse Level Order
```java
// Add each level to FRONT of result (or reverse at end)
LinkedList<List<Integer>> result = new LinkedList<>();
result.addFirst(level); // prepend instead of append
```

## Variant 3 — Zigzag Level Order
```java
// Use LinkedList<Integer> for level, toggle addFirst/addLast
LinkedList<Integer> level = new LinkedList<>();
if (leftToRight) level.addLast(node.val);
else              level.addFirst(node.val);
leftToRight = !leftToRight; // toggle after each level
```

## Variant 4 — Right/Left View
```java
// Right: collect LAST node at each level
if (i == size - 1) result.add(node.val);
// Left: collect FIRST node at each level
if (i == 0) result.add(node.val);
```

## Variant 5 — Next Right Pointers
```java
// Track prev, connect prev.next = current
TreeNode prev = null;
for (int i = 0; i < size; i++) {
    TreeNode node = queue.poll();
    if (prev != null) prev.next = node;
    prev = node;
}
// prev.next = null (last node at level)
```

## Variant 6 — Column Tracking (Vertical Order)
```java
// Two parallel queues: nodes and columns
Queue<TreeNode> nodeQ = new LinkedList<>();
Queue<Integer> colQ = new LinkedList<>();
nodeQ.offer(root); colQ.offer(0);
// Child columns: left→col-1, right→col+1
```

## Variant 7 — Parent Map + BFS from Target (Distance K)
```java
// Step 1: DFS/BFS to build parentMap
Map<TreeNode,TreeNode> parent = new HashMap<>();
// Step 2: BFS from target treating tree as undirected graph
Queue<TreeNode> q = new LinkedList<>();
Set<TreeNode> seen = new HashSet<>();
q.offer(target); seen.add(target);
// Explore: left, right, parent
```

---

# BASIC LEVEL ORDER (B1–B10)

## B1. Binary Tree Level Order Traversal ⭐
**LeetCode 102** — Returns `List<List<Integer>>`. Core template.

```
Tree:       1
           / \
          2   3
         / \ / \
        4  5 6  7
Output: [[1],[2,3],[4,5,6,7]]
```

---

## B2. Level Order Line by Line
Print each level as a separate line. Same BFS, different output formatting.

---

## B3. Reverse Level Order ⭐
**LeetCode 107** — Deepest level first. Use `result.addFirst(level)` or reverse at end.

```
Output: [[4,5,6,7],[2,3],[1]]
```

---

## B4. Zigzag Level Order ⭐⭐
**LeetCode 103** — Alternate left-to-right and right-to-left.

```
Output: [[1],[3,2],[4,5,6,7]]
Use LinkedList<Integer>: addLast vs addFirst based on level parity
```

---

## B5. Average of Levels ⭐
**LeetCode 637** — `sum / size` per level. Watch for integer overflow — use `double`.

---

## B6. Largest Value in Each Row ⭐
**LeetCode 515** — Track `max = Integer.MIN_VALUE` per level, update with each node.

---

## B7. Minimum Value at Each Level
Same as B6 but track `min = Integer.MAX_VALUE`.

---

## B8. Level Order Successor
After seeing key node, return `queue.peek()` — next node in BFS order.

---

## B9. Connect Level Order Siblings ⭐⭐
**LeetCode 116** — Track `prev` pointer, connect `prev.next = node`.

```java
TreeNode prev = null;
for (int i = 0; i < size; i++) {
    TreeNode node = queue.poll();
    if (prev != null) prev.next = node;
    prev = node;
    // ... enqueue children
}
// Don't set prev.next = null — it's already null by default
```

---

## B10. Connect All Siblings (LeetCode 117)
Any binary tree (not just perfect). Process all nodes in single BFS stream without size loop — `prev.next` always points to next in BFS order.

---

# TRAVERSAL VARIATIONS (T1–T10)

## T1. Right Side View ⭐
**LeetCode 199** — Collect last node at each level.

```
Tree: 1→[2,3]→[4,5,6,7]
Right view: [1,3,7]
```

---

## T2. Left Side View
Collect first node at each level. `if (i == 0) result.add(node.val)`.

---

## T3. Top View
First node seen at each column. Use `colMap.putIfAbsent(col, node.val)` — BFS ensures top-most comes first.

---

## T4. Bottom View
Last node seen at each column. Use `colMap.put(col, node.val)` — overwrites with bottom-most.

---

## T5. Vertical Order Traversal ⭐⭐
**LeetCode 987** — Track `(col, row)` for each node. Sort by `(col, row, val)`.

```java
// For sorting within same column and row: sort by val
entries.sort((a,b) -> a[0]!=b[0] ? a[0]-b[0] : a[1]-b[1]);
```

---

## T6. Diagonal Traversal
Left child → diagonal+1, Right child → same diagonal. Group by diagonal number.

---

## T7. Boundary Traversal
Left boundary (top-down) + all leaves (left-right) + right boundary (bottom-up). No duplicates.

---

## T8. Spiral Level Order
= Zigzag. Alternate direction each level using Deque.

---

## T10. Corner Nodes
First and last node at each level: `[first, last]` pairs.

---

# DEPTH & HEIGHT (D1–D10)

## D1. Minimum Depth ⭐
**LeetCode 111** — BFS: **stop at FIRST leaf** (not deepest). Crucial difference from max depth!

```java
if (node.left == null && node.right == null) return depth; // FIRST leaf = min depth
```

---

## D2. Maximum Depth ⭐
**LeetCode 104** — Count total levels in BFS. `depth++` after each level.

---

## D4. Balanced Binary Tree
For each node (BFS order): check `|height(left) - height(right)| <= 1`.

---

## D5. Deepest Node
Last node dequeued from BFS (overall, not per-level).

---

## D6. Nodes at Maximum Depth
Last level processed in BFS — store and return it.

---

## D8. Level with Maximum Sum
Track `maxSum` and `maxLevel` across all levels.

---

## D10. Minimum Height Trees (LeetCode 310) ⭐⭐
Topological sort: repeatedly remove leaves. Final remaining nodes = roots of min-height trees.

```java
// Find degree-1 nodes (leaves), remove them, repeat
// At most 2 nodes remain → answer
```

---

# BFS NODE CONNECTIONS (C1–C10)

## C1. Populating Next Right Pointers ⭐
**LeetCode 116** — See B9 above.

---

## C2. Cousins in Binary Tree ⭐
**LeetCode 993** — Track `(depth, parent)` for both x and y via BFS.

```java
// Cousins: same depth AND different parents
return depthX == depthY && parentX != parentY;
```

---

## C4/C5. BFS Serialization/Deserialization ⭐⭐
```java
// Serialize: BFS, write "X" for null
// Deserialize: BFS, read values and re-link children
// This produces unique encoding (unlike DFS)
```

---

## C7/C9. Mirror/Invert Binary Tree ⭐
**LeetCode 226** — For each node in BFS: swap left and right children.

```java
TreeNode tmp = node.left; node.left = node.right; node.right = tmp;
```

---

## C8. Symmetric Tree ⭐
**LeetCode 101** — BFS with paired queue: always enqueue `(left.left, right.right)` and `(left.right, right.left)`.

---

## C10. Merge Two Binary Trees ⭐
**LeetCode 617** — BFS with paired `(t1, t2)` nodes. Add values, handle null cases.

---

# PATH & SUM (P1–P10)

## P1. Binary Tree Path Sum ⭐
**LeetCode 112** — BFS with two parallel queues: nodes and running sums.

```java
Queue<Integer> sumQueue = new LinkedList<>();
sumQueue.offer(root.val);
// When enqueuing children: sumQueue.offer(currentSum + child.val)
```

---

## P2. Path Sum II ⭐⭐
**LeetCode 113** — BFS with path-tracking queue (expensive memory).

Alternative: DFS backtracking is more efficient for path collection.

---

## P3. Sum of Left Leaves ⭐
**LeetCode 404** — BFS with parent tracking. A leaf is "left" if `parent.left == node`.

---

## P6. Deepest Leaves Sum ⭐⭐
**LeetCode 1302** — At end of BFS, `sum` variable holds the last (deepest) level's leaf sum.

---

# BST BFS (B1–B10)

## B3. Min Distance Between BST Nodes ⭐
**LeetCode 530** — Inorder traversal gives sorted sequence; min diff between consecutive values.

---

## B4. Kth Smallest in BST ⭐⭐
**LeetCode 230** — Inorder traversal (sorted), return kth element.

---

## B8. Validate BST ⭐⭐
**LeetCode 98** — BFS with range `[min, max]` per node.

```java
Queue<long[]> rangeQueue; // [min, max] bounds for each node
// Left child: range [min, node.val]
// Right child: range [node.val, max]
```

---

# N-ARY TREE BFS (N1–N10)

## N1. N-ary Tree Level Order ⭐
**LeetCode 429** — Same BFS, but enqueue ALL children.

```java
for (Node child : node.children) queue.offer(child);
```

---

## N2. Maximum Depth of N-ary Tree ⭐
**LeetCode 559** — Count BFS levels.

---

## N8. Count Leaves
Leaf = `node.children.isEmpty()`. Count during BFS.

---

## N9. Width of N-ary Tree
`maxWidth = Math.max(maxWidth, queue.size())` before processing each level.

---

# GRID & GRAPH BFS (G1–G10)

## G1. Min Time to Burn Tree ⭐⭐
1. Build parent map via DFS/BFS
2. BFS from target (treat as undirected: explore left, right, parent)
3. Return BFS level count

---

## G3. Nodes at Distance K ⭐⭐
**LeetCode 863** — Same as G1 setup:
1. Build parent map
2. BFS from target with `Set<visited>`
3. When `distance == k`, return all nodes in queue

---

## G7. Nearest Leaf Node
Parent map + BFS until first leaf found.

---

# LEETCODE QUICK REFERENCE

| # | Problem | Key Technique | Time | Space |
|---|---------|--------------|------|-------|
| 102 | Level Order | Queue+size | O(n) | O(w) |
| 103 | Zigzag | Deque+toggle | O(n) | O(w) |
| 107 | Level Order II | addFirst | O(n) | O(n) |
| 199 | Right Side View | Last per level | O(n) | O(w) |
| 515 | Largest per Row | Max per level | O(n) | O(w) |
| 637 | Average Levels | Sum/count | O(n) | O(w) |
| 116 | Connect Ptrs | prev pointer | O(n) | O(1)* |
| 117 | Connect Ptrs II | Queue | O(n) | O(w) |
| 429 | N-ary Level | All children | O(n) | O(w) |
| 993 | Cousins | depth+parent | O(n) | O(w) |
| 310 | Min Height Trees | Topo sort | O(n) | O(n) |
| 863 | Distance K | Parent+BFS | O(n) | O(n) |
| 102+107 | Clone Tree | Parallel BFS | O(n) | O(n) |

\*O(1) extra space possible for perfect binary tree using next pointers

---

# INTERVIEW PROBLEMS (IN1–IN10)

| # | Scenario | Maps To |
|---|----------|---------|
| IN1 | Employee hierarchy | N-ary tree level order |
| IN2 | Organization chart | N-ary depth + level count |
| IN3 | Folder structure | N-ary level traversal |
| IN4 | Web crawler | BFS on URL graph |
| IN5 | Social network levels | BFS shortest path |
| IN6 | Game skill tree | BFS on dependency tree |
| IN7 | File system tree | N-ary BFS |
| IN8 | Family tree levels | Level order with generation labels |
| IN9 | DOM traversal | N-ary BFS (HTML tree) |
| IN10 | Recommendation system | Multi-source BFS from liked items |

---

# Pattern Selection Guide

```
Binary Tree → list of levels?          → Standard BFS (Template 1)
Binary Tree → reverse levels?          → addFirst per level
Binary Tree → alternating direction?   → Deque + leftToRight toggle (Zigzag)
Binary Tree → one node per level?      → first (left view) or last (right view)
Binary Tree → depth/height?            → Count BFS levels
Binary Tree → minimum depth?           → BFS: stop at FIRST leaf (not deepest!)
Binary Tree → connect siblings?        → BFS + prev pointer
Binary Tree → column grouping?         → BFS + column index tracking
Binary Tree → specific node + distance? → Parent map + BFS from node
Binary Tree → burn/infection spread?   → Parent map + multi-source BFS
N-ary Tree → any traversal?            → Queue + for(child : node.children)
BST → sorted order?                    → Inorder (DFS, not BFS usually)
BST → validate?                        → BFS + range [min,max] per node
```

---

# Key Invariants

1. **`size = queue.size()` before the inner loop** — this is the number of nodes at the current level
2. **Enqueue children BEFORE advancing** — ensures next level is fully populated
3. **BFS gives shortest path** — use for minimum depth, distance problems
4. **Parent map unlocks Distance K** — convert tree to undirected graph
5. **Deque enables zigzag** — `addFirst` vs `addLast` based on level parity

*100 Tree BFS Problems — Complete Java Solutions | O(n) Time | O(w) Space*
