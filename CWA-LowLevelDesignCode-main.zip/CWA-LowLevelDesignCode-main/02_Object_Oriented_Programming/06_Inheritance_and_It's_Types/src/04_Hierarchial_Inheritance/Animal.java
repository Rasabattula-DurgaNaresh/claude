package Hierarchial_Inheritance;

public class Animal {
    void eat() {
        System.out.println("This animal eats food.");
    }
}
