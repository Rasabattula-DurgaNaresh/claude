package com.example.batch.reader;

import com.example.batch.model.SalesRecord;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Integration tests for SalesItemReader — reads the actual CSV and validates records.
 */
@SpringBootTest
@ActiveProfiles("test")
@DisplayName("SalesItemReader Tests")
class SalesItemReaderTest {

    @Autowired
    private SalesItemReader salesItemReader;

    @Test
    @DisplayName("Reads all 20 records from the CSV file")
    void shouldReadAllRecords() throws Exception {
        FlatFileItemReader<SalesRecord> reader = salesItemReader.salesCsvReader();
        reader.open(new ExecutionContext());

        List<SalesRecord> records = new ArrayList<>();
        SalesRecord record;
        while ((record = reader.read()) != null) {
            records.add(record);
        }
        reader.close();

        assertThat(records).hasSize(20);
    }

    @Test
    @DisplayName("First record maps correctly to SalesRecord fields")
    void shouldMapFirstRecordCorrectly() throws Exception {
        FlatFileItemReader<SalesRecord> reader = salesItemReader.salesCsvReader();
        reader.open(new ExecutionContext());

        SalesRecord first = reader.read();
        reader.close();

        assertThat(first).isNotNull();
        assertThat(first.getOrderId()).isEqualTo(1001L);
        assertThat(first.getCustomerName()).isEqualTo("Alice Johnson");
        assertThat(first.getProduct()).isEqualTo("Laptop Pro");
        assertThat(first.getCategory()).isEqualTo("Electronics");
        assertThat(first.getQuantity()).isEqualTo(2);
        assertThat(first.getRegion()).isEqualTo("North");
        assertThat(first.getStatus()).isEqualTo("COMPLETED");
    }

    @Test
    @DisplayName("unitPrice and orderDate are correctly parsed")
    void shouldParseNumericAndDateFields() throws Exception {
        FlatFileItemReader<SalesRecord> reader = salesItemReader.salesCsvReader();
        reader.open(new ExecutionContext());

        SalesRecord first = reader.read();
        reader.close();

        assertThat(first.getUnitPrice()).isEqualByComparingTo("1299.99");
        assertThat(first.getOrderDate().getYear()).isEqualTo(2024);
        assertThat(first.getOrderDate().getMonthValue()).isEqualTo(1);
        assertThat(first.getOrderDate().getDayOfMonth()).isEqualTo(5);
    }

    @Test
    @DisplayName("Contains exactly 1 CANCELLED record in the CSV")
    void shouldContainOneCancelledRecord() throws Exception {
        FlatFileItemReader<SalesRecord> reader = salesItemReader.salesCsvReader();
        reader.open(new ExecutionContext());

        long cancelled = 0;
        SalesRecord record;
        while ((record = reader.read()) != null) {
            if ("CANCELLED".equals(record.getStatus())) cancelled++;
        }
        reader.close();

        assertThat(cancelled).isEqualTo(1);
    }
}
