package com.example.batch.job;

import com.example.batch.model.ProcessedSale;
import com.example.batch.model.ProcessedSaleRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.batch.core.*;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.batch.test.JobRepositoryTestUtils;
import org.springframework.batch.test.context.SpringBatchTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Integration test: launches the full salesReportJob and verifies
 * that records are correctly persisted and skipped.
 */
@SpringBatchTest
@SpringBootTest
@ActiveProfiles("test")
@DisplayName("Sales Report Job — Integration Tests")
class SalesJobIntegrationTest {

    @Autowired private JobLauncherTestUtils jobLauncherTestUtils;
    @Autowired private JobRepositoryTestUtils jobRepositoryTestUtils;
    @Autowired private ProcessedSaleRepository repository;

    @BeforeEach
    void cleanUp() {
        jobRepositoryTestUtils.removeJobExecutions();
        repository.deleteAll();
    }

    @Test
    @DisplayName("Job completes with COMPLETED status")
    void jobShouldComplete() throws Exception {
        JobExecution execution = jobLauncherTestUtils.launchJob(
                new JobParametersBuilder()
                        .addLong("run.id", System.currentTimeMillis())
                        .toJobParameters()
        );
        assertThat(execution.getStatus()).isEqualTo(BatchStatus.COMPLETED);
    }

    @Test
    @DisplayName("All non-CANCELLED records are persisted to the database")
    void shouldPersistNonCancelledRecords() throws Exception {
        jobLauncherTestUtils.launchJob(
                new JobParametersBuilder()
                        .addLong("run.id", System.currentTimeMillis())
                        .toJobParameters()
        );

        // CSV has 20 records, 1 is CANCELLED → expect 19 persisted
        List<ProcessedSale> all = repository.findAll();
        assertThat(all).hasSize(19);
    }

    @Test
    @DisplayName("CANCELLED orders are not in the database")
    void shouldNotPersistCancelledOrders() throws Exception {
        jobLauncherTestUtils.launchJob(
                new JobParametersBuilder()
                        .addLong("run.id", System.currentTimeMillis())
                        .toJobParameters()
        );

        long cancelledCount = repository.countByStatus("CANCELLED");
        assertThat(cancelledCount).isZero();
    }

    @Test
    @DisplayName("Completed orders have positive finalAmount after discount")
    void completedOrdersShouldHavePositiveFinalAmount() throws Exception {
        jobLauncherTestUtils.launchJob(
                new JobParametersBuilder()
                        .addLong("run.id", System.currentTimeMillis())
                        .toJobParameters()
        );

        List<ProcessedSale> completed = repository.findByStatus("COMPLETED");
        assertThat(completed).isNotEmpty();
        completed.forEach(sale ->
                assertThat(sale.getFinalAmount()).isPositive()
        );
    }

    @Test
    @DisplayName("Step execution metrics are recorded correctly")
    void stepMetricsShouldBeCorrect() throws Exception {
        JobExecution execution = jobLauncherTestUtils.launchJob(
                new JobParametersBuilder()
                        .addLong("run.id", System.currentTimeMillis())
                        .toJobParameters()
        );

        StepExecution stepExecution = execution.getStepExecutions().iterator().next();
        assertThat(stepExecution.getReadCount()).isEqualTo(20);   // all CSV rows
        assertThat(stepExecution.getWriteCount()).isEqualTo(19);  // minus 1 cancelled
        assertThat(stepExecution.getFilterCount()).isEqualTo(1);  // 1 cancelled filtered
        assertThat(stepExecution.getStatus()).isEqualTo(BatchStatus.COMPLETED);
    }

    @Test
    @DisplayName("Records have processedAt timestamp set")
    void recordsShouldHaveProcessedTimestamp() throws Exception {
        jobLauncherTestUtils.launchJob(
                new JobParametersBuilder()
                        .addLong("run.id", System.currentTimeMillis())
                        .toJobParameters()
        );

        repository.findAll().forEach(sale ->
                assertThat(sale.getProcessedAt()).isNotNull()
        );
    }
}
