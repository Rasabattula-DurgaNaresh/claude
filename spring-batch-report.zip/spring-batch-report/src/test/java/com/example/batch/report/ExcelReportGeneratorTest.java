package com.example.batch.report;

import com.example.batch.model.ProcessedSale;
import com.example.batch.model.ProcessedSaleRepository;
import com.example.batch.model.SalesSummary;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.FileInputStream;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

/**
 * Unit tests for ExcelReportGenerator.
 * Verifies sheet names, headers, and data rows in the generated workbook.
 */
@DisplayName("ExcelReportGenerator Tests")
class ExcelReportGeneratorTest {

    @TempDir
    Path tempDir;

    private ProcessedSaleRepository repository;
    private ExcelReportGenerator generator;

    @BeforeEach
    void setUp() throws Exception {
        repository = mock(ProcessedSaleRepository.class);
        generator = new ExcelReportGenerator(repository);

        var field = ExcelReportGenerator.class.getDeclaredField("excelOutputPath");
        field.setAccessible(true);
        field.set(generator, tempDir.resolve("report.xlsx").toString());
    }

    private ProcessedSale buildSale(long id, String status, String category, String region) {
        return ProcessedSale.builder()
                .id(id)
                .orderId(id)
                .customerName("Customer " + id)
                .product("Product " + id)
                .category(category)
                .quantity(2)
                .unitPrice(new BigDecimal("100.00"))
                .totalAmount(new BigDecimal("200.00"))
                .discountApplied(new BigDecimal("10.00"))
                .finalAmount(new BigDecimal("190.00"))
                .orderDate(LocalDate.of(2024, 1, 15))
                .region(region)
                .status(status)
                .processedAt(LocalDateTime.now())
                .build();
    }

    private SalesSummary buildSummary(String category, String region) {
        return new SalesSummary(category, region, 5L,
                new BigDecimal("1000.00"), new BigDecimal("50.00"),
                new BigDecimal("950.00"), new BigDecimal("190.00"));
    }

    @Test
    @DisplayName("Excel file is created at the configured path")
    void shouldCreateExcelFile() throws Exception {
        when(repository.findAll()).thenReturn(List.of(buildSale(1L, "COMPLETED", "Electronics", "North")));
        when(repository.findSalesSummaryByCategoryAndRegion()).thenReturn(List.of());

        generator.generateReport();

        Path reportPath = tempDir.resolve("report.xlsx");
        assertThat(reportPath).exists();
        assertThat(reportPath.toFile().length()).isGreaterThan(0);
    }

    @Test
    @DisplayName("Workbook contains exactly 3 sheets")
    void shouldCreateThreeSheets() throws Exception {
        when(repository.findAll()).thenReturn(List.of(buildSale(1L, "COMPLETED", "Electronics", "North")));
        when(repository.findSalesSummaryByCategoryAndRegion()).thenReturn(List.of());

        generator.generateReport();

        try (var fis = new FileInputStream(tempDir.resolve("report.xlsx").toFile());
             var wb = new XSSFWorkbook(fis)) {
            assertThat(wb.getNumberOfSheets()).isEqualTo(3);
            assertThat(wb.getSheetName(0)).isEqualTo("Executive Summary");
            assertThat(wb.getSheetName(1)).isEqualTo("By Category & Region");
            assertThat(wb.getSheetName(2)).isEqualTo("All Processed Sales");
        }
    }

    @Test
    @DisplayName("Category & Region sheet has correct headers")
    void categorySheetShouldHaveCorrectHeaders() throws Exception {
        when(repository.findAll()).thenReturn(List.of());
        when(repository.findSalesSummaryByCategoryAndRegion())
                .thenReturn(List.of(buildSummary("Electronics", "North")));

        generator.generateReport();

        try (var fis = new FileInputStream(tempDir.resolve("report.xlsx").toFile());
             var wb = new XSSFWorkbook(fis)) {
            var sheet = wb.getSheet("By Category & Region");
            var headerRow = sheet.getRow(0);
            assertThat(headerRow.getCell(0).getStringCellValue()).isEqualTo("Category");
            assertThat(headerRow.getCell(1).getStringCellValue()).isEqualTo("Region");
            assertThat(headerRow.getCell(2).getStringCellValue()).isEqualTo("Total Orders");
        }
    }

    @Test
    @DisplayName("Raw data sheet contains data rows for all sales")
    void rawDataSheetShouldContainAllSales() throws Exception {
        List<ProcessedSale> sales = List.of(
                buildSale(1L, "COMPLETED", "Electronics", "North"),
                buildSale(2L, "REFUNDED",  "Furniture",   "South")
        );
        when(repository.findAll()).thenReturn(sales);
        when(repository.findSalesSummaryByCategoryAndRegion()).thenReturn(List.of());

        generator.generateReport();

        try (var fis = new FileInputStream(tempDir.resolve("report.xlsx").toFile());
             var wb = new XSSFWorkbook(fis)) {
            var sheet = wb.getSheet("All Processed Sales");
            // row 0 = header, rows 1..N = data
            assertThat(sheet.getLastRowNum()).isEqualTo(2); // header + 2 data rows
        }
    }

    @Test
    @DisplayName("Empty sales list still generates a valid Excel file")
    void shouldHandleEmptySalesList() throws Exception {
        when(repository.findAll()).thenReturn(List.of());
        when(repository.findSalesSummaryByCategoryAndRegion()).thenReturn(List.of());

        generator.generateReport();

        assertThat(tempDir.resolve("report.xlsx")).exists();
    }
}
