package com.example.batch.writer;

import com.example.batch.model.ProcessedSale;
import com.example.batch.model.ProcessedSaleRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.ArgumentCaptor;
import org.springframework.batch.item.Chunk;

import java.io.File;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

/**
 * Unit tests for SalesItemWriter — verifies DB persistence and CSV output.
 */
@DisplayName("SalesItemWriter Tests")
class SalesItemWriterTest {

    @TempDir
    Path tempDir;

    private ProcessedSaleRepository repository;
    private SalesItemWriter writer;

    @BeforeEach
    void setUp() throws Exception {
        repository = mock(ProcessedSaleRepository.class);
        writer = new SalesItemWriter(repository);

        // Inject temp CSV path via reflection
        var field = SalesItemWriter.class.getDeclaredField("csvOutputPath");
        field.setAccessible(true);
        field.set(writer, tempDir.resolve("output.csv").toString());
    }

    private ProcessedSale buildSale(long orderId) {
        return ProcessedSale.builder()
                .orderId(orderId)
                .customerName("Test User")
                .product("Widget")
                .category("Electronics")
                .quantity(2)
                .unitPrice(new BigDecimal("49.99"))
                .totalAmount(new BigDecimal("99.98"))
                .discountApplied(new BigDecimal("5.00"))
                .finalAmount(new BigDecimal("94.98"))
                .orderDate(LocalDate.of(2024, 1, 10))
                .region("North")
                .status("COMPLETED")
                .processedAt(LocalDateTime.now())
                .build();
    }

    @Test
    @DisplayName("Persists all items to the repository")
    void shouldSaveAllItemsToRepository() throws Exception {
        List<ProcessedSale> sales = List.of(buildSale(1001L), buildSale(1002L));
        writer.write(new Chunk<>(sales));

        @SuppressWarnings("unchecked")
        ArgumentCaptor<List<ProcessedSale>> captor = ArgumentCaptor.forClass(List.class);
        verify(repository, times(1)).saveAll(captor.capture());
        assertThat(captor.getValue()).hasSize(2);
    }

    @Test
    @DisplayName("Creates CSV file with header and data rows")
    void shouldWriteCsvWithHeaderAndData() throws Exception {
        writer.write(new Chunk<>(List.of(buildSale(1001L))));

        Path csvPath = tempDir.resolve("output.csv");
        assertThat(csvPath).exists();

        List<String> lines = Files.readAllLines(csvPath);
        assertThat(lines).hasSizeGreaterThanOrEqualTo(2);
        assertThat(lines.get(0)).contains("orderId", "customerName", "totalAmount");
        assertThat(lines.get(1)).contains("1001");
    }

    @Test
    @DisplayName("Appends multiple chunks to the same CSV file")
    void shouldAppendMultipleChunks() throws Exception {
        writer.write(new Chunk<>(List.of(buildSale(1001L))));
        writer.write(new Chunk<>(List.of(buildSale(1002L))));

        Path csvPath = tempDir.resolve("output.csv");
        List<String> lines = Files.readAllLines(csvPath);

        // 1 header + 2 data rows
        assertThat(lines).hasSize(3);
    }
}
