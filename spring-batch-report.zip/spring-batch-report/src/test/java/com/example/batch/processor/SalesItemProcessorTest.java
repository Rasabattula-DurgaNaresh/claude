package com.example.batch.processor;

import com.example.batch.model.ProcessedSale;
import com.example.batch.model.SalesRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for SalesItemProcessor.
 * Tests discount logic, cancellation filtering, and field mapping.
 */
@DisplayName("SalesItemProcessor Tests")
class SalesItemProcessorTest {

    private SalesItemProcessor processor;

    @BeforeEach
    void setUp() {
        processor = new SalesItemProcessor();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private SalesRecord buildRecord(String status, String category, int qty, double price) {
        return SalesRecord.builder()
                .orderId(1001L)
                .customerName("Test Customer")
                .product("Test Product")
                .category(category)
                .quantity(qty)
                .unitPrice(new BigDecimal(price))
                .orderDate(LocalDate.of(2024, 1, 15))
                .region("North")
                .status(status)
                .build();
    }

    // ── Tests ─────────────────────────────────────────────────────────────────

    @Nested
    @DisplayName("Cancelled Order Handling")
    class CancelledOrders {

        @Test
        @DisplayName("Returns null for CANCELLED orders — Spring Batch will skip them")
        void shouldReturnNullForCancelledOrders() throws Exception {
            SalesRecord record = buildRecord("CANCELLED", "Electronics", 2, 100.0);
            ProcessedSale result = processor.process(record);
            assertThat(result).isNull();
        }

        @Test
        @DisplayName("Case-insensitive: cancelled (lowercase) is also skipped")
        void shouldSkipCancelledCaseInsensitive() throws Exception {
            SalesRecord record = buildRecord("cancelled", "Electronics", 1, 50.0);
            assertThat(processor.process(record)).isNull();
        }
    }

    @Nested
    @DisplayName("Amount Calculations")
    class AmountCalculations {

        @Test
        @DisplayName("Total amount = quantity × unitPrice")
        void shouldCalculateTotalAmount() throws Exception {
            SalesRecord record = buildRecord("COMPLETED", "Office", 5, 20.00);
            ProcessedSale result = processor.process(record);

            assertThat(result).isNotNull();
            assertThat(result.getTotalAmount()).isEqualByComparingTo("100.00");
        }

        @Test
        @DisplayName("Electronics gets 5% discount")
        void shouldApplyElectronicsDiscount() throws Exception {
            SalesRecord record = buildRecord("COMPLETED", "Electronics", 1, 100.00);
            ProcessedSale result = processor.process(record);

            assertThat(result.getDiscountApplied()).isEqualByComparingTo("5.00");
            assertThat(result.getFinalAmount()).isEqualByComparingTo("95.00");
        }

        @Test
        @DisplayName("Furniture gets 10% discount")
        void shouldApplyFurnitureDiscount() throws Exception {
            SalesRecord record = buildRecord("COMPLETED", "Furniture", 1, 200.00);
            ProcessedSale result = processor.process(record);

            assertThat(result.getDiscountApplied()).isEqualByComparingTo("20.00");
            assertThat(result.getFinalAmount()).isEqualByComparingTo("180.00");
        }

        @Test
        @DisplayName("Unknown category gets 2% default discount")
        void shouldApplyDefaultDiscountForUnknownCategory() throws Exception {
            SalesRecord record = buildRecord("COMPLETED", "UNKNOWN", 1, 100.00);
            ProcessedSale result = processor.process(record);

            assertThat(result.getDiscountApplied()).isEqualByComparingTo("2.00");
            assertThat(result.getFinalAmount()).isEqualByComparingTo("98.00");
        }

        @ParameterizedTest(name = "{0} → {1}% discount")
        @CsvSource({
            "ELECTRONICS, 0.05",
            "FURNITURE,   0.10",
            "STATIONERY,  0.03",
            "OFFICE,      0.02",
            "OTHER,       0.02"
        })
        @DisplayName("Discount rates by category")
        void shouldReturnCorrectDiscountRates(String category, BigDecimal expectedRate) {
            assertThat(processor.getDiscountRate(category))
                    .isEqualByComparingTo(expectedRate);
        }
    }

    @Nested
    @DisplayName("Field Mapping")
    class FieldMapping {

        @Test
        @DisplayName("All fields are correctly mapped from SalesRecord to ProcessedSale")
        void shouldMapAllFieldsCorrectly() throws Exception {
            SalesRecord record = buildRecord("COMPLETED", "Electronics", 3, 150.00);
            ProcessedSale result = processor.process(record);

            assertThat(result).isNotNull();
            assertThat(result.getOrderId()).isEqualTo(1001L);
            assertThat(result.getCustomerName()).isEqualTo("Test Customer");
            assertThat(result.getProduct()).isEqualTo("Test Product");
            assertThat(result.getCategory()).isEqualTo("Electronics");
            assertThat(result.getQuantity()).isEqualTo(3);
            assertThat(result.getRegion()).isEqualTo("North");
            assertThat(result.getStatus()).isEqualTo("COMPLETED");
            assertThat(result.getProcessedAt()).isNotNull();
        }

        @Test
        @DisplayName("REFUNDED orders are processed (not skipped)")
        void shouldProcessRefundedOrders() throws Exception {
            SalesRecord record = buildRecord("REFUNDED", "Electronics", 2, 100.00);
            ProcessedSale result = processor.process(record);
            assertThat(result).isNotNull();
            assertThat(result.getStatus()).isEqualTo("REFUNDED");
        }
    }
}
