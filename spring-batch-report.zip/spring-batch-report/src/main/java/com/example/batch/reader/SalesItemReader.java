package com.example.batch.reader;

import com.example.batch.model.SalesRecord;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.support.DefaultConversionService;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Reads SalesRecord entries from a CSV file.
 * Skips the header row and maps each line to a SalesRecord.
 */
@Slf4j
@Configuration
public class SalesItemReader {

    @Value("${batch.input.file}")
    private Resource inputFile;

    @Bean
    public FlatFileItemReader<SalesRecord> salesCsvReader() {
        log.info("Initializing SalesItemReader from: {}", inputFile);

        BeanWrapperFieldSetMapper<SalesRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<>() {{
            setTargetType(SalesRecord.class);
            setConversionService(conversionService());
        }};

        return new FlatFileItemReaderBuilder<SalesRecord>()
                .name("salesCsvReader")
                .resource(inputFile)
                .delimited()
                .names("orderId", "customerName", "product", "category",
                       "quantity", "unitPrice", "orderDate", "region", "status")
                .linesToSkip(1)   // skip CSV header
                .fieldSetMapper(fieldSetMapper)
                .build();
    }

    /**
     * Custom conversion service to handle LocalDate and BigDecimal parsing from CSV strings.
     */
    private ConversionService conversionService() {
        DefaultConversionService service = new DefaultConversionService();
        DefaultConversionService.addDefaultConverters(service);

        // LocalDate converter
        service.addConverter(String.class, LocalDate.class,
                source -> LocalDate.parse(source.trim(), DateTimeFormatter.ofPattern("yyyy-MM-dd")));

        // BigDecimal converter
        service.addConverter(String.class, BigDecimal.class,
                source -> new BigDecimal(source.trim()));

        return service;
    }
}
