package com.example.batch.report;

import com.example.batch.model.ProcessedSale;
import com.example.batch.model.ProcessedSaleRepository;
import com.example.batch.model.SalesSummary;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Generates a multi-sheet Excel report after batch processing:
 *  Sheet 1 — Executive Summary (KPIs)
 *  Sheet 2 — Sales by Category & Region
 *  Sheet 3 — Full Processed Data
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ExcelReportGenerator {

    private final ProcessedSaleRepository repository;

    @Value("${report.excel.output}")
    private String excelOutputPath;

    public void generateReport() throws IOException {
        log.info("Generating Excel report...");

        Path outputPath = Paths.get(excelOutputPath);
        Files.createDirectories(outputPath.getParent());

        List<ProcessedSale> allSales = repository.findAll();
        List<SalesSummary> summaries = repository.findSalesSummaryByCategoryAndRegion();

        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            createSummarySheet(workbook, allSales);
            createCategoryRegionSheet(workbook, summaries);
            createRawDataSheet(workbook, allSales);

            try (FileOutputStream fos = new FileOutputStream(outputPath.toFile())) {
                workbook.write(fos);
            }
        }
        log.info("Excel report saved to: {}", excelOutputPath);
    }

    // ── Sheet 1: Executive Summary ────────────────────────────────────────────
    private void createSummarySheet(XSSFWorkbook wb, List<ProcessedSale> sales) {
        XSSFSheet sheet = wb.createSheet("Executive Summary");
        sheet.setColumnWidth(0, 7000);
        sheet.setColumnWidth(1, 5000);

        CellStyle titleStyle = createTitleStyle(wb);
        CellStyle headerStyle = createHeaderStyle(wb);
        CellStyle kpiStyle    = createKpiStyle(wb);
        CellStyle labelStyle  = createLabelStyle(wb);

        // Title
        Row titleRow = sheet.createRow(0);
        Cell titleCell = titleRow.createCell(0);
        titleCell.setCellValue("Sales Batch Processing — Executive Summary");
        titleCell.setCellStyle(titleStyle);
        sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 1));

        // Generated at
        Row dateRow = sheet.createRow(1);
        dateRow.createCell(0).setCellValue("Generated: " +
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm")));

        sheet.createRow(2); // spacer

        // KPI rows
        List<ProcessedSale> completed = sales.stream()
                .filter(s -> "COMPLETED".equalsIgnoreCase(s.getStatus())).toList();
        List<ProcessedSale> refunded  = sales.stream()
                .filter(s -> "REFUNDED".equalsIgnoreCase(s.getStatus())).toList();

        BigDecimal totalRevenue  = completed.stream().map(ProcessedSale::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal totalDiscount = completed.stream().map(ProcessedSale::getDiscountApplied)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal netRevenue    = completed.stream().map(ProcessedSale::getFinalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal avgOrder      = completed.isEmpty() ? BigDecimal.ZERO :
                netRevenue.divide(BigDecimal.valueOf(completed.size()), 2, RoundingMode.HALF_UP);

        Object[][] kpis = {
            {"KPI", "Value"},
            {"Total Orders Processed", sales.size()},
            {"Completed Orders", completed.size()},
            {"Refunded Orders", refunded.size()},
            {"Cancelled Orders (skipped)", sales.size() - completed.size() - refunded.size()},
            {"Gross Revenue ($)", totalRevenue.toPlainString()},
            {"Total Discounts ($)", totalDiscount.toPlainString()},
            {"Net Revenue ($)", netRevenue.toPlainString()},
            {"Average Order Value ($)", avgOrder.toPlainString()},
        };

        int rowNum = 3;
        for (Object[] kpi : kpis) {
            Row row = sheet.createRow(rowNum++);
            Cell label = row.createCell(0);
            Cell value = row.createCell(1);
            label.setCellValue(kpi[0].toString());
            value.setCellValue(kpi[1].toString());
            if (rowNum == 4) { // header row
                label.setCellStyle(headerStyle);
                value.setCellStyle(headerStyle);
            } else {
                label.setCellStyle(labelStyle);
                value.setCellStyle(kpiStyle);
            }
        }
    }

    // ── Sheet 2: Category & Region Breakdown ─────────────────────────────────
    private void createCategoryRegionSheet(XSSFWorkbook wb, List<SalesSummary> summaries) {
        XSSFSheet sheet = wb.createSheet("By Category & Region");
        int[] widths = {5000, 4000, 4000, 6000, 6000, 6000, 6000};
        for (int i = 0; i < widths.length; i++) sheet.setColumnWidth(i, widths[i]);

        CellStyle headerStyle = createHeaderStyle(wb);
        CellStyle dataStyle   = createDataStyle(wb);
        CellStyle moneyStyle  = createMoneyStyle(wb);

        String[] headers = {"Category","Region","Total Orders","Gross Revenue ($)",
                            "Discount ($)","Net Revenue ($)","Avg Order Value ($)"};
        Row hRow = sheet.createRow(0);
        for (int i = 0; i < headers.length; i++) {
            Cell c = hRow.createCell(i);
            c.setCellValue(headers[i]);
            c.setCellStyle(headerStyle);
        }

        int rowNum = 1;
        for (SalesSummary s : summaries) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(s.getCategory());
            row.createCell(1).setCellValue(s.getRegion());
            row.createCell(2).setCellValue(s.getTotalOrders());
            row.createCell(3).setCellValue(s.getTotalRevenue().doubleValue());
            row.createCell(4).setCellValue(s.getTotalDiscount().doubleValue());
            row.createCell(5).setCellValue(s.getNetRevenue().doubleValue());
            row.createCell(6).setCellValue(s.getAverageOrderValue().setScale(2, RoundingMode.HALF_UP).doubleValue());

            for (int i = 0; i < 7; i++) {
                row.getCell(i).setCellStyle(i >= 3 ? moneyStyle : dataStyle);
            }
        }
    }

    // ── Sheet 3: Raw Processed Data ───────────────────────────────────────────
    private void createRawDataSheet(XSSFWorkbook wb, List<ProcessedSale> sales) {
        XSSFSheet sheet = wb.createSheet("All Processed Sales");
        CellStyle headerStyle = createHeaderStyle(wb);
        CellStyle dataStyle   = createDataStyle(wb);

        String[] headers = {"Order ID","Customer","Product","Category","Qty",
                            "Unit Price","Total","Discount","Final","Date","Region","Status"};
        Row hRow = sheet.createRow(0);
        for (int i = 0; i < headers.length; i++) {
            Cell c = hRow.createCell(i);
            c.setCellValue(headers[i]);
            c.setCellStyle(headerStyle);
            sheet.setColumnWidth(i, 4200);
        }

        int rowNum = 1;
        for (ProcessedSale s : sales) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(s.getOrderId());
            row.createCell(1).setCellValue(s.getCustomerName());
            row.createCell(2).setCellValue(s.getProduct());
            row.createCell(3).setCellValue(s.getCategory());
            row.createCell(4).setCellValue(s.getQuantity());
            row.createCell(5).setCellValue(s.getUnitPrice().doubleValue());
            row.createCell(6).setCellValue(s.getTotalAmount().doubleValue());
            row.createCell(7).setCellValue(s.getDiscountApplied().doubleValue());
            row.createCell(8).setCellValue(s.getFinalAmount().doubleValue());
            row.createCell(9).setCellValue(s.getOrderDate().toString());
            row.createCell(10).setCellValue(s.getRegion());
            row.createCell(11).setCellValue(s.getStatus());
            for (int i = 0; i < 12; i++) row.getCell(i).setCellStyle(dataStyle);
        }
    }

    // ── Style helpers ─────────────────────────────────────────────────────────
    private CellStyle createTitleStyle(XSSFWorkbook wb) {
        CellStyle s = wb.createCellStyle();
        Font f = wb.createFont(); f.setBold(true); f.setFontHeightInPoints((short)14);
        s.setFont(f);
        return s;
    }

    private CellStyle createHeaderStyle(XSSFWorkbook wb) {
        CellStyle s = wb.createCellStyle();
        Font f = wb.createFont(); f.setBold(true); f.setColor(IndexedColors.WHITE.getIndex());
        s.setFont(f);
        s.setFillForegroundColor(IndexedColors.DARK_BLUE.getIndex());
        s.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        s.setAlignment(HorizontalAlignment.CENTER);
        setBorder(s);
        return s;
    }

    private CellStyle createKpiStyle(XSSFWorkbook wb) {
        CellStyle s = wb.createCellStyle();
        Font f = wb.createFont(); f.setBold(true);
        s.setFont(f);
        s.setFillForegroundColor(IndexedColors.LIGHT_YELLOW.getIndex());
        s.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        setBorder(s);
        return s;
    }

    private CellStyle createLabelStyle(XSSFWorkbook wb) {
        CellStyle s = wb.createCellStyle();
        setBorder(s);
        return s;
    }

    private CellStyle createDataStyle(XSSFWorkbook wb) {
        CellStyle s = wb.createCellStyle();
        setBorder(s);
        return s;
    }

    private CellStyle createMoneyStyle(XSSFWorkbook wb) {
        CellStyle s = wb.createCellStyle();
        setBorder(s);
        DataFormat df = wb.createDataFormat();
        s.setDataFormat(df.getFormat("#,##0.00"));
        return s;
    }

    private void setBorder(CellStyle s) {
        s.setBorderBottom(BorderStyle.THIN);
        s.setBorderTop(BorderStyle.THIN);
        s.setBorderLeft(BorderStyle.THIN);
        s.setBorderRight(BorderStyle.THIN);
    }
}
