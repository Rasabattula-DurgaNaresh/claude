package com.example.batch.model;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * JPA entity persisted after processing each SalesRecord.
 */
@Entity
@Table(name = "processed_sales")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProcessedSale {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "order_id", unique = true, nullable = false)
    private Long orderId;

    @Column(name = "customer_name")
    private String customerName;

    private String product;
    private String category;
    private Integer quantity;

    @Column(name = "unit_price", precision = 10, scale = 2)
    private BigDecimal unitPrice;

    @Column(name = "total_amount", precision = 10, scale = 2)
    private BigDecimal totalAmount;

    @Column(name = "order_date")
    private LocalDate orderDate;

    private String region;
    private String status;

    @Column(name = "processed_at")
    private LocalDateTime processedAt;

    @Column(name = "discount_applied", precision = 5, scale = 2)
    private BigDecimal discountApplied;

    @Column(name = "final_amount", precision = 10, scale = 2)
    private BigDecimal finalAmount;
}
