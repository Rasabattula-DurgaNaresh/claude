package com.example.batch.model;

import lombok.*;
import java.math.BigDecimal;

/**
 * Aggregated summary used for report generation.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SalesSummary {
    private String category;
    private String region;
    private long totalOrders;
    private BigDecimal totalRevenue;
    private BigDecimal totalDiscount;
    private BigDecimal netRevenue;
    private BigDecimal averageOrderValue;
}
