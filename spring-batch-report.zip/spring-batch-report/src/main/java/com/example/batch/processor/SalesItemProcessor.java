package com.example.batch.processor;

import com.example.batch.model.ProcessedSale;
import com.example.batch.model.SalesRecord;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;

/**
 * Processes a raw SalesRecord into a ProcessedSale:
 *  - Validates required fields
 *  - Computes totalAmount = quantity * unitPrice
 *  - Applies category-based discount
 *  - Skips CANCELLED orders (returns null)
 */
@Slf4j
@Component
public class SalesItemProcessor implements ItemProcessor<SalesRecord, ProcessedSale> {

    @Override
    public ProcessedSale process(SalesRecord record) throws Exception {
        log.debug("Processing order: {}", record.getOrderId());

        // Skip cancelled orders — returning null tells Spring Batch to drop the item
        if ("CANCELLED".equalsIgnoreCase(record.getStatus())) {
            log.info("Skipping CANCELLED order: {}", record.getOrderId());
            return null;
        }

        // Compute total amount
        BigDecimal totalAmount = record.getUnitPrice()
                .multiply(BigDecimal.valueOf(record.getQuantity()))
                .setScale(2, RoundingMode.HALF_UP);

        // Apply discount based on category
        BigDecimal discountRate = getDiscountRate(record.getCategory());
        BigDecimal discountApplied = totalAmount.multiply(discountRate).setScale(2, RoundingMode.HALF_UP);
        BigDecimal finalAmount = totalAmount.subtract(discountApplied).setScale(2, RoundingMode.HALF_UP);

        return ProcessedSale.builder()
                .orderId(record.getOrderId())
                .customerName(record.getCustomerName())
                .product(record.getProduct())
                .category(record.getCategory())
                .quantity(record.getQuantity())
                .unitPrice(record.getUnitPrice())
                .totalAmount(totalAmount)
                .orderDate(record.getOrderDate())
                .region(record.getRegion())
                .status(record.getStatus())
                .discountApplied(discountApplied)
                .finalAmount(finalAmount)
                .processedAt(LocalDateTime.now())
                .build();
    }

    /**
     * Returns a discount rate for each category.
     * Electronics: 5%, Furniture: 10%, others: 2%
     */
    BigDecimal getDiscountRate(String category) {
        if (category == null) return BigDecimal.ZERO;
        return switch (category.toUpperCase()) {
            case "ELECTRONICS" -> new BigDecimal("0.05");
            case "FURNITURE"   -> new BigDecimal("0.10");
            case "STATIONERY"  -> new BigDecimal("0.03");
            case "OFFICE"      -> new BigDecimal("0.02");
            default            -> new BigDecimal("0.02");
        };
    }
}
