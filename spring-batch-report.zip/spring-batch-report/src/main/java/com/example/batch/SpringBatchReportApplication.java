package com.example.batch;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@RequiredArgsConstructor
@Slf4j
public class SpringBatchReportApplication implements CommandLineRunner {

    private final JobLauncher jobLauncher;
    private final Job salesReportJob;

    public static void main(String[] args) {
        SpringApplication.run(SpringBatchReportApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        log.info("Launching salesReportJob...");

        JobParameters params = new JobParametersBuilder()
                .addLong("run.id", System.currentTimeMillis())
                .toJobParameters();

        var execution = jobLauncher.run(salesReportJob, params);

        log.info("Job finished with status: {}", execution.getStatus());
    }
}
