package com.example.batch.config;

import com.example.batch.listener.JobCompletionListener;
import com.example.batch.model.ProcessedSale;
import com.example.batch.model.SalesRecord;
import com.example.batch.processor.SalesItemProcessor;
import com.example.batch.reader.SalesItemReader;
import com.example.batch.writer.SalesItemWriter;
import lombok.RequiredArgsConstructor;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

/**
 * Spring Batch job configuration.
 *
 * Job: salesReportJob
 * Step 1: Read CSV → Process → Write to DB + CSV
 * (After job: listener generates Excel report)
 */
@Configuration
@RequiredArgsConstructor
public class BatchJobConfig {

    private final SalesItemReader salesItemReader;
    private final SalesItemProcessor salesItemProcessor;
    private final SalesItemWriter salesItemWriter;
    private final JobCompletionListener jobCompletionListener;

    @Value("${batch.chunk.size:100}")
    private int chunkSize;

    @Bean
    public Job salesReportJob(JobRepository jobRepository, Step salesProcessingStep) {
        return new JobBuilder("salesReportJob", jobRepository)
                .incrementer(new RunIdIncrementer())
                .listener(jobCompletionListener)
                .start(salesProcessingStep)
                .build();
    }

    @Bean
    public Step salesProcessingStep(JobRepository jobRepository,
                                    PlatformTransactionManager transactionManager) {
        return new StepBuilder("salesProcessingStep", jobRepository)
                .<SalesRecord, ProcessedSale>chunk(chunkSize, transactionManager)
                .reader(salesItemReader.salesCsvReader())
                .processor(salesItemProcessor)
                .writer(salesItemWriter)
                .build();
    }
}
