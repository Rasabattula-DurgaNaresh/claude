package com.example.batch.listener;

import com.example.batch.report.ExcelReportGenerator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.stereotype.Component;

/**
 * Listens for job completion and triggers the Excel report generation.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class JobCompletionListener implements JobExecutionListener {

    private final ExcelReportGenerator reportGenerator;

    @Override
    public void beforeJob(JobExecution jobExecution) {
        log.info("========================================");
        log.info("  Sales Batch Job STARTING");
        log.info("  Job ID  : {}", jobExecution.getJobId());
        log.info("  Started : {}", jobExecution.getStartTime());
        log.info("========================================");
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        log.info("========================================");
        log.info("  Sales Batch Job COMPLETED");
        log.info("  Status  : {}", jobExecution.getStatus());
        log.info("  Duration: {}ms",
                jobExecution.getEndTime() != null && jobExecution.getStartTime() != null
                        ? java.time.Duration.between(jobExecution.getStartTime(), jobExecution.getEndTime()).toMillis()
                        : "N/A");
        log.info("========================================");

        if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
            try {
                log.info("Generating Excel report...");
                reportGenerator.generateReport();
                log.info("✅ Excel report generated successfully.");
            } catch (Exception e) {
                log.error("❌ Failed to generate Excel report: {}", e.getMessage(), e);
            }
        } else {
            log.warn("Job did not complete successfully — skipping report generation.");
        }
    }
}
