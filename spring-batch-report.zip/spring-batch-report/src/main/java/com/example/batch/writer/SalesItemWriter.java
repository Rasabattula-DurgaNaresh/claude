package com.example.batch.writer;

import com.example.batch.model.ProcessedSale;
import com.example.batch.model.ProcessedSaleRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Writes processed sales to:
 *  1. H2 database (via JPA repository)
 *  2. A CSV output file for downstream consumers
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class SalesItemWriter implements ItemWriter<ProcessedSale> {

    private final ProcessedSaleRepository repository;

    @Value("${report.csv.output}")
    private String csvOutputPath;

    private boolean headerWritten = false;

    @Override
    public void write(Chunk<? extends ProcessedSale> chunk) throws Exception {
        log.info("Writing chunk of {} items", chunk.size());

        // 1. Persist to DB
        repository.saveAll(chunk.getItems());

        // 2. Append to CSV output
        writeToCsv(chunk);
    }

    private void writeToCsv(Chunk<? extends ProcessedSale> chunk) throws IOException {
        Path outputPath = Paths.get(csvOutputPath);
        Files.createDirectories(outputPath.getParent());

        try (PrintWriter writer = new PrintWriter(new FileWriter(outputPath.toFile(), true))) {
            if (!headerWritten) {
                writer.println("orderId,customerName,product,category,quantity," +
                               "unitPrice,totalAmount,discountApplied,finalAmount," +
                               "orderDate,region,status,processedAt");
                headerWritten = true;
            }
            for (ProcessedSale sale : chunk.getItems()) {
                writer.printf("%d,%s,%s,%s,%d,%.2f,%.2f,%.2f,%.2f,%s,%s,%s,%s%n",
                        sale.getOrderId(),
                        sale.getCustomerName(),
                        sale.getProduct(),
                        sale.getCategory(),
                        sale.getQuantity(),
                        sale.getUnitPrice(),
                        sale.getTotalAmount(),
                        sale.getDiscountApplied(),
                        sale.getFinalAmount(),
                        sale.getOrderDate(),
                        sale.getRegion(),
                        sale.getStatus(),
                        sale.getProcessedAt()
                );
            }
        }
        log.info("CSV written to: {}", csvOutputPath);
    }
}
