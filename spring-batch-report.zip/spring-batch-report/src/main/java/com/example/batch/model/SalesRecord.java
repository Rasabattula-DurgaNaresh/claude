package com.example.batch.model;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Represents a raw sales record read from the input CSV.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SalesRecord {

    private Long orderId;
    private String customerName;
    private String product;
    private String category;
    private Integer quantity;
    private BigDecimal unitPrice;
    private LocalDate orderDate;
    private String region;
    private String status;

    // Computed field — set during processing
    private BigDecimal totalAmount;
}
