package com.example.batch.model;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProcessedSaleRepository extends JpaRepository<ProcessedSale, Long> {

    List<ProcessedSale> findByStatus(String status);

    List<ProcessedSale> findByRegion(String region);

    List<ProcessedSale> findByCategory(String category);

    @Query("""
        SELECT new com.example.batch.model.SalesSummary(
            p.category,
            p.region,
            COUNT(p),
            SUM(p.totalAmount),
            SUM(p.discountApplied),
            SUM(p.finalAmount),
            AVG(p.finalAmount)
        )
        FROM ProcessedSale p
        WHERE p.status = 'COMPLETED'
        GROUP BY p.category, p.region
        ORDER BY p.category, p.region
    """)
    List<SalesSummary> findSalesSummaryByCategoryAndRegion();

    @Query("SELECT COUNT(p) FROM ProcessedSale p WHERE p.status = :status")
    long countByStatus(String status);
}
