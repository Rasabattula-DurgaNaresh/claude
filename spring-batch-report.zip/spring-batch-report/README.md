# Spring Batch Report Generator

A production-ready Spring Batch project that reads sales data from CSV,
applies business logic, persists results to a database, and generates
Excel + CSV reports.

---

## Architecture

```
CSV Input (sales_data.csv)
        │
        ▼
┌─────────────────┐
│ SalesItemReader │  FlatFileItemReader — reads & maps CSV rows
└────────┬────────┘
         │ SalesRecord
         ▼
┌──────────────────────┐
│ SalesItemProcessor   │  Validates, computes totals, applies category discounts
│                      │  Returns null for CANCELLED orders (filtered by Batch)
└──────────┬───────────┘
           │ ProcessedSale
           ▼
┌─────────────────┐
│ SalesItemWriter │  Saves to H2 DB + writes processed_sales.csv
└────────┬────────┘
         │ (job completes)
         ▼
┌──────────────────────────┐
│ JobCompletionListener    │  Triggers ExcelReportGenerator
│ ExcelReportGenerator     │  3-sheet Excel report via Apache POI
└──────────────────────────┘
```

---

## Features

- **CSV Reading** — FlatFileItemReader with custom LocalDate + BigDecimal converters
- **Processing** — discount rules per category (Electronics 5%, Furniture 10%, etc.)
- **Filtering** — CANCELLED orders are silently dropped (null from processor)
- **Writing** — JPA persistence + CSV output per chunk
- **Reporting** — Excel workbook with 3 sheets:
  - Executive Summary (KPIs)
  - Sales by Category & Region (aggregated)
  - All Processed Sales (raw data)

---

## Discount Rules

| Category    | Discount |
|-------------|----------|
| Electronics | 5%       |
| Furniture   | 10%      |
| Stationery  | 3%       |
| Office      | 2%       |
| Other       | 2%       |

---

## Project Structure

```
src/
├── main/
│   ├── java/com/example/batch/
│   │   ├── SpringBatchReportApplication.java   # Entry point
│   │   ├── config/BatchJobConfig.java          # Job & Step wiring
│   │   ├── reader/SalesItemReader.java          # CSV reader
│   │   ├── processor/SalesItemProcessor.java   # Business logic
│   │   ├── writer/SalesItemWriter.java          # DB + CSV writer
│   │   ├── report/ExcelReportGenerator.java    # Excel report (Apache POI)
│   │   ├── listener/JobCompletionListener.java # Post-job hooks
│   │   └── model/                              # Entities & Repository
│   └── resources/
│       ├── application.properties
│       └── data/sales_data.csv                 # Sample input (20 orders)
└── test/
    └── java/com/example/batch/
        ├── processor/SalesItemProcessorTest.java    # Unit tests
        ├── writer/SalesItemWriterTest.java           # Unit tests
        ├── reader/SalesItemReaderTest.java           # Integration tests
        ├── report/ExcelReportGeneratorTest.java      # Unit tests
        └── job/SalesJobIntegrationTest.java          # End-to-end job test
```

---

## Running the Application

### Prerequisites
- Java 17+
- Maven 3.8+

### Run
```bash
mvn spring-boot:run
```

Reports will be generated in `./reports/`:
- `processed_sales.csv`
- `sales_summary.xlsx`

---

## Running Tests

```bash
# All tests
mvn test

# Specific test class
mvn test -Dtest=SalesItemProcessorTest
mvn test -Dtest=SalesJobIntegrationTest
```

---

## Test Coverage

| Test Class                    | Type        | What it verifies                              |
|-------------------------------|-------------|-----------------------------------------------|
| SalesItemProcessorTest        | Unit        | Discounts, filtering, field mapping           |
| SalesItemWriterTest           | Unit        | DB persistence, CSV output, append behaviour  |
| SalesItemReaderTest           | Integration | CSV parsing, field types, record count        |
| ExcelReportGeneratorTest      | Unit        | Sheet count, headers, data rows, edge cases   |
| SalesJobIntegrationTest       | Integration | Full job lifecycle, step metrics              |

---

## Configuration

Key properties in `application.properties`:

| Property                | Default                          | Description              |
|-------------------------|----------------------------------|--------------------------|
| `batch.chunk.size`      | `100`                            | Items per transaction    |
| `batch.input.file`      | `classpath:data/sales_data.csv`  | Input CSV location       |
| `report.csv.output`     | `./reports/processed_sales.csv`  | CSV output path          |
| `report.excel.output`   | `./reports/sales_summary.xlsx`   | Excel output path        |
