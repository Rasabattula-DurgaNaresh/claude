import { db } from '../config/database';
interface AuditParams { userId: string; action: string; ip?: string; userAgent?: string; entityType?: string; entityId?: string; oldValues?: any; newValues?: any; }
export class AuditService {
  async log(params: AuditParams) {
    try {
      await db.query('INSERT INTO audit_log (user_id,action,entity_type,entity_id,old_values,new_values,ip_address,user_agent) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)',
        [params.userId, params.action, params.entityType || null, params.entityId || null,
         params.oldValues ? JSON.stringify(params.oldValues) : null, params.newValues ? JSON.stringify(params.newValues) : null, params.ip || null, params.userAgent || null]);
    } catch { /* non-blocking */ }
  }
}
