import { Router } from 'express';
import { db } from '../config/database';
import { redisClient } from '../config/redis';
export const healthRouter = Router();
healthRouter.get('/', async (_, res) => {
  try { await db.query('SELECT 1'); await redisClient.ping(); res.json({ status: 'healthy', service: 'auth', timestamp: new Date().toISOString() }); }
  catch (err) { res.status(503).json({ status: 'unhealthy', error: String(err) }); }
});
