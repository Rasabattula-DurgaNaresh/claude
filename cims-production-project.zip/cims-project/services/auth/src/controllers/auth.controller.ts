import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import speakeasy from 'speakeasy';
import QRCode from 'qrcode';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../config/database';
import { redisClient } from '../config/redis';
import { logger } from '../utils/logger';
import { AuditService } from '../services/audit.service';

const JWT_SECRET = process.env.JWT_SECRET!;
const JWT_EXPIRES_IN = parseInt(process.env.JWT_EXPIRES_IN || '3600');
const REFRESH_SECRET = process.env.REFRESH_TOKEN_SECRET!;

export class AuthController {
  private audit = new AuditService();

  async login(req: Request, res: Response): Promise<void> {
    const { username, password, mfa_token } = req.body;
    try {
      const result = await db.query('SELECT * FROM users WHERE (username=$1 OR email=$1) AND status=$2', [username, 'active']);
      const user = result.rows[0];
      if (!user || !(await bcrypt.compare(password, user.password_hash))) {
        if (user) await db.query("UPDATE users SET failed_attempts=failed_attempts+1, locked_until=CASE WHEN failed_attempts>=4 THEN NOW()+INTERVAL '15 minutes' ELSE locked_until END WHERE id=$1", [user.id]);
        res.status(401).json({ message: 'Invalid credentials' }); return;
      }
      if (user.locked_until && new Date(user.locked_until) > new Date()) { res.status(423).json({ message: 'Account temporarily locked' }); return; }
      if (user.mfa_enabled) {
        if (!mfa_token) { res.status(202).json({ requiresMfa: true }); return; }
        const ok = speakeasy.totp.verify({ secret: user.mfa_secret, encoding: 'base32', token: mfa_token, window: 1 });
        if (!ok) { res.status(401).json({ message: 'Invalid MFA token' }); return; }
      }
      const payload = { sub: user.id, username: user.username, role: user.role };
      const accessToken = jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
      const refreshToken = uuidv4();
      const refreshHash = await bcrypt.hash(refreshToken, 10);
      await db.query("INSERT INTO refresh_tokens (user_id,token_hash,expires_at) VALUES ($1,$2,NOW()+INTERVAL '7 days')", [user.id, refreshHash]);
      await db.query('UPDATE users SET failed_attempts=0, last_login=NOW() WHERE id=$1', [user.id]);
      await this.audit.log({ userId: user.id, action: 'LOGIN', ip: req.ip, userAgent: req.get('user-agent') });
      res.json({ access_token: accessToken, refresh_token: refreshToken, token_type: 'Bearer', expires_in: JWT_EXPIRES_IN, user: { id: user.id, username: user.username, email: user.email, role: user.role, mfa_enabled: user.mfa_enabled } });
    } catch (err) { logger.error('Login error', err); res.status(500).json({ message: 'Internal server error' }); }
  }

  async refreshToken(req: Request, res: Response): Promise<void> {
    const { refresh_token } = req.body;
    if (!refresh_token) { res.status(400).json({ message: 'Refresh token required' }); return; }
    try {
      const tokens = await db.query("SELECT rt.*,u.username,u.role,u.status FROM refresh_tokens rt JOIN users u ON rt.user_id=u.id WHERE rt.expires_at>NOW() AND rt.revoked=false");
      let found: any = null;
      for (const row of tokens.rows) { if (await bcrypt.compare(refresh_token, row.token_hash)) { found = row; break; } }
      if (!found || found.status !== 'active') { res.status(401).json({ message: 'Invalid refresh token' }); return; }
      const newToken = jwt.sign({ sub: found.user_id, username: found.username, role: found.role }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
      res.json({ access_token: newToken, token_type: 'Bearer', expires_in: JWT_EXPIRES_IN });
    } catch (err) { logger.error('Refresh error', err); res.status(500).json({ message: 'Internal server error' }); }
  }

  async logout(req: Request, res: Response): Promise<void> {
    const userId = (req as any).user.sub;
    await db.query('UPDATE refresh_tokens SET revoked=true WHERE user_id=$1', [userId]);
    await this.audit.log({ userId, action: 'LOGOUT', ip: req.ip });
    res.json({ message: 'Logged out successfully' });
  }

  async getProfile(req: Request, res: Response): Promise<void> {
    const userId = (req as any).user.sub;
    const r = await db.query('SELECT id,username,email,role,mfa_enabled,last_login,created_at FROM users WHERE id=$1', [userId]);
    res.json(r.rows[0]);
  }

  async enableMfa(req: Request, res: Response): Promise<void> {
    const userId = (req as any).user.sub;
    const u = await db.query('SELECT username FROM users WHERE id=$1', [userId]);
    const secret = speakeasy.generateSecret({ name: `CIMS (${u.rows[0].username})`, issuer: 'CIMS' });
    await db.query('UPDATE users SET mfa_secret=$1 WHERE id=$2', [secret.base32, userId]);
    const qr = await QRCode.toDataURL(secret.otpauth_url!);
    res.json({ secret: secret.base32, qr_code: qr });
  }

  async verifyMfa(req: Request, res: Response): Promise<void> {
    const userId = (req as any).user.sub;
    const r = await db.query('SELECT mfa_secret FROM users WHERE id=$1', [userId]);
    const ok = speakeasy.totp.verify({ secret: r.rows[0].mfa_secret, encoding: 'base32', token: req.body.token, window: 1 });
    if (!ok) { res.status(400).json({ message: 'Invalid MFA token' }); return; }
    await db.query('UPDATE users SET mfa_enabled=true WHERE id=$1', [userId]);
    res.json({ message: 'MFA enabled successfully' });
  }

  async disableMfa(req: Request, res: Response): Promise<void> {
    const userId = (req as any).user.sub;
    await db.query('UPDATE users SET mfa_enabled=false, mfa_secret=NULL WHERE id=$1', [userId]);
    res.json({ message: 'MFA disabled' });
  }

  async changePassword(req: Request, res: Response): Promise<void> {
    const userId = (req as any).user.sub;
    const { current_password, new_password } = req.body;
    const r = await db.query('SELECT password_hash FROM users WHERE id=$1', [userId]);
    if (!(await bcrypt.compare(current_password, r.rows[0].password_hash))) { res.status(401).json({ message: 'Current password incorrect' }); return; }
    const hash = await bcrypt.hash(new_password, 12);
    await db.query('UPDATE users SET password_hash=$1 WHERE id=$2', [hash, userId]);
    await db.query('UPDATE refresh_tokens SET revoked=true WHERE user_id=$1', [userId]);
    await this.audit.log({ userId, action: 'CHANGE_PASSWORD', ip: req.ip });
    res.json({ message: 'Password changed. Please log in again.' });
  }
}
