import { Request, Response, NextFunction } from 'express';
import { logger } from '../utils/logger';
export function errorHandler(err: any, req: Request, res: Response, _next: NextFunction) {
  logger.error({ err, path: req.path, method: req.method });
  const status = err.status || 500;
  res.status(status).json({ message: status < 500 ? err.message : 'Internal server error' });
}
