import { Request, Response, NextFunction } from 'express';
import { redisClient } from '../config/redis';
interface Opts { max: number; window: number; }
export function rateLimiter(opts: Opts) {
  return async (req: Request, res: Response, next: NextFunction) => {
    const key = `rl:${req.ip}:${req.path}`;
    try {
      const count = await redisClient.incr(key);
      if (count === 1) await redisClient.expire(key, opts.window);
      if (count > opts.max) { res.set('Retry-After', String(opts.window)); return res.status(429).json({ message: 'Too many requests' }); }
      res.set('X-RateLimit-Remaining', String(Math.max(0, opts.max - count)));
      next();
    } catch { next(); }
  };
}
