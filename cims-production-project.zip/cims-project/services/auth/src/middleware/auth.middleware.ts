import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
export function authenticate(req: Request, res: Response, next: NextFunction) {
  const auth = req.headers.authorization;
  if (!auth?.startsWith('Bearer ')) return res.status(401).json({ message: 'Authorization header missing' });
  try {
    const payload = jwt.verify(auth.split(' ')[1], process.env.JWT_SECRET!);
    (req as any).user = payload;
    next();
  } catch { return res.status(401).json({ message: 'Invalid or expired token' }); }
}
