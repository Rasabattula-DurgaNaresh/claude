import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import morgan from 'morgan';
import { collectDefaultMetrics, register } from 'prom-client';
import { authRouter } from './routes/auth.routes';
import { healthRouter } from './routes/health.routes';
import { errorHandler } from './middleware/error.middleware';
import { logger } from './utils/logger';
import { db } from './config/database';
import { redisClient } from './config/redis';

collectDefaultMetrics({ prefix: 'cims_auth_' });

const app = express();
const PORT = parseInt(process.env.PORT || '3001');

// Middleware
app.use(helmet());
app.use(cors({
  origin: process.env.CORS_ORIGIN || 'https://cims.yourdomain.com',
  credentials: true,
}));
app.use(express.json({ limit: '10kb' }));
app.use(morgan('combined', { stream: { write: (msg) => logger.info(msg.trim()) } }));

// Routes
app.use('/health', healthRouter);
app.use('/auth', authRouter);

// Metrics endpoint
app.get('/metrics', async (_, res) => {
  res.set('Content-Type', register.contentType);
  res.end(await register.metrics());
});

// Error handling
app.use(errorHandler);

// Start server
async function bootstrap() {
  try {
    await db.connect();
    await redisClient.connect();
    app.listen(PORT, () => {
      logger.info(`Auth Service running on port ${PORT}`);
    });
  } catch (err) {
    logger.error('Failed to start auth service', err);
    process.exit(1);
  }
}

process.on('SIGTERM', async () => {
  logger.info('SIGTERM received, shutting down gracefully');
  await db.end();
  await redisClient.quit();
  process.exit(0);
});

bootstrap();
