import { createClient } from 'redis';
import { logger } from '../utils/logger';
export const redisClient = createClient({
  socket: { host: process.env.REDIS_HOST || 'redis', port: parseInt(process.env.REDIS_PORT || '6379') },
  password: process.env.REDIS_PASSWORD,
});
redisClient.on('error', (err) => logger.error('Redis error', err));
