import { Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { ExternalGatewayService } from '../services/external-gateway.service';
import { TransUnionSocketService } from '../services/transunion.service';
import { db } from '../config/database';
import { logger } from '../utils/logger';
const gwSvc = new ExternalGatewayService();
const tuSvc = new TransUnionSocketService();
export class McraController {
  async assess(req: Request, res: Response) {
    const assessmentId = uuidv4();
    try {
      const { subject_id, assessment_type, parameters } = req.body;
      await db.query("INSERT INTO credit_reports (id,subject_id,report_type,source,data,created_by) VALUES ($1,$2,$3,$4,$5,$6)", [assessmentId, subject_id, assessment_type || 'mcra', 'mcra', JSON.stringify({ status: 'pending', parameters }), (req as any).user.sub]);
      res.status(202).json({ assessment_id: assessmentId, status: 'accepted', message: 'Assessment initiated' });
    } catch (err) { logger.error('Assessment error', err); res.status(500).json({ message: 'Assessment failed' }); }
  }
  async queryTransUnion(req: Request, res: Response) {
    const requestId = uuidv4();
    try {
      const result = await tuSvc.sendRequest(requestId, req.body);
      res.json({ request_id: requestId, result });
    } catch (err: any) {
      logger.warn('TransUnion query failed, falling back to API', err.message);
      res.status(503).json({ message: 'TransUnion service temporarily unavailable', request_id: requestId });
    }
  }
  async submitToCrp(req: Request, res: Response) {
    const requestId = uuidv4();
    try {
      const result = await gwSvc.callCRP('/submit', req.body, requestId);
      res.json({ request_id: requestId, result });
    } catch (err) { res.status(502).json({ message: 'CRP submission failed', request_id: requestId }); }
  }
  async lookupOneConnect(req: Request, res: Response) {
    const requestId = uuidv4();
    try {
      const result = await gwSvc.callOneConnect('/lookup', req.body, requestId);
      res.json({ request_id: requestId, result });
    } catch (err) { res.status(502).json({ message: 'OneConnect lookup failed', request_id: requestId }); }
  }
  async getAssessment(req: Request, res: Response) {
    try {
      const { rows } = await db.query('SELECT * FROM credit_reports WHERE id=$1', [req.params.id]);
      if (!rows.length) { res.status(404).json({ message: 'Assessment not found' }); return; }
      res.json(rows[0]);
    } catch (err) { res.status(500).json({ message: 'Failed to fetch assessment' }); }
  }
}
