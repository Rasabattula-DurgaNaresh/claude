import { Router } from 'express';
import { db } from '../config/database';
export const healthRouter = Router();
healthRouter.get('/',async(_,res)=>{try{await db.query('SELECT 1');res.json({status:'healthy',service:'mcra'});}catch{res.status(503).json({status:'unhealthy'});}});
