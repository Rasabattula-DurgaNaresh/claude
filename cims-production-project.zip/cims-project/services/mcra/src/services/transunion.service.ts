import net from 'net';
import { logger } from '../utils/logger';

export class TransUnionSocketService {
  private socket: net.Socket | null = null;
  private host = process.env.TRANSUNION_SOCKET_HOST!;
  private port = parseInt(process.env.TRANSUNION_SOCKET_PORT || '9443');
  private reconnectTimer: NodeJS.Timeout | null = null;
  private responseCallbacks: Map<string, (data: any) => void> = new Map();

  async connect(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.socket = new net.Socket();
      this.socket.connect(this.port, this.host, () => {
        logger.info(`TransUnion socket connected to ${this.host}:${this.port}`);
        resolve();
      });
      this.socket.on('data', (data) => this.handleData(data));
      this.socket.on('error', (err) => { logger.error('TU socket error', err); reject(err); });
      this.socket.on('close', () => {
        logger.warn('TransUnion socket closed, scheduling reconnect...');
        this.scheduleReconnect();
      });
      this.socket.setTimeout(30000);
    });
  }

  private handleData(data: Buffer) {
    try {
      const msg = JSON.parse(data.toString());
      if (msg.requestId && this.responseCallbacks.has(msg.requestId)) {
        this.responseCallbacks.get(msg.requestId)!(msg);
        this.responseCallbacks.delete(msg.requestId);
      }
    } catch (err) { logger.error('Failed to parse TU response', err); }
  }

  async sendRequest(requestId: string, payload: any): Promise<any> {
    if (!this.socket || this.socket.destroyed) throw new Error('TransUnion socket not connected');
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => { this.responseCallbacks.delete(requestId); reject(new Error('TransUnion request timeout')); }, 30000);
      this.responseCallbacks.set(requestId, (data) => { clearTimeout(timeout); resolve(data); });
      this.socket!.write(JSON.stringify({ requestId, ...payload }));
    });
  }

  private scheduleReconnect() {
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.reconnectTimer = setTimeout(() => { this.connect().catch(err => logger.error('Reconnect failed', err)); }, 5000);
  }

  disconnect() { this.socket?.destroy(); if (this.reconnectTimer) clearTimeout(this.reconnectTimer); }
}
