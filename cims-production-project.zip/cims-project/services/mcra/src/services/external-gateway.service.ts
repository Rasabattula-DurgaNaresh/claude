import axios, { AxiosInstance } from 'axios';
import { logger } from '../utils/logger';
import { db } from '../config/database';

export class ExternalGatewayService {
  private crpClient: AxiosInstance;
  private oneConnectClient: AxiosInstance;

  constructor() {
    this.crpClient = axios.create({
      baseURL: process.env.CRP_URL,
      timeout: 30000,
      headers: { 'Content-Type': 'application/json', 'X-Source-System': 'CIMS-MCRA' },
    });
    this.oneConnectClient = axios.create({
      baseURL: process.env.ONECONNECT_URL,
      timeout: 30000,
      headers: { 'Content-Type': 'application/json', 'X-Source-System': 'CIMS-MCRA' },
    });
  }

  async callCRP(endpoint: string, payload: any, requestId: string) {
    const start = Date.now();
    try {
      const { data, status } = await this.crpClient.post(endpoint, payload, { headers: { 'X-Request-ID': requestId } });
      await this.logCall('CRP', requestId, endpoint, payload, data, status, true, Date.now() - start);
      return data;
    } catch (err: any) {
      await this.logCall('CRP', requestId, endpoint, payload, null, err.response?.status, false, Date.now() - start, err.message);
      throw err;
    }
  }

  async callOneConnect(endpoint: string, payload: any, requestId: string) {
    const start = Date.now();
    try {
      const { data, status } = await this.oneConnectClient.post(endpoint, payload, { headers: { 'X-Request-ID': requestId } });
      await this.logCall('ONECONNECT', requestId, endpoint, payload, data, status, true, Date.now() - start);
      return data;
    } catch (err: any) {
      await this.logCall('ONECONNECT', requestId, endpoint, payload, null, err.response?.status, false, Date.now() - start, err.message);
      throw err;
    }
  }

  private async logCall(system: string, requestId: string, endpoint: string, req: any, resp: any, status: any, success: boolean, duration: number, error?: string) {
    try {
      await db.query('INSERT INTO integration_log (system_name,request_id,direction,endpoint,method,request_payload,response_payload,status_code,success,error_message,duration_ms) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)',
        [system, requestId, 'outbound', endpoint, 'POST', JSON.stringify(req), resp ? JSON.stringify(resp) : null, status, success, error || null, duration]);
    } catch { /* non-blocking */ }
  }
}
