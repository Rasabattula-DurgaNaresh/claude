import { Request,Response,NextFunction } from 'express';
export function errorHandler(err:any,req:Request,res:Response,_:NextFunction){res.status(err.status||500).json({message:err.message||'Internal server error'});}
