import * as Minio from 'minio';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../config/database';

const client = new Minio.Client({
  endPoint: process.env.MINIO_ENDPOINT || 'minio',
  port: parseInt(process.env.MINIO_PORT || '9000'),
  useSSL: process.env.MINIO_USE_SSL === 'true',
  accessKey: process.env.MINIO_ACCESS_KEY!,
  secretKey: process.env.MINIO_SECRET_KEY!,
});

const BUCKET = 'cims-documents';

export class MinioService {
  async ensureBucket() {
    const exists = await client.bucketExists(BUCKET);
    if (!exists) await client.makeBucket(BUCKET, 'us-east-1');
  }

  async uploadFile(filename: string, base64Content: string, entityId: string, userId: string) {
    await this.ensureBucket();
    const buffer = Buffer.from(base64Content, 'base64');
    const storedName = `${uuidv4()}-${filename}`;
    await client.putObject(BUCKET, storedName, buffer, buffer.length, { 'Content-Type': 'application/octet-stream' });
    const { rows } = await db.query(
      'INSERT INTO files (original_name,stored_name,bucket,size_bytes,uploaded_by,entity_id) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id',
      [filename, storedName, BUCKET, buffer.length, userId, entityId]
    );
    return { file_id: rows[0].id, name: filename, size: buffer.length };
  }

  async listFiles(entityId: string) {
    const { rows } = await db.query('SELECT id,original_name,size_bytes,created_at FROM files WHERE entity_id=$1 ORDER BY created_at DESC', [entityId]);
    return rows;
  }

  async getPresignedUrl(storedName: string) {
    return client.presignedGetObject(BUCKET, storedName, 3600);
  }
}
