import axios from 'axios';
import { db } from '../config/database';
import { logger } from '../utils/logger';

export class BureauService {
  private iclnet2Url = process.env.ICLNET2_GATEWAY_URL!;

  async submitEnquiry(data: any, userId: string) {
    const { rows } = await db.query(
      "INSERT INTO credit_reports (subject_id, report_type, source, data, created_by) VALUES ($1,$2,$3,$4,$5) RETURNING id",
      [data.subject_id, data.report_type || 'standard', 'bureau', JSON.stringify(data), userId]
    );
    const enquiryId = rows[0].id;
    // Call external bureau via ICLNET2
    try {
      const response = await axios.post(`${this.iclnet2Url}/bureau/enquiry`, data, {
        headers: { 'X-Request-ID': enquiryId, 'Content-Type': 'application/json' },
        timeout: 30000,
      });
      await db.query('UPDATE credit_reports SET data=$1, bureau_ref=$2, score=$3 WHERE id=$4',
        [JSON.stringify(response.data), response.data.reference, response.data.score, enquiryId]);
      await this.logIntegration('ICLNET2_BUREAU', enquiryId, '/bureau/enquiry', 'POST', data, response.data, response.status, true);
      return { enquiry_id: enquiryId, status: 'completed', data: response.data };
    } catch (err: any) {
      await this.logIntegration('ICLNET2_BUREAU', enquiryId, '/bureau/enquiry', 'POST', data, null, err.response?.status, false, err.message);
      return { enquiry_id: enquiryId, status: 'pending', message: 'Enquiry queued for retry' };
    }
  }

  async getEnquiry(id: string) {
    const { rows } = await db.query('SELECT * FROM credit_reports WHERE id=$1', [id]);
    if (!rows.length) throw new Error('Not found');
    return rows[0];
  }

  async batchEnquiry(subjects: any[], userId: string) {
    const batchId = (await db.query(
      "INSERT INTO batch_jobs (job_name,job_type,status,total_records,created_by) VALUES ($1,$2,$3,$4,$5) RETURNING id",
      ['Bureau Batch Enquiry', 'bureau_batch', 'pending', subjects.length, userId]
    )).rows[0].id;
    // Process async (simplified)
    setImmediate(() => this.processBatch(batchId, subjects, userId));
    return { batch_id: batchId, total: subjects.length, status: 'accepted' };
  }

  private async processBatch(batchId: string, subjects: any[], userId: string) {
    let processed = 0, failed = 0;
    await db.query("UPDATE batch_jobs SET status='running', started_at=NOW() WHERE id=$1", [batchId]);
    for (const subject of subjects) {
      try { await this.submitEnquiry(subject, userId); processed++; }
      catch { failed++; }
      await db.query('UPDATE batch_jobs SET processed_records=$1, failed_records=$2 WHERE id=$3', [processed, failed, batchId]);
    }
    await db.query("UPDATE batch_jobs SET status='completed', completed_at=NOW() WHERE id=$1", [batchId]);
  }

  async getCreditReport(subjectId: string) {
    const { rows } = await db.query('SELECT * FROM credit_reports WHERE subject_id=$1 ORDER BY fetched_at DESC LIMIT 1', [subjectId]);
    if (!rows.length) throw new Error('No report found');
    return rows[0];
  }

  private async logIntegration(system: string, reqId: string, endpoint: string, method: string, req: any, resp: any, status: any, success: boolean, error?: string) {
    try {
      await db.query('INSERT INTO integration_log (system_name,request_id,direction,endpoint,method,request_payload,response_payload,status_code,success,error_message) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)',
        [system, reqId, 'outbound', endpoint, method, JSON.stringify(req), resp ? JSON.stringify(resp) : null, status, success, error || null]);
    } catch { /* non-blocking */ }
  }
}
