import winston from 'winston';
export const logger = winston.createLogger({ level: 'info', format: winston.format.combine(winston.format.timestamp(), process.env.NODE_ENV==='production'?winston.format.json():winston.format.prettyPrint()), defaultMeta:{service:'cims-bureau'}, transports:[new winston.transports.Console()] });
