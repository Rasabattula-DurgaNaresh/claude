import { Pool } from 'pg';
import { logger } from '../utils/logger';
export const db = new Pool({ host:process.env.DB_HOST, port:parseInt(process.env.DB_PORT||'5432'), database:process.env.DB_NAME, user:process.env.DB_USER, password:process.env.DB_PASSWORD, max:20 });
db.on('error',(err)=>logger.error('DB error',err));
