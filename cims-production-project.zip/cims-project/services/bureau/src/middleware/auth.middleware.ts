import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
export function authenticate(req:Request,res:Response,next:NextFunction){const auth=req.headers.authorization;if(!auth?.startsWith('Bearer '))return res.status(401).json({message:'Unauthorized'});try{(req as any).user=jwt.verify(auth.split(' ')[1],process.env.JWT_SECRET!);next();}catch{return res.status(401).json({message:'Invalid token'});}}
