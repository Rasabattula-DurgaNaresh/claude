import { Request, Response } from 'express';
import { BureauService } from '../services/bureau.service';
import { MinioService } from '../services/minio.service';
import { logger } from '../utils/logger';
const bureauSvc = new BureauService();
const minioSvc = new MinioService();
export class BureauController {
  async createEnquiry(req: Request, res: Response) {
    try {
      const result = await bureauSvc.submitEnquiry(req.body, (req as any).user.sub);
      res.status(201).json(result);
    } catch (err) { logger.error('Enquiry error', err); res.status(500).json({ message: 'Failed to process enquiry' }); }
  }
  async getEnquiry(req: Request, res: Response) {
    try { res.json(await bureauSvc.getEnquiry(req.params.id)); }
    catch (err) { res.status(404).json({ message: 'Enquiry not found' }); }
  }
  async batchEnquiry(req: Request, res: Response) {
    try {
      const { subjects } = req.body;
      if (!Array.isArray(subjects) || subjects.length > 100) { res.status(400).json({ message: 'Invalid batch: max 100 subjects' }); return; }
      const result = await bureauSvc.batchEnquiry(subjects, (req as any).user.sub);
      res.status(202).json(result);
    } catch (err) { res.status(500).json({ message: 'Batch enquiry failed' }); }
  }
  async getCreditReport(req: Request, res: Response) {
    try { res.json(await bureauSvc.getCreditReport(req.params.subjectId)); }
    catch (err) { res.status(500).json({ message: 'Failed to get credit report' }); }
  }
  async uploadDocument(req: Request, res: Response) {
    try {
      if (!req.body.filename || !req.body.content) { res.status(400).json({ message: 'filename and content required' }); return; }
      const result = await minioSvc.uploadFile(req.body.filename, req.body.content, req.body.entityId, (req as any).user.sub);
      res.status(201).json(result);
    } catch (err) { res.status(500).json({ message: 'Upload failed' }); }
  }
  async listFiles(req: Request, res: Response) {
    try { res.json(await minioSvc.listFiles(req.params.entityId)); }
    catch (err) { res.status(500).json({ message: 'Failed to list files' }); }
  }
}
