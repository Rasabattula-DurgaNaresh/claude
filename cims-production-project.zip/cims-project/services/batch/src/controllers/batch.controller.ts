import { Request, Response } from 'express';
import { db } from '../config/database';
import { DownstreamDispatchJob } from '../jobs/downstream-dispatch.job';
import { DataReconciliationJob } from '../jobs/data-reconciliation.job';
import { logger } from '../utils/logger';

export class BatchController {
  async listJobs(req: Request, res: Response) {
    const { rows } = await db.query('SELECT id,job_name,job_type,status,total_records,processed_records,failed_records,started_at,completed_at FROM batch_jobs ORDER BY created_at DESC LIMIT 50');
    res.json({ jobs: rows });
  }
  async getJob(req: Request, res: Response) {
    const { rows } = await db.query('SELECT * FROM batch_jobs WHERE id=$1', [req.params.id]);
    if (!rows.length) { res.status(404).json({ message: 'Job not found' }); return; }
    res.json(rows[0]);
  }
  async triggerJob(req: Request, res: Response) {
    const { job_type } = req.body;
    try {
      if (job_type === 'downstream_dispatch') {
        new DownstreamDispatchJob().run().catch(err => logger.error('Dispatch job error', err));
        res.json({ message: 'Downstream dispatch job triggered' });
      } else if (job_type === 'data_reconciliation') {
        new DataReconciliationJob().run().catch(err => logger.error('Reconciliation job error', err));
        res.json({ message: 'Reconciliation job triggered' });
      } else {
        res.status(400).json({ message: 'Unknown job type' });
      }
    } catch (err) { res.status(500).json({ message: 'Failed to trigger job' }); }
  }
  async cancelJob(req: Request, res: Response) {
    await db.query("UPDATE batch_jobs SET status='cancelled' WHERE id=$1 AND status='pending'", [req.params.id]);
    res.json({ message: 'Cancellation requested' });
  }
}
