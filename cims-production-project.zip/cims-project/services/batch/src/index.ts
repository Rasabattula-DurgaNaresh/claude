import express from 'express';
import helmet from 'helmet';
import cron from 'node-cron';
import { batchRouter } from './routes/batch.routes';
import { healthRouter } from './routes/health.routes';
import { errorHandler } from './middleware/error.middleware';
import { logger } from './utils/logger';
import { DownstreamDispatchJob } from './jobs/downstream-dispatch.job';
import { DataReconciliationJob } from './jobs/data-reconciliation.job';

const app = express();
const PORT = parseInt(process.env.PORT || '3003');
app.use(helmet()); app.use(express.json());
app.use('/health', healthRouter);
app.use('/batch', batchRouter);
app.use(errorHandler);

// Schedule batch jobs
const dispatchJob = new DownstreamDispatchJob();
const reconcileJob = new DataReconciliationJob();
cron.schedule(process.env.BATCH_CRON_SCHEDULE || '0 2 * * *', () => dispatchJob.run());
cron.schedule('0 */6 * * *', () => reconcileJob.run());

app.listen(PORT, () => logger.info(`Batch Service on port ${PORT}`));
