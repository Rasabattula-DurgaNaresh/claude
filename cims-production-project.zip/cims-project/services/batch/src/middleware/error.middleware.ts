import { Request,Response,NextFunction } from 'express';
export function errorHandler(err:any,_req:Request,res:Response,_n:NextFunction){res.status(err.status||500).json({message:err.message||'Internal server error'});}
