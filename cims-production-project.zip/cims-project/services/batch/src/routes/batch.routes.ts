import { Router } from 'express';
import { BatchController } from '../controllers/batch.controller';
export const batchRouter = Router();
const ctrl = new BatchController();
batchRouter.get('/jobs',       ctrl.listJobs.bind(ctrl));
batchRouter.get('/jobs/:id',   ctrl.getJob.bind(ctrl));
batchRouter.post('/trigger',   ctrl.triggerJob.bind(ctrl));
batchRouter.post('/cancel/:id',ctrl.cancelJob.bind(ctrl));
