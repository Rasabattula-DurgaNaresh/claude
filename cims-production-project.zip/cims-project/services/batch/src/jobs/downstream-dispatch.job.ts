import axios from 'axios';
import { db } from '../config/database';
import { logger } from '../utils/logger';

const DOWNSTREAM_SYSTEMS = [
  { name: 'ICM',   url: process.env.DOWNSTREAM_ICM_URL   || '', endpoint: '/cims/data' },
  { name: 'RLS',   url: process.env.DOWNSTREAM_RLS_URL   || '', endpoint: '/ingest' },
  { name: 'PDW',   url: process.env.DOWNSTREAM_PDW_URL   || '', endpoint: '/load' },
  { name: 'RDS',   url: process.env.DOWNSTREAM_RDS_URL   || '', endpoint: '/push' },
  { name: 'CCMS',  url: process.env.DOWNSTREAM_CCMS_URL  || '', endpoint: '/sync' },
  { name: 'PROBE', url: process.env.DOWNSTREAM_PROBE_URL || '', endpoint: '/receive' },
  { name: 'OAMS',  url: process.env.DOWNSTREAM_OAMS_URL  || '', endpoint: '/import' },
  { name: 'EDMP',  url: process.env.DOWNSTREAM_EDMP_URL  || '', endpoint: '/batch' },
  { name: 'ECARS', url: process.env.DOWNSTREAM_ECARS_URL || '', endpoint: '/feed' },
];

export class DownstreamDispatchJob {
  async run() {
    logger.info('Starting downstream dispatch batch job');
    const jobId = (await db.query(
      "INSERT INTO batch_jobs (job_name,job_type,status,scheduled_at) VALUES ($1,$2,$3,NOW()) RETURNING id",
      ['Downstream Dispatch', 'downstream_dispatch', 'running']
    )).rows[0].id;
    let totalSent = 0, totalFailed = 0;
    for (const system of DOWNSTREAM_SYSTEMS) {
      if (!system.url) { logger.warn(`${system.name} URL not configured, skipping`); continue; }
      try {
        const { rows } = await db.query(
          "SELECT * FROM credit_reports WHERE created_at > NOW() - INTERVAL '24 hours' ORDER BY created_at ASC LIMIT 1000"
        );
        if (!rows.length) continue;
        const response = await axios.post(`${system.url}${system.endpoint}`, { records: rows, batch_id: jobId }, { timeout: 60000 });
        logger.info(`Dispatched ${rows.length} records to ${system.name}`);
        await this.logDispatch(system.name, jobId, rows.length, true);
        totalSent += rows.length;
      } catch (err: any) {
        logger.error(`Failed to dispatch to ${system.name}`, err.message);
        await this.logDispatch(system.name, jobId, 0, false, err.message);
        totalFailed++;
      }
    }
    await db.query(
      "UPDATE batch_jobs SET status=$1, completed_at=NOW(), processed_records=$2, failed_records=$3 WHERE id=$4",
      [totalFailed > 0 ? 'completed_with_errors' : 'completed', totalSent, totalFailed, jobId]
    );
    logger.info(`Downstream dispatch complete. Sent: ${totalSent}, Failed systems: ${totalFailed}`);
  }

  private async logDispatch(system: string, jobId: string, count: number, success: boolean, error?: string) {
    try {
      await db.query('INSERT INTO integration_log (system_name,request_id,direction,endpoint,method,success,error_message) VALUES ($1,$2,$3,$4,$5,$6,$7)',
        [system, jobId, 'outbound', '/batch', 'POST', success, error || null]);
    } catch { /* non-blocking */ }
  }
}
