import { db } from '../config/database';
import { logger } from '../utils/logger';

export class DataReconciliationJob {
  async run() {
    logger.info('Starting data reconciliation job');
    try {
      // Clean expired refresh tokens
      const { rowCount: expiredTokens } = await db.query("DELETE FROM refresh_tokens WHERE expires_at < NOW() OR revoked = true");
      logger.info(`Cleaned ${expiredTokens} expired tokens`);

      // Archive old audit logs (> 90 days)
      const { rowCount: archivedLogs } = await db.query("DELETE FROM audit_log WHERE created_at < NOW() - INTERVAL '90 days'");
      logger.info(`Archived ${archivedLogs} old audit records`);

      // Mark stale batch jobs as failed
      const { rowCount: staleBatches } = await db.query(
        "UPDATE batch_jobs SET status='failed', error_message='Timed out' WHERE status='running' AND started_at < NOW() - INTERVAL '4 hours'"
      );
      logger.info(`Marked ${staleBatches} stale jobs as failed`);

      // Clean expired integration logs > 30 days
      await db.query("DELETE FROM integration_log WHERE created_at < NOW() - INTERVAL '30 days'");

      logger.info('Data reconciliation complete');
    } catch (err) {
      logger.error('Reconciliation job failed', err);
    }
  }
}
