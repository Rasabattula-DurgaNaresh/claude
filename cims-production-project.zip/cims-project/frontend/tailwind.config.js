/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: { 50:'#eff6ff',100:'#dbeafe',500:'#3b82f6',600:'#2563eb',700:'#1d4ed8',900:'#1e3a8a' },
        secondary: { 500:'#64748b',700:'#334155' },
        danger: { 500:'#ef4444', 600:'#dc2626' },
        success: { 500:'#22c55e', 600:'#16a34a' },
        warning: { 500:'#f59e0b', 600:'#d97706' },
      },
      fontFamily: { sans: ['IBM Plex Sans','system-ui','sans-serif'], mono: ['IBM Plex Mono','monospace'] },
    }
  },
  plugins: [],
};