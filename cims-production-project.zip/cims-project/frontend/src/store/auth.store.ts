import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { authApi } from '../services/auth.api';

interface User { id: string; username: string; email: string; role: string; mfa_enabled: boolean; }
interface AuthState {
  user: User | null; accessToken: string | null; refreshToken: string | null; isAuthenticated: boolean;
  login: (username: string, password: string, mfaToken?: string) => Promise<any>;
  logout: () => Promise<void>;
  setTokens: (access: string, refresh: string) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null, accessToken: null, refreshToken: null, isAuthenticated: false,
      login: async (username, password, mfaToken) => {
        const data = await authApi.login(username, password, mfaToken);
        if (data.requiresMfa) return data;
        set({ user: data.user, accessToken: data.access_token, refreshToken: data.refresh_token, isAuthenticated: true });
        return data;
      },
      logout: async () => {
        try { await authApi.logout(); } catch {}
        set({ user: null, accessToken: null, refreshToken: null, isAuthenticated: false });
      },
      setTokens: (access, refresh) => set({ accessToken: access, refreshToken: refresh }),
    }),
    { name: 'cims-auth', partialize: (state) => ({ user: state.user, accessToken: state.accessToken, refreshToken: state.refreshToken, isAuthenticated: state.isAuthenticated }) }
  )
);