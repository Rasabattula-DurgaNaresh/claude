import { api } from './api';
export const authApi = {
  login: async (username: string, password: string, mfa_token?: string) => {
    const { data } = await api.post('/auth/login', { username, password, ...(mfa_token && { mfa_token }) });
    return data;
  },
  logout: async () => { await api.post('/auth/logout'); },
  getProfile: async () => { const { data } = await api.get('/auth/me'); return data; },
  enableMfa: async () => { const { data } = await api.post('/auth/mfa/enable'); return data; },
  verifyMfa: async (token: string) => { await api.post('/auth/mfa/verify', { token }); },
  changePassword: async (current: string, next: string) => { await api.post('/auth/change-password', { current_password: current, new_password: next }); },
};