import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useAuthStore } from '../store/auth.store';
import { Shield, Loader2, Eye, EyeOff, AlertCircle } from 'lucide-react';

const schema = z.object({ username: z.string().min(1, 'Username required'), password: z.string().min(1, 'Password required'), mfaToken: z.string().optional() });
type FormData = z.infer<typeof schema>;

export function LoginPage() {
  const navigate = useNavigate();
  const { login } = useAuthStore();
  const [requiresMfa, setRequiresMfa] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');

  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<FormData>({ resolver: zodResolver(schema) });

  const onSubmit = async (data: FormData) => {
    setError('');
    try {
      const result = await login(data.username, data.password, data.mfaToken);
      if (result?.requiresMfa) { setRequiresMfa(true); return; }
      navigate('/dashboard');
    } catch (err: any) {
      setError(err.response?.data?.message || 'Login failed. Please try again.');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-primary-900 to-slate-900 flex items-center justify-center p-4">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(255,255,255,0.15) 1px, transparent 0)', backgroundSize: '32px 32px' }} />

      <div className="relative w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary-600 rounded-2xl mb-4 shadow-lg shadow-primary-500/30">
            <Shield size={28} className="text-white" />
          </div>
          <h1 className="text-2xl font-bold text-white">Welcome to CIMS</h1>
          <p className="text-slate-400 text-sm mt-1">Credit Information Management System</p>
        </div>

        {/* Card */}
        <div className="bg-white rounded-2xl shadow-2xl p-8">
          <h2 className="text-lg font-semibold text-slate-900 mb-6">{requiresMfa ? 'Two-Factor Authentication' : 'Sign in to your account'}</h2>

          {error && (
            <div className="flex items-start gap-2 p-3 bg-danger-50 border border-danger-200 rounded-lg mb-4 text-danger-700 text-sm">
              <AlertCircle size={16} className="mt-0.5 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            {!requiresMfa && (
              <>
                <div>
                  <label className="label">Username or Email</label>
                  <input {...register('username')} className="input" placeholder="Enter username or email" autoComplete="username" />
                  {errors.username && <p className="text-danger-600 text-xs mt-1">{errors.username.message}</p>}
                </div>
                <div>
                  <label className="label">Password</label>
                  <div className="relative">
                    <input {...register('password')} type={showPassword ? 'text' : 'password'} className="input pr-10" placeholder="Enter password" autoComplete="current-password" />
                    <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                  {errors.password && <p className="text-danger-600 text-xs mt-1">{errors.password.message}</p>}
                </div>
              </>
            )}

            {requiresMfa && (
              <div>
                <label className="label">Authentication Code</label>
                <input {...register('mfaToken')} className="input text-center text-xl tracking-widest" placeholder="000000" maxLength={6} autoFocus />
                <p className="text-slate-500 text-xs mt-1.5">Enter the 6-digit code from your authenticator app</p>
              </div>
            )}

            <button type="submit" disabled={isSubmitting} className="btn-primary w-full justify-center py-2.5 mt-2">
              {isSubmitting ? <Loader2 size={16} className="animate-spin" /> : null}
              {isSubmitting ? 'Signing in...' : requiresMfa ? 'Verify Code' : 'Sign In'}
            </button>
          </form>
        </div>

        <p className="text-center text-slate-500 text-xs mt-6">Protected by CIMS Security ∙ TLS 1.3</p>
      </div>
    </div>
  );
}