import { useQuery } from '@tanstack/react-query';
import { api } from '../services/api';
import { FileSearch, Package, BarChart3, Activity, TrendingUp, CheckCircle2, AlertTriangle, Clock } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const mockActivity = [
  { time: '00:00', enquiries: 12 }, { time: '04:00', enquiries: 8 },
  { time: '08:00', enquiries: 45 }, { time: '12:00', enquiries: 89 },
  { time: '16:00', enquiries: 67 }, { time: '20:00', enquiries: 34 },
];

const StatCard = ({ title, value, change, icon: Icon, color }: any) => (
  <div className="card p-5">
    <div className="flex items-start justify-between">
      <div>
        <p className="text-sm text-slate-500 font-medium">{title}</p>
        <p className="text-2xl font-bold text-slate-900 mt-1">{value}</p>
        {change && <p className={`text-xs mt-1 ${change > 0 ? 'text-success-600' : 'text-danger-600'}`}>{change > 0 ? '+' : ''}{change}% vs yesterday</p>}
      </div>
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${color}`}>
        <Icon size={18} className="text-white" />
      </div>
    </div>
  </div>
);

const SystemStatus = ({ name, status }: { name: string; status: 'healthy' | 'degraded' | 'down' }) => (
  <div className="flex items-center justify-between py-2">
    <span className="text-sm text-slate-700">{name}</span>
    <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${status === 'healthy' ? 'badge-active' : status === 'degraded' ? 'badge-pending' : 'badge-error'}`}>
      {status}
    </span>
  </div>
);

export function DashboardPage() {
  const { data: batchJobs } = useQuery({ queryKey: ['batch-jobs'], queryFn: async () => { const { data } = await api.get('/batch/jobs'); return data; }, refetchInterval: 30000 });

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-slate-900">Dashboard</h1>
        <p className="text-sm text-slate-500 mt-0.5">System overview and operational metrics</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <StatCard title="Bureau Enquiries Today" value="1,284" change={12.4} icon={FileSearch} color="bg-primary-600" />
        <StatCard title="Active Batch Jobs" value={batchJobs?.jobs?.filter((j: any) => j.status === 'running').length ?? '0'} icon={Package} color="bg-warning-500" />
        <StatCard title="MCRA Assessments" value="342" change={-3.1} icon={BarChart3} color="bg-purple-600" />
        <StatCard title="System Uptime" value="99.97%" icon={Activity} color="bg-success-600" />
      </div>

      {/* Charts + Status */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Activity Chart */}
        <div className="xl:col-span-2 card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold text-slate-900">Enquiry Activity (24h)</h2>
            <span className="badge-active">Live</span>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={mockActivity}>
              <defs>
                <linearGradient id="enquiryGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2563eb" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#2563eb" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="time" tick={{ fontSize: 12, fill: '#64748b' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12, fill: '#64748b' }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)' }} />
              <Area type="monotone" dataKey="enquiries" stroke="#2563eb" strokeWidth={2} fill="url(#enquiryGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* System Status */}
        <div className="card p-5">
          <h2 className="text-sm font-semibold text-slate-900 mb-4">System Status</h2>
          <div className="divide-y divide-slate-100">
            <SystemStatus name="Auth Service" status="healthy" />
            <SystemStatus name="Bureau Service" status="healthy" />
            <SystemStatus name="Batch Service" status="healthy" />
            <SystemStatus name="MCRA Service" status="healthy" />
            <SystemStatus name="Primary DB" status="healthy" />
            <SystemStatus name="Standby DB" status="healthy" />
            <SystemStatus name="Kong IAG" status="healthy" />
            <SystemStatus name="ICLNET2 Gateway" status="healthy" />
            <SystemStatus name="TransUnion Socket" status="healthy" />
            <SystemStatus name="MinIO Storage" status="healthy" />
          </div>
        </div>
      </div>

      {/* Recent Batch Jobs */}
      <div className="card">
        <div className="px-5 py-4 border-b border-slate-100">
          <h2 className="text-sm font-semibold text-slate-900">Recent Batch Jobs</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50">
                <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Job Name</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Type</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Status</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Records</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Completed</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {batchJobs?.jobs?.slice(0, 5).map((job: any) => (
                <tr key={job.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-5 py-3 font-medium text-slate-900">{job.job_name}</td>
                  <td className="px-5 py-3 text-slate-600 font-mono text-xs">{job.job_type}</td>
                  <td className="px-5 py-3">
                    <span className={job.status === 'completed' ? 'badge-active' : job.status === 'running' ? 'badge-pending' : 'badge-error'}>{job.status}</span>
                  </td>
                  <td className="px-5 py-3 text-slate-600">{job.processed_records ?? 0} / {job.total_records ?? 0}</td>
                  <td className="px-5 py-3 text-slate-500 text-xs">{job.completed_at ? new Date(job.completed_at).toLocaleString() : '—'}</td>
                </tr>
              )) || (
                <tr><td colSpan={5} className="px-5 py-8 text-center text-slate-400">No recent jobs</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}