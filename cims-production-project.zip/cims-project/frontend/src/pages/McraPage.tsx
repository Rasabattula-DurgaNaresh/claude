export function McraPage() {
  return (
    <div className="p-6">
      <h1 className="text-xl font-bold text-slate-900">MCRA</h1>
      <p className="text-sm text-slate-500 mt-1">Multi-Credit Risk Assessment portal</p>
      <div className="card p-12 mt-6 text-center">
        <p className="text-slate-400">Module content renders here</p>
      </div>
    </div>
  );
}
