# CIMS — Credit Information Management System

Production-ready microservices platform for credit information management.

## Architecture

```
Internet
  └── Nginx LB (443/80)
        └── Kong IAG (API Gateway)
              ├── Auth Service    (JWT, MFA, OAuth)
              ├── Bureau Service  (Credit enquiries, MinIO file storage)
              ├── Batch Service   (Scheduled jobs, downstream dispatch)
              └── MCRA Service    (Risk assessment, external system calls)

Databases:
  ├── Primary PostgreSQL  (read/write)
  └── Standby PostgreSQL  (read-only replica)

Object Storage:  MinIO (documents & files)
Cache/Sessions:  Redis
API Gateway:     Kong IAG (internal), Kong OAG/EAG (ICLNET2)

External Systems (via ICLNET2 leased line):
  ├── CRP          (Credit Risk Platform)
  ├── OneConnect   (via Kong OAG)
  └── TransUnion   (socket connection via Kong EAG)

Downstream Systems (batch dispatch):
  ICM, RLS, PDW, RDS, CCMS, PROBE, OAMS, EDMP, ECARS, Business Report Server

External Clients:
  RTOB, COS, Jocata → Kong IAG

Monitoring:
  Prometheus + Grafana
```

## Quick Start

```bash
# 1. Copy and configure environment
make setup-env
vim .env   # fill in all secrets

# 2. Build all Docker images
make build

# 3. Start all services
make up

# 4. Check health
make health

# 5. View logs
make logs
```

## Service Ports

| Service | Internal Port | Exposed |
|---------|--------------|---------|
| Nginx LB | 80/443 | 80/443 |
| Kong IAG Proxy | 8000/8443 | 8000/8443 |
| Kong Admin | 8001 | 8001 |
| Auth Service | 3001 | — |
| Bureau Service | 3002 | — |
| Batch Service | 3003 | — |
| MCRA Service | 3004 | — |
| Primary DB | 5432 | 5432 |
| Redis | 6379 | — |
| MinIO API | 9000 | 9000 |
| MinIO Console | 9001 | 9001 |
| Prometheus | 9090 | 9090 |
| Grafana | 3000 | 3000 |

## API Endpoints

### Auth
```
POST /api/auth/login         — Login (returns JWT)
POST /api/auth/refresh       — Refresh access token
POST /api/auth/logout        — Revoke session
GET  /api/auth/me            — Get current user
POST /api/auth/mfa/enable    — Enable MFA
POST /api/auth/mfa/verify    — Verify MFA token
POST /api/auth/change-password
```

### Bureau
```
POST /api/bureau/enquiry          — Submit credit enquiry
GET  /api/bureau/enquiry/:id      — Get enquiry result
POST /api/bureau/batch-enquiry    — Bulk enquiry (max 100)
GET  /api/bureau/report/:subjectId
POST /api/bureau/upload           — Upload document to MinIO
GET  /api/bureau/files/:entityId  — List files
```

### Batch
```
GET  /api/batch/jobs              — List jobs
GET  /api/batch/jobs/:id          — Job detail
POST /api/batch/trigger           — Trigger manual job
POST /api/batch/cancel/:id        — Cancel pending job
```

### MCRA
```
POST /api/mcra/assess                — Submit risk assessment
POST /api/mcra/transunion/query      — Query TransUnion (socket)
POST /api/mcra/crp/submit            — Submit to CRP
POST /api/mcra/oneconnect/lookup     — Lookup via OneConnect
GET  /api/mcra/assessment/:id        — Get assessment
```

## Security

- All endpoints protected by JWT (except /auth/login, /auth/refresh, /health)
- MFA support via TOTP (Google Authenticator compatible)
- Account lockout after 5 failed attempts (15 min)
- Rate limiting at Kong IAG layer
- TLS 1.2/1.3 enforced at Nginx
- All secrets via environment variables (never in code)
- Audit log for all sensitive operations
- RBAC via user roles

## Connectivity Notes (per diagram)

1. Existing connectivity maintained — no changes to current integrations
2. MCRA microservice connects to CRP on ICLNET2 leased line
3. MCRA microservice connects to OneConnect and NOVA on ICLNET2 leased line
4. TransUnion connected via socket through ICLNET2 Kong EAG (not API)

## Development

```bash
cd services/auth && npm run dev
cd services/bureau && npm run dev
cd services/batch && npm run dev
cd services/mcra && npm run dev
cd frontend && npm run dev
```
