-- CIMS Database Schema

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ─── USERS & AUTH ─────────────────────────────────────────────
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'user',
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    mfa_enabled BOOLEAN DEFAULT false,
    mfa_secret VARCHAR(255),
    last_login TIMESTAMPTZ,
    failed_attempts INTEGER DEFAULT 0,
    locked_until TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE refresh_tokens (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    token_hash VARCHAR(255) NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    revoked BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── AUDIT LOG ────────────────────────────────────────────────
CREATE TABLE audit_log (
    id BIGSERIAL PRIMARY KEY,
    user_id UUID REFERENCES users(id),
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(100),
    entity_id VARCHAR(255),
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_audit_user_id ON audit_log(user_id);
CREATE INDEX idx_audit_created_at ON audit_log(created_at);
CREATE INDEX idx_audit_entity ON audit_log(entity_type, entity_id);

-- ─── CREDIT INFORMATION ───────────────────────────────────────
CREATE TABLE credit_subjects (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    subject_type VARCHAR(20) NOT NULL CHECK (subject_type IN ('individual','corporate')),
    national_id VARCHAR(50) UNIQUE,
    company_reg_no VARCHAR(50),
    full_name VARCHAR(500) NOT NULL,
    date_of_birth DATE,
    address JSONB,
    contact JSONB,
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE credit_reports (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    subject_id UUID REFERENCES credit_subjects(id),
    report_type VARCHAR(50) NOT NULL,
    source VARCHAR(50) NOT NULL,
    score INTEGER,
    data JSONB NOT NULL,
    bureau_ref VARCHAR(255),
    fetched_at TIMESTAMPTZ DEFAULT NOW(),
    expires_at TIMESTAMPTZ,
    created_by UUID REFERENCES users(id)
);

CREATE INDEX idx_credit_subjects_national_id ON credit_subjects(national_id);
CREATE INDEX idx_credit_reports_subject_id ON credit_reports(subject_id);
CREATE INDEX idx_credit_reports_fetched_at ON credit_reports(fetched_at);

-- ─── BATCH JOBS ───────────────────────────────────────────────
CREATE TABLE batch_jobs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_name VARCHAR(100) NOT NULL,
    job_type VARCHAR(50) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    total_records INTEGER DEFAULT 0,
    processed_records INTEGER DEFAULT 0,
    failed_records INTEGER DEFAULT 0,
    parameters JSONB,
    result JSONB,
    error_message TEXT,
    scheduled_at TIMESTAMPTZ,
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_batch_jobs_status ON batch_jobs(status);
CREATE INDEX idx_batch_jobs_job_type ON batch_jobs(job_type);

-- ─── FILE TRACKING ────────────────────────────────────────────
CREATE TABLE files (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    original_name VARCHAR(500) NOT NULL,
    stored_name VARCHAR(500) NOT NULL,
    bucket VARCHAR(100) NOT NULL,
    mime_type VARCHAR(100),
    size_bytes BIGINT,
    checksum VARCHAR(64),
    uploaded_by UUID REFERENCES users(id),
    entity_type VARCHAR(100),
    entity_id UUID,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── DOWNSTREAM INTEGRATION LOG ───────────────────────────────
CREATE TABLE integration_log (
    id BIGSERIAL PRIMARY KEY,
    system_name VARCHAR(100) NOT NULL,
    request_id VARCHAR(255),
    direction VARCHAR(10) CHECK (direction IN ('outbound','inbound')),
    endpoint VARCHAR(500),
    method VARCHAR(10),
    request_payload JSONB,
    response_payload JSONB,
    status_code INTEGER,
    duration_ms INTEGER,
    success BOOLEAN,
    error_message TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_integration_log_system ON integration_log(system_name);
CREATE INDEX idx_integration_log_created ON integration_log(created_at);

-- ─── UPDATED_AT TRIGGER ───────────────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = NOW(); RETURN NEW; END; $$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_credit_subjects_updated_at BEFORE UPDATE ON credit_subjects FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ─── INITIAL ADMIN USER (CHANGE PASSWORD IMMEDIATELY) ─────────
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin', 'admin@cims.internal', crypt('ChangeMe123!', gen_salt('bf', 12)), 'admin');
