/**
 * TOPIC 15: Map - Complete Reference
 * ====================================
 * HashMap: O(1) avg, unordered, 1 null key, load factor=0.75
 * LinkedHashMap: insertion/access order, O(1)
 * TreeMap: sorted keys, O(log n), no null key
 * ConcurrentHashMap: thread-safe, high performance (Java 5+)
 * Hashtable: legacy, synchronized, no null key/value
 * EnumMap: fast map with enum keys
 * WeakHashMap: keys collected by GC when no other reference
 */
import java.util.*;
import java.util.stream.*;

public class CollectionsMapComplete {

    public static void main(String[] args) {

        // ============================================================
        // HASHMAP - COMPLETE OPERATIONS
        // ============================================================
        System.out.println("=== HASHMAP ===");
        Map<String, Integer> scores = new HashMap<>();
        scores.put("Alice", 95); scores.put("Bob", 87);
        scores.put("Charlie", 92); scores.put("Diana", 88);
        scores.put("Alice", 98);          // overwrites Alice's score
        scores.putIfAbsent("Eve", 75);    // only if not exists
        System.out.println("Scores: " + scores);

        // Access
        System.out.println("get(Alice):           " + scores.get("Alice"));
        System.out.println("getOrDefault(Frank,0):" + scores.getOrDefault("Frank", 0));
        System.out.println("containsKey(Bob):     " + scores.containsKey("Bob"));
        System.out.println("containsValue(92):    " + scores.containsValue(92));
        System.out.println("size:                 " + scores.size());

        // Iteration methods
        System.out.println("\nEntry Set iteration:");
        for (Map.Entry<String, Integer> entry : scores.entrySet()) {
            System.out.printf("  %-8s -> %d%n", entry.getKey(), entry.getValue());
        }
        System.out.println("Key Set:   " + scores.keySet());
        System.out.println("Values:    " + new ArrayList<>(scores.values()));
        scores.forEach((k, v) -> System.out.println("  forEach: " + k + "=" + v));

        // Compute operations (Java 8+)
        scores.computeIfPresent("Bob", (k, v) -> v + 5);    // update if exists
        scores.computeIfAbsent("Frank", k -> k.length() * 10); // add if absent
        scores.compute("Charlie", (k, v) -> v == null ? 50 : v + 10); // always compute
        scores.merge("Alice", 5, Integer::sum);               // merge value
        scores.replace("Diana", 88, 90);                     // conditional replace
        scores.replace("Eve", 99);                           // unconditional replace
        System.out.println("\nAfter compute ops: " + scores);

        // Remove
        scores.remove("Frank");
        scores.remove("Eve", 100);  // only removes if value matches
        System.out.println("After removes: " + scores);

        // ============================================================
        // LINKEDHASHMAP
        // ============================================================
        System.out.println("\n=== LINKEDHASHMAP ===");
        // Insertion order
        Map<String, String> capitals = new LinkedHashMap<>();
        capitals.put("India",   "New Delhi");
        capitals.put("USA",     "Washington D.C.");
        capitals.put("UK",      "London");
        capitals.put("Japan",   "Tokyo");
        capitals.put("Germany", "Berlin");
        capitals.put("France",  "Paris");
        System.out.println("Insertion order preserved:");
        capitals.forEach((k, v) -> System.out.println("  " + k + " -> " + v));

        // Access-order LRU Cache (accessOrder=true)
        Map<Integer, String> lruCache = new LinkedHashMap<>(16, 0.75f, true) {
            @Override protected boolean removeEldestEntry(Map.Entry<Integer,String> eldest) {
                return size() > 3;  // evict when cache exceeds 3
            }
        };
        lruCache.put(1, "one"); lruCache.put(2, "two"); lruCache.put(3, "three");
        System.out.println("\nLRU cache (max 3): " + lruCache);
        lruCache.get(1);   // access 1 -> moves to end
        lruCache.put(4, "four");  // evicts LRU (which is 2 now)
        System.out.println("After access(1) and put(4): " + lruCache);

        // ============================================================
        // TREEMAP
        // ============================================================
        System.out.println("\n=== TREEMAP ===");
        TreeMap<String, Integer> treeMap = new TreeMap<>(scores);
        System.out.println("Sorted keys: " + treeMap);
        System.out.println("firstKey:    " + treeMap.firstKey());
        System.out.println("lastKey:     " + treeMap.lastKey());
        System.out.println("headMap(<Charlie): " + treeMap.headMap("Charlie"));
        System.out.println("tailMap(>=Charlie):" + treeMap.tailMap("Charlie"));
        System.out.println("subMap(B,D):       " + treeMap.subMap("B", "D"));
        System.out.println("floorKey(B):       " + treeMap.floorKey("B"));
        System.out.println("ceilingKey(B):     " + treeMap.ceilingKey("B"));
        System.out.println("lowerKey(Charlie): " + treeMap.lowerKey("Charlie"));
        System.out.println("higherKey(Charlie):" + treeMap.higherKey("Charlie"));
        System.out.println("firstEntry:        " + treeMap.firstEntry());
        System.out.println("lastEntry:         " + treeMap.lastEntry());
        System.out.println("pollFirstEntry:    " + treeMap.pollFirstEntry()); // removes first
        System.out.println("pollLastEntry:     " + treeMap.pollLastEntry());  // removes last
        System.out.println("After polls:       " + treeMap);

        // Reverse order TreeMap
        TreeMap<Integer, String> reversed = new TreeMap<>(Comparator.reverseOrder());
        reversed.put(3,"three"); reversed.put(1,"one"); reversed.put(2,"two"); reversed.put(5,"five");
        System.out.println("Reverse sorted: " + reversed);

        // ============================================================
        // PRACTICAL: WORD FREQUENCY
        // ============================================================
        System.out.println("\n=== WORD FREQUENCY ===");
        String text = "to be or not to be that is the question whether tis nobler to suffer";
        Map<String, Integer> freq = new HashMap<>();
        for (String word : text.split(" ")) {
            freq.merge(word, 1, Integer::sum);
        }
        System.out.println("All frequencies: " + new TreeMap<>(freq));

        // Top 5 words
        System.out.println("Top 5 words:");
        freq.entrySet().stream()
            .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
            .limit(5)
            .forEach(e -> System.out.printf("  %-12s: %d%n", e.getKey(), e.getValue()));

        // ============================================================
        // PRACTICAL: GROUP & AGGREGATE (equivalent to SQL GROUP BY)
        // ============================================================
        System.out.println("\n=== GROUP BY OPERATIONS ===");
        record Employee(String name, String dept, double salary) {}
        List<Employee> employees = Arrays.asList(
            new Employee("Alice",   "Engineering", 95000),
            new Employee("Bob",     "Marketing",   75000),
            new Employee("Charlie", "Engineering", 85000),
            new Employee("Diana",   "HR",          65000),
            new Employee("Eve",     "Marketing",   80000),
            new Employee("Frank",   "Engineering", 105000)
        );

        // Group by department
        Map<String, List<Employee>> byDept = employees.stream()
            .collect(Collectors.groupingBy(Employee::dept));
        byDept.forEach((dept, emps) -> {
            System.out.printf("  %-15s: %s%n", dept,
                emps.stream().map(Employee::name).collect(Collectors.joining(", ")));
        });

        // Avg salary by dept
        System.out.println("\nAvg salary by dept:");
        employees.stream()
            .collect(Collectors.groupingBy(Employee::dept, Collectors.averagingDouble(Employee::salary)))
            .entrySet().stream()
            .sorted(Map.Entry.<String,Double>comparingByValue().reversed())
            .forEach(e -> System.out.printf("  %-15s: Rs %.0f%n", e.getKey(), e.getValue()));

        // Count by dept
        System.out.println("\nCount by dept:");
        employees.stream()
            .collect(Collectors.groupingBy(Employee::dept, Collectors.counting()))
            .forEach((dept, cnt) -> System.out.printf("  %-15s: %d employees%n", dept, cnt));

        // ============================================================
        // NESTED MAPS
        // ============================================================
        System.out.println("\n=== NESTED MAP (Student-Subject-Marks) ===");
        Map<String, Map<String, Integer>> marks = new LinkedHashMap<>();
        marks.put("Alice", Map.of("Math", 95, "Science", 88, "English", 92));
        marks.put("Bob",   Map.of("Math", 78, "Science", 85, "English", 70));
        marks.put("Charlie",Map.of("Math", 90, "Science", 75, "English", 88));

        marks.forEach((student, subjectMarks) -> {
            double avg = subjectMarks.values().stream().mapToInt(Integer::intValue).average().orElse(0);
            System.out.printf("  %-10s: marks=%s avg=%.1f%n", student, subjectMarks, avg);
        });

        // ============================================================
        // MAP.OF / MAP.COPYOF (Java 9+)
        // ============================================================
        System.out.println("\n=== IMMUTABLE MAPS (Java 9+) ===");
        Map<String, Integer> immutable = Map.of("A",1, "B",2, "C",3, "D",4);
        System.out.println("Map.of: " + immutable);

        Map<String, Integer> entries = Map.ofEntries(
            Map.entry("Alice", 100),
            Map.entry("Bob",   200),
            Map.entry("Carol", 300)
        );
        System.out.println("Map.ofEntries: " + entries);

        Map<String, Integer> mutableCopy = new HashMap<>(immutable);
        mutableCopy.put("E", 5);
        System.out.println("Mutable copy + E: " + mutableCopy);

        try { immutable.put("X", 10); }
        catch (UnsupportedOperationException e) { System.out.println("Map.of is immutable!"); }
    }
}
