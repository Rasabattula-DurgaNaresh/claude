# ☕ Java Core Concepts - Complete Learning Package

A comprehensive, in-depth Java reference with **50+ programs** covering every core concept.

## 📁 Folder Structure

| Folder | Topic | Files |
|--------|-------|-------|
| `01_Basics` | Hello World, Data Types, Variables | 3 files |
| `02_Operators` | All Operators, Precedence, Bitwise | 1 file |
| `03_ControlFlow` | If-Else, Switch, Loops, Labels | 2 files |
| `04_Arrays` | 1D/2D/Jagged, Sorting, Searching | 1 file |
| `05_Strings` | String Pool, StringBuilder, Java11+ | 1 file |
| `06_OOP_Classes` | Classes, Objects, Constructors, Overloading | 2 files |
| `07_OOP_Inheritance` | extends, super, Multilevel, Hierarchical | 1 file |
| `08_OOP_Polymorphism` | Runtime/Compile-time, Upcasting, Dispatch | 1 file |
| `09_OOP_Abstraction` | Abstract Classes, Interfaces | 1 file |
| `10_OOP_Encapsulation` | Access Control, Validation, Immutable, Builder | 1 file |
| `11_Interfaces` | Default/Static methods, Functional, Comparable | 1 file |
| `12_InnerClasses` | Member, Static Nested, Local, Anonymous | 1 file |
| `13_ExceptionHandling` | try-catch-finally, Custom Exceptions, Chaining | 1 file |
| `14_Collections_List` | ArrayList, LinkedList, Collections utility | 1 file |
| `15_Collections_Map` | HashMap, TreeMap, LinkedHashMap, groupingBy | 1 file |
| `16_Collections_Set` | HashSet, TreeSet, PriorityQueue, ArrayDeque | 1 file |
| `17_Collections_Queue` | BlockingQueue, ConcurrentHashMap, Producer-Consumer | 1 file |
| `18_Generics` | Generic classes, methods, wildcards, PECS | 1 file |
| `19_Lambdas` | Lambda syntax, Functional interfaces, Method refs | 1 file |
| `20_StreamAPI` | filter/map/flatMap, Collectors, parallel, Optional | 1 file |
| `21_Multithreading` | Thread, Executor, CompletableFuture, Atomic | 1 file |
| `22_FileIO` | BufferedReader/Writer, NIO Files, CSV, Binary | 1 file |
| `23_Serialization` | Serializable, transient, Externalizable, Deep Copy | 1 file |
| `24_JDBC_Concepts` | JDBC steps, DAO pattern, Transactions, Pool | 1 file |
| `25_DesignPatterns_Creational` | Singleton, Factory, Builder, Prototype | 1 file |
| `26_DesignPatterns_Structural` | Adapter, Decorator, Facade, Proxy, Composite | 1 file |
| `27_DesignPatterns_Behavioral` | Observer, Strategy, Command, State, Chain | 1 file |
| `28_Java8_Features` | Date-Time API, Optional, Collectors, Streams | 1 file |
| `29_Java9to21_Features` | Records, Sealed Classes, var, Switch Expr, Virtual Threads | 1 file |
| `30_DataStructures` | Dynamic Array, LinkedList, BST, Graph, Heap | 1 file |
| `31_Algorithms` | Sorting, Searching, Dynamic Programming, Math | 1 file |
| `32_Practice_Programs` | 50 classic problems: strings, arrays, numbers, OOP | 1 file |
| `00_StudyMaterial` | Complete Java study guide (markdown) | 1 file |

## 🚀 How to Run

```bash
# Compile
javac 01_Basics/HelloWorld.java

# Run
java -cp 01_Basics HelloWorld

# Or with records/modern syntax (Java 16+)
java --enable-preview -cp . ClassName
```

## 📚 Learning Path

**Beginner** → Start with 01-05 (Basics, Operators, Flow, Arrays, Strings)

**OOP** → Topics 06-12 (Classes through Inner Classes)

**Intermediate** → Topics 13-18 (Exceptions, Collections, Generics)

**Advanced** → Topics 19-23 (Lambdas, Streams, Threads, IO)

**Expert** → Topics 24-31 (JDBC, Patterns, Data Structures, Algorithms)

**Practice** → Topic 32 (50 classic programs)

## 💡 Key Java Concepts at a Glance

```
Primitive Types: byte short int long float double boolean char
Object Creation: ClassName obj = new ClassName(args);
Inheritance:     class Child extends Parent {}
Interface:       class MyClass implements Interface1, Interface2 {}
Lambda:          (params) -> expression
Stream:          list.stream().filter(...).map(...).collect(...)
Optional:        Optional.of(val).map(...).orElse(default)
Records:         record Point(int x, int y) {}
Sealed:          sealed interface Shape permits Circle, Rect {}
```

## 📝 Java Quick Reference

| Concept | Syntax |
|---------|--------|
| Array | `int[] arr = new int[10];` |
| ArrayList | `List<String> list = new ArrayList<>();` |
| HashMap | `Map<K,V> map = new HashMap<>();` |
| Stream filter | `list.stream().filter(x -> x > 0)` |
| Lambda | `Runnable r = () -> System.out.println("hi");` |
| Try-with-resources | `try (Connection c = ...) { ... }` |
| Optional | `Optional.ofNullable(val).orElse("default")` |
| Thread | `new Thread(() -> {...}).start();` |

---
*Generated as a comprehensive Java Core Concepts learning package*
