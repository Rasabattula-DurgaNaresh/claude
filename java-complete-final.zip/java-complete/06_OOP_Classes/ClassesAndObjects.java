/**
 * TOPIC 06: OOP - Classes, Objects, Constructors
 * ================================================
 * Class = blueprint/template  |  Object = instance of class
 * Fields (attributes), Methods (behavior), Constructors
 * Constructor: same name as class, no return type, auto-called at object creation
 * this: current object reference
 * static: belongs to class (not instance), shared by all objects
 * toString / equals / hashCode: best practice to override
 */
public class ClassesAndObjects {

    // ============================================================
    // COMPLETE BankAccount CLASS
    // ============================================================
    static class BankAccount {
        // Instance fields
        private final String accountId;
        private final String holderName;
        private double       balance;
        private int          transactions;

        // Class (static) field
        private static int   totalAccounts = 0;
        private static double totalDeposited = 0;

        // ---- Constructors ----
        // No-arg constructor
        public BankAccount() {
            this("ACC" + (++totalAccounts), "Anonymous", 0.0);
        }

        // Parameterized constructor (primary)
        public BankAccount(String id, String name, double initialBalance) {
            if (initialBalance < 0) throw new IllegalArgumentException("Balance cannot be negative");
            this.accountId   = id;
            this.holderName  = name;
            this.balance     = initialBalance;
            this.transactions = 0;
            totalAccounts++;
            totalDeposited   += initialBalance;
        }

        // Copy constructor
        public BankAccount(BankAccount other) {
            this(other.accountId + "_COPY", other.holderName, other.balance);
        }

        // ---- Instance Methods ----
        public boolean deposit(double amount) {
            if (amount <= 0) { System.out.println("Invalid deposit amount"); return false; }
            balance += amount;
            transactions++;
            totalDeposited += amount;
            System.out.printf("  Deposited Rs %.2f | Balance: Rs %.2f%n", amount, balance);
            return true;
        }

        public boolean withdraw(double amount) {
            if (amount <= 0)    { System.out.println("  Invalid amount"); return false; }
            if (amount > balance){ System.out.println("  Insufficient funds"); return false; }
            balance -= amount;
            transactions++;
            System.out.printf("  Withdrew Rs %.2f | Balance: Rs %.2f%n", amount, balance);
            return true;
        }

        public void transfer(BankAccount target, double amount) {
            System.out.printf("  Transfer Rs %.2f from %s to %s%n", amount, accountId, target.accountId);
            if (withdraw(amount)) target.deposit(amount);
        }

        // ---- Getters (read-only access) ----
        public String getAccountId()    { return accountId; }
        public String getHolderName()   { return holderName; }
        public double getBalance()      { return balance; }
        public int    getTransactions() { return transactions; }

        // ---- Static Methods ----
        public static int    getTotalAccounts()  { return totalAccounts; }
        public static double getTotalDeposited() { return totalDeposited; }

        // ---- Override Object methods ----
        @Override
        public String toString() {
            return String.format("BankAccount[%s | %s | Rs %.2f | %d txns]",
                accountId, holderName, balance, transactions);
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj)               return true;
            if (!(obj instanceof BankAccount)) return false;
            BankAccount other = (BankAccount) obj;
            return this.accountId.equals(other.accountId);
        }

        @Override
        public int hashCode() {
            return accountId.hashCode();
        }
    }

    // ============================================================
    // SIMPLE PRODUCT CLASS
    // ============================================================
    static class Product {
        private static int nextId = 1000;
        private final int    id;
        private String name;
        private double price;
        private int    quantity;

        public Product(String name, double price, int quantity) {
            this.id       = nextId++;
            this.name     = name;
            this.price    = price;
            this.quantity = quantity;
        }

        public double totalValue() { return price * quantity; }
        public boolean sell(int qty) {
            if (qty > quantity) return false;
            quantity -= qty;
            return true;
        }
        public void restock(int qty) { quantity += qty; }

        public String getName()  { return name; }
        public double getPrice() { return price; }
        public int getQuantity() { return quantity; }
        public int getId()       { return id; }

        public void setPrice(double price) {
            if (price < 0) throw new IllegalArgumentException("Price must be >= 0");
            this.price = price;
        }

        @Override public String toString() {
            return String.format("Product{id=%d name='%s' price=%.2f qty=%d value=%.2f}",
                id, name, price, quantity, totalValue());
        }
    }

    // ============================================================
    // MAIN
    // ============================================================
    public static void main(String[] args) {

        System.out.println("=== CREATING OBJECTS ===");
        BankAccount acc1 = new BankAccount("ACC001", "Alice", 10000.0);
        BankAccount acc2 = new BankAccount("ACC002", "Bob",   5000.0);
        BankAccount acc3 = new BankAccount();         // no-arg constructor
        BankAccount acc4 = new BankAccount(acc1);     // copy constructor

        System.out.println(acc1);
        System.out.println(acc2);
        System.out.println(acc3);
        System.out.println(acc4);

        System.out.println("\n=== OPERATIONS ===");
        acc1.deposit(2000);
        acc1.withdraw(500);
        acc1.withdraw(15000);  // insufficient funds
        acc1.transfer(acc2, 3000);
        System.out.println(acc1);
        System.out.println(acc2);

        System.out.println("\n=== STATIC FIELDS ===");
        System.out.println("Total accounts created: " + BankAccount.getTotalAccounts());
        System.out.println("Total deposited: Rs " + BankAccount.getTotalDeposited());

        System.out.println("\n=== equals() & hashCode() ===");
        BankAccount dupAcc = new BankAccount("ACC001", "Impostor", 0);
        System.out.println("acc1.equals(dupAcc): " + acc1.equals(dupAcc));  // true (same id)
        System.out.println("acc1.equals(acc2):   " + acc1.equals(acc2));   // false

        System.out.println("\n=== PRODUCT CLASS ===");
        Product p1 = new Product("Laptop",  65000, 10);
        Product p2 = new Product("Phone",   25000, 50);
        Product p3 = new Product("Tablet",  35000, 25);
        System.out.println(p1);
        System.out.println(p2);
        System.out.println(p3);

        p1.sell(3);
        System.out.println("After sell 3 laptops: qty=" + p1.getQuantity() + " value=" + p1.totalValue());
        p2.restock(20);
        System.out.println("After restock phones: qty=" + p2.getQuantity());
        p3.setPrice(32000);
        System.out.println("After price change: " + p3);

        System.out.println("\n=== OBJECT CONCEPTS ===");
        System.out.println("null check: " + (acc3 != null ? "not null" : "null"));
        System.out.println("instanceof: " + (acc1 instanceof BankAccount));
        System.out.println("getClass:   " + acc1.getClass().getSimpleName());
        System.out.println("hashCode:   " + acc1.hashCode());
    }
}
