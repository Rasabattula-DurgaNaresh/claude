/**
 * TOPIC 06: Method Overloading (Compile-Time Polymorphism)
 * =========================================================
 * Same method name, different parameter list (type/count/order)
 * Return type ALONE cannot distinguish overloaded methods
 * Constructor overloading: multiple constructors with different params
 * Type promotion: Java auto-promotes when no exact match
 */
public class MethodOverloading {

    // ---- Overloaded Math Operations ----
    static int    add(int a, int b)            { return a + b; }
    static int    add(int a, int b, int c)     { return a + b + c; }
    static long   add(long a, long b)          { return a + b; }
    static double add(double a, double b)      { return a + b; }
    static String add(String a, String b)      { return a + b; }  // concatenation
    static double add(int a, double b)         { return a + b; }
    static double add(double a, int b)         { return a + b; }

    // ---- Overloaded print ----
    static void display(int n)        { System.out.println("int:     " + n); }
    static void display(double d)     { System.out.println("double:  " + d); }
    static void display(String s)     { System.out.println("String:  " + s); }
    static void display(boolean b)    { System.out.println("boolean: " + b); }
    static void display(char c)       { System.out.println("char:    " + c); }
    static void display(int a, int b) { System.out.println("two ints: " + a + ", " + b); }

    // ---- Overloaded Area (geometry) ----
    static double area(double radius)              { return Math.PI * radius * radius; }         // circle
    static double area(double length, double width){ return length * width; }                     // rectangle
    static double area(double a, double b, double c) {                                            // triangle (Heron's)
        double s = (a + b + c) / 2;
        return Math.sqrt(s * (s-a) * (s-b) * (s-c));
    }

    // ---- Overloaded search ----
    static int search(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) if (arr[i] == target) return i;
        return -1;
    }
    static int search(String[] arr, String target) {
        for (int i = 0; i < arr.length; i++) if (arr[i].equals(target)) return i;
        return -1;
    }

    // ---- Constructor Overloading (Rectangle) ----
    static class Rectangle {
        double width, height;
        String color;

        Rectangle()                              { this(1.0, 1.0, "white"); }
        Rectangle(double side)                   { this(side, side, "white"); }
        Rectangle(double w, double h)            { this(w, h, "white"); }
        Rectangle(double w, double h, String c)  { width=w; height=h; color=c; }

        double area()      { return width * height; }
        double perimeter() { return 2 * (width + height); }
        boolean isSquare() { return width == height; }

        @Override public String toString() {
            return String.format("Rectangle[%.1fx%.1f %s area=%.2f]", width, height, color, area());
        }
    }

    public static void main(String[] args) {
        System.out.println("=== OVERLOADED ADD ===");
        System.out.println("add(3, 4)             = " + add(3, 4));
        System.out.println("add(1, 2, 3)          = " + add(1, 2, 3));
        System.out.println("add(1000L, 2000L)     = " + add(1000L, 2000L));
        System.out.println("add(1.5, 2.5)         = " + add(1.5, 2.5));
        System.out.println("add(3, 2.5)           = " + add(3, 2.5));
        System.out.println("add(\"Hello\",\" Java\")  = " + add("Hello", " Java"));

        System.out.println("\n=== OVERLOADED DISPLAY ===");
        display(42);
        display(3.14);
        display("Hello Java");
        display(true);
        display('X');
        display(10, 20);

        System.out.println("\n=== OVERLOADED AREA ===");
        System.out.printf("Circle (r=5):         %.4f%n", area(5));
        System.out.printf("Rectangle (4x6):      %.4f%n", area(4, 6));
        System.out.printf("Triangle (3,4,5):     %.4f%n", area(3, 4, 5));

        System.out.println("\n=== CONSTRUCTOR OVERLOADING ===");
        Rectangle r1 = new Rectangle();
        Rectangle r2 = new Rectangle(5.0);
        Rectangle r3 = new Rectangle(3.0, 4.0);
        Rectangle r4 = new Rectangle(3.0, 4.0, "red");
        System.out.println(r1 + " square? " + r1.isSquare());
        System.out.println(r2 + " square? " + r2.isSquare());
        System.out.println(r3 + " square? " + r3.isSquare());
        System.out.println(r4);

        System.out.println("\n=== TYPE PROMOTION ===");
        // byte -> short -> int -> long -> float -> double (automatic widening)
        byte  byt = 10;
        short sho = 20;
        display(byt);   // promoted to int -> calls display(int)
        display(sho);   // promoted to int -> calls display(int)

        System.out.println("\n=== OVERLOADED SEARCH ===");
        int[]    iArr = {3, 1, 4, 1, 5, 9, 2, 6};
        String[] sArr = {"Alice", "Bob", "Charlie"};
        System.out.println("int search(5):        " + search(iArr, 5));
        System.out.println("String search(Bob):   " + search(sArr, "Bob"));
        System.out.println("int search(99):       " + search(iArr, 99));
    }
}
