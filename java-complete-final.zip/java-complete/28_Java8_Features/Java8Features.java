/**
 * TOPIC 28: Java 8 Features - Complete Reference
 * ================================================
 * 1. Lambda Expressions (covered in topic 19)
 * 2. Stream API (covered in topic 20)
 * 3. Default & Static Interface Methods
 * 4. Optional<T>
 * 5. Date-Time API (java.time)
 * 6. Method References
 * 7. Functional Interfaces (java.util.function)
 * 8. Collectors, groupingBy, etc.
 * 9. Map.computeIfAbsent, merge, forEach
 * 10. CompletableFuture (basics)
 */
import java.util.*;
import java.util.function.*;
import java.util.stream.*;
import java.time.*;
import java.time.format.*;
import java.time.temporal.*;

public class Java8Features {
    public static void main(String[] args) {

        // ============================================================
        // DATE-TIME API (java.time) - Major Java 8 addition
        // ============================================================
        System.out.println("=== DATE-TIME API ===");

        // LocalDate, LocalTime, LocalDateTime (no timezone)
        LocalDate today = LocalDate.now();
        LocalTime now   = LocalTime.now();
        LocalDateTime dt = LocalDateTime.now();

        System.out.println("LocalDate:     " + today);
        System.out.println("LocalTime:     " + now.format(DateTimeFormatter.ofPattern("HH:mm:ss")));
        System.out.println("LocalDateTime: " + dt.format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss")));

        // Creating specific dates
        LocalDate dob  = LocalDate.of(1995, Month.JUNE, 15);
        LocalDate exam = LocalDate.of(2024, 12, 31);
        System.out.println("DOB:   " + dob + " (" + dob.getDayOfWeek() + ")");
        System.out.println("Exam:  " + exam);

        // Arithmetic
        LocalDate nextWeek = today.plusWeeks(1);
        LocalDate lastMonth = today.minusMonths(1);
        System.out.println("Next week:  " + nextWeek);
        System.out.println("Last month: " + lastMonth);

        // Period (date-based)
        Period age = Period.between(dob, today);
        System.out.printf("Age: %d years, %d months, %d days%n",
            age.getYears(), age.getMonths(), age.getDays());

        // Duration (time-based)
        LocalDateTime start = LocalDateTime.of(2024, 1, 1, 9, 0, 0);
        LocalDateTime end   = LocalDateTime.now();
        Duration dur = Duration.between(start, end);
        System.out.printf("Duration: %d days, %d hours%n", dur.toDays(), dur.toHours() % 24);

        // ZonedDateTime
        ZonedDateTime istNow = ZonedDateTime.now(ZoneId.of("Asia/Kolkata"));
        ZonedDateTime utcNow = ZonedDateTime.now(ZoneId.of("UTC"));
        ZonedDateTime nyNow  = ZonedDateTime.now(ZoneId.of("America/New_York"));
        System.out.println("IST: " + istNow.format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss z")));
        System.out.println("UTC: " + utcNow.format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss z")));
        System.out.println("NY:  " + nyNow.format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss z")));

        // Instant (machine time / epoch)
        Instant epoch = Instant.EPOCH;
        Instant nowInst = Instant.now();
        System.out.println("Epoch:   " + epoch);
        System.out.println("Now:     " + nowInst);
        System.out.println("Millis:  " + nowInst.toEpochMilli());

        // Formatting / Parsing
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        String formatted = LocalDateTime.now().format(fmt);
        LocalDateTime parsed = LocalDateTime.parse("25/12/2024 09:30", fmt);
        System.out.println("Formatted: " + formatted);
        System.out.println("Parsed:    " + parsed);

        // Temporal Adjusters
        LocalDate firstOfMonth = today.with(TemporalAdjusters.firstDayOfMonth());
        LocalDate lastOfYear   = today.with(TemporalAdjusters.lastDayOfYear());
        LocalDate nextMonday   = today.with(TemporalAdjusters.next(DayOfWeek.MONDAY));
        System.out.println("First of month: " + firstOfMonth);
        System.out.println("Last of year:   " + lastOfYear);
        System.out.println("Next Monday:    " + nextMonday);

        // Year, Month, MonthDay
        Year year = Year.now();
        System.out.println("Is leap year? " + year.isLeap());
        System.out.println("Days in 2024: " + Year.of(2024).length());

        // DateTimeFormatter.ISO_*
        System.out.println("ISO_DATE:       " + today.format(DateTimeFormatter.ISO_DATE));
        System.out.println("ISO_DATE_TIME:  " + dt.format(DateTimeFormatter.ISO_DATE_TIME));

        // ============================================================
        // DEFAULT INTERFACE METHODS
        // ============================================================
        System.out.println("\n=== DEFAULT INTERFACE METHODS ===");
        // Already covered in Interfaces topic; key examples:
        // List.sort(), Iterable.forEach(), Map.forEach()
        // Collection.removeIf(), List.replaceAll()

        List<String> fruits = new ArrayList<>(Arrays.asList("banana","apple","cherry","date"));
        fruits.sort(Comparator.naturalOrder());       // List.sort (Java 8 default)
        System.out.println("sorted: " + fruits);
        fruits.replaceAll(String::toUpperCase);       // List.replaceAll (Java 8 default)
        System.out.println("upper: " + fruits);
        fruits.removeIf(s -> s.length() < 5);        // Collection.removeIf
        System.out.println("len>=5: " + fruits);
        fruits.forEach(System.out::println);          // Iterable.forEach

        // Map defaults
        Map<String,Integer> scores = new HashMap<>(Map.of("Alice",90,"Bob",80,"Charlie",70));
        scores.computeIfAbsent("Dave", k -> 75);
        scores.computeIfPresent("Bob", (k,v) -> v + 5);
        scores.merge("Alice", 5, Integer::sum);
        scores.getOrDefault("Frank", 0);
        scores.replaceAll((k,v) -> v + 1);
        scores.forEach((k,v) -> System.out.printf("  %s: %d%n", k, v));

        // ============================================================
        // OPTIONAL
        // ============================================================
        System.out.println("\n=== OPTIONAL ===");
        Optional<String> opt1 = Optional.of("Hello");
        Optional<String> opt2 = Optional.empty();
        Optional<String> opt3 = Optional.ofNullable(null);

        System.out.println("isPresent: " + opt1.isPresent());
        System.out.println("isEmpty:   " + opt2.isEmpty());
        System.out.println("get:       " + opt1.get());
        System.out.println("orElse:    " + opt2.orElse("default"));
        System.out.println("orElseGet: " + opt3.orElseGet(() -> "computed"));

        // Chaining
        String result = Optional.ofNullable("  hello world  ")
            .map(String::trim)
            .filter(s -> s.length() > 5)
            .map(String::toUpperCase)
            .orElse("short string");
        System.out.println("chained:   " + result);

        opt1.ifPresent(s -> System.out.println("ifPresent: " + s));
        opt1.ifPresentOrElse(s -> System.out.println("present: "+s), () -> System.out.println("empty"));

        // ============================================================
        // COLLECTORS (Java 8)
        // ============================================================
        System.out.println("\n=== COLLECTORS ===");
        record Employee(String name, String dept, double salary, int age) {}
        List<Employee> emps = List.of(
            new Employee("Alice",   "Eng",       95000, 28),
            new Employee("Bob",     "Marketing", 75000, 32),
            new Employee("Charlie", "Eng",       85000, 26),
            new Employee("Diana",   "HR",        65000, 30),
            new Employee("Eve",     "Marketing", 80000, 27)
        );

        // groupingBy + downstream
        Map<String, Double> avgByDept = emps.stream()
            .collect(Collectors.groupingBy(Employee::dept, Collectors.averagingDouble(Employee::salary)));
        System.out.println("Avg salary by dept: " + avgByDept);

        Map<String, Optional<Employee>> maxByDept = emps.stream()
            .collect(Collectors.groupingBy(Employee::dept,
                Collectors.maxBy(Comparator.comparingDouble(Employee::salary))));
        maxByDept.forEach((d, e) -> System.out.println("Top in " + d + ": " + e.map(Employee::name).orElse("none")));

        // partitioningBy
        Map<Boolean, List<String>> partition = emps.stream()
            .collect(Collectors.partitioningBy(e -> e.salary() > 80000,
                Collectors.mapping(Employee::name, Collectors.toList())));
        System.out.println("High earners: " + partition.get(true));
        System.out.println("Others:       " + partition.get(false));

        // joining
        String names = emps.stream().map(Employee::name)
            .collect(Collectors.joining(", ", "[ ", " ]"));
        System.out.println("Names: " + names);

        // toMap
        Map<String, Double> nameToSalary = emps.stream()
            .collect(Collectors.toMap(Employee::name, Employee::salary));
        System.out.println("nameToSalary: " + nameToSalary);

        // statistics
        DoubleSummaryStatistics stats = emps.stream()
            .collect(Collectors.summarizingDouble(Employee::salary));
        System.out.printf("Stats: count=%d min=%.0f max=%.0f avg=%.2f sum=%.0f%n",
            stats.getCount(), stats.getMin(), stats.getMax(), stats.getAverage(), stats.getSum());

        // ============================================================
        // COMPLETABLEFUTURE BASICS
        // ============================================================
        System.out.println("\n=== COMPLETABLEFUTURE ===");
        try {
            String cfResult = java.util.concurrent.CompletableFuture
                .supplyAsync(() -> "Hello")
                .thenApply(s -> s + " World")
                .thenApply(String::toUpperCase)
                .get();
            System.out.println("CF result: " + cfResult);

            // exceptionally
            String safe = java.util.concurrent.CompletableFuture
                .supplyAsync(() -> { throw new RuntimeException("oops"); })
                .exceptionally(e -> "recovered from: " + e.getMessage())
                .get();
            System.out.println("Recovered: " + safe);
        } catch (Exception e) { e.printStackTrace(); }

        System.out.println("\nJava 8 features covered!");
    }
}
