# Java Complete Study Guide

## 1. Java Fundamentals

### Memory Model
- **Stack**: local variables, method calls, primitive values
- **Heap**: objects, arrays, class instances
- **String Pool**: interned string literals (part of heap, Java 8+)
- **Method Area**: class definitions, static variables, constants

### Data Types
| Type | Size | Range | Default |
|------|------|-------|---------|
| byte | 1B | -128 to 127 | 0 |
| short | 2B | -32768 to 32767 | 0 |
| int | 4B | ±2.1 billion | 0 |
| long | 8B | ±9.2 quintillion | 0L |
| float | 4B | ±3.4E38 | 0.0f |
| double | 8B | ±1.8E308 | 0.0 |
| boolean | 1bit | true/false | false |
| char | 2B | '\u0000' to '\uffff' | '\u0000' |

### Type Casting
```
Widening (safe):  byte → short → int → long → float → double
Narrowing (risky): double → float → long → int → short → byte
```

---

## 2. OOP Pillars

| Pillar | Keyword | Description |
|--------|---------|-------------|
| Encapsulation | private + getters/setters | Hiding internal state |
| Inheritance | extends | IS-A relationship, code reuse |
| Polymorphism | @Override | Many forms, runtime dispatch |
| Abstraction | abstract, interface | Hide complexity, show essentials |

### Access Modifiers
| Modifier | Same Class | Same Package | Subclass | Everywhere |
|----------|-----------|--------------|----------|------------|
| private | ✅ | ❌ | ❌ | ❌ |
| (default) | ✅ | ✅ | ❌ | ❌ |
| protected | ✅ | ✅ | ✅ | ❌ |
| public | ✅ | ✅ | ✅ | ✅ |

---

## 3. Collections Framework

```
Collection
├── List (ordered, duplicates allowed)
│   ├── ArrayList  – O(1) get, O(n) insert
│   └── LinkedList – O(1) insert at ends, O(n) get
├── Set (no duplicates)
│   ├── HashSet       – unordered, O(1)
│   ├── LinkedHashSet – insertion order, O(1)
│   └── TreeSet       – sorted, O(log n)
└── Queue
    ├── PriorityQueue – min-heap, O(log n)
    └── ArrayDeque    – double-ended, O(1)

Map (key-value pairs)
├── HashMap       – unordered, O(1)
├── LinkedHashMap – insertion/access order
├── TreeMap       – sorted keys, O(log n)
└── ConcurrentHashMap – thread-safe
```

---

## 4. Big O Complexity

| Operation | ArrayList | LinkedList | HashMap | TreeMap |
|-----------|-----------|------------|---------|---------|
| get(i) | O(1) | O(n) | O(1) | O(log n) |
| add(end) | O(1)* | O(1) | O(1) | O(log n) |
| add(idx) | O(n) | O(n) | - | - |
| remove | O(n) | O(n) | O(1) | O(log n) |
| contains | O(n) | O(n) | O(1) | O(log n) |
| *amortized

---

## 5. Stream API Cheat Sheet

```java
// Creation
Stream.of(1,2,3)
list.stream()
array.stream()
Stream.generate(() -> Math.random()).limit(5)
Stream.iterate(0, n -> n+1).limit(10)

// Intermediate (lazy)
.filter(predicate)
.map(function)
.flatMap(function)
.distinct()
.sorted()
.sorted(comparator)
.limit(n)
.skip(n)
.peek(consumer)

// Terminal (eager)
.forEach(consumer)
.collect(Collectors.toList())
.count()
.sum() / .average() / .min() / .max()
.reduce(identity, accumulator)
.findFirst() / .findAny()
.anyMatch() / .allMatch() / .noneMatch()
.toArray()

// Collectors
Collectors.toList()
Collectors.toSet()
Collectors.toMap(keyFn, valueFn)
Collectors.groupingBy(classifier)
Collectors.groupingBy(classifier, downstream)
Collectors.partitioningBy(predicate)
Collectors.joining(delimiter, prefix, suffix)
Collectors.counting()
Collectors.summarizingDouble(fn)
```

---

## 6. Exception Hierarchy

```
Throwable
├── Error (don't catch)
│   ├── OutOfMemoryError
│   ├── StackOverflowError
│   └── VirtualMachineError
└── Exception
    ├── Checked (must handle)
    │   ├── IOException
    │   ├── SQLException
    │   ├── ClassNotFoundException
    │   └── InterruptedException
    └── RuntimeException (unchecked)
        ├── NullPointerException
        ├── ArrayIndexOutOfBoundsException
        ├── ClassCastException
        ├── NumberFormatException
        ├── IllegalArgumentException
        └── ConcurrentModificationException
```

---

## 7. Design Patterns Summary

### Creational
- **Singleton**: one instance (double-checked locking, enum)
- **Factory**: delegate creation to subclass/method
- **Builder**: step-by-step complex object creation
- **Prototype**: clone existing objects

### Structural
- **Adapter**: bridge incompatible interfaces
- **Decorator**: add behavior dynamically
- **Facade**: simplified interface to subsystem
- **Proxy**: controlled access (lazy, security, logging)
- **Composite**: tree structure, uniform treatment

### Behavioral
- **Observer**: event notification pattern
- **Strategy**: interchangeable algorithms
- **Command**: encapsulate actions (supports undo/redo)
- **Template Method**: skeleton in base, details in subclass
- **State**: behavior changes with state
- **Chain of Responsibility**: pass through handlers

---

## 8. Multithreading Quick Reference

```java
// Create Thread
new Thread(() -> {...}).start()
new Thread(new Runnable(){}).start()

// Thread Pool
ExecutorService pool = Executors.newFixedThreadPool(4);
pool.submit(() -> {...});
pool.shutdown();

// Synchronized
synchronized(this) { ... }
public synchronized void method() { ... }

// Locks
ReentrantLock lock = new ReentrantLock();
lock.lock(); try { ... } finally { lock.unlock(); }

// Atomic
AtomicInteger count = new AtomicInteger(0);
count.incrementAndGet();
count.compareAndSet(expected, update);

// CompletableFuture
CompletableFuture.supplyAsync(() -> value)
    .thenApply(fn)
    .thenAccept(consumer)
    .exceptionally(ex -> fallback)
    .get();
```

---

## 9. Java 8-21 Features Timeline

| Version | Key Features |
|---------|-------------|
| Java 8 | Lambda, Stream API, Optional, Date-Time API, Default methods |
| Java 9 | Modules, Collection.of(), Stream.iterate() with predicate |
| Java 10 | `var` local type inference |
| Java 11 | String.strip/isBlank/repeat/lines, Files.readString/writeString |
| Java 14 | Switch expressions (stable) |
| Java 15 | Text Blocks (stable) |
| Java 16 | Records (stable), instanceof pattern matching |
| Java 17 | Sealed classes (stable), LTS |
| Java 21 | Virtual threads, Pattern matching switch, Sequenced collections, LTS |

---

## 10. Interview Cheat Sheet

```
String vs StringBuilder vs StringBuffer
  String:        immutable, pool, thread-safe
  StringBuilder: mutable, fast, NOT thread-safe
  StringBuffer:  mutable, thread-safe (synchronized)

== vs .equals()
  ==        : reference comparison (same object?)
  .equals() : value comparison (override for custom classes!)

ArrayList vs LinkedList
  ArrayList:   fast get O(1), slow insert-middle O(n)
  LinkedList:  slow get O(n), fast insert-ends O(1)

HashMap internal:
  Default capacity: 16, load factor: 0.75
  Resizes at 12 entries (16 * 0.75)
  Uses hashCode() for bucket, equals() to resolve collision
  Java 8+: tree (red-black) when bucket > 8 (O(n) → O(log n))

abstract class vs interface
  abstract class: IS-A, single inheritance, has state/constructors
  interface:      CAN-DO, multiple implementation, behavioral contract

final vs finally vs finalize
  final:     cannot change (variable, method override, class extend)
  finally:   always runs in try-catch block
  finalize:  GC callback (deprecated in Java 9+)

static: class-level, shared, no 'this', loaded once
transient: skip during serialization
volatile: visibility guarantee across threads (no caching)
synchronized: mutual exclusion (one thread at a time)
```
