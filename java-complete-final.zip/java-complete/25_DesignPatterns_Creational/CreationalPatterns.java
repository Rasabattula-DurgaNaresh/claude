/**
 * TOPIC 25: Creational Design Patterns
 * =======================================
 * 1. Singleton    : one instance, global access point
 * 2. Factory Method: delegate creation to subclasses
 * 3. Abstract Factory: families of related objects
 * 4. Builder      : step-by-step complex object construction
 * 5. Prototype    : clone existing object
 * 6. Object Pool  : reuse expensive objects
 */
import java.util.*;

public class CreationalPatterns {

    // ============================================================
    // 1. SINGLETON (Thread-safe, double-checked locking)
    // ============================================================
    static class Configuration {
        private static volatile Configuration instance;
        private final Map<String, String> settings = new HashMap<>();

        private Configuration() {
            // Load default settings
            settings.put("host",    "localhost");
            settings.put("port",    "8080");
            settings.put("db.url",  "jdbc:mysql://localhost/mydb");
            settings.put("timeout", "30");
            System.out.println("Configuration created (should see only once!)");
        }

        public static Configuration getInstance() {
            if (instance == null) {
                synchronized (Configuration.class) {
                    if (instance == null) {
                        instance = new Configuration();
                    }
                }
            }
            return instance;
        }

        public String get(String key)              { return settings.get(key); }
        public void   set(String key, String value){ settings.put(key, value); }
        public Map<String,String> getAll()          { return Collections.unmodifiableMap(settings); }
    }

    // Enum Singleton (simplest, thread-safe, serialization-safe)
    enum DatabaseSingleton {
        INSTANCE;
        private int connectionCount = 0;
        public void connect()    { connectionCount++; System.out.println("DB connected. Count: " + connectionCount); }
        public void disconnect() { connectionCount--; }
        public int getCount()    { return connectionCount; }
    }

    // ============================================================
    // 2. FACTORY METHOD
    // ============================================================
    interface Logger {
        void log(String level, String msg);
        default void info(String msg)  { log("INFO",  msg); }
        default void error(String msg) { log("ERROR", msg); }
        default void warn(String msg)  { log("WARN",  msg); }
    }

    static class ConsoleLogger implements Logger {
        public void log(String level, String msg) {
            System.out.printf("[CONSOLE][%s] %s%n", level, msg);
        }
    }
    static class FileLogger implements Logger {
        private String filename;
        public FileLogger(String f) { filename=f; }
        public void log(String level, String msg) {
            System.out.printf("[FILE:%s][%s] %s%n", filename, level, msg);
        }
    }
    static class DatabaseLogger implements Logger {
        private String table;
        public DatabaseLogger(String t) { table=t; }
        public void log(String level, String msg) {
            System.out.printf("[DB:%s][%s] %s%n", table, level, msg);
        }
    }

    // Factory
    static class LoggerFactory {
        public static Logger create(String type, String... options) {
            return switch (type.toUpperCase()) {
                case "CONSOLE"  -> new ConsoleLogger();
                case "FILE"     -> new FileLogger(options.length>0 ? options[0] : "app.log");
                case "DATABASE" -> new DatabaseLogger(options.length>0 ? options[0] : "logs");
                default -> throw new IllegalArgumentException("Unknown logger type: " + type);
            };
        }
    }

    // ============================================================
    // 3. ABSTRACT FACTORY
    // ============================================================
    interface Button    { void render(); void onClick(); }
    interface TextField { void render(); String getValue(); }
    interface UIFactory {
        Button    createButton(String label);
        TextField createTextField(String placeholder);
    }

    static class LightButton implements Button {
        private String label;
        LightButton(String l) { label=l; }
        public void render()   { System.out.println("  [LIGHT Button] " + label); }
        public void onClick()  { System.out.println("  Light button '" + label + "' clicked"); }
    }
    static class DarkButton implements Button {
        private String label;
        DarkButton(String l) { label=l; }
        public void render()   { System.out.println("  [DARK  Button] " + label); }
        public void onClick()  { System.out.println("  Dark button '" + label + "' clicked"); }
    }
    static class LightTextField implements TextField {
        private String placeholder;
        LightTextField(String p) { placeholder=p; }
        public void render()    { System.out.println("  [LIGHT TextField] _" + placeholder + "_"); }
        public String getValue(){ return "light input"; }
    }
    static class DarkTextField implements TextField {
        private String placeholder;
        DarkTextField(String p) { placeholder=p; }
        public void render()    { System.out.println("  [DARK  TextField] |" + placeholder + "|"); }
        public String getValue(){ return "dark input"; }
    }

    static class LightThemeFactory implements UIFactory {
        public Button    createButton(String l)   { return new LightButton(l); }
        public TextField createTextField(String p){ return new LightTextField(p); }
    }
    static class DarkThemeFactory implements UIFactory {
        public Button    createButton(String l)   { return new DarkButton(l); }
        public TextField createTextField(String p){ return new DarkTextField(p); }
    }

    static void renderLoginForm(UIFactory factory) {
        System.out.println("Login Form:");
        TextField user = factory.createTextField("Enter username");
        TextField pass = factory.createTextField("Enter password");
        Button    btn  = factory.createButton("Login");
        user.render(); pass.render(); btn.render();
        btn.onClick();
    }

    // ============================================================
    // 4. BUILDER
    // ============================================================
    static class QueryBuilder {
        private String table;
        private List<String> columns = new ArrayList<>();
        private List<String> conditions = new ArrayList<>();
        private String orderBy;
        private boolean orderDesc = false;
        private int limit = -1;
        private int offset = 0;

        public QueryBuilder from(String table)       { this.table=table; return this; }
        public QueryBuilder select(String... cols)   { columns.addAll(Arrays.asList(cols)); return this; }
        public QueryBuilder where(String cond)       { conditions.add(cond); return this; }
        public QueryBuilder orderBy(String col)      { this.orderBy=col; return this; }
        public QueryBuilder desc()                   { this.orderDesc=true; return this; }
        public QueryBuilder limit(int n)             { this.limit=n; return this; }
        public QueryBuilder offset(int n)            { this.offset=n; return this; }

        public String build() {
            StringBuilder sb = new StringBuilder("SELECT ");
            sb.append(columns.isEmpty() ? "*" : String.join(", ", columns));
            sb.append(" FROM ").append(table);
            if (!conditions.isEmpty()) sb.append(" WHERE ").append(String.join(" AND ", conditions));
            if (orderBy != null) sb.append(" ORDER BY ").append(orderBy).append(orderDesc ? " DESC" : "");
            if (limit > 0) sb.append(" LIMIT ").append(limit);
            if (offset > 0) sb.append(" OFFSET ").append(offset);
            return sb.toString();
        }
    }

    // ============================================================
    // 5. PROTOTYPE
    // ============================================================
    static class ConfigTemplate implements Cloneable {
        private String environment;
        private Map<String, String> settings;
        private List<String> enabledFeatures;

        public ConfigTemplate(String env) {
            this.environment = env;
            this.settings = new HashMap<>();
            this.enabledFeatures = new ArrayList<>();
        }

        public void setSetting(String k, String v) { settings.put(k, v); }
        public void enableFeature(String f)        { enabledFeatures.add(f); }
        public void setEnvironment(String e)       { environment = e; }

        @Override public ConfigTemplate clone() {
            try {
                ConfigTemplate copy = (ConfigTemplate) super.clone();
                copy.settings = new HashMap<>(this.settings);              // deep copy
                copy.enabledFeatures = new ArrayList<>(this.enabledFeatures); // deep copy
                return copy;
            } catch (CloneNotSupportedException e) {
                throw new RuntimeException(e);
            }
        }

        @Override public String toString() {
            return "Config{env=" + environment + " settings=" + settings + " features=" + enabledFeatures + "}";
        }
    }

    public static void main(String[] args) {

        System.out.println("=== 1. SINGLETON ===");
        Configuration c1 = Configuration.getInstance();
        Configuration c2 = Configuration.getInstance();
        System.out.println("Same instance? " + (c1 == c2));
        System.out.println("host: " + c1.get("host"));
        c1.set("host", "prod.server.com");
        System.out.println("host via c2: " + c2.get("host"));  // same!

        System.out.println("\nEnum Singleton:");
        DatabaseSingleton.INSTANCE.connect();
        DatabaseSingleton.INSTANCE.connect();
        System.out.println("Connections: " + DatabaseSingleton.INSTANCE.getCount());

        System.out.println("\n=== 2. FACTORY METHOD ===");
        Logger cl  = LoggerFactory.create("CONSOLE");
        Logger fl  = LoggerFactory.create("FILE", "app.log");
        Logger dbl = LoggerFactory.create("DATABASE", "system_logs");
        cl.info("App started"); cl.error("Something failed");
        fl.info("Writing to file"); fl.warn("Disk almost full");
        dbl.info("DB operation completed");

        System.out.println("\n=== 3. ABSTRACT FACTORY ===");
        System.out.println("Light Theme:");
        renderLoginForm(new LightThemeFactory());
        System.out.println("\nDark Theme:");
        renderLoginForm(new DarkThemeFactory());

        System.out.println("\n=== 4. BUILDER ===");
        String q1 = new QueryBuilder()
            .from("employees")
            .select("id", "name", "salary", "dept")
            .where("dept = 'Engineering'")
            .where("salary > 80000")
            .orderBy("salary").desc()
            .limit(10)
            .build();
        System.out.println("Query 1: " + q1);

        String q2 = new QueryBuilder()
            .from("products")
            .where("category = 'Electronics'")
            .where("price < 50000")
            .orderBy("rating").desc()
            .limit(5).offset(10)
            .build();
        System.out.println("Query 2: " + q2);

        System.out.println("\n=== 5. PROTOTYPE ===");
        ConfigTemplate baseConfig = new ConfigTemplate("base");
        baseConfig.setSetting("timeout", "30");
        baseConfig.setSetting("max-connections", "100");
        baseConfig.enableFeature("logging");
        baseConfig.enableFeature("caching");
        System.out.println("Base: " + baseConfig);

        ConfigTemplate devConfig = baseConfig.clone();
        devConfig.setEnvironment("development");
        devConfig.setSetting("debug", "true");
        devConfig.enableFeature("profiling");

        ConfigTemplate prodConfig = baseConfig.clone();
        prodConfig.setEnvironment("production");
        prodConfig.setSetting("max-connections", "1000");
        prodConfig.setSetting("timeout", "10");

        System.out.println("Dev:  " + devConfig);
        System.out.println("Prod: " + prodConfig);
        System.out.println("Base unchanged: " + baseConfig);
    }
}
