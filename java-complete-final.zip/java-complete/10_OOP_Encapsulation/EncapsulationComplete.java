/**
 * TOPIC 10: Encapsulation & Access Control
 * ==========================================
 * Encapsulation = bind data + methods, hide internal details
 * Access modifiers: private, default, protected, public
 * Getters/Setters: controlled access to private fields
 * Immutable classes: all fields final, no setters
 * Builder pattern: create complex objects step by step
 */
public class EncapsulationComplete {

    // ============================================================
    // WELL-ENCAPSULATED: Hospital Patient
    // ============================================================
    static class Patient {
        private final String patientId;
        private String       name;
        private int          age;
        private String       bloodGroup;
        private double       weight;       // kg
        private double       height;       // cm
        private String       diagnosis;
        private boolean      isAdmitted;
        private static int   nextId = 1000;

        // Constructor
        public Patient(String name, int age, String bloodGroup, double weight, double height) {
            this.patientId  = "P" + (nextId++);
            this.name       = validateName(name);
            this.age        = validateAge(age);
            this.bloodGroup = validateBloodGroup(bloodGroup);
            this.weight     = validateWeight(weight);
            this.height     = validateHeight(height);
            this.isAdmitted = false;
        }

        // Validation methods (private)
        private String validateName(String n) {
            if (n == null || n.isBlank()) throw new IllegalArgumentException("Name cannot be empty");
            return n.trim();
        }
        private int validateAge(int a) {
            if (a < 0 || a > 150) throw new IllegalArgumentException("Invalid age: " + a);
            return a;
        }
        private String validateBloodGroup(String bg) {
            java.util.Set<String> valid = java.util.Set.of("A+","A-","B+","B-","AB+","AB-","O+","O-");
            if (!valid.contains(bg)) throw new IllegalArgumentException("Invalid blood group: " + bg);
            return bg;
        }
        private double validateWeight(double w) {
            if (w < 0.5 || w > 500) throw new IllegalArgumentException("Invalid weight");
            return w;
        }
        private double validateHeight(double h) {
            if (h < 30 || h > 250) throw new IllegalArgumentException("Invalid height");
            return h;
        }

        // Business logic methods
        public double calculateBMI() {
            double heightM = height / 100;
            return weight / (heightM * heightM);
        }

        public String getBMICategory() {
            double bmi = calculateBMI();
            if (bmi < 18.5) return "Underweight";
            if (bmi < 25.0) return "Normal";
            if (bmi < 30.0) return "Overweight";
            return "Obese";
        }

        public void admit(String diagnosis) {
            if (isAdmitted) { System.out.println(name + " already admitted"); return; }
            this.diagnosis = diagnosis;
            this.isAdmitted = true;
            System.out.println(name + " admitted with: " + diagnosis);
        }

        public void discharge() {
            if (!isAdmitted) { System.out.println(name + " is not admitted"); return; }
            isAdmitted = false;
            System.out.println(name + " discharged");
        }

        // Getters (no setters for patientId - immutable!)
        public String getPatientId()  { return patientId; }
        public String getName()       { return name; }
        public int    getAge()        { return age; }
        public String getBloodGroup() { return bloodGroup; }
        public double getWeight()     { return weight; }
        public double getHeight()     { return height; }
        public boolean isAdmitted()   { return isAdmitted; }
        public String getDiagnosis()  { return isAdmitted ? diagnosis : "N/A"; }

        // Setters with validation
        public void setWeight(double w) { this.weight = validateWeight(w); }
        public void setAge(int a)       { this.age = validateAge(a); }

        @Override public String toString() {
            return String.format("Patient[%s | %s | Age:%d | %s | BMI:%.1f(%s) | Admitted:%s]",
                patientId, name, age, bloodGroup, calculateBMI(), getBMICategory(), isAdmitted);
        }
    }

    // ============================================================
    // IMMUTABLE CLASS
    // ============================================================
    static final class Money {
        private final double  amount;
        private final String  currency;

        public Money(double amount, String currency) {
            if (amount < 0) throw new IllegalArgumentException("Amount cannot be negative");
            this.amount   = amount;
            this.currency = currency.toUpperCase();
        }

        // No setters! Operations return NEW Money object
        public Money add(Money other) {
            if (!this.currency.equals(other.currency))
                throw new IllegalArgumentException("Currency mismatch: " + this.currency + " vs " + other.currency);
            return new Money(this.amount + other.amount, this.currency);
        }

        public Money subtract(Money other) {
            if (!this.currency.equals(other.currency))
                throw new IllegalArgumentException("Currency mismatch");
            return new Money(this.amount - other.amount, this.currency);
        }

        public Money multiply(double factor) { return new Money(amount * factor, currency); }
        public boolean isGreaterThan(Money other) {
            if (!currency.equals(other.currency)) throw new IllegalArgumentException("Currency mismatch");
            return this.amount > other.amount;
        }

        public double getAmount()   { return amount; }
        public String getCurrency() { return currency; }

        @Override public String toString()         { return String.format("%s %.2f", currency, amount); }
        @Override public boolean equals(Object obj){
            if (!(obj instanceof Money)) return false;
            Money m = (Money)obj;
            return this.amount == m.amount && this.currency.equals(m.currency);
        }
        @Override public int hashCode() { return java.util.Objects.hash(amount, currency); }
    }

    // ============================================================
    // BUILDER PATTERN (Encapsulated construction)
    // ============================================================
    static class Pizza {
        private final String   size;
        private final String   crust;
        private final java.util.List<String> toppings;
        private final boolean  extraCheese;
        private final boolean  isVeg;
        private final String   sauce;

        private Pizza(Builder b) {
            this.size        = b.size;
            this.crust       = b.crust;
            this.toppings    = java.util.Collections.unmodifiableList(b.toppings);
            this.extraCheese = b.extraCheese;
            this.isVeg       = b.isVeg;
            this.sauce       = b.sauce;
        }

        public double calculatePrice() {
            double price = switch (size) {
                case "SMALL"  -> 199;
                case "MEDIUM" -> 299;
                case "LARGE"  -> 399;
                default       -> 249;
            };
            price += toppings.size() * 30;
            if (extraCheese) price += 50;
            return price;
        }

        @Override public String toString() {
            return String.format("Pizza{%s %s crust=%s toppings=%s cheese=%s veg=%s price=Rs%.0f}",
                size, sauce, crust, toppings, extraCheese, isVeg, calculatePrice());
        }

        // Builder class
        static class Builder {
            private String size   = "MEDIUM";
            private String crust  = "THIN";
            private java.util.List<String> toppings = new java.util.ArrayList<>();
            private boolean extraCheese = false;
            private boolean isVeg       = true;
            private String  sauce = "TOMATO";

            public Builder size(String s)        { this.size=s.toUpperCase();  return this; }
            public Builder crust(String c)       { this.crust=c.toUpperCase(); return this; }
            public Builder addTopping(String t)  { this.toppings.add(t);       return this; }
            public Builder extraCheese()         { this.extraCheese=true;      return this; }
            public Builder nonVeg()              { this.isVeg=false;           return this; }
            public Builder sauce(String s)       { this.sauce=s.toUpperCase(); return this; }
            public Pizza build()                 { return new Pizza(this); }
        }
    }

    public static void main(String[] args) {
        System.out.println("=== PATIENT ENCAPSULATION ===");
        Patient p1 = new Patient("Alice Kumar", 28, "B+", 65.5, 165.0);
        Patient p2 = new Patient("Bob Singh",   45, "O+", 80.0, 175.0);
        System.out.println(p1);
        System.out.println(p2);

        p1.admit("Appendicitis");
        p2.admit("Hypertension");
        System.out.println("After admission:");
        System.out.println(p1);
        p1.discharge();
        System.out.println("After discharge: " + p1.isAdmitted());

        // Validation
        try { Patient bad = new Patient("X", -5, "X+", 65, 165); }
        catch (IllegalArgumentException e) { System.out.println("Validation: " + e.getMessage()); }

        System.out.println("\n=== IMMUTABLE MONEY ===");
        Money salary  = new Money(50000, "INR");
        Money bonus   = new Money(10000, "INR");
        Money tax     = new Money(8000,  "INR");
        Money net     = salary.add(bonus).subtract(tax);
        System.out.println("Salary: " + salary);
        System.out.println("Bonus:  " + bonus);
        System.out.println("Tax:    " + tax);
        System.out.println("Net:    " + net);
        System.out.println("Original unchanged: " + salary);  // still 50000!
        System.out.println("Is net > salary? " + net.isGreaterThan(salary));

        System.out.println("\n=== PIZZA BUILDER ===");
        Pizza p  = new Pizza.Builder()
            .size("Large")
            .crust("THICK")
            .sauce("BBQ")
            .addTopping("Mushrooms")
            .addTopping("Peppers")
            .addTopping("Onions")
            .extraCheese()
            .build();

        Pizza veg = new Pizza.Builder()
            .size("small")
            .addTopping("Corn")
            .addTopping("Paneer")
            .build();

        System.out.println(p);
        System.out.println(veg);
    }
}
