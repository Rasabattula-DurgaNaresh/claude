/**
 * TOPIC 20: Stream API - Complete Reference (Java 8+)
 * =====================================================
 * Stream = sequence of elements supporting pipeline operations
 * Lazy: intermediate ops don't execute until terminal op triggered
 * Non-reusable: once consumed, cannot be reused
 *
 * Sources: Collection.stream(), Arrays.stream(), Stream.of(), Stream.generate()
 * Intermediate: filter, map, flatMap, distinct, sorted, peek, limit, skip
 * Terminal: forEach, collect, reduce, count, min, max, findFirst, anyMatch
 * Collectors: toList, toSet, toMap, groupingBy, partitioningBy, joining, counting
 * Numeric streams: IntStream, LongStream, DoubleStream (no boxing overhead)
 * Parallel: collection.parallelStream() or stream.parallel()
 */
import java.util.*;
import java.util.stream.*;
import java.util.function.*;

public class StreamAPIComplete {

    record Employee(String name, String dept, double salary, int age, String city) {}

    public static void main(String[] args) {

        // ============================================================
        // STREAM CREATION
        // ============================================================
        System.out.println("=== STREAM CREATION ===");
        Stream<String> fromOf      = Stream.of("A", "B", "C");
        Stream<Integer> fromArr    = Arrays.stream(new Integer[]{1,2,3,4,5});
        Stream<String> fromList    = List.of("x","y","z").stream();
        Stream<Integer> generated  = Stream.generate(() -> (int)(Math.random()*10)).limit(5);
        Stream<Integer> iterated   = Stream.iterate(0, n -> n + 2).limit(6); // 0,2,4,6,8,10
        Stream<String> empty       = Stream.empty();

        System.out.println("of:        " + fromOf.collect(Collectors.toList()));
        System.out.println("arrays:    " + fromArr.collect(Collectors.toList()));
        System.out.println("list:      " + fromList.collect(Collectors.toList()));
        System.out.println("generate:  " + generated.collect(Collectors.toList()));
        System.out.println("iterate:   " + iterated.collect(Collectors.toList()));
        System.out.println("empty:     " + empty.count());

        // Java 9+: iterate with predicate
        List<Integer> powersOf2 = Stream.iterate(1, n -> n < 1000, n -> n * 2)
            .collect(Collectors.toList());
        System.out.println("Powers<1000: " + powersOf2);

        // concat two streams
        Stream<String> combined = Stream.concat(Stream.of("A","B"), Stream.of("C","D"));
        System.out.println("concat: " + combined.collect(Collectors.toList()));

        // ============================================================
        // FILTER & MAP
        // ============================================================
        System.out.println("\n=== FILTER & MAP ===");
        List<Integer> nums = Arrays.asList(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15);

        List<Integer> evenSquares = nums.stream()
            .filter(n -> n % 2 == 0)
            .map(n -> n * n)
            .collect(Collectors.toList());
        System.out.println("Even squares:    " + evenSquares);

        List<String> longWords = Arrays.asList("apple","banana","fig","cherry","kiwi","strawberry")
            .stream()
            .filter(s -> s.length() > 5)
            .map(String::toUpperCase)
            .sorted()
            .collect(Collectors.toList());
        System.out.println("Long words upper: " + longWords);

        // mapToInt, mapToDouble (primitive specialization)
        int sumOfSquares = nums.stream().mapToInt(n -> n * n).sum();
        double avgVal    = nums.stream().mapToDouble(Integer::doubleValue).average().orElse(0);
        System.out.println("Sum of squares: " + sumOfSquares);
        System.out.printf("Average:        %.2f%n", avgVal);

        // ============================================================
        // FLATMAP
        // ============================================================
        System.out.println("\n=== FLATMAP ===");
        List<List<Integer>> nested = Arrays.asList(
            Arrays.asList(1, 2, 3), Arrays.asList(4, 5), Arrays.asList(6, 7, 8, 9));
        List<Integer> flat = nested.stream()
            .flatMap(Collection::stream)
            .collect(Collectors.toList());
        System.out.println("Flattened: " + flat);

        List<String> sentences = Arrays.asList("Hello world Java", "Stream API rocks", "Lambda is fun");
        List<String> words = sentences.stream()
            .flatMap(s -> Arrays.stream(s.split(" ")))
            .distinct()
            .sorted()
            .collect(Collectors.toList());
        System.out.println("Unique words: " + words);

        // ============================================================
        // DISTINCT, SORTED, LIMIT, SKIP, PEEK
        // ============================================================
        System.out.println("\n=== DISTINCT / SORTED / LIMIT / SKIP ===");
        List<Integer> raw = Arrays.asList(5,2,8,2,1,9,5,3,7,8,1,4);
        System.out.println("distinct:         " + raw.stream().distinct().collect(Collectors.toList()));
        System.out.println("sorted:           " + raw.stream().distinct().sorted().collect(Collectors.toList()));
        System.out.println("limit(4):         " + raw.stream().limit(4).collect(Collectors.toList()));
        System.out.println("skip(3).limit(4): " + raw.stream().skip(3).limit(4).collect(Collectors.toList()));

        // peek (for debugging, doesn't consume)
        List<Integer> peeked = raw.stream()
            .distinct()
            .peek(n -> System.out.print("  before:" + n))
            .filter(n -> n > 4)
            .peek(n -> System.out.print(" after:" + n + "\n"))
            .collect(Collectors.toList());
        System.out.println("peek result: " + peeked);

        // ============================================================
        // COLLECTORS
        // ============================================================
        System.out.println("\n=== COLLECTORS ===");
        List<Employee> employees = Arrays.asList(
            new Employee("Alice",   "Eng",       95000, 28, "Hyderabad"),
            new Employee("Bob",     "Marketing", 75000, 32, "Mumbai"),
            new Employee("Charlie", "Eng",       85000, 26, "Hyderabad"),
            new Employee("Diana",   "HR",        65000, 30, "Delhi"),
            new Employee("Eve",     "Marketing", 80000, 27, "Bangalore"),
            new Employee("Frank",   "Eng",      105000, 35, "Hyderabad"),
            new Employee("Grace",   "HR",        70000, 29, "Mumbai"),
            new Employee("Hank",    "Eng",       90000, 31, "Delhi")
        );

        // toList, toSet, toMap
        List<String>  names    = employees.stream().map(Employee::name).collect(Collectors.toList());
        Set<String>   depts    = employees.stream().map(Employee::dept).collect(Collectors.toSet());
        Map<String, Double> salMap = employees.stream()
            .collect(Collectors.toMap(Employee::name, Employee::salary));
        System.out.println("names: " + names);
        System.out.println("depts: " + new TreeSet<>(depts));

        // groupingBy
        Map<String, List<Employee>> byDept = employees.stream()
            .collect(Collectors.groupingBy(Employee::dept));
        byDept.forEach((dept, emps) ->
            System.out.printf("  %-12s: %s%n", dept,
                emps.stream().map(Employee::name).collect(Collectors.joining(", "))));

        // groupingBy + downstream collector
        System.out.println("\nAvg salary by dept:");
        employees.stream()
            .collect(Collectors.groupingBy(Employee::dept, Collectors.averagingDouble(Employee::salary)))
            .entrySet().stream().sorted(Map.Entry.<String,Double>comparingByValue().reversed())
            .forEach(e -> System.out.printf("  %-12s: Rs %.0f%n", e.getKey(), e.getValue()));

        System.out.println("\nCount by dept:");
        employees.stream()
            .collect(Collectors.groupingBy(Employee::dept, Collectors.counting()))
            .forEach((d,c) -> System.out.printf("  %-12s: %d%n", d, c));

        System.out.println("\nMax salary per dept:");
        employees.stream()
            .collect(Collectors.groupingBy(Employee::dept,
                Collectors.maxBy(Comparator.comparingDouble(Employee::salary))))
            .forEach((d,opt) -> System.out.printf("  %-12s: %s%n", d, opt.map(Employee::name).orElse("none")));

        // partitioningBy (true/false split)
        Map<Boolean, List<Employee>> partition = employees.stream()
            .collect(Collectors.partitioningBy(e -> e.salary() > 80000));
        System.out.println("\nSalary >80k:  " + partition.get(true).stream().map(Employee::name).collect(Collectors.toList()));
        System.out.println("Salary <=80k: " + partition.get(false).stream().map(Employee::name).collect(Collectors.toList()));

        // joining
        String nameList = employees.stream().map(Employee::name).collect(Collectors.joining(", ", "[", "]"));
        System.out.println("\njoining: " + nameList);

        // summarizingDouble
        DoubleSummaryStatistics stats = employees.stream()
            .collect(Collectors.summarizingDouble(Employee::salary));
        System.out.printf("\nStats: count=%d sum=%.0f min=%.0f max=%.0f avg=%.2f%n",
            stats.getCount(), stats.getSum(), stats.getMin(), stats.getMax(), stats.getAverage());

        // toUnmodifiableList, toUnmodifiableMap (Java 10+)
        List<String> immNames = employees.stream().map(Employee::name).collect(Collectors.toUnmodifiableList());
        System.out.println("Immutable list: " + immNames.getClass().getSimpleName());

        // ============================================================
        // REDUCE
        // ============================================================
        System.out.println("\n=== REDUCE ===");
        int sum = nums.stream().reduce(0, Integer::sum);
        Optional<Integer> product = nums.stream().reduce((a,b) -> a * b);
        Optional<Integer> maxVal  = nums.stream().reduce(Integer::max);
        String concat = Stream.of("a","b","c","d").reduce("", (a,b) -> a + b);
        System.out.println("sum:     " + sum);
        System.out.println("product: " + product.orElse(0));
        System.out.println("max:     " + maxVal.orElse(0));
        System.out.println("concat:  " + concat);

        // 3-arg reduce for parallel use (identity, accumulator, combiner)
        int parallelSum = nums.parallelStream().reduce(0, Integer::sum, Integer::sum);
        System.out.println("parallel sum: " + parallelSum);

        // ============================================================
        // TERMINAL OPERATIONS
        // ============================================================
        System.out.println("\n=== TERMINAL OPERATIONS ===");
        List<Integer> testNums = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        System.out.println("count:       " + testNums.stream().count());
        System.out.println("anyMatch(>7):" + testNums.stream().anyMatch(n -> n > 7));
        System.out.println("allMatch(>0):" + testNums.stream().allMatch(n -> n > 0));
        System.out.println("noneMatch(<0):" + testNums.stream().noneMatch(n -> n < 0));
        System.out.println("findFirst:   " + testNums.stream().filter(n -> n > 5).findFirst());
        System.out.println("findAny:     " + testNums.stream().filter(n -> n > 5).findAny());
        System.out.println("min:         " + testNums.stream().min(Integer::compareTo));
        System.out.println("max:         " + testNums.stream().max(Integer::compareTo));
        testNums.stream().filter(n -> n % 3 == 0).forEach(n -> System.out.print(n + " "));
        System.out.println("(multiples of 3)");

        // ============================================================
        // NUMERIC STREAMS
        // ============================================================
        System.out.println("\n=== NUMERIC STREAMS ===");
        IntStream.range(1, 6).forEach(n -> System.out.print(n + " "));
        System.out.println(" (range 1..5)");
        IntStream.rangeClosed(1, 5).forEach(n -> System.out.print(n + " "));
        System.out.println(" (rangeClosed 1..5)");

        int[] intArr = IntStream.rangeClosed(1, 10).toArray();
        System.out.println("sum 1..10:  " + IntStream.rangeClosed(1,10).sum());
        System.out.println("avg 1..10:  " + IntStream.rangeClosed(1,10).average().orElse(0));

        // Boxing/Unboxing
        List<Integer> boxed = IntStream.rangeClosed(1,5).boxed().collect(Collectors.toList());
        int[] unboxed = List.of(1,2,3,4,5).stream().mapToInt(Integer::intValue).toArray();
        System.out.println("boxed:   " + boxed);
        System.out.println("unboxed: " + Arrays.toString(unboxed));

        // ============================================================
        // PARALLEL STREAMS
        // ============================================================
        System.out.println("\n=== PARALLEL STREAMS ===");
        List<Integer> bigList = IntStream.rangeClosed(1, 1_000_000).boxed().collect(Collectors.toList());

        long t1 = System.currentTimeMillis();
        long seqSum = bigList.stream().mapToLong(Integer::longValue).sum();
        System.out.println("Sequential sum: " + seqSum + " in " + (System.currentTimeMillis()-t1) + "ms");

        long t2 = System.currentTimeMillis();
        long parSum = bigList.parallelStream().mapToLong(Integer::longValue).sum();
        System.out.println("Parallel sum:   " + parSum + " in " + (System.currentTimeMillis()-t2) + "ms");

        // ============================================================
        // OPTIONAL
        // ============================================================
        System.out.println("\n=== OPTIONAL ===");
        Optional<String> opt1 = Optional.of("Hello");
        Optional<String> opt2 = Optional.empty();
        Optional<String> opt3 = Optional.ofNullable(null);

        System.out.println("isPresent:    " + opt1.isPresent());
        System.out.println("isEmpty:      " + opt2.isEmpty());
        System.out.println("get:          " + opt1.get());
        System.out.println("orElse:       " + opt2.orElse("Default"));
        System.out.println("orElseGet:    " + opt2.orElseGet(() -> "Lazy Default"));
        System.out.println("orElseThrow:  ");
        try { opt2.orElseThrow(() -> new RuntimeException("Not found")); }
        catch (RuntimeException e) { System.out.println("  Caught: " + e.getMessage()); }

        // Optional chaining
        Optional<Integer> len = opt1.map(String::length);
        Optional<String>  upper = opt1.filter(s -> s.length() > 3).map(String::toUpperCase);
        System.out.println("map to length:       " + len);
        System.out.println("filter+map to upper: " + upper);

        opt1.ifPresent(s -> System.out.println("ifPresent: " + s));
        opt1.ifPresentOrElse(
            s -> System.out.println("ifPresentOrElse: " + s),
            () -> System.out.println("ifPresentOrElse: empty")
        );

        // flatMap with Optional
        Optional<String> nested = Optional.of(Optional.of("inner")).flatMap(o -> o);
        System.out.println("flatMap: " + nested);
    }
}
