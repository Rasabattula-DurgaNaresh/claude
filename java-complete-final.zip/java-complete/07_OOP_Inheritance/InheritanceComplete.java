/**
 * TOPIC 07: Inheritance - extends, super, Overriding, final
 * ===========================================================
 * Inheritance: IS-A relationship, code reuse
 * extends: single inheritance (Java does not support multiple class inheritance)
 * super: access parent constructor/methods/fields
 * @Override: method overriding (runtime polymorphism)
 * final class: cannot be subclassed
 * final method: cannot be overridden
 * Method hiding: static methods are hidden, not overridden
 *
 * Types: Single, Multilevel, Hierarchical (not Multiple via classes)
 */
public class InheritanceComplete {

    // ============================================================
    // BASE CLASS
    // ============================================================
    static class Animal {
        protected String name;
        protected String species;
        protected int    age;
        protected double weight; // kg

        public Animal(String name, String species, int age, double weight) {
            this.name    = name;
            this.species = species;
            this.age     = age;
            this.weight  = weight;
        }

        // Concrete methods (inherited as-is)
        public void eat(String food)  { System.out.println(name + " eats " + food); }
        public void sleep()           { System.out.println(name + " is sleeping..."); }
        public void move()            { System.out.println(name + " moves"); }

        // Method intended to be overridden
        public String makeSound()     { return "(generic animal sound)"; }
        public String getDescription(){ return String.format("%s (%s), age=%d, weight=%.1fkg", name, species, age, weight); }

        // Final method - CANNOT be overridden
        public final String getId()   { return species.toUpperCase() + "_" + name; }

        @Override public String toString() {
            return "[" + getClass().getSimpleName() + "] " + getDescription() + " | Sound: " + makeSound();
        }
    }

    // ============================================================
    // SINGLE INHERITANCE
    // ============================================================
    static class Dog extends Animal {
        private String breed;
        private boolean isVaccinated;

        public Dog(String name, String breed, int age, boolean vaccinated) {
            super(name, "Canis lupus familiaris", age, 20.0); // call parent constructor
            this.breed         = breed;
            this.isVaccinated  = vaccinated;
        }

        // Override parent method
        @Override public String makeSound() { return "Woof! Woof!"; }

        // Additional behavior
        public void fetch(String item) { System.out.println(name + " fetches the " + item + "!"); }
        public void wagTail()         { System.out.println(name + " wags tail happily"); }

        @Override public String getDescription() {
            return super.getDescription() + " | Breed: " + breed + " | Vaccinated: " + isVaccinated;
        }
    }

    // ============================================================
    // MULTILEVEL INHERITANCE (A -> B -> C)
    // ============================================================
    static class Vehicle {
        protected String brand, model;
        protected int    year;
        protected double speed;

        public Vehicle(String brand, String model, int year) {
            this.brand = brand; this.model = model; this.year = year; this.speed = 0;
        }
        public void accelerate(double kmh) { speed += kmh; System.out.println(brand+" "+model+" speed: "+speed+"km/h"); }
        public void brake(double kmh)      { speed = Math.max(0, speed-kmh); System.out.println("Speed: "+speed+"km/h"); }
        public String getInfo()            { return brand + " " + model + " (" + year + ")"; }
        @Override public String toString() { return getInfo() + " @" + speed + "km/h"; }
    }

    static class Car extends Vehicle {
        private int    doors;
        private String fuelType;

        public Car(String brand, String model, int year, int doors, String fuelType) {
            super(brand, model, year);
            this.doors = doors; this.fuelType = fuelType;
        }

        public void honk() { System.out.println(brand + " " + model + ": BEEP BEEP!"); }

        @Override public String getInfo() {
            return super.getInfo() + " [" + doors + "-door, " + fuelType + "]";
        }
    }

    static class ElectricCar extends Car {
        private int batteryKwh;
        private int rangeKm;
        private int chargePercent;

        public ElectricCar(String brand, String model, int year, int batteryKwh, int rangeKm) {
            super(brand, model, year, 4, "Electric");
            this.batteryKwh    = batteryKwh;
            this.rangeKm       = rangeKm;
            this.chargePercent = 80;
        }

        public void charge(int percent) {
            chargePercent = Math.min(100, chargePercent + percent);
            System.out.println(brand + " " + model + " charged to " + chargePercent + "%");
        }

        @Override public String getInfo() {
            return super.getInfo() + " [" + batteryKwh + "kWh, " + rangeKm + "km range, " + chargePercent + "% charged]";
        }
    }

    // ============================================================
    // HIERARCHICAL INHERITANCE (one parent, multiple children)
    // ============================================================
    static class Shape {
        protected String color;
        public Shape(String color) { this.color = color; }
        public double area()       { return 0; }
        public double perimeter()  { return 0; }
        public void display() {
            System.out.printf("[%s] %s: area=%.4f perimeter=%.4f%n",
                color, getClass().getSimpleName(), area(), perimeter());
        }
    }

    static class Circle    extends Shape {
        private double r;
        public Circle(String c, double r)  { super(c); this.r=r; }
        @Override public double area()     { return Math.PI*r*r; }
        @Override public double perimeter(){ return 2*Math.PI*r; }
    }

    static class Rect extends Shape {
        private double w,h;
        public Rect(String c, double w, double h){ super(c); this.w=w; this.h=h; }
        @Override public double area()     { return w*h; }
        @Override public double perimeter(){ return 2*(w+h); }
    }

    static class Triangle extends Shape {
        private double a,b,c;
        public Triangle(String col, double a, double b, double c){ super(col); this.a=a; this.b=b; this.c=c; }
        @Override public double area() { double s=(a+b+c)/2; return Math.sqrt(s*(s-a)*(s-b)*(s-c)); }
        @Override public double perimeter() { return a+b+c; }
    }

    // Final class - cannot extend
    static final class ImmutablePoint {
        private final double x, y;
        public ImmutablePoint(double x, double y) { this.x=x; this.y=y; }
        public double getX() { return x; }
        public double getY() { return y; }
        // Cannot create class extending ImmutablePoint!
    }

    public static void main(String[] args) {
        System.out.println("=== SINGLE INHERITANCE ===");
        Dog dog = new Dog("Rex", "Labrador", 3, true);
        System.out.println(dog);
        dog.eat("bone");
        dog.sleep();
        dog.fetch("ball");
        dog.wagTail();
        System.out.println("ID: " + dog.getId());

        System.out.println("\n=== MULTILEVEL INHERITANCE ===");
        ElectricCar tesla = new ElectricCar("Tesla", "Model 3", 2024, 82, 568);
        System.out.println(tesla.getInfo());
        tesla.accelerate(100);
        tesla.honk();
        tesla.charge(15);
        tesla.brake(30);

        System.out.println("\n=== HIERARCHICAL INHERITANCE ===");
        Shape[] shapes = {
            new Circle("Red", 5.0),
            new Rect("Blue", 4.0, 6.0),
            new Triangle("Green", 3.0, 4.0, 5.0)
        };
        double totalArea = 0;
        for (Shape s : shapes) { s.display(); totalArea += s.area(); }
        System.out.printf("Total area: %.4f%n", totalArea);

        System.out.println("\n=== super KEYWORD ===");
        // super() in constructor: call parent constructor (must be first!)
        // super.method(): call parent's version of overridden method
        // super.field: access parent's field (if not private)

        System.out.println("\n=== instanceof HIERARCHY ===");
        Object ecar = new ElectricCar("Tata", "Nexon EV", 2023, 40, 312);
        System.out.println("ElectricCar: " + (ecar instanceof ElectricCar)); // true
        System.out.println("Car:         " + (ecar instanceof Car));          // true
        System.out.println("Vehicle:     " + (ecar instanceof Vehicle));      // true
        System.out.println("Object:      " + (ecar instanceof Object));       // true (all classes!)

        System.out.println("\n=== METHOD HIDING vs OVERRIDING ===");
        System.out.println("Overriding: instance methods -> dynamic dispatch (runtime)");
        System.out.println("Hiding: static methods -> resolved at compile time");
        // Static method hiding example
        System.out.println(Parent.staticMethod()); // "Parent static"
        System.out.println(Child.staticMethod());  // "Child static" (hidden, not overridden)
        Parent ref = new Child();
        System.out.println(ref.staticMethod());    // "Parent static" (reference type used!)
    }

    static class Parent {
        static String staticMethod() { return "Parent static"; }
        String instanceMethod()      { return "Parent instance"; }
    }
    static class Child extends Parent {
        static String staticMethod() { return "Child static"; }   // HIDES parent
        @Override
        String instanceMethod()      { return "Child instance"; } // OVERRIDES parent
    }
}
