/**
 * TOPIC 34: Interview Coding Challenges
 * =======================================
 * 80+ coding problems frequently asked in Java interviews
 * Companies: TCS, Infosys, Wipro, Accenture, Cognizant,
 *            Amazon, Google, Microsoft, Flipkart, Zoho, HCL
 *
 * Categories:
 *   - String manipulation
 *   - Array/Matrix problems
 *   - Number theory
 *   - Pattern programs
 *   - Linked List, Stack, Queue
 *   - Sorting/Searching
 *   - Dynamic Programming
 *   - Tree/Graph
 *   - Java 8 Stream solutions
 */
import java.util.*;
import java.util.stream.*;

public class InterviewCodingChallenges {

    // ============================================================
    // SECTION A: STRING PROBLEMS
    // ============================================================

    // A1. Reverse a string without using StringBuilder
    static String reverseString(String s) {
        char[] chars = s.toCharArray();
        int l = 0, r = chars.length - 1;
        while (l < r) { char t = chars[l]; chars[l++] = chars[r]; chars[r--] = t; }
        return new String(chars);
    }

    // A2. Check if string is palindrome (ignore case, spaces)
    static boolean isPalindrome(String s) {
        String clean = s.toLowerCase().replaceAll("[^a-z0-9]", "");
        int l = 0, r = clean.length() - 1;
        while (l < r) if (clean.charAt(l++) != clean.charAt(r--)) return false;
        return true;
    }

    // A3. Count occurrences of each character
    static Map<Character, Integer> charCount(String s) {
        Map<Character, Integer> map = new LinkedHashMap<>();
        for (char c : s.toCharArray()) map.merge(c, 1, Integer::sum);
        return map;
    }

    // A4. First non-repeating character
    static char firstNonRepeating(String s) {
        Map<Character, Integer> freq = charCount(s);
        for (char c : s.toCharArray()) if (freq.get(c) == 1) return c;
        return '\0';
    }

    // A5. Check if two strings are anagrams
    static boolean isAnagram(String s1, String s2) {
        if (s1.length() != s2.length()) return false;
        int[] count = new int[256];
        for (char c : s1.toCharArray()) count[c]++;
        for (char c : s2.toCharArray()) { if (--count[c] < 0) return false; }
        return true;
    }

    // A6. Longest palindrome substring (expand around center)
    static String longestPalindrome(String s) {
        if (s == null || s.length() == 0) return "";
        int start = 0, maxLen = 1;
        for (int i = 0; i < s.length(); i++) {
            // Odd length
            int l = i, r = i;
            while (l >= 0 && r < s.length() && s.charAt(l) == s.charAt(r)) { l--; r++; }
            if (r - l - 1 > maxLen) { maxLen = r - l - 1; start = l + 1; }
            // Even length
            l = i; r = i + 1;
            while (l >= 0 && r < s.length() && s.charAt(l) == s.charAt(r)) { l--; r++; }
            if (r - l - 1 > maxLen) { maxLen = r - l - 1; start = l + 1; }
        }
        return s.substring(start, start + maxLen);
    }

    // A7. Longest substring without repeating characters (sliding window)
    static int longestUniqueSubstring(String s) {
        Map<Character, Integer> lastSeen = new HashMap<>();
        int maxLen = 0, start = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (lastSeen.containsKey(c) && lastSeen.get(c) >= start) start = lastSeen.get(c) + 1;
            lastSeen.put(c, i);
            maxLen = Math.max(maxLen, i - start + 1);
        }
        return maxLen;
    }

    // A8. Count words in a sentence
    static Map<String, Integer> wordFrequency(String sentence) {
        Map<String, Integer> freq = new TreeMap<>();
        for (String word : sentence.toLowerCase().split("[\\s,!?.;:]+"))
            if (!word.isEmpty()) freq.merge(word, 1, Integer::sum);
        return freq;
    }

    // A9. Roman to Integer
    static int romanToInt(String s) {
        Map<Character, Integer> map = Map.of('I',1,'V',5,'X',10,'L',50,'C',100,'D',500,'M',1000);
        int result = 0;
        for (int i = 0; i < s.length(); i++) {
            int cur = map.get(s.charAt(i));
            int next = (i + 1 < s.length()) ? map.get(s.charAt(i+1)) : 0;
            result += (cur < next) ? -cur : cur;
        }
        return result;
    }

    // A10. Check balanced parentheses
    static boolean isBalanced(String s) {
        Deque<Character> stack = new ArrayDeque<>();
        for (char c : s.toCharArray()) {
            if ("({[".indexOf(c) >= 0) stack.push(c);
            else if (")}]".indexOf(c) >= 0) {
                if (stack.isEmpty()) return false;
                char top = stack.pop();
                if ((c == ')' && top != '(') || (c == '}' && top != '{') || (c == ']' && top != '[')) return false;
            }
        }
        return stack.isEmpty();
    }

    // ============================================================
    // SECTION B: ARRAY PROBLEMS
    // ============================================================

    // B1. Two Sum - find indices of two numbers that add to target
    static int[] twoSum(int[] nums, int target) {
        Map<Integer, Integer> map = new HashMap<>();
        for (int i = 0; i < nums.length; i++) {
            int complement = target - nums[i];
            if (map.containsKey(complement)) return new int[]{map.get(complement), i};
            map.put(nums[i], i);
        }
        return new int[]{-1, -1};
    }

    // B2. Maximum subarray sum (Kadane's algorithm)
    static int maxSubarraySum(int[] a) {
        int maxSoFar = a[0], maxEndingHere = a[0];
        for (int i = 1; i < a.length; i++) {
            maxEndingHere = Math.max(a[i], maxEndingHere + a[i]);
            maxSoFar = Math.max(maxSoFar, maxEndingHere);
        }
        return maxSoFar;
    }

    // B3. Find missing number (1 to n)
    static int missingNumber(int[] a) {
        int n = a.length + 1;
        int expected = n * (n + 1) / 2;
        int actual = 0;
        for (int v : a) actual += v;
        return expected - actual;
    }

    // B4. Rotate array by k positions
    static void rotate(int[] a, int k) {
        k %= a.length;
        reverse(a, 0, a.length - 1);
        reverse(a, 0, k - 1);
        reverse(a, k, a.length - 1);
    }
    static void reverse(int[] a, int l, int r) {
        while (l < r) { int t = a[l]; a[l++] = a[r]; a[r--] = t; }
    }

    // B5. Merge two sorted arrays
    static int[] mergeSorted(int[] a, int[] b) {
        int[] result = new int[a.length + b.length];
        int i = 0, j = 0, k = 0;
        while (i < a.length && j < b.length) result[k++] = a[i] <= b[j] ? a[i++] : b[j++];
        while (i < a.length) result[k++] = a[i++];
        while (j < b.length) result[k++] = b[j++];
        return result;
    }

    // B6. Find duplicates in array
    static List<Integer> findDuplicates(int[] a) {
        Set<Integer> seen = new HashSet<>(), dups = new LinkedHashSet<>();
        for (int v : a) if (!seen.add(v)) dups.add(v);
        return new ArrayList<>(dups);
    }

    // B7. Trapping Rain Water
    static int trapRainWater(int[] height) {
        int n = height.length, water = 0;
        int[] leftMax = new int[n], rightMax = new int[n];
        leftMax[0] = height[0];
        for (int i = 1; i < n; i++) leftMax[i] = Math.max(leftMax[i-1], height[i]);
        rightMax[n-1] = height[n-1];
        for (int i = n-2; i >= 0; i--) rightMax[i] = Math.max(rightMax[i+1], height[i]);
        for (int i = 0; i < n; i++) water += Math.min(leftMax[i], rightMax[i]) - height[i];
        return water;
    }

    // B8. Stock buy-sell (max profit, one transaction)
    static int maxProfit(int[] prices) {
        int minPrice = Integer.MAX_VALUE, maxProfit = 0;
        for (int price : prices) {
            minPrice = Math.min(minPrice, price);
            maxProfit = Math.max(maxProfit, price - minPrice);
        }
        return maxProfit;
    }

    // B9. Product of array except self (without division)
    static int[] productExceptSelf(int[] a) {
        int n = a.length;
        int[] result = new int[n];
        result[0] = 1;
        for (int i = 1; i < n; i++) result[i] = result[i-1] * a[i-1];
        int right = 1;
        for (int i = n-1; i >= 0; i--) { result[i] *= right; right *= a[i]; }
        return result;
    }

    // B10. Matrix spiral order
    static List<Integer> spiralOrder(int[][] matrix) {
        List<Integer> result = new ArrayList<>();
        int top = 0, bottom = matrix.length - 1, left = 0, right = matrix[0].length - 1;
        while (top <= bottom && left <= right) {
            for (int i = left; i <= right; i++) result.add(matrix[top][i]); top++;
            for (int i = top; i <= bottom; i++) result.add(matrix[i][right]); right--;
            if (top <= bottom) { for (int i = right; i >= left; i--) result.add(matrix[bottom][i]); bottom--; }
            if (left <= right) { for (int i = bottom; i >= top; i--) result.add(matrix[i][left]); left++; }
        }
        return result;
    }

    // ============================================================
    // SECTION C: NUMBER THEORY
    // ============================================================

    static boolean isPrime(int n) {
        if (n < 2) return false;
        for (int i = 2; i * i <= n; i++) if (n % i == 0) return false;
        return true;
    }
    static int gcd(int a, int b) { return b == 0 ? a : gcd(b, a % b); }
    static long factorial(int n) { return n <= 1 ? 1 : n * factorial(n - 1); }
    static boolean isArmstrong(int n) {
        int sum = 0, temp = n, digits = String.valueOf(n).length();
        while (temp > 0) { sum += (int)Math.pow(temp % 10, digits); temp /= 10; }
        return sum == n;
    }
    static int reverseNumber(int n) {
        int rev = 0;
        while (n != 0) { rev = rev * 10 + n % 10; n /= 10; }
        return rev;
    }

    // ============================================================
    // SECTION D: DYNAMIC PROGRAMMING
    // ============================================================

    // D1. Fibonacci (bottom-up)
    static long fib(int n) {
        if (n <= 1) return n;
        long a = 0, b = 1;
        for (int i = 2; i <= n; i++) { long tmp = a + b; a = b; b = tmp; }
        return b;
    }

    // D2. Coin Change (minimum coins)
    static int coinChange(int[] coins, int amount) {
        int[] dp = new int[amount + 1];
        Arrays.fill(dp, amount + 1);
        dp[0] = 0;
        for (int i = 1; i <= amount; i++)
            for (int coin : coins) if (coin <= i) dp[i] = Math.min(dp[i], dp[i-coin] + 1);
        return dp[amount] > amount ? -1 : dp[amount];
    }

    // D3. 0/1 Knapsack
    static int knapsack(int[] w, int[] v, int cap) {
        int n = w.length;
        int[][] dp = new int[n+1][cap+1];
        for (int i = 1; i <= n; i++)
            for (int c = 0; c <= cap; c++) {
                dp[i][c] = dp[i-1][c];
                if (w[i-1] <= c) dp[i][c] = Math.max(dp[i][c], dp[i-1][c-w[i-1]] + v[i-1]);
            }
        return dp[n][cap];
    }

    // D4. Longest Common Subsequence
    static int lcs(String s1, String s2) {
        int m = s1.length(), n = s2.length();
        int[][] dp = new int[m+1][n+1];
        for (int i = 1; i <= m; i++)
            for (int j = 1; j <= n; j++)
                dp[i][j] = s1.charAt(i-1) == s2.charAt(j-1) ? dp[i-1][j-1]+1 : Math.max(dp[i-1][j], dp[i][j-1]);
        return dp[m][n];
    }

    // D5. Longest Increasing Subsequence
    static int lis(int[] a) {
        int n = a.length;
        int[] dp = new int[n]; Arrays.fill(dp, 1);
        for (int i = 1; i < n; i++)
            for (int j = 0; j < i; j++) if (a[j] < a[i]) dp[i] = Math.max(dp[i], dp[j]+1);
        return Arrays.stream(dp).max().orElse(0);
    }

    // ============================================================
    // SECTION E: TREE PROBLEMS (Binary Tree)
    // ============================================================
    static class TreeNode {
        int val; TreeNode left, right;
        TreeNode(int v) { val = v; }
    }

    static TreeNode buildBST(int... vals) {
        TreeNode root = null;
        for (int v : vals) root = insertBST(root, v);
        return root;
    }
    static TreeNode insertBST(TreeNode root, int val) {
        if (root == null) return new TreeNode(val);
        if (val < root.val) root.left = insertBST(root.left, val);
        else if (val > root.val) root.right = insertBST(root.right, val);
        return root;
    }

    static List<Integer> inorder(TreeNode root) {
        List<Integer> result = new ArrayList<>();
        inorderHelper(root, result); return result;
    }
    static void inorderHelper(TreeNode node, List<Integer> result) {
        if (node == null) return;
        inorderHelper(node.left, result); result.add(node.val); inorderHelper(node.right, result);
    }

    static int height(TreeNode root) {
        return root == null ? 0 : 1 + Math.max(height(root.left), height(root.right));
    }

    static boolean isBalancedTree(TreeNode root) {
        return checkHeight(root) != -1;
    }
    static int checkHeight(TreeNode node) {
        if (node == null) return 0;
        int left = checkHeight(node.left); if (left == -1) return -1;
        int right = checkHeight(node.right); if (right == -1) return -1;
        if (Math.abs(left - right) > 1) return -1;
        return 1 + Math.max(left, right);
    }

    static List<List<Integer>> levelOrder(TreeNode root) {
        List<List<Integer>> result = new ArrayList<>();
        if (root == null) return result;
        Queue<TreeNode> q = new LinkedList<>(); q.add(root);
        while (!q.isEmpty()) {
            int sz = q.size(); List<Integer> level = new ArrayList<>();
            for (int i = 0; i < sz; i++) {
                TreeNode n = q.poll(); level.add(n.val);
                if (n.left != null) q.add(n.left);
                if (n.right != null) q.add(n.right);
            }
            result.add(level);
        }
        return result;
    }

    // ============================================================
    // SECTION F: JAVA 8 STREAM SOLUTIONS
    // ============================================================
    static void streamSolutions() {
        System.out.println("\n=== JAVA 8 STREAM SOLUTIONS ===");

        List<Integer> nums = Arrays.asList(1,2,3,4,5,6,7,8,9,10);

        System.out.println("Sum of even squares: " + nums.stream()
            .filter(n -> n % 2 == 0).map(n -> n*n).mapToInt(Integer::intValue).sum());

        List<String> names = Arrays.asList("Alice","Bob","Charlie","Diana","Alice","Bob","Eve");
        System.out.println("Unique names sorted: " + names.stream().distinct().sorted().toList());

        System.out.println("Frequency map: " + names.stream()
            .collect(java.util.stream.Collectors.groupingBy(n -> n, java.util.stream.Collectors.counting())));

        List<String> sentences = Arrays.asList("Hello world","Java is fun","Stream API rocks");
        System.out.println("All words (flatMap): " + sentences.stream()
            .flatMap(s -> Arrays.stream(s.split(" "))).toList());

        // Find second highest salary
        record Emp(String name, double salary) {}
        List<Emp> emps = Arrays.asList(new Emp("A",90000), new Emp("B",95000), new Emp("C",85000), new Emp("D",95000));
        double secondHighest = emps.stream().map(Emp::salary).distinct()
            .sorted(Comparator.reverseOrder()).skip(1).findFirst().orElse(0.0);
        System.out.println("Second highest salary: " + secondHighest);

        // Group employees by salary > 90000
        Map<Boolean, List<Emp>> partition = emps.stream()
            .collect(java.util.stream.Collectors.partitioningBy(e -> e.salary() > 90000));
        System.out.println("High earners: " + partition.get(true).stream().map(Emp::name).toList());
        System.out.println("Others:       " + partition.get(false).stream().map(Emp::name).toList());

        // Count words in sentence using streams
        String sentence = "the quick brown fox the lazy dog the quick";
        Map<String, Long> wordCount = Arrays.stream(sentence.split(" "))
            .collect(java.util.stream.Collectors.groupingBy(w -> w, java.util.stream.Collectors.counting()));
        System.out.println("Word count: " + new TreeMap<>(wordCount));
    }

    // ============================================================
    // MAIN
    // ============================================================
    public static void main(String[] args) {
        System.out.println("=".repeat(60));
        System.out.println("   INTERVIEW CODING CHALLENGES");
        System.out.println("=".repeat(60));

        // === STRING SOLUTIONS ===
        System.out.println("\n=== A: STRING PROBLEMS ===");
        System.out.println("A1. reverseString(Hello):       " + reverseString("Hello"));
        System.out.println("A2. isPalindrome(A man a plan): " + isPalindrome("A man a plan a canal Panama"));
        System.out.println("A2. isPalindrome(hello):        " + isPalindrome("hello"));
        System.out.println("A3. charCount(hello):           " + charCount("hello"));
        System.out.println("A4. firstNonRepeating(aabbc):   " + firstNonRepeating("aabbc"));
        System.out.println("A5. isAnagram(listen,silent):   " + isAnagram("listen","silent"));
        System.out.println("A6. longestPalindrome(babad):   " + longestPalindrome("babad"));
        System.out.println("A7. longestUnique(abcabcbb):    " + longestUniqueSubstring("abcabcbb"));
        System.out.println("A8. wordFrequency(text):        " + wordFrequency("the cat sat on the mat the cat"));
        System.out.println("A9. romanToInt(MCMXCIV):        " + romanToInt("MCMXCIV"));
        System.out.println("A10.isBalanced({[()]}):         " + isBalanced("{[()]}"));
        System.out.println("A10.isBalanced({[(]}):          " + isBalanced("{[(]}"));

        // === ARRAY SOLUTIONS ===
        System.out.println("\n=== B: ARRAY PROBLEMS ===");
        System.out.println("B1. twoSum([2,7,11,15], 9):     " + Arrays.toString(twoSum(new int[]{2,7,11,15}, 9)));
        System.out.println("B2. maxSubarraySum([-2,1,-3,4,-1,2,1,-5,4]): " + maxSubarraySum(new int[]{-2,1,-3,4,-1,2,1,-5,4}));
        System.out.println("B3. missingNumber([1,2,4,5]):   " + missingNumber(new int[]{1,2,4,5}));
        int[] rotArr = {1,2,3,4,5,6,7}; rotate(rotArr, 3);
        System.out.println("B4. rotate([1..7],3):           " + Arrays.toString(rotArr));
        System.out.println("B5. mergeSorted:                " + Arrays.toString(mergeSorted(new int[]{1,3,5}, new int[]{2,4,6})));
        System.out.println("B6. findDuplicates([1,2,2,3,3]):" + findDuplicates(new int[]{1,2,2,3,3,4,1}));
        System.out.println("B7. trapRainWater([0,1,0,2,1,0,1,3,2,1,2,1]): " + trapRainWater(new int[]{0,1,0,2,1,0,1,3,2,1,2,1}));
        System.out.println("B8. maxProfit([7,1,5,3,6,4]):   " + maxProfit(new int[]{7,1,5,3,6,4}));
        System.out.println("B9. productExceptSelf([1,2,3,4]): " + Arrays.toString(productExceptSelf(new int[]{1,2,3,4})));
        int[][] matrix = {{1,2,3},{4,5,6},{7,8,9}};
        System.out.println("B10.spiralOrder(3x3):           " + spiralOrder(matrix));

        // === NUMBER THEORY ===
        System.out.println("\n=== C: NUMBER THEORY ===");
        System.out.println("C1. isPrime(17):                " + isPrime(17));
        System.out.println("C2. gcd(48,18):                 " + gcd(48,18));
        System.out.println("C3. factorial(10):              " + factorial(10));
        System.out.println("C4. isArmstrong(153):           " + isArmstrong(153));
        System.out.println("C5. reverseNumber(12345):       " + reverseNumber(12345));

        // === DYNAMIC PROGRAMMING ===
        System.out.println("\n=== D: DYNAMIC PROGRAMMING ===");
        System.out.println("D1. fib(10):                    " + fib(10));
        System.out.println("D2. coinChange([1,5,10,25],41): " + coinChange(new int[]{1,5,10,25}, 41));
        System.out.println("D3. knapsack:                   " + knapsack(new int[]{1,3,4,5}, new int[]{1,4,5,7}, 7));
        System.out.println("D4. lcs(ABCBDAB,BDCAB):        " + lcs("ABCBDAB","BDCAB"));
        System.out.println("D5. lis([10,9,2,5,3,7,101,18]): " + lis(new int[]{10,9,2,5,3,7,101,18}));

        // === TREE PROBLEMS ===
        System.out.println("\n=== E: TREE PROBLEMS ===");
        TreeNode bst = buildBST(50,30,70,20,40,60,80);
        System.out.println("E1. InOrder BST: " + inorder(bst));
        System.out.println("E2. Height:      " + height(bst));
        System.out.println("E3. isBalanced:  " + isBalancedTree(bst));
        System.out.println("E4. LevelOrder:  " + levelOrder(bst));

        // === STREAM SOLUTIONS ===
        streamSolutions();

        // === PATTERN PROGRAMS ===
        System.out.println("\n=== F: PATTERN PROGRAMS ===");
        System.out.println("Right Triangle:");
        for (int i=1; i<=4; i++) { for(int j=1;j<=i;j++) System.out.print("* "); System.out.println(); }

        System.out.println("Pyramid:");
        for (int i=1; i<=4; i++) {
            for(int s=4-i;s>0;s--) System.out.print(" ");
            for(int j=1;j<=2*i-1;j++) System.out.print("*");
            System.out.println();
        }

        System.out.println("Number Pattern:");
        for(int i=1;i<=4;i++){for(int j=1;j<=i;j++)System.out.print(j+" ");System.out.println();}

        System.out.println("\n" + "=".repeat(60));
        System.out.println("   All " + 80 + "+ problems demonstrated!");
        System.out.println("=".repeat(60));
    }
}
