/**
 * TOPIC 09: Abstraction - Abstract Classes & Interfaces
 * ======================================================
 * Abstract class: partially implemented, cannot be instantiated
 * Interface: fully abstract contract (Java 8+ allows default/static methods)
 * Template Method Pattern: skeleton in abstract class, details in subclass
 * Multiple interface implementation (solves diamond problem)
 */
public class AbstractionComplete {

    // ============================================================
    // ABSTRACT CLASS EXAMPLE
    // ============================================================
    static abstract class Employee {
        protected String name;
        protected String empId;
        protected String department;
        protected double baseSalary;

        public Employee(String name, String empId, String dept, double baseSalary) {
            this.name=name; this.empId=empId; this.department=dept; this.baseSalary=baseSalary;
        }

        // Abstract: every employee type calculates salary differently
        public abstract double calculateSalary();
        public abstract String getEmployeeType();

        // Concrete: common behavior
        public void printPayslip() {
            System.out.println("=".repeat(50));
            System.out.println("PAYSLIP - " + name + " [" + empId + "]");
            System.out.println("Department: " + department);
            System.out.println("Type: " + getEmployeeType());
            System.out.printf("Base Salary:    Rs %10.2f%n", baseSalary);
            System.out.printf("Net Salary:     Rs %10.2f%n", calculateSalary());
            System.out.println("=".repeat(50));
        }

        // Hooks (optional override)
        public String getBonus()    { return "No bonus"; }
        public void onLeave()       { System.out.println(name + " is on leave"); }

        public String getName()     { return name; }
        public double getBaseSalary() { return baseSalary; }
    }

    static class FullTimeEmployee extends Employee {
        private double hra, da, pf;
        public FullTimeEmployee(String n, String id, String d, double base, double hra, double da) {
            super(n, id, d, base);
            this.hra=hra; this.da=da; this.pf=base*0.12;
        }
        @Override public double calculateSalary() { return baseSalary + hra + da - pf; }
        @Override public String getEmployeeType() { return "Full-Time Permanent"; }
        @Override public String getBonus()        { return "Annual bonus: Rs " + (baseSalary * 0.1); }
    }

    static class ContractEmployee extends Employee {
        private double hourlyRate; private int hoursWorked;
        public ContractEmployee(String n, String id, String d, double rate, int hours) {
            super(n, id, d, rate*hours); hourlyRate=rate; hoursWorked=hours;
        }
        @Override public double calculateSalary() { return hourlyRate * hoursWorked; }
        @Override public String getEmployeeType() { return "Contract (Hourly)"; }
    }

    static class Intern extends Employee {
        private String mentor;
        public Intern(String n, String id, String d, double stipend, String mentor) {
            super(n, id, d, stipend); this.mentor=mentor;
        }
        @Override public double calculateSalary() { return baseSalary; }  // just stipend
        @Override public String getEmployeeType() { return "Intern (Stipend)"; }
        @Override public void onLeave()           { System.out.println(name + " informs mentor " + mentor); }
    }

    // ============================================================
    // INTERFACES
    // ============================================================
    interface Drivable {
        void start();
        void stop();
        default void refuel(String fuelType) {
            System.out.println("Refueling with: " + fuelType);
        }
        static Drivable noOp() {
            return new Drivable() {
                public void start() { System.out.println("No-op start"); }
                public void stop()  { System.out.println("No-op stop"); }
            };
        }
    }

    interface Flyable {
        int MAX_ALTITUDE = 12000; // public static final (implicit)
        void takeOff();
        void land();
        default void autopilot() { System.out.println("Autopilot engaged"); }
    }

    interface Swimmable {
        void dive(int depth);
        void surface();
    }

    // Multiple interface implementation
    static class FlyingCar implements Drivable, Flyable {
        private String model;
        public FlyingCar(String model) { this.model=model; }
        @Override public void start()   { System.out.println(model + " engine started"); }
        @Override public void stop()    { System.out.println(model + " engine stopped"); }
        @Override public void takeOff() { System.out.println(model + " takes off! Max alt: " + MAX_ALTITUDE + "m"); }
        @Override public void land()    { System.out.println(model + " lands on road"); }
    }

    static class AmphibiousVehicle implements Drivable, Swimmable {
        private String name;
        public AmphibiousVehicle(String n) { name=n; }
        @Override public void start()        { System.out.println(name + " starts"); }
        @Override public void stop()         { System.out.println(name + " stops"); }
        @Override public void dive(int depth){ System.out.println(name + " dives to " + depth + "m"); }
        @Override public void surface()      { System.out.println(name + " surfaces"); }
    }

    // Interface extending interface
    interface SmartDevice extends Drivable {
        void connectToNetwork(String ssid);
        void executeRemoteCommand(String cmd);
        default void sendDiagnostics() { System.out.println("Sending diagnostics..."); }
    }

    static class AutonomousCar implements SmartDevice, Flyable {
        private String id;
        public AutonomousCar(String id) { this.id=id; }
        @Override public void start()   { System.out.println("AutonomousCar " + id + ": systems online"); }
        @Override public void stop()    { System.out.println("AutonomousCar " + id + ": shutdown"); }
        @Override public void takeOff() { System.out.println("AutonomousCar " + id + ": air mode!"); }
        @Override public void land()    { System.out.println("AutonomousCar " + id + ": land mode"); }
        @Override public void connectToNetwork(String s)      { System.out.println("Connected to " + s); }
        @Override public void executeRemoteCommand(String cmd){ System.out.println("Executing: " + cmd); }
    }

    public static void main(String[] args) {
        System.out.println("=== ABSTRACT CLASS - Employee ===");
        Employee[] employees = {
            new FullTimeEmployee("Alice", "E001", "Engineering", 60000, 24000, 18000),
            new ContractEmployee("Bob",   "C001", "Marketing",   750, 160),
            new Intern("Charlie", "I001", "Engineering", 15000, "Alice")
        };
        for (Employee e : employees) {
            e.printPayslip();
            System.out.println("Bonus: " + e.getBonus());
            e.onLeave();
            System.out.println();
        }

        System.out.println("=== INTERFACES ===");
        FlyingCar fc = new FlyingCar("AeroX-2050");
        fc.start();
        fc.takeOff();
        fc.autopilot();    // default method
        fc.refuel("Electric"); // default from Drivable
        fc.land();
        fc.stop();

        System.out.println("\n=== MULTIPLE INTERFACES ===");
        AmphibiousVehicle av = new AmphibiousVehicle("DuckBoat");
        av.start();
        av.dive(5);
        av.surface();
        av.stop();

        System.out.println("\n=== INTERFACE REFERENCES ===");
        Drivable d = new FlyingCar("TestCar");
        Flyable  f = new FlyingCar("TestCar");
        d.start(); d.stop();
        f.takeOff(); f.land();

        System.out.println("\n=== ANONYMOUS IMPLEMENTATION ===");
        Drivable noop = Drivable.noOp();  // static factory method
        noop.start(); noop.stop();

        System.out.println("\n=== INTERFACE CONSTANT ===");
        System.out.println("MAX_ALTITUDE = " + Flyable.MAX_ALTITUDE + "m");

        AutonomousCar auto = new AutonomousCar("ROBO-001");
        auto.start();
        auto.connectToNetwork("5G-Tesla-Net");
        auto.executeRemoteCommand("NAVIGATE_TO /home");
        auto.sendDiagnostics();
    }
}
