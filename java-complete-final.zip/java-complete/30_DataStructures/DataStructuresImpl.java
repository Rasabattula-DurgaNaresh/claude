/**
 * TOPIC 30: Data Structures - Custom Implementations
 * ====================================================
 * Implementing core data structures from scratch:
 * 1. Dynamic Array (ArrayList equivalent)
 * 2. Singly Linked List
 * 3. Doubly Linked List
 * 4. Stack (array-based)
 * 5. Queue (circular array)
 * 6. Binary Search Tree (BST)
 * 7. Hash Map (chaining)
 * 8. Min Heap / Priority Queue
 * 9. Graph (adjacency list) with BFS/DFS
 */
import java.util.*;

public class DataStructuresImpl {

    // ============================================================
    // 1. DYNAMIC ARRAY
    // ============================================================
    static class DynamicArray<T> {
        private Object[] data;
        private int size;
        private static final int INIT_CAP = 4;

        @SuppressWarnings("unchecked")
        public DynamicArray() { data = new Object[INIT_CAP]; size = 0; }

        public void add(T item) {
            if (size == data.length) resize(data.length * 2);
            data[size++] = item;
        }

        public void add(int idx, T item) {
            if (idx < 0 || idx > size) throw new IndexOutOfBoundsException("Index: " + idx);
            if (size == data.length) resize(data.length * 2);
            System.arraycopy(data, idx, data, idx+1, size-idx);
            data[idx] = item; size++;
        }

        @SuppressWarnings("unchecked")
        public T get(int idx) {
            if (idx < 0 || idx >= size) throw new IndexOutOfBoundsException();
            return (T) data[idx];
        }

        public void set(int idx, T item) {
            if (idx < 0 || idx >= size) throw new IndexOutOfBoundsException();
            data[idx] = item;
        }

        public void remove(int idx) {
            if (idx < 0 || idx >= size) throw new IndexOutOfBoundsException();
            System.arraycopy(data, idx+1, data, idx, size-idx-1);
            data[--size] = null;
            if (size < data.length/4 && data.length > INIT_CAP) resize(data.length/2);
        }

        private void resize(int newCap) {
            data = Arrays.copyOf(data, newCap);
        }

        public int size()     { return size; }
        public boolean isEmpty() { return size == 0; }

        @Override public String toString() {
            StringBuilder sb = new StringBuilder("[");
            for (int i = 0; i < size; i++) { sb.append(data[i]); if(i<size-1) sb.append(", "); }
            return sb.append("]").toString();
        }
    }

    // ============================================================
    // 2. LINKED LIST
    // ============================================================
    static class SinglyLinkedList<T> {
        private static class Node<T> { T data; Node<T> next; Node(T d){data=d;} }
        private Node<T> head; private int size;

        public void addFirst(T data) { Node<T> n=new Node<>(data); n.next=head; head=n; size++; }
        public void addLast(T data) {
            Node<T> n=new Node<>(data);
            if(head==null){head=n;}else{Node<T> cur=head;while(cur.next!=null)cur=cur.next;cur.next=n;}
            size++;
        }
        public T removeFirst() {
            if(head==null) throw new NoSuchElementException();
            T d=head.data; head=head.next; size--; return d;
        }
        public T get(int idx) {
            Node<T> cur=head; for(int i=0;i<idx;i++) cur=cur.next; return cur.data;
        }
        public boolean contains(T val) {
            for(Node<T> c=head;c!=null;c=c.next) if(Objects.equals(c.data,val)) return true;
            return false;
        }
        public void reverse() {
            Node<T> prev=null,cur=head;
            while(cur!=null){Node<T> next=cur.next;cur.next=prev;prev=cur;cur=next;}
            head=prev;
        }
        public int size() { return size; }
        @Override public String toString() {
            StringBuilder sb=new StringBuilder("[");
            for(Node<T> c=head;c!=null;c=c.next){sb.append(c.data);if(c.next!=null)sb.append(" -> ");}
            return sb.append("]").toString();
        }
    }

    // ============================================================
    // 3. STACK
    // ============================================================
    static class ArrayStack<T> {
        private Object[] data; private int top;
        @SuppressWarnings("unchecked")
        public ArrayStack(int cap) { data=new Object[cap]; top=-1; }
        public void push(T item) { if(top==data.length-1) throw new RuntimeException("Stack full"); data[++top]=item; }
        @SuppressWarnings("unchecked")
        public T pop()  { if(top<0) throw new EmptyStackException(); return (T)data[top--]; }
        @SuppressWarnings("unchecked")
        public T peek() { if(top<0) throw new EmptyStackException(); return (T)data[top]; }
        public boolean isEmpty() { return top<0; }
        public int size()        { return top+1; }
        @Override public String toString() {
            StringBuilder sb=new StringBuilder("Stack[");
            for(int i=top;i>=0;i--){sb.append(data[i]);if(i>0)sb.append(", ");}
            return sb.append("]").toString();
        }
    }

    // ============================================================
    // 4. QUEUE (Circular Array)
    // ============================================================
    static class CircularQueue<T> {
        private Object[] data; private int front,rear,size,cap;
        @SuppressWarnings("unchecked")
        public CircularQueue(int cap) { data=new Object[cap]; this.cap=cap; front=0; rear=-1; size=0; }
        public void enqueue(T item) {
            if(size==cap) throw new RuntimeException("Queue full");
            rear=(rear+1)%cap; data[rear]=item; size++;
        }
        @SuppressWarnings("unchecked")
        public T dequeue() {
            if(size==0) throw new NoSuchElementException();
            T item=(T)data[front]; front=(front+1)%cap; size--; return item;
        }
        @SuppressWarnings("unchecked")
        public T peek()      { if(size==0) throw new NoSuchElementException(); return (T)data[front]; }
        public boolean isEmpty() { return size==0; }
        public int size()        { return size; }
    }

    // ============================================================
    // 5. BINARY SEARCH TREE
    // ============================================================
    static class BST {
        private static class Node { int val; Node left,right; Node(int v){val=v;} }
        private Node root;

        public void insert(int val) { root=insert(root,val); }
        private Node insert(Node n, int val) {
            if(n==null) return new Node(val);
            if(val<n.val) n.left=insert(n.left,val);
            else if(val>n.val) n.right=insert(n.right,val);
            return n;
        }
        public boolean contains(int val) { return contains(root,val); }
        private boolean contains(Node n, int val) {
            if(n==null) return false;
            if(val==n.val) return true;
            return val<n.val ? contains(n.left,val) : contains(n.right,val);
        }
        public void delete(int val) { root=delete(root,val); }
        private Node delete(Node n, int val) {
            if(n==null) return null;
            if(val<n.val) n.left=delete(n.left,val);
            else if(val>n.val) n.right=delete(n.right,val);
            else {
                if(n.left==null) return n.right;
                if(n.right==null) return n.left;
                Node min=n.right; while(min.left!=null) min=min.left;
                n.val=min.val; n.right=delete(n.right,min.val);
            }
            return n;
        }
        public List<Integer> inOrder()  { List<Integer> r=new ArrayList<>(); inOrder(root,r); return r; }
        private void inOrder(Node n, List<Integer> r) { if(n==null)return; inOrder(n.left,r); r.add(n.val); inOrder(n.right,r); }
        public List<Integer> preOrder() { List<Integer> r=new ArrayList<>(); preOrder(root,r); return r; }
        private void preOrder(Node n, List<Integer> r){ if(n==null)return; r.add(n.val); preOrder(n.left,r); preOrder(n.right,r); }
        public int height() { return height(root); }
        private int height(Node n) { return n==null ? 0 : 1+Math.max(height(n.left),height(n.right)); }
        public List<List<Integer>> levelOrder() {
            List<List<Integer>> result=new ArrayList<>();
            if(root==null) return result;
            Queue<Node> q=new LinkedList<>(); q.add(root);
            while(!q.isEmpty()) {
                int sz=q.size(); List<Integer> level=new ArrayList<>();
                for(int i=0;i<sz;i++){Node n=q.poll();level.add(n.val);if(n.left!=null)q.add(n.left);if(n.right!=null)q.add(n.right);}
                result.add(level);
            }
            return result;
        }
    }

    // ============================================================
    // 6. GRAPH (Adjacency List)
    // ============================================================
    static class Graph {
        private int vertices;
        private Map<Integer, List<Integer>> adj = new HashMap<>();

        public Graph(int v) {
            vertices=v;
            for(int i=0;i<v;i++) adj.put(i,new ArrayList<>());
        }
        public void addEdge(int u, int v) { adj.get(u).add(v); adj.get(v).add(u); }
        public void addDirected(int u, int v) { adj.get(u).add(v); }

        public List<Integer> bfs(int start) {
            List<Integer> result=new ArrayList<>();
            boolean[] visited=new boolean[vertices];
            Queue<Integer> q=new LinkedList<>();
            q.add(start); visited[start]=true;
            while(!q.isEmpty()) {
                int node=q.poll(); result.add(node);
                for(int neighbor : adj.get(node))
                    if(!visited[neighbor]){visited[neighbor]=true;q.add(neighbor);}
            }
            return result;
        }

        public List<Integer> dfs(int start) {
            List<Integer> result=new ArrayList<>();
            boolean[] visited=new boolean[vertices];
            dfsHelper(start,visited,result);
            return result;
        }
        private void dfsHelper(int node, boolean[] visited, List<Integer> result) {
            visited[node]=true; result.add(node);
            for(int n:adj.get(node)) if(!visited[n]) dfsHelper(n,visited,result);
        }

        public boolean hasCycle() {
            boolean[] visited=new boolean[vertices], stack=new boolean[vertices];
            for(int i=0;i<vertices;i++) if(!visited[i]&&hasCycleHelper(i,visited,stack)) return true;
            return false;
        }
        private boolean hasCycleHelper(int node, boolean[] v, boolean[] s) {
            v[node]=s[node]=true;
            for(int n:adj.get(node)) {
                if(!v[n]&&hasCycleHelper(n,v,s)) return true;
                else if(s[n]) return true;
            }
            s[node]=false; return false;
        }
    }

    // ============================================================
    // 7. MIN HEAP
    // ============================================================
    static class MinHeap {
        private int[] data; private int size;
        public MinHeap(int cap) { data=new int[cap]; size=0; }
        public void insert(int val) {
            data[size++]=val; siftUp(size-1);
        }
        public int extractMin() {
            int min=data[0]; data[0]=data[--size]; siftDown(0); return min;
        }
        public int peek() { return data[0]; }
        public boolean isEmpty() { return size==0; }
        private void siftUp(int i) {
            while(i>0){int p=(i-1)/2;if(data[p]<=data[i])break;swap(i,p);i=p;}
        }
        private void siftDown(int i) {
            while(i<size){int l=2*i+1,r=2*i+2,m=i;
                if(l<size&&data[l]<data[m])m=l;
                if(r<size&&data[r]<data[m])m=r;
                if(m==i)break;swap(i,m);i=m;}
        }
        private void swap(int a, int b){int t=data[a];data[a]=data[b];data[b]=t;}
        public int size() { return size; }
    }

    public static void main(String[] args) {

        System.out.println("=== DYNAMIC ARRAY ===");
        DynamicArray<Integer> da = new DynamicArray<>();
        for (int i = 1; i <= 8; i++) da.add(i * 10);
        System.out.println("Array: " + da + " size=" + da.size());
        da.add(2, 25);
        System.out.println("After add(2,25): " + da);
        da.remove(0);
        System.out.println("After remove(0): " + da);
        System.out.println("get(3): " + da.get(3));

        System.out.println("\n=== LINKED LIST ===");
        SinglyLinkedList<Integer> ll = new SinglyLinkedList<>();
        ll.addLast(1); ll.addLast(2); ll.addLast(3); ll.addLast(4); ll.addLast(5);
        System.out.println("List: " + ll);
        ll.addFirst(0);
        System.out.println("addFirst(0): " + ll);
        System.out.println("contains(3): " + ll.contains(3));
        ll.reverse();
        System.out.println("reversed: " + ll);
        System.out.println("removeFirst: " + ll.removeFirst() + " -> " + ll);

        System.out.println("\n=== STACK ===");
        ArrayStack<String> stack = new ArrayStack<>(10);
        stack.push("A"); stack.push("B"); stack.push("C");
        System.out.println("Stack: " + stack + " top=" + stack.peek());
        System.out.println("pop: " + stack.pop() + " -> " + stack);

        System.out.println("\n=== CIRCULAR QUEUE ===");
        CircularQueue<Integer> queue = new CircularQueue<>(5);
        queue.enqueue(1); queue.enqueue(2); queue.enqueue(3);
        System.out.println("size="+queue.size()+" front="+queue.peek());
        System.out.println("dequeue: " + queue.dequeue());
        queue.enqueue(4); queue.enqueue(5); queue.enqueue(6);
        System.out.println("size="+queue.size()+" front="+queue.peek());

        System.out.println("\n=== BINARY SEARCH TREE ===");
        BST bst = new BST();
        int[] vals = {50, 30, 70, 20, 40, 60, 80, 10, 25, 35, 45};
        for (int v : vals) bst.insert(v);
        System.out.println("InOrder (sorted): " + bst.inOrder());
        System.out.println("PreOrder:         " + bst.preOrder());
        System.out.println("Level Order:      " + bst.levelOrder());
        System.out.println("Height:           " + bst.height());
        System.out.println("Contains 40:      " + bst.contains(40));
        System.out.println("Contains 99:      " + bst.contains(99));
        bst.delete(30);
        System.out.println("After delete(30): " + bst.inOrder());

        System.out.println("\n=== GRAPH BFS/DFS ===");
        Graph g = new Graph(6);
        g.addEdge(0, 1); g.addEdge(0, 2); g.addEdge(1, 3);
        g.addEdge(2, 4); g.addEdge(3, 5); g.addEdge(4, 5);
        System.out.println("BFS from 0: " + g.bfs(0));
        System.out.println("DFS from 0: " + g.dfs(0));

        Graph dag = new Graph(4);
        dag.addDirected(0,1); dag.addDirected(1,2); dag.addDirected(2,3);
        System.out.println("DAG has cycle: " + dag.hasCycle());

        System.out.println("\n=== MIN HEAP ===");
        MinHeap heap = new MinHeap(20);
        int[] heapData = {5,3,8,1,9,2,7,4,6};
        for (int v : heapData) heap.insert(v);
        System.out.print("Heap sort (extract min): ");
        while (!heap.isEmpty()) System.out.print(heap.extractMin() + " ");
        System.out.println();
    }
}
