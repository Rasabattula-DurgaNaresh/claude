/**
 * TOPIC 08: Polymorphism - Runtime & Compile-Time
 * =================================================
 * Polymorphism = "many forms"
 *
 * 1. Compile-time (Static):  Method Overloading, Operator Overloading
 * 2. Runtime (Dynamic):      Method Overriding, Virtual Method Invocation
 *
 * Dynamic dispatch: JVM decides which method to call at runtime
 * based on the ACTUAL type of the object, not the reference type.
 *
 * Upcasting: Parent ref = new Child() -- implicit, always safe
 * Downcasting: Child ref = (Child) parentRef -- explicit, may throw ClassCastException
 */
public class PolymorphismComplete {

    // ============================================================
    // SHAPE HIERARCHY (Classic Polymorphism Example)
    // ============================================================
    static abstract class Shape {
        private String color;
        private static int totalShapes = 0;

        public Shape(String color) { this.color = color; totalShapes++; }
        public abstract double area();
        public abstract double perimeter();
        public String getColor()                { return color; }
        public static int getTotalShapes()      { return totalShapes; }

        // Template method pattern: uses abstract methods
        public void printSummary() {
            System.out.printf("%-12s | color=%-8s | area=%8.3f | perimeter=%8.3f%n",
                getClass().getSimpleName(), color, area(), perimeter());
        }

        // Overloaded draw (compile-time polymorphism)
        public void draw()               { System.out.println("Drawing " + getClass().getSimpleName()); }
        public void draw(String style)   { System.out.println("Drawing " + getClass().getSimpleName() + " in " + style + " style"); }
        public void draw(int x, int y)   { System.out.println("Drawing " + getClass().getSimpleName() + " at (" + x + "," + y + ")"); }
    }

    static class Circle extends Shape {
        private double radius;
        public Circle(String color, double radius) { super(color); this.radius=radius; }
        @Override public double area()      { return Math.PI * radius * radius; }
        @Override public double perimeter() { return 2 * Math.PI * radius; }
        public double getRadius()           { return radius; }
    }

    static class Rectangle extends Shape {
        private double width, height;
        public Rectangle(String c, double w, double h) { super(c); width=w; height=h; }
        @Override public double area()      { return width * height; }
        @Override public double perimeter() { return 2 * (width + height); }
    }

    static class Triangle extends Shape {
        private double a, b, c;
        public Triangle(String col, double a, double b, double c) { super(col); this.a=a; this.b=b; this.c=c; }
        @Override public double area() { double s=(a+b+c)/2; return Math.sqrt(s*(s-a)*(s-b)*(s-c)); }
        @Override public double perimeter() { return a+b+c; }
    }

    static class Square extends Rectangle {
        public Square(String c, double side) { super(c, side, side); }
        @Override public void draw() { System.out.println("Drawing Square (special Rectangle)"); }
    }

    // ============================================================
    // PAYMENT SYSTEM (Real-World Polymorphism)
    // ============================================================
    interface Payable {
        boolean processPayment(double amount);
        String getMethodName();
        default String getReceipt(double amount) {
            return String.format("Receipt: Rs %.2f paid via %s", amount, getMethodName());
        }
    }

    static class CreditCard implements Payable {
        private String cardNumber; private String bank;
        public CreditCard(String num, String bank) { cardNumber=num; this.bank=bank; }
        @Override public boolean processPayment(double amount) {
            System.out.printf("  [Credit Card] %s bank *%s: Rs %.2f charged%n",
                bank, cardNumber.substring(cardNumber.length()-4), amount);
            return true;
        }
        @Override public String getMethodName() { return "Credit Card (" + bank + ")"; }
    }

    static class UPI implements Payable {
        private String upiId;
        public UPI(String id) { upiId=id; }
        @Override public boolean processPayment(double amount) {
            System.out.printf("  [UPI] %s: Rs %.2f transferred%n", upiId, amount);
            return true;
        }
        @Override public String getMethodName() { return "UPI (" + upiId + ")"; }
    }

    static class Cash implements Payable {
        private double cashGiven;
        public Cash(double cash) { cashGiven=cash; }
        @Override public boolean processPayment(double amount) {
            if (cashGiven < amount) { System.out.println("  [Cash] Insufficient!"); return false; }
            System.out.printf("  [Cash] Rs %.2f paid, change: Rs %.2f%n", cashGiven, cashGiven-amount);
            return true;
        }
        @Override public String getMethodName() { return "Cash"; }
    }

    static boolean checkout(Payable method, double amount) {
        System.out.println("Paying via: " + method.getMethodName());
        boolean success = method.processPayment(amount);
        if (success) System.out.println(method.getReceipt(amount));
        return success;
    }

    // ============================================================
    // NOTIFICATION SYSTEM
    // ============================================================
    static abstract class Notification {
        private String message;
        private String recipient;

        public Notification(String message, String recipient) {
            this.message=message; this.recipient=recipient;
        }

        public abstract void send();          // must override
        protected String getMessage()         { return message; }
        protected String getRecipient()       { return recipient; }

        // Template pattern
        public void sendWithLog() {
            System.out.println("[LOG] Sending " + getClass().getSimpleName() + " to " + recipient);
            send();
            System.out.println("[LOG] Sent successfully");
        }
    }

    static class EmailNotification extends Notification {
        public EmailNotification(String msg, String email) { super(msg, email); }
        @Override public void send() {
            System.out.println("EMAIL -> " + getRecipient() + ": " + getMessage());
        }
    }
    static class SMSNotification extends Notification {
        public SMSNotification(String msg, String phone) { super(msg, phone); }
        @Override public void send() {
            System.out.println("SMS -> " + getRecipient() + ": " + getMessage());
        }
    }
    static class PushNotification extends Notification {
        public PushNotification(String msg, String deviceId) { super(msg, deviceId); }
        @Override public void send() {
            System.out.println("PUSH -> Device[" + getRecipient() + "]: " + getMessage());
        }
    }

    public static void main(String[] args) {

        System.out.println("=== RUNTIME POLYMORPHISM - Shapes ===");
        Shape[] shapes = {
            new Circle("Red", 7),
            new Rectangle("Blue", 5, 8),
            new Triangle("Green", 3, 4, 5),
            new Square("Yellow", 6),
            new Circle("Purple", 3)
        };
        double totalArea = 0;
        for (Shape s : shapes) {
            s.printSummary();     // dynamic dispatch!
            totalArea += s.area();
        }
        System.out.printf("Total shapes: %d | Total area: %.3f%n", Shape.getTotalShapes(), totalArea);

        System.out.println("\n=== OVERLOADED METHODS (compile-time) ===");
        Shape c = new Circle("cyan", 4);
        c.draw();
        c.draw("vector");
        c.draw(100, 200);

        System.out.println("\n=== UPCASTING & DOWNCASTING ===");
        Shape s1 = new Circle("pink", 5);  // upcast (implicit)
        System.out.println("Actual type: " + s1.getClass().getSimpleName()); // Circle!
        System.out.println("area() via Shape ref: " + s1.area());  // Circle.area() called!

        // Downcast (explicit, may throw ClassCastException)
        if (s1 instanceof Circle circ) {           // pattern matching (Java 16+)
            System.out.println("Radius (via downcast): " + circ.getRadius());
        }
        // Manual downcast:
        Circle c2 = (Circle) s1;
        System.out.println("Radius (manual cast): " + c2.getRadius());

        // ClassCastException example
        try {
            Rectangle r = (Rectangle) s1;  // Circle cannot be cast to Rectangle!
        } catch (ClassCastException e) {
            System.out.println("ClassCastException caught: " + e.getMessage());
        }

        System.out.println("\n=== PAYMENT POLYMORPHISM ===");
        Payable[] methods = {
            new CreditCard("4111111111111234", "HDFC"),
            new UPI("alice@paytm"),
            new Cash(2000)
        };
        for (Payable p : methods) {
            checkout(p, 1499.0);
            System.out.println();
        }

        System.out.println("=== NOTIFICATION POLYMORPHISM ===");
        Notification[] notifications = {
            new EmailNotification("Your order is shipped!", "alice@example.com"),
            new SMSNotification("OTP: 123456", "+91-9876543210"),
            new PushNotification("Flash Sale! 50% off!", "device-abc-123")
        };
        for (Notification n : notifications) n.sendWithLog();
    }
}
