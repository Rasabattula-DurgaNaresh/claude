/**
 * TOPIC 32: Practice Programs - 50 Classic Java Problems
 * ========================================================
 * Covers: strings, numbers, arrays, OOP, logic, math
 * Perfect for interview preparation and skill building
 */
import java.util.*;
import java.util.stream.*;

public class PracticePrograms {

    // ============= NUMBER PROGRAMS =============
    static boolean isPalindrome(int n) {
        int orig=n, rev=0;
        while(n>0){rev=rev*10+n%10;n/=10;}
        return orig==rev;
    }
    static boolean isArmstrong(int n) {
        int sum=0,temp=n,digits=String.valueOf(n).length();
        while(temp>0){sum+=(int)Math.pow(temp%10,digits);temp/=10;}
        return sum==n;
    }
    static int sumOfDigits(int n) { int s=0;while(n>0){s+=n%10;n/=10;}return s; }
    static int reverseNum(int n)  { int r=0;while(n>0){r=r*10+n%10;n/=10;}return r; }
    static boolean isPerfect(int n){ int s=0;for(int i=1;i<n;i++)if(n%i==0)s+=i;return s==n; }
    static List<Integer> primeFactors(int n){
        List<Integer> f=new ArrayList<>();
        for(int d=2;d*d<=n;d++) while(n%d==0){f.add(d);n/=d;}
        if(n>1) f.add(n); return f;
    }
    static int gcd(int a,int b){return b==0?a:gcd(b,a%b);}
    static int lcm(int a,int b){return a/gcd(a,b)*b;}
    static boolean isPrime(int n){if(n<2)return false;for(int i=2;i*i<=n;i++)if(n%i==0)return false;return true;}

    // ============= STRING PROGRAMS =============
    static boolean isStringPalindrome(String s){
        int l=0,r=s.length()-1;
        while(l<r){if(s.charAt(l)!=s.charAt(r))return false;l++;r--;}
        return true;
    }
    static String reverseString(String s){return new StringBuilder(s).reverse().toString();}
    static String reverseWords(String s){
        String[] words=s.split("\\s+");
        StringBuilder sb=new StringBuilder();
        for(int i=words.length-1;i>=0;i--){sb.append(words[i]);if(i>0)sb.append(" ");}
        return sb.toString();
    }
    static boolean isAnagram(String a,String b){
        char[] c1=a.toLowerCase().toCharArray(),c2=b.toLowerCase().toCharArray();
        Arrays.sort(c1);Arrays.sort(c2);return Arrays.equals(c1,c2);
    }
    static Map<Character,Integer> charFrequency(String s){
        Map<Character,Integer> m=new LinkedHashMap<>();
        for(char c:s.toCharArray()) m.merge(c,1,Integer::sum);
        return m;
    }
    static char firstNonRepeating(String s){
        Map<Character,Integer> freq=charFrequency(s);
        for(char c:s.toCharArray()) if(freq.get(c)==1) return c;
        return '\0';
    }
    static int countVowels(String s){int c=0;for(char ch:s.toLowerCase().toCharArray())if("aeiou".indexOf(ch)>=0)c++;return c;}
    static String removeDuplicates(String s){
        StringBuilder sb=new StringBuilder();Set<Character> seen=new LinkedHashSet<>();
        for(char c:s.toCharArray())if(seen.add(c))sb.append(c);return sb.toString();
    }
    static String longestWord(String sentence){
        return Arrays.stream(sentence.split("\\s+")).max(Comparator.comparingInt(String::length)).orElse("");
    }
    static boolean isRotation(String s1,String s2){return s1.length()==s2.length()&&(s1+s1).contains(s2);}
    static String countAndSay(String s){
        StringBuilder result=new StringBuilder();
        int i=0,n=s.length();
        while(i<n){char c=s.charAt(i);int cnt=0;while(i<n&&s.charAt(i)==c){cnt++;i++;}result.append(cnt).append(c);}
        return result.toString();
    }

    // ============= ARRAY PROGRAMS =============
    static int[] twoSum(int[] nums,int target){
        Map<Integer,Integer> map=new HashMap<>();
        for(int i=0;i<nums.length;i++){int comp=target-nums[i];if(map.containsKey(comp))return new int[]{map.get(comp),i};map.put(nums[i],i);}
        return new int[]{-1,-1};
    }
    static void rotate(int[] a,int k){
        k%=a.length;reverse(a,0,a.length-1);reverse(a,0,k-1);reverse(a,k,a.length-1);
    }
    static void reverse(int[] a,int l,int r){while(l<r){int t=a[l];a[l]=a[r];a[r]=t;l++;r--;}}
    static int[] mergeSorted(int[] a,int[] b){
        int[] result=new int[a.length+b.length];
        int i=0,j=0,k=0;
        while(i<a.length&&j<b.length)result[k++]=a[i]<=b[j]?a[i++]:b[j++];
        while(i<a.length)result[k++]=a[i++];while(j<b.length)result[k++]=b[j++];
        return result;
    }
    static int findSecondLargest(int[] a){
        int first=Integer.MIN_VALUE,second=Integer.MIN_VALUE;
        for(int v:a){if(v>first){second=first;first=v;}else if(v>second&&v!=first)second=v;}
        return second;
    }
    static int maxSubarraySum(int[] a){int max=a[0],cur=a[0];for(int i=1;i<a.length;i++){cur=Math.max(a[i],cur+a[i]);max=Math.max(max,cur);}return max;}
    static List<Integer> findDuplicates(int[] a){
        Set<Integer> seen=new HashSet<>(),dups=new LinkedHashSet<>();
        for(int v:a)if(!seen.add(v))dups.add(v);return new ArrayList<>(dups);
    }
    static int[] moveZerosToEnd(int[] a){
        int[] r=a.clone();int pos=0;
        for(int v:r)if(v!=0)r[pos++]=v;
        while(pos<r.length)r[pos++]=0;return r;
    }

    // ============= OOP/LOGIC PROGRAMS =============
    static class FibonacciGenerator {
        private long a=0,b=1;
        public long next(){long tmp=a;a=b;b=tmp+b;return tmp;}
        public List<Long> first(int n){List<Long> r=new ArrayList<>();for(int i=0;i<n;i++)r.add(next());return r;}
    }

    static int fibonacci(int n){if(n<=1)return n;int a=0,b=1;for(int i=2;i<=n;i++){int t=a+b;a=b;b=t;}return b;}

    static class MatrixOps {
        static int[][] multiply(int[][] A,int[][] B){
            int n=A.length,m=B[0].length,k=B.length;
            int[][] C=new int[n][m];
            for(int i=0;i<n;i++)for(int j=0;j<m;j++)for(int l=0;l<k;l++)C[i][j]+=A[i][l]*B[l][j];
            return C;
        }
        static int[][] transpose(int[][] A){
            int[][] T=new int[A[0].length][A.length];
            for(int i=0;i<A.length;i++)for(int j=0;j<A[0].length;j++)T[j][i]=A[i][j];
            return T;
        }
        static void spiral(int[][] m){
            int top=0,bottom=m.length-1,left=0,right=m[0].length-1;
            System.out.print("Spiral: ");
            while(top<=bottom&&left<=right){
                for(int i=left;i<=right;i++)System.out.print(m[top][i]+" ");top++;
                for(int i=top;i<=bottom;i++)System.out.print(m[i][right]+" ");right--;
                if(top<=bottom){for(int i=right;i>=left;i--)System.out.print(m[bottom][i]+" ");bottom--;}
                if(left<=right){for(int i=bottom;i>=top;i--)System.out.print(m[i][left]+" ");left++;}
            }
            System.out.println();
        }
    }

    // Roman numerals
    static String toRoman(int n){
        int[] vals={1000,900,500,400,100,90,50,40,10,9,5,4,1};
        String[] syms={"M","CM","D","CD","C","XC","L","XL","X","IX","V","IV","I"};
        StringBuilder sb=new StringBuilder();
        for(int i=0;n>0;i++)while(n>=vals[i]){sb.append(syms[i]);n-=vals[i];}
        return sb.toString();
    }

    // Balanced parentheses
    static boolean isBalanced(String s){
        Deque<Character> stack=new ArrayDeque<>();
        for(char c:s.toCharArray()){
            if("({[".indexOf(c)>=0){stack.push(c);}
            else if(")}]".indexOf(c)>=0){
                if(stack.isEmpty()) return false;
                char top=stack.pop();
                if((c==')'&&top!='(')||(c=='}'&&top!='{')||(c==']'&&top!='['))return false;
            }
        }
        return stack.isEmpty();
    }

    // Valid number
    static boolean isValidNumber(String s){try{Double.parseDouble(s);return true;}catch(NumberFormatException e){return false;}}

    // Binary conversion
    static String decToBin(int n){return Integer.toBinaryString(n);}
    static int binToDec(String b){return Integer.parseInt(b,2);}

    // Caesar cipher
    static String caesarCipher(String s,int shift){
        StringBuilder sb=new StringBuilder();
        for(char c:s.toCharArray()){
            if(Character.isLetter(c)){
                char base=Character.isUpperCase(c)?'A':'a';
                sb.append((char)(base+(c-base+shift)%26));
            }else sb.append(c);
        }
        return sb.toString();
    }

    // FizzBuzz
    static List<String> fizzBuzz(int n){
        List<String> r=new ArrayList<>();
        for(int i=1;i<=n;i++){
            if(i%15==0)r.add("FizzBuzz");
            else if(i%3==0)r.add("Fizz");
            else if(i%5==0)r.add("Buzz");
            else r.add(String.valueOf(i));
        }
        return r;
    }

    public static void main(String[] args) {

        System.out.println("===== 50 CLASSIC JAVA PROGRAMS =====\n");

        // 1-5: Number checks
        System.out.println("--- Numbers ---");
        int[] nums = {121, 123, 153, 370, 6, 28, 496, 12321, 100};
        for (int n : nums) {
            System.out.printf("n=%-5d | palindrome=%-5b | armstrong=%-5b | perfect=%-5b | prime=%-5b%n",
                n, isPalindrome(n), isArmstrong(n), isPerfect(n), isPrime(n));
        }

        // 6-10: Number operations
        System.out.println("\n--- Number Operations ---");
        System.out.println("6.  sumDigits(12345)    = " + sumOfDigits(12345));
        System.out.println("7.  reverse(12345)      = " + reverseNum(12345));
        System.out.println("8.  primeFactors(360)   = " + primeFactors(360));
        System.out.println("9.  GCD(48,18)          = " + gcd(48, 18));
        System.out.println("10. LCM(12,18)          = " + lcm(12, 18));

        // 11-22: String programs
        System.out.println("\n--- Strings ---");
        System.out.println("11. isPalindrome(racecar)   = " + isStringPalindrome("racecar"));
        System.out.println("12. isPalindrome(hello)     = " + isStringPalindrome("hello"));
        System.out.println("13. reverse(Hello Java)     = " + reverseString("Hello Java"));
        System.out.println("14. reverseWords(Java is fun)= " + reverseWords("Java is fun"));
        System.out.println("15. isAnagram(listen,silent)= " + isAnagram("listen", "silent"));
        System.out.println("16. charFrequency(hello)    = " + charFrequency("hello"));
        System.out.println("17. firstNonRepeating(aabbc)= " + firstNonRepeating("aabbc"));
        System.out.println("18. countVowels(Hello World)= " + countVowels("Hello World"));
        System.out.println("19. removeDuplicates(programming) = " + removeDuplicates("programming"));
        System.out.println("20. longestWord(The quick brown fox)= " + longestWord("The quick brown fox"));
        System.out.println("21. isRotation(abcde,cdeab)= " + isRotation("abcde", "cdeab"));
        System.out.println("22. countAndSay(111221)     = " + countAndSay("111221"));

        // 23-32: Array programs
        System.out.println("\n--- Arrays ---");
        int[] arr = {2, 7, 11, 15};
        System.out.println("23. twoSum([2,7,11,15],9)  = " + Arrays.toString(twoSum(arr, 9)));
        int[] rot = {1,2,3,4,5,6,7}; rotate(rot,3);
        System.out.println("24. rotate([1..7],3)       = " + Arrays.toString(rot));
        int[] a1={1,3,5,7}, a2={2,4,6,8};
        System.out.println("25. mergeSorted([1,3,5,7],[2,4,6,8]) = " + Arrays.toString(mergeSorted(a1,a2)));
        int[] arr2 = {3, 1, 4, 1, 5, 9, 2, 6, 5};
        System.out.println("26. secondLargest         = " + findSecondLargest(arr2));
        int[] sub = {-2,1,-3,4,-1,2,1,-5,4};
        System.out.println("27. maxSubarraySum(Kadane)= " + maxSubarraySum(sub));
        int[] dups = {1,2,3,4,2,5,3,6,1};
        System.out.println("28. findDuplicates        = " + findDuplicates(dups));
        int[] zeros = {0,1,0,3,12,0,5};
        System.out.println("29. moveZerosToEnd        = " + Arrays.toString(moveZerosToEnd(zeros)));

        // Spiral matrix
        int[][] matrix = {{1,2,3},{4,5,6},{7,8,9}};
        MatrixOps.spiral(matrix);

        // 30-32: Matrix
        int[][] A = {{1,2},{3,4}}, B = {{5,6},{7,8}};
        int[][] prod = MatrixOps.multiply(A,B);
        System.out.println("30. Matrix product [1,2;3,4]*[5,6;7,8]: " + Arrays.deepToString(prod));
        System.out.println("31. Transpose of [[1,2],[3,4]]: " + Arrays.deepToString(MatrixOps.transpose(A)));

        // 33-40: OOP/Logic
        System.out.println("\n--- Logic & OOP ---");
        FibonacciGenerator fib = new FibonacciGenerator();
        System.out.println("33. First 10 Fibonacci: " + fib.first(10));
        System.out.println("34. Fib(20) iterative: " + fibonacci(20));
        System.out.println("35. FizzBuzz(1-20): " + fizzBuzz(20));
        System.out.println("36. isBalanced({[()]})  = " + isBalanced("{[()]}"));
        System.out.println("    isBalanced({[()]}) = " + isBalanced("{[(])}"));
        System.out.println("37. Roman(2024) = " + toRoman(2024));
        System.out.println("    Roman(1999) = " + toRoman(1999));
        System.out.println("    Roman(58)   = " + toRoman(58));
        System.out.println("38. decToBin(255) = " + decToBin(255));
        System.out.println("    binToDec(11111111) = " + binToDec("11111111"));
        System.out.println("39. caesarCipher(Hello World, 3) = " + caesarCipher("Hello World", 3));
        System.out.println("    caesarDecrypt:  " + caesarCipher("Khoor Zruog", 23));
        System.out.println("40. isValidNumber(3.14) = " + isValidNumber("3.14"));
        System.out.println("    isValidNumber(abc)  = " + isValidNumber("abc"));

        // 41-50: Advanced
        System.out.println("\n--- Advanced ---");
        // Pangram check
        String sentence = "The quick brown fox jumps over the lazy dog";
        boolean isPangram = "abcdefghijklmnopqrstuvwxyz".chars()
            .allMatch(c -> sentence.toLowerCase().indexOf(c) >= 0);
        System.out.println("41. isPangram:    " + isPangram);

        // Word count in sentence
        Map<String, Long> wordCount = Arrays.stream(sentence.split(" "))
            .collect(java.util.stream.Collectors.groupingBy(w->w.toLowerCase(), java.util.stream.Collectors.counting()));
        System.out.println("42. WordCount:    " + new TreeMap<>(wordCount));

        // Largest prime under N
        int N = 100;
        int largestPrime = IntStream.rangeClosed(2, N).filter(n -> isPrime(n)).max().orElse(-1);
        System.out.println("43. LargestPrime<100: " + largestPrime);

        // Sum of primes under 100
        int primeSum = IntStream.rangeClosed(2, N).filter(n -> isPrime(n)).sum();
        System.out.println("44. SumPrimes<100:    " + primeSum);

        // Pascal's triangle
        System.out.println("45. Pascal's Triangle (5 rows):");
        for(int i=0;i<5;i++){
            int val=1;
            for(int j=0;j<=i;j++){System.out.print(val+" ");val=val*(i-j)/(j+1);}
            System.out.println();
        }

        // Power of 2 check
        System.out.println("46. isPowerOf2(64) = " + (64>0 && (64&(64-1))==0));
        System.out.println("    isPowerOf2(63) = " + (63>0 && (63&(63-1))==0));

        // Count set bits
        System.out.println("47. setBits(255) = " + Integer.bitCount(255));
        System.out.println("    setBits(170) = " + Integer.bitCount(170));

        // Find missing number (sum formula)
        int[] consecutive = {1,2,3,4,6,7,8,9,10}; // missing 5
        int n = 10, expectedSum = n*(n+1)/2, actualSum = 0;
        for(int v:consecutive) actualSum+=v;
        System.out.println("48. MissingNumber = " + (expectedSum-actualSum));

        // Anagram groups
        List<String> words = Arrays.asList("eat","tea","tan","ate","nat","bat");
        Map<String, List<String>> anagramGroups = words.stream()
            .collect(java.util.stream.Collectors.groupingBy(w->{char[]c=w.toCharArray();Arrays.sort(c);return new String(c);}));
        System.out.println("49. AnagramGroups = " + anagramGroups.values());

        // Longest substring without repeating
        String testStr = "abcabcbb";
        int maxLen=0, start=0; Map<Character,Integer> pos=new HashMap<>();
        for(int i=0;i<testStr.length();i++){
            char c=testStr.charAt(i);
            if(pos.containsKey(c)&&pos.get(c)>=start) start=pos.get(c)+1;
            pos.put(c,i); maxLen=Math.max(maxLen,i-start+1);
        }
        System.out.println("50. LongestSubstr(abcabcbb) = " + maxLen);

        System.out.println("\n===== ALL 50 PROGRAMS COMPLETE! =====");
    }
}
