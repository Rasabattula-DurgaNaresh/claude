/**
 * TOPIC 27: Behavioral Design Patterns
 * =======================================
 * 1. Observer    : event notification (subscribe/publish)
 * 2. Strategy    : interchangeable algorithms
 * 3. Command     : encapsulate actions (undo/redo)
 * 4. Template Method: skeleton algorithm, subclass fills gaps
 * 5. Iterator    : traverse without exposing internals
 * 6. State       : change behavior based on state
 * 7. Chain of Responsibility: pass request through chain
 */
import java.util.*;

public class BehavioralPatterns {

    // ============================================================
    // 1. OBSERVER
    // ============================================================
    interface Observer { void update(String event, Object data); }
    interface Observable {
        void addObserver(String event, Observer o);
        void removeObserver(String event, Observer o);
        void notifyObservers(String event, Object data);
    }

    static class StockMarket implements Observable {
        private final Map<String, List<Observer>> observers = new HashMap<>();
        private final Map<String, Double> prices = new HashMap<>();

        public void addObserver(String event, Observer o) {
            observers.computeIfAbsent(event, k -> new ArrayList<>()).add(o);
        }
        public void removeObserver(String event, Observer o) {
            observers.getOrDefault(event, List.of()).remove(o);
        }
        public void notifyObservers(String event, Object data) {
            observers.getOrDefault(event, List.of()).forEach(o -> o.update(event, data));
            observers.getOrDefault("ALL", List.of()).forEach(o -> o.update(event, data));
        }
        public void updatePrice(String stock, double newPrice) {
            double old = prices.getOrDefault(stock, 0.0);
            prices.put(stock, newPrice);
            double change = ((newPrice - old) / Math.max(old, 1)) * 100;
            System.out.printf("[Market] %s: %.2f -> %.2f (%.1f%%)%n", stock, old, newPrice, change);
            notifyObservers(stock, Map.of("price", newPrice, "change", change));
            if (Math.abs(change) > 5) notifyObservers("ALERT", Map.of("stock", stock, "change", change));
        }
    }

    // ============================================================
    // 2. STRATEGY
    // ============================================================
    interface SortStrategy { void sort(int[] arr); String getName(); }

    static class BubbleSort implements SortStrategy {
        public void sort(int[] arr) {
            for (int i = 0; i < arr.length-1; i++)
                for (int j = 0; j < arr.length-i-1; j++)
                    if (arr[j] > arr[j+1]) { int t=arr[j]; arr[j]=arr[j+1]; arr[j+1]=t; }
        }
        public String getName() { return "BubbleSort O(n²)"; }
    }

    static class SelectionSort implements SortStrategy {
        public void sort(int[] arr) {
            for (int i = 0; i < arr.length-1; i++) {
                int minIdx = i;
                for (int j = i+1; j < arr.length; j++) if (arr[j] < arr[minIdx]) minIdx = j;
                int t = arr[i]; arr[i] = arr[minIdx]; arr[minIdx] = t;
            }
        }
        public String getName() { return "SelectionSort O(n²)"; }
    }

    static class QuickSort implements SortStrategy {
        public void sort(int[] arr) { quickSort(arr, 0, arr.length-1); }
        private void quickSort(int[] arr, int lo, int hi) {
            if (lo >= hi) return;
            int pivot = arr[hi], i = lo-1;
            for (int j = lo; j < hi; j++) if (arr[j] <= pivot) { i++; int t=arr[i]; arr[i]=arr[j]; arr[j]=t; }
            int t=arr[i+1]; arr[i+1]=arr[hi]; arr[hi]=t;
            int p = i+1;
            quickSort(arr, lo, p-1); quickSort(arr, p+1, hi);
        }
        public String getName() { return "QuickSort O(n log n)"; }
    }

    static class Sorter {
        private SortStrategy strategy;
        public Sorter(SortStrategy s) { strategy = s; }
        public void setStrategy(SortStrategy s) { strategy = s; }
        public int[] sort(int[] arr) {
            int[] copy = arr.clone();
            long start = System.nanoTime();
            strategy.sort(copy);
            System.out.printf("[%s] sorted in %d ns%n", strategy.getName(), System.nanoTime()-start);
            return copy;
        }
    }

    // ============================================================
    // 3. COMMAND (with Undo/Redo)
    // ============================================================
    interface Command { void execute(); void undo(); String description(); }

    static class TextEditor {
        private StringBuilder text = new StringBuilder();
        private final Deque<Command> history = new ArrayDeque<>();
        private final Deque<Command> redoStack = new ArrayDeque<>();

        private void execute(Command cmd) {
            cmd.execute();
            history.push(cmd);
            redoStack.clear(); // clear redo on new action
        }

        public void type(String chars) {
            execute(new Command() {
                public void execute()      { text.append(chars); }
                public void undo()         { text.delete(text.length()-chars.length(), text.length()); }
                public String description(){ return "Type '" + chars + "'"; }
            });
        }

        public void delete(int n) {
            String deleted = text.substring(Math.max(0, text.length()-n));
            execute(new Command() {
                public void execute()      { text.delete(Math.max(0, text.length()-n), text.length()); }
                public void undo()         { text.append(deleted); }
                public String description(){ return "Delete " + n + " chars (was: '" + deleted + "')"; }
            });
        }

        public void undo() {
            if (!history.isEmpty()) {
                Command cmd = history.pop();
                cmd.undo();
                redoStack.push(cmd);
                System.out.println("  Undo: " + cmd.description());
            } else System.out.println("  Nothing to undo");
        }

        public void redo() {
            if (!redoStack.isEmpty()) {
                Command cmd = redoStack.pop();
                cmd.execute();
                history.push(cmd);
                System.out.println("  Redo: " + cmd.description());
            } else System.out.println("  Nothing to redo");
        }

        public String getText() { return text.toString(); }
    }

    // ============================================================
    // 4. TEMPLATE METHOD
    // ============================================================
    static abstract class DataExporter {
        // Template method defines skeleton
        public final void export(String data, String destination) {
            System.out.println("=== Exporting ===");
            String validated = validate(data);
            String transformed = transform(validated);
            String formatted = format(transformed);
            write(formatted, destination);
            notifyCompletion(destination);
        }

        protected String validate(String data) {
            if (data == null || data.isBlank()) throw new IllegalArgumentException("Empty data!");
            System.out.println("  [Validate] OK");
            return data.trim();
        }

        protected abstract String transform(String data);  // must override
        protected abstract String format(String data);     // must override

        protected void write(String data, String dest) {
            System.out.println("  [Write] -> " + dest + " (" + data.length() + " chars)");
        }

        protected void notifyCompletion(String dest) {  // optional hook
            System.out.println("  [Done] Export to " + dest + " complete");
        }
    }

    static class CsvExporter extends DataExporter {
        protected String transform(String data) { return data.replace("|", ","); }
        protected String format(String data) {
            return "id,name,value\n" + data;
        }
    }

    static class JsonExporter extends DataExporter {
        protected String transform(String data) {
            return Arrays.stream(data.split("\n"))
                .map(line -> { String[] p=line.split("\\|"); return String.format("{\"id\":\"%s\",\"name\":\"%s\",\"value\":\"%s\"}", p[0],p[1],p[2]); })
                .reduce("", (a,b) -> a.isEmpty() ? b : a + ",\n" + b);
        }
        protected String format(String data) { return "[\n" + data + "\n]"; }
    }

    // ============================================================
    // 5. STATE
    // ============================================================
    interface OrderState {
        void processPayment(OrderContext ctx);
        void ship(OrderContext ctx);
        void deliver(OrderContext ctx);
        void cancel(OrderContext ctx);
        String getStateName();
    }

    static class OrderContext {
        private OrderState state;
        private String orderId;

        public OrderContext(String id) {
            orderId=id; state=new PendingState();
            System.out.println("[Order " + id + "] Created -> " + state.getStateName());
        }

        public void setState(OrderState s) {
            System.out.println("[Order " + orderId + "] " + state.getStateName() + " -> " + s.getStateName());
            state = s;
        }

        public void processPayment() { state.processPayment(this); }
        public void ship()           { state.ship(this); }
        public void deliver()        { state.deliver(this); }
        public void cancel()         { state.cancel(this); }
        public String getState()     { return state.getStateName(); }
    }

    static class PendingState implements OrderState {
        public void processPayment(OrderContext c) { c.setState(new PaidState()); System.out.println("  Payment received!"); }
        public void ship(OrderContext c)     { System.out.println("  Cannot ship: payment pending!"); }
        public void deliver(OrderContext c)  { System.out.println("  Cannot deliver: payment pending!"); }
        public void cancel(OrderContext c)   { c.setState(new CancelledState()); System.out.println("  Order cancelled."); }
        public String getStateName()          { return "PENDING"; }
    }
    static class PaidState implements OrderState {
        public void processPayment(OrderContext c) { System.out.println("  Already paid!"); }
        public void ship(OrderContext c)     { c.setState(new ShippedState()); System.out.println("  Shipped!"); }
        public void deliver(OrderContext c)  { System.out.println("  Not shipped yet!"); }
        public void cancel(OrderContext c)   { c.setState(new CancelledState()); System.out.println("  Cancelled (refund initiated)."); }
        public String getStateName()          { return "PAID"; }
    }
    static class ShippedState implements OrderState {
        public void processPayment(OrderContext c) { System.out.println("  Already paid!"); }
        public void ship(OrderContext c)     { System.out.println("  Already shipped!"); }
        public void deliver(OrderContext c)  { c.setState(new DeliveredState()); System.out.println("  Delivered!"); }
        public void cancel(OrderContext c)   { System.out.println("  Cannot cancel: already shipped!"); }
        public String getStateName()          { return "SHIPPED"; }
    }
    static class DeliveredState implements OrderState {
        public void processPayment(OrderContext c) { System.out.println("  Already paid!"); }
        public void ship(OrderContext c)     { System.out.println("  Already delivered!"); }
        public void deliver(OrderContext c)  { System.out.println("  Already delivered!"); }
        public void cancel(OrderContext c)   { System.out.println("  Cannot cancel: delivered!"); }
        public String getStateName()          { return "DELIVERED"; }
    }
    static class CancelledState implements OrderState {
        public void processPayment(OrderContext c) { System.out.println("  Order is cancelled!"); }
        public void ship(OrderContext c)     { System.out.println("  Order is cancelled!"); }
        public void deliver(OrderContext c)  { System.out.println("  Order is cancelled!"); }
        public void cancel(OrderContext c)   { System.out.println("  Already cancelled!"); }
        public String getStateName()          { return "CANCELLED"; }
    }

    // ============================================================
    // 6. CHAIN OF RESPONSIBILITY
    // ============================================================
    static abstract class RequestHandler {
        protected RequestHandler next;
        public RequestHandler setNext(RequestHandler next) { this.next=next; return next; }
        public abstract boolean handle(Map<String,Object> request);
    }

    static class AuthHandler extends RequestHandler {
        public boolean handle(Map<String,Object> req) {
            String token = (String) req.get("token");
            if (token == null || !token.startsWith("valid-")) {
                System.out.println("  [Auth] FAILED: invalid token");
                return false;
            }
            System.out.println("  [Auth] OK");
            return next == null || next.handle(req);
        }
    }

    static class RateLimitHandler extends RequestHandler {
        private Map<String, Integer> counts = new HashMap<>();
        private static final int MAX = 3;
        public boolean handle(Map<String,Object> req) {
            String user = (String) req.get("user");
            int cnt = counts.merge(user, 1, Integer::sum);
            if (cnt > MAX) { System.out.println("  [RateLimit] FAILED: limit exceeded for " + user); return false; }
            System.out.println("  [RateLimit] OK (" + cnt + "/" + MAX + ")");
            return next == null || next.handle(req);
        }
    }

    static class LoggingHandler extends RequestHandler {
        public boolean handle(Map<String,Object> req) {
            System.out.println("  [Logger] Request: " + req);
            return next == null || next.handle(req);
        }
    }

    static class BusinessHandler extends RequestHandler {
        public boolean handle(Map<String,Object> req) {
            System.out.println("  [Business] Processing: " + req.get("action"));
            return true;
        }
    }

    public static void main(String[] args) {

        System.out.println("=== 1. OBSERVER ===");
        StockMarket market = new StockMarket();
        market.addObserver("TATA", (e,d) -> System.out.println("  Portfolio App: TATA update: " + d));
        market.addObserver("TATA", (e,d) -> System.out.println("  Mobile Alert:  TATA update: " + d));
        market.addObserver("ALERT", (e,d) -> System.out.println("  !! ALERT !! " + d));
        market.updatePrice("TATA", 3500.0);
        market.updatePrice("TATA", 3800.0);  // +8.5% -> triggers ALERT

        System.out.println("\n=== 2. STRATEGY ===");
        int[] data = {64, 34, 25, 12, 22, 11, 90};
        Sorter sorter = new Sorter(new BubbleSort());
        System.out.println("Original: " + Arrays.toString(data));
        System.out.println("Bubble:   " + Arrays.toString(sorter.sort(data)));
        sorter.setStrategy(new QuickSort());
        System.out.println("Quick:    " + Arrays.toString(sorter.sort(data)));

        System.out.println("\n=== 3. COMMAND (Undo/Redo) ===");
        TextEditor editor = new TextEditor();
        editor.type("Hello");
        editor.type(", World");
        System.out.println("Text: " + editor.getText());
        editor.delete(5);
        System.out.println("Text: " + editor.getText());
        editor.undo();
        System.out.println("After undo: " + editor.getText());
        editor.undo();
        System.out.println("After undo: " + editor.getText());
        editor.redo();
        System.out.println("After redo: " + editor.getText());

        System.out.println("\n=== 4. TEMPLATE METHOD ===");
        String rawData = "1|Alice|95000\n2|Bob|85000\n3|Charlie|75000";
        new CsvExporter().export(rawData, "output.csv");
        System.out.println();
        new JsonExporter().export(rawData, "output.json");

        System.out.println("\n=== 5. STATE ===");
        OrderContext order = new OrderContext("ORD-001");
        order.ship();           // fail: pending
        order.processPayment(); // -> PAID
        order.cancel();         // -> CANCELLED
        order.ship();           // fail: cancelled

        OrderContext order2 = new OrderContext("ORD-002");
        order2.processPayment();
        order2.ship();
        order2.deliver();
        order2.cancel();        // fail: delivered

        System.out.println("\n=== 6. CHAIN OF RESPONSIBILITY ===");
        AuthHandler auth = new AuthHandler();
        RateLimitHandler rate = new RateLimitHandler();
        LoggingHandler log = new LoggingHandler();
        BusinessHandler biz = new BusinessHandler();
        auth.setNext(rate).setNext(log).setNext(biz);

        Map<String,Object> req1 = Map.of("token","valid-abc","user","alice","action","view-dashboard");
        Map<String,Object> req2 = Map.of("token","valid-abc","user","alice","action","view-report");
        Map<String,Object> req3 = Map.of("token","valid-abc","user","alice","action","download");
        Map<String,Object> req4 = Map.of("token","valid-abc","user","alice","action","upload");
        Map<String,Object> req5 = Map.of("token","invalid","user","bob","action","hack");

        for (Map<String,Object> req : List.of(req1, req2, req3, req4, req5)) {
            System.out.println("Request: " + req.get("action") + " by " + req.get("user"));
            boolean ok = auth.handle(req);
            System.out.println("Result: " + (ok ? "ALLOWED" : "REJECTED") + "\n");
        }
    }
}
