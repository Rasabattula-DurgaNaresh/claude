/**
 * TOPIC 05: Strings - Complete Reference
 * ========================================
 * String: immutable, stored in String Pool
 * StringBuilder: mutable, not thread-safe, fast
 * StringBuffer: mutable, thread-safe, slower
 * Java 11+ new methods: strip, isBlank, repeat, lines
 * Java 15+ text blocks (multiline strings)
 * Regular expressions: matches, replaceAll, split
 */
public class StringsComplete {
    public static void main(String[] args) {

        // ============================================================
        // STRING CREATION & POOL
        // ============================================================
        System.out.println("=== STRING POOL & CREATION ===");
        String s1 = "Java";           // String Pool
        String s2 = "Java";           // Same pool reference
        String s3 = new String("Java"); // Heap (new object)
        String s4 = "Java".intern();  // force pool

        System.out.println("s1 == s2 (pool):  " + (s1 == s2));       // true
        System.out.println("s1 == s3 (heap):  " + (s1 == s3));       // false!
        System.out.println("s1.equals(s3):    " + s1.equals(s3));    // true
        System.out.println("s3.intern()==s1:  " + (s3.intern() == s1)); // true

        // ============================================================
        // LENGTH & CHARACTER ACCESS
        // ============================================================
        System.out.println("\n=== LENGTH & CHARACTER ACCESS ===");
        String str = "Hello, Java World!";
        System.out.println("String: '" + str + "'");
        System.out.println("length():          " + str.length());
        System.out.println("charAt(7):         " + str.charAt(7));     // 'J'
        System.out.println("charAt(-1 equiv):  " + str.charAt(str.length()-1)); // '!'
        System.out.println("indexOf('a'):      " + str.indexOf('a'));   // 8
        System.out.println("lastIndexOf('a'):  " + str.lastIndexOf('a')); // 10
        System.out.println("indexOf(\"Java\"):  " + str.indexOf("Java"));
        System.out.println("indexOf('a',9):    " + str.indexOf('a', 9)); // start at 9

        // ============================================================
        // SUBSTRING & EXTRACTION
        // ============================================================
        System.out.println("\n=== SUBSTRING ===");
        System.out.println("substring(7):      " + str.substring(7));        // "Java World!"
        System.out.println("substring(7,11):   " + str.substring(7, 11));    // "Java"

        // ============================================================
        // COMPARISON
        // ============================================================
        System.out.println("\n=== COMPARISON ===");
        String a = "apple", b = "APPLE", c = "banana";
        System.out.println("equals:            " + a.equals(b));           // false
        System.out.println("equalsIgnoreCase:  " + a.equalsIgnoreCase(b)); // true
        System.out.println("compareTo:         " + a.compareTo(c));        // negative (a < b)
        System.out.println("compareToIgnoreCase: " + a.compareToIgnoreCase(b)); // 0
        System.out.println("contentEquals:     " + a.contentEquals("apple"));  // true

        // ============================================================
        // CASE & TRIM
        // ============================================================
        System.out.println("\n=== CASE & TRIM ===");
        String s = "  Hello World  ";
        System.out.println("original:      '" + s + "'");
        System.out.println("toUpperCase:   '" + s.toUpperCase() + "'");
        System.out.println("toLowerCase:   '" + s.toLowerCase() + "'");
        System.out.println("trim():        '" + s.trim() + "'");      // removes ASCII whitespace
        System.out.println("strip():       '" + s.strip() + "'");     // Java 11, Unicode-aware
        System.out.println("stripLeading:  '" + s.stripLeading() + "'");
        System.out.println("stripTrailing: '" + s.stripTrailing() + "'");

        // ============================================================
        // CONTAINS, STARTS/ENDS WITH
        // ============================================================
        System.out.println("\n=== SEARCH ===");
        System.out.println("contains(\"World\"): " + str.contains("World"));
        System.out.println("startsWith(\"Hello\"): " + str.startsWith("Hello"));
        System.out.println("startsWith(\"Java\",7): " + str.startsWith("Java", 7));
        System.out.println("endsWith(\"World!\"): " + str.endsWith("World!"));
        System.out.println("isEmpty():          " + "".isEmpty());
        System.out.println("isBlank():          " + "  ".isBlank());    // Java 11+
        System.out.println("matches(regex):     " + "12345".matches("\\d+"));

        // ============================================================
        // REPLACE & SPLIT
        // ============================================================
        System.out.println("\n=== REPLACE & SPLIT ===");
        String text = "The quick brown fox jumps over the lazy dog";
        System.out.println("replace('o','0'):     " + text.replace('o','0'));
        System.out.println("replace(\"fox\",\"cat\"): " + text.replace("fox","cat"));
        System.out.println("replaceAll([aeiou]): " + text.replaceAll("[aeiou]","*"));
        System.out.println("replaceFirst(\\w+):  " + text.replaceFirst("\\w+","A"));

        String csv = "Alice,28,Engineer,Hyderabad,India";
        String[] parts = csv.split(",");
        System.out.println("split(','):    " + java.util.Arrays.toString(parts));
        System.out.println("split limit=3: " + java.util.Arrays.toString(csv.split(",", 3)));

        // ============================================================
        // JAVA 11+ NEW METHODS
        // ============================================================
        System.out.println("\n=== JAVA 11+ STRING METHODS ===");
        System.out.println("repeat: " + "ha".repeat(3));          // hahaha
        System.out.println("isBlank: " + "   ".isBlank());        // true
        System.out.println("lines count: " + "a\nb\nc".lines().count()); // 3
        "line1\nline2\nline3".lines().forEach(l -> System.out.println("  > " + l));

        // Java 15+ formatted()
        String template = "Name: %s, Age: %d".formatted("Alice", 25);
        System.out.println("formatted: " + template);

        // ============================================================
        // STRING FORMATTING
        // ============================================================
        System.out.println("\n=== STRING FORMAT ===");
        System.out.println(String.format("%-10s | %5d | %8.2f", "Alice", 25, 9500.5));
        System.out.println(String.format("Hex: %X | Oct: %o | Sci: %e", 255, 255, 12345.678));
        System.out.printf("Name: %s%n", "Bob");

        // ============================================================
        // CONVERSION
        // ============================================================
        System.out.println("\n=== CONVERSION ===");
        System.out.println("String.valueOf(42):     " + String.valueOf(42));
        System.out.println("String.valueOf(true):   " + String.valueOf(true));
        System.out.println("String.valueOf(3.14):   " + String.valueOf(3.14));
        System.out.println("Integer.parseInt(\"123\"): " + Integer.parseInt("123"));
        System.out.println("Double.parseDouble:     " + Double.parseDouble("3.14"));
        System.out.println("Integer.toBinaryString: " + Integer.toBinaryString(255));
        System.out.println("Integer.toHexString:    " + Integer.toHexString(255));

        // ============================================================
        // STRINGBUILDER
        // ============================================================
        System.out.println("\n=== STRINGBUILDER ===");
        StringBuilder sb = new StringBuilder();
        sb.append("Hello").append(", ").append("World");
        sb.insert(5, " Beautiful");
        System.out.println("After append+insert: " + sb);
        sb.delete(5, 15);
        System.out.println("After delete(5,15):  " + sb);
        sb.replace(7, 12, "Java");
        System.out.println("After replace:       " + sb);
        sb.reverse();
        System.out.println("After reverse:       " + sb);
        sb.reverse();  // restore
        System.out.println("Capacity: " + sb.capacity() + " Length: " + sb.length());

        // Performance test
        long t1 = System.currentTimeMillis();
        String concat = "";
        for (int i = 0; i < 5000; i++) concat += i;  // slow! N String objects created
        System.out.println("String concat:   " + (System.currentTimeMillis()-t1) + "ms");

        long t2 = System.currentTimeMillis();
        StringBuilder fast = new StringBuilder();
        for (int i = 0; i < 5000; i++) fast.append(i);  // fast! single object
        System.out.println("StringBuilder:   " + (System.currentTimeMillis()-t2) + "ms");

        // ============================================================
        // TEXT BLOCKS (Java 15+)
        // ============================================================
        System.out.println("\n=== TEXT BLOCKS ===");
        String json = """
                {
                  "name": "Alice",
                  "age": 28,
                  "skills": ["Java", "SQL", "Python"]
                }
                """;
        System.out.println(json);

        // Join
        System.out.println("\n=== JOIN ===");
        System.out.println(String.join(", ", "Alice", "Bob", "Charlie"));
        System.out.println(String.join(" | ", java.util.List.of("Java","Python","Go")));
    }
}
