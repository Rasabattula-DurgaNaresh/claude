/**
 * TOPIC 26: Structural Design Patterns
 * =======================================
 * 1. Adapter    : bridge incompatible interfaces
 * 2. Decorator  : add behavior dynamically (wrapper)
 * 3. Facade     : simplified interface to complex subsystem
 * 4. Proxy      : controlled access (lazy, security, logging)
 * 5. Composite  : tree structure, treat leaf/composite uniformly
 * 6. Bridge     : decouple abstraction from implementation
 */
import java.util.*;

public class StructuralPatterns {

    // ============================================================
    // 1. ADAPTER
    // ============================================================
    // Old XML API
    static class XmlDataParser {
        public String parseXml(String xml) {
            return "Parsed XML: " + xml.replaceAll("<[^>]+>", "").trim();
        }
    }

    // New JSON interface our system expects
    interface JsonProcessor {
        String processJson(String json);
    }

    // Adapter bridges XML -> JSON interface
    static class XmlToJsonAdapter implements JsonProcessor {
        private final XmlDataParser xmlParser;
        public XmlToJsonAdapter(XmlDataParser parser) { this.xmlParser = parser; }

        @Override public String processJson(String json) {
            // Convert JSON to XML (simplified), parse, return
            String xml = "<data>" + json.replace("{","").replace("}","")
                .replace("\"","").replace(":", "=") + "</data>";
            return xmlParser.parseXml(xml);
        }
    }

    // ============================================================
    // 2. DECORATOR
    // ============================================================
    interface TextProcessor {
        String process(String text);
    }

    static class PlainTextProcessor implements TextProcessor {
        public String process(String text) { return text; }
    }

    // Base decorator
    static abstract class TextDecorator implements TextProcessor {
        protected final TextProcessor wrapped;
        public TextDecorator(TextProcessor tp) { this.wrapped = tp; }
    }

    static class UpperCaseDecorator extends TextDecorator {
        public UpperCaseDecorator(TextProcessor tp) { super(tp); }
        public String process(String text) { return wrapped.process(text).toUpperCase(); }
    }

    static class TrimDecorator extends TextDecorator {
        public TrimDecorator(TextProcessor tp) { super(tp); }
        public String process(String text) { return wrapped.process(text).trim(); }
    }

    static class PunctuationDecorator extends TextDecorator {
        public PunctuationDecorator(TextProcessor tp) { super(tp); }
        public String process(String text) {
            return wrapped.process(text).replaceAll("[^a-zA-Z0-9 ]", "");
        }
    }

    static class PrefixDecorator extends TextDecorator {
        private String prefix;
        public PrefixDecorator(TextProcessor tp, String prefix) { super(tp); this.prefix=prefix; }
        public String process(String text) { return prefix + wrapped.process(text); }
    }

    // Coffee Decorator (classic example)
    interface Coffee { double cost(); String description(); }

    static class SimpleCoffee implements Coffee {
        public double cost()        { return 50; }
        public String description() { return "Simple Coffee"; }
    }
    static class MilkDecorator implements Coffee {
        private Coffee c;
        MilkDecorator(Coffee c) { this.c=c; }
        public double cost()        { return c.cost() + 15; }
        public String description() { return c.description() + " + Milk"; }
    }
    static class SugarDecorator implements Coffee {
        private Coffee c;
        SugarDecorator(Coffee c) { this.c=c; }
        public double cost()        { return c.cost() + 5; }
        public String description() { return c.description() + " + Sugar"; }
    }
    static class WhipDecorator implements Coffee {
        private Coffee c;
        WhipDecorator(Coffee c) { this.c=c; }
        public double cost()        { return c.cost() + 25; }
        public String description() { return c.description() + " + Whip"; }
    }

    // ============================================================
    // 3. FACADE
    // ============================================================
    // Complex subsystem
    static class InventorySystem {
        public boolean checkStock(String item, int qty) {
            System.out.println("  [Inventory] Checking stock: " + item + " x" + qty);
            return true; // simplified
        }
        public void reserveItems(String item, int qty) {
            System.out.println("  [Inventory] Reserved: " + item + " x" + qty);
        }
        public void releaseItems(String item, int qty) {
            System.out.println("  [Inventory] Released: " + item + " x" + qty);
        }
    }
    static class PaymentGateway {
        public boolean processPayment(String cardNum, double amount) {
            System.out.println("  [Payment] Processing Rs " + amount + " on card *" + cardNum.substring(cardNum.length()-4));
            return true;
        }
        public void refund(double amount) { System.out.println("  [Payment] Refunding Rs " + amount); }
    }
    static class ShippingService {
        public String scheduleShipping(String address) {
            String trackingId = "TRK" + System.currentTimeMillis() % 10000;
            System.out.println("  [Shipping] Scheduled to: " + address + " | ID: " + trackingId);
            return trackingId;
        }
    }
    static class NotificationService {
        public void sendEmail(String email, String msg) {
            System.out.println("  [Email] -> " + email + ": " + msg);
        }
        public void sendSMS(String phone, String msg) {
            System.out.println("  [SMS] -> " + phone + ": " + msg);
        }
    }

    // FACADE: simple unified interface
    static class EcommerceFacade {
        private final InventorySystem  inventory  = new InventorySystem();
        private final PaymentGateway   payment    = new PaymentGateway();
        private final ShippingService  shipping   = new ShippingService();
        private final NotificationService notify  = new NotificationService();

        public String placeOrder(String item, int qty, String card, double amount,
                                  String address, String email) {
            System.out.println(">>> Placing order...");
            if (!inventory.checkStock(item, qty)) throw new RuntimeException("Out of stock!");
            inventory.reserveItems(item, qty);
            if (!payment.processPayment(card, amount)) {
                inventory.releaseItems(item, qty);
                throw new RuntimeException("Payment failed!");
            }
            String trackingId = shipping.scheduleShipping(address);
            notify.sendEmail(email, "Order confirmed! Tracking: " + trackingId);
            System.out.println(">>> Order placed successfully! Tracking: " + trackingId);
            return trackingId;
        }
    }

    // ============================================================
    // 4. PROXY
    // ============================================================
    interface ImageLoader {
        void display();
        String getUrl();
    }

    static class RealImage implements ImageLoader {
        private String url;
        public RealImage(String url) {
            this.url = url;
            System.out.println("  [RealImage] Loading from: " + url); // expensive!
        }
        public void display()    { System.out.println("  [RealImage] Displaying: " + url); }
        public String getUrl()   { return url; }
    }

    // Lazy proxy (only loads when needed)
    static class LazyImageProxy implements ImageLoader {
        private String url;
        private RealImage image;

        public LazyImageProxy(String url) { this.url=url; }

        public void display() {
            if (image == null) {
                System.out.println("  [Proxy] First access - loading...");
                image = new RealImage(url); // lazy loading
            }
            image.display();
        }
        public String getUrl() { return url; }
    }

    // Logging proxy
    static class LoggingProxy implements ImageLoader {
        private final ImageLoader wrapped;
        private int accessCount = 0;

        public LoggingProxy(ImageLoader img) { this.wrapped=img; }
        public void display() {
            accessCount++;
            System.out.println("  [Proxy] Access #" + accessCount + " for " + wrapped.getUrl());
            wrapped.display();
        }
        public String getUrl() { return wrapped.getUrl(); }
    }

    // ============================================================
    // 5. COMPOSITE
    // ============================================================
    interface FileSystemItem {
        String getName();
        long getSize();
        void print(String indent);
    }

    static class SimpleFile implements FileSystemItem {
        private String name;
        private long size;
        SimpleFile(String name, long size) { this.name=name; this.size=size; }
        public String getName() { return name; }
        public long getSize()   { return size; }
        public void print(String indent) {
            System.out.printf("%s📄 %s (%d bytes)%n", indent, name, size);
        }
    }

    static class Directory implements FileSystemItem {
        private String name;
        private List<FileSystemItem> children = new ArrayList<>();

        Directory(String name) { this.name=name; }
        public void add(FileSystemItem item) { children.add(item); }

        public String getName() { return name; }
        public long getSize()   { return children.stream().mapToLong(FileSystemItem::getSize).sum(); }
        public void print(String indent) {
            System.out.printf("%s📁 %s/ (%d bytes total)%n", indent, name, getSize());
            children.forEach(c -> c.print(indent + "  "));
        }
    }

    public static void main(String[] args) {

        System.out.println("=== 1. ADAPTER ===");
        XmlDataParser xmlParser = new XmlDataParser();
        JsonProcessor processor = new XmlToJsonAdapter(xmlParser);
        String result = processor.processJson("{\"name\": \"Alice\", \"age\": \"25\"}");
        System.out.println("Processed: " + result);

        System.out.println("\n=== 2. DECORATOR ===");
        TextProcessor plain  = new PlainTextProcessor();
        TextProcessor upper  = new UpperCaseDecorator(new TrimDecorator(plain));
        TextProcessor cleaned = new PunctuationDecorator(new TrimDecorator(new UpperCaseDecorator(plain)));
        TextProcessor prefixed = new PrefixDecorator(new UpperCaseDecorator(plain), "[PREFIX] ");

        String text = "  hello, world! java is awesome.  ";
        System.out.println("Plain:    " + plain.process(text));
        System.out.println("Upper+Trim: " + upper.process(text));
        System.out.println("Cleaned:  " + cleaned.process(text));
        System.out.println("Prefixed: " + prefixed.process(text));

        // Coffee
        System.out.println("\nCoffee:");
        Coffee coffee = new WhipDecorator(new SugarDecorator(new MilkDecorator(new SimpleCoffee())));
        System.out.println(coffee.description() + " = Rs " + coffee.cost());

        System.out.println("\n=== 3. FACADE ===");
        EcommerceFacade shop = new EcommerceFacade();
        shop.placeOrder("Laptop", 1, "4111111111111234", 65000.0,
            "42 MG Road, Hyderabad", "alice@example.com");

        System.out.println("\n=== 4. PROXY ===");
        System.out.println("Lazy Proxy:");
        ImageLoader img = new LazyImageProxy("https://cdn.example.com/large-image.jpg");
        System.out.println("Created proxy (not loaded yet)");
        img.display(); // loads now
        img.display(); // uses cache

        System.out.println("\nLogging Proxy:");
        ImageLoader loggingImg = new LoggingProxy(new LazyImageProxy("https://example.com/img2.jpg"));
        loggingImg.display();
        loggingImg.display();
        loggingImg.display();

        System.out.println("\n=== 5. COMPOSITE (File System) ===");
        Directory root = new Directory("C:");
        Directory windows = new Directory("Windows");
        Directory system32 = new Directory("System32");
        system32.add(new SimpleFile("kernel32.dll", 1024000));
        system32.add(new SimpleFile("user32.dll",   512000));
        windows.add(system32);
        windows.add(new SimpleFile("notepad.exe", 204800));
        root.add(windows);

        Directory users = new Directory("Users");
        Directory alice = new Directory("Alice");
        alice.add(new SimpleFile("document.docx", 51200));
        alice.add(new SimpleFile("photo.jpg",     2048000));
        Directory docs = new Directory("Documents");
        docs.add(new SimpleFile("report.pdf",  102400));
        docs.add(new SimpleFile("budget.xlsx", 81920));
        alice.add(docs);
        users.add(alice);
        root.add(users);

        root.print("");
        System.out.printf("Total size: %,d bytes%n", root.getSize());
    }
}
