/**
 * TOPIC 37: Enums & Records - Complete Reference
 * ================================================
 * Enum:   special class, fixed set of named constants
 *         - has ordinal(), name(), values(), valueOf()
 *         - can have fields, constructors, methods, implement interfaces
 *         - EnumSet, EnumMap: specialized high-performance collections
 * Record: immutable data carrier (Java 16+)
 *         - auto generates: constructor, getters, equals, hashCode, toString
 *         - can have custom methods, compact constructors, implement interfaces
 */
import java.util.*;

public class EnumsAndRecords {

    // ============================================================
    // BASIC ENUM
    // ============================================================
    enum Day {
        MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY;

        public boolean isWeekend() { return this == SATURDAY || this == SUNDAY; }
        public boolean isWeekday() { return !isWeekend(); }
        public Day next() { return values()[(ordinal() + 1) % 7]; }
    }

    // ============================================================
    // ENUM WITH FIELDS AND CONSTRUCTOR
    // ============================================================
    enum Planet {
        MERCURY(3.303e+23, 2.4397e6),
        VENUS  (4.869e+24, 6.0518e6),
        EARTH  (5.976e+24, 6.37814e6),
        MARS   (6.421e+23, 3.3972e6);

        private final double mass;   // kg
        private final double radius; // meters
        static final double G = 6.67300E-11;

        Planet(double mass, double radius) { this.mass=mass; this.radius=radius; }

        double surfaceGravity()  { return G * mass / (radius * radius); }
        double surfaceWeight(double otherMass) { return otherMass * surfaceGravity(); }
        public double getMass()   { return mass; }
        public double getRadius() { return radius; }
    }

    // ============================================================
    // ENUM IMPLEMENTING INTERFACE (Strategy via Enum)
    // ============================================================
    interface MathOp { double apply(double a, double b); }

    enum Operation implements MathOp {
        ADD("+")  { public double apply(double a, double b) { return a + b; } },
        SUB("-")  { public double apply(double a, double b) { return a - b; } },
        MUL("*")  { public double apply(double a, double b) { return a * b; } },
        DIV("/")  { public double apply(double a, double b) {
            if (b == 0) throw new ArithmeticException("Division by zero");
            return a / b;
        }};

        private final String symbol;
        Operation(String s) { symbol = s; }
        public String getSymbol() { return symbol; }

        public static Operation fromSymbol(String sym) {
            for (Operation op : values()) if (op.symbol.equals(sym)) return op;
            throw new IllegalArgumentException("Unknown op: " + sym);
        }
    }

    // ============================================================
    // ENUM WITH ABSTRACT METHOD
    // ============================================================
    enum HttpStatus {
        OK(200, "OK") {
            @Override public boolean isSuccess() { return true; }
        },
        CREATED(201, "Created") {
            @Override public boolean isSuccess() { return true; }
        },
        BAD_REQUEST(400, "Bad Request") {
            @Override public boolean isSuccess() { return false; }
        },
        NOT_FOUND(404, "Not Found") {
            @Override public boolean isSuccess() { return false; }
        },
        INTERNAL_SERVER_ERROR(500, "Internal Server Error") {
            @Override public boolean isSuccess() { return false; }
        };

        private final int code;
        private final String message;
        HttpStatus(int code, String msg) { this.code=code; this.message=msg; }

        public abstract boolean isSuccess();
        public int getCode()       { return code; }
        public String getMessage() { return message; }

        public static HttpStatus fromCode(int code) {
            for (HttpStatus s : values()) if (s.code == code) return s;
            throw new IllegalArgumentException("Unknown code: " + code);
        }

        @Override public String toString() {
            return code + " " + message + " [" + (isSuccess() ? "SUCCESS" : "ERROR") + "]";
        }
    }

    // ============================================================
    // ENUM AS STATE MACHINE
    // ============================================================
    enum TrafficLight {
        RED {
            @Override public TrafficLight next() { return GREEN; }
            @Override public String action()     { return "STOP"; }
        },
        GREEN {
            @Override public TrafficLight next() { return YELLOW; }
            @Override public String action()     { return "GO"; }
        },
        YELLOW {
            @Override public TrafficLight next() { return RED; }
            @Override public String action()     { return "CAUTION"; }
        };

        public abstract TrafficLight next();
        public abstract String action();
    }

    // ============================================================
    // RECORDS (Java 16+)
    // ============================================================
    record Point(double x, double y) {
        // Compact constructor (validation)
        Point {
            if (Double.isNaN(x) || Double.isNaN(y))
                throw new IllegalArgumentException("Coordinates cannot be NaN");
        }
        // Custom methods
        public double distanceTo(Point other) {
            return Math.sqrt(Math.pow(x-other.x, 2) + Math.pow(y-other.y, 2));
        }
        public Point translate(double dx, double dy) { return new Point(x+dx, y+dy); }
        public double magnitude() { return Math.sqrt(x*x + y*y); }
        public static Point origin() { return new Point(0, 0); }
    }

    record Person(String name, int age, String email) {
        Person {
            Objects.requireNonNull(name, "name cannot be null");
            if (age < 0 || age > 150) throw new IllegalArgumentException("Invalid age");
            name = name.strip();
            email = email.toLowerCase();
        }
        public boolean isAdult() { return age >= 18; }
        public String initials() {
            return Arrays.stream(name.split(" "))
                .map(w -> String.valueOf(w.charAt(0)))
                .reduce("", String::concat);
        }
    }

    record Range(int start, int end) {
        Range { if (start > end) throw new IllegalArgumentException("start > end"); }
        public int size()            { return end - start + 1; }
        public boolean contains(int n){ return n >= start && n <= end; }
        public boolean overlaps(Range other) {
            return this.start <= other.end && other.start <= this.end;
        }
        public java.util.stream.IntStream stream() {
            return java.util.stream.IntStream.rangeClosed(start, end);
        }
    }

    // Generic record
    record Pair<A, B>(A first, B second) {
        public static <X,Y> Pair<X,Y> of(X x, Y y) { return new Pair<>(x, y); }
        public Pair<B, A> swap() { return new Pair<>(second, first); }
    }

    // Record implementing interface
    interface Printable { void print(); }
    record Employee(String id, String name, String dept, double salary) implements Printable {
        public void print() {
            System.out.printf("  [%s] %-12s | %-15s | Rs %.0f%n", id, name, dept, salary);
        }
        public double tax()   { return salary * 0.3; }
        public double netPay(){ return salary - tax(); }
    }

    public static void main(String[] args) {

        // ---- Day Enum ----
        System.out.println("=== DAY ENUM ===");
        for (Day d : Day.values()) {
            System.out.printf("  %-10s ordinal=%-2d weekend=%-5b next=%s%n",
                d.name(), d.ordinal(), d.isWeekend(), d.next().name());
        }
        Day today = Day.valueOf("WEDNESDAY");
        System.out.println("Parsed: " + today + " isWeekday=" + today.isWeekday());

        // ---- Planet Enum ----
        System.out.println("\n=== PLANET ENUM ===");
        double earthWeight = 75.0;
        double mass = earthWeight / Planet.EARTH.surfaceGravity();
        for (Planet p : Planet.values()) {
            System.out.printf("  %-10s weight=%.2f N%n", p, p.surfaceWeight(mass));
        }

        // ---- Operation Enum ----
        System.out.println("\n=== OPERATION ENUM ===");
        double a = 10, b = 3;
        for (Operation op : Operation.values()) {
            System.out.printf("  %.0f %s %.0f = %.4f%n", a, op.getSymbol(), b, op.apply(a, b));
        }
        System.out.println("fromSymbol('*') = " + Operation.fromSymbol("*"));

        // ---- HttpStatus Enum ----
        System.out.println("\n=== HTTP STATUS ENUM ===");
        int[] codes = {200, 201, 400, 404, 500};
        for (int code : codes) {
            HttpStatus s = HttpStatus.fromCode(code);
            System.out.println("  " + s);
        }

        // ---- Traffic Light State Machine ----
        System.out.println("\n=== TRAFFIC LIGHT STATE MACHINE ===");
        TrafficLight light = TrafficLight.RED;
        for (int i = 0; i < 6; i++) {
            System.out.printf("  %-8s -> %s%n", light, light.action());
            light = light.next();
        }

        // ---- EnumSet / EnumMap ----
        System.out.println("\n=== ENUMSET & ENUMMAP ===");
        EnumSet<Day> weekdays = EnumSet.range(Day.MONDAY, Day.FRIDAY);
        EnumSet<Day> weekend  = EnumSet.of(Day.SATURDAY, Day.SUNDAY);
        System.out.println("Weekdays: " + weekdays);
        System.out.println("Weekend:  " + weekend);

        EnumMap<Day, String> schedule = new EnumMap<>(Day.class);
        schedule.put(Day.MONDAY,    "Team Standup 9am");
        schedule.put(Day.WEDNESDAY, "Code Review 2pm");
        schedule.put(Day.FRIDAY,    "Sprint Review 4pm");
        schedule.forEach((d,s) -> System.out.println("  " + d + ": " + s));

        // ---- RECORDS ----
        System.out.println("\n=== RECORDS ===");
        Point p1 = new Point(3, 4);
        Point p2 = new Point(6, 8);
        System.out.println("p1=" + p1 + " p2=" + p2);
        System.out.println("distance: " + p1.distanceTo(p2));
        System.out.println("translate: " + p1.translate(1, 1));
        System.out.println("equals: " + p1.equals(new Point(3, 4))); // true!

        Person alice = new Person("  Alice Kumar  ", 28, "Alice@TEST.COM");
        System.out.println("Person: " + alice);
        System.out.println("initials: " + alice.initials());
        System.out.println("isAdult: " + alice.isAdult());

        Range r = new Range(1, 10);
        System.out.println("Range: " + r + " size=" + r.size() + " contains(5)=" + r.contains(5));
        System.out.println("overlaps(5,15): " + r.overlaps(new Range(5, 15)));
        System.out.println("sum: " + r.stream().sum());

        Pair<String,Integer> pair = Pair.of("Alice", 25);
        System.out.println("Pair: " + pair + " swapped: " + pair.swap());

        System.out.println("\n=== EMPLOYEE RECORDS ===");
        List<Employee> employees = List.of(
            new Employee("E001","Alice Kumar","Engineering", 95000),
            new Employee("E002","Bob Singh",  "Marketing",  75000),
            new Employee("E003","Charlie Das","Engineering",105000)
        );
        employees.forEach(Employee::print);
        double avgSalary = employees.stream().mapToDouble(Employee::salary).average().orElse(0);
        System.out.printf("Average salary: Rs %.0f%n", avgSalary);

        // Records are immutable
        System.out.println("\nRecords are immutable - no setters!");
        System.out.println("To 'modify', create new: " + new Point(p1.x() + 10, p1.y()));
    }
}
