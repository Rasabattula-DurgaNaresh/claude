/**
 * TOPIC 22: File I/O - Complete Reference
 * =========================================
 * java.io:  File, FileReader/Writer, BufferedReader/Writer, Stream-based
 * java.nio.file: Path, Files, Paths (modern, Java 7+)
 * Files.readAllLines, writeString, copy, move, delete
 * BufferedReader: efficient line-by-line reading
 * FileInputStream/OutputStream: binary data
 * try-with-resources: auto-close streams
 * Walking directory trees, watching file changes
 */
import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class FileIOComplete {

    public static void main(String[] args) throws Exception {
        String tmpDir = System.getProperty("java.io.tmpdir") + File.separator + "java_io_demo";
        Files.createDirectories(Paths.get(tmpDir));

        // ============================================================
        // 1. java.io.File (legacy)
        // ============================================================
        System.out.println("=== java.io.File ===");
        File dir = new File(tmpDir);
        File f1  = new File(tmpDir, "sample.txt");
        System.out.println("exists:       " + f1.exists());
        System.out.println("isDirectory:  " + dir.isDirectory());
        System.out.println("absolutePath: " + f1.getAbsolutePath());
        System.out.println("parent:       " + f1.getParent());
        System.out.println("separator:    " + File.separator);

        // ============================================================
        // 2. WRITE - BufferedWriter / PrintWriter
        // ============================================================
        System.out.println("\n=== WRITING FILES ===");

        // BufferedWriter (fastest for text)
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(f1))) {
            bw.write("Line 1: Hello, File I/O!");
            bw.newLine();
            bw.write("Line 2: Java NIO rocks.");
            bw.newLine();
            bw.write("Line 3: BufferedWriter is efficient.");
            bw.newLine();
        }
        System.out.println("Written with BufferedWriter: " + f1.getName());

        // PrintWriter (printf support)
        File f2 = new File(tmpDir, "data.csv");
        try (PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(f2)))) {
            pw.println("Name,Age,City,Salary");
            pw.printf("Alice,28,Hyderabad,95000%n");
            pw.printf("Bob,35,Mumbai,85000%n");
            pw.printf("Charlie,26,Delhi,75000%n");
            pw.printf("Diana,30,Bangalore,110000%n");
        }
        System.out.println("Written with PrintWriter: " + f2.getName());

        // Files.writeString (Java 11+, simplest)
        Path f3 = Paths.get(tmpDir, "modern.txt");
        Files.writeString(f3, "Modern NIO write!\nLine 2\nLine 3\n");
        System.out.println("Written with Files.writeString: " + f3.getFileName());

        // Files.write with List
        Path f4 = Paths.get(tmpDir, "lines.txt");
        Files.write(f4, Arrays.asList("Alpha", "Beta", "Gamma", "Delta", "Epsilon"));
        System.out.println("Written with Files.write(List): " + f4.getFileName());

        // Append to file
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(f1, true))) {
            bw.write("Line 4: Appended line.");
            bw.newLine();
        }
        System.out.println("Appended to: " + f1.getName());

        // ============================================================
        // 3. READ - BufferedReader / Files
        // ============================================================
        System.out.println("\n=== READING FILES ===");

        // BufferedReader
        System.out.println("BufferedReader line-by-line:");
        try (BufferedReader br = new BufferedReader(new FileReader(f1))) {
            String line;
            int lineNum = 1;
            while ((line = br.readLine()) != null) {
                System.out.printf("  %2d: %s%n", lineNum++, line);
            }
        }

        // Files.readAllLines
        List<String> allLines = Files.readAllLines(f2, StandardCharsets.UTF_8);
        System.out.println("\nFiles.readAllLines (CSV):");
        allLines.forEach(l -> System.out.println("  " + l));

        // Files.readString (Java 11+)
        String content = Files.readString(f3, StandardCharsets.UTF_8);
        System.out.println("\nFiles.readString:\n  " + content.replace("\n", "\n  ").trim());

        // Stream-based reading (lazy, good for large files)
        System.out.println("\nStream-based reading (Files.lines):");
        try (var lines = Files.lines(f4)) {
            lines.filter(l -> l.length() > 4)
                 .map(String::toLowerCase)
                 .forEach(l -> System.out.println("  " + l));
        }

        // ============================================================
        // 4. CSV PROCESSING
        // ============================================================
        System.out.println("\n=== CSV PROCESSING ===");
        record Employee(String name, int age, String city, double salary) {}

        List<Employee> employees = Files.readAllLines(f2).stream()
            .skip(1)  // skip header
            .map(line -> {
                String[] p = line.split(",");
                return new Employee(p[0], Integer.parseInt(p[1]), p[2], Double.parseDouble(p[3]));
            })
            .sorted(Comparator.comparingDouble(Employee::salary).reversed())
            .toList();

        System.out.println("Employees by salary desc:");
        employees.forEach(e -> System.out.printf("  %-10s | %s | Rs %.0f%n", e.name(), e.city(), e.salary()));
        double avgSalary = employees.stream().mapToDouble(Employee::salary).average().orElse(0);
        System.out.printf("Average salary: Rs %.0f%n", avgSalary);

        // ============================================================
        // 5. BINARY I/O
        // ============================================================
        System.out.println("\n=== BINARY I/O ===");
        File binFile = new File(tmpDir, "data.bin");

        // Write binary (DataOutputStream)
        try (DataOutputStream dos = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(binFile)))) {
            dos.writeInt(42);
            dos.writeDouble(3.14159);
            dos.writeBoolean(true);
            dos.writeUTF("Hello Binary!");
            dos.writeLong(9876543210L);
        }
        System.out.println("Binary written: " + binFile.length() + " bytes");

        // Read binary (DataInputStream)
        try (DataInputStream dis = new DataInputStream(new BufferedInputStream(new FileInputStream(binFile)))) {
            System.out.println("int:     " + dis.readInt());
            System.out.println("double:  " + dis.readDouble());
            System.out.println("boolean: " + dis.readBoolean());
            System.out.println("UTF:     " + dis.readUTF());
            System.out.println("long:    " + dis.readLong());
        }

        // ============================================================
        // 6. PATH & FILES OPERATIONS (NIO)
        // ============================================================
        System.out.println("\n=== NIO PATH OPERATIONS ===");
        Path base = Paths.get(tmpDir);
        Path sub  = base.resolve("subdir");
        Files.createDirectories(sub);

        Path src  = f3;
        Path dest = sub.resolve("copy.txt");
        Files.copy(src, dest, StandardCopyOption.REPLACE_EXISTING);
        System.out.println("Copied: " + src.getFileName() + " -> " + dest);

        // Move
        Path moved = sub.resolve("moved.txt");
        Files.copy(dest, moved, StandardCopyOption.REPLACE_EXISTING);
        Files.move(dest, sub.resolve("renamed.txt"), StandardCopyOption.REPLACE_EXISTING);
        System.out.println("Moved: " + dest.getFileName() + " -> renamed.txt");

        // File info
        Path infoFile = f1.toPath();
        System.out.println("\nFile info for " + infoFile.getFileName() + ":");
        System.out.println("  size:         " + Files.size(infoFile) + " bytes");
        System.out.println("  exists:       " + Files.exists(infoFile));
        System.out.println("  isReadable:   " + Files.isReadable(infoFile));
        System.out.println("  isWritable:   " + Files.isWritable(infoFile));
        System.out.println("  lastModified: " + Files.getLastModifiedTime(infoFile));

        // ============================================================
        // 7. DIRECTORY WALKING
        // ============================================================
        System.out.println("\n=== DIRECTORY WALKING ===");
        System.out.println("All files in " + tmpDir + ":");
        try (var walk = Files.walk(base)) {
            walk.filter(Files::isRegularFile)
                .forEach(p -> System.out.println("  " + base.relativize(p)));
        }

        // Find files by extension
        System.out.println("\nOnly .txt files:");
        try (var find = Files.find(base, 3, (p, attr) ->
                p.toString().endsWith(".txt") && attr.isRegularFile())) {
            find.forEach(p -> System.out.println("  " + base.relativize(p)));
        }

        // List (1 level)
        System.out.println("\nDirect children:");
        try (var list = Files.list(base)) {
            list.forEach(p -> System.out.println("  " + p.getFileName() + (Files.isDirectory(p) ? "/" : "")));
        }

        // ============================================================
        // 8. CLEANUP
        // ============================================================
        System.out.println("\n=== CLEANUP ===");
        try (var walk = Files.walk(base)) {
            walk.sorted(Comparator.reverseOrder())
                .forEach(p -> { try { Files.delete(p); } catch (IOException e) {} });
        }
        System.out.println("Cleaned up " + tmpDir);

        System.out.println("\nFile I/O examples complete!");
    }
}
