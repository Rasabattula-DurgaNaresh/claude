/**
 * TOPIC 29: Java 9 - 21 Modern Features
 * ========================================
 * Java 9:  Module system, Collection factory methods, Stream improvements
 * Java 10: Local variable type inference (var)
 * Java 11: String methods, Files improvements, HttpClient
 * Java 14: Records (preview), Switch expressions
 * Java 15: Text blocks, Sealed classes (preview)
 * Java 16: Records (stable), instanceof pattern matching
 * Java 17: Sealed classes (stable), JEP 406
 * Java 21: Pattern matching switch, Virtual threads, Sequenced collections
 */
import java.util.*;
import java.util.stream.*;

public class ModernJavaFeatures {

    // ============================================================
    // RECORDS (Java 16)
    // ============================================================
    record Point(double x, double y) {
        // Compact constructor (validation)
        Point {
            if (Double.isNaN(x) || Double.isNaN(y))
                throw new IllegalArgumentException("Coordinates cannot be NaN");
        }

        // Custom methods
        public double distanceTo(Point other) {
            return Math.sqrt(Math.pow(x - other.x, 2) + Math.pow(y - other.y, 2));
        }
        public Point translate(double dx, double dy) { return new Point(x + dx, y + dy); }
        public double magnitude() { return Math.sqrt(x*x + y*y); }
    }

    record Person(String name, int age, String email) {
        // Canonical constructor validation
        Person {
            Objects.requireNonNull(name, "name cannot be null");
            if (age < 0 || age > 150) throw new IllegalArgumentException("Invalid age: " + age);
            name = name.trim();
        }
        // Custom accessor (override generated)
        public String name() { return name.toUpperCase(); }
        // Additional method
        public boolean isAdult() { return age >= 18; }

        @Override public String toString() {
            return "Person{" + name + ", age=" + age + ", email=" + email + "}";
        }
    }

    record Range(int start, int end) implements Iterable<Integer> {
        Range { if (start > end) throw new IllegalArgumentException("start > end"); }
        public int size() { return end - start + 1; }
        public boolean contains(int n) { return n >= start && n <= end; }
        public Iterator<Integer> iterator() {
            return new Iterator<>() {
                int cur = start;
                public boolean hasNext() { return cur <= end; }
                public Integer next()    { return cur++; }
            };
        }
    }

    // ============================================================
    // SEALED CLASSES (Java 17)
    // ============================================================
    sealed interface Shape permits Circle, Rectangle, Triangle {
        double area();
        default String describe() {
            return getClass().getSimpleName() + " (area=" + String.format("%.2f", area()) + ")";
        }
    }

    record Circle(double radius) implements Shape {
        public double area() { return Math.PI * radius * radius; }
    }

    record Rectangle(double width, double height) implements Shape {
        public double area() { return width * height; }
    }

    record Triangle(double base, double height) implements Shape {
        public double area() { return 0.5 * base * height; }
    }

    // Sealed class hierarchy
    sealed abstract class Result<T> permits Result.Success, Result.Failure {
        static final class Success<T> extends Result<T> {
            private final T value;
            Success(T v) { value = v; }
            public T getValue() { return value; }
            @Override public String toString() { return "Success(" + value + ")"; }
        }
        static final class Failure<T> extends Result<T> {
            private final String error;
            Failure(String e) { error = e; }
            public String getError() { return error; }
            @Override public String toString() { return "Failure(" + error + ")"; }
        }

        public static <T> Result<T> success(T v) { return new Success<>(v); }
        public static <T> Result<T> failure(String e) { return new Failure<>(e); }
        public boolean isSuccess()  { return this instanceof Success; }
        public boolean isFailure()  { return this instanceof Failure; }
    }

    static Result<Integer> divide(int a, int b) {
        if (b == 0) return Result.failure("Division by zero");
        return Result.success(a / b);
    }

    public static void main(String[] args) {

        // ============================================================
        // RECORDS
        // ============================================================
        System.out.println("=== RECORDS (Java 16) ===");
        Point p1 = new Point(3, 4);
        Point p2 = new Point(6, 8);
        System.out.println("p1:          " + p1);
        System.out.println("p2:          " + p2);
        System.out.println("distance:    " + p1.distanceTo(p2));
        System.out.println("magnitude:   " + p1.magnitude());
        System.out.println("translate:   " + p1.translate(1, 1));
        System.out.println("equals:      " + p1.equals(new Point(3, 4)));  // structural equality
        System.out.println("hashCode:    " + (p1.hashCode() == new Point(3,4).hashCode()));

        Person alice = new Person("  alice  ", 28, "alice@test.com");
        System.out.println("Person: " + alice);
        System.out.println("name():  " + alice.name());     // accessor (overridden)
        System.out.println("isAdult: " + alice.isAdult());

        Range range = new Range(1, 5);
        System.out.print("Range: ");
        for (int n : range) System.out.print(n + " ");
        System.out.println("| size=" + range.size() + " contains(3)=" + range.contains(3));

        // Records in collections
        List<Point> points = List.of(new Point(1,2), new Point(3,4), new Point(5,6));
        points.stream().map(p -> p.magnitude()).forEach(m -> System.out.printf("  magnitude=%.2f%n", m));

        // ============================================================
        // VAR (Java 10)
        // ============================================================
        System.out.println("\n=== VAR (Java 10) ===");
        var number  = 42;                     // int
        var text    = "Hello";                // String
        var list    = new ArrayList<String>();// ArrayList<String>
        var map     = new HashMap<String,Integer>();
        list.add("Java"); list.add("Kotlin"); list.add("Scala");
        map.put("A",1); map.put("B",2);

        System.out.println("var int:  " + number);
        System.out.println("var str:  " + text);
        System.out.println("var list: " + list);
        System.out.println("var map:  " + map);

        for (var item : list) System.out.println("  var in for-each: " + item);

        // ============================================================
        // SWITCH EXPRESSIONS (Java 14/17)
        // ============================================================
        System.out.println("\n=== SWITCH EXPRESSIONS (Java 14+) ===");
        int[] testNums = {1,2,3,4,5,6,7};
        for (int n : testNums) {
            String dayType = switch (n) {
                case 1, 7 -> "Weekend";
                case 2, 3, 4, 5, 6 -> "Weekday";
                default -> "Invalid";
            };
            System.out.println("  " + n + " -> " + dayType);
        }

        // Switch with yield
        String score = "B";
        int grade = switch (score) {
            case "A+" -> 100;
            case "A"  -> 90;
            case "B"  -> { System.out.println("  (computing B grade)"); yield 80; }
            case "C"  -> 70;
            default   -> 0;
        };
        System.out.println("Grade for B: " + grade);

        // ============================================================
        // PATTERN MATCHING instanceof (Java 16)
        // ============================================================
        System.out.println("\n=== PATTERN MATCHING instanceof ===");
        Object[] objects = {42, "hello", 3.14, List.of(1,2,3), new Point(1,2), null};
        for (Object obj : objects) {
            if (obj instanceof Integer i) {
                System.out.println("  Integer: " + i + " * 2 = " + (i*2));
            } else if (obj instanceof String s && s.length() > 3) {
                System.out.println("  String (len>" + 3 + "): " + s.toUpperCase());
            } else if (obj instanceof Double d) {
                System.out.printf("  Double: %.4f%n", d);
            } else if (obj instanceof List<?> l) {
                System.out.println("  List size=" + l.size() + ": " + l);
            } else if (obj instanceof Point p) {
                System.out.println("  Point: " + p + " mag=" + p.magnitude());
            } else {
                System.out.println("  Other/null: " + obj);
            }
        }

        // ============================================================
        // SEALED CLASSES (Java 17)
        // ============================================================
        System.out.println("\n=== SEALED CLASSES ===");
        List<Shape> shapes = List.of(new Circle(5), new Rectangle(4,6), new Triangle(3,8));
        for (Shape s : shapes) {
            // Pattern matching switch (Java 21)
            String desc = switch (s) {
                case Circle c    -> "Circle with r=" + c.radius();
                case Rectangle r -> "Rectangle " + r.width() + "x" + r.height();
                case Triangle t  -> "Triangle base=" + t.base() + " h=" + t.height();
            };
            System.out.println("  " + desc + " -> " + s.describe());
        }

        // ============================================================
        // TEXT BLOCKS (Java 15)
        // ============================================================
        System.out.println("\n=== TEXT BLOCKS ===");
        String json = """
                {
                  "name": "Alice",
                  "age": 28,
                  "skills": ["Java", "Python", "SQL"],
                  "address": {
                    "city": "Hyderabad",
                    "country": "India"
                  }
                }
                """;
        System.out.println(json);

        String html = """
                <html>
                  <body>
                    <h1>Hello, %s!</h1>
                  </body>
                </html>
                """.formatted("World");
        System.out.println(html);

        // ============================================================
        // JAVA 11 STRING METHODS
        // ============================================================
        System.out.println("=== JAVA 11 STRING METHODS ===");
        System.out.println("isBlank: " + "   ".isBlank());
        System.out.println("strip:   '" + "  hello  ".strip() + "'");
        System.out.println("repeat:  " + "ab".repeat(4));
        "line1\nline2\nline3".lines().forEach(l -> System.out.println("  line: " + l));

        // ============================================================
        // JAVA 9: COLLECTION FACTORIES
        // ============================================================
        System.out.println("\n=== COLLECTION FACTORIES (Java 9+) ===");
        List<String> immList = List.of("A","B","C","D");
        Set<Integer>  immSet  = Set.of(1,2,3,4,5);
        Map<String,Integer> immMap = Map.of("one",1,"two",2,"three",3);
        Map<String,Integer> entries = Map.ofEntries(
            Map.entry("a",1), Map.entry("b",2), Map.entry("c",3)
        );
        System.out.println("List.of:       " + immList);
        System.out.println("Set.of:        " + immSet);
        System.out.println("Map.of:        " + immMap);
        System.out.println("Map.ofEntries: " + entries);

        // ============================================================
        // JAVA 9: STREAM IMPROVEMENTS
        // ============================================================
        System.out.println("\n=== STREAM IMPROVEMENTS (Java 9+) ===");
        // takeWhile, dropWhile
        List<Integer> nums = List.of(1,2,3,4,5,6,7,8,9,10);
        System.out.println("takeWhile(<5): " + nums.stream().takeWhile(n -> n < 5).toList());
        System.out.println("dropWhile(<5): " + nums.stream().dropWhile(n -> n < 5).toList());

        // iterate with predicate (Java 9)
        List<Integer> evens = Stream.iterate(0, n -> n < 20, n -> n + 2).toList();
        System.out.println("iterate(evens<20): " + evens);

        // Stream.ofNullable (Java 9)
        long count1 = Stream.ofNullable("hello").count();  // 1
        long count2 = Stream.ofNullable(null).count();     // 0
        System.out.println("ofNullable(hello): " + count1 + " | ofNullable(null): " + count2);

        // ============================================================
        // SEALED RESULT TYPE PATTERN
        // ============================================================
        System.out.println("\n=== SEALED RESULT TYPE ===");
        int[][] testCases = {{10,2},{5,0},{100,4},{7,3}};
        for (int[] tc : testCases) {
            Result<Integer> r = divide(tc[0], tc[1]);
            String msg = switch (r) {
                case Result.Success<Integer> s -> tc[0] + "/" + tc[1] + " = " + s.getValue();
                case Result.Failure<Integer> f -> "Error: " + f.getError();
            };
            System.out.println("  " + msg);
        }

        // ============================================================
        // JAVA 21: VIRTUAL THREADS
        // ============================================================
        System.out.println("\n=== VIRTUAL THREADS (Java 21) ===");
        System.out.println("Virtual threads are lightweight (Project Loom)");
        System.out.println("Create with: Thread.ofVirtual().start(runnable)");
        System.out.println("Or: Executors.newVirtualThreadPerTaskExecutor()");

        try {
            var executor = java.util.concurrent.Executors.newVirtualThreadPerTaskExecutor();
            var futures = new ArrayList<java.util.concurrent.Future<String>>();
            for (int i = 1; i <= 5; i++) {
                final int taskId = i;
                futures.add(executor.submit(() -> {
                    Thread.sleep(10);
                    return "VT-" + taskId + " on " + Thread.currentThread();
                }));
            }
            for (var f : futures) System.out.println("  " + f.get());
            executor.shutdown();
        } catch (Exception e) { System.out.println("  " + e.getMessage()); }

        System.out.println("\n=== JAVA 21: SEQUENCED COLLECTIONS ===");
        System.out.println("SequencedCollection: getFirst(), getLast(), reversed()");
        var seqList = new ArrayList<>(List.of("A","B","C","D","E"));
        System.out.println("getFirst: " + seqList.getFirst());
        System.out.println("getLast:  " + seqList.getLast());
        System.out.println("reversed: " + seqList.reversed());
        seqList.addFirst("Z");
        System.out.println("addFirst(Z): " + seqList);
        seqList.removeLast();
        System.out.println("removeLast:  " + seqList);

        System.out.println("\nModern Java features complete!");
    }
}
