/**
 * TOPIC 04: Arrays - Complete Guide
 * ==================================
 * Array = fixed-size homogeneous data structure (index from 0)
 * Stored on heap, accessed by reference
 * Arrays class: sort, binarySearch, copyOf, fill, equals, toString
 * Multi-dimensional: 2D, 3D, jagged arrays
 * Array as method parameter (pass by reference!)
 */
import java.util.Arrays;

public class ArraysComplete {
    public static void main(String[] args) {

        // ============================================================
        // DECLARATION & INITIALIZATION
        // ============================================================
        System.out.println("=== DECLARATION & INIT ===");
        int[] a1;                            // declaration only (null)
        int[] a2 = new int[5];               // default values: all 0
        int[] a3 = {10, 20, 30, 40, 50};    // inline init
        int[] a4 = new int[]{1, 2, 3, 4};   // explicit new
        String[] names = new String[3];      // default: all null

        System.out.println("Default int[5]:    " + Arrays.toString(a2));  // [0,0,0,0,0]
        System.out.println("Inline init:       " + Arrays.toString(a3));
        System.out.println("Default String[3]: " + Arrays.toString(names)); // [null,null,null]

        // Array properties
        System.out.println("Length: " + a3.length);       // 5 (field, not method!)
        System.out.println("Last element: " + a3[a3.length - 1]);  // 50

        // Modify elements
        a2[0] = 100; a2[2] = 200; a2[4] = 300;
        System.out.println("Modified a2: " + Arrays.toString(a2));

        // ============================================================
        // TRAVERSAL METHODS
        // ============================================================
        System.out.println("\n=== TRAVERSAL ===");
        int[] nums = {5, 2, 8, 1, 9, 3, 7, 4, 6};

        // Method 1: traditional for
        System.out.print("For loop: ");
        for (int i = 0; i < nums.length; i++) System.out.print(nums[i] + " ");
        System.out.println();

        // Method 2: enhanced for-each
        System.out.print("For-each: ");
        for (int num : nums) System.out.print(num + " ");
        System.out.println();

        // Method 3: Arrays.stream
        System.out.print("Stream:   ");
        Arrays.stream(nums).forEach(n -> System.out.print(n + " "));
        System.out.println();

        // ============================================================
        // SORTING
        // ============================================================
        System.out.println("\n=== SORTING ===");
        int[] toSort = nums.clone();
        System.out.println("Before: " + Arrays.toString(toSort));
        Arrays.sort(toSort);
        System.out.println("After:  " + Arrays.toString(toSort));

        // Sort partial range
        int[] partial = {5, 2, 8, 1, 9, 3, 7};
        Arrays.sort(partial, 2, 5);  // sort indices [2,5) only
        System.out.println("Partial sort[2,5): " + Arrays.toString(partial));

        // Sort descending (need Integer[])
        Integer[] desc = {5, 2, 8, 1, 9, 3};
        Arrays.sort(desc, (x, y) -> y - x);
        System.out.println("Desc:   " + Arrays.toString(desc));

        // ============================================================
        // SEARCHING
        // ============================================================
        System.out.println("\n=== SEARCHING ===");
        int[] sorted = {1, 3, 5, 7, 9, 11, 13, 15};
        int idx = Arrays.binarySearch(sorted, 7);    // must be sorted!
        System.out.println("binarySearch(7): index=" + idx);
        int notFound = Arrays.binarySearch(sorted, 6);  // negative = insertion point
        System.out.println("binarySearch(6): " + notFound + " (not found, insert at " + (-notFound-1) + ")");

        // Linear search (manual, for unsorted)
        int target = 9;
        int linearIdx = -1;
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] == target) { linearIdx = i; break; }
        }
        System.out.println("Linear search(" + target + "): index=" + linearIdx);

        // ============================================================
        // COPY OPERATIONS
        // ============================================================
        System.out.println("\n=== COPY OPERATIONS ===");
        int[] original = {1, 2, 3, 4, 5};

        int[] fullCopy   = Arrays.copyOf(original, original.length);
        int[] expanded   = Arrays.copyOf(original, 8);          // extra slots = 0
        int[] trimmed    = Arrays.copyOf(original, 3);
        int[] range      = Arrays.copyOfRange(original, 1, 4);  // [1,4) -> {2,3,4}

        int[] sysCopy = new int[original.length];
        System.arraycopy(original, 0, sysCopy, 0, original.length); // fastest

        System.out.println("Original:  " + Arrays.toString(original));
        System.out.println("Full copy: " + Arrays.toString(fullCopy));
        System.out.println("Expanded:  " + Arrays.toString(expanded));
        System.out.println("Trimmed:   " + Arrays.toString(trimmed));
        System.out.println("Range[1,4):" + Arrays.toString(range));
        System.out.println("System.arraycopy: " + Arrays.toString(sysCopy));

        // IMPORTANT: shallow copy vs deep copy
        fullCopy[0] = 999;  // does not affect original!
        System.out.println("original[0] after modifying copy: " + original[0]);  // still 1

        // ============================================================
        // FILL & COMPARE
        // ============================================================
        System.out.println("\n=== FILL & COMPARE ===");
        int[] filled = new int[6];
        Arrays.fill(filled, 7);
        System.out.println("Fill(7):   " + Arrays.toString(filled));
        Arrays.fill(filled, 2, 5, -1);  // fill range [2,5)
        System.out.println("Fill[2,5): " + Arrays.toString(filled));

        int[] arr1 = {1, 2, 3};
        int[] arr2 = {1, 2, 3};
        int[] arr3 = {1, 2, 4};
        System.out.println("arr1.equals(arr2)? " + (arr1 == arr2));     // false (reference!)
        System.out.println("Arrays.equals:     " + Arrays.equals(arr1, arr2));   // true
        System.out.println("Arrays.equals:     " + Arrays.equals(arr1, arr3));   // false
        System.out.println("compare(arr1,arr3):" + Arrays.compare(arr1, arr3));  // negative (<)

        // ============================================================
        // 2D ARRAYS (Matrix)
        // ============================================================
        System.out.println("\n=== 2D ARRAYS (MATRIX) ===");
        int[][] matrix = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
        };
        System.out.println("Rows: " + matrix.length + ", Cols: " + matrix[0].length);

        // Print matrix
        for (int[] row : matrix) System.out.println(Arrays.toString(row));

        // Sum all elements
        int matSum = 0;
        for (int[] row : matrix) for (int val : row) matSum += val;
        System.out.println("Matrix sum: " + matSum);

        // Matrix transpose
        int rows = 3, cols = 3;
        int[][] transposed = new int[cols][rows];
        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++)
                transposed[j][i] = matrix[i][j];
        System.out.println("Transposed:");
        for (int[] row : transposed) System.out.println(Arrays.toString(row));

        // Matrix multiplication
        System.out.println("Matrix multiply (2x2):");
        int[][] A = {{1,2},{3,4}};
        int[][] B = {{5,6},{7,8}};
        int[][] C = new int[2][2];
        for (int i = 0; i < 2; i++)
            for (int j = 0; j < 2; j++)
                for (int k = 0; k < 2; k++)
                    C[i][j] += A[i][k] * B[k][j];
        for (int[] row : C) System.out.println(Arrays.toString(row));

        // ============================================================
        // JAGGED ARRAYS
        // ============================================================
        System.out.println("\n=== JAGGED ARRAYS ===");
        int[][] jagged = new int[4][];
        for (int i = 0; i < jagged.length; i++) {
            jagged[i] = new int[i + 1];
            for (int j = 0; j <= i; j++) jagged[i][j] = i + 1;
        }
        for (int[] row : jagged) System.out.println(Arrays.toString(row));

        // ============================================================
        // ARRAY AS METHOD PARAMETER
        // ============================================================
        System.out.println("\n=== ARRAYS & METHODS ===");
        int[] sample = {3, 1, 4, 1, 5, 9, 2, 6};
        System.out.println("Before reverse: " + Arrays.toString(sample));
        reverseArray(sample);         // modifies original (pass by reference!)
        System.out.println("After reverse:  " + Arrays.toString(sample));

        int[] stats = {10, 25, 3, 47, 8, 32};
        System.out.printf("Min=%d Max=%d Sum=%d Avg=%.2f%n",
            minOf(stats), maxOf(stats), sumOf(stats), avgOf(stats));
    }

    static void reverseArray(int[] arr) {
        for (int l = 0, r = arr.length-1; l < r; l++, r--) {
            int t = arr[l]; arr[l] = arr[r]; arr[r] = t;
        }
    }
    static int minOf(int[] a) { return Arrays.stream(a).min().getAsInt(); }
    static int maxOf(int[] a) { return Arrays.stream(a).max().getAsInt(); }
    static int sumOf(int[] a) { return Arrays.stream(a).sum(); }
    static double avgOf(int[] a) { return Arrays.stream(a).average().getAsDouble(); }
}
