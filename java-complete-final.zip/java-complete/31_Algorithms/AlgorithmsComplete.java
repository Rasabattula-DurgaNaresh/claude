/**
 * TOPIC 31: Algorithms - Sorting, Searching, Dynamic Programming
 * ================================================================
 * Sorting:   Bubble, Selection, Insertion, Merge, Quick, Counting, Radix
 * Searching: Linear, Binary, Jump, Interpolation
 * Dynamic Programming: Fibonacci, Knapsack, LCS, Coin Change, LIS
 * Recursion: Factorial, Tower of Hanoi, Permutations
 * Math:      GCD, LCM, Primes, Power
 */
import java.util.*;

public class AlgorithmsComplete {

    // ============================================================
    // SORTING ALGORITHMS
    // ============================================================
    static void bubbleSort(int[] a) {
        for(int i=0;i<a.length-1;i++)
            for(int j=0;j<a.length-i-1;j++)
                if(a[j]>a[j+1]){int t=a[j];a[j]=a[j+1];a[j+1]=t;}
    }

    static void selectionSort(int[] a) {
        for(int i=0;i<a.length-1;i++){
            int min=i;
            for(int j=i+1;j<a.length;j++) if(a[j]<a[min]) min=j;
            int t=a[i];a[i]=a[min];a[min]=t;
        }
    }

    static void insertionSort(int[] a) {
        for(int i=1;i<a.length;i++){
            int key=a[i],j=i-1;
            while(j>=0&&a[j]>key){a[j+1]=a[j];j--;}
            a[j+1]=key;
        }
    }

    static void mergeSort(int[] a, int l, int r) {
        if(l>=r) return;
        int m=(l+r)/2;
        mergeSort(a,l,m); mergeSort(a,m+1,r);
        merge(a,l,m,r);
    }
    static void merge(int[] a, int l, int m, int r) {
        int n1=m-l+1, n2=r-m;
        int[] L=new int[n1], R=new int[n2];
        System.arraycopy(a,l,L,0,n1); System.arraycopy(a,m+1,R,0,n2);
        int i=0,j=0,k=l;
        while(i<n1&&j<n2) a[k++]=L[i]<=R[j]?L[i++]:R[j++];
        while(i<n1) a[k++]=L[i++];
        while(j<n2) a[k++]=R[j++];
    }

    static void quickSort(int[] a, int lo, int hi) {
        if(lo>=hi) return;
        int p=partition(a,lo,hi);
        quickSort(a,lo,p-1); quickSort(a,p+1,hi);
    }
    static int partition(int[] a, int lo, int hi) {
        int pivot=a[hi],i=lo-1;
        for(int j=lo;j<hi;j++) if(a[j]<=pivot){i++;int t=a[i];a[i]=a[j];a[j]=t;}
        int t=a[i+1];a[i+1]=a[hi];a[hi]=t;
        return i+1;
    }

    static void countingSort(int[] a, int max) {
        int[] count=new int[max+1];
        for(int v:a) count[v]++;
        int idx=0;
        for(int i=0;i<=max;i++) while(count[i]-->0) a[idx++]=i;
    }

    static int[] heapSort(int[] input) {
        int[] a = input.clone();
        int n=a.length;
        for(int i=n/2-1;i>=0;i--) heapify(a,n,i);
        for(int i=n-1;i>0;i--){int t=a[0];a[0]=a[i];a[i]=t;heapify(a,i,0);}
        return a;
    }
    static void heapify(int[] a, int n, int i) {
        int largest=i, l=2*i+1, r=2*i+2;
        if(l<n&&a[l]>a[largest]) largest=l;
        if(r<n&&a[r]>a[largest]) largest=r;
        if(largest!=i){int t=a[i];a[i]=a[largest];a[largest]=t;heapify(a,n,largest);}
    }

    // ============================================================
    // SEARCHING ALGORITHMS
    // ============================================================
    static int linearSearch(int[] a, int target) {
        for(int i=0;i<a.length;i++) if(a[i]==target) return i;
        return -1;
    }

    static int binarySearch(int[] a, int target) {
        int lo=0, hi=a.length-1;
        while(lo<=hi){
            int mid=lo+(hi-lo)/2;
            if(a[mid]==target) return mid;
            if(a[mid]<target) lo=mid+1; else hi=mid-1;
        }
        return -1;
    }

    static int jumpSearch(int[] a, int target) {
        int n=a.length, step=(int)Math.sqrt(n), prev=0;
        while(a[Math.min(step,n)-1]<target){prev=step;step+=(int)Math.sqrt(n);if(prev>=n)return -1;}
        while(a[prev]<target){prev++;if(prev==Math.min(step,n))return -1;}
        return a[prev]==target?prev:-1;
    }

    // ============================================================
    // DYNAMIC PROGRAMMING
    // ============================================================
    // Fibonacci (memoization)
    static long fibMemo(int n, Map<Integer,Long> memo) {
        if(n<=1) return n;
        if(memo.containsKey(n)) return memo.get(n);
        long result=fibMemo(n-1,memo)+fibMemo(n-2,memo);
        memo.put(n,result); return result;
    }

    // Fibonacci (tabulation)
    static long fibDP(int n) {
        if(n<=1) return n;
        long[] dp=new long[n+1]; dp[0]=0;dp[1]=1;
        for(int i=2;i<=n;i++) dp[i]=dp[i-1]+dp[i-2];
        return dp[n];
    }

    // 0/1 Knapsack
    static int knapsack(int[] weights, int[] values, int capacity) {
        int n=weights.length;
        int[][] dp=new int[n+1][capacity+1];
        for(int i=1;i<=n;i++)
            for(int w=0;w<=capacity;w++) {
                dp[i][w]=dp[i-1][w];
                if(weights[i-1]<=w)
                    dp[i][w]=Math.max(dp[i][w], dp[i-1][w-weights[i-1]]+values[i-1]);
            }
        return dp[n][capacity];
    }

    // Longest Common Subsequence
    static int lcs(String s1, String s2) {
        int m=s1.length(),n=s2.length();
        int[][] dp=new int[m+1][n+1];
        for(int i=1;i<=m;i++)
            for(int j=1;j<=n;j++)
                dp[i][j]=s1.charAt(i-1)==s2.charAt(j-1)?dp[i-1][j-1]+1:Math.max(dp[i-1][j],dp[i][j-1]);
        return dp[m][n];
    }

    // Coin Change (minimum coins)
    static int coinChange(int[] coins, int amount) {
        int[] dp=new int[amount+1];
        Arrays.fill(dp, amount+1);
        dp[0]=0;
        for(int i=1;i<=amount;i++)
            for(int c:coins) if(c<=i) dp[i]=Math.min(dp[i],dp[i-c]+1);
        return dp[amount]>amount?-1:dp[amount];
    }

    // Longest Increasing Subsequence
    static int lis(int[] a) {
        int n=a.length;
        int[] dp=new int[n]; Arrays.fill(dp,1);
        for(int i=1;i<n;i++)
            for(int j=0;j<i;j++)
                if(a[j]<a[i]) dp[i]=Math.max(dp[i],dp[j]+1);
        return Arrays.stream(dp).max().orElse(0);
    }

    // Max Subarray (Kadane's)
    static int maxSubarray(int[] a) {
        int maxSoFar=a[0], maxEndingHere=a[0];
        for(int i=1;i<a.length;i++){
            maxEndingHere=Math.max(a[i],maxEndingHere+a[i]);
            maxSoFar=Math.max(maxSoFar,maxEndingHere);
        }
        return maxSoFar;
    }

    // ============================================================
    // MATH ALGORITHMS
    // ============================================================
    static int gcd(int a, int b) { return b==0?a:gcd(b,a%b); }
    static int lcm(int a, int b) { return a/gcd(a,b)*b; }

    static boolean isPrime(int n) {
        if(n<2) return false; if(n<4) return true;
        if(n%2==0||n%3==0) return false;
        for(int i=5;i*i<=n;i+=6) if(n%i==0||n%(i+2)==0) return false;
        return true;
    }

    static List<Integer> sieveOfEratosthenes(int n) {
        boolean[] isComposite=new boolean[n+1];
        for(int i=2;i*i<=n;i++) if(!isComposite[i]) for(int j=i*i;j<=n;j+=i) isComposite[j]=true;
        List<Integer> primes=new ArrayList<>();
        for(int i=2;i<=n;i++) if(!isComposite[i]) primes.add(i);
        return primes;
    }

    static long power(long base, long exp, long mod) {
        long result=1; base%=mod;
        while(exp>0){if((exp&1)==1) result=result*base%mod; exp>>=1; base=base*base%mod;}
        return result;
    }

    // ============================================================
    // RECURSION
    // ============================================================
    static long factorial(int n) { return n<=1?1:n*factorial(n-1); }

    static void hanoi(int n, char from, char to, char aux) {
        if(n==0) return;
        hanoi(n-1,from,aux,to);
        System.out.printf("  Move disk %d: %c -> %c%n",n,from,to);
        hanoi(n-1,aux,to,from);
    }

    static List<List<Integer>> permutations(int[] nums) {
        List<List<Integer>> result=new ArrayList<>();
        permuteHelper(nums,0,result); return result;
    }
    static void permuteHelper(int[] nums, int start, List<List<Integer>> result) {
        if(start==nums.length){List<Integer> perm=new ArrayList<>();for(int n:nums)perm.add(n);result.add(perm);return;}
        for(int i=start;i<nums.length;i++){
            int t=nums[start];nums[start]=nums[i];nums[i]=t;
            permuteHelper(nums,start+1,result);
            t=nums[start];nums[start]=nums[i];nums[i]=t;
        }
    }

    public static void main(String[] args) {
        int[] orig = {64,25,12,22,11,90,45,33,78,5};

        System.out.println("=== SORTING ===");
        int[] a;
        a=orig.clone(); bubbleSort(a);    System.out.println("Bubble:    " + Arrays.toString(a));
        a=orig.clone(); selectionSort(a); System.out.println("Selection: " + Arrays.toString(a));
        a=orig.clone(); insertionSort(a); System.out.println("Insertion: " + Arrays.toString(a));
        a=orig.clone(); mergeSort(a,0,a.length-1); System.out.println("Merge:     " + Arrays.toString(a));
        a=orig.clone(); quickSort(a,0,a.length-1); System.out.println("Quick:     " + Arrays.toString(a));
        a=orig.clone(); System.out.println("Heap:      " + Arrays.toString(heapSort(a)));
        a=new int[]{4,2,9,2,5,1,7,3}; countingSort(a,9); System.out.println("Counting:  " + Arrays.toString(a));

        System.out.println("\n=== SEARCHING ===");
        int[] sorted={5,11,12,22,25,33,45,64,78,90};
        System.out.println("Array:    " + Arrays.toString(sorted));
        System.out.println("Linear(45):      idx=" + linearSearch(sorted,45));
        System.out.println("Binary(45):      idx=" + binarySearch(sorted,45));
        System.out.println("Binary(99):      idx=" + binarySearch(sorted,99));
        System.out.println("Jump(33):        idx=" + jumpSearch(sorted,33));

        System.out.println("\n=== DYNAMIC PROGRAMMING ===");
        Map<Integer,Long> memo=new HashMap<>();
        System.out.println("Fib(10) memo:   " + fibMemo(10,memo));
        System.out.println("Fib(50) dp:     " + fibDP(50));

        int[] weights={1,3,4,5}, values={1,4,5,7};
        System.out.println("Knapsack(7):    " + knapsack(weights,values,7));

        System.out.println("LCS(ABCBDAB,BDCAB): " + lcs("ABCBDAB","BDCAB"));

        int[] coins={1,5,10,25};
        System.out.println("CoinChange(41): " + coinChange(coins,41) + " coins");
        System.out.println("CoinChange(3):  " + coinChange(new int[]{2},3) + " (impossible)");

        int[] seq={10,9,2,5,3,7,101,18};
        System.out.println("LIS:            " + lis(seq));

        int[] sub={-2,1,-3,4,-1,2,1,-5,4};
        System.out.println("MaxSubarray:    " + maxSubarray(sub));

        System.out.println("\n=== MATH ===");
        System.out.println("GCD(48,18):     " + gcd(48,18));
        System.out.println("LCM(4,6):       " + lcm(4,6));
        System.out.println("isPrime(17):    " + isPrime(17));
        System.out.println("isPrime(20):    " + isPrime(20));
        System.out.println("Primes<=30:     " + sieveOfEratosthenes(30));
        System.out.println("2^10 mod 1000:  " + power(2,10,1000));

        System.out.println("\n=== RECURSION ===");
        System.out.println("10! = " + factorial(10));
        System.out.println("Tower of Hanoi (3 disks):");
        hanoi(3,'A','C','B');
        System.out.println("Permutations of [1,2,3]: " + permutations(new int[]{1,2,3}).size() + " perms");
        permutations(new int[]{1,2,3}).forEach(p -> System.out.print(p + " "));
        System.out.println();
    }
}
