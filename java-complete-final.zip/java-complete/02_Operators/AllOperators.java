/**
 * TOPIC 02: All Java Operators - Complete Reference
 * ==================================================
 * Categories:
 *   Arithmetic  : + - * / % ++ --
 *   Assignment  : = += -= *= /= %= &= |= ^= <<= >>= >>>=
 *   Relational  : == != < > <= >=
 *   Logical     : && || ! & | ^ (short-circuit vs non-short-circuit)
 *   Bitwise     : & | ^ ~ << >> >>>
 *   Ternary     : condition ? true : false
 *   instanceof  : type checking
 *   Precedence  : higher precedence evaluated first
 */
public class AllOperators {
    public static void main(String[] args) {

        // ============================================================
        // ARITHMETIC OPERATORS
        // ============================================================
        System.out.println("=== ARITHMETIC OPERATORS ===");
        int a = 17, b = 5;
        System.out.println("a=" + a + ", b=" + b);
        System.out.println("a + b = " + (a + b));    // 22
        System.out.println("a - b = " + (a - b));    // 12
        System.out.println("a * b = " + (a * b));    // 85
        System.out.println("a / b = " + (a / b));    // 3 (integer division!)
        System.out.println("a % b = " + (a % b));    // 2 (modulus/remainder)

        // Important: integer division truncates
        System.out.println("17/5 (int) = " + (17/5));       // 3
        System.out.println("17.0/5 (double) = " + (17.0/5)); // 3.4
        System.out.println("(double)17/5 = " + ((double)17/5)); // 3.4

        // Modulus with negatives
        System.out.println("-7 % 3 = " + (-7 % 3));   // -1 (sign follows dividend)
        System.out.println("7 % -3 = " + (7 % -3));   // 1

        // ============================================================
        // INCREMENT / DECREMENT
        // ============================================================
        System.out.println("\n=== INCREMENT / DECREMENT ===");
        int x = 5;
        System.out.println("x    = " + x);
        System.out.println("x++  = " + x++);  // post: returns 5, THEN x=6
        System.out.println("x    = " + x);    // 6
        System.out.println("++x  = " + ++x);  // pre: x=7, THEN returns 7
        System.out.println("x--  = " + x--);  // post: returns 7, THEN x=6
        System.out.println("--x  = " + --x);  // pre: x=5, THEN returns 5
        System.out.println("x    = " + x);    // 5

        // Tricky cases
        int n = 10;
        int r = n++ + ++n;  // 10 + 12 = 22 (n goes 10->11->12)
        System.out.println("n=10; n++ + ++n = " + r + " (n=" + n + ")");

        // ============================================================
        // ASSIGNMENT OPERATORS
        // ============================================================
        System.out.println("\n=== ASSIGNMENT OPERATORS ===");
        int v = 20;
        System.out.println("v = 20");
        v += 5;  System.out.println("v += 5  -> " + v);   // 25
        v -= 3;  System.out.println("v -= 3  -> " + v);   // 22
        v *= 2;  System.out.println("v *= 2  -> " + v);   // 44
        v /= 4;  System.out.println("v /= 4  -> " + v);   // 11
        v %= 4;  System.out.println("v %= 4  -> " + v);   // 3
        v <<= 2; System.out.println("v <<= 2 -> " + v);   // 12 (3 * 4)
        v >>= 1; System.out.println("v >>= 1 -> " + v);   // 6 (12 / 2)
        v &= 5;  System.out.println("v &= 5  -> " + v);   // 4 (0110 & 0101 = 0100)
        v |= 3;  System.out.println("v |= 3  -> " + v);   // 7 (100 | 011 = 111)
        v ^= 2;  System.out.println("v ^= 2  -> " + v);   // 5 (111 ^ 010 = 101)

        // ============================================================
        // RELATIONAL OPERATORS
        // ============================================================
        System.out.println("\n=== RELATIONAL OPERATORS ===");
        int p = 10, q = 20;
        System.out.println("p=10, q=20");
        System.out.println("p == q  : " + (p == q));   // false
        System.out.println("p != q  : " + (p != q));   // true
        System.out.println("p <  q  : " + (p <  q));   // true
        System.out.println("p >  q  : " + (p >  q));   // false
        System.out.println("p <= q  : " + (p <= q));   // true
        System.out.println("p >= q  : " + (p >= q));   // false

        // ============================================================
        // LOGICAL OPERATORS (Short-Circuit)
        // ============================================================
        System.out.println("\n=== LOGICAL OPERATORS ===");
        boolean t = true, f = false;
        System.out.println("t && t = " + (t && t));    // true
        System.out.println("t && f = " + (t && f));    // false
        System.out.println("f && t = " + (f && t));    // false (short-circuit: t not evaluated!)
        System.out.println("f || t = " + (f || t));    // true
        System.out.println("t || f = " + (t || f));    // true (short-circuit: f not evaluated!)
        System.out.println("!t     = " + (!t));        // false
        System.out.println("!f     = " + (!f));        // true

        // Short-circuit demonstration
        int counter = 0;
        boolean r1 = false && (++counter > 0);  // counter NOT incremented (short-circuit)
        System.out.println("false && (++counter): counter=" + counter);  // 0
        boolean r2 = true  || (++counter > 0);  // counter NOT incremented
        System.out.println("true  || (++counter): counter=" + counter);  // 0

        // Non-short-circuit (evaluates both sides always)
        counter = 0;
        boolean r3 = false & (++counter > 0);   // counter IS incremented
        System.out.println("false &  (++counter): counter=" + counter);  // 1
        boolean r4 = true  | (++counter > 0);   // counter IS incremented
        System.out.println("true  |  (++counter): counter=" + counter);  // 2

        // ============================================================
        // BITWISE OPERATORS
        // ============================================================
        System.out.println("\n=== BITWISE OPERATORS ===");
        int bA = 0b1100;  // 12
        int bB = 0b1010;  // 10
        System.out.printf("A  = %4d  [%s]%n", bA, Integer.toBinaryString(bA));
        System.out.printf("B  = %4d  [%s]%n", bB, Integer.toBinaryString(bB));
        System.out.printf("A&B= %4d  [%s]  (AND)%n", bA&bB, Integer.toBinaryString(bA&bB));   // 8
        System.out.printf("A|B= %4d  [%s]  (OR)%n",  bA|bB, Integer.toBinaryString(bA|bB));  // 14
        System.out.printf("A^B= %4d  [%s]  (XOR)%n", bA^bB, Integer.toBinaryString(bA^bB));  // 6
        System.out.printf("~A = %4d        (NOT/complement)%n", ~bA);  // -13
        System.out.printf("A<<1= %4d  [%s]  (left shift *2)%n", bA<<1, Integer.toBinaryString(bA<<1));   // 24
        System.out.printf("A>>1= %4d  [%s]  (right shift /2)%n",bA>>1, Integer.toBinaryString(bA>>1));  // 6
        System.out.printf("A>>>1=%4d  [%s]  (unsigned right shift)%n",bA>>>1, Integer.toBinaryString(bA>>>1)); // 6

        // Practical bitwise uses
        System.out.println("\nPractical uses:");
        System.out.println("n & 1 == 0 ? even : odd : " + (bA & 1) + " -> " + (bA%2==0 ? "even":"odd"));
        System.out.println("n << 1 = n*2 : " + (bA<<1));
        System.out.println("n >> 1 = n/2 : " + (bA>>1));

        // ============================================================
        // TERNARY OPERATOR
        // ============================================================
        System.out.println("\n=== TERNARY OPERATOR ===");
        int age = 20;
        String status = (age >= 18) ? "Adult" : "Minor";
        int max = (p > q) ? p : q;
        // Nested ternary
        String grade = (age >= 90) ? "A" : (age >= 80) ? "B" : (age >= 70) ? "C" : "D";
        System.out.println("status = " + status);
        System.out.println("max(p,q) = " + max);
        System.out.println("grade = " + grade);

        // ============================================================
        // instanceof OPERATOR
        // ============================================================
        System.out.println("\n=== instanceof OPERATOR ===");
        Object str = "Hello Java";
        Object num = 42;
        System.out.println("str instanceof String  : " + (str instanceof String));   // true
        System.out.println("str instanceof Object  : " + (str instanceof Object));   // true
        System.out.println("num instanceof Integer : " + (num instanceof Integer));  // true
        System.out.println("num instanceof String  : " + (num instanceof String));   // false
        System.out.println("null instanceof String : " + (null instanceof String));  // false (never NPE)

        // Pattern matching instanceof (Java 16+)
        Object obj = "Hello World";
        if (obj instanceof String s && s.length() > 5) {
            System.out.println("Pattern match: '" + s + "' length=" + s.length());
        }

        // ============================================================
        // OPERATOR PRECEDENCE (high to low)
        // ============================================================
        System.out.println("\n=== OPERATOR PRECEDENCE ===");
        // () -> ++ -- (postfix) -> ++ -- ! ~ (prefix) -> * / % -> + -
        // -> << >> >>> -> < > <= >= instanceof -> == !=
        // -> & -> ^ -> | -> && -> || -> ?: -> =
        int result = 2 + 3 * 4;        // 14 (not 20!) - * before +
        System.out.println("2 + 3 * 4 = " + result);
        result = (2 + 3) * 4;           // 20 - parentheses override
        System.out.println("(2+3) * 4 = " + result);
        result = 10 - 3 + 2;            // 9 (left to right for same precedence)
        System.out.println("10 - 3 + 2 = " + result);
        boolean b1 = 5 > 3 && 2 < 4;   // true (> and < before &&)
        System.out.println("5>3 && 2<4 = " + b1);
    }
}
