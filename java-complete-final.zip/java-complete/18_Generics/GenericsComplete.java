/**
 * TOPIC 18: Generics - Complete Reference
 * =========================================
 * Generics: compile-time type safety, eliminates casting
 * Type erasure: generics only exist at compile time
 *
 * Generic class:  class Box<T> { T value; }
 * Generic method: <T extends Comparable<T>> T max(T a, T b)
 * Bounded types:  <T extends Number>, <T super Integer>
 * Wildcards:      ?, ? extends T, ? super T
 * PECS:           Producer Extends, Consumer Super
 * Multiple bounds: <T extends Comparable<T> & Serializable>
 */
import java.util.*;
import java.util.function.*;

public class GenericsComplete {

    // ============================================================
    // GENERIC CLASSES
    // ============================================================
    static class Box<T> {
        private T value;
        public Box(T value)        { this.value = value; }
        public T get()             { return value; }
        public void set(T value)   { this.value = value; }
        public boolean isEmpty()   { return value == null; }
        public <R> Box<R> map(Function<T, R> fn) { return new Box<>(fn.apply(value)); }
        @Override public String toString() { return "Box[" + value + "]"; }
    }

    static class Pair<A, B> {
        private final A first;
        private final B second;

        public Pair(A first, B second) { this.first=first; this.second=second; }
        public A getFirst()            { return first; }
        public B getSecond()           { return second; }
        public Pair<B, A> swap()       { return new Pair<>(second, first); }

        public static <X, Y> Pair<X, Y> of(X x, Y y) { return new Pair<>(x, y); }

        @Override public String toString() { return "(" + first + ", " + second + ")"; }
    }

    static class Triple<A, B, C> {
        private final A first; private final B second; private final C third;
        public Triple(A a, B b, C c) { first=a; second=b; third=c; }
        public A getFirst()  { return first; }
        public B getSecond() { return second; }
        public C getThird()  { return third; }
        @Override public String toString() { return "(" + first + ", " + second + ", " + third + ")"; }
    }

    // Generic Stack
    static class Stack<T> {
        private final LinkedList<T> items = new LinkedList<>();
        public void  push(T item)        { items.addFirst(item); }
        public T     pop()               {
            if (isEmpty()) throw new EmptyStackException();
            return items.removeFirst();
        }
        public T     peek()              {
            if (isEmpty()) throw new EmptyStackException();
            return items.getFirst();
        }
        public boolean isEmpty()         { return items.isEmpty(); }
        public int   size()              { return items.size(); }
        @Override public String toString(){ return items.toString(); }
    }

    // Generic Repository
    interface Repository<T, ID> {
        void          save(T entity);
        Optional<T>   findById(ID id);
        List<T>       findAll();
        void          delete(ID id);
        int           count();
    }

    static class InMemoryRepo<T> implements Repository<T, Integer> {
        private final Map<Integer, T> store = new LinkedHashMap<>();
        private int nextId = 1;

        @Override public void save(T entity)               { store.put(nextId++, entity); }
        @Override public Optional<T> findById(Integer id)  { return Optional.ofNullable(store.get(id)); }
        @Override public List<T> findAll()                  { return new ArrayList<>(store.values()); }
        @Override public void delete(Integer id)            { store.remove(id); }
        @Override public int count()                        { return store.size(); }

        public List<T> findAll(Predicate<T> filter) {
            return store.values().stream().filter(filter).collect(java.util.stream.Collectors.toList());
        }
    }

    // ============================================================
    // GENERIC METHODS
    // ============================================================
    static <T extends Comparable<T>> T max(T a, T b) {
        return a.compareTo(b) >= 0 ? a : b;
    }

    static <T extends Comparable<T>> T min(T a, T b) {
        return a.compareTo(b) <= 0 ? a : b;
    }

    static <T extends Comparable<T>> void bubbleSort(T[] arr) {
        for (int i = 0; i < arr.length-1; i++)
            for (int j = 0; j < arr.length-i-1; j++)
                if (arr[j].compareTo(arr[j+1]) > 0) {
                    T t = arr[j]; arr[j] = arr[j+1]; arr[j+1] = t;
                }
    }

    static <T> void swap(T[] arr, int i, int j) {
        T t = arr[i]; arr[i] = arr[j]; arr[j] = t;
    }

    static <T> List<T> filter(List<T> list, Predicate<T> pred) {
        List<T> result = new ArrayList<>();
        for (T t : list) if (pred.test(t)) result.add(t);
        return result;
    }

    static <T, R> List<R> map(List<T> list, Function<T, R> fn) {
        List<R> result = new ArrayList<>();
        for (T t : list) result.add(fn.apply(t));
        return result;
    }

    static <T> T reduce(List<T> list, T identity, BinaryOperator<T> op) {
        T result = identity;
        for (T t : list) result = op.apply(result, t);
        return result;
    }

    // Multiple bounds
    static <T extends Comparable<T> & java.io.Serializable> T clampedMax(T a, T b) {
        return max(a, b);
    }

    // ============================================================
    // WILDCARDS
    // ============================================================
    // ? extends T: upper bounded, read-only (Producer)
    static double sumNumbers(List<? extends Number> list) {
        double sum = 0;
        for (Number n : list) sum += n.doubleValue();
        return sum;
    }

    // ? super T: lower bounded, write (Consumer)
    static void fillWith(List<? super Integer> list, int... values) {
        for (int v : values) list.add(v);
    }

    // Unbounded wildcard
    static void printAll(List<?> list) {
        list.forEach(item -> System.out.print(item + " "));
        System.out.println();
    }

    // PECS example: copy from src to dest
    static <T> void copy(List<? extends T> src, List<? super T> dest) {
        for (T item : src) dest.add(item);
    }

    public static void main(String[] args) {

        System.out.println("=== GENERIC CLASSES ===");
        Box<String>  strBox = new Box<>("Hello");
        Box<Integer> intBox = new Box<>(42);
        Box<String>  mapped = strBox.map(s -> s.toUpperCase());
        System.out.println("strBox: " + strBox + " -> upper: " + mapped);
        System.out.println("intBox: " + intBox + " -> doubled: " + intBox.map(n -> n * 2));

        Pair<String, Integer> pair = Pair.of("Alice", 25);
        System.out.println("pair: " + pair + " | swapped: " + pair.swap());

        Triple<String, Integer, Double> triple = new Triple<>("Bob", 30, 9.5);
        System.out.println("triple: " + triple);

        System.out.println("\n=== GENERIC STACK ===");
        Stack<String> stack = new Stack<>();
        stack.push("Java"); stack.push("Python"); stack.push("Go");
        System.out.println("Stack: " + stack);
        System.out.println("peek: " + stack.peek() + " | pop: " + stack.pop());
        System.out.println("Stack: " + stack + " | size: " + stack.size());

        System.out.println("\n=== GENERIC REPOSITORY ===");
        InMemoryRepo<String> repo = new InMemoryRepo<>();
        repo.save("Alice"); repo.save("Bob"); repo.save("Charlie"); repo.save("Diana");
        System.out.println("All: " + repo.findAll());
        System.out.println("findById(2): " + repo.findById(2));
        System.out.println("findAll(len>3): " + repo.findAll(s -> s.length() > 3));
        repo.delete(2);
        System.out.println("After delete(2): " + repo.findAll() + " count=" + repo.count());

        System.out.println("\n=== GENERIC METHODS ===");
        System.out.println("max(3,7):             " + max(3, 7));
        System.out.println("max(\"apple\",\"banana\"): " + max("apple", "banana"));
        System.out.println("max(3.14, 2.71):       " + max(3.14, 2.71));

        Integer[] arr = {5, 2, 8, 1, 9, 3, 7};
        bubbleSort(arr);
        System.out.println("bubbleSort: " + Arrays.toString(arr));

        String[] sarr = {"banana","apple","cherry","date"};
        bubbleSort(sarr);
        System.out.println("bubbleSort strings: " + Arrays.toString(sarr));

        List<Integer> nums = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        System.out.println("filter(even): " + filter(nums, n -> n % 2 == 0));
        System.out.println("map(x*x):     " + map(nums, n -> n * n));
        System.out.println("reduce(sum):  " + reduce(nums, 0, Integer::sum));
        System.out.println("reduce(prod): " + reduce(Arrays.asList(1,2,3,4,5), 1, (a,b)->a*b));

        System.out.println("\n=== WILDCARDS ===");
        List<Integer>  ints    = Arrays.asList(1, 2, 3, 4, 5);
        List<Double>   doubles = Arrays.asList(1.1, 2.2, 3.3);
        List<Long>     longs   = Arrays.asList(100L, 200L, 300L);
        System.out.println("sum(ints):    " + sumNumbers(ints));
        System.out.println("sum(doubles): " + sumNumbers(doubles));
        System.out.println("sum(longs):   " + sumNumbers(longs));

        List<Number> numList = new ArrayList<>();
        fillWith(numList, 10, 20, 30, 40);
        System.out.println("fillWith ints: " + numList);

        System.out.print("printAll: "); printAll(nums);

        List<Integer> source = Arrays.asList(1, 2, 3);
        List<Number> dest = new ArrayList<>();
        copy(source, dest);
        System.out.println("copy: " + dest);

        System.out.println("\n=== TYPE ERASURE ===");
        Box<String>  bs = new Box<>("hello");
        Box<Integer> bi = new Box<>(42);
        System.out.println("bs.getClass() == bi.getClass(): " + (bs.getClass() == bi.getClass())); // true!
        System.out.println("Both are just Box at runtime (type erased)");
    }
}
