/**
 * TOPIC 40: Unit Testing with JUnit 5 Concepts
 * ==============================================
 * NOTE: This file demonstrates testing patterns and concepts.
 * In a real project: add JUnit 5 + Mockito to your build tool.
 *
 * JUnit 5 annotations:
 *   @Test, @BeforeEach, @AfterEach, @BeforeAll, @AfterAll
 *   @DisplayName, @Disabled, @Tag, @Nested, @ParameterizedTest
 *   @ValueSource, @CsvSource, @MethodSource
 *
 * Assertions: assertEquals, assertNotNull, assertThrows, assertTrue, assertAll
 * Mockito: mock(), when(), verify(), ArgumentCaptor, @Mock, @InjectMocks
 * TDD: Red -> Green -> Refactor
 */
import java.util.*;
import java.util.function.*;

public class UnitTestingConcepts {

    // ============================================================
    // CLASSES TO TEST
    // ============================================================
    static class Calculator {
        public int    add(int a, int b)         { return a + b; }
        public int    subtract(int a, int b)    { return a - b; }
        public int    multiply(int a, int b)    { return a * b; }
        public double divide(int a, int b) {
            if (b == 0) throw new ArithmeticException("Cannot divide by zero");
            return (double) a / b;
        }
        public long   factorial(int n) {
            if (n < 0) throw new IllegalArgumentException("n must be >= 0");
            if (n == 0) return 1;
            return n * factorial(n - 1);
        }
        public boolean isPrime(int n) {
            if (n < 2) return false;
            for (int i = 2; i * i <= n; i++) if (n % i == 0) return false;
            return true;
        }
    }

    static class StringUtils {
        public String reverse(String s) {
            if (s == null) throw new NullPointerException("Input cannot be null");
            return new StringBuilder(s).reverse().toString();
        }
        public boolean isPalindrome(String s) {
            if (s == null) return false;
            String clean = s.toLowerCase().replaceAll("[^a-z0-9]", "");
            return clean.equals(new StringBuilder(clean).reverse().toString());
        }
        public int countOccurrences(String text, char ch) {
            if (text == null) return 0;
            int count = 0;
            for (char c : text.toCharArray()) if (c == ch) count++;
            return count;
        }
        public String titleCase(String s) {
            if (s == null || s.isBlank()) return s;
            return Arrays.stream(s.split("\\s+"))
                .map(w -> Character.toUpperCase(w.charAt(0)) + w.substring(1).toLowerCase())
                .reduce("", (a, b) -> a.isEmpty() ? b : a + " " + b);
        }
    }

    // Repository interface (for Mockito-style testing)
    interface UserRepository {
        Optional<String> findById(int id);
        List<String>     findAll();
        boolean          save(String user);
        void             deleteById(int id);
    }

    static class UserService {
        private final UserRepository repo;
        public UserService(UserRepository repo) { this.repo = repo; }

        public String getUserName(int id) {
            return repo.findById(id).orElseThrow(() -> new RuntimeException("User not found: " + id));
        }
        public List<String> getAllUsers() {
            List<String> users = repo.findAll();
            if (users.isEmpty()) throw new RuntimeException("No users found");
            return users;
        }
        public boolean createUser(String name) {
            if (name == null || name.isBlank()) throw new IllegalArgumentException("Name cannot be blank");
            return repo.save(name.trim());
        }
    }

    // ============================================================
    // MINI TEST FRAMEWORK (simulates JUnit)
    // ============================================================
    static int passed = 0, failed = 0;

    static void test(String name, Runnable testFn) {
        try {
            testFn.run();
            System.out.println("  ✅ PASS: " + name);
            passed++;
        } catch (AssertionError e) {
            System.out.println("  ❌ FAIL: " + name + " | " + e.getMessage());
            failed++;
        } catch (Exception e) {
            System.out.println("  ❌ ERROR: " + name + " | " + e.getMessage());
            failed++;
        }
    }

    static void assertEquals(Object expected, Object actual) {
        if (!Objects.equals(expected, actual))
            throw new AssertionError("Expected <" + expected + "> but was <" + actual + ">");
    }
    static void assertTrue(boolean condition) {
        if (!condition) throw new AssertionError("Expected true but was false");
    }
    static void assertFalse(boolean condition) {
        if (condition) throw new AssertionError("Expected false but was true");
    }
    static void assertNotNull(Object obj) {
        if (obj == null) throw new AssertionError("Expected non-null but was null");
    }
    static void assertNull(Object obj) {
        if (obj != null) throw new AssertionError("Expected null but was <" + obj + ">");
    }
    static <T extends Throwable> T assertThrows(Class<T> type, Runnable fn) {
        try { fn.run(); throw new AssertionError("Expected " + type.getSimpleName() + " but none thrown"); }
        catch (Throwable t) {
            if (!type.isInstance(t)) throw new AssertionError("Expected " + type.getSimpleName() + " but got " + t.getClass().getSimpleName());
            return type.cast(t);
        }
    }

    // Mockito-style mock (simplified)
    static UserRepository mockRepo(Map<Integer, String> users) {
        return new UserRepository() {
            public Optional<String> findById(int id) { return Optional.ofNullable(users.get(id)); }
            public List<String>     findAll()         { return new ArrayList<>(users.values()); }
            public boolean          save(String u)    { users.put(users.size()+1, u); return true; }
            public void             deleteById(int id){ users.remove(id); }
        };
    }

    public static void main(String[] args) {

        System.out.println("=== JUNIT 5 - REAL TEST ANNOTATIONS ===");
        System.out.println("""
            @Test
            @DisplayName("Should add two positive numbers")
            void testAdd() {
                Calculator calc = new Calculator();
                assertEquals(5, calc.add(2, 3));
                assertEquals(0, calc.add(-1, 1));
            }

            @ParameterizedTest
            @ValueSource(ints = {2, 3, 5, 7, 11, 13})
            void testIsPrime(int n) {
                assertTrue(new Calculator().isPrime(n));
            }

            @ParameterizedTest
            @CsvSource({"2,3,5", "10,5,15", "-1,1,0"})
            void testAddCSV(int a, int b, int expected) {
                assertEquals(expected, new Calculator().add(a, b));
            }

            @Test
            void testDivideByZero() {
                assertThrows(ArithmeticException.class, () -> new Calculator().divide(10, 0));
            }

            @BeforeEach
            void setUp() { /* runs before each test */ }

            @AfterEach
            void tearDown() { /* runs after each test */ }

            @Nested
            class DivisionTests {
                @Test void testPositiveDivision() { ... }
                @Test void testNegativeDivision() { ... }
            }
        """);

        // ============================================================
        // CALCULATOR TESTS
        // ============================================================
        System.out.println("=== CALCULATOR TESTS ===");
        Calculator calc = new Calculator();

        test("add: 2+3=5",           () -> assertEquals(5, calc.add(2,3)));
        test("add: negative",        () -> assertEquals(-1, calc.add(-4,3)));
        test("add: zeros",           () -> assertEquals(0, calc.add(0,0)));
        test("subtract: 10-3=7",     () -> assertEquals(7, calc.subtract(10,3)));
        test("multiply: 4*5=20",     () -> assertEquals(20, calc.multiply(4,5)));
        test("multiply: by zero",    () -> assertEquals(0, calc.multiply(99,0)));
        test("divide: 10/4=2.5",     () -> assertEquals(2.5, calc.divide(10,4)));
        test("divide by zero",       () -> assertThrows(ArithmeticException.class, () -> calc.divide(10,0)));
        test("factorial: 5!=120",    () -> assertEquals(120L, calc.factorial(5)));
        test("factorial: 0!=1",      () -> assertEquals(1L, calc.factorial(0)));
        test("factorial: negative",  () -> assertThrows(IllegalArgumentException.class, () -> calc.factorial(-1)));
        test("isPrime: 7",           () -> assertTrue(calc.isPrime(7)));
        test("isPrime: 2",           () -> assertTrue(calc.isPrime(2)));
        test("isPrime: 1 (not)",     () -> assertFalse(calc.isPrime(1)));
        test("isPrime: 4 (not)",     () -> assertFalse(calc.isPrime(4)));
        test("isPrime: 0 (not)",     () -> assertFalse(calc.isPrime(0)));

        // ============================================================
        // STRING UTILS TESTS
        // ============================================================
        System.out.println("\n=== STRING UTILS TESTS ===");
        StringUtils su = new StringUtils();

        test("reverse: hello",         () -> assertEquals("olleh", su.reverse("hello")));
        test("reverse: empty",         () -> assertEquals("", su.reverse("")));
        test("reverse: null throws",   () -> assertThrows(NullPointerException.class, () -> su.reverse(null)));
        test("palindrome: racecar",    () -> assertTrue(su.isPalindrome("racecar")));
        test("palindrome: A man a plan a canal Panama", () -> assertTrue(su.isPalindrome("A man a plan a canal Panama")));
        test("palindrome: hello",      () -> assertFalse(su.isPalindrome("hello")));
        test("palindrome: null",       () -> assertFalse(su.isPalindrome(null)));
        test("countOccurrences: l in hello", () -> assertEquals(2, su.countOccurrences("hello",'l')));
        test("titleCase: hello world", () -> assertEquals("Hello World", su.titleCase("hello world")));
        test("titleCase: JAVA IS FUN", () -> assertEquals("Java Is Fun", su.titleCase("JAVA IS FUN")));

        // ============================================================
        // USER SERVICE TESTS (with Mock)
        // ============================================================
        System.out.println("\n=== USER SERVICE TESTS (Mock) ===");
        Map<Integer,String> mockData = new HashMap<>(Map.of(1,"Alice",2,"Bob",3,"Charlie"));
        UserRepository mockRepo = mockRepo(mockData);
        UserService service = new UserService(mockRepo);

        test("getUserName: id=1",      () -> assertEquals("Alice", service.getUserName(1)));
        test("getUserName: id=2",      () -> assertEquals("Bob",   service.getUserName(2)));
        test("getUserName: not found", () -> assertThrows(RuntimeException.class, () -> service.getUserName(99)));
        test("getAllUsers: not empty",  () -> assertNotNull(service.getAllUsers()));
        test("createUser: valid",       () -> assertTrue(service.createUser("Diana")));
        test("createUser: blank throws",() -> assertThrows(IllegalArgumentException.class, () -> service.createUser("  ")));
        test("createUser: null throws", () -> assertThrows(IllegalArgumentException.class, () -> service.createUser(null)));

        // ============================================================
        // SUMMARY
        // ============================================================
        System.out.println("\n=== TEST SUMMARY ===");
        System.out.println("Total:  " + (passed+failed));
        System.out.println("Passed: " + passed + " ✅");
        System.out.println("Failed: " + failed + " ❌");

        // ============================================================
        // MOCKITO QUICK REFERENCE
        // ============================================================
        System.out.println("\n=== MOCKITO QUICK REFERENCE ===");
        System.out.println("""
            // Create mock
            UserRepository repo = mock(UserRepository.class);
            @Mock UserRepository repo;  // with @ExtendWith(MockitoExtension.class)

            // Stub behavior
            when(repo.findById(1)).thenReturn(Optional.of("Alice"));
            when(repo.save(any())).thenReturn(true);
            when(repo.findById(99)).thenThrow(new RuntimeException("Not found"));
            doNothing().when(repo).deleteById(anyInt());

            // Verify interactions
            verify(repo, times(1)).findById(1);
            verify(repo, never()).deleteById(anyInt());
            verify(repo, atLeast(1)).findAll();

            // Argument Captor
            ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);
            verify(repo).save(captor.capture());
            assertEquals("Alice", captor.getValue());

            // Spy (partial mock - real object, override some methods)
            UserService spy = spy(new UserService(repo));
            doReturn("MockResult").when(spy).getUserName(1);
        """);

        System.out.println("=== TDD CYCLE ===");
        System.out.println("🔴 RED:    Write failing test first");
        System.out.println("🟢 GREEN:  Write minimal code to pass test");
        System.out.println("🔵 REFACTOR: Clean up code, tests still pass");
        System.out.println("Repeat!");
    }
}
