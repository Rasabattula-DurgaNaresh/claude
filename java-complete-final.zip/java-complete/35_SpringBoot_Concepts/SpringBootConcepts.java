/**
 * TOPIC 35: Spring Boot Concepts (No external dependencies)
 * ===========================================================
 * This file demonstrates Spring Boot PATTERNS and CONCEPTS
 * using pure Java. In real projects, add Spring Boot starter.
 *
 * Key Concepts:
 *   @SpringBootApplication = @Configuration + @ComponentScan + @EnableAutoConfiguration
 *   IoC Container: Spring manages object creation and lifecycle
 *   Dependency Injection: @Autowired, constructor injection
 *   @RestController, @GetMapping, @PostMapping, @RequestBody
 *   @Service, @Repository, @Component (stereotypes)
 *   AOP: @Aspect, @Before, @After, @Around
 *   @Transactional: declarative transaction management
 *   application.properties / application.yml
 *   Actuator: /health, /metrics, /info, /beans
 */
import java.util.*;
import java.util.function.*;
import java.lang.annotation.*;

public class SpringBootConcepts {

    // ============================================================
    // DEPENDENCY INJECTION SIMULATION
    // ============================================================

    // @Repository equivalent
    interface ProductRepository {
        Optional<Product> findById(Long id);
        List<Product> findAll();
        List<Product> findByCategory(String category);
        Product save(Product product);
        void deleteById(Long id);
    }

    record Product(Long id, String name, String category, double price, int stock) {
        @Override public String toString() {
            return String.format("Product{id=%d name='%s' cat='%s' price=%.2f stock=%d}",
                id, name, category, price, stock);
        }
    }

    // @Repository implementation
    static class InMemoryProductRepository implements ProductRepository {
        private final Map<Long, Product> store = new LinkedHashMap<>();
        private long nextId = 1;

        public InMemoryProductRepository() {
            save(new Product(null, "Laptop",    "Electronics", 65000, 10));
            save(new Product(null, "Phone",     "Electronics", 25000, 50));
            save(new Product(null, "Chair",     "Furniture",   8000,  20));
            save(new Product(null, "Desk",      "Furniture",   15000, 15));
            save(new Product(null, "Notebook",  "Stationery",  150,   100));
        }

        @Override public Optional<Product> findById(Long id) {
            return Optional.ofNullable(store.get(id));
        }
        @Override public List<Product> findAll() { return new ArrayList<>(store.values()); }
        @Override public List<Product> findByCategory(String cat) {
            return store.values().stream().filter(p -> p.category().equals(cat)).toList();
        }
        @Override public Product save(Product p) {
            long id = p.id() == null ? nextId++ : p.id();
            Product saved = new Product(id, p.name(), p.category(), p.price(), p.stock());
            store.put(id, saved);
            return saved;
        }
        @Override public void deleteById(Long id) { store.remove(id); }
    }

    // @Service layer
    static class ProductService {
        private final ProductRepository repo;  // Injected!

        // Constructor injection (preferred in Spring)
        public ProductService(ProductRepository repo) { this.repo = repo; }

        public List<Product> getAllProducts()                   { return repo.findAll(); }
        public Optional<Product> getById(Long id)              { return repo.findById(id); }
        public List<Product> getByCategory(String category)    { return repo.findByCategory(category); }

        public Product createProduct(String name, String category, double price, int stock) {
            if (name == null || name.isBlank()) throw new IllegalArgumentException("Name required");
            if (price < 0)                      throw new IllegalArgumentException("Price must be >= 0");
            return repo.save(new Product(null, name, category, price, stock));
        }

        public Product updatePrice(Long id, double newPrice) {
            return repo.findById(id).map(p ->
                repo.save(new Product(p.id(), p.name(), p.category(), newPrice, p.stock()))
            ).orElseThrow(() -> new RuntimeException("Product not found: " + id));
        }

        public void deleteProduct(Long id) {
            if (repo.findById(id).isEmpty()) throw new RuntimeException("Product not found: " + id);
            repo.deleteById(id);
        }

        public Map<String, Double> getAveragePriceByCategory() {
            Map<String, List<Double>> grouped = new HashMap<>();
            repo.findAll().forEach(p -> grouped.computeIfAbsent(p.category(), k -> new ArrayList<>()).add(p.price()));
            Map<String, Double> result = new LinkedHashMap<>();
            grouped.forEach((cat, prices) -> result.put(cat, prices.stream().mapToDouble(d->d).average().orElse(0)));
            return result;
        }
    }

    // ============================================================
    // REST CONTROLLER SIMULATION
    // ============================================================
    static class ProductController {
        private final ProductService service;

        public ProductController(ProductService service) { this.service = service; }

        // @GetMapping("/products")
        public ApiResponse<List<Product>> getAllProducts() {
            return ApiResponse.success(service.getAllProducts());
        }

        // @GetMapping("/products/{id}")
        public ApiResponse<Product> getProduct(Long id) {
            return service.getById(id)
                .map(ApiResponse::success)
                .orElse(ApiResponse.error("Product not found: " + id));
        }

        // @GetMapping("/products/category/{cat}")
        public ApiResponse<List<Product>> getByCategory(String category) {
            return ApiResponse.success(service.getByCategory(category));
        }

        // @PostMapping("/products")
        public ApiResponse<Product> createProduct(String name, String category, double price, int stock) {
            try {
                return ApiResponse.success(service.createProduct(name, category, price, stock));
            } catch (IllegalArgumentException e) {
                return ApiResponse.error(e.getMessage());
            }
        }

        // @PutMapping("/products/{id}/price")
        public ApiResponse<Product> updatePrice(Long id, double newPrice) {
            try {
                return ApiResponse.success(service.updatePrice(id, newPrice));
            } catch (RuntimeException e) {
                return ApiResponse.error(e.getMessage());
            }
        }

        // @DeleteMapping("/products/{id}")
        public ApiResponse<Void> deleteProduct(Long id) {
            try {
                service.deleteProduct(id);
                return ApiResponse.success(null);
            } catch (RuntimeException e) {
                return ApiResponse.error(e.getMessage());
            }
        }
    }

    record ApiResponse<T>(boolean success, T data, String message, int status) {
        static <T> ApiResponse<T> success(T data) {
            return new ApiResponse<>(true, data, "OK", 200);
        }
        static <T> ApiResponse<T> error(String msg) {
            return new ApiResponse<>(false, null, msg, 400);
        }
        @Override public String toString() {
            return String.format("ApiResponse{success=%b status=%d msg='%s' data=%s}", success, status, message, data);
        }
    }

    // ============================================================
    // AOP - ASPECT-ORIENTED PROGRAMMING SIMULATION
    // ============================================================
    // Simulates @Around, @Before, @After aspects

    static class LoggingAspect {
        public <T> T logAround(String methodName, java.util.concurrent.Callable<T> fn) throws Exception {
            System.out.println("  [AOP Before] Entering: " + methodName);
            long start = System.currentTimeMillis();
            try {
                T result = fn.call();
                System.out.println("  [AOP After ] " + methodName + " completed in " + (System.currentTimeMillis()-start) + "ms");
                return result;
            } catch (Exception e) {
                System.out.println("  [AOP Error ] " + methodName + " threw: " + e.getMessage());
                throw e;
            }
        }
    }

    static class TransactionAspect {
        public <T> T withTransaction(java.util.concurrent.Callable<T> fn) throws Exception {
            System.out.println("  [TX] Transaction BEGIN");
            try {
                T result = fn.call();
                System.out.println("  [TX] Transaction COMMIT");
                return result;
            } catch (Exception e) {
                System.out.println("  [TX] Transaction ROLLBACK: " + e.getMessage());
                throw e;
            }
        }
    }

    public static void main(String[] args) throws Exception {

        // Wire up dependencies (IoC container would do this)
        ProductRepository repo = new InMemoryProductRepository();
        ProductService service = new ProductService(repo);
        ProductController controller = new ProductController(service);
        LoggingAspect logging = new LoggingAspect();
        TransactionAspect tx = new TransactionAspect();

        System.out.println("=== SPRING BOOT ARCHITECTURE ===");
        System.out.println("""
            Request -> DispatcherServlet -> HandlerMapping
                    -> Controller (@RestController)
                    -> Service (@Service)
                    -> Repository (@Repository)
                    -> Database
                    <- ResponseEntity<T> (JSON)
            """);

        System.out.println("=== DEPENDENCY INJECTION ===");
        System.out.println("IoC container manages: ProductRepository <- ProductService <- ProductController");
        System.out.println("Constructor injection (preferred):");
        System.out.println("  @Autowired is automatic with single constructor in Spring Boot");
        System.out.println();

        System.out.println("=== REST API CALLS ===");

        // GET /products
        System.out.println("GET /products:");
        ApiResponse<List<Product>> all = logging.logAround("GET /products", () -> controller.getAllProducts());
        all.data().forEach(p -> System.out.println("  " + p));

        // GET /products/1
        System.out.println("\nGET /products/1:");
        System.out.println("  " + controller.getProduct(1L));

        // GET /products/99 (not found)
        System.out.println("\nGET /products/99 (not found):");
        System.out.println("  " + controller.getProduct(99L));

        // GET /products/category/Electronics
        System.out.println("\nGET /products/category/Electronics:");
        controller.getByCategory("Electronics").data().forEach(p -> System.out.println("  " + p));

        // POST /products
        System.out.println("\nPOST /products (create new):");
        ApiResponse<Product> created = tx.withTransaction(() ->
            controller.createProduct("Tablet", "Electronics", 35000, 25));
        System.out.println("  Created: " + created.data());

        // PUT /products/1/price
        System.out.println("\nPUT /products/1/price (update):");
        System.out.println("  " + controller.updatePrice(1L, 59999.0));

        // DELETE /products/5
        System.out.println("\nDELETE /products/5:");
        System.out.println("  " + controller.deleteProduct(5L));
        System.out.println("  After delete, count: " + controller.getAllProducts().data().size());

        // Category averages
        System.out.println("\nAverage price by category:");
        service.getAveragePriceByCategory().forEach((cat, avg) ->
            System.out.printf("  %-15s: Rs %.2f%n", cat, avg));

        // ============================================================
        System.out.println("\n=== SPRING BOOT KEY ANNOTATIONS ===");
        System.out.println("""
            @SpringBootApplication  : Main class entry point
            @RestController         : @Controller + @ResponseBody
            @GetMapping/@PostMapping: HTTP method mappings
            @RequestBody            : Deserialize JSON to object
            @PathVariable           : URL path parameter
            @RequestParam           : Query string parameter
            @Service                : Business logic layer
            @Repository             : Data access layer
            @Component              : Generic Spring component
            @Autowired              : Dependency injection
            @Value("${prop}")       : Inject property value
            @Configuration          : Java-based config class
            @Bean                   : Declare a Spring bean
            @Transactional          : Manage transactions
            @Aspect                 : AOP aspect class
            @Cacheable              : Cache method result
            @Scheduled              : Schedule tasks
            @Async                  : Async method execution
            @Valid / @NotNull       : Bean validation
            @ExceptionHandler       : Handle specific exceptions
            @ControllerAdvice       : Global exception handling
        """);

        System.out.println("=== COMMON application.properties ===");
        System.out.println("""
            server.port=8080
            spring.datasource.url=jdbc:mysql://localhost:3306/mydb
            spring.datasource.username=root
            spring.datasource.password=secret
            spring.jpa.hibernate.ddl-auto=update
            spring.jpa.show-sql=true
            logging.level.org.springframework=INFO
            spring.cache.type=redis
            spring.data.redis.host=localhost
            spring.data.redis.port=6379
            management.endpoints.web.exposure.include=health,info,metrics
        """);
    }
}
