/**
 * TOPIC 03: Control Flow - If-Else, Switch
 * ==========================================
 * Decision making: if, if-else, if-else-if ladder, switch
 * Enhanced switch (Java 14+): arrow syntax, yield
 * Pattern matching in switch (Java 21+)
 * Nested conditions, ternary shorthand
 */
public class IfElseSwitch {
    public static void main(String[] args) {

        // ============================================================
        // BASIC IF-ELSE
        // ============================================================
        System.out.println("=== IF-ELSE ===");
        int score = 78;
        if (score >= 90) {
            System.out.println("Grade: A (Excellent)");
        } else if (score >= 80) {
            System.out.println("Grade: B (Very Good)");
        } else if (score >= 70) {
            System.out.println("Grade: C (Good)");
        } else if (score >= 60) {
            System.out.println("Grade: D (Satisfactory)");
        } else {
            System.out.println("Grade: F (Failed)");
        }

        // Short form (no braces for single statement - NOT recommended)
        if (score > 50) System.out.println("Passed the exam");

        // ============================================================
        // NESTED IF
        // ============================================================
        System.out.println("\n=== NESTED IF ===");
        int age = 25; double salary = 75000;
        if (age >= 18) {
            if (salary >= 50000) {
                System.out.println("Eligible for premium credit card");
            } else {
                System.out.println("Eligible for basic credit card");
            }
        } else {
            System.out.println("Not eligible (age < 18)");
        }

        // ============================================================
        // TRADITIONAL SWITCH
        // ============================================================
        System.out.println("\n=== TRADITIONAL SWITCH ===");
        int month = 7;
        switch (month) {
            case 1:  System.out.println("January  - 31 days"); break;
            case 2:  System.out.println("February - 28/29 days"); break;
            case 3:  System.out.println("March    - 31 days"); break;
            case 4:  System.out.println("April    - 30 days"); break;
            case 5:  System.out.println("May      - 31 days"); break;
            case 6:  System.out.println("June     - 30 days"); break;
            case 7:  System.out.println("July     - 31 days"); break;
            case 8:  System.out.println("August   - 31 days"); break;
            case 9:  System.out.println("September- 30 days"); break;
            case 10: System.out.println("October  - 31 days"); break;
            case 11: System.out.println("November - 30 days"); break;
            case 12: System.out.println("December - 31 days"); break;
            default: System.out.println("Invalid month");
        }

        // Fall-through (intentional, no break)
        System.out.println("Quarter:");
        switch (month) {
            case 1: case 2: case 3:   System.out.println("Q1"); break;
            case 4: case 5: case 6:   System.out.println("Q2"); break;
            case 7: case 8: case 9:   System.out.println("Q3"); break;
            case 10: case 11: case 12:System.out.println("Q4"); break;
        }

        // Switch with String (Java 7+)
        String day = "WEDNESDAY";
        switch (day) {
            case "MONDAY": case "TUESDAY": case "WEDNESDAY":
            case "THURSDAY": case "FRIDAY":
                System.out.println(day + " = Weekday"); break;
            case "SATURDAY": case "SUNDAY":
                System.out.println(day + " = Weekend"); break;
            default:
                System.out.println("Invalid day");
        }

        // ============================================================
        // ENHANCED SWITCH (Java 14+)
        // ============================================================
        System.out.println("\n=== ENHANCED SWITCH (Java 14+) ===");
        int dayNum = 3;
        String dayName = switch (dayNum) {
            case 1 -> "Monday";
            case 2 -> "Tuesday";
            case 3 -> "Wednesday";
            case 4 -> "Thursday";
            case 5 -> "Friday";
            case 6 -> "Saturday";
            case 7 -> "Sunday";
            default -> throw new IllegalArgumentException("Invalid day: " + dayNum);
        };
        System.out.println("Day " + dayNum + " = " + dayName);

        // Enhanced switch with blocks and yield
        int num = 4;
        String category = switch (num) {
            case 1, 2, 3 -> "Low";
            case 4, 5, 6 -> {
                String s = num > 5 ? "High-Mid" : "Mid";
                yield s;           // yield returns value from block
            }
            case 7, 8, 9 -> "High";
            default -> "Out of range";
        };
        System.out.println("Category of " + num + ": " + category);

        // Switch as statement (not expression)
        switch (day) {
            case "SATURDAY", "SUNDAY" -> System.out.println("Weekend!");
            default -> System.out.println("Weekday!");
        }

        // ============================================================
        // REAL WORLD EXAMPLES
        // ============================================================
        System.out.println("\n=== REAL WORLD EXAMPLES ===");

        // Traffic light
        String light = "GREEN";
        String action = switch (light) {
            case "RED"    -> "STOP";
            case "YELLOW" -> "SLOW DOWN";
            case "GREEN"  -> "GO";
            default       -> "INVALID SIGNAL";
        };
        System.out.println("Light=" + light + " -> " + action);

        // BMI calculator
        double bmi = 22.5;
        String bmiCategory;
        if (bmi < 18.5)      bmiCategory = "Underweight";
        else if (bmi < 25.0) bmiCategory = "Normal weight";
        else if (bmi < 30.0) bmiCategory = "Overweight";
        else                 bmiCategory = "Obese";
        System.out.printf("BMI=%.1f -> %s%n", bmi, bmiCategory);

        // ATM operations
        int choice = 2;
        switch (choice) {
            case 1 -> System.out.println("Check Balance");
            case 2 -> System.out.println("Withdraw Cash");
            case 3 -> System.out.println("Deposit Cash");
            case 4 -> System.out.println("Transfer Funds");
            case 5 -> System.out.println("Exit");
            default -> System.out.println("Invalid option");
        }
    }
}
