/**
 * TOPIC 03: Loops - for, while, do-while, for-each
 * ==================================================
 * for      : known iteration count
 * while    : pre-check condition (may execute 0 times)
 * do-while : post-check condition (executes at least once)
 * for-each : iterate arrays/collections (no index)
 * break    : exit loop immediately
 * continue : skip to next iteration
 * labels   : named loops for multi-level break/continue
 */
import java.util.*;

public class Loops {
    public static void main(String[] args) {

        // ============================================================
        // FOR LOOP
        // ============================================================
        System.out.println("=== FOR LOOP ===");
        // Basic counting
        System.out.print("1 to 10: ");
        for (int i = 1; i <= 10; i++) System.out.print(i + " ");
        System.out.println();

        // Count down
        System.out.print("10 to 1: ");
        for (int i = 10; i >= 1; i--) System.out.print(i + " ");
        System.out.println();

        // Step by 2
        System.out.print("Even: ");
        for (int i = 2; i <= 20; i += 2) System.out.print(i + " ");
        System.out.println();

        // Multiple variables
        System.out.print("Two vars: ");
        for (int i = 0, j = 10; i < j; i++, j--) System.out.print("[" + i + "," + j + "] ");
        System.out.println();

        // Infinite loop pattern (uncomment to test - use break to exit)
        // for (;;) { ... break; }

        // ============================================================
        // WHILE LOOP
        // ============================================================
        System.out.println("\n=== WHILE LOOP ===");
        int n = 1;
        System.out.print("Powers of 2: ");
        while (n <= 1024) { System.out.print(n + " "); n *= 2; }
        System.out.println();

        // Digit sum using while
        int number = 12345;
        int sum = 0, temp = number;
        while (temp > 0) { sum += temp % 10; temp /= 10; }
        System.out.println("Sum of digits of " + number + " = " + sum);

        // Reverse a number
        int rev = 0; temp = 12345;
        while (temp > 0) { rev = rev * 10 + temp % 10; temp /= 10; }
        System.out.println("Reverse of 12345 = " + rev);

        // GCD using Euclid's algorithm
        int a = 48, b = 18;
        int aa = a, bb = b;
        while (bb != 0) { int t = bb; bb = aa % bb; aa = t; }
        System.out.println("GCD(" + a + "," + b + ") = " + aa);

        // ============================================================
        // DO-WHILE LOOP
        // ============================================================
        System.out.println("\n=== DO-WHILE LOOP ===");
        int x = 1;
        do {
            System.out.print(x + " ");
            x += 3;
        } while (x <= 20);
        System.out.println();

        // Key difference: do-while executes at least once
        int val = 100;
        System.out.print("do-while with val=100 (condition x<5): ");
        do {
            System.out.print(val + " ");
            val++;
        } while (val < 5);  // false from start, but runs once!
        System.out.println();

        // ============================================================
        // FOR-EACH (Enhanced for)
        // ============================================================
        System.out.println("\n=== FOR-EACH ===");
        int[] primes = {2, 3, 5, 7, 11, 13, 17, 19};
        int total = 0;
        for (int p : primes) { total += p; }
        System.out.println("Sum of primes: " + total);

        String[] fruits = {"Apple", "Banana", "Cherry", "Mango"};
        for (String fruit : fruits) System.out.print(fruit + " ");
        System.out.println();

        List<Integer> nums = Arrays.asList(10, 20, 30, 40, 50);
        int listSum = 0;
        for (int num : nums) listSum += num;
        System.out.println("List sum: " + listSum);

        // ============================================================
        // BREAK & CONTINUE
        // ============================================================
        System.out.println("\n=== BREAK & CONTINUE ===");
        System.out.print("Skip multiples of 3, stop at 15: ");
        for (int i = 1; i <= 20; i++) {
            if (i % 3 == 0) continue;  // skip
            if (i > 15)     break;     // stop
            System.out.print(i + " ");
        }
        System.out.println();

        // Find first element matching condition
        int[] data = {5, 12, 3, 18, 7, 25, 9};
        int target = -1;
        for (int d : data) {
            if (d > 15) { target = d; break; }
        }
        System.out.println("First element > 15: " + target);

        // ============================================================
        // LABELED BREAK / CONTINUE
        // ============================================================
        System.out.println("\n=== LABELED LOOPS ===");
        System.out.println("Labeled break (stop outer loop when i+j == 5):");
        outerLoop:
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (i + j == 5) break outerLoop;
                System.out.print("[" + i + "," + j + "] ");
            }
            System.out.println();
        }
        System.out.println();

        System.out.println("Labeled continue:");
        outer:
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                if (j == 2) continue outer;  // skip rest of inner, next outer iteration
                System.out.print("[" + i + "," + j + "] ");
            }
        }
        System.out.println();

        // ============================================================
        // PATTERNS & PUZZLES
        // ============================================================
        System.out.println("\n=== PATTERNS ===");

        // Right triangle
        for (int i = 1; i <= 5; i++) {
            for (int j = 1; j <= i; j++) System.out.print("* ");
            System.out.println();
        }

        // Diamond pattern
        System.out.println("Diamond:");
        int half = 4;
        for (int i = 1; i <= half; i++) {
            for (int s = half-i; s > 0; s--) System.out.print(" ");
            for (int j = 1; j <= 2*i-1; j++) System.out.print("*");
            System.out.println();
        }
        for (int i = half-1; i >= 1; i--) {
            for (int s = half-i; s > 0; s--) System.out.print(" ");
            for (int j = 1; j <= 2*i-1; j++) System.out.print("*");
            System.out.println();
        }

        // Multiplication table
        System.out.println("\n3x3 Multiplication Table:");
        for (int i = 1; i <= 3; i++) {
            for (int j = 1; j <= 3; j++) System.out.printf("%4d", i*j);
            System.out.println();
        }

        // Fibonacci using for loop
        System.out.print("\nFibonacci (first 10): ");
        long fib1 = 0, fib2 = 1;
        System.out.print(fib1 + " " + fib2 + " ");
        for (int i = 3; i <= 10; i++) {
            long next = fib1 + fib2;
            System.out.print(next + " ");
            fib1 = fib2; fib2 = next;
        }
        System.out.println();
    }
}
