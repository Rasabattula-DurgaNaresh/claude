/**
 * TOPIC 38: Regex & Date Formatting - Complete Reference
 * ========================================================
 * Regex: Pattern, Matcher, String.matches/replaceAll/split
 * Common patterns: email, phone, URL, IP, date, password
 * Date formatting: DateTimeFormatter, SimpleDateFormat (legacy)
 * Parsing: string -> date objects
 */
import java.util.regex.*;
import java.time.*;
import java.time.format.*;
import java.util.*;

public class RegexAndDateFormat {

    // ============================================================
    // COMMON REGEX PATTERNS
    // ============================================================
    static final String EMAIL_REGEX    = "^[a-zA-Z0-9._%+\\-]+@[a-zA-Z0-9.\\-]+\\.[a-zA-Z]{2,}$";
    static final String PHONE_REGEX    = "^(\\+91|0)?[789]\\d{9}$";
    static final String URL_REGEX      = "^(https?://)(www\\.)?[a-zA-Z0-9\\-\\.]+\\.[a-zA-Z]{2,}(/.*)?$";
    static final String IP_REGEX       = "^((25[0-5]|2[0-4]\\d|[01]?\\d\\d?)\\.){3}(25[0-5]|2[0-4]\\d|[01]?\\d\\d?)$";
    static final String DATE_REGEX     = "^(0[1-9]|[12]\\d|3[01])/(0[1-9]|1[0-2])/(19|20)\\d{2}$";
    static final String PASSWORD_REGEX = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$";
    static final String PINCODE_REGEX  = "^[1-9][0-9]{5}$";
    static final String PAN_REGEX      = "^[A-Z]{5}[0-9]{4}[A-Z]{1}$";
    static final String AADHAAR_REGEX  = "^[2-9]{1}[0-9]{11}$";

    static boolean matches(String pattern, String input) {
        return Pattern.matches(pattern, input);
    }

    public static void main(String[] args) {

        // ---- Email Validation ----
        System.out.println("=== EMAIL VALIDATION ===");
        String[] emails = {"alice@example.com","bad-email","alice.bob@co.in",
            "test+tag@domain.org","@nodomain.com","nodot@domaincom"};
        for (String e : emails)
            System.out.printf("  %-30s valid=%b%n", e, matches(EMAIL_REGEX, e));

        // ---- Phone Validation ----
        System.out.println("\n=== PHONE VALIDATION ===");
        String[] phones = {"+919876543210","09876543210","9876543210","1234567890","98765432"};
        for (String p : phones)
            System.out.printf("  %-20s valid=%b%n", p, matches(PHONE_REGEX, p));

        // ---- Password Strength ----
        System.out.println("\n=== PASSWORD VALIDATION ===");
        String[] passwords = {"weak","Str0ng@Pass","NoSpecial1","noUppercase1@","Short1@"};
        for (String pwd : passwords)
            System.out.printf("  %-20s valid=%b%n", pwd, matches(PASSWORD_REGEX, pwd));

        // ---- IP Address ----
        System.out.println("\n=== IP ADDRESS ===");
        String[] ips = {"192.168.1.1","256.1.1.1","0.0.0.0","10.0.0.1","999.999.999.999"};
        for (String ip : ips)
            System.out.printf("  %-20s valid=%b%n", ip, matches(IP_REGEX, ip));

        // ---- Pattern & Matcher (groups) ----
        System.out.println("\n=== PATTERN & MATCHER (GROUPS) ===");
        String text = "Contact: alice@test.com and bob@example.org for support@help.co.in";
        Pattern emailPat = Pattern.compile("[a-zA-Z0-9._%+\\-]+@[a-zA-Z0-9.\\-]+\\.[a-zA-Z]{2,}");
        Matcher m = emailPat.matcher(text);
        System.out.println("Emails found:");
        while (m.find()) System.out.println("  found: '" + m.group() + "' at [" + m.start() + "," + m.end() + ")");

        // Named groups
        System.out.println("\nNamed groups (date parsing):");
        Pattern datePat = Pattern.compile("(?<day>\\d{2})/(?<month>\\d{2})/(?<year>\\d{4})");
        String[] dates = {"25/12/2024","01/01/2025","15/08/1947"};
        for (String d : dates) {
            Matcher dm = datePat.matcher(d);
            if (dm.matches()) {
                System.out.printf("  %s -> day=%s month=%s year=%s%n",
                    d, dm.group("day"), dm.group("month"), dm.group("year"));
            }
        }

        // ---- Find and Replace ----
        System.out.println("\n=== FIND & REPLACE ===");
        String html = "<p>Hello <b>World</b>! Visit <a href='#'>here</a>.</p>";
        String stripped = html.replaceAll("<[^>]+>", "");
        System.out.println("Stripped HTML:  " + stripped);

        String csv = "Alice, 28 , Hyderabad , 95000";
        String normalized = csv.replaceAll("\\s*,\\s*", ",");
        System.out.println("Normalized CSV: " + normalized);

        String camel = "myVariableNameHere";
        String snake = camel.replaceAll("([A-Z])", "_$1").toLowerCase();
        System.out.println("camelToSnake:   " + snake);

        String redundant = "The  the  quick   brown    fox";
        String cleaned = redundant.replaceAll("\\s+", " ").trim();
        System.out.println("Clean spaces:   " + cleaned);

        // Mask credit card
        String card = "4111-1111-1111-1234";
        String masked = card.replaceAll("\\d(?=\\d{4})", "*");
        System.out.println("Masked card:    " + masked);

        // ---- Split with Regex ----
        System.out.println("\n=== SPLIT WITH REGEX ===");
        String data = "Alice:28:Hyderabad; Bob:35:Mumbai; Charlie:26:Delhi";
        String[] records = data.split(";\\s*");
        for (String rec : records) {
            String[] parts = rec.split(":");
            System.out.printf("  Name=%-10s Age=%-3s City=%s%n", parts[0], parts[1], parts[2]);
        }

        // ---- DATE-TIME FORMATTING ----
        System.out.println("\n=== DATE-TIME FORMATTING ===");
        LocalDateTime now = LocalDateTime.now();

        // Predefined formatters
        System.out.println("ISO_DATE:          " + now.format(DateTimeFormatter.ISO_DATE));
        System.out.println("ISO_DATE_TIME:     " + now.format(DateTimeFormatter.ISO_DATE_TIME));
        System.out.println("ISO_LOCAL_DATE_TIME:" + now.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));

        // Custom formatters
        DateTimeFormatter[] formatters = {
            DateTimeFormatter.ofPattern("dd/MM/yyyy"),
            DateTimeFormatter.ofPattern("MM-dd-yyyy"),
            DateTimeFormatter.ofPattern("dd MMM yyyy"),
            DateTimeFormatter.ofPattern("EEEE, dd MMMM yyyy"),
            DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"),
            DateTimeFormatter.ofPattern("hh:mm a, dd-MMM-yyyy"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"),
        };
        String[] labels = {"dd/MM/yyyy","MM-dd-yyyy","dd MMM yyyy","Full","With time","12-hour","ISO-like"};
        for (int i = 0; i < formatters.length; i++) {
            System.out.printf("  %-20s: %s%n", labels[i], now.format(formatters[i]));
        }

        // ---- DATE PARSING ----
        System.out.println("\n=== DATE PARSING ===");
        String[] dateToParse = {"25/12/2024","01 Jan 2025","2024-06-15","Monday, 25 December 2023"};
        DateTimeFormatter[] parsers = {
            DateTimeFormatter.ofPattern("dd/MM/yyyy"),
            DateTimeFormatter.ofPattern("dd MMM yyyy"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd"),
            DateTimeFormatter.ofPattern("EEEE, dd MMMM yyyy"),
        };
        for (int i = 0; i < dateToParse.length; i++) {
            LocalDate parsed = LocalDate.parse(dateToParse[i], parsers[i]);
            System.out.printf("  %-35s -> %s (%s)%n", dateToParse[i], parsed, parsed.getDayOfWeek());
        }

        // ---- DATE ARITHMETIC ----
        System.out.println("\n=== DATE ARITHMETIC ===");
        LocalDate today = LocalDate.now();
        System.out.println("Today:         " + today);
        System.out.println("+7 days:       " + today.plusDays(7));
        System.out.println("+3 months:     " + today.plusMonths(3));
        System.out.println("-1 year:       " + today.minusYears(1));
        System.out.println("Day of week:   " + today.getDayOfWeek());
        System.out.println("Day of year:   " + today.getDayOfYear());
        System.out.println("Is leap year:  " + today.isLeapYear());

        LocalDate dob = LocalDate.of(1995, 6, 15);
        Period age = Period.between(dob, today);
        System.out.printf("Age (DOB 1995-06-15): %d years, %d months, %d days%n",
            age.getYears(), age.getMonths(), age.getDays());

        // Days between two dates
        long daysBetween = java.time.temporal.ChronoUnit.DAYS.between(dob, today);
        System.out.println("Days since DOB: " + daysBetween);

        // Timezone conversion
        System.out.println("\n=== TIMEZONE CONVERSION ===");
        ZonedDateTime ist = ZonedDateTime.now(ZoneId.of("Asia/Kolkata"));
        ZonedDateTime utc = ist.withZoneSameInstant(ZoneId.of("UTC"));
        ZonedDateTime ny  = ist.withZoneSameInstant(ZoneId.of("America/New_York"));
        ZonedDateTime lon = ist.withZoneSameInstant(ZoneId.of("Europe/London"));
        DateTimeFormatter tz = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss z");
        System.out.println("IST: " + ist.format(tz));
        System.out.println("UTC: " + utc.format(tz));
        System.out.println("NY:  " + ny.format(tz));
        System.out.println("LON: " + lon.format(tz));
    }
}
