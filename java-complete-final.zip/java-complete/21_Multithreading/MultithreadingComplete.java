/**
 * TOPIC 21: Multithreading - Complete Reference
 * ===============================================
 * Thread creation: extends Thread OR implements Runnable OR Callable
 * Thread states: NEW -> RUNNABLE -> BLOCKED/WAITING/TIMED_WAITING -> TERMINATED
 * synchronized: mutual exclusion (method or block)
 * volatile: visibility guarantee (no caching in registers)
 * wait/notify/notifyAll: inter-thread communication
 * ExecutorService: thread pool management
 * Future/CompletableFuture: async result handling
 * Atomic classes: lock-free thread-safe operations
 * CountDownLatch, CyclicBarrier, Semaphore: coordination
 */
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.concurrent.locks.*;

public class MultithreadingComplete {

    // ============================================================
    // THREAD CREATION - 3 WAYS
    // ============================================================
    // 1. Extending Thread
    static class MyThread extends Thread {
        private final String taskName;
        public MyThread(String name) { super(name); this.taskName = name; }
        @Override public void run() {
            for (int i = 1; i <= 3; i++) {
                System.out.printf("  [%s] step %d%n", taskName, i);
                try { Thread.sleep(50); } catch (InterruptedException e) { Thread.currentThread().interrupt(); return; }
            }
        }
    }

    // 2. Implementing Runnable
    static class MyRunnable implements Runnable {
        private final String name;
        public MyRunnable(String name) { this.name = name; }
        @Override public void run() {
            System.out.printf("  [Runnable:%s] running on %s%n", name, Thread.currentThread().getName());
        }
    }

    // 3. Callable (returns value, can throw)
    static class MyCallable implements Callable<Integer> {
        private final int n;
        public MyCallable(int n) { this.n = n; }
        @Override public Integer call() throws Exception {
            Thread.sleep(100);
            return n * n;
        }
    }

    // ============================================================
    // SYNCHRONIZED COUNTER
    // ============================================================
    static class Counter {
        private int count = 0;

        public synchronized void increment() { count++; }
        public synchronized void decrement() { count--; }
        public synchronized int  getCount()  { return count; }

        // Block-level sync (finer granularity)
        public void incrementBlock() {
            synchronized (this) { count++; }
        }
    }

    // ============================================================
    // PRODUCER-CONSUMER (wait/notify)
    // ============================================================
    static class SharedBuffer {
        private final Queue<Integer> buffer = new LinkedList<>();
        private final int MAX_SIZE;

        public SharedBuffer(int max) { this.MAX_SIZE = max; }

        public synchronized void produce(int value) throws InterruptedException {
            while (buffer.size() == MAX_SIZE) {
                System.out.println("  Buffer full! Producer waiting...");
                wait();
            }
            buffer.add(value);
            System.out.println("  Produced: " + value + " | buffer=" + buffer.size());
            notifyAll();
        }

        public synchronized int consume() throws InterruptedException {
            while (buffer.isEmpty()) {
                System.out.println("  Buffer empty! Consumer waiting...");
                wait();
            }
            int val = buffer.poll();
            System.out.println("  Consumed: " + val + " | buffer=" + buffer.size());
            notifyAll();
            return val;
        }
    }

    // ============================================================
    // REENTRANT LOCK
    // ============================================================
    static class BankAccountLocked {
        private double balance;
        private final ReentrantLock lock = new ReentrantLock();

        public BankAccountLocked(double initial) { balance = initial; }

        public boolean transfer(BankAccountLocked target, double amount) {
            // Acquire both locks in consistent order (by hash to prevent deadlock)
            ReentrantLock firstLock  = System.identityHashCode(this) < System.identityHashCode(target) ? lock : target.lock;
            ReentrantLock secondLock = firstLock == lock ? target.lock : lock;

            firstLock.lock();
            try {
                secondLock.lock();
                try {
                    if (balance < amount) return false;
                    balance -= amount;
                    target.balance += amount;
                    System.out.printf("  Transferred %.0f | this=%.0f target=%.0f%n", amount, balance, target.balance);
                    return true;
                } finally { secondLock.unlock(); }
            } finally { firstLock.unlock(); }
        }

        public double getBalance() { return balance; }
    }

    public static void main(String[] args) throws Exception {

        // ============================================================
        // 1. BASIC THREAD CREATION
        // ============================================================
        System.out.println("=== THREAD CREATION ===");

        // extends Thread
        MyThread t1 = new MyThread("Task-A");
        MyThread t2 = new MyThread("Task-B");
        t1.start(); t2.start();
        t1.join(); t2.join();

        // Runnable with Thread
        Thread rt = new Thread(new MyRunnable("R1"), "RunnerThread");
        rt.start(); rt.join();

        // Lambda Runnable (most common)
        Thread lt = new Thread(() -> System.out.println("  [Lambda] on " + Thread.currentThread().getName()));
        lt.start(); lt.join();

        System.out.println("Thread.currentThread(): " + Thread.currentThread().getName());
        System.out.println("Available processors:   " + Runtime.getRuntime().availableProcessors());

        // ============================================================
        // 2. THREAD PROPERTIES
        // ============================================================
        System.out.println("\n=== THREAD PROPERTIES ===");
        Thread demo = new Thread(() -> {}, "DemoThread");
        demo.setDaemon(false);
        demo.setPriority(Thread.MAX_PRIORITY);
        System.out.println("Name:     " + demo.getName());
        System.out.println("Priority: " + demo.getPriority() + " (MAX=" + Thread.MAX_PRIORITY + ")");
        System.out.println("Daemon:   " + demo.isDaemon());
        System.out.println("State:    " + demo.getState()); // NEW
        demo.start();
        demo.join();
        System.out.println("State after join: " + demo.getState()); // TERMINATED

        // ============================================================
        // 3. RACE CONDITION & SYNCHRONIZATION
        // ============================================================
        System.out.println("\n=== SYNCHRONIZATION ===");
        Counter syncCounter = new Counter();
        List<Thread> threads = new ArrayList<>();

        for (int i = 0; i < 10; i++) {
            Thread th = new Thread(() -> {
                for (int j = 0; j < 1000; j++) syncCounter.increment();
            });
            threads.add(th); th.start();
        }
        for (Thread th : threads) th.join();
        System.out.println("Expected: 10000 | Got: " + syncCounter.getCount());

        // ============================================================
        // 4. EXECUTOR SERVICE
        // ============================================================
        System.out.println("\n=== EXECUTOR SERVICE ===");

        // Fixed thread pool
        ExecutorService fixed = Executors.newFixedThreadPool(3);
        for (int i = 1; i <= 6; i++) {
            final int taskId = i;
            fixed.submit(() -> {
                System.out.printf("  Task-%d on %s%n", taskId, Thread.currentThread().getName());
                Thread.sleep(50);
                return taskId;
            });
        }
        fixed.shutdown();
        fixed.awaitTermination(5, TimeUnit.SECONDS);

        // Callable with Future
        ExecutorService pool = Executors.newFixedThreadPool(4);
        List<Future<Integer>> futures = new ArrayList<>();
        for (int i = 1; i <= 8; i++) {
            futures.add(pool.submit(new MyCallable(i)));
        }
        System.out.print("Squares: ");
        for (Future<Integer> f : futures) System.out.print(f.get() + " ");
        System.out.println();
        pool.shutdown();

        // ============================================================
        // 5. ATOMIC VARIABLES
        // ============================================================
        System.out.println("\n=== ATOMIC VARIABLES ===");
        AtomicInteger atomicCount = new AtomicInteger(0);
        AtomicLong    atomicLong  = new AtomicLong(0L);
        AtomicBoolean atomicBool  = new AtomicBoolean(false);

        ExecutorService atomicPool = Executors.newFixedThreadPool(5);
        CountDownLatch latch = new CountDownLatch(10);
        for (int i = 0; i < 10; i++) {
            atomicPool.submit(() -> {
                for (int j = 0; j < 1000; j++) atomicCount.incrementAndGet();
                latch.countDown();
            });
        }
        latch.await();
        atomicPool.shutdown();
        System.out.println("AtomicInteger (10x1000): " + atomicCount.get());

        AtomicInteger ref = new AtomicInteger(10);
        System.out.println("compareAndSet(10,20): " + ref.compareAndSet(10, 20) + " -> " + ref.get());
        System.out.println("compareAndSet(10,30): " + ref.compareAndSet(10, 30) + " -> " + ref.get());
        System.out.println("getAndIncrement: " + ref.getAndIncrement() + " -> " + ref.get());
        System.out.println("addAndGet(5):    " + ref.addAndGet(5));

        // ============================================================
        // 6. COMPLETABLE FUTURE
        // ============================================================
        System.out.println("\n=== COMPLETABLE FUTURE ===");
        CompletableFuture<String> cf1 = CompletableFuture.supplyAsync(() -> {
            try { Thread.sleep(100); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            return "Hello";
        });

        CompletableFuture<String> cf2 = cf1
            .thenApply(s -> s + " World")
            .thenApply(String::toUpperCase);

        System.out.println("CF result: " + cf2.get());

        // Combining futures
        CompletableFuture<Integer> f1 = CompletableFuture.supplyAsync(() -> 10);
        CompletableFuture<Integer> f2 = CompletableFuture.supplyAsync(() -> 20);
        CompletableFuture<Integer> combined = f1.thenCombine(f2, Integer::sum);
        System.out.println("Combined futures: " + combined.get());

        // allOf / anyOf
        CompletableFuture<Void> allDone = CompletableFuture.allOf(f1, f2);
        allDone.get();
        System.out.println("allOf completed");

        // Exception handling
        CompletableFuture<String> failCF = CompletableFuture
            .supplyAsync(() -> { throw new RuntimeException("Oops"); })
            .exceptionally(ex -> "Recovered: " + ex.getMessage());
        System.out.println("exceptionally: " + failCF.get());

        // ============================================================
        // 7. COUNTDOWN LATCH & CYCLIC BARRIER
        // ============================================================
        System.out.println("\n=== COUNTDOWN LATCH ===");
        CountDownLatch startGun = new CountDownLatch(1);
        CountDownLatch finished = new CountDownLatch(3);

        for (int i = 1; i <= 3; i++) {
            final int runner = i;
            new Thread(() -> {
                try {
                    startGun.await(); // all wait for start
                    System.out.println("  Runner " + runner + " started!");
                    Thread.sleep((long)(Math.random() * 200));
                    System.out.println("  Runner " + runner + " finished!");
                    finished.countDown();
                } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            }).start();
        }
        System.out.println("Ready... Set... GO!");
        startGun.countDown();  // release all
        finished.await();      // wait for all to finish
        System.out.println("Race complete!");

        // ============================================================
        // 8. SEMAPHORE (connection pool)
        // ============================================================
        System.out.println("\n=== SEMAPHORE ===");
        Semaphore semaphore = new Semaphore(3); // max 3 concurrent
        ExecutorService semPool = Executors.newFixedThreadPool(6);
        CountDownLatch semLatch = new CountDownLatch(6);

        for (int i = 1; i <= 6; i++) {
            final int taskNum = i;
            semPool.submit(() -> {
                try {
                    semaphore.acquire();
                    System.out.printf("  Task %d acquired permit (available: %d)%n",
                        taskNum, semaphore.availablePermits());
                    Thread.sleep(100);
                    semaphore.release();
                    System.out.printf("  Task %d released (available: %d)%n",
                        taskNum, semaphore.availablePermits());
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                } finally { semLatch.countDown(); }
            });
        }
        semLatch.await();
        semPool.shutdown();

        System.out.println("\nMultithreading examples complete!");
    }
}
