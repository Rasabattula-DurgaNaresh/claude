/**
 * TOPIC 14: Collections - List Interface Complete
 * =================================================
 * List: ordered, allows duplicates, index-based
 *
 * ArrayList  : O(1) get/set, O(n) insert/delete, backed by array
 * LinkedList : O(1) add/remove at ends, O(n) get, doubly-linked
 * CopyOnWriteArrayList : thread-safe ArrayList (reads don't lock)
 * Collections utility : sort, binarySearch, reverse, shuffle, etc.
 * List.of() : immutable list (Java 9+)
 */
import java.util.*;
import java.util.stream.*;

public class CollectionsListComplete {

    record Person(String name, int age, String city, double salary) {
        @Override public String toString() {
            return String.format("Person{%-10s age=%-2d city=%-12s salary=%.0f}", name, age, city, salary);
        }
    }

    public static void main(String[] args) {

        // ============================================================
        // ARRAYLIST - COMPLETE OPERATIONS
        // ============================================================
        System.out.println("=== ARRAYLIST ===");
        List<String> list = new ArrayList<>();

        // Adding
        list.add("Cherry");
        list.add("Apple");
        list.add("Banana");
        list.add(0, "Avocado");                  // at index
        list.addAll(Arrays.asList("Date", "Fig")); // add collection
        list.addAll(2, Arrays.asList("X", "Y"));  // add collection at index
        System.out.println("After adds: " + list);
        System.out.println("Size: " + list.size() + " | Is empty: " + list.isEmpty());

        // Accessing
        System.out.println("get(0): " + list.get(0));
        System.out.println("indexOf(\"Apple\"): " + list.indexOf("Apple"));
        System.out.println("lastIndexOf: " + list.lastIndexOf("X"));
        System.out.println("contains: " + list.contains("Banana"));
        System.out.println("subList(1,4): " + list.subList(1, 4));

        // Modifying
        list.set(0, "Apricot");           // replace at index
        list.remove("X");                  // remove by value
        list.remove(1);                   // remove by index
        list.removeIf(s -> s.length() < 4); // remove if condition
        System.out.println("After modify: " + list);

        // Sorting
        list.add("Mango"); list.add("Kiwi"); list.add("Lemon");
        Collections.sort(list);
        System.out.println("Sorted: " + list);
        list.sort(Comparator.comparingInt(String::length));
        System.out.println("By length: " + list);
        list.sort(Comparator.comparingInt(String::length).thenComparing(Comparator.naturalOrder()));
        System.out.println("By length then alpha: " + list);

        // Searching
        Collections.sort(list);
        int idx = Collections.binarySearch(list, "Lemon");
        System.out.println("binarySearch(Lemon): " + idx);

        // ============================================================
        // LINKEDLIST AS LIST, QUEUE, AND DEQUE
        // ============================================================
        System.out.println("\n=== LINKEDLIST ===");
        LinkedList<Integer> linked = new LinkedList<>(Arrays.asList(1, 2, 3, 4, 5));

        // As List
        linked.add(6);
        linked.add(0, 0);
        System.out.println("As List: " + linked);

        // As Deque (double-ended queue)
        linked.addFirst(100); linked.addLast(200);
        System.out.println("After addFirst/Last: " + linked);
        System.out.println("peekFirst: " + linked.peekFirst() + " | peekLast: " + linked.peekLast());
        linked.pollFirst(); linked.pollLast();
        System.out.println("After pollFirst/Last: " + linked);

        // As Stack
        LinkedList<String> stack = new LinkedList<>();
        stack.push("first"); stack.push("second"); stack.push("third");
        System.out.println("Stack: " + stack);
        System.out.println("pop: " + stack.pop() + " | Stack: " + stack);

        // As Queue
        Queue<String> queue = new LinkedList<>(Arrays.asList("A", "B", "C"));
        System.out.println("Queue: " + queue);
        System.out.println("peek: " + queue.peek() + " | poll: " + queue.poll());
        System.out.println("Queue after poll: " + queue);

        // ============================================================
        // COLLECTIONS UTILITY CLASS
        // ============================================================
        System.out.println("\n=== COLLECTIONS UTILITY ===");
        List<Integer> nums = new ArrayList<>(Arrays.asList(3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5));
        System.out.println("Original:       " + nums);

        Collections.sort(nums);
        System.out.println("sort:           " + nums);

        Collections.reverse(nums);
        System.out.println("reverse:        " + nums);

        Collections.shuffle(nums, new Random(42));
        System.out.println("shuffle(seed42):" + nums);

        System.out.println("max:            " + Collections.max(nums));
        System.out.println("min:            " + Collections.min(nums));
        System.out.println("frequency(5):   " + Collections.frequency(nums, 5));

        List<Integer> filled = new ArrayList<>(Collections.nCopies(5, 0));
        System.out.println("nCopies(5,0):   " + filled);

        Collections.fill(filled, 7);
        System.out.println("fill(7):        " + filled);

        Collections.sort(nums);
        int bsIdx = Collections.binarySearch(nums, 5);
        System.out.println("binarySearch(5):" + bsIdx);

        Collections.swap(nums, 0, nums.size()-1);
        System.out.println("swap(0,last):   " + nums);

        Collections.rotate(nums, 2);
        System.out.println("rotate(2):      " + nums);

        List<Integer> syncList = Collections.synchronizedList(new ArrayList<>(nums));
        List<Integer> unmodList = Collections.unmodifiableList(nums);
        System.out.println("Synchronized and Unmodifiable lists created");

        // disjoint: true if no common elements
        List<Integer> setA = Arrays.asList(1, 2, 3);
        List<Integer> setB = Arrays.asList(4, 5, 6);
        List<Integer> setC = Arrays.asList(3, 4, 5);
        System.out.println("disjoint(A,B):  " + Collections.disjoint(setA, setB));  // true
        System.out.println("disjoint(A,C):  " + Collections.disjoint(setA, setC));  // false

        // ============================================================
        // LIST WITH CUSTOM OBJECTS
        // ============================================================
        System.out.println("\n=== LIST WITH OBJECTS ===");
        List<Person> people = new ArrayList<>(Arrays.asList(
            new Person("Charlie", 30, "Hyderabad",  75000),
            new Person("Alice",   25, "Mumbai",     95000),
            new Person("Bob",     35, "Delhi",      85000),
            new Person("Diana",   28, "Bangalore",  110000),
            new Person("Eve",     22, "Hyderabad",  65000)
        ));

        // Sort by different fields
        people.sort(Comparator.comparing(Person::name));
        System.out.println("By name:");
        people.forEach(p -> System.out.println("  " + p));

        people.sort(Comparator.comparingDouble(Person::salary).reversed());
        System.out.println("\nBy salary desc:");
        people.forEach(p -> System.out.println("  " + p));

        // Filter, map, collect (Streams)
        List<String> hydPeople = people.stream()
            .filter(p -> p.city().equals("Hyderabad"))
            .map(Person::name)
            .sorted()
            .collect(Collectors.toList());
        System.out.println("\nHyderabad residents: " + hydPeople);

        // ============================================================
        // IMMUTABLE LISTS (Java 9+)
        // ============================================================
        System.out.println("\n=== IMMUTABLE LISTS (Java 9+) ===");
        List<String> immutable1 = List.of("A", "B", "C");
        List<String> immutable2 = List.copyOf(immutable1);
        List<String> mutable    = new ArrayList<>(immutable1);  // mutable copy
        mutable.add("D");
        System.out.println("List.of:   " + immutable1);
        System.out.println("copyOf:    " + immutable2);
        System.out.println("mutable:   " + mutable);
        try { immutable1.add("X"); }
        catch (UnsupportedOperationException e) { System.out.println("List.of is immutable!"); }

        // ============================================================
        // PERFORMANCE COMPARISON
        // ============================================================
        System.out.println("\n=== PERFORMANCE ===");
        int N = 100000;
        // ArrayList: O(n) insertion at beginning
        List<Integer> arrayList = new ArrayList<>();
        long t1 = System.currentTimeMillis();
        for (int i = 0; i < N; i++) arrayList.add(0, i);  // always at front
        System.out.println("ArrayList.add(0,i) x" + N + ": " + (System.currentTimeMillis()-t1) + "ms");

        // LinkedList: O(1) insertion at beginning
        List<Integer> linkedList = new LinkedList<>();
        long t2 = System.currentTimeMillis();
        for (int i = 0; i < N; i++) ((LinkedList<Integer>)linkedList).addFirst(i);
        System.out.println("LinkedList.addFirst x" + N + ": " + (System.currentTimeMillis()-t2) + "ms");

        // ArrayList: O(1) random access
        long t3 = System.currentTimeMillis();
        for (int i = 0; i < N; i++) arrayList.get(i % arrayList.size());
        System.out.println("ArrayList.get x" + N + ":  " + (System.currentTimeMillis()-t3) + "ms");
    }
}
