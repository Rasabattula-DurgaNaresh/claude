/**
 * TOPIC 19: Lambda Expressions - Complete Reference
 * ===================================================
 * Lambda = anonymous function: (params) -> body
 * Requires a @FunctionalInterface (single abstract method)
 *
 * Built-in functional interfaces (java.util.function):
 *   Predicate<T>        : T -> boolean
 *   Function<T,R>       : T -> R
 *   BiFunction<T,U,R>   : T,U -> R
 *   Consumer<T>         : T -> void
 *   Supplier<T>         : () -> T
 *   UnaryOperator<T>    : T -> T
 *   BinaryOperator<T>   : T,T -> T
 *   Runnable            : () -> void
 *   Callable<V>         : () -> V (throws Exception)
 *
 * Method references: Class::method or obj::method
 */
import java.util.*;
import java.util.function.*;
import java.util.stream.*;

public class LambdasComplete {

    @FunctionalInterface interface TriFunction<A,B,C,R> { R apply(A a, B b, C c); }
    @FunctionalInterface interface ThrowingSupplier<T> { T get() throws Exception; }
    @FunctionalInterface interface StringTransformer { String transform(String s); }

    record Person(String name, int age, String city, double salary) {}

    public static void main(String[] args) {

        // ============================================================
        // LAMBDA SYNTAX FORMS
        // ============================================================
        System.out.println("=== LAMBDA SYNTAX FORMS ===");

        // No params
        Runnable r1 = () -> System.out.println("No params lambda");
        r1.run();

        // One param (parens optional)
        Consumer<String> c1 = s -> System.out.println("Single param: " + s);
        Consumer<String> c2 = (String s) -> System.out.println("Typed param: " + s);
        c1.accept("hello"); c2.accept("world");

        // Two params
        BiFunction<Integer,Integer,Integer> add = (a, b) -> a + b;
        System.out.println("BiFunction add: " + add.apply(3, 4));

        // Block body (multiple statements)
        Function<Integer, String> classify = n -> {
            if (n < 0)   return "negative";
            if (n == 0)  return "zero";
            if (n < 10)  return "small";
            if (n < 100) return "medium";
            return "large";
        };
        int[] testNums = {-5, 0, 7, 42, 500};
        for (int n : testNums) System.out.println("  " + n + " -> " + classify.apply(n));

        // ============================================================
        // PREDICATE
        // ============================================================
        System.out.println("\n=== PREDICATE ===");
        Predicate<Integer> isEven    = n -> n % 2 == 0;
        Predicate<Integer> isPositive= n -> n > 0;
        Predicate<Integer> gt10      = n -> n > 10;
        Predicate<String>  notEmpty  = s -> !s.isBlank();
        Predicate<String>  hasAt     = s -> s.contains("@");
        Predicate<String>  emailValid= notEmpty.and(hasAt).and(s -> s.contains("."));

        System.out.println("isEven(4):        " + isEven.test(4));
        System.out.println("isEven.negate(4): " + isEven.negate().test(4));
        System.out.println("isEven.and(gt10)(12): " + isEven.and(gt10).test(12));
        System.out.println("isEven.or(isPositive)(3): " + isEven.or(isPositive).test(3));

        List<String> emails = Arrays.asList("alice@test.com", "bad-email", "", "bob@example.org", "no-dot@com");
        System.out.println("Valid emails: " + emails.stream().filter(emailValid).collect(Collectors.toList()));

        // BiPredicate
        BiPredicate<String, Integer> longerThan = (s, n) -> s.length() > n;
        System.out.println("longerThan(Hello, 3): " + longerThan.test("Hello", 3));

        // ============================================================
        // FUNCTION & COMPOSITION
        // ============================================================
        System.out.println("\n=== FUNCTION & COMPOSITION ===");
        Function<String, Integer> strLen = String::length;
        Function<Integer, Boolean> isEvenFn = n -> n % 2 == 0;
        Function<String, Boolean> strLenIsEven = strLen.andThen(isEvenFn);

        Function<Integer, Integer> times2 = n -> n * 2;
        Function<Integer, Integer> plus10  = n -> n + 10;
        Function<Integer, Integer> times2ThenPlus10 = times2.andThen(plus10);
        Function<Integer, Integer> plus10ThenTimes2 = times2.compose(plus10); // compose runs arg first

        System.out.println("andThen (3->*2->+10): " + times2ThenPlus10.apply(3));  // 16
        System.out.println("compose (3->+10->*2): " + plus10ThenTimes2.apply(3));  // 26
        System.out.println("strLenIsEven(Hello):  " + strLenIsEven.apply("Hello")); // false (5 is odd)
        System.out.println("strLenIsEven(Java!):  " + strLenIsEven.apply("Java!"));  // true (5 is odd)

        // UnaryOperator
        UnaryOperator<String> shout     = s -> s.toUpperCase() + "!";
        UnaryOperator<String> addBraces = s -> "[" + s + "]";
        UnaryOperator<String> pipeline  = shout.andThen(addBraces);
        System.out.println("pipeline(hello): " + pipeline.apply("hello")); // [HELLO!]

        // BinaryOperator
        BinaryOperator<Integer> multiply = (a, b) -> a * b;
        BinaryOperator<String>  longest  = (a, b) -> a.length() >= b.length() ? a : b;
        System.out.println("multiply(6,7): " + multiply.apply(6, 7));
        System.out.println("longest(apple, banana): " + longest.apply("apple", "banana"));

        // ============================================================
        // CONSUMER & SUPPLIER
        // ============================================================
        System.out.println("\n=== CONSUMER & SUPPLIER ===");
        Consumer<String>  printer  = System.out::println;
        Consumer<String>  logger   = s -> System.out.println("[LOG] " + s);
        Consumer<String>  combined = printer.andThen(logger);
        combined.accept("Hello Consumer!");

        BiConsumer<String, Integer> printEntry = (k, v) -> System.out.printf("  %s -> %d%n", k, v);
        Map.of("A",1,"B",2,"C",3).forEach(printEntry);

        Supplier<List<String>> listFactory  = ArrayList::new;
        Supplier<Double>       randomPrice  = () -> Math.round(Math.random() * 9900 + 100) / 100.0;
        Supplier<String>       uuidSupplier = () -> java.util.UUID.randomUUID().toString();

        List<String> newList = listFactory.get(); newList.add("hello");
        System.out.println("Supplier list: " + newList);
        System.out.println("Random price:  " + randomPrice.get());
        System.out.println("UUID:          " + uuidSupplier.get());

        // ============================================================
        // CUSTOM FUNCTIONAL INTERFACES
        // ============================================================
        System.out.println("\n=== CUSTOM FUNCTIONAL INTERFACES ===");
        TriFunction<Integer,Integer,Integer,Integer> triAdd = (a, b, c) -> a + b + c;
        System.out.println("triAdd(1,2,3): " + triAdd.apply(1,2,3));

        StringTransformer camelToSnake = s ->
            s.replaceAll("([A-Z])", "_$1").toLowerCase().replaceAll("^_","");
        System.out.println("camelToSnake(helloWorld): " + camelToSnake.transform("helloWorld"));
        System.out.println("camelToSnake(myVariableName): " + camelToSnake.transform("myVariableName"));

        // ============================================================
        // METHOD REFERENCES
        // ============================================================
        System.out.println("\n=== METHOD REFERENCES ===");
        // 1. Static method reference: Class::staticMethod
        Function<String, Integer> parseInt1 = s -> Integer.parseInt(s);
        Function<String, Integer> parseInt2 = Integer::parseInt;  // method ref
        System.out.println("parseInt (lambda): " + parseInt1.apply("42"));
        System.out.println("parseInt (method ref): " + parseInt2.apply("42"));

        // 2. Instance method of arbitrary instance: Class::instanceMethod
        Function<String, String> toUpper1 = s -> s.toUpperCase();
        Function<String, String> toUpper2 = String::toUpperCase;  // method ref
        System.out.println("toUpper: " + toUpper2.apply("hello"));

        Predicate<String> isEmpty = String::isEmpty;
        System.out.println("isEmpty: " + isEmpty.test(""));

        // 3. Instance method of specific instance: obj::method
        String prefix = "Hello, ";
        Function<String, String> greet = prefix::concat;
        System.out.println("greet: " + greet.apply("Alice"));

        // 4. Constructor reference: Class::new
        Function<String, StringBuilder> sbFactory = StringBuilder::new;
        StringBuilder sb = sbFactory.apply("initial content");
        System.out.println("Constructor ref: " + sb);

        BiFunction<String,Integer,String> padded = (s,n) -> s + " ".repeat(n);
        System.out.println("BiFunction: " + padded.apply("hi", 3) + "|");

        // ============================================================
        // PRACTICAL: PIPELINE PATTERN
        // ============================================================
        System.out.println("\n=== PIPELINE PATTERN ===");
        List<String> rawData = Arrays.asList("  alice  ", "BOB", "", "  charlie", "dave  ", null, "EVE");

        List<String> processed = rawData.stream()
            .filter(Objects::nonNull)
            .map(String::trim)
            .filter(s -> !s.isEmpty())
            .map(s -> s.substring(0,1).toUpperCase() + s.substring(1).toLowerCase())
            .sorted()
            .collect(Collectors.toList());
        System.out.println("Processed: " + processed);

        // ============================================================
        // PRACTICAL: STRATEGY PATTERN WITH LAMBDAS
        // ============================================================
        System.out.println("\n=== STRATEGY PATTERN ===");
        List<Person> people = Arrays.asList(
            new Person("Charlie", 30, "Hyderabad", 75000),
            new Person("Alice",   25, "Mumbai",    95000),
            new Person("Bob",     35, "Delhi",     85000),
            new Person("Diana",   28, "Bangalore", 110000)
        );

        // Sorting strategies
        Comparator<Person> byName   = Comparator.comparing(Person::name);
        Comparator<Person> byAge    = Comparator.comparingInt(Person::age);
        Comparator<Person> bySalary = Comparator.comparingDouble(Person::salary).reversed();
        Comparator<Person> complex  = bySalary.thenComparing(byAge).thenComparing(byName);

        System.out.println("By salary desc:");
        people.stream().sorted(bySalary)
            .forEach(p -> System.out.printf("  %-10s age=%-2d salary=%.0f%n", p.name(), p.age(), p.salary()));

        // Filtering strategies
        Predicate<Person> youngFilter   = p -> p.age() < 30;
        Predicate<Person> highPayFilter = p -> p.salary() > 80000;
        System.out.println("Young & high pay: " + people.stream()
            .filter(youngFilter.and(highPayFilter))
            .map(Person::name).collect(Collectors.toList()));

        // ============================================================
        // CURRYING & PARTIAL APPLICATION
        // ============================================================
        System.out.println("\n=== CURRYING ===");
        Function<Integer, Function<Integer, Integer>> curriedAdd = a -> b -> a + b;
        Function<Integer, Integer> add5 = curriedAdd.apply(5);  // partial application
        System.out.println("add5(3):  " + add5.apply(3));   // 8
        System.out.println("add5(10): " + add5.apply(10));  // 15

        Function<String, Function<String, String>> concat = a -> b -> a + b;
        Function<String, String> hello = concat.apply("Hello, ");
        System.out.println(hello.apply("World!"));
        System.out.println(hello.apply("Java!"));

        System.out.println("\nLambda examples complete!");
    }
}
