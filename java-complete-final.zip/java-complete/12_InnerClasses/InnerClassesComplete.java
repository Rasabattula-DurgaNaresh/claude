/**
 * TOPIC 12: Inner Classes - All Types
 * =====================================
 * 1. Member Inner Class   : non-static, has access to outer class
 * 2. Static Nested Class  : static, no outer instance needed
 * 3. Local Inner Class    : inside a method
 * 4. Anonymous Inner Class: no name, one-time use
 *
 * Use cases:
 *   Member inner: needs outer class data (Iterator, Event listeners)
 *   Static nested: logically grouped but independent
 *   Anonymous: override single method without full subclass
 *   Local: helper class for method-specific logic
 */
public class InnerClassesComplete {

    // ============================================================
    // 1. MEMBER (NON-STATIC) INNER CLASS
    // ============================================================
    private String outerField = "OuterField";
    private int    outerData  = 100;

    class MemberInner {
        private String innerField = "InnerField";

        public void show() {
            // Access outer class members directly!
            System.out.println("Outer field: " + outerField);  // direct access
            System.out.println("Outer data:  " + outerData);
            System.out.println("Inner field: " + innerField);
            System.out.println("Outer 'this': " + InnerClassesComplete.this);
        }

        public void modifyOuter() {
            outerData = 999;  // can MODIFY outer class fields!
        }
    }

    // ============================================================
    // 2. STATIC NESTED CLASS
    // ============================================================
    static class StaticNested {
        private String nestedField;

        public StaticNested(String field) { nestedField = field; }

        public void show() {
            // CANNOT access outer non-static members directly
            // outerField; // ERROR!
            System.out.println("StaticNested: " + nestedField);
        }

        // Can have its own static members
        static void staticMethod() {
            System.out.println("StaticNested.staticMethod() called");
        }
    }

    // Real example: Builder pattern (static nested)
    static class HttpRequest {
        private final String url, method, body;
        private final java.util.Map<String,String> headers;

        private HttpRequest(Builder b) {
            url=b.url; method=b.method; body=b.body; headers=b.headers;
        }

        @Override public String toString() {
            return method + " " + url + " headers=" + headers + " body=" + body;
        }

        static class Builder {
            private String url, method="GET", body=null;
            private java.util.Map<String,String> headers = new java.util.LinkedHashMap<>();

            public Builder(String url)           { this.url=url; }
            public Builder method(String m)       { this.method=m; return this; }
            public Builder header(String k, String v) { headers.put(k,v); return this; }
            public Builder body(String b)         { this.body=b; return this; }
            public HttpRequest build()            { return new HttpRequest(this); }
        }
    }

    // ============================================================
    // CUSTOM ITERATOR (member inner class example)
    // ============================================================
    static class NumberRange implements Iterable<Integer> {
        private final int start, end, step;

        public NumberRange(int start, int end, int step) {
            this.start=start; this.end=end; this.step=step;
        }

        @Override
        public java.util.Iterator<Integer> iterator() {
            return new java.util.Iterator<Integer>() {  // anonymous!
                private int current = start;

                @Override public boolean hasNext() { return current <= end; }
                @Override public Integer next()    {
                    if (!hasNext()) throw new java.util.NoSuchElementException();
                    int val = current; current += step; return val;
                }
            };
        }
    }

    // ============================================================
    // MAIN
    // ============================================================
    public static void main(String[] args) {

        System.out.println("=== 1. MEMBER INNER CLASS ===");
        InnerClassesComplete outer = new InnerClassesComplete();
        MemberInner inner = outer.new MemberInner();   // needs outer instance!
        inner.show();
        inner.modifyOuter();
        System.out.println("Outer data after modifyOuter: " + outer.outerData);

        System.out.println("\n=== 2. STATIC NESTED CLASS ===");
        StaticNested sn = new StaticNested("hello");   // NO outer instance needed
        sn.show();
        StaticNested.staticMethod();

        HttpRequest req = new HttpRequest.Builder("https://api.example.com/users")
            .method("POST")
            .header("Content-Type", "application/json")
            .header("Authorization", "Bearer token123")
            .body("{\"name\":\"Alice\"}")
            .build();
        System.out.println("Request: " + req);

        System.out.println("\n=== 3. LOCAL INNER CLASS ===");
        // Defined inside a method
        class LocalHelper {
            String prefix;
            LocalHelper(String p) { prefix=p; }
            void print(String msg) { System.out.println("[" + prefix + "] " + msg); }
        }
        LocalHelper lh = new LocalHelper("DEBUG");
        lh.print("This is a local class");
        lh.print("Only accessible in this method");

        System.out.println("\n=== 4. ANONYMOUS INNER CLASS ===");

        // Anonymous Runnable
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                System.out.println("Anonymous Runnable running in thread: " + Thread.currentThread().getName());
            }
        });
        t.start();
        try { t.join(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }

        // Same as lambda (Java 8+)
        Thread t2 = new Thread(() -> System.out.println("Lambda Runnable"));
        t2.start();
        try { t2.join(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }

        // Anonymous Comparator
        java.util.List<String> words = new java.util.ArrayList<>(
            java.util.Arrays.asList("banana", "apple", "fig", "cherry"));

        java.util.Collections.sort(words, new java.util.Comparator<String>() {
            @Override public int compare(String a, String b) {
                return Integer.compare(a.length(), b.length());
            }
        });
        System.out.println("Sorted by length (anonymous Comparator): " + words);

        // Same with lambda
        words.sort((a, b) -> Integer.compare(a.length(), b.length()));
        System.out.println("Sorted by length (lambda): " + words);

        System.out.println("\n=== CUSTOM ITERABLE with Anonymous Iterator ===");
        NumberRange range = new NumberRange(1, 20, 3);
        System.out.print("Range(1,20,step=3): ");
        for (int n : range) System.out.print(n + " ");
        System.out.println();

        System.out.println("\n=== ANONYMOUS CLASS - UI EVENT LISTENER ===");
        // Simulated event handler pattern
        interface ClickListener { void onClick(String elementId); }
        interface HoverListener { void onHover(String elementId); }

        ClickListener button = new ClickListener() {
            @Override public void onClick(String id) {
                System.out.println("Button [" + id + "] clicked! Processing...");
            }
        };
        button.onClick("submit-btn");

        HoverListener tooltip = (id) -> System.out.println("Tooltip shown for: " + id);
        tooltip.onHover("info-icon");
    }
}
