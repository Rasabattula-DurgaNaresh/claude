/**
 * TOPIC 36: JVM Memory Model & Garbage Collection
 * =================================================
 * JVM Memory Areas:
 *   Heap      : objects, arrays, class instances (GC managed)
 *   Stack     : local vars, method frames, primitive values
 *   Method Area/Metaspace: class definitions, static vars, constants
 *   PC Register: current instruction pointer per thread
 *   Native Method Stack: native (non-Java) calls
 *
 * GC Algorithms:
 *   Serial    : single thread, good for small apps
 *   Parallel  : multi-thread, good throughput (-XX:+UseParallelGC)
 *   G1        : default Java 9+, balanced (-XX:+UseG1GC)
 *   ZGC       : sub-ms pauses, Java 15+ (-XX:+UseZGC)
 *   Shenandoah: concurrent, Red Hat
 *
 * Key Flags:
 *   -Xms512m  : initial heap size
 *   -Xmx2g    : max heap size
 *   -Xss256k  : thread stack size
 *   -verbose:gc: print GC events
 */
import java.lang.ref.*;
import java.util.*;

public class JVMMemoryAndGC {

    // ============================================================
    // REFERENCE TYPES
    // ============================================================
    // Strong Reference: default, prevents GC
    // Soft Reference : collected when memory low (good for caches)
    // Weak Reference : collected at next GC cycle (WeakHashMap)
    // Phantom Reference: after finalization (for cleanup)

    static class HeavyObject {
        private final byte[] data;
        private final String id;

        public HeavyObject(String id, int sizeMB) {
            this.id = id;
            this.data = new byte[sizeMB * 1024]; // sizeMB KB
        }

        @Override protected void finalize() {
            System.out.println("  [GC] Finalizing: " + id);
        }

        @Override public String toString() { return "HeavyObject[" + id + "]"; }
    }

    // Soft Reference Cache (GC collects when memory needed)
    static class SoftCache<K, V> {
        private final Map<K, SoftReference<V>> cache = new HashMap<>();

        public void put(K key, V value) {
            cache.put(key, new SoftReference<>(value));
        }

        public Optional<V> get(K key) {
            SoftReference<V> ref = cache.get(key);
            if (ref == null) return Optional.empty();
            V val = ref.get();
            if (val == null) { cache.remove(key); return Optional.empty(); }
            return Optional.of(val);
        }

        public int size() { return cache.size(); }
        public void cleanup() { cache.entrySet().removeIf(e -> e.getValue().get() == null); }
    }

    // WeakHashMap: keys are weak references (auto-removed by GC)
    static class WeakCache<K, V> {
        private final WeakHashMap<K, V> map = new WeakHashMap<>();
        public void put(K key, V value) { map.put(key, value); }
        public V get(K key)             { return map.get(key); }
        public int size()               { return map.size(); }
    }

    public static void main(String[] args) {

        // ============================================================
        // JVM MEMORY INFO
        // ============================================================
        System.out.println("=== JVM MEMORY INFO ===");
        Runtime rt = Runtime.getRuntime();
        long maxMem  = rt.maxMemory();
        long totalMem= rt.totalMemory();
        long freeMem = rt.freeMemory();
        long usedMem = totalMem - freeMem;

        System.out.printf("Max Memory   : %,d bytes (%.1f MB)%n", maxMem,   maxMem/1024.0/1024);
        System.out.printf("Total Memory : %,d bytes (%.1f MB)%n", totalMem, totalMem/1024.0/1024);
        System.out.printf("Free Memory  : %,d bytes (%.1f MB)%n", freeMem,  freeMem/1024.0/1024);
        System.out.printf("Used Memory  : %,d bytes (%.1f MB)%n", usedMem,  usedMem/1024.0/1024);
        System.out.println("Available Processors: " + rt.availableProcessors());

        // JVM System Properties
        System.out.println("\n=== JVM PROPERTIES ===");
        String[] props = {"java.version","java.vendor","java.vm.name","os.name","os.arch","user.dir","file.separator"};
        for (String p : props) System.out.printf("  %-25s = %s%n", p, System.getProperty(p));

        // ============================================================
        // REFERENCE TYPES
        // ============================================================
        System.out.println("\n=== REFERENCE TYPES ===");

        // Strong Reference
        HeavyObject strong = new HeavyObject("strong-ref", 1);
        System.out.println("Strong ref: " + strong + " (won't be collected)");

        // Soft Reference
        SoftReference<HeavyObject> softRef = new SoftReference<>(new HeavyObject("soft-ref", 1));
        System.out.println("Soft ref: " + softRef.get() + " (collected when OOM)");

        // Weak Reference
        HeavyObject obj = new HeavyObject("weak-ref", 1);
        WeakReference<HeavyObject> weakRef = new WeakReference<>(obj);
        System.out.println("Weak ref before null: " + weakRef.get());
        obj = null; // remove strong reference
        System.gc(); // suggest GC (not guaranteed)
        try { Thread.sleep(100); } catch (InterruptedException e) {}
        System.out.println("Weak ref after GC:    " + weakRef.get() + " (may be null)");

        // ReferenceQueue
        System.out.println("\nReferenceQueue:");
        ReferenceQueue<HeavyObject> queue = new ReferenceQueue<>();
        HeavyObject phantom = new HeavyObject("phantom-ref", 1);
        PhantomReference<HeavyObject> pRef = new PhantomReference<>(phantom, queue);
        phantom = null;
        System.gc();
        try { Thread.sleep(100); } catch (InterruptedException e) {}
        System.out.println("Phantom get() always null: " + pRef.get()); // always null
        Reference<?> polled = queue.poll();
        System.out.println("Queue polled: " + (polled != null ? "enqueued (object finalized)" : "not yet"));

        // ============================================================
        // SOFT CACHE DEMO
        // ============================================================
        System.out.println("\n=== SOFT CACHE (memory-sensitive) ===");
        SoftCache<String, String> cache = new SoftCache<>();
        cache.put("key1", "value1");
        cache.put("key2", "value2");
        cache.put("key3", "value3");
        System.out.println("Cache size: " + cache.size());
        System.out.println("get(key1): " + cache.get("key1"));
        System.out.println("get(key9): " + cache.get("key9"));

        // ============================================================
        // WEAKHASHMAP DEMO
        // ============================================================
        System.out.println("\n=== WEAKHASHMAP ===");
        WeakHashMap<Object, String> weakMap = new WeakHashMap<>();
        Object key1 = new Object();
        Object key2 = new Object();
        weakMap.put(key1, "value1");
        weakMap.put(key2, "value2");
        System.out.println("WeakHashMap size: " + weakMap.size());
        key1 = null; // remove strong ref to key1
        System.gc();
        try { Thread.sleep(100); } catch (InterruptedException e) {}
        System.out.println("After GC + null key: " + weakMap.size() + " (key1 may be removed)");

        // ============================================================
        // STRING POOL DEMO
        // ============================================================
        System.out.println("\n=== STRING POOL ===");
        String s1 = "Hello";           // pool
        String s2 = "Hello";           // same pool object
        String s3 = new String("Hello"); // heap
        String s4 = s3.intern();        // back to pool

        System.out.println("s1 == s2:         " + (s1 == s2));  // true
        System.out.println("s1 == s3:         " + (s1 == s3));  // false (heap)
        System.out.println("s1 == s4:         " + (s1 == s4));  // true (interned)
        System.out.println("s1.equals(s3):    " + s1.equals(s3)); // true

        // ============================================================
        // MEMORY LEAK PATTERNS
        // ============================================================
        System.out.println("\n=== MEMORY LEAK PATTERNS (what NOT to do) ===");
        System.out.println("1. Static collections that grow but never shrink");
        System.out.println("   Solution: use WeakHashMap or clear when done");
        System.out.println("2. Listeners/callbacks never unregistered");
        System.out.println("   Solution: always remove listeners on destroy");
        System.out.println("3. Inner class holding reference to outer class");
        System.out.println("   Solution: use static nested class or lambda");
        System.out.println("4. Large objects in thread-local that aren't removed");
        System.out.println("   Solution: threadLocal.remove() when done");
        System.out.println("5. Unclosed streams, connections, file handles");
        System.out.println("   Solution: try-with-resources!");

        // ============================================================
        // GC ALGORITHMS SUMMARY
        // ============================================================
        System.out.println("\n=== GC ALGORITHMS ===");
        System.out.println("Serial GC:     -XX:+UseSerialGC | Single thread | Small apps");
        System.out.println("Parallel GC:   -XX:+UseParallelGC | High throughput | Batch");
        System.out.println("G1 GC:         -XX:+UseG1GC | Default Java 9+ | Balanced");
        System.out.println("ZGC:           -XX:+UseZGC | Sub-ms pauses | Java 15+ LTS");
        System.out.println("Shenandoah:    -XX:+UseShenandoahGC | Concurrent | OpenJDK");

        System.out.println("\n=== GC GENERATIONS ===");
        System.out.println("Young Gen (Eden + S0 + S1): New short-lived objects");
        System.out.println("  Minor GC: fast, frequent, collects young gen");
        System.out.println("Old Gen: Long-lived objects promoted from young");
        System.out.println("  Major GC: slower, less frequent");
        System.out.println("Metaspace: Class metadata (was PermGen in Java 7-)");

        System.out.println("\n=== USEFUL JVM FLAGS ===");
        System.out.println("-Xms512m           : Initial heap size");
        System.out.println("-Xmx4g             : Max heap size");
        System.out.println("-Xss512k           : Thread stack size");
        System.out.println("-XX:+HeapDumpOnOutOfMemoryError : Dump on OOM");
        System.out.println("-XX:HeapDumpPath=/tmp/heap.hprof");
        System.out.println("-verbose:gc        : Print GC events");
        System.out.println("-XX:+PrintGCDetails: Detailed GC logs");
        System.out.println("-Xlog:gc*:file=gc.log : Java 9+ GC logging");

        // ============================================================
        // OBJECT LIFECYCLE
        // ============================================================
        System.out.println("\n=== OBJECT LIFECYCLE ===");
        System.out.println("1. Allocated on heap (Eden space)");
        System.out.println("2. Minor GC: short-lived objects collected");
        System.out.println("3. Surviving objects promoted to Survivor space");
        System.out.println("4. After N promotions -> moved to Old Gen");
        System.out.println("5. Major/Full GC collects Old Gen");
        System.out.println("6. finalize() called (deprecated Java 9+, unreliable)");
        System.out.println("7. Memory reclaimed");

        System.out.println("\nJVM Memory & GC complete!");
    }
}
