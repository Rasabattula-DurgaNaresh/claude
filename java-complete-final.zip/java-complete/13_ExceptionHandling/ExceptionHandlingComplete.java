/**
 * TOPIC 13: Exception Handling - Complete Guide
 * ==============================================
 * Throwable hierarchy:
 *   Error (JVM-level, don't catch)
 *   Exception
 *     Checked (must declare/handle: IOException, SQLException)
 *     RuntimeException (unchecked: NPE, AIOOBE, IllegalArgument)
 *
 * try-catch-finally    : basic structure
 * try-with-resources   : auto-close (AutoCloseable)
 * multi-catch          : catch(Type1 | Type2 e)
 * exception chaining   : throw new Exception("msg", causeException)
 * Custom exceptions    : extend Exception or RuntimeException
 * Stack trace          : e.printStackTrace()
 */
public class ExceptionHandlingComplete {

    // ============================================================
    // CUSTOM EXCEPTION HIERARCHY
    // ============================================================
    static class AppException extends RuntimeException {
        private final String errorCode;
        public AppException(String code, String message) {
            super(message); this.errorCode = code;
        }
        public AppException(String code, String message, Throwable cause) {
            super(message, cause); this.errorCode = code;
        }
        public String getErrorCode() { return errorCode; }
    }

    static class ValidationException extends AppException {
        private final String field;
        public ValidationException(String field, String message) {
            super("VALIDATION_ERROR", "[" + field + "] " + message);
            this.field = field;
        }
        public String getField() { return field; }
    }

    static class DatabaseException extends AppException {
        public DatabaseException(String message, Throwable cause) {
            super("DB_ERROR", message, cause);
        }
    }

    static class NotFoundException extends AppException {
        public NotFoundException(String resource, Object id) {
            super("NOT_FOUND", resource + " with id=" + id + " not found");
        }
    }

    static class AuthException extends AppException {
        private int remainingAttempts;
        public AuthException(String message, int attempts) {
            super("AUTH_FAILED", message);
            this.remainingAttempts = attempts;
        }
        public int getRemainingAttempts() { return remainingAttempts; }
    }

    // ============================================================
    // AUTO-CLOSEABLE RESOURCES
    // ============================================================
    static class DatabaseConnection implements AutoCloseable {
        private final String url;
        private boolean isOpen;
        private int queryCount;

        public DatabaseConnection(String url) throws DatabaseException {
            if (url == null || !url.startsWith("jdbc:")) {
                throw new DatabaseException("Invalid connection URL: " + url, null);
            }
            this.url = url; this.isOpen = true; this.queryCount = 0;
            System.out.println("  [DB] Connected to: " + url);
        }

        public String executeQuery(String sql) {
            if (!isOpen) throw new IllegalStateException("Connection is closed!");
            queryCount++;
            System.out.println("  [DB] Query #" + queryCount + ": " + sql);
            if (sql.contains("DROP")) throw new DatabaseException("DROP not allowed!", null);
            return "ResultSet{rows=5}";
        }

        public void beginTransaction() { System.out.println("  [DB] Transaction started"); }
        public void commit()           { System.out.println("  [DB] Committed"); }
        public void rollback()         { System.out.println("  [DB] Rolled back"); }

        @Override public void close() {
            isOpen = false;
            System.out.println("  [DB] Connection closed after " + queryCount + " queries");
        }
    }

    static class FileProcessor implements AutoCloseable {
        private final String filename;
        private boolean isOpen;

        public FileProcessor(String filename) {
            this.filename = filename; this.isOpen = true;
            System.out.println("  [FILE] Opened: " + filename);
        }

        public String readLine(int lineNo) {
            if (!isOpen) throw new IllegalStateException("File is closed!");
            return "Line " + lineNo + " from " + filename;
        }

        @Override public void close() {
            isOpen = false;
            System.out.println("  [FILE] Closed: " + filename);
        }
    }

    // ============================================================
    // BUSINESS LOGIC WITH EXCEPTIONS
    // ============================================================
    static class UserService {
        private java.util.Map<Integer, String> users = new java.util.HashMap<>();
        private java.util.Map<String, Integer> loginAttempts = new java.util.HashMap<>();
        private static final int MAX_ATTEMPTS = 3;

        public UserService() {
            users.put(1, "alice:password123");
            users.put(2, "bob:secret456");
        }

        public void createUser(String username, String email, int age) {
            if (username == null || username.length() < 3)
                throw new ValidationException("username", "must be at least 3 characters");
            if (!email.contains("@") || !email.contains("."))
                throw new ValidationException("email", "invalid format");
            if (age < 0 || age > 150)
                throw new ValidationException("age", "must be between 0 and 150");
            System.out.println("User created: " + username + " | " + email + " | age=" + age);
        }

        public String login(String username, String password) {
            int attempts = loginAttempts.getOrDefault(username, 0);
            if (attempts >= MAX_ATTEMPTS)
                throw new AuthException("Account locked for " + username, 0);

            boolean valid = users.values().stream()
                .anyMatch(u -> u.equals(username + ":" + password));

            if (!valid) {
                loginAttempts.merge(username, 1, Integer::sum);
                int left = MAX_ATTEMPTS - loginAttempts.get(username);
                throw new AuthException("Invalid credentials for " + username, left);
            }
            loginAttempts.remove(username);
            return "token-" + username + "-" + System.currentTimeMillis();
        }

        public String findUser(int id) {
            String user = users.get(id);
            if (user == null) throw new NotFoundException("User", id);
            return user;
        }
    }

    // ============================================================
    // CHECKED EXCEPTION EXAMPLE
    // ============================================================
    static int parseAndDivide(String numStr, String denStr) throws Exception {
        try {
            int num = Integer.parseInt(numStr);
            int den = Integer.parseInt(denStr);
            if (den == 0) throw new ArithmeticException("Division by zero");
            return num / den;
        } catch (NumberFormatException e) {
            throw new Exception("Invalid number format: " + numStr + " or " + denStr, e);  // chaining
        }
    }

    public static void main(String[] args) {

        // ============================================================
        // 1. BASIC TRY-CATCH-FINALLY
        // ============================================================
        System.out.println("=== 1. TRY-CATCH-FINALLY ===");
        int[] arr = {1, 2, 3};
        try {
            System.out.println("arr[5] = " + arr[5]);  // ArrayIndexOutOfBoundsException
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Caught: " + e.getClass().getSimpleName() + " -> " + e.getMessage());
        } finally {
            System.out.println("Finally: always runs (cleanup here)");
        }

        // ============================================================
        // 2. MULTI-CATCH
        // ============================================================
        System.out.println("\n=== 2. MULTI-CATCH ===");
        Object[] objects = {42, "not a number", null, 3.14};
        for (Object obj : objects) {
            try {
                String s = (String) obj;            // ClassCastException for Integer/Double
                int n = Integer.parseInt(s);        // NumberFormatException for "not a number"
                String upper = s.toUpperCase();     // NullPointerException for null
                System.out.println("Parsed: " + n);
            } catch (ClassCastException | NullPointerException e) {
                System.out.println("Type error for " + obj + ": " + e.getClass().getSimpleName());
            } catch (NumberFormatException e) {
                System.out.println("Number format error for '" + obj + "'");
            }
        }

        // ============================================================
        // 3. TRY-WITH-RESOURCES
        // ============================================================
        System.out.println("\n=== 3. TRY-WITH-RESOURCES ===");
        try (DatabaseConnection db = new DatabaseConnection("jdbc:mysql://localhost/test");
             FileProcessor file  = new FileProcessor("data.txt")) {

            System.out.println(db.executeQuery("SELECT * FROM users"));
            System.out.println(db.executeQuery("SELECT COUNT(*) FROM orders"));
            System.out.println(file.readLine(1));
            System.out.println(file.readLine(2));
        } catch (DatabaseException e) {
            System.out.println("DB Error [" + e.getErrorCode() + "]: " + e.getMessage());
        }
        // Both db and file are automatically closed!

        // Multiple resources with exception in between
        System.out.println("\nMultiple resources with exception:");
        try (DatabaseConnection db2 = new DatabaseConnection("jdbc:oracle://localhost/hr")) {
            db2.beginTransaction();
            db2.executeQuery("SELECT * FROM employees");
            db2.executeQuery("DROP TABLE employees");  // throws!
            db2.commit();
        } catch (DatabaseException e) {
            System.out.println("Caught: " + e.getMessage());
            // rollback would happen here in real code
        }

        // ============================================================
        // 4. CUSTOM EXCEPTIONS
        // ============================================================
        System.out.println("\n=== 4. CUSTOM EXCEPTIONS ===");
        UserService service = new UserService();

        // Validation
        String[] usernames = {"Alice", "ab", null, "ValidUser"};
        String[] emails    = {"alice@test.com", "bad@test.com", "alice@test.com", "no-at-sign"};
        for (int i = 0; i < usernames.length; i++) {
            try {
                service.createUser(usernames[i], emails[i], 25);
            } catch (ValidationException e) {
                System.out.println("Validation [" + e.getField() + "]: " + e.getMessage());
            } catch (AppException e) {
                System.out.println("App error [" + e.getErrorCode() + "]: " + e.getMessage());
            }
        }

        // Login
        System.out.println("\nLogin attempts:");
        String[][] logins = {{"alice","wrong"},{"alice","wrong"},{"alice","password123"},{"bob","wrong"},{"bob","wrong"},{"bob","wrong"},{"bob","wrong"}};
        for (String[] cred : logins) {
            try {
                String token = service.login(cred[0], cred[1]);
                System.out.println("Login OK: " + token);
            } catch (AuthException e) {
                System.out.println("Auth failed: " + e.getMessage() + " | Remaining: " + e.getRemainingAttempts());
            }
        }

        // Not found
        try { service.findUser(999); }
        catch (NotFoundException e) { System.out.println(e.getMessage()); }

        // ============================================================
        // 5. EXCEPTION CHAINING
        // ============================================================
        System.out.println("\n=== 5. EXCEPTION CHAINING ===");
        String[][] inputs = {{"10","2"},{"5","0"},{"abc","3"},{"10","xyz"}};
        for (String[] inp : inputs) {
            try {
                System.out.printf("parseAndDivide(\"%s\",\"%s\") = %d%n",
                    inp[0], inp[1], parseAndDivide(inp[0], inp[1]));
            } catch (ArithmeticException e) {
                System.out.println("Math error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                if (e.getCause() != null) System.out.println("  Caused by: " + e.getCause());
            }
        }

        // ============================================================
        // 6. EXCEPTION GOTCHAS
        // ============================================================
        System.out.println("\n=== 6. GOTCHAS ===");

        // finally return overrides try return!
        System.out.println("getVal() = " + getVal());  // returns 99, not 1

        // NullPointerException
        try {
            String s = null;
            System.out.println(s.length());
        } catch (NullPointerException e) {
            System.out.println("NPE caught! Always null-check before calling methods");
        }

        // ClassCastException
        try {
            Object num = 42;
            String s = (String) num;
        } catch (ClassCastException e) {
            System.out.println("ClassCast: use instanceof before casting!");
        }

        // StackOverflowError (uncatchable in practice)
        // recursive(); // would cause StackOverflowError
        System.out.println("StackOverflowError happens with infinite recursion");

        System.out.println("\nAll exception examples complete!");
    }

    static int getVal() {
        try { return 1; }
        finally { return 99; }  // overrides try's return!
    }
}
