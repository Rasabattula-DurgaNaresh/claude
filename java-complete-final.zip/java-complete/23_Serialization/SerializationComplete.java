/**
 * TOPIC 23: Serialization & Deserialization
 * ===========================================
 * Serialization: convert object -> byte stream (save/send)
 * Deserialization: byte stream -> object (restore)
 * Implements Serializable (marker interface)
 * serialVersionUID: version control for deserialization
 * transient: skip field during serialization
 * readObject/writeObject: custom serialization hooks
 * Externalizable: full manual control
 * Record serialization (Java 16+)
 * JSON (via toString/manual, no external lib needed here)
 */
import java.io.*;
import java.nio.file.*;
import java.util.*;

public class SerializationComplete {

    // ============================================================
    // SERIALIZABLE CLASSES
    // ============================================================
    static class Person implements Serializable {
        private static final long serialVersionUID = 1L;

        private String name;
        private int    age;
        private String email;
        private transient String password;  // NOT serialized (sensitive)
        private transient int    tempScore; // NOT serialized (computed)
        private static int instanceCount = 0; // static: NOT serialized (class-level)

        public Person(String name, int age, String email, String password) {
            this.name = name; this.age = age;
            this.email = email; this.password = password;
            instanceCount++;
        }

        // Custom serialization hooks
        private void writeObject(ObjectOutputStream oos) throws IOException {
            oos.defaultWriteObject();  // serialize non-transient fields
            // Can write extra data:
            oos.writeObject(email.toLowerCase());  // normalize email before saving
        }

        private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
            ois.defaultReadObject();  // deserialize non-transient fields
            // Restore transient fields or do post-processing:
            this.password = "HIDDEN";  // restore with placeholder
            this.tempScore = name.length() * 10;  // computed field
        }

        @Override public String toString() {
            return String.format("Person{name=%s age=%d email=%s password=%s score=%d}",
                name, age, email, password, tempScore);
        }
    }

    static class Address implements Serializable {
        private static final long serialVersionUID = 2L;
        String street, city, state, pincode;

        public Address(String street, String city, String state, String pincode) {
            this.street=street; this.city=city; this.state=state; this.pincode=pincode;
        }

        @Override public String toString() {
            return street + ", " + city + ", " + state + " - " + pincode;
        }
    }

    static class Employee implements Serializable {
        private static final long serialVersionUID = 3L;
        private String  empId;
        private String  name;
        private double  salary;
        private Address address;   // Nested object (also Serializable)
        private List<String> skills; // Collections are Serializable

        public Employee(String empId, String name, double salary, Address address, List<String> skills) {
            this.empId=empId; this.name=name; this.salary=salary;
            this.address=address; this.skills=skills;
        }

        @Override public String toString() {
            return String.format("Employee{%s | %s | Rs %.0f | %s | skills=%s}",
                empId, name, salary, address, skills);
        }
    }

    // ============================================================
    // EXTERNALIZABLE (full control, faster but more work)
    // ============================================================
    static class Product implements Externalizable {
        private String name;
        private double price;
        private int    quantity;

        public Product() {}  // REQUIRED: no-arg constructor for Externalizable

        public Product(String name, double price, int qty) {
            this.name=name; this.price=price; this.quantity=qty;
        }

        @Override public void writeExternal(ObjectOutput out) throws IOException {
            out.writeObject(name.toUpperCase());  // store in uppercase
            out.writeDouble(price);
            out.writeInt(quantity);
        }

        @Override public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
            this.name     = (String) in.readObject();
            this.price    = in.readDouble();
            this.quantity = in.readInt();
        }

        @Override public String toString() {
            return "Product{" + name + " Rs" + price + " qty=" + quantity + "}";
        }
    }

    // ============================================================
    // UTILITY METHODS
    // ============================================================
    static byte[] serialize(Object obj) throws IOException {
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
             ObjectOutputStream oos = new ObjectOutputStream(baos)) {
            oos.writeObject(obj);
            return baos.toByteArray();
        }
    }

    @SuppressWarnings("unchecked")
    static <T> T deserialize(byte[] data) throws IOException, ClassNotFoundException {
        try (ByteArrayInputStream bais = new ByteArrayInputStream(data);
             ObjectInputStream ois = new ObjectInputStream(bais)) {
            return (T) ois.readObject();
        }
    }

    static void saveToFile(Object obj, String filename) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(
                new BufferedOutputStream(new FileOutputStream(filename)))) {
            oos.writeObject(obj);
            System.out.println("Saved to: " + filename);
        }
    }

    @SuppressWarnings("unchecked")
    static <T> T loadFromFile(String filename) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(
                new BufferedInputStream(new FileInputStream(filename)))) {
            T obj = (T) ois.readObject();
            System.out.println("Loaded from: " + filename);
            return obj;
        }
    }

    public static void main(String[] args) throws Exception {
        String tmpDir = System.getProperty("java.io.tmpdir") + File.separator;

        // ============================================================
        // 1. BASIC SERIALIZATION
        // ============================================================
        System.out.println("=== BASIC SERIALIZATION ===");
        Person p1 = new Person("Alice", 28, "Alice@Example.COM", "secret123");
        System.out.println("Before: " + p1);

        // Serialize to byte array
        byte[] bytes = serialize(p1);
        System.out.println("Serialized size: " + bytes.length + " bytes");

        // Deserialize back
        Person p2 = deserialize(bytes);
        System.out.println("After:  " + p2);
        System.out.println("(Note: password replaced, score computed, email normalized)");

        // ============================================================
        // 2. FILE SERIALIZATION
        // ============================================================
        System.out.println("\n=== FILE SERIALIZATION ===");
        Address addr = new Address("42 MG Road", "Hyderabad", "Telangana", "500001");
        Employee emp = new Employee("E001", "Bob Singh", 85000, addr,
            Arrays.asList("Java", "Spring", "Docker", "SQL"));

        String empFile = tmpDir + "employee.ser";
        saveToFile(emp, empFile);
        Employee emp2 = loadFromFile(empFile);
        System.out.println("Employee: " + emp2);
        System.out.println("Address:  " + emp2.address);
        System.out.println("Skills:   " + emp2.skills);
        new File(empFile).delete();

        // ============================================================
        // 3. LIST SERIALIZATION
        // ============================================================
        System.out.println("\n=== SERIALIZING COLLECTIONS ===");
        List<Person> people = Arrays.asList(
            new Person("Charlie", 30, "charlie@test.com", "pwd1"),
            new Person("Diana",   25, "diana@test.com",   "pwd2"),
            new Person("Eve",     35, "eve@test.com",     "pwd3")
        );

        byte[] listBytes = serialize(people);
        System.out.println("List serialized: " + listBytes.length + " bytes");

        List<Person> restoredPeople = deserialize(listBytes);
        System.out.println("Restored " + restoredPeople.size() + " people:");
        restoredPeople.forEach(p -> System.out.println("  " + p));

        // ============================================================
        // 4. EXTERNALIZABLE
        // ============================================================
        System.out.println("\n=== EXTERNALIZABLE ===");
        Product prod = new Product("laptop", 65000.50, 10);
        System.out.println("Original: " + prod);

        byte[] prodBytes = serialize(prod);
        System.out.println("Serialized: " + prodBytes.length + " bytes");

        Product prod2 = deserialize(prodBytes);
        System.out.println("Restored:   " + prod2);  // name in UPPERCASE

        // ============================================================
        // 5. DEEP COPY VIA SERIALIZATION
        // ============================================================
        System.out.println("\n=== DEEP COPY VIA SERIALIZATION ===");
        Employee original = new Employee("E002", "Frank", 90000,
            new Address("10 Park St", "Mumbai", "Maharashtra", "400001"),
            new ArrayList<>(Arrays.asList("Python", "ML")));

        // Deep copy using serialize/deserialize
        byte[] copyBytes = serialize(original);
        Employee copy = deserialize(copyBytes);

        // Modify copy - original should not be affected
        copy.skills.add("TensorFlow");
        copy.address.city = "Delhi";

        System.out.println("Original address: " + original.address.city);  // Mumbai
        System.out.println("Copy address:     " + copy.address.city);      // Delhi
        System.out.println("Original skills:  " + original.skills);        // [Python, ML]
        System.out.println("Copy skills:      " + copy.skills);            // [Python, ML, TensorFlow]

        // ============================================================
        // 6. SERIALVERSIONUID IMPORTANCE
        // ============================================================
        System.out.println("\n=== serialVersionUID ===");
        System.out.println("Always define serialVersionUID explicitly!");
        System.out.println("Without it, Java computes one from class structure.");
        System.out.println("If you change the class (add/remove fields), the auto-generated");
        System.out.println("UID changes, causing InvalidClassException on deserialization.");
        System.out.println("Best practice: private static final long serialVersionUID = 1L;");

        System.out.println("\nSerialization examples complete!");
    }
}
