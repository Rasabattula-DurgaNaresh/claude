/**
 * TOPIC 16: Set & Queue - Complete Reference
 * ===========================================
 * Set: no duplicates, uses equals() and hashCode()
 *   HashSet:       O(1), unordered
 *   LinkedHashSet: O(1), insertion order
 *   TreeSet:       O(log n), sorted (natural or custom)
 *   EnumSet:       very fast set for enum values
 *
 * Queue / Priority:
 *   PriorityQueue: min-heap by default
 *   ArrayDeque:    resizable double-ended queue (faster than Stack/LinkedList)
 */
import java.util.*;
import java.util.stream.*;

public class CollectionsSetComplete {

    enum Priority { LOW, MEDIUM, HIGH, CRITICAL }

    record Task(String name, Priority priority, int id) {
        @Override public String toString() {
            return String.format("Task{%d %-15s [%s]}", id, name, priority);
        }
    }

    public static void main(String[] args) {

        // ============================================================
        // HASHSET
        // ============================================================
        System.out.println("=== HASHSET ===");
        Set<Integer> set = new HashSet<>(Arrays.asList(3,1,4,1,5,9,2,6,5,3,5,3));
        System.out.println("Unique elements: " + set);  // order not guaranteed
        set.add(7);
        System.out.println("After add(7):    " + set);
        set.remove(9);
        System.out.println("After remove(9): " + set);
        System.out.println("contains(5): " + set.contains(5));
        System.out.println("size: " + set.size());

        // Set from collection (remove duplicates!)
        List<String> withDups = Arrays.asList("apple","banana","apple","cherry","banana","date");
        Set<String> unique = new HashSet<>(withDups);
        List<String> deduped = new ArrayList<>(unique);
        System.out.println("Deduped list: " + deduped);

        // ============================================================
        // SET OPERATIONS (Union, Intersection, Difference)
        // ============================================================
        System.out.println("\n=== SET OPERATIONS ===");
        Set<Integer> setA = new HashSet<>(Arrays.asList(1, 2, 3, 4, 5, 6));
        Set<Integer> setB = new HashSet<>(Arrays.asList(4, 5, 6, 7, 8, 9));

        Set<Integer> union = new HashSet<>(setA); union.addAll(setB);
        Set<Integer> intersection = new HashSet<>(setA); intersection.retainAll(setB);
        Set<Integer> diffAB = new HashSet<>(setA); diffAB.removeAll(setB);
        Set<Integer> diffBA = new HashSet<>(setB); diffBA.removeAll(setA);
        Set<Integer> symDiff = new HashSet<>(union); symDiff.removeAll(intersection);

        System.out.println("A:           " + new TreeSet<>(setA));
        System.out.println("B:           " + new TreeSet<>(setB));
        System.out.println("Union:       " + new TreeSet<>(union));
        System.out.println("Intersection:" + new TreeSet<>(intersection));
        System.out.println("A - B:       " + new TreeSet<>(diffAB));
        System.out.println("B - A:       " + new TreeSet<>(diffBA));
        System.out.println("Sym Diff:    " + new TreeSet<>(symDiff));
        System.out.println("A subset of Union? " + union.containsAll(setA));
        System.out.println("A,B disjoint?      " + Collections.disjoint(setA, setB));
        System.out.println("diffAB disjoint B? " + Collections.disjoint(diffAB, setB));

        // ============================================================
        // LINKEDHASHSET
        // ============================================================
        System.out.println("\n=== LINKEDHASHSET (Insertion Order) ===");
        Set<String> linkedSet = new LinkedHashSet<>();
        String[] words = {"banana","apple","cherry","apple","avocado","banana","date"};
        for (String w : words) linkedSet.add(w);
        System.out.println("Unique in insertion order: " + linkedSet);

        // ============================================================
        // TREESET
        // ============================================================
        System.out.println("\n=== TREESET ===");
        TreeSet<Integer> ts = new TreeSet<>(Arrays.asList(5,2,8,1,9,3,7,4,6,10));
        System.out.println("TreeSet (sorted): " + ts);
        System.out.println("first: " + ts.first() + " | last: " + ts.last());
        System.out.println("headSet(<5):      " + ts.headSet(5));
        System.out.println("tailSet(>=5):     " + ts.tailSet(5));
        System.out.println("subSet(3,7):      " + ts.subSet(3, 7));
        System.out.println("floor(5):         " + ts.floor(5));
        System.out.println("ceiling(5):       " + ts.ceiling(5));
        System.out.println("lower(5):         " + ts.lower(5));  // <5
        System.out.println("higher(5):        " + ts.higher(5)); // >5
        System.out.println("pollFirst:        " + ts.pollFirst() + " -> " + ts);
        System.out.println("pollLast:         " + ts.pollLast()  + " -> " + ts);
        System.out.println("descendingSet:    " + ts.descendingSet());

        // Custom comparator TreeSet
        TreeSet<String> byLen = new TreeSet<>(
            Comparator.comparingInt(String::length).thenComparing(Comparator.naturalOrder()));
        byLen.addAll(Arrays.asList("banana","apple","kiwi","cherry","fig","date","mango"));
        System.out.println("By length+alpha: " + byLen);

        // ============================================================
        // ENUMSET
        // ============================================================
        System.out.println("\n=== ENUMSET ===");
        EnumSet<Priority> highPriority = EnumSet.of(Priority.HIGH, Priority.CRITICAL);
        EnumSet<Priority> allPriorities = EnumSet.allOf(Priority.class);
        EnumSet<Priority> lowPriorities = EnumSet.complementOf(highPriority);
        System.out.println("High:    " + highPriority);
        System.out.println("All:     " + allPriorities);
        System.out.println("Low:     " + lowPriorities);

        // ============================================================
        // PRIORITYQUEUE
        // ============================================================
        System.out.println("\n=== PRIORITYQUEUE ===");
        // Min-heap (natural order)
        PriorityQueue<Integer> minPQ = new PriorityQueue<>();
        minPQ.addAll(Arrays.asList(5, 1, 8, 3, 2, 7, 4, 6));
        System.out.println("PQ (min-heap), peek: " + minPQ.peek());
        System.out.print("Poll order: ");
        while (!minPQ.isEmpty()) System.out.print(minPQ.poll() + " ");
        System.out.println();

        // Max-heap
        PriorityQueue<Integer> maxPQ = new PriorityQueue<>(Collections.reverseOrder());
        maxPQ.addAll(Arrays.asList(5, 1, 8, 3, 2, 7));
        System.out.print("Max-heap poll: ");
        while (!maxPQ.isEmpty()) System.out.print(maxPQ.poll() + " ");
        System.out.println();

        // Priority Queue with Tasks
        PriorityQueue<Task> taskQueue = new PriorityQueue<>(
            Comparator.comparing(Task::priority).reversed()  // CRITICAL first
        );
        taskQueue.add(new Task("Fix Bug",          Priority.HIGH,     1));
        taskQueue.add(new Task("Write Docs",       Priority.LOW,      2));
        taskQueue.add(new Task("Deploy Hotfix",    Priority.CRITICAL, 3));
        taskQueue.add(new Task("Code Review",      Priority.MEDIUM,   4));
        taskQueue.add(new Task("DB Migration",     Priority.CRITICAL, 5));
        taskQueue.add(new Task("Update README",    Priority.LOW,      6));
        System.out.println("\nTask execution order:");
        while (!taskQueue.isEmpty()) System.out.println("  " + taskQueue.poll());

        // ============================================================
        // ARRAYDEQUE
        // ============================================================
        System.out.println("\n=== ARRAYDEQUE ===");
        ArrayDeque<String> deque = new ArrayDeque<>();
        deque.addFirst("B"); deque.addFirst("A");
        deque.addLast("C"); deque.addLast("D");
        System.out.println("Deque: " + deque);
        System.out.println("peekFirst: " + deque.peekFirst() + " | peekLast: " + deque.peekLast());
        System.out.println("pollFirst: " + deque.pollFirst() + " -> " + deque);
        System.out.println("pollLast:  " + deque.pollLast()  + " -> " + deque);

        // As Stack (LIFO)
        Deque<Integer> stack = new ArrayDeque<>();
        stack.push(1); stack.push(2); stack.push(3);
        System.out.println("\nStack: " + stack);
        System.out.println("pop: " + stack.pop() + " -> " + stack);

        // As Queue (FIFO)
        Deque<Integer> queue = new ArrayDeque<>();
        queue.offer(1); queue.offer(2); queue.offer(3);
        System.out.println("\nQueue: " + queue);
        System.out.println("poll: " + queue.poll() + " -> " + queue);

        // BFS simulation with Queue
        System.out.println("\n=== BFS with Queue ===");
        Queue<String> bfsQueue = new ArrayDeque<>();
        Set<String> visited = new LinkedHashSet<>();
        Map<String, List<String>> graph = Map.of(
            "A", Arrays.asList("B", "C"),
            "B", Arrays.asList("D", "E"),
            "C", Arrays.asList("F"),
            "D", Collections.emptyList(),
            "E", Collections.emptyList(),
            "F", Collections.emptyList()
        );
        bfsQueue.offer("A");
        while (!bfsQueue.isEmpty()) {
            String node = bfsQueue.poll();
            if (visited.add(node)) {
                bfsQueue.addAll(graph.getOrDefault(node, Collections.emptyList()));
            }
        }
        System.out.println("BFS traversal: " + visited);
    }
}
