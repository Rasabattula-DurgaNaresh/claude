/**
 * TOPIC 11: Interfaces - Complete Deep Dive
 * ===========================================
 * Interface features by Java version:
 *   Pre-Java 8 : abstract methods + constants only
 *   Java 8     : default methods, static methods
 *   Java 9     : private methods, private static methods
 *   Java 16+   : sealed interfaces
 *
 * Functional Interface: exactly ONE abstract method (@FunctionalInterface)
 * Marker Interface: no methods (Serializable, Cloneable, Remote)
 * Interface vs Abstract Class: "can-do" vs "is-a"
 * Default method conflict resolution: most specific wins, or override required
 */
import java.util.*;
import java.util.function.*;

public class InterfacesComplete {

    // ============================================================
    // FUNCTIONAL INTERFACES
    // ============================================================
    @FunctionalInterface
    interface Validator<T> {
        boolean validate(T value);

        // Default combinator methods
        default Validator<T> and(Validator<T> other) {
            return value -> this.validate(value) && other.validate(value);
        }
        default Validator<T> or(Validator<T> other) {
            return value -> this.validate(value) || other.validate(value);
        }
        default Validator<T> negate() {
            return value -> !this.validate(value);
        }
    }

    @FunctionalInterface
    interface Transformer<T, R> {
        R transform(T input);
        default <V> Transformer<T, V> andThen(Transformer<R, V> after) {
            return input -> after.transform(this.transform(input));
        }
    }

    // ============================================================
    // INTERFACE WITH DEFAULT & STATIC METHODS
    // ============================================================
    interface Logger {
        // Abstract
        void log(String level, String message);

        // Default methods
        default void info(String msg)    { log("INFO",  msg); }
        default void warn(String msg)    { log("WARN",  msg); }
        default void error(String msg)   { log("ERROR", msg); }
        default void debug(String msg)   { log("DEBUG", msg); }

        // Static factory
        static Logger console() {
            return (level, msg) ->
                System.out.printf("[%s] %-5s | %s%n",
                    java.time.LocalTime.now().toString().substring(0,8), level, msg);
        }

        static Logger prefix(String prefix) {
            return (level, msg) -> System.out.printf("[%s] %s: %s%n", level, prefix, msg);
        }

        // Default: combine two loggers
        default Logger and(Logger other) {
            return (level, msg) -> { this.log(level, msg); other.log(level, msg); };
        }
    }

    // ============================================================
    // INTERFACE INHERITANCE
    // ============================================================
    interface Readable  { String read(); }
    interface Writable  { void write(String data); }
    interface ReadWrite extends Readable, Writable {
        default void copy(ReadWrite dest) {
            dest.write(this.read());
        }
    }

    static class InMemoryStore implements ReadWrite {
        private String data = "";
        @Override public String read()           { return data; }
        @Override public void write(String d)    { data = d; System.out.println("Written: " + d); }
    }

    // ============================================================
    // COMPARABLE & COMPARATOR
    // ============================================================
    static class Student implements Comparable<Student> {
        String name; int age; double gpa;

        public Student(String n, int a, double g) { name=n; age=a; gpa=g; }

        @Override public int compareTo(Student other) {
            return Double.compare(other.gpa, this.gpa);  // descending GPA
        }

        // Comparators as static fields
        static Comparator<Student> BY_NAME  = Comparator.comparing(s -> s.name);
        static Comparator<Student> BY_AGE   = Comparator.comparingInt(s -> s.age);
        static Comparator<Student> BY_GPA   = Comparator.comparingDouble((Student s) -> s.gpa).reversed();
        static Comparator<Student> COMPLEX  = BY_GPA.thenComparing(BY_NAME).thenComparing(BY_AGE);

        @Override public String toString() {
            return String.format("Student{%-10s age=%-2d gpa=%.2f}", name, age, gpa);
        }
    }

    // ============================================================
    // DEFAULT METHOD CONFLICT
    // ============================================================
    interface A { default String greet() { return "Hello from A"; } }
    interface B { default String greet() { return "Hello from B"; } }

    static class C implements A, B {
        // MUST override when both interfaces have same default method
        @Override public String greet() {
            return A.super.greet() + " and " + B.super.greet();
        }
    }

    // ============================================================
    // MARKER INTERFACES (no methods)
    // ============================================================
    interface Printable {}
    interface Cacheable {}
    interface Auditable {}

    static class UserRecord implements Printable, Cacheable, Auditable {
        String username; String email;
        public UserRecord(String u, String e) { username=u; email=e; }
        public void printIfPrintable() {
            if (this instanceof Printable) System.out.println("Printing: " + username);
        }
    }

    public static void main(String[] args) {

        System.out.println("=== FUNCTIONAL INTERFACES ===");
        // Validators using lambda
        Validator<String> notEmpty = s -> !s.isBlank();
        Validator<String> hasAt    = s -> s.contains("@");
        Validator<String> hasDot   = s -> s.contains(".");
        Validator<String> emailValidator = notEmpty.and(hasAt).and(hasDot);

        String[] emails = {"alice@example.com", "bad-email", "", "no-dot@com"};
        for (String e : emails) {
            System.out.println("  " + e + " valid? " + emailValidator.validate(e));
        }

        // Transformer chain
        Transformer<String, Integer> strToLen = String::length;
        Transformer<Integer, String> lenToStr = n -> "Length is " + n;
        Transformer<String, String> combined = strToLen.andThen(lenToStr);
        System.out.println("  " + combined.transform("Hello World"));

        System.out.println("\n=== LOGGER INTERFACE ===");
        Logger consoleLog = Logger.console();
        consoleLog.info("Application started");
        consoleLog.warn("Low disk space");
        consoleLog.error("Database connection failed");

        Logger prefixLog = Logger.prefix("AUTH");
        prefixLog.info("User login attempt");
        prefixLog.error("Invalid password");

        Logger combined2 = consoleLog.and(prefixLog);
        combined2.warn("Dual logging example");

        System.out.println("\n=== INTERFACE INHERITANCE ===");
        InMemoryStore store1 = new InMemoryStore();
        InMemoryStore store2 = new InMemoryStore();
        store1.write("Hello from store1!");
        store1.copy(store2);
        System.out.println("store2 has: " + store2.read());

        System.out.println("\n=== COMPARABLE & COMPARATOR ===");
        List<Student> students = Arrays.asList(
            new Student("Charlie", 22, 8.5),
            new Student("Alice",   20, 9.2),
            new Student("Bob",     21, 9.2),
            new Student("Diana",   23, 8.7)
        );
        System.out.println("Natural (GPA desc): ");
        Collections.sort(students);
        students.forEach(s -> System.out.println("  " + s));

        System.out.println("By name: ");
        students.sort(Student.BY_NAME);
        students.forEach(s -> System.out.println("  " + s));

        System.out.println("Complex (GPA desc, then name, then age): ");
        students.sort(Student.COMPLEX);
        students.forEach(s -> System.out.println("  " + s));

        System.out.println("\n=== DEFAULT METHOD CONFLICT ===");
        C cObj = new C();
        System.out.println(cObj.greet());

        System.out.println("\n=== MARKER INTERFACES ===");
        UserRecord user = new UserRecord("alice", "alice@test.com");
        user.printIfPrintable();
        System.out.println("Is Printable? " + (user instanceof Printable));
        System.out.println("Is Cacheable? " + (user instanceof Cacheable));
        System.out.println("Is Auditable? " + (user instanceof Auditable));
    }
}
