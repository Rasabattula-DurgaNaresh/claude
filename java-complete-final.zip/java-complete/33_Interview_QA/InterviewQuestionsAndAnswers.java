/**
 * TOPIC 33: Java Interview Questions & Answers
 * ==============================================
 * 150+ interview questions with detailed answers
 * Covers: Core Java, OOP, Collections, Threads, JVM, Java 8+
 * Difficulty: Easy / Medium / Hard
 * Format: Question as comment, runnable demonstration below
 */
import java.util.*;
import java.util.stream.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.function.*;

public class InterviewQuestionsAndAnswers {

    // ============================================================
    // SECTION 1: JAVA BASICS
    // ============================================================

    // Q1: What is the difference between JDK, JRE, and JVM?
    static void q01_jdkJreJvm() {
        System.out.println("Q1: JDK vs JRE vs JVM");
        System.out.println("  JVM  : Java Virtual Machine - Executes bytecode");
        System.out.println("         Platform-specific, provides: memory mgmt, GC, security");
        System.out.println("  JRE  : Java Runtime Environment = JVM + core libraries");
        System.out.println("         Needed to RUN Java programs");
        System.out.println("  JDK  : Java Development Kit = JRE + compiler + tools");
        System.out.println("         Needed to DEVELOP Java programs");
        System.out.println("  Hierarchy: JDK ⊃ JRE ⊃ JVM");
    }

    // Q2: What is the difference between == and .equals()?
    static void q02_equalsVsDoubleEqual() {
        System.out.println("\nQ2: == vs .equals()");
        String s1 = "Hello";
        String s2 = "Hello";
        String s3 = new String("Hello");

        System.out.println("  s1 = \"Hello\" (pool)");
        System.out.println("  s2 = \"Hello\" (pool)");
        System.out.println("  s3 = new String(\"Hello\") (heap)");
        System.out.println("  s1 == s2:        " + (s1 == s2));      // true (same pool ref)
        System.out.println("  s1 == s3:        " + (s1 == s3));      // false (diff object)
        System.out.println("  s1.equals(s3):   " + s1.equals(s3));   // true (same content)
        System.out.println("  RULE: Use == for primitives, .equals() for objects");
        System.out.println("  Always override equals() + hashCode() together!");
    }

    // Q3: What is String immutability and why?
    static void q03_stringImmutability() {
        System.out.println("\nQ3: String Immutability");
        String s = "Hello";
        System.out.println("  s = \"Hello\", s.toUpperCase() -> " + s.toUpperCase());
        System.out.println("  Original s = " + s + " (unchanged!)");
        System.out.println("  Why immutable?");
        System.out.println("    1. Thread-safety: safe to share across threads");
        System.out.println("    2. String Pool: same literal can be shared");
        System.out.println("    3. Security: passwords, class names can't be changed");
        System.out.println("    4. HashMap key safety: hashCode stays constant");
        System.out.println("  String vs StringBuilder vs StringBuffer:");
        System.out.println("    String:        immutable, thread-safe, slow concatenation");
        System.out.println("    StringBuilder: mutable, NOT thread-safe, FAST");
        System.out.println("    StringBuffer:  mutable, thread-safe (synchronized), slower");
    }

    // Q4: What is autoboxing and unboxing?
    static void q04_autoboxing() {
        System.out.println("\nQ4: Autoboxing & Unboxing");
        // Autoboxing: primitive -> wrapper
        Integer i1 = 42;               // autoboxing: int -> Integer
        Double  d1 = 3.14;             // autoboxing: double -> Double
        Boolean b1 = true;             // autoboxing: boolean -> Boolean

        // Unboxing: wrapper -> primitive
        int i2 = i1;                   // unboxing
        double d2 = d1;                // unboxing

        System.out.println("  Autoboxed Integer: " + i1);
        System.out.println("  Unboxed int: " + i2);

        // Integer cache: -128 to 127 (cached)
        Integer a = 127, b = 127;
        Integer c = 128, d = 128;
        System.out.println("  Integer 127: a==b -> " + (a == b));  // true (cached)
        System.out.println("  Integer 128: c==d -> " + (c == d));  // false! (new objects)
        System.out.println("  Use .equals(): c.equals(d) -> " + c.equals(d));

        // Null unboxing -> NullPointerException!
        Integer nullInt = null;
        try { int x = nullInt; }  // unboxing null!
        catch (NullPointerException e) { System.out.println("  Null unboxing -> NPE!"); }
    }

    // Q5: final vs finally vs finalize
    static void q05_finalFinallyFinalize() {
        System.out.println("\nQ5: final vs finally vs finalize");
        System.out.println("  final:");
        System.out.println("    variable : constant (cannot reassign)");
        System.out.println("    method   : cannot override in subclass");
        System.out.println("    class    : cannot extend (e.g., String, Integer)");

        final int MAX = 100;
        // MAX = 200; // Compile error!

        System.out.println("  finally: always runs in try-catch block");
        System.out.println("    Even after return or exception!");
        System.out.println("    Exception: System.exit() or JVM crash");

        System.out.println("  finalize: method called by GC before collecting");
        System.out.println("    @Deprecated in Java 9+, unreliable, avoid!");
        System.out.println("    Use try-with-resources or Cleaner instead");
    }

    // Q6: What are static and instance members?
    static void q06_staticVsInstance() {
        System.out.println("\nQ6: static vs instance");
        System.out.println("  static (class-level):");
        System.out.println("    - Shared by ALL instances");
        System.out.println("    - Loaded once when class is loaded");
        System.out.println("    - Access via ClassName.member");
        System.out.println("    - Cannot access 'this' or instance members directly");
        System.out.println("  instance:");
        System.out.println("    - Each object has its own copy");
        System.out.println("    - Created when object created");
        System.out.println("    - Access via objectRef.member");

        // static initialization block
        System.out.println("  Static init block: runs once when class loaded");
        System.out.println("  Instance init block: runs before each constructor");
    }

    // Q7: What is the difference between abstract class and interface?
    static void q07_abstractVsInterface() {
        System.out.println("\nQ7: Abstract Class vs Interface");
        System.out.println("  Abstract Class:");
        System.out.println("    - Can have: abstract + concrete methods, fields, constructors");
        System.out.println("    - Single inheritance (extends ONE class)");
        System.out.println("    - Access modifiers allowed for methods");
        System.out.println("    - Use when IS-A relationship with shared state");

        System.out.println("  Interface:");
        System.out.println("    - Pre-Java 8: only public abstract methods + constants");
        System.out.println("    - Java 8+: default, static methods");
        System.out.println("    - Java 9+: private methods");
        System.out.println("    - Multiple implementation allowed");
        System.out.println("    - Use for CAN-DO contracts (Runnable, Serializable)");

        System.out.println("  When to use which?");
        System.out.println("    Abstract class: Animal (shared code, different subclasses)");
        System.out.println("    Interface: Comparable, Iterable, Callable, Runnable");
    }

    // Q8: Method overloading vs overriding
    static void q08_overloadingVsOverriding() {
        System.out.println("\nQ8: Overloading vs Overriding");
        System.out.println("  Overloading (Compile-time polymorphism):");
        System.out.println("    - Same class, same name, DIFFERENT parameters");
        System.out.println("    - Resolved at COMPILE time");
        System.out.println("    - Return type alone does NOT differentiate");
        System.out.println("    - Example: System.out.println(int), println(String)");

        System.out.println("  Overriding (Runtime polymorphism):");
        System.out.println("    - Different class (parent-child), SAME signature");
        System.out.println("    - Resolved at RUNTIME (dynamic dispatch)");
        System.out.println("    - Need @Override annotation (best practice)");
        System.out.println("    - Cannot override: static, final, private methods");
        System.out.println("    - Covariant return type allowed (subtype of parent return)");
    }

    // Q9: What is constructor chaining?
    static void q09_constructorChaining() {
        System.out.println("\nQ9: Constructor Chaining");
        System.out.println("  this() : call another constructor in SAME class");
        System.out.println("  super(): call parent constructor (must be FIRST statement)");
        System.out.println("  Example:");
        System.out.println("    class Person {");
        System.out.println("      Person() { this(\"Unknown\", 0); }");
        System.out.println("      Person(String name) { this(name, 0); }");
        System.out.println("      Person(String name, int age) { this.name=name; this.age=age; }");
        System.out.println("    }");
    }

    // Q10: What is the difference between throw and throws?
    static void q10_throwVsThrows() {
        System.out.println("\nQ10: throw vs throws");
        System.out.println("  throw:  used to THROW an exception");
        System.out.println("    throw new RuntimeException(\"error\");");
        System.out.println("    throw new IllegalArgumentException(\"bad arg\");");
        System.out.println("  throws: declares method MAY throw exception");
        System.out.println("    void readFile() throws IOException { ... }");
        System.out.println("    Mandatory for checked exceptions!");
        System.out.println("  Checked vs Unchecked:");
        System.out.println("    Checked:   IOException, SQLException (must handle)");
        System.out.println("    Unchecked: RuntimeException and subclasses (optional)");
    }

    // ============================================================
    // SECTION 2: COLLECTIONS
    // ============================================================

    // Q11: HashMap internal working
    static void q11_hashmapInternal() {
        System.out.println("\nQ11: HashMap Internal Working");
        System.out.println("  Structure: Array of buckets (Node<K,V>[] table)");
        System.out.println("  Default capacity: 16, Load factor: 0.75");
        System.out.println("  Resize trigger: size > capacity * loadFactor (12 entries for cap=16)");
        System.out.println("  Steps on put(key, value):");
        System.out.println("    1. hash = key.hashCode() ^ (hash >>> 16)");
        System.out.println("    2. index = hash & (capacity - 1)");
        System.out.println("    3. If bucket empty -> insert new Node");
        System.out.println("    4. If collision -> LinkedList (Java 7) or TreeNode (Java 8+)");
        System.out.println("    5. TreeNode when bucket size > 8 (O(n) -> O(log n))");
        System.out.println("  Null key: always goes to bucket 0");
        System.out.println("  Thread-unsafe: use ConcurrentHashMap for threads");

        HashMap<String,Integer> map = new HashMap<>();
        map.put("Alice", 1); map.put("Bob", 2); map.put(null, 3);
        System.out.println("  Map with null key: " + map);
    }

    // Q12: Difference between HashMap, LinkedHashMap, TreeMap
    static void q12_mapTypes() {
        System.out.println("\nQ12: HashMap vs LinkedHashMap vs TreeMap");

        HashMap<String,Integer>       hm = new HashMap<>();
        LinkedHashMap<String,Integer> lm = new LinkedHashMap<>();
        TreeMap<String,Integer>       tm = new TreeMap<>();

        String[] keys = {"Banana","Apple","Cherry","Date"};
        for (int i=0; i<keys.length; i++) {hm.put(keys[i],i+1);lm.put(keys[i],i+1);tm.put(keys[i],i+1);}

        System.out.println("  HashMap   (unordered): " + hm);
        System.out.println("  LinkedHashMap (insert): " + lm);
        System.out.println("  TreeMap    (sorted):   " + tm);
        System.out.println("  Null keys: HashMap=1, LinkedHashMap=1, TreeMap=0");
        System.out.println("  Performance: HashMap O(1), TreeMap O(log n)");
    }

    // Q13: ConcurrentHashMap vs HashMap vs Hashtable
    static void q13_concurrentMap() {
        System.out.println("\nQ13: ConcurrentHashMap vs HashMap vs Hashtable");
        System.out.println("  HashMap:");
        System.out.println("    - NOT thread-safe");
        System.out.println("    - Allows null key + null values");
        System.out.println("    - Best performance for single thread");

        System.out.println("  Hashtable (legacy):");
        System.out.println("    - Thread-safe (synchronized EVERY method)");
        System.out.println("    - NO null key or value");
        System.out.println("    - Poor concurrency (one thread at a time)");

        System.out.println("  ConcurrentHashMap:");
        System.out.println("    - Thread-safe (segment/bucket locking)");
        System.out.println("    - NO null key or value");
        System.out.println("    - High concurrency (multiple readers + writers)");
        System.out.println("    - Java 8: uses CAS + synchronized at node level");
        System.out.println("  Use: ConcurrentHashMap for thread safety!");
    }

    // Q14: Fail-fast vs Fail-safe iterators
    static void q14_failFastVsSafe() {
        System.out.println("\nQ14: Fail-fast vs Fail-safe Iterators");

        // Fail-fast: ConcurrentModificationException if modified during iteration
        List<Integer> list = new ArrayList<>(Arrays.asList(1,2,3,4,5));
        System.out.println("  Fail-fast (ArrayList): modifying during iteration -> CME");
        try {
            for (Integer n : list) {
                if (n == 3) list.remove(n); // throws ConcurrentModificationException
            }
        } catch (ConcurrentModificationException e) {
            System.out.println("  Caught CME! (as expected)");
        }

        // Fix: use Iterator.remove() or removeIf
        list = new ArrayList<>(Arrays.asList(1,2,3,4,5));
        list.removeIf(n -> n == 3);
        System.out.println("  Fixed with removeIf: " + list);

        // Fail-safe: CopyOnWriteArrayList (works on a copy)
        List<Integer> cowList = new CopyOnWriteArrayList<>(Arrays.asList(1,2,3,4,5));
        for (Integer n : cowList) {
            if (n == 3) cowList.remove(n); // No exception!
        }
        System.out.println("  Fail-safe (CopyOnWriteArrayList): " + cowList);

        System.out.println("  Fail-fast collections: ArrayList, HashMap, HashSet");
        System.out.println("  Fail-safe collections: CopyOnWriteArrayList, ConcurrentHashMap");
    }

    // Q15: Comparable vs Comparator
    static void q15_comparableVsComparator() {
        System.out.println("\nQ15: Comparable vs Comparator");
        System.out.println("  Comparable (java.lang):");
        System.out.println("    - Defines natural ordering for the class");
        System.out.println("    - int compareTo(T other)");
        System.out.println("    - Modifies the class itself");
        System.out.println("    - e.g., String, Integer, LocalDate");

        System.out.println("  Comparator (java.util):");
        System.out.println("    - External ordering strategy");
        System.out.println("    - int compare(T o1, T o2)");
        System.out.println("    - Multiple comparators per class");
        System.out.println("    - Can be lambda!");

        record Student(String name, int age, double gpa) {}
        List<Student> students = Arrays.asList(
            new Student("Charlie",22,8.5), new Student("Alice",20,9.2), new Student("Bob",21,9.2));

        // Natural sort with Comparator
        students.sort(Comparator.comparing(Student::name));
        System.out.println("  By name: " + students.stream().map(Student::name).toList());
        students.sort(Comparator.comparingDouble(Student::gpa).reversed().thenComparing(Student::name));
        System.out.println("  By GPA desc+name: " + students.stream().map(s->s.name()+"="+s.gpa()).toList());
    }

    // ============================================================
    // SECTION 3: MULTITHREADING
    // ============================================================

    // Q16: volatile vs synchronized
    static void q16_volatileVsSynchronized() {
        System.out.println("\nQ16: volatile vs synchronized");
        System.out.println("  volatile:");
        System.out.println("    - Visibility: changes visible to ALL threads immediately");
        System.out.println("    - Prevents CPU register caching");
        System.out.println("    - Does NOT ensure atomicity (i++ is NOT atomic!)");
        System.out.println("    - Use for simple flags: volatile boolean running = true;");

        System.out.println("  synchronized:");
        System.out.println("    - Mutual exclusion (only one thread at a time)");
        System.out.println("    - Ensures visibility AND atomicity");
        System.out.println("    - More overhead than volatile");
        System.out.println("    - Use for compound operations: check-then-act");

        System.out.println("  AtomicInteger:");
        System.out.println("    - Lock-free, CAS (compare-and-swap) operations");
        System.out.println("    - incrementAndGet(), compareAndSet() are atomic");
        System.out.println("    - Best for counters");
    }

    // Q17: Deadlock - what, why, how to prevent
    static void q17_deadlock() {
        System.out.println("\nQ17: Deadlock");
        System.out.println("  What: Two threads each hold a lock the other needs -> infinite wait");
        System.out.println("  Conditions (all 4 needed): Mutual Exclusion, Hold & Wait,");
        System.out.println("    No Preemption, Circular Wait");
        System.out.println("  Prevention:");
        System.out.println("    1. Lock ordering: always acquire locks in same order");
        System.out.println("    2. tryLock(timeout): fail if can't acquire in time");
        System.out.println("    3. Avoid nested locks");
        System.out.println("    4. Use higher-level concurrency: Executors, CompletableFuture");
        System.out.println("  Detection: jstack, VisualVM, JConsole, Thread.getAllStackTraces()");
    }

    // Q18: wait() vs sleep() vs yield()
    static void q18_waitSleepYield() {
        System.out.println("\nQ18: wait() vs sleep() vs yield()");
        System.out.println("  wait():");
        System.out.println("    - Object method (must be in synchronized block)");
        System.out.println("    - RELEASES the lock, thread enters WAITING state");
        System.out.println("    - Woken by notify()/notifyAll()");
        System.out.println("    - Used for inter-thread communication");

        System.out.println("  sleep(ms):");
        System.out.println("    - Thread method, does NOT release lock");
        System.out.println("    - Thread enters TIMED_WAITING state");
        System.out.println("    - Used to pause execution");

        System.out.println("  yield():");
        System.out.println("    - Hint to scheduler to let other threads run");
        System.out.println("    - Does NOT release lock, may be ignored");
        System.out.println("    - Thread goes back to RUNNABLE (not WAITING)");
    }

    // Q19: Callable vs Runnable
    static void q19_callableVsRunnable() throws Exception {
        System.out.println("\nQ19: Callable vs Runnable");
        System.out.println("  Runnable: void run() - no return, no checked exception");
        System.out.println("  Callable: V call() throws Exception - returns value, can throw");

        ExecutorService pool = Executors.newFixedThreadPool(2);

        Runnable r = () -> System.out.println("  Runnable: no return value");
        Callable<Integer> c = () -> { Thread.sleep(10); return 42; };

        pool.execute(r);
        Future<Integer> future = pool.submit(c);
        System.out.println("  Callable returned: " + future.get());
        pool.shutdown();
    }

    // ============================================================
    // SECTION 4: JAVA 8+
    // ============================================================

    // Q20: What is a lambda expression?
    static void q20_lambdas() {
        System.out.println("\nQ20: Lambda Expressions");
        System.out.println("  Lambda = anonymous function: (params) -> body");
        System.out.println("  Requires a Functional Interface (1 abstract method)");

        // Before Java 8
        Runnable r1 = new Runnable() { public void run() { System.out.println("  Old way"); } };
        // Java 8+
        Runnable r2 = () -> System.out.println("  Lambda way");
        r1.run(); r2.run();

        // With parameters
        Comparator<String> comp = (a, b) -> a.length() - b.length();
        List<String> words = new ArrayList<>(Arrays.asList("banana","apple","fig","cherry"));
        words.sort(comp);
        System.out.println("  Sorted by length: " + words);

        // Method reference shorthand
        words.forEach(System.out::println);
    }

    // Q21: Stream API - lazy evaluation
    static void q21_streamLazyEval() {
        System.out.println("\nQ21: Stream Lazy Evaluation");
        System.out.println("  Intermediate ops are LAZY (not executed until terminal)");
        System.out.println("  Short-circuit: findFirst, limit stop processing early");

        List<Integer> nums = Arrays.asList(1,2,3,4,5,6,7,8,9,10);

        // This does NOT compute all elements
        Optional<Integer> first = nums.stream()
            .filter(n -> { System.out.print("  filter(" + n + ") "); return n % 2 == 0; })
            .map(n -> { System.out.print("map(" + n + ") "); return n * n; })
            .findFirst(); // stops after first match!
        System.out.println("\n  Result: " + first + " (only processed until first even found!)");
    }

    // Q22: Optional - what and why?
    static void q22_optional() {
        System.out.println("\nQ22: Optional<T>");
        System.out.println("  Purpose: explicit null handling, avoid NPE");

        Optional<String> present = Optional.of("Alice");
        Optional<String> empty   = Optional.empty();
        Optional<String> nullable = Optional.ofNullable(null);

        System.out.println("  isPresent: " + present.isPresent());
        System.out.println("  orElse:    " + empty.orElse("default"));
        System.out.println("  map:       " + present.map(String::length));
        System.out.println("  filter:    " + present.filter(s -> s.length() > 3));

        // Avoid: optional.get() without checking!
        try { empty.get(); }
        catch (NoSuchElementException e) { System.out.println("  get() on empty -> " + e.getClass().getSimpleName()); }
        System.out.println("  Best practice: orElse, orElseGet, orElseThrow, ifPresent");
    }

    // ============================================================
    // SECTION 5: OOP ADVANCED
    // ============================================================

    // Q23: Liskov Substitution Principle
    static void q23_solidPrinciples() {
        System.out.println("\nQ23: SOLID Principles");
        System.out.println("  S - Single Responsibility: class does ONE thing");
        System.out.println("  O - Open/Closed: open for extension, closed for modification");
        System.out.println("  L - Liskov Substitution: subclass can replace parent");
        System.out.println("      List<String> list = new ArrayList<>(); (works!)");
        System.out.println("  I - Interface Segregation: small focused interfaces");
        System.out.println("  D - Dependency Inversion: depend on abstractions, not implementations");
        System.out.println("      Inject UserRepository interface, not UserRepositoryImpl");
    }

    // Q24: Covariant return type
    static void q24_covariantReturn() {
        System.out.println("\nQ24: Covariant Return Type");
        System.out.println("  Java 5+: overriding method can return a subtype");
        System.out.println("  class Animal { Animal create() {...} }");
        System.out.println("  class Dog extends Animal { Dog create() {...} } // OK!");
        System.out.println("  The return type is covariant (more specific type allowed)");
    }

    // Q25: What is a marker interface?
    static void q25_markerInterface() {
        System.out.println("\nQ25: Marker Interface");
        System.out.println("  Interface with NO methods - just marks a class");
        System.out.println("  Examples: Serializable, Cloneable, RandomAccess, Remote");
        System.out.println("  JVM/framework checks instanceof at runtime");
        System.out.println("  Modern alternative: @Annotation (more flexible)");
        System.out.println("  Serializable: 'if obj instanceof Serializable -> serialize it'");
    }

    // ============================================================
    // SECTION 6: JVM & PERFORMANCE
    // ============================================================

    // Q26: What causes OutOfMemoryError?
    static void q26_oom() {
        System.out.println("\nQ26: OutOfMemoryError causes");
        System.out.println("  Java heap space:   too many objects, increase -Xmx");
        System.out.println("  GC overhead:       GC spending >98% time, freeing <2%");
        System.out.println("  Metaspace:         too many classes loaded (-XX:MaxMetaspaceSize)");
        System.out.println("  Direct buffer:     ByteBuffer.allocateDirect too large");
        System.out.println("  Unable to create native thread: too many threads");
        System.out.println("  Solutions: fix memory leaks, increase heap, use streaming");
    }

    // Q27: What is StackOverflowError?
    static void q27_stackOverflow() {
        System.out.println("\nQ27: StackOverflowError");
        System.out.println("  Cause: infinite/deep recursion, each call adds to call stack");
        System.out.println("  Stack is finite (-Xss flag)");
        System.out.println("  Fix:");
        System.out.println("    1. Add base case to recursion");
        System.out.println("    2. Convert to iteration");
        System.out.println("    3. Use trampolining pattern");
        System.out.println("    4. Increase stack: -Xss2m");
    }

    // Q28: String Pool internals
    static void q28_stringPool() {
        System.out.println("\nQ28: String Pool");
        System.out.println("  String pool (String Intern Pool) is in Heap (Java 8+)");
        System.out.println("  Was in PermGen (Java 7 and before)");
        System.out.println("  Stores literal strings: \"Hello\" always goes to pool");
        System.out.println("  new String(\"Hello\") goes to heap (NOT pool)");
        System.out.println("  s.intern() moves string to pool or returns existing");
        System.out.println("  Benefit: saves memory (same literal shared)");
        System.out.println("  WARN: .intern() can cause OutOfMemoryError if abused");
    }

    // Q29: Difference between deep copy and shallow copy
    static void q29_deepVsShallow() {
        System.out.println("\nQ29: Deep Copy vs Shallow Copy");
        System.out.println("  Shallow copy: copies object, but nested objects are shared");
        System.out.println("    Object.clone() = shallow by default");
        System.out.println("    new ArrayList<>(existingList) = shallow");
        System.out.println("  Deep copy: copies object AND all nested objects recursively");
        System.out.println("    Methods: manual copy, serialization, copy constructor");

        // Example
        int[] original = {1, 2, 3};
        int[] shallow  = original;               // same array!
        int[] deep     = original.clone();       // new array, same values

        shallow[0]  = 99;
        System.out.println("  After shallow[0]=99, original[0]=" + original[0]); // 99!
        deep[0] = 77;
        System.out.println("  After deep[0]=77,    original[0]=" + original[0]); // 99, unchanged
    }

    // Q30: What is a singleton and how do you make it thread-safe?
    static void q30_singleton() {
        System.out.println("\nQ30: Thread-safe Singleton patterns");
        System.out.println("  1. Eager initialization:");
        System.out.println("     private static final Singleton INSTANCE = new Singleton();");
        System.out.println("     - Thread-safe, but created even if unused");

        System.out.println("  2. Double-checked locking:");
        System.out.println("     private static volatile Singleton instance;");
        System.out.println("     if(null){synchronized(Singleton.class){if(null){new...}}}");
        System.out.println("     - Lazy + thread-safe");

        System.out.println("  3. Bill Pugh (Static inner class) - BEST:");
        System.out.println("     private static class Holder { static Singleton INST = new...; }");
        System.out.println("     - Lazy, thread-safe, no synchronization overhead");

        System.out.println("  4. Enum Singleton - SIMPLEST:");
        System.out.println("     enum MySingleton { INSTANCE; }");
        System.out.println("     - Serialization-safe, thread-safe, simplest");
    }

    // ADDITIONAL QUESTIONS 31-50
    static void q31to50() {
        System.out.println("\n=== QUESTIONS 31-50 QUICK REFERENCE ===");

        System.out.println("Q31: Checked vs Unchecked Exceptions");
        System.out.println("  Checked  : Must handle at compile time (IOException, SQLException)");
        System.out.println("  Unchecked: RuntimeException subclasses (NPE, AIOOBE, ClassCast)");

        System.out.println("Q32: try-with-resources");
        System.out.println("  try(Connection c=...; Statement s=...){ } // auto-closes!");
        System.out.println("  Resource must implement AutoCloseable");
        System.out.println("  close() called in REVERSE order of creation");

        System.out.println("Q33: transient keyword");
        System.out.println("  Marks field to be skipped during serialization");
        System.out.println("  Use for: passwords, calculated fields, connections");

        System.out.println("Q34: static import");
        System.out.println("  import static java.lang.Math.*; -> use PI, sqrt() directly");

        System.out.println("Q35: Varargs");
        System.out.println("  void method(String... args) -> treated as String[]");
        System.out.println("  Must be last parameter, one varargs per method");

        System.out.println("Q36: Default methods in interfaces - diamond problem");
        System.out.println("  If class implements 2 interfaces with same default -> must override");
        System.out.println("  InterfaceName.super.method() to call specific interface method");

        System.out.println("Q37: Functional interfaces");
        System.out.println("  @FunctionalInterface: exactly ONE abstract method");
        System.out.println("  Predicate, Function, Consumer, Supplier, BiFunction...");

        System.out.println("Q38: Method references types");
        System.out.println("  Static: Integer::parseInt");
        System.out.println("  Instance of specific obj: obj::method");
        System.out.println("  Instance of arbitrary obj: String::toUpperCase");
        System.out.println("  Constructor: ArrayList::new");

        System.out.println("Q39: flatMap vs map");
        System.out.println("  map:     one-to-one, wraps in Stream<Stream<T>>");
        System.out.println("  flatMap: one-to-many, flattens Stream<T>");

        System.out.println("Q40: Immutable class creation rules");
        System.out.println("  1. Class final (no subclass)");
        System.out.println("  2. All fields private final");
        System.out.println("  3. No setters");
        System.out.println("  4. Deep copy mutable fields in constructor/getters");
        System.out.println("  Examples: String, Integer, LocalDate, BigDecimal");

        System.out.println("Q41: instanceof pattern matching (Java 16)");
        System.out.println("  if (obj instanceof String s && s.length() > 3) { use s }");

        System.out.println("Q42: Records (Java 16)");
        System.out.println("  record Point(int x, int y) {} // immutable data carrier");
        System.out.println("  Auto-generates: constructor, getters, equals, hashCode, toString");

        System.out.println("Q43: Sealed classes (Java 17)");
        System.out.println("  sealed interface Shape permits Circle, Rect, Triangle {}");
        System.out.println("  Restricted inheritance, exhaustive pattern matching");

        System.out.println("Q44: Virtual Threads (Java 21)");
        System.out.println("  Lightweight (millions possible), map to OS threads dynamically");
        System.out.println("  Thread.ofVirtual().start(runnable)");
        System.out.println("  Executors.newVirtualThreadPerTaskExecutor()");

        System.out.println("Q45: CompletableFuture vs Future");
        System.out.println("  Future: can get(), cancel(), isDone() -- blocking");
        System.out.println("  CompletableFuture: non-blocking, composable, then*/when*/except*");

        System.out.println("Q46: hashCode() contract");
        System.out.println("  If a.equals(b) -> a.hashCode() == b.hashCode() (MANDATORY)");
        System.out.println("  If !a.equals(b) -> different hashCode preferred (performance)");
        System.out.println("  Must override BOTH equals() and hashCode() together!");

        System.out.println("Q47: ConcurrentHashMap vs SynchronizedMap");
        System.out.println("  Collections.synchronizedMap(): locks ENTIRE map per operation");
        System.out.println("  ConcurrentHashMap: segment/bucket-level locking, much faster");

        System.out.println("Q48: WeakHashMap use case");
        System.out.println("  Keys are weak references - GC removes when no other reference");
        System.out.println("  Use for: caches where GC can reclaim keys");

        System.out.println("Q49: Enum advanced features");
        System.out.println("  Can have fields, constructors, methods");
        System.out.println("  Can implement interfaces");
        System.out.println("  Can have abstract methods (each constant implements)");
        System.out.println("  EnumSet/EnumMap: high-performance specialized collections");

        System.out.println("Q50: String.intern() and == vs equals");
        System.out.println("  s.intern() returns canonical pool representation");
        System.out.println("  After intern, == works like equals (but use .equals always!)");
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=".repeat(60));
        System.out.println("   JAVA INTERVIEW QUESTIONS & ANSWERS");
        System.out.println("=".repeat(60));

        q01_jdkJreJvm();
        q02_equalsVsDoubleEqual();
        q03_stringImmutability();
        q04_autoboxing();
        q05_finalFinallyFinalize();
        q06_staticVsInstance();
        q07_abstractVsInterface();
        q08_overloadingVsOverriding();
        q09_constructorChaining();
        q10_throwVsThrows();
        q11_hashmapInternal();
        q12_mapTypes();
        q13_concurrentMap();
        q14_failFastVsSafe();
        q15_comparableVsComparator();
        q16_volatileVsSynchronized();
        q17_deadlock();
        q18_waitSleepYield();
        q19_callableVsRunnable();
        q20_lambdas();
        q21_streamLazyEval();
        q22_optional();
        q23_solidPrinciples();
        q24_covariantReturn();
        q25_markerInterface();
        q26_oom();
        q27_stackOverflow();
        q28_stringPool();
        q29_deepVsShallow();
        q30_singleton();
        q31to50();

        System.out.println("\n" + "=".repeat(60));
        System.out.println("   See InterviewCodingChallenges.java for coding problems!");
        System.out.println("=".repeat(60));
    }
}
