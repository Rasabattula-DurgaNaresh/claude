# Java Complete Interview Study Guide
## 200+ Questions with Answers

---

## PART 1: CORE JAVA BASICS

### Q: What is platform independence in Java?
Java compiles to bytecode (.class) which runs on JVM. JVM is platform-specific but bytecode is not — "Write Once Run Anywhere" (WORA).

### Q: What are the 8 primitive types and their sizes?
| Type | Size | Range |
|------|------|-------|
| byte | 1 byte | -128 to 127 |
| short | 2 bytes | -32,768 to 32,767 |
| int | 4 bytes | ~±2.1 billion |
| long | 8 bytes | ~±9.2 quintillion |
| float | 4 bytes | ~7 decimal digits |
| double | 8 bytes | ~15 decimal digits |
| boolean | ~1 bit | true/false |
| char | 2 bytes | '\u0000' to '\uffff' |

### Q: What is autoboxing?
Automatic conversion between primitive and wrapper class:
- `Integer i = 42;` — autoboxing (int → Integer)
- `int x = i;` — unboxing (Integer → int)
- Integer cache: -128 to 127 cached, so `Integer a=127; Integer b=127; a==b` is `true`
- Integer 128+: new objects, `a==b` is `false`. Always use `.equals()`!

### Q: String vs StringBuilder vs StringBuffer?
- **String**: immutable, thread-safe, stored in pool, slow for repeated concat
- **StringBuilder**: mutable, NOT thread-safe, fast, preferred for single-thread concat  
- **StringBuffer**: mutable, thread-safe (synchronized), slower than StringBuilder

### Q: What is String immutability and why?
Once created, value cannot change. Reasons:
1. **Thread safety**: can share across threads safely
2. **String Pool**: same literal shared → memory savings
3. **Security**: passwords, class names cannot be tampered
4. **HashMap key**: hashCode stays constant

### Q: final vs finally vs finalize?
- `final`: constant variable, non-overridable method, non-extendable class
- `finally`: block that always runs after try-catch (even after return)
- `finalize()`: called by GC before collecting — deprecated Java 9+, unreliable

### Q: static vs instance?
- **static**: class-level, shared by all instances, no `this`, loaded once
- **instance**: per-object, each object has own copy, needs object to access

---

## PART 2: OOP

### Q: 4 Pillars of OOP?
1. **Encapsulation**: bind data + behavior, hide implementation
2. **Inheritance**: IS-A, code reuse, `extends`
3. **Polymorphism**: many forms — overloading (compile-time), overriding (runtime)
4. **Abstraction**: hide complexity, expose essentials — `abstract`, `interface`

### Q: Abstract class vs Interface?

| Feature | Abstract Class | Interface |
|---------|---------------|-----------|
| Inheritance | Single | Multiple |
| Constructor | Yes | No |
| Fields | Any type | Only public static final |
| Methods | Abstract + concrete | Pre-J8: abstract only; J8+: default/static |
| Use | IS-A, shared code | CAN-DO, contract |

### Q: Method Overloading vs Overriding?

| | Overloading | Overriding |
|---|---|---|
| Where | Same class | Parent-Child |
| Parameters | Must differ | Must be same |
| Resolution | Compile time | Runtime |
| Return type | Can differ | Same or covariant |
| static/private | Can overload | Cannot override |

### Q: Access modifiers scope?
```
private   → same class only
default   → same package
protected → same package + subclasses
public    → everywhere
```

### Q: What is the `super` keyword?
- `super()` — call parent constructor (must be first line)
- `super.method()` — call parent's overridden method
- `super.field` — access parent's field

### Q: Can we override static methods?
No — static methods are **hidden**, not overridden. Resolution is based on reference type (compile-time), not object type (runtime).

### Q: What is covariant return type?
Overriding method can return a subtype of parent's return type:
```java
class Animal { Animal clone() {} }
class Dog extends Animal { Dog clone() {} } // valid!
```

### Q: SOLID Principles?
- **S**ingle Responsibility — one class, one purpose
- **O**pen/Closed — open for extension, closed for modification
- **L**iskov Substitution — subtype must be usable wherever parent is
- **I**nterface Segregation — prefer small focused interfaces
- **D**ependency Inversion — depend on abstractions, not implementations

---

## PART 3: EXCEPTIONS

### Q: Exception hierarchy?
```
Throwable
├── Error (JVM errors, don't catch)
│   ├── OutOfMemoryError
│   └── StackOverflowError
└── Exception
    ├── Checked (IOException, SQLException) — must handle
    └── RuntimeException (NPE, AIOOBE) — unchecked
```

### Q: Checked vs Unchecked?
- **Checked**: compiler forces you to handle (IOException, ClassNotFoundException)
- **Unchecked**: RuntimeException subclasses, optional handling

### Q: try-with-resources?
Resources implementing `AutoCloseable` are automatically closed:
```java
try (Connection c = ...; Statement s = ...) {
    // use c and s
} // auto-closed in reverse order!
```

### Q: throw vs throws?
- `throw new RuntimeException("msg")` — actually throw an exception
- `void method() throws IOException` — declare may throw

### Q: Can finally be skipped?
Yes: `System.exit()` call, JVM crash, or infinite loop/deadlock in try block.

### Q: Exception chaining?
```java
try { } catch (IOException e) {
    throw new AppException("Failed", e); // e is the cause
}
// e.getCause() returns original IOException
```

---

## PART 4: COLLECTIONS

### Q: List vs Set vs Map?
- **List**: ordered, duplicates allowed, index-based
- **Set**: unordered (except LinkedHashSet/TreeSet), no duplicates
- **Map**: key-value pairs, keys unique

### Q: ArrayList vs LinkedList?
| | ArrayList | LinkedList |
|---|---|---|
| get(i) | O(1) | O(n) |
| add(end) | O(1)* | O(1) |
| add(middle) | O(n) | O(n) |
| Memory | Less (array) | More (nodes with pointers) |
| Use when | Random access | Frequent add/remove at ends |

### Q: HashMap internal working?
1. `hashCode()` on key, then mix: `h ^ (h >>> 16)`
2. `index = hash & (capacity-1)`
3. If bucket empty → insert Node
4. If collision → linked list (Java 7) or Red-Black Tree (Java 8, when bucket > 8)
5. Default capacity: 16, load factor: 0.75, resizes at 12 entries
6. Null key always goes to bucket 0

### Q: HashMap vs LinkedHashMap vs TreeMap?
- **HashMap**: unordered, O(1), 1 null key allowed
- **LinkedHashMap**: insertion or access order, O(1)
- **TreeMap**: sorted by keys, O(log n), no null key

### Q: Fail-fast vs Fail-safe?
- **Fail-fast** (ArrayList, HashMap): `ConcurrentModificationException` if modified during iteration
- **Fail-safe** (CopyOnWriteArrayList, ConcurrentHashMap): iterate over snapshot, no exception
- Fix fail-fast: use `iterator.remove()` or `removeIf()`

### Q: Comparable vs Comparator?
- **Comparable**: `compareTo()` in the class itself (natural order)
- **Comparator**: external, can have multiple, use as lambda `(a,b) -> ...`

### Q: ConcurrentHashMap vs Hashtable?
- **Hashtable**: synchronizes entire map (one thread at a time) — slow
- **ConcurrentHashMap**: segment/bucket locking, much higher concurrency

---

## PART 5: MULTITHREADING

### Q: Thread states?
NEW → RUNNABLE → (BLOCKED / WAITING / TIMED_WAITING) → TERMINATED

### Q: volatile vs synchronized?
- **volatile**: guarantees visibility (no CPU cache), but NOT atomicity
- **synchronized**: guarantees both visibility AND atomicity (mutual exclusion)
- `i++` is NOT atomic even with volatile! Use `AtomicInteger`.

### Q: wait() vs sleep() vs yield()?
| | wait() | sleep() | yield() |
|---|---|---|---|
| Class | Object | Thread | Thread |
| Releases lock | YES | No | No |
| State | WAITING | TIMED_WAITING | RUNNABLE |
| Woken by | notify() | timeout | scheduler |

### Q: Deadlock - how to prevent?
Four conditions (all needed): Mutual Exclusion, Hold & Wait, No Preemption, Circular Wait
Prevention:
1. Always acquire locks in same order
2. Use `tryLock(timeout)`
3. Avoid nested locks
4. Use higher-level concurrency (Executors)

### Q: Callable vs Runnable?
- **Runnable**: `void run()` — no return, no checked exception
- **Callable**: `V call() throws Exception` — returns value, can throw

### Q: Thread pool benefits?
1. Reuse threads (avoid creation/destruction overhead)
2. Limit thread count (prevent resource exhaustion)
3. Task queuing
4. Thread lifecycle management

### Q: CompletableFuture vs Future?
- **Future**: blocking `get()`, cannot compose, no exception handling
- **CompletableFuture**: non-blocking, chainable (thenApply/thenCompose), `exceptionally()`

---

## PART 6: JAVA 8+ FEATURES

### Q: Lambda expression syntax?
```java
() -> expr                    // no params
x -> x * 2                   // one param
(x, y) -> x + y              // two params
(int x, int y) -> { return x + y; }  // typed, block body
```

### Q: Functional interfaces?
Interface with exactly ONE abstract method:
- `Predicate<T>`: `boolean test(T t)`
- `Function<T,R>`: `R apply(T t)`
- `Consumer<T>`: `void accept(T t)`
- `Supplier<T>`: `T get()`
- `BiFunction<T,U,R>`: `R apply(T t, U u)`
- `UnaryOperator<T>`: `T apply(T t)`
- `BinaryOperator<T>`: `T apply(T t1, T t2)`

### Q: Method reference types?
```java
Integer::parseInt          // static
String::toUpperCase        // instance of arbitrary object
obj::method                // instance of specific object
ArrayList::new             // constructor
```

### Q: Stream lazy evaluation?
Intermediate operations (filter, map, sorted) are LAZY — not executed until terminal operation. Short-circuit operations (findFirst, limit) stop early once result found.

### Q: Optional — what and why?
Explicit null handling to avoid NPE. Main methods:
```java
Optional.of(val)           // throws if null
Optional.ofNullable(val)   // OK with null
optional.isPresent()
optional.get()             // throws if empty!
optional.orElse(default)
optional.orElseGet(() -> computeDefault())
optional.map(fn)
optional.filter(pred)
optional.ifPresent(consumer)
```

### Q: Stream terminal operations?
`forEach, collect, reduce, count, min, max, findFirst, findAny, anyMatch, allMatch, noneMatch, toArray`

### Q: Collectors.groupingBy?
```java
employees.stream()
    .collect(Collectors.groupingBy(Employee::dept,         // classifier
             Collectors.averagingDouble(Employee::salary)));// downstream
```

---

## PART 7: JVM & PERFORMANCE

### Q: JVM memory areas?
- **Heap**: objects, arrays (GC managed)
- **Stack**: method frames, local variables
- **Metaspace**: class definitions (replaced PermGen in Java 8)
- **PC Register**: current instruction per thread
- **Native Stack**: JNI calls

### Q: Heap generations?
- **Young Generation**: Eden + Survivor 0 + Survivor 1 (Minor GC)
- **Old/Tenured Generation**: long-lived objects (Major GC)
- **Minor GC**: fast, frequent; **Major GC**: slow, less frequent

### Q: What causes OutOfMemoryError?
1. Java heap space — too many objects
2. GC overhead limit — GC can't free enough memory
3. Metaspace — too many class definitions loaded
4. Unable to create native thread — too many threads

### Q: String Pool?
- Stored in heap (Java 8+, was PermGen in Java 7-)
- String literals automatically interned
- `new String("hello")` creates heap object NOT in pool
- `.intern()` forces pool storage

### Q: GC algorithms?
| GC | Flag | Use case |
|---|---|---|
| Serial | -XX:+UseSerialGC | Single thread, small apps |
| Parallel | -XX:+UseParallelGC | Batch, throughput |
| G1 | -XX:+UseG1GC | Default Java 9+, balanced |
| ZGC | -XX:+UseZGC | Sub-ms pauses, Java 15+ |

---

## PART 8: RECORDS, SEALED CLASSES, MODERN JAVA

### Q: What are Records (Java 16)?
Immutable data carriers:
```java
record Person(String name, int age) {}
// Auto-generates: canonical constructor, getters (name(), age()),
// equals(), hashCode(), toString()
```

### Q: Sealed Classes (Java 17)?
Restrict which classes can extend/implement:
```java
sealed interface Shape permits Circle, Rectangle, Triangle {}
// Enables exhaustive pattern matching switch
```

### Q: Pattern matching instanceof (Java 16)?
```java
if (obj instanceof String s && s.length() > 3) {
    System.out.println(s.toUpperCase()); // s already cast!
}
```

### Q: Switch expressions (Java 14)?
```java
String result = switch (day) {
    case MONDAY -> "Weekday";
    case SATURDAY, SUNDAY -> "Weekend";
    default -> throw new IllegalArgumentException();
};
```

### Q: Virtual Threads (Java 21)?
- Lightweight threads managed by JVM (not OS)
- Can create millions (vs thousands for platform threads)
- `Thread.ofVirtual().start(runnable)`
- `Executors.newVirtualThreadPerTaskExecutor()`

---

## TOP 50 TRICKY QUESTIONS

1. `String s = "a" + "b" + "c"` — how many objects? Just 1 (compiler optimizes to "abc")
2. Can we override `main()`? Yes, but JVM calls the specific signature.
3. Can constructor be private? Yes — Singleton pattern.
4. Can interface have constructor? No.
5. Can abstract class have constructor? Yes — called via super().
6. Is `++i` atomic? No — read + increment + write = 3 ops.
7. `System.gc()` guaranteed to run? No — just a hint to JVM.
8. Can we catch `Error`? Yes syntactically, but shouldn't.
9. `null instanceof Object`? Always `false` (no NPE!).
10. `int[] a = {1,2,3}; int[] b = a; b[0]=99;` — a[0]? 99! (arrays are references)
11. Can static method access instance variable? No.
12. What if `equals()` overridden but not `hashCode()`? HashMap/HashSet breaks!
13. `ArrayList<Integer> vs int[]` — which is faster? `int[]` (no boxing overhead)
14. Difference between `remove(int index)` and `remove(Object o)` in ArrayList? Overloaded methods.
15. `Collections.unmodifiableList()` vs `List.of()`? Both immutable, but `List.of()` doesn't allow null.
16. `CopyOnWriteArrayList` — when to use? Many reads, few writes (thread-safe read without locking).
17. `EnumSet` vs `HashSet`? EnumSet is bit-vector based, extremely fast for enum values.
18. `Optional.of(null)` throws? Yes — NPE. Use `Optional.ofNullable(null)`.
19. Is `Stream` reusable? No — once terminal operation called, stream is consumed.
20. `flatMap` vs `map`? map: one-to-one; flatMap: one-to-many (flattens nested streams).
21. `Collectors.toUnmodifiableList()` vs `Collectors.toList()`? Unmodifiable returns immutable list.
22. `parallelStream()` always faster? No — has overhead, good for CPU-intensive tasks on large data.
23. `ThreadLocal` — what is it? Per-thread variable. Each thread has own independent copy.
24. `ReentrantLock` vs `synchronized`? ReentrantLock: tryLock, fairness, interruptible, multiple conditions.
25. What is `happens-before`? Memory visibility guarantee — write A happens-before read B.
26. Difference between `wait()` and `park()`? `wait()` is Object method; `park()` is LockSupport (more flexible).
27. `String.format()` vs `printf()`? `format()` returns String; `printf()` prints directly.
28. `charAt()` vs `codePointAt()`? `charAt()` for BMP; `codePointAt()` for supplementary Unicode characters.
29. `String.valueOf(null)` vs `"" + null`? valueOf returns "null"; concat returns "null" too.
30. Inner class can access outer private members? Yes — member inner class has full access.
31. Static nested class vs inner class? Static: no outer instance needed; Inner: needs outer instance.
32. `getClass()` vs `instanceof`? `getClass()`: exact type; `instanceof`: includes subclasses.
33. `==` on two `Long` objects? Unsafe — use `.equals()`. Cache only for -128 to 127.
34. Can enum extend a class? No. Enum implicitly extends `java.lang.Enum`.
35. Can enum implement interface? Yes!
36. Difference between `Enum.values()` and `EnumSet.allOf()`? Both return all constants; `values()` returns array, `allOf()` returns EnumSet.
37. What is `transient`? Marks field to skip during serialization.
38. What is `serialVersionUID`? Version ID for serialization compatibility. Always define explicitly.
39. What is method hiding? Static methods in subclass hide (not override) parent static methods.
40. `default` method in interface — can it be overridden? Yes, in implementing class.
41. `private` method in interface (Java 9)? Yes — helper for default methods.
42. `var` restrictions? Local variables only, must have initializer, can't be null, no arrays directly.
43. `record` can extend class? No — records implicitly extend `java.lang.Record`.
44. `record` can implement interface? Yes!
45. Sealed class — what is `non-sealed`? Permits the subclass to be further extended freely.
46. What is `@FunctionalInterface`? Annotation to ensure only one abstract method. Compilation error if violated.
47. `Predicate.not()` (Java 11)? `Predicate.not(String::isBlank)` — negates a method reference predicate.
48. `String.lines()` (Java 11)? Returns `Stream<String>` of lines (splits on \n, \r, \r\n).
49. `Stream.toList()` (Java 16) vs `collect(toList())`? `toList()` returns unmodifiable list; `collect(toList())` returns modifiable.
50. Virtual threads vs reactive? Virtual: blocking code style (readable); Reactive: non-blocking callbacks (complex).

---

## JAVA INTERVIEW PATTERNS CHEAT SHEET

### Singleton (Thread-safe)
```java
enum Singleton { INSTANCE; public void doWork() {} }
```

### Builder
```java
class Pizza {
    private Pizza(Builder b) { ... }
    static class Builder {
        public Builder topping(String t) { ...; return this; }
        public Pizza build() { return new Pizza(this); }
    }
}
```

### Factory
```java
interface Shape { double area(); }
static Shape create(String type) {
    return switch(type) {
        case "circle" -> new Circle(5);
        case "rect"   -> new Rectangle(4,6);
        default -> throw new IllegalArgumentException(type);
    };
}
```

### Strategy via Lambda
```java
Function<List<Integer>, Integer> sumStrategy = list -> list.stream().mapToInt(Integer::intValue).sum();
Function<List<Integer>, Integer> maxStrategy = list -> list.stream().mapToInt(Integer::intValue).max().orElse(0);
```

### Observer via Java Events
```java
Map<String, List<Consumer<String>>> listeners = new HashMap<>();
void on(String event, Consumer<String> listener) { listeners.computeIfAbsent(event, k -> new ArrayList<>()).add(listener); }
void emit(String event, String data) { listeners.getOrDefault(event, List.of()).forEach(l -> l.accept(data)); }
```

---

*Good luck with your Java interviews! Practice the code, understand the concepts.*
