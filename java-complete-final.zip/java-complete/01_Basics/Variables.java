/**
 * TOPIC 01: Variables, Constants, Scope, var (Java 10+)
 * ======================================================
 * Variable kinds: local, instance (field), class (static), parameter
 * Naming: camelCase for vars/methods, UPPER_SNAKE for constants
 * var: inferred type (Java 10+), only for local variables
 * final: makes variable a constant (cannot reassign)
 * Scope: variables live from declaration to closing brace
 */
public class Variables {

    // Instance variable (each object has its own copy)
    int instanceVar = 100;

    // Class (static) variable (shared by all instances)
    static int classVar = 0;

    // Constants (static final)
    static final double GRAVITY        = 9.80665;
    static final int    MAX_STUDENTS   = 500;
    static final String APP_NAME       = "JavaLearn";

    public static void main(String[] args) {

        // ============================================================
        // LOCAL VARIABLES
        // ============================================================
        System.out.println("=== Local Variables ===");
        int localInt   = 42;
        double localPi = 3.14159;
        String localStr = "Hello";
        boolean flag = true;

        System.out.println("localInt=" + localInt + " localPi=" + localPi);
        System.out.println("localStr=" + localStr + " flag=" + flag);

        // ============================================================
        // var - Local Type Inference (Java 10+)
        // ============================================================
        System.out.println("\n=== var Type Inference (Java 10+) ===");
        var number = 42;             // inferred: int
        var text   = "Java";         // inferred: String
        var pi     = 3.14;           // inferred: double
        var list   = new java.util.ArrayList<String>(); // inferred: ArrayList<String>

        System.out.println("var number: " + number + " -> " + ((Object)number).getClass().getSimpleName());
        System.out.println("var text:   " + text   + " -> String");
        System.out.println("var pi:     " + pi     + " -> double");
        list.add("Java"); list.add("Python");
        System.out.println("var list:   " + list   + " -> ArrayList");

        // var limitations:
        // var x;            // ERROR: cannot infer type without initializer
        // var y = null;     // ERROR: cannot infer type from null
        // var z = {1,2,3};  // ERROR: cannot use array initializer

        // ============================================================
        // CONSTANTS (final)
        // ============================================================
        System.out.println("\n=== Constants (final) ===");
        System.out.println("GRAVITY     = " + GRAVITY);
        System.out.println("MAX_STUDENTS= " + MAX_STUDENTS);
        System.out.println("APP_NAME    = " + APP_NAME);

        // Local final
        final int MAX_RETRY = 3;
        System.out.println("MAX_RETRY   = " + MAX_RETRY);
        // MAX_RETRY = 5; // ERROR: cannot assign value to final variable

        // ============================================================
        // SCOPE
        // ============================================================
        System.out.println("\n=== Variable Scope ===");
        int outer = 10;
        {
            int inner = 20;  // only exists in this block
            System.out.println("Inside block: outer=" + outer + " inner=" + inner);
        }
        // inner not accessible here
        System.out.println("Outside block: outer=" + outer);

        // Loop variable scope
        for (int i = 0; i < 3; i++) {
            int loopLocal = i * 2;  // created fresh each iteration
            System.out.println("  i=" + i + " loopLocal=" + loopLocal);
        }
        // i and loopLocal not accessible here

        // ============================================================
        // INSTANCE vs STATIC
        // ============================================================
        System.out.println("\n=== Instance vs Class Variables ===");
        Variables obj1 = new Variables();
        Variables obj2 = new Variables();
        obj1.instanceVar = 111;
        obj2.instanceVar = 222;
        classVar = 999;  // shared by all

        System.out.println("obj1.instanceVar = " + obj1.instanceVar);  // 111
        System.out.println("obj2.instanceVar = " + obj2.instanceVar);  // 222
        System.out.println("obj1.classVar    = " + obj1.classVar);     // 999 (shared)
        System.out.println("obj2.classVar    = " + obj2.classVar);     // 999 (shared)

        // ============================================================
        // NAMING CONVENTIONS EXAMPLES
        // ============================================================
        System.out.println("\n=== Naming Conventions ===");
        // Variables: camelCase
        int studentAge  = 20;
        String firstName = "Alice";
        // Constants: UPPER_SNAKE_CASE
        final double TAX_RATE = 0.18;
        // Classes: PascalCase (StudentRecord, HttpClient)
        // Methods: camelCase (calculateTotal, getName)
        // Packages: lowercase (com.example.util)

        System.out.println("studentAge=" + studentAge + " firstName=" + firstName + " TAX_RATE=" + TAX_RATE);

        // ============================================================
        // MULTIPLE ASSIGNMENT & SWAP
        // ============================================================
        System.out.println("\n=== Assignment Tricks ===");
        int a, b, c;
        a = b = c = 5;  // chained assignment
        System.out.println("a=b=c=5: " + a + " " + b + " " + c);

        // Swap without temp variable
        int x = 10, y = 20;
        x = x + y;  y = x - y;  x = x - y;
        System.out.println("After swap: x=" + x + " y=" + y);

        // XOR swap
        int p = 100, q = 200;
        p ^= q;  q ^= p;  p ^= q;
        System.out.println("XOR swap: p=" + p + " q=" + q);
    }
}
