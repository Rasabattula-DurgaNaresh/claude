/**
 * ============================================================
 * TOPIC 01: Hello World & Program Structure
 * ============================================================
 * KEY CONCEPTS:
 *   public class   -> class accessible anywhere, filename must match
 *   main method    -> JVM entry point
 *   System.out     -> standard output (PrintStream)
 *   println/print/printf -> output methods
 *   args           -> command-line arguments array
 *   // and /* */   -> single and multi-line comments
 *   Javadoc /**    -> documentation comments
 * ============================================================
 */
public class HelloWorld {

    /** Application version */
    static final String VERSION = "21.0";

    /**
     * Main entry point.
     * @param args command-line arguments
     */
    public static void main(String[] args) {

        // ================================================================
        // 1. OUTPUT METHODS
        // ================================================================
        System.out.println("=== Output Methods ===");

        System.out.println("println: adds newline automatically");
        System.out.print("print: no newline |");
        System.out.print(" continues here\n");

        // printf: formatted output (like C)
        // %s=String, %d=int, %f=float, %n=newline, %b=boolean
        System.out.printf("Name: %-10s | Age: %3d | GPA: %.2f%n", "Alice", 20, 9.25);
        System.out.printf("Hex: %X | Oct: %o | Sci: %e%n", 255, 255, 123456.789);

        // String.format returns a String (doesn't print)
        String formatted = String.format("Java %s | Math.PI = %.10f", VERSION, Math.PI);
        System.out.println(formatted);

        // ================================================================
        // 2. COMMAND-LINE ARGUMENTS
        // ================================================================
        System.out.println("\n=== Command-Line Args ===");
        System.out.println("Number of args: " + args.length);
        for (int i = 0; i < args.length; i++) {
            System.out.printf("  args[%d] = \"%s\"%n", i, args[i]);
        }
        // To test: java HelloWorld Alice Bob Charlie

        // ================================================================
        // 3. JAVA PROGRAM STRUCTURE FACTS
        // ================================================================
        System.out.println("\n=== Java Facts ===");
        System.out.println("Java is: compiled + interpreted");
        System.out.println("  .java  -> javac -> .class (bytecode) -> JVM -> execution");
        System.out.println("Platform independent: WORA (Write Once Run Anywhere)");
        System.out.println("Strongly typed: all variables need declared types");
        System.out.println("Case-sensitive: Hello != hello != HELLO");

        // ================================================================
        // 4. TEXT BLOCKS (Java 15+)
        // ================================================================
        System.out.println("\n=== Text Block (Java 15+) ===");
        String json = """
                {
                  "course": "Java Programming",
                  "level": "Complete",
                  "version": "%s"
                }
                """.formatted(VERSION);
        System.out.println(json);

        // ================================================================
        // 5. IDENTIFIERS & KEYWORDS
        // ================================================================
        System.out.println("=== Java Keywords (sample) ===");
        // abstract assert boolean break byte case catch char class const
        // continue default do double else enum extends final finally float
        // for goto if implements import instanceof int interface long native
        // new package private protected public return short static strictfp
        // super switch synchronized this throw throws transient try var void
        // volatile while (53 reserved keywords total)
        System.out.println("Java has 53 reserved keywords");
        System.out.println("Identifiers: letters, digits, _, $ (cannot start with digit)");

        System.out.println("\nProgram completed successfully!");
    }
}
