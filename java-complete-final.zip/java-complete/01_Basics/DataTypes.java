/**
 * TOPIC 01: Primitive Data Types - Complete Reference
 * ====================================================
 * Java 8 primitive types: byte short int long float double boolean char
 * Reference types: String, arrays, objects (stored on heap)
 * Wrapper classes: Byte Short Integer Long Float Double Boolean Character
 */
public class DataTypes {
    public static void main(String[] args) {

        // ============================================================
        // INTEGER TYPES
        // ============================================================
        System.out.println("=== INTEGER TYPES ===");
        byte   b1 = 127;              // 1 byte, -128 to 127
        byte   b2 = -128;
        short  s1 = 32_767;           // 2 bytes, -32768 to 32767 (underscore OK)
        int    i1 = 2_147_483_647;    // 4 bytes, ~±2.1 billion
        long   l1 = 9_223_372_036_854_775_807L; // 8 bytes, 'L' required

        System.out.printf("byte   : min=%d, max=%d, size=%d bits%n", Byte.MIN_VALUE, Byte.MAX_VALUE, Byte.SIZE);
        System.out.printf("short  : min=%d, max=%d%n", Short.MIN_VALUE, Short.MAX_VALUE);
        System.out.printf("int    : min=%d, max=%d%n", Integer.MIN_VALUE, Integer.MAX_VALUE);
        System.out.printf("long   : min=%d, max=%d%n", Long.MIN_VALUE, Long.MAX_VALUE);
        System.out.println("Values: byte=" + b1 + " short=" + s1 + " int=" + i1 + " long=" + l1);

        // Literals: decimal, hex, octal, binary
        int decimal = 255;
        int hex     = 0xFF;        // hexadecimal
        int octal   = 0377;        // octal
        int binary  = 0b11111111;  // binary (Java 7+)
        System.out.printf("255 = dec:%d hex:%d oct:%d bin:%d (all same)%n", decimal, hex, octal, binary);

        // ============================================================
        // FLOATING POINT TYPES
        // ============================================================
        System.out.println("\n=== FLOATING POINT TYPES ===");
        float  f1 = 3.14f;             // 4 bytes, ~7 decimal digits, 'f' required
        float  f2 = 3.14F;             // uppercase F also ok
        double d1 = 3.141592653589793; // 8 bytes, ~15 decimal digits (default)
        double d2 = 1.5e10;            // scientific notation = 15,000,000,000
        double d3 = Double.MAX_VALUE;
        double d4 = Double.MIN_VALUE;  // smallest positive non-zero

        System.out.printf("float  : %.7f (precision ~7 digits)%n", f1);
        System.out.printf("double : %.15f (precision ~15 digits)%n", d1);
        System.out.printf("1.5e10 : %.0f%n", d2);
        System.out.printf("Double.MAX: %e%n", d3);

        // Special float/double values
        System.out.println("\nSpecial values:");
        System.out.println("1.0/0.0      = " + (1.0/0.0));      // Infinity
        System.out.println("-1.0/0.0     = " + (-1.0/0.0));     // -Infinity
        System.out.println("0.0/0.0      = " + (0.0/0.0));      // NaN
        System.out.println("isNaN(NaN)   = " + Double.isNaN(0.0/0.0));
        System.out.println("isInfinite   = " + Double.isInfinite(1.0/0.0));

        // Floating point precision issue!
        System.out.println("\nPrecision gotcha:");
        System.out.println("0.1 + 0.2 = " + (0.1 + 0.2));       // Not 0.3!
        System.out.printf("Rounded:   %.1f%n", 0.1 + 0.2);       // Use rounding

        // ============================================================
        // BOOLEAN
        // ============================================================
        System.out.println("\n=== BOOLEAN ===");
        boolean isJavaFun  = true;
        boolean isFinished = false;
        boolean result     = isJavaFun && !isFinished;
        System.out.println("isJavaFun   = " + isJavaFun);
        System.out.println("isFinished  = " + isFinished);
        System.out.println("fun&&!done  = " + result);
        System.out.println("Boolean.TRUE= " + Boolean.TRUE);

        // ============================================================
        // CHAR
        // ============================================================
        System.out.println("\n=== CHAR ===");
        char c1 = 'A';
        char c2 = 65;              // numeric value for 'A'
        char c3 = '\u0041';        // unicode for 'A'
        char c4 = '\n';            // newline escape
        char c5 = '\'';            // escaped single quote
        char c6 = '\t';            // tab

        System.out.println("char 'A' three ways: " + c1 + " " + c2 + " " + c3);
        System.out.println("Escape sequences: newline=\\n tab=\\t quote=\\'");

        // Char arithmetic
        System.out.println("\nChar arithmetic:");
        for (char ch = 'A'; ch <= 'Z'; ch++) System.out.print(ch);
        System.out.println();
        for (char ch = 'a'; ch <= 'z'; ch++) System.out.print(ch);
        System.out.println();
        System.out.println("'A' + 1 = " + (char)('A' + 1)); // 'B'
        System.out.println("'Z' - 'A' = " + ('Z' - 'A'));   // 25

        // ============================================================
        // TYPE CASTING
        // ============================================================
        System.out.println("\n=== TYPE CASTING ===");

        // Widening (implicit/automatic): no data loss
        // byte -> short -> int -> long -> float -> double
        byte  wb = 42;
        short ws = wb;    // byte -> short (widening)
        int   wi = ws;    // short -> int
        long  wl = wi;    // int -> long
        float wf = wl;    // long -> float (may lose precision for large values)
        double wd = wf;   // float -> double
        System.out.println("Widening: " + wb + " -> " + ws + " -> " + wi + " -> " + wl + " -> " + wf + " -> " + wd);

        // Narrowing (explicit cast required): may lose data
        double nd = 9.99;
        int    ni = (int) nd;    // truncates decimal, NOT rounds!
        System.out.println("\nNarrowing:");
        System.out.println("(int) 9.99 = " + ni);           // 9 not 10!
        System.out.println("(int) -9.99 = " + (int)-9.99);  // -9

        byte overflow = (byte) 130;  // 130 > 127, wraps: 130-256 = -126
        System.out.println("(byte) 130 = " + overflow);     // -126!

        // Char <-> int
        char  ch = 'Z';
        int   ascii = ch;               // char -> int (widening)
        char  back  = (char)(ascii + 1); // int -> char (narrowing)
        System.out.println("'Z' as int = " + ascii + " | next char = " + back);

        // ============================================================
        // WRAPPER CLASSES
        // ============================================================
        System.out.println("\n=== WRAPPER CLASSES ===");
        Integer iObj = 42;                  // autoboxing
        int     iPrim = iObj;              // unboxing
        String  iStr  = Integer.toString(255, 16); // "ff" (base 16)

        System.out.println("Autoboxed Integer: " + iObj);
        System.out.println("Unboxed int:       " + iPrim);
        System.out.println("255 in hex:        " + iStr);
        System.out.println("parseInt(\"123\"):   " + Integer.parseInt("123"));
        System.out.println("parseLong(\"9B\",16):" + Long.parseLong("9B", 16)); // hex to long
        System.out.println("Integer.bitCount(255): " + Integer.bitCount(255)); // number of 1 bits
        System.out.println("Integer.reverse(1): " + Integer.reverse(1));
        System.out.println("Integer.highestOneBit(100): " + Integer.highestOneBit(100));

        // ============================================================
        // DEFAULT VALUES (in class fields)
        // ============================================================
        System.out.println("\n=== DEFAULT VALUES (class fields) ===");
        System.out.println("byte/short/int/long -> 0");
        System.out.println("float/double -> 0.0");
        System.out.println("boolean -> false");
        System.out.println("char -> '\\u0000' (null char)");
        System.out.println("Object/String/array -> null");
        System.out.println("Note: local variables have NO default (must init before use)");
    }
}
