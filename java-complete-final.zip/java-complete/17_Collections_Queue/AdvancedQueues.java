/**
 * TOPIC 17: Advanced Queues & Concurrent Collections
 * ====================================================
 * BlockingQueue    : thread-safe, blocks on put/take
 * ConcurrentHashMap: thread-safe map (no global lock)
 * CopyOnWriteArrayList: reads don't lock
 * LinkedBlockingQueue  : bounded/unbounded blocking queue
 * ArrayBlockingQueue   : bounded blocking queue
 * Producer-Consumer pattern using BlockingQueue
 */
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

public class AdvancedQueues {

    // Producer-Consumer using BlockingQueue
    static class Producer implements Runnable {
        private final BlockingQueue<String> queue;
        private final String name;
        private final int count;

        public Producer(BlockingQueue<String> q, String name, int count) {
            this.queue=q; this.name=name; this.count=count;
        }

        @Override public void run() {
            try {
                for (int i = 1; i <= count; i++) {
                    String item = name + "-item-" + i;
                    queue.put(item);
                    System.out.println("  [PRODUCE] " + item + " | queue=" + queue.size());
                    Thread.sleep(50);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    static class Consumer implements Runnable {
        private final BlockingQueue<String> queue;
        private final String name;
        private final AtomicInteger count;
        private volatile boolean running = true;

        public Consumer(BlockingQueue<String> q, String name, AtomicInteger c) {
            this.queue=q; this.name=name; this.count=c;
        }

        public void stop() { running = false; }

        @Override public void run() {
            try {
                while (running || !queue.isEmpty()) {
                    String item = queue.poll(200, TimeUnit.MILLISECONDS);
                    if (item != null) {
                        System.out.println("  [CONSUME] " + name + " got: " + item);
                        count.incrementAndGet();
                        Thread.sleep(80);
                    }
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public static void main(String[] args) throws Exception {

        // ============================================================
        // ARRAYBLOCKINGQUEUE (bounded)
        // ============================================================
        System.out.println("=== ARRAYBLOCKINGQUEUE (bounded, capacity=3) ===");
        BlockingQueue<String> bounded = new ArrayBlockingQueue<>(3);
        bounded.put("A"); bounded.put("B"); bounded.put("C");
        System.out.println("Queue full: " + bounded);
        System.out.println("offer(D, 100ms): " + bounded.offer("D", 100, TimeUnit.MILLISECONDS)); // false (full)
        System.out.println("take: " + bounded.take());
        bounded.put("D");
        System.out.println("After take+put: " + bounded);

        // ============================================================
        // LINKEDBLOCKINGQUEUE (unbounded by default)
        // ============================================================
        System.out.println("\n=== LINKEDBLOCKINGQUEUE ===");
        BlockingQueue<Integer> unbounded = new LinkedBlockingQueue<>();
        for (int i = 1; i <= 5; i++) unbounded.put(i);
        System.out.println("Queue: " + unbounded);
        System.out.println("peek: " + unbounded.peek() + " | size: " + unbounded.size());

        // ============================================================
        // PRIORITY BLOCKING QUEUE
        // ============================================================
        System.out.println("\n=== PRIORITYBLOCKINGQUEUE ===");
        PriorityBlockingQueue<Integer> pbq = new PriorityBlockingQueue<>();
        pbq.addAll(Arrays.asList(5, 1, 8, 3, 2, 7));
        System.out.println("PBQ: " + pbq + " | peek: " + pbq.peek());
        System.out.print("Poll order: ");
        while (!pbq.isEmpty()) System.out.print(pbq.poll() + " ");
        System.out.println();

        // ============================================================
        // PRODUCER-CONSUMER PATTERN
        // ============================================================
        System.out.println("\n=== PRODUCER-CONSUMER PATTERN ===");
        BlockingQueue<String> sharedQueue = new LinkedBlockingQueue<>(5);
        AtomicInteger consumed = new AtomicInteger(0);

        Consumer c = new Consumer(sharedQueue, "Consumer-1", consumed);
        Thread producerThread = new Thread(new Producer(sharedQueue, "Producer", 6));
        Thread consumerThread = new Thread(c);

        consumerThread.start();
        producerThread.start();

        producerThread.join();
        Thread.sleep(500); // let consumer finish
        c.stop();
        consumerThread.join();
        System.out.println("Total consumed: " + consumed.get());

        // ============================================================
        // CONCURRENTHASHMAP
        // ============================================================
        System.out.println("\n=== CONCURRENTHASHMAP ===");
        ConcurrentHashMap<String, AtomicInteger> wordCount = new ConcurrentHashMap<>();
        String[] words = "the quick brown fox the lazy dog the fox".split(" ");

        // Thread-safe counting
        ExecutorService pool = Executors.newFixedThreadPool(4);
        CountDownLatch latch = new CountDownLatch(words.length);
        for (String word : words) {
            pool.submit(() -> {
                wordCount.computeIfAbsent(word, k -> new AtomicInteger(0)).incrementAndGet();
                latch.countDown();
            });
        }
        latch.await();
        pool.shutdown();
        System.out.println("Word counts: " + new TreeMap<>(wordCount));

        // ConcurrentHashMap operations
        ConcurrentHashMap<String, Integer> map = new ConcurrentHashMap<>();
        map.put("A", 1); map.put("B", 2); map.put("C", 3);
        map.putIfAbsent("D", 4);
        map.compute("A", (k, v) -> v == null ? 1 : v + 10);
        System.out.println("ConcurrentHashMap: " + map);

        // ============================================================
        // COPYONWRITEARRAYLIST
        // ============================================================
        System.out.println("\n=== COPYONWRITEARRAYLIST ===");
        List<String> cowList = new CopyOnWriteArrayList<>(Arrays.asList("A", "B", "C"));
        System.out.println("Initial: " + cowList);

        // Safe to iterate and modify concurrently
        for (String s : cowList) {
            if (s.equals("B")) cowList.add("D");  // no ConcurrentModificationException!
            System.out.print(s + " ");
        }
        System.out.println("\nAfter concurrent modify: " + cowList);

        // ============================================================
        // DELAQUEUE (elements available after delay)
        // ============================================================
        System.out.println("\n=== DELAYQUEUE (timed tasks) ===");
        // Simulating with scheduled executor instead
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(2);
        System.out.println("Scheduling tasks...");
        scheduler.schedule(() -> System.out.println("  Task 1 runs at 100ms"), 100, TimeUnit.MILLISECONDS);
        scheduler.schedule(() -> System.out.println("  Task 2 runs at 200ms"), 200, TimeUnit.MILLISECONDS);
        scheduler.schedule(() -> System.out.println("  Task 3 runs at 300ms"), 300, TimeUnit.MILLISECONDS);
        Thread.sleep(500);
        scheduler.shutdown();

        System.out.println("\nAll queue examples complete!");
    }
}
