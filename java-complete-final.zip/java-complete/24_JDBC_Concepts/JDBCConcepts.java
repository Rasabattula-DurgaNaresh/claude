/**
 * TOPIC 24: JDBC - Java Database Connectivity Concepts
 * ======================================================
 * NOTE: This file uses an in-memory H2-like simulation (no real DB needed).
 * In real projects: add JDBC driver jar and use actual connection string.
 *
 * JDBC Steps:
 *   1. Load Driver (Class.forName or auto via ServiceLoader)
 *   2. Get Connection (DriverManager.getConnection)
 *   3. Create Statement / PreparedStatement / CallableStatement
 *   4. Execute Query / Update
 *   5. Process ResultSet
 *   6. Close resources (try-with-resources)
 *
 * Statement:         simple, but SQL injection risk
 * PreparedStatement: parameterized, safe, compiled once
 * CallableStatement: stored procedures
 * Transaction:       commit/rollback for data consistency
 * Connection Pool:   HikariCP, DBCP (reuse connections)
 */
import java.sql.*;
import java.util.*;

public class JDBCConcepts {

    // ============================================================
    // JDBC SIMULATION (without real DB for portability)
    // ============================================================
    // In real code:
    //   String url  = "jdbc:mysql://localhost:3306/mydb";
    //   String user = "root";
    //   String pass = "password";
    //   Connection conn = DriverManager.getConnection(url, user, pass);

    // DAO Pattern
    record Student(int id, String name, int age, double gpa, String dept) {}

    static class StudentDAO {
        // Simulate in-memory database
        private List<Student> database = new ArrayList<>(Arrays.asList(
            new Student(1, "Alice",   22, 9.2, "CS"),
            new Student(2, "Bob",     24, 8.5, "ECE"),
            new Student(3, "Charlie", 21, 9.5, "CS"),
            new Student(4, "Diana",   23, 8.8, "ME"),
            new Student(5, "Eve",     22, 9.1, "CS")
        ));
        private int nextId = 6;

        // CREATE
        public Student insert(String name, int age, double gpa, String dept) {
            Student s = new Student(nextId++, name, age, gpa, dept);
            database.add(s);
            System.out.println("  INSERT: " + s);
            return s;
        }

        // READ
        public Optional<Student> findById(int id) {
            return database.stream().filter(s -> s.id() == id).findFirst();
        }

        public List<Student> findAll() { return new ArrayList<>(database); }

        public List<Student> findByDept(String dept) {
            return database.stream().filter(s -> s.dept().equals(dept)).toList();
        }

        public List<Student> findByGpaAbove(double minGpa) {
            return database.stream().filter(s -> s.gpa() >= minGpa).toList();
        }

        // UPDATE
        public boolean updateGpa(int id, double newGpa) {
            for (int i = 0; i < database.size(); i++) {
                if (database.get(i).id() == id) {
                    Student old = database.get(i);
                    database.set(i, new Student(old.id(), old.name(), old.age(), newGpa, old.dept()));
                    System.out.println("  UPDATE id=" + id + " gpa=" + old.gpa() + " -> " + newGpa);
                    return true;
                }
            }
            return false;
        }

        // DELETE
        public boolean delete(int id) {
            boolean removed = database.removeIf(s -> s.id() == id);
            if (removed) System.out.println("  DELETE id=" + id);
            return removed;
        }

        // AGGREGATE queries
        public double averageGpa()     { return database.stream().mapToDouble(Student::gpa).average().orElse(0); }
        public Student topStudent()    { return database.stream().max(Comparator.comparingDouble(Student::gpa)).orElseThrow(); }
        public long countByDept(String d) { return database.stream().filter(s -> s.dept().equals(d)).count(); }
        public Map<String, Long> countPerDept() {
            Map<String, Long> result = new LinkedHashMap<>();
            database.stream().forEach(s -> result.merge(s.dept(), 1L, Long::sum));
            return result;
        }
    }

    // Transaction simulation
    static class TransactionManager {
        private List<String> log = new ArrayList<>();
        private boolean inTransaction = false;
        private List<String> rollbackData = new ArrayList<>();

        public void beginTransaction() {
            inTransaction = true; rollbackData.clear();
            System.out.println("  BEGIN TRANSACTION");
        }

        public void execute(String sql) {
            if (!inTransaction) throw new IllegalStateException("Not in transaction!");
            rollbackData.add(sql);
            log.add(sql);
            System.out.println("  EXEC: " + sql);
            // Simulate failure for DROP
            if (sql.contains("INVALID")) throw new RuntimeException("SQL Error: invalid statement");
        }

        public void commit() {
            inTransaction = false;
            System.out.println("  COMMIT (" + rollbackData.size() + " statements committed)");
        }

        public void rollback() {
            inTransaction = false;
            System.out.println("  ROLLBACK (" + rollbackData.size() + " statements rolled back)");
            rollbackData.clear();
        }

        public List<String> getLog() { return Collections.unmodifiableList(log); }
    }

    // Connection Pool simulation
    static class ConnectionPool {
        private final Queue<String> pool = new LinkedList<>();
        private final int MAX_SIZE;
        private int created = 0;

        public ConnectionPool(int size) {
            MAX_SIZE = size;
            for (int i = 1; i <= size; i++) pool.offer("Conn-" + i);
            System.out.println("Pool created with " + size + " connections");
        }

        public synchronized String acquire() {
            if (pool.isEmpty()) throw new RuntimeException("No connections available!");
            String conn = pool.poll();
            System.out.println("  Acquired: " + conn + " (available: " + pool.size() + ")");
            return conn;
        }

        public synchronized void release(String conn) {
            pool.offer(conn);
            System.out.println("  Released: " + conn + " (available: " + pool.size() + ")");
        }

        public int available() { return pool.size(); }
    }

    public static void main(String[] args) {

        // ============================================================
        // JDBC OVERVIEW
        // ============================================================
        System.out.println("=== JDBC OVERVIEW ===");
        System.out.println("Steps to use JDBC:");
        System.out.println("  1. Add JDBC driver to classpath (e.g., mysql-connector-java.jar)");
        System.out.println("  2. Connection conn = DriverManager.getConnection(url, user, pass)");
        System.out.println("  3. PreparedStatement ps = conn.prepareStatement(sql)");
        System.out.println("  4. ps.setString(1, value); ps.setInt(2, num);");
        System.out.println("  5. ResultSet rs = ps.executeQuery(); // SELECT");
        System.out.println("     int rows = ps.executeUpdate();    // INSERT/UPDATE/DELETE");
        System.out.println("  6. while (rs.next()) { rs.getString(1); rs.getInt(2); }");
        System.out.println("  7. rs.close(); ps.close(); conn.close(); // or try-with-resources");

        System.out.println("\n=== REAL JDBC EXAMPLE PATTERN ===");
        System.out.println("""
            // Real JDBC code:
            String sql = "SELECT id, name, salary FROM employees WHERE dept = ?";
            try (Connection conn = DriverManager.getConnection(url, user, pass);
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                
                ps.setString(1, "Engineering");  // parameterized (safe!)
                
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        int id = rs.getInt("id");
                        String name = rs.getString("name");
                        double salary = rs.getDouble("salary");
                        System.out.println(id + " " + name + " " + salary);
                    }
                }
            } // auto-closed!
            """);

        // ============================================================
        // DAO PATTERN DEMO
        // ============================================================
        System.out.println("=== DAO PATTERN ===");
        StudentDAO dao = new StudentDAO();

        System.out.println("All students:");
        dao.findAll().forEach(s -> System.out.printf("  [%d] %-10s age=%d gpa=%.1f dept=%s%n",
            s.id(), s.name(), s.age(), s.gpa(), s.dept()));

        System.out.println("\nCRUD Operations:");
        dao.insert("Frank", 23, 8.7, "ECE");
        dao.insert("Grace", 21, 9.4, "CS");
        System.out.println("findById(3): " + dao.findById(3));
        System.out.println("findByDept(CS): " + dao.findByDept("CS").stream()
            .map(Student::name).toList());
        System.out.println("findByGpa>=9.0: " + dao.findByGpaAbove(9.0).stream()
            .map(Student::name).toList());
        dao.updateGpa(2, 8.9);
        dao.delete(4);

        System.out.println("\nAggregations:");
        System.out.printf("Average GPA:  %.2f%n", dao.averageGpa());
        System.out.println("Top student:  " + dao.topStudent().name());
        System.out.println("CS count:     " + dao.countByDept("CS"));
        System.out.println("Count/dept:   " + dao.countPerDept());

        // ============================================================
        // TRANSACTIONS
        // ============================================================
        System.out.println("\n=== TRANSACTIONS ===");
        TransactionManager tm = new TransactionManager();

        // Successful transaction
        System.out.println("Successful transaction:");
        tm.beginTransaction();
        try {
            tm.execute("UPDATE accounts SET balance = balance - 1000 WHERE id = 1");
            tm.execute("UPDATE accounts SET balance = balance + 1000 WHERE id = 2");
            tm.execute("INSERT INTO audit_log VALUES (NOW(), 'transfer', 1000)");
            tm.commit();
        } catch (Exception e) {
            tm.rollback();
            System.out.println("Error: " + e.getMessage());
        }

        // Failed transaction
        System.out.println("\nFailed transaction (auto-rollback):");
        tm.beginTransaction();
        try {
            tm.execute("UPDATE stock SET qty = qty - 5 WHERE product_id = 100");
            tm.execute("THIS IS INVALID SQL");  // will throw
            tm.execute("INSERT INTO orders VALUES (...)");
            tm.commit();
        } catch (Exception e) {
            System.out.println("Error caught: " + e.getMessage());
            tm.rollback();
        }

        // ============================================================
        // CONNECTION POOL
        // ============================================================
        System.out.println("\n=== CONNECTION POOL ===");
        ConnectionPool pool = new ConnectionPool(3);

        String c1 = pool.acquire();
        String c2 = pool.acquire();
        System.out.println("Available: " + pool.available());
        pool.release(c1);
        pool.release(c2);
        System.out.println("Available after release: " + pool.available());

        System.out.println("\n=== JDBC BEST PRACTICES ===");
        System.out.println("1. Always use PreparedStatement (never string concat for SQL!)");
        System.out.println("2. Always close connections in finally or try-with-resources");
        System.out.println("3. Use connection pools (HikariCP) in production");
        System.out.println("4. Use transactions for multiple related operations");
        System.out.println("5. Set appropriate fetch size for large result sets");
        System.out.println("6. Use batch updates for bulk inserts/updates");
        System.out.println("7. Consider ORM (Hibernate/JPA) for complex mappings");
        System.out.println("8. Never expose raw SQL errors to end users");
    }
}
