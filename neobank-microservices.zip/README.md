# NeoBank — Banking Microservices Platform

> **Production-ready** banking platform built with **Spring Boot 3.2** · **Java 17** · **React 18**

---

## 🏗️ Architecture

```
React 18 (port 3000)
    │ nginx proxy
    ▼
API Gateway (port 8080)  ← JWT auth · Circuit breaker · Rate limiting
    │
    ├── Customer Service  (8081) · PostgreSQL customerdb
    ├── Account Service   (8082) · PostgreSQL accountdb
    ├── Transaction Service (8083) · PostgreSQL transactiondb
    ├── Loan Service      (8084) · PostgreSQL loandb
    └── Notification Service (8085) · PostgreSQL notificationdb

Eureka Discovery (8761)
Apache Kafka  ── event bus between services
Redis         ── rate limiting, caching
PostgreSQL    ── one database per service
```

## 🚀 Quick Start

### 1. Prerequisites
- Java 17+, Maven 3.9+
- Docker & Docker Compose
- Node.js 20+

### 2. Generate JWT Secret
```bash
make jwt-secret
```

### 3. Configure environment
```bash
cp .env.example .env
# Edit .env and paste your JWT_SECRET
```

### 4. Build backend
```bash
make build-backend
```

### 5. Start all services
```bash
make up
```

### 6. Install & run frontend (dev mode)
```bash
cd frontend
npm install --legacy-peer-deps
npm start
```

## 📋 Service URLs

| Service | URL |
|---------|-----|
| Frontend | http://localhost:3000 |
| API Gateway | http://localhost:8080 |
| Swagger UI | http://localhost:8080/swagger-ui.html |
| Eureka Dashboard | http://localhost:8761 |
| Customer Service | http://localhost:8081 |
| Account Service | http://localhost:8082 |
| Transaction Service | http://localhost:8083 |
| Loan Service | http://localhost:8084 |
| Notification Service | http://localhost:8085 |

## 🔑 API Endpoints

### Authentication
```
POST /api/v1/customers/register   Register new customer
POST /api/v1/auth/login           Login → JWT token
GET  /api/v1/customers/me         Get profile
PUT  /api/v1/customers/me         Update profile
POST /api/v1/customers/me/change-password
```

### Accounts
```
POST   /api/v1/accounts           Open account
GET    /api/v1/accounts           List my accounts
GET    /api/v1/accounts/{id}      Account details
POST   /api/v1/accounts/{id}/freeze
POST   /api/v1/accounts/{id}/unfreeze
POST   /api/v1/accounts/{id}/close
```

### Transactions
```
POST /api/v1/transactions/transfer   Transfer funds
GET  /api/v1/transactions            History (paginated)
GET  /api/v1/transactions/{ref}      By reference
GET  /api/v1/transactions/statement  Date range statement
```

### Loans
```
POST /api/v1/loans/apply    Apply for loan
GET  /api/v1/loans          My loans
GET  /api/v1/loans/{id}     Loan details
POST /api/v1/loans/{id}/approve
POST /api/v1/loans/{id}/reject
```

## 🛠️ Tech Stack

**Backend**
- Spring Boot 3.2.3 · Spring Cloud 2023.0.1
- Spring Security · JWT (jjwt 0.12.5)
- Spring Data JPA · Flyway · PostgreSQL 16
- Apache Kafka · Redis
- Netflix Eureka · Spring Cloud Gateway
- Springdoc OpenAPI 2.4 · Micrometer / Prometheus

**Frontend**
- React 18 · React Router v6
- Zustand · Axios · Recharts
- Lucide React · react-hot-toast

**Infrastructure**
- Docker / Docker Compose
- Nginx (reverse proxy + SPA serving)

## 🔐 Security Features
- BCrypt password hashing (cost 12)
- JWT access tokens (1h) + refresh tokens (7d)
- Account lockout after 5 failed attempts (30 min)
- Gateway-level JWT validation
- Pessimistic locking on account operations
- Per-service security filter chains

## 📦 Module Structure
```
neobank/
├── backend/bank-parent/
│   ├── bank-common/         Shared DTOs, exceptions, JWT
│   ├── bank-discovery/      Eureka server (port 8761)
│   ├── bank-gateway/        API Gateway (port 8080)
│   ├── bank-customer/       Customer & Auth (port 8081)
│   ├── bank-account/        Accounts (port 8082)
│   ├── bank-transaction/    Transfers & history (port 8083)
│   ├── bank-loan/           Loan management (port 8084)
│   └── bank-notification/   Kafka + email (port 8085)
├── frontend/                React 18 SPA
├── infrastructure/
│   ├── nginx/nginx.conf
│   └── sql/init.sql
├── docker-compose.yml
├── .env.example
├── Makefile
└── README.md
```