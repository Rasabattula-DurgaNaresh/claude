package com.bank.common.dto;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*; import java.time.LocalDateTime;
@Data @Builder @JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiResponse<T> {
  @Builder.Default private boolean success = true;
  private String message; private T data; private String errorCode;
  @Builder.Default private LocalDateTime timestamp = LocalDateTime.now();
  public static <T> ApiResponse<T> ok(T data) { return ApiResponse.<T>builder().data(data).build(); }
  public static <T> ApiResponse<T> ok(String msg, T data) { return ApiResponse.<T>builder().message(msg).data(data).build(); }
  public static <T> ApiResponse<T> error(String msg, String code) { return ApiResponse.<T>builder().success(false).message(msg).errorCode(code).build(); }
}