package com.bank.common.exception;
import com.bank.common.dto.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*; import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.validation.FieldError; import org.springframework.web.bind.*;
import org.springframework.web.bind.annotation.*; import java.util.*;
@Slf4j @RestControllerAdvice
public class GlobalExceptionHandler {
  @ExceptionHandler(BankException.class)
  public ResponseEntity<ApiResponse<Void>> handle(BankException ex) {
    log.warn("[{}] {}", ex.getErrorCode(), ex.getMessage());
    return ResponseEntity.status(ex.getStatus()).body(ApiResponse.error(ex.getMessage(), ex.getErrorCode()));
  }
  @ExceptionHandler(MethodArgumentNotValidException.class)
  public ResponseEntity<ApiResponse<Map<String,String>>> handleValidation(MethodArgumentNotValidException ex) {
    Map<String,String> errors = new LinkedHashMap<>();
    ex.getBindingResult().getAllErrors().forEach(e -> errors.put(((FieldError)e).getField(), e.getDefaultMessage()));
    return ResponseEntity.badRequest().body(ApiResponse.<Map<String,String>>builder().success(false)
      .message("Validation failed").data(errors).errorCode("VALIDATION_ERROR").build());
  }
  @ExceptionHandler(BadCredentialsException.class)
  public ResponseEntity<ApiResponse<Void>> handleBadCreds(BadCredentialsException ex) {
    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(ApiResponse.error("Invalid credentials","UNAUTHORIZED"));
  }
  @ExceptionHandler(AccessDeniedException.class)
  public ResponseEntity<ApiResponse<Void>> handleForbidden(AccessDeniedException ex) {
    return ResponseEntity.status(HttpStatus.FORBIDDEN).body(ApiResponse.error("Access denied","FORBIDDEN"));
  }
  @ExceptionHandler(Exception.class)
  public ResponseEntity<ApiResponse<Void>> handleGeneral(Exception ex) {
    log.error("Unhandled exception", ex);
    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ApiResponse.error("Internal server error","INTERNAL_ERROR"));
  }
}