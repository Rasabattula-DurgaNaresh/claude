package com.bank.common.exception;
import lombok.Getter; import org.springframework.http.HttpStatus;
@Getter
public class BankException extends RuntimeException {
  private final String errorCode; private final HttpStatus status;
  public BankException(String msg, String errorCode, HttpStatus status) { super(msg); this.errorCode=errorCode; this.status=status; }
  public static BankException notFound(String r, String id) { return new BankException(r+" not found: "+id,"NOT_FOUND",HttpStatus.NOT_FOUND); }
  public static BankException badRequest(String msg, String code) { return new BankException(msg,code,HttpStatus.BAD_REQUEST); }
  public static BankException conflict(String msg, String code) { return new BankException(msg,code,HttpStatus.CONFLICT); }
  public static BankException forbidden(String msg) { return new BankException(msg,"FORBIDDEN",HttpStatus.FORBIDDEN); }
  public static BankException insufficientFunds() { return new BankException("Insufficient funds","INSUFFICIENT_FUNDS",HttpStatus.UNPROCESSABLE_ENTITY); }
}