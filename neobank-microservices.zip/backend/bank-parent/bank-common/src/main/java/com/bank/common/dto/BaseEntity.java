package com.bank.common.dto;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.UuidGenerator;
import org.springframework.data.annotation.*;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import java.time.LocalDateTime;
@Getter @Setter @MappedSuperclass @EntityListeners(AuditingEntityListener.class)
public abstract class BaseEntity {
  @Id @UuidGenerator @Column(name="id",updatable=false,nullable=false,length=36) private String id;
  @CreatedDate @Column(name="created_at",updatable=false) private LocalDateTime createdAt;
  @LastModifiedDate @Column(name="updated_at") private LocalDateTime updatedAt;
  @Version @Column(name="version") private Long version = 0L;
}