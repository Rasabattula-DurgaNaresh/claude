package com.bank.common.security;
import io.jsonwebtoken.*; import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value; import org.springframework.stereotype.Component;
import javax.crypto.SecretKey; import java.util.*; import java.util.Base64;
@Slf4j @Component
public class JwtService {
  @Value("${bank.jwt.secret}") private String secret;
  @Value("${bank.jwt.access-expiry:3600000}") private long accessExpiry;
  @Value("${bank.jwt.refresh-expiry:604800000}") private long refreshExpiry;
  private SecretKey key() { return Keys.hmacShaKeyFor(Base64.getDecoder().decode(secret)); }
  public String generateAccess(String sub, String customerId, String role) {
    return Jwts.builder().subject(sub)
      .claims(Map.of("customerId",customerId,"role",role,"type","ACCESS"))
      .issuedAt(new Date()).expiration(new Date(System.currentTimeMillis()+accessExpiry))
      .signWith(key()).compact();
  }
  public String generateRefresh(String sub) {
    return Jwts.builder().subject(sub).claim("type","REFRESH")
      .issuedAt(new Date()).expiration(new Date(System.currentTimeMillis()+refreshExpiry))
      .signWith(key()).compact();
  }
  public Claims claims(String token) { return Jwts.parser().verifyWith(key()).build().parseSignedClaims(token).getPayload(); }
  public String subject(String token) { return claims(token).getSubject(); }
  public String role(String token)    { return (String)claims(token).get("role"); }
  public String customerId(String token) { return (String)claims(token).get("customerId"); }
  public boolean valid(String token) { try { claims(token); return true; } catch(JwtException|IllegalArgumentException e) { return false; } }
}