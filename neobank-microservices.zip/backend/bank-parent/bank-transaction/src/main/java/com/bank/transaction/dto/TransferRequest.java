package com.bank.transaction.dto;
import jakarta.validation.constraints.*; import lombok.Data; import java.math.BigDecimal;
@Data public class TransferRequest {
  @NotBlank private String fromAccountId;
  @NotBlank private String toAccountNumber;
  @NotNull @DecimalMin("0.01") @DecimalMax("999999.99") private BigDecimal amount;
  @NotBlank @Size(min=3,max=3) private String currency;
  @Size(max=500) private String description;
}