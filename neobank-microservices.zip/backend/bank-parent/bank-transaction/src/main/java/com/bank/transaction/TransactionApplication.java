package com.bank.transaction;
import org.springframework.boot.SpringApplication; import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients; import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
@SpringBootApplication @EnableJpaAuditing @EnableFeignClients @ComponentScan(basePackages={"com.bank.transaction","com.bank.common"})
public class TransactionApplication { public static void main(String[] a) { SpringApplication.run(TransactionApplication.class,a); } }