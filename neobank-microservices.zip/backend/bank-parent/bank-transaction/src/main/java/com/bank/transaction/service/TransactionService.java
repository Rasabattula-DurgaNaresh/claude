package com.bank.transaction.service;
import com.bank.common.dto.PageResponse; import com.bank.common.exception.BankException;
import com.bank.transaction.dto.*; import com.bank.transaction.entity.Transaction;
import com.bank.transaction.repository.TransactionRepository;
import lombok.RequiredArgsConstructor; import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.*; import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service; import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import java.math.BigDecimal; import java.time.*; import java.util.*; import java.util.stream.*;
@Slf4j @Service @RequiredArgsConstructor
public class TransactionService {
  private final TransactionRepository repo; private final KafkaTemplate<String,Object> kafka;
  private final RestTemplate rest; private static final BigDecimal FEE=new BigDecimal("1.00");

  @Transactional public TransactionDto transfer(String cid, TransferRequest req) {
    String ref=genRef();
    Transaction tx=Transaction.builder().reference(ref).customerId(cid).fromAccountId(req.getFromAccountId())
      .type(Transaction.Type.TRANSFER).amount(req.getAmount()).fee(FEE).currency(req.getCurrency())
      .description(req.getDescription()).build();
    tx=repo.save(tx);
    try {
      tx.setStatus(Transaction.Status.PROCESSING); repo.save(tx);
      rest.postForObject("http://bank-account/api/v1/accounts/internal/debit",
        Map.of("accountId",req.getFromAccountId(),"amount",req.getAmount().add(FEE)),Void.class);
      rest.postForObject("http://bank-account/api/v1/accounts/internal/credit",
        Map.of("accountId",req.getToAccountNumber(),"amount",req.getAmount()),Void.class);
      tx.setStatus(Transaction.Status.COMPLETED); tx.setProcessedAt(LocalDateTime.now()); tx=repo.save(tx);
      kafka.send("transaction-events",tx.getId(),Map.of("eventType","TRANSFER_COMPLETED","txId",tx.getId(),"customerId",cid,"amount",req.getAmount()));
    } catch(Exception e) {
      log.error("Transfer failed [{}]: {}",ref,e.getMessage());
      tx.setStatus(Transaction.Status.FAILED); tx.setFailedReason(e.getMessage()); repo.save(tx);
      throw BankException.badRequest("Transfer failed: "+e.getMessage(),"TRANSFER_FAILED"); }
    return toDto(tx);
  }

  @Transactional(readOnly=true) public PageResponse<TransactionDto> history(String cid, int page, int size) {
    return PageResponse.of(repo.findByCustomerIdOrderByCreatedAtDesc(cid,PageRequest.of(page,size)).map(this::toDto)); }

  @Transactional(readOnly=true) public TransactionDto byRef(String ref, String cid) {
    Transaction tx=repo.findByReference(ref).orElseThrow(()->BankException.notFound("Transaction",ref));
    if(!tx.getCustomerId().equals(cid)) throw BankException.forbidden("Not your transaction");
    return toDto(tx); }

  @Transactional(readOnly=true) public List<TransactionDto> statement(String cid, LocalDateTime from, LocalDateTime to) {
    return repo.findByCustomerIdAndCreatedAtBetween(cid,from,to).stream().map(this::toDto).collect(Collectors.toList()); }

  private TransactionDto toDto(Transaction t){return TransactionDto.builder().id(t.getId()).reference(t.getReference())
    .type(t.getType().name()).status(t.getStatus().name()).amount(t.getAmount()).fee(t.getFee()).currency(t.getCurrency())
    .fromAccountNumber(t.getFromAccountNumber()).toAccountNumber(t.getToAccountNumber())
    .description(t.getDescription()).category(t.getCategory()).balanceAfter(t.getBalanceAfter())
    .processedAt(t.getProcessedAt()).createdAt(t.getCreatedAt()).build();}
  private String genRef(){String r;do{r="TXN"+System.currentTimeMillis()+new Random().nextInt(9999);}while(repo.existsByReference(r));return r;}
}