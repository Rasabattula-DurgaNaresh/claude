package com.bank.transaction.dto;
import lombok.Builder; import lombok.Data; import java.math.BigDecimal; import java.time.LocalDateTime;
@Data @Builder public class TransactionDto {
  private String id,reference,type,status,currency,fromAccountNumber,toAccountNumber,description,category;
  private BigDecimal amount,fee,balanceAfter; private LocalDateTime processedAt,createdAt;
}