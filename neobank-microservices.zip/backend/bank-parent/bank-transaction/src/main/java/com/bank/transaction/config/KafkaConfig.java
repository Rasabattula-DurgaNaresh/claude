package com.bank.transaction.config;
import org.apache.kafka.clients.producer.ProducerConfig; import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value; import org.springframework.context.annotation.*;
import org.springframework.kafka.core.*; import org.springframework.kafka.support.serializer.JsonSerializer; import java.util.Map;
@Configuration public class KafkaConfig {
  @Value("${spring.kafka.bootstrap-servers}") private String s;
  @Bean public ProducerFactory<String,Object> pf(){return new DefaultKafkaProducerFactory<>(Map.of(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,s,ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,StringSerializer.class,ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,JsonSerializer.class));}
  @Bean public KafkaTemplate<String,Object> kt(){return new KafkaTemplate<>(pf());}
}