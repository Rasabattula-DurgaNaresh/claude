package com.bank.transaction.entity;
import com.bank.common.dto.BaseEntity; import jakarta.persistence.*;
import lombok.*; import java.math.BigDecimal; import java.time.LocalDateTime;
@Entity @Table(name="transactions",indexes={
  @Index(name="idx_tx_ref",columnList="reference",unique=true),
  @Index(name="idx_tx_from",columnList="from_account_id"),
  @Index(name="idx_tx_to",columnList="to_account_id"),
  @Index(name="idx_tx_customer",columnList="customer_id"),
  @Index(name="idx_tx_status",columnList="status"),
  @Index(name="idx_tx_created",columnList="created_at")})
@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class Transaction extends BaseEntity {
  @Column(name="reference",length=50,unique=true,nullable=false) private String reference;
  @Column(name="customer_id",length=36,nullable=false) private String customerId;
  @Column(name="from_account_id",length=36) private String fromAccountId;
  @Column(name="to_account_id",length=36) private String toAccountId;
  @Column(name="from_account_number",length=20) private String fromAccountNumber;
  @Column(name="to_account_number",length=20) private String toAccountNumber;
  @Enumerated(EnumType.STRING) @Column(name="type",length=30,nullable=false) private Type type;
  @Column(name="amount",precision=19,scale=2,nullable=false) private BigDecimal amount;
  @Column(name="fee",precision=19,scale=2) @Builder.Default private BigDecimal fee=BigDecimal.ZERO;
  @Column(name="currency",length=3) @Builder.Default private String currency="USD";
  @Enumerated(EnumType.STRING) @Column(name="status",length=20) @Builder.Default private Status status=Status.PENDING;
  @Column(name="description",length=500) private String description;
  @Column(name="category",length=100) private String category;
  @Column(name="processed_at") private LocalDateTime processedAt;
  @Column(name="failed_reason",length=500) private String failedReason;
  @Column(name="balance_after",precision=19,scale=2) private BigDecimal balanceAfter;
  public enum Type { TRANSFER,DEPOSIT,WITHDRAWAL,PAYMENT,REFUND,FEE,INTEREST }
  public enum Status { PENDING,PROCESSING,COMPLETED,FAILED,REVERSED }
}