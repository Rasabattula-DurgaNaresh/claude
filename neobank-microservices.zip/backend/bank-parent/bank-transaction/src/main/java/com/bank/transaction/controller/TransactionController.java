package com.bank.transaction.controller;
import com.bank.common.dto.*; import com.bank.transaction.dto.*; import com.bank.transaction.service.TransactionService;
import io.swagger.v3.oas.annotations.Operation; import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid; import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat; import org.springframework.http.*;
import org.springframework.web.bind.annotation.*; import java.time.LocalDateTime; import java.util.List;
@RestController @RequestMapping("/api/v1/transactions") @RequiredArgsConstructor
@Tag(name="Transaction Service",description="Fund transfers and transaction history")
public class TransactionController {
  private final TransactionService svc;
  @PostMapping("/transfer") @Operation(summary="Transfer funds between accounts")
  public ResponseEntity<ApiResponse<TransactionDto>> transfer(@RequestHeader("X-Customer-Id") String cid, @Valid @RequestBody TransferRequest req) {
    return ResponseEntity.status(201).body(ApiResponse.ok("Transfer initiated",svc.transfer(cid,req))); }
  @GetMapping @Operation(summary="Transaction history (paginated)")
  public ResponseEntity<ApiResponse<PageResponse<TransactionDto>>> history(@RequestHeader("X-Customer-Id") String cid,
      @RequestParam(defaultValue="0") int page, @RequestParam(defaultValue="20") int size) {
    return ResponseEntity.ok(ApiResponse.ok(svc.history(cid,page,size))); }
  @GetMapping("/{reference}") @Operation(summary="Get transaction by reference")
  public ResponseEntity<ApiResponse<TransactionDto>> get(@PathVariable String reference, @RequestHeader("X-Customer-Id") String cid) {
    return ResponseEntity.ok(ApiResponse.ok(svc.byRef(reference,cid))); }
  @GetMapping("/statement") @Operation(summary="Account statement for date range")
  public ResponseEntity<ApiResponse<List<TransactionDto>>> statement(@RequestHeader("X-Customer-Id") String cid,
      @RequestParam @DateTimeFormat(iso=DateTimeFormat.ISO.DATE_TIME) LocalDateTime from,
      @RequestParam @DateTimeFormat(iso=DateTimeFormat.ISO.DATE_TIME) LocalDateTime to) {
    return ResponseEntity.ok(ApiResponse.ok(svc.statement(cid,from,to))); }
}