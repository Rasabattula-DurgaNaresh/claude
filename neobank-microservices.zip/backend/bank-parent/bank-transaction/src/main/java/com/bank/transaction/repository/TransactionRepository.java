package com.bank.transaction.repository;
import com.bank.transaction.entity.Transaction; import org.springframework.data.domain.*;
import org.springframework.data.jpa.repository.*; import org.springframework.stereotype.Repository;
import java.time.LocalDateTime; import java.util.*; import java.util.Optional;
@Repository public interface TransactionRepository extends JpaRepository<Transaction,String> {
  Optional<Transaction> findByReference(String reference);
  Page<Transaction> findByCustomerIdOrderByCreatedAtDesc(String cid, Pageable p);
  List<Transaction> findByCustomerIdAndCreatedAtBetween(String cid, LocalDateTime from, LocalDateTime to);
  boolean existsByReference(String ref);
}