package com.bank.transaction.config;
import com.bank.common.security.JwtService; import jakarta.servlet.*; import jakarta.servlet.http.*; import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority; import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter; import java.io.IOException; import java.util.List;
@RequiredArgsConstructor public class JwtFilter extends OncePerRequestFilter {
  private final JwtService jwt;
  @Override protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain) throws ServletException, IOException {
    String auth=req.getHeader("Authorization");
    if(auth!=null&&auth.startsWith("Bearer ")){String t=auth.substring(7);if(jwt.valid(t))
      SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(jwt.subject(t),null,List.of(new SimpleGrantedAuthority("ROLE_"+jwt.role(t)))));}
    chain.doFilter(req,res); }
}