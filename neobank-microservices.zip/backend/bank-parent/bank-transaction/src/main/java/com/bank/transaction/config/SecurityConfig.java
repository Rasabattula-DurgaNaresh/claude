package com.bank.transaction.config;
import com.bank.common.security.JwtService; import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.*; import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy; import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
@Configuration @EnableWebSecurity @RequiredArgsConstructor
public class SecurityConfig {
  private final JwtService jwtService;
  @Bean public SecurityFilterChain chain(HttpSecurity http) throws Exception {
    return http.csrf(AbstractHttpConfigurer::disable)
      .sessionManagement(s->s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
      .authorizeHttpRequests(a->a.requestMatchers("/actuator/**","/v3/api-docs/**","/api/v1/transactions/internal/**").permitAll().anyRequest().authenticated())
      .addFilterBefore(new JwtFilter(jwtService), UsernamePasswordAuthenticationFilter.class).build(); }
}