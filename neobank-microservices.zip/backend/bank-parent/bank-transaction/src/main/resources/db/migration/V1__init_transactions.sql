CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE TABLE transactions (
  id                  VARCHAR(36)   PRIMARY KEY DEFAULT gen_random_uuid()::text,
  reference           VARCHAR(50)   UNIQUE NOT NULL,
  customer_id         VARCHAR(36)   NOT NULL,
  from_account_id     VARCHAR(36),
  to_account_id       VARCHAR(36),
  from_account_number VARCHAR(20),
  to_account_number   VARCHAR(20),
  type                VARCHAR(30)   NOT NULL,
  amount              NUMERIC(19,2) NOT NULL,
  fee                 NUMERIC(19,2) DEFAULT 0,
  currency            VARCHAR(3)    NOT NULL DEFAULT 'USD',
  status              VARCHAR(20)   NOT NULL DEFAULT 'PENDING',
  description         VARCHAR(500),
  category            VARCHAR(100),
  processed_at        TIMESTAMP,
  failed_reason       VARCHAR(500),
  balance_after       NUMERIC(19,2),
  created_at          TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at          TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  version             BIGINT        NOT NULL DEFAULT 0
);
CREATE INDEX idx_tx_customer ON transactions(customer_id);
CREATE INDEX idx_tx_status   ON transactions(status);
CREATE INDEX idx_tx_created  ON transactions(created_at DESC);