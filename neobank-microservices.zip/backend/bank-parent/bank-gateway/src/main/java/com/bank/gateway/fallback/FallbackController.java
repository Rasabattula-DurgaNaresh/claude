package com.bank.gateway.fallback;
import com.bank.common.dto.ApiResponse;
import org.springframework.web.bind.annotation.*; import reactor.core.publisher.Mono;
@RestController
public class FallbackController {
  @RequestMapping("/fallback")
  public Mono<ApiResponse<Void>> fallback() {
    return Mono.just(ApiResponse.error("Service temporarily unavailable. Please try again later.","SERVICE_UNAVAILABLE"));
  }
}