package com.bank.gateway.filter;
import com.bank.common.security.JwtService;
import lombok.RequiredArgsConstructor; import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.gateway.filter.*; import org.springframework.core.Ordered;
import org.springframework.http.*; import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher; import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono; import java.util.List;
@Slf4j @Component @RequiredArgsConstructor
public class JwtAuthFilter implements GlobalFilter, Ordered {
  private final JwtService jwt;
  private final AntPathMatcher m = new AntPathMatcher();
  private static final List<String> PUBLIC = List.of(
    "/api/v1/auth/**","/api/v1/customers/register",
    "/actuator/**","/v3/api-docs/**","/swagger-ui/**","/webjars/**");
  @Override
  public Mono<Void> filter(ServerWebExchange ex, GatewayFilterChain chain) {
    String path = ex.getRequest().getURI().getPath();
    if (PUBLIC.stream().anyMatch(p -> m.match(p, path))) return chain.filter(ex);
    String auth = ex.getRequest().getHeaders().getFirst(HttpHeaders.AUTHORIZATION);
    if (auth == null || !auth.startsWith("Bearer ")) {
      ex.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED); return ex.getResponse().setComplete(); }
    String token = auth.substring(7);
    if (!jwt.valid(token)) {
      ex.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED); return ex.getResponse().setComplete(); }
    try {
      var mutated = ex.getRequest().mutate()
        .header("X-Customer-Id", jwt.customerId(token))
        .header("X-Username",    jwt.subject(token))
        .header("X-User-Role",   jwt.role(token)).build();
      return chain.filter(ex.mutate().request(mutated).build());
    } catch (Exception e) {
      ex.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED); return ex.getResponse().setComplete(); }
  }
  @Override public int getOrder() { return -100; }
}