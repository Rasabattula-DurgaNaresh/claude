package com.bank.customer.repository;
import com.bank.customer.entity.Customer;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;
import java.util.Optional;
@Repository
public interface CustomerRepository extends JpaRepository<Customer,String> {
  Optional<Customer> findByUsernameOrEmail(String u, String e);
  Optional<Customer> findByEmail(String email);
  boolean existsByEmail(String email);
  boolean existsByUsername(String username);
  boolean existsByNationalId(String id);
  @Modifying @Query("UPDATE Customer c SET c.failedAttempts=c.failedAttempts+1 WHERE c.id=:id")
  void incFailedAttempts(String id);
  @Modifying @Query("UPDATE Customer c SET c.failedAttempts=0,c.lockedUntil=null WHERE c.id=:id")
  void resetAttempts(String id);
}