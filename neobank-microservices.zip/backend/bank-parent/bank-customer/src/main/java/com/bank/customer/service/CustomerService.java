package com.bank.customer.service;
import com.bank.common.exception.BankException; import com.bank.common.security.JwtService;
import com.bank.customer.dto.*; import com.bank.customer.entity.Customer;
import com.bank.customer.repository.CustomerRepository;
import lombok.RequiredArgsConstructor; import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service; import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime; import java.util.Map;
@Slf4j @Service @RequiredArgsConstructor
public class CustomerService {
  private final CustomerRepository repo; private final PasswordEncoder enc;
  private final JwtService jwt; private final KafkaTemplate<String,Object> kafka;
  private static final int MAX_ATTEMPTS = 5, LOCK_MINS = 30;

  @Transactional
  public AuthResponse register(RegisterRequest req) {
    if (repo.existsByEmail(req.getEmail())) throw BankException.conflict("Email already registered","EMAIL_EXISTS");
    if (repo.existsByUsername(req.getUsername())) throw BankException.conflict("Username taken","USERNAME_EXISTS");
    Customer c = Customer.builder().username(req.getUsername()).email(req.getEmail())
      .passwordHash(enc.encode(req.getPassword())).firstName(req.getFirstName())
      .lastName(req.getLastName()).phoneNumber(req.getPhoneNumber())
      .nationalId(req.getNationalId()).dateOfBirth(req.getDateOfBirth()).address(req.getAddress()).build();
    c = repo.save(c);
    kafka.send("customer-events", c.getId(), Map.of("eventType","REGISTERED","customerId",c.getId(),"email",c.getEmail(),"name",c.fullName()));
    return buildAuth(c);
  }

  @Transactional
  public AuthResponse login(LoginRequest req) {
    Customer c = repo.findByUsernameOrEmail(req.getUsername(), req.getUsername())
      .orElseThrow(() -> new BadCredentialsException("Invalid credentials"));
    if (c.isLocked()) throw BankException.badRequest("Account locked for "+LOCK_MINS+" min","ACCOUNT_LOCKED");
    if (c.getStatus() != Customer.Status.ACTIVE) throw BankException.badRequest("Account is "+c.getStatus(),"INACTIVE");
    if (!enc.matches(req.getPassword(), c.getPasswordHash())) {
      repo.incFailedAttempts(c.getId());
      if (c.getFailedAttempts()+1 >= MAX_ATTEMPTS) { c.setLockedUntil(LocalDateTime.now().plusMinutes(LOCK_MINS)); repo.save(c); }
      throw new BadCredentialsException("Invalid credentials"); }
    repo.resetAttempts(c.getId());
    c.setLastLogin(LocalDateTime.now()); repo.save(c);
    return buildAuth(c);
  }

  @Transactional(readOnly=true)
  public CustomerDto profile(String id) { return toDto(find(id)); }

  @Transactional
  public CustomerDto updateProfile(String id, Map<String,String> req) {
    Customer c = find(id);
    if (req.containsKey("firstName")) c.setFirstName(req.get("firstName"));
    if (req.containsKey("lastName"))  c.setLastName(req.get("lastName"));
    if (req.containsKey("phoneNumber")) c.setPhoneNumber(req.get("phoneNumber"));
    if (req.containsKey("address"))   c.setAddress(req.get("address"));
    return toDto(repo.save(c));
  }

  @Transactional
  public void changePassword(String id, ChangePasswordRequest req) {
    Customer c = find(id);
    if (!enc.matches(req.getCurrentPassword(), c.getPasswordHash()))
      throw BankException.badRequest("Current password incorrect","WRONG_PASSWORD");
    c.setPasswordHash(enc.encode(req.getNewPassword())); repo.save(c);
  }

  private Customer find(String id) { return repo.findById(id).orElseThrow(()->BankException.notFound("Customer",id)); }
  private CustomerDto toDto(Customer c) {
    return CustomerDto.builder().id(c.getId()).username(c.getUsername()).email(c.getEmail())
      .firstName(c.getFirstName()).lastName(c.getLastName()).phoneNumber(c.getPhoneNumber())
      .role(c.getRole().name()).status(c.getStatus().name()).kycStatus(c.getKycStatus().name())
      .lastLogin(c.getLastLogin()).createdAt(c.getCreatedAt()).build();
  }
  private AuthResponse buildAuth(Customer c) {
    return AuthResponse.builder()
      .accessToken(jwt.generateAccess(c.getUsername(),c.getId(),c.getRole().name()))
      .refreshToken(jwt.generateRefresh(c.getUsername()))
      .tokenType("Bearer").expiresIn(3600L).customer(toDto(c)).build();
  }
}