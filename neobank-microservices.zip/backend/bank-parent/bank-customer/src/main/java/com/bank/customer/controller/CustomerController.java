package com.bank.customer.controller;
import com.bank.common.dto.ApiResponse; import com.bank.customer.dto.*;
import com.bank.customer.service.CustomerService;
import io.swagger.v3.oas.annotations.Operation; import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid; import lombok.RequiredArgsConstructor;
import org.springframework.http.*; import org.springframework.web.bind.annotation.*;
import java.util.Map;
@RestController @RequiredArgsConstructor
@Tag(name="Customer & Auth",description="Registration, authentication, and profile management")
public class CustomerController {
  private final CustomerService svc;

  @PostMapping("/api/v1/customers/register")
  @Operation(summary="Register new customer")
  public ResponseEntity<ApiResponse<AuthResponse>> register(@Valid @RequestBody RegisterRequest req) {
    return ResponseEntity.status(201).body(ApiResponse.ok("Account created successfully",svc.register(req)));
  }

  @PostMapping("/api/v1/auth/login")
  @Operation(summary="Customer login")
  public ResponseEntity<ApiResponse<AuthResponse>> login(@Valid @RequestBody LoginRequest req) {
    return ResponseEntity.ok(ApiResponse.ok(svc.login(req)));
  }

  @GetMapping("/api/v1/customers/me")
  @Operation(summary="Get my profile")
  public ResponseEntity<ApiResponse<CustomerDto>> me(@RequestHeader("X-Customer-Id") String id) {
    return ResponseEntity.ok(ApiResponse.ok(svc.profile(id)));
  }

  @PutMapping("/api/v1/customers/me")
  @Operation(summary="Update profile")
  public ResponseEntity<ApiResponse<CustomerDto>> update(
      @RequestHeader("X-Customer-Id") String id, @RequestBody Map<String,String> req) {
    return ResponseEntity.ok(ApiResponse.ok("Profile updated",svc.updateProfile(id,req)));
  }

  @PostMapping("/api/v1/customers/me/change-password")
  @Operation(summary="Change password")
  public ResponseEntity<ApiResponse<Void>> changePw(
      @RequestHeader("X-Customer-Id") String id, @Valid @RequestBody ChangePasswordRequest req) {
    svc.changePassword(id,req); return ResponseEntity.ok(ApiResponse.ok("Password updated",null));
  }
}