package com.bank.customer.dto;
import lombok.Builder; import lombok.Data;
@Data @Builder
public class AuthResponse {
  private String accessToken, refreshToken, tokenType; private long expiresIn;
  private CustomerDto customer;
}