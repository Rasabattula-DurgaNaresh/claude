package com.bank.customer;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.kafka.annotation.EnableKafka;
@SpringBootApplication @EnableJpaAuditing @EnableKafka
@ComponentScan(basePackages={"com.bank.customer","com.bank.common"})
public class CustomerApplication {
  public static void main(String[] args) { SpringApplication.run(CustomerApplication.class, args); }
}