package com.bank.customer.config;
import com.bank.common.security.JwtService; import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.*; import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
@Configuration @EnableWebSecurity @EnableMethodSecurity @RequiredArgsConstructor
public class SecurityConfig {
  private final JwtService jwtService;
  @Bean public PasswordEncoder encoder() { return new BCryptPasswordEncoder(12); }
  @Bean public SecurityFilterChain chain(HttpSecurity http) throws Exception {
    return http.csrf(AbstractHttpConfigurer::disable)
      .sessionManagement(s->s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
      .authorizeHttpRequests(a->a
        .requestMatchers(HttpMethod.POST,"/api/v1/customers/register","/api/v1/auth/login").permitAll()
        .requestMatchers("/actuator/**","/v3/api-docs/**","/swagger-ui/**").permitAll()
        .anyRequest().authenticated())
      .addFilterBefore(new JwtFilter(jwtService), UsernamePasswordAuthenticationFilter.class)
      .build(); }
}