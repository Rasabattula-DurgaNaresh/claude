package com.bank.customer.entity;
import com.bank.common.dto.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import java.time.*;
@Entity @Table(name="customers",indexes={
  @Index(name="idx_cust_email",columnList="email",unique=true),
  @Index(name="idx_cust_username",columnList="username",unique=true),
  @Index(name="idx_cust_phone",columnList="phone_number")})
@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class Customer extends BaseEntity {
  @Column(name="username",length=100,unique=true,nullable=false) private String username;
  @Column(name="email",length=255,unique=true,nullable=false) private String email;
  @Column(name="password_hash",length=255,nullable=false) private String passwordHash;
  @Column(name="first_name",length=100,nullable=false) private String firstName;
  @Column(name="last_name",length=100,nullable=false) private String lastName;
  @Column(name="phone_number",length=20) private String phoneNumber;
  @Column(name="national_id",length=50,unique=true) private String nationalId;
  @Column(name="date_of_birth") private LocalDate dateOfBirth;
  @Column(name="address",columnDefinition="TEXT") private String address;
  @Enumerated(EnumType.STRING) @Column(name="status",length=20) @Builder.Default
  private Status status = Status.ACTIVE;
  @Enumerated(EnumType.STRING) @Column(name="kyc_status",length=20) @Builder.Default
  private KycStatus kycStatus = KycStatus.PENDING;
  @Enumerated(EnumType.STRING) @Column(name="role",length=30) @Builder.Default
  private Role role = Role.CUSTOMER;
  @Column(name="failed_attempts") @Builder.Default private int failedAttempts = 0;
  @Column(name="locked_until") private LocalDateTime lockedUntil;
  @Column(name="last_login") private LocalDateTime lastLogin;
  public boolean isLocked() { return lockedUntil != null && lockedUntil.isAfter(LocalDateTime.now()); }
  public String fullName() { return firstName + " " + lastName; }
  public enum Status { ACTIVE, INACTIVE, SUSPENDED, CLOSED }
  public enum KycStatus { PENDING, SUBMITTED, VERIFIED, REJECTED }
  public enum Role { CUSTOMER, PREMIUM, CORPORATE, STAFF, ADMIN }
}