package com.bank.customer.dto;
import lombok.Builder; import lombok.Data; import java.time.LocalDateTime;
@Data @Builder
public class CustomerDto {
  private String id, username, email, firstName, lastName, phoneNumber, role, status, kycStatus;
  private LocalDateTime lastLogin, createdAt;
}