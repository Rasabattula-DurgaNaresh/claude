package com.bank.customer.config;
import com.bank.common.security.JwtService;
import jakarta.servlet.*; import jakarta.servlet.http.*; import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException; import java.util.List;
@RequiredArgsConstructor
public class JwtFilter extends OncePerRequestFilter {
  private final JwtService jwt;
  @Override protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain)
      throws ServletException, IOException {
    String auth = req.getHeader("Authorization");
    if (auth != null && auth.startsWith("Bearer ")) {
      String token = auth.substring(7);
      if (jwt.valid(token)) SecurityContextHolder.getContext().setAuthentication(
        new UsernamePasswordAuthenticationToken(jwt.subject(token), null,
          List.of(new SimpleGrantedAuthority("ROLE_"+jwt.role(token))))); }
    chain.doFilter(req,res); }
}