package com.bank.customer.dto;
import jakarta.validation.constraints.*;
import lombok.Data; import java.time.LocalDate;
@Data
public class RegisterRequest {
  @NotBlank @Size(min=3,max=100) private String username;
  @NotBlank @Email @Size(max=255) private String email;
  @NotBlank
  @Pattern(regexp="^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&]).{8,}$",
           message="Password needs uppercase, lowercase, digit & special character")
  private String password;
  @NotBlank @Size(min=2,max=100) private String firstName;
  @NotBlank @Size(min=2,max=100) private String lastName;
  @Pattern(regexp="^\\+?[1-9]\\d{1,14}$",message="Invalid phone number") private String phoneNumber;
  private String nationalId; private LocalDate dateOfBirth; private String address;
}