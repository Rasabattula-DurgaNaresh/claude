CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE TABLE customers (
  id            VARCHAR(36)  PRIMARY KEY DEFAULT gen_random_uuid()::text,
  username      VARCHAR(100) UNIQUE NOT NULL,
  email         VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  first_name    VARCHAR(100) NOT NULL,
  last_name     VARCHAR(100) NOT NULL,
  phone_number  VARCHAR(20),
  national_id   VARCHAR(50)  UNIQUE,
  date_of_birth DATE,
  address       TEXT,
  status        VARCHAR(20)  NOT NULL DEFAULT 'ACTIVE',
  kyc_status    VARCHAR(20)  NOT NULL DEFAULT 'PENDING',
  role          VARCHAR(30)  NOT NULL DEFAULT 'CUSTOMER',
  failed_attempts INT        NOT NULL DEFAULT 0,
  locked_until  TIMESTAMP,
  last_login    TIMESTAMP,
  created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  version       BIGINT       NOT NULL DEFAULT 0
);
CREATE INDEX idx_cust_email    ON customers(email);
CREATE INDEX idx_cust_username ON customers(username);
CREATE INDEX idx_cust_status   ON customers(status);