CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE TABLE accounts (
  id               VARCHAR(36)  PRIMARY KEY DEFAULT gen_random_uuid()::text,
  account_number   VARCHAR(20)  UNIQUE NOT NULL,
  customer_id      VARCHAR(36)  NOT NULL,
  account_type     VARCHAR(30)  NOT NULL,
  balance          NUMERIC(19,2) NOT NULL DEFAULT 0,
  available_balance NUMERIC(19,2) NOT NULL DEFAULT 0,
  currency         VARCHAR(3)   NOT NULL DEFAULT 'USD',
  interest_rate    NUMERIC(5,4) DEFAULT 0,
  status           VARCHAR(20)  NOT NULL DEFAULT 'ACTIVE',
  overdraft_limit  NUMERIC(19,2) DEFAULT 0,
  daily_limit      NUMERIC(19,2) DEFAULT 10000,
  opened_at        TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  closed_at        TIMESTAMP,
  iban             VARCHAR(34)  UNIQUE,
  created_at       TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  version          BIGINT       NOT NULL DEFAULT 0
);
CREATE INDEX idx_acc_customer ON accounts(customer_id);
CREATE INDEX idx_acc_type ON accounts(account_type);