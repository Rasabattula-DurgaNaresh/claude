package com.bank.account.controller;
import com.bank.account.dto.*; import com.bank.account.service.AccountService;
import com.bank.common.dto.ApiResponse;
import io.swagger.v3.oas.annotations.Operation; import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid; import lombok.RequiredArgsConstructor;
import org.springframework.http.*; import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/v1/accounts") @RequiredArgsConstructor
@Tag(name="Account Service",description="Bank account management")
public class AccountController {
  private final AccountService svc;
  @PostMapping @Operation(summary="Open new account")
  public ResponseEntity<ApiResponse<AccountDto>> open(@RequestHeader("X-Customer-Id") String cid, @Valid @RequestBody CreateAccountRequest req) {
    return ResponseEntity.status(201).body(ApiResponse.ok("Account opened",svc.open(cid,req))); }
  @GetMapping @Operation(summary="List my accounts")
  public ResponseEntity<ApiResponse<List<AccountDto>>> list(@RequestHeader("X-Customer-Id") String cid) {
    return ResponseEntity.ok(ApiResponse.ok(svc.listMine(cid))); }
  @GetMapping("/{id}") @Operation(summary="Get account details")
  public ResponseEntity<ApiResponse<AccountDto>> get(@PathVariable String id, @RequestHeader("X-Customer-Id") String cid) {
    return ResponseEntity.ok(ApiResponse.ok(svc.get(id,cid))); }
  @PostMapping("/{id}/freeze") @Operation(summary="Freeze account")
  public ResponseEntity<ApiResponse<AccountDto>> freeze(@PathVariable String id, @RequestHeader("X-Customer-Id") String cid) {
    return ResponseEntity.ok(ApiResponse.ok("Account frozen",svc.freeze(id,cid))); }
  @PostMapping("/{id}/unfreeze") @Operation(summary="Unfreeze account")
  public ResponseEntity<ApiResponse<AccountDto>> unfreeze(@PathVariable String id, @RequestHeader("X-Customer-Id") String cid) {
    return ResponseEntity.ok(ApiResponse.ok("Account unfrozen",svc.unfreeze(id,cid))); }
  @PostMapping("/{id}/close") @Operation(summary="Close account")
  public ResponseEntity<ApiResponse<AccountDto>> close(@PathVariable String id, @RequestHeader("X-Customer-Id") String cid) {
    return ResponseEntity.ok(ApiResponse.ok("Account closed",svc.close(id,cid))); }
  @PostMapping("/internal/debit")
  public ResponseEntity<Void> debit(@RequestBody java.util.Map<String,Object> req) {
    svc.debit((String)req.get("accountId"),new java.math.BigDecimal(req.get("amount").toString())); return ResponseEntity.ok().build(); }
  @PostMapping("/internal/credit")
  public ResponseEntity<Void> credit(@RequestBody java.util.Map<String,Object> req) {
    svc.credit((String)req.get("accountId"),new java.math.BigDecimal(req.get("amount").toString())); return ResponseEntity.ok().build(); }
}