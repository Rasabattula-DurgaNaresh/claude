package com.bank.account.service;
import com.bank.account.dto.*; import com.bank.account.entity.Account;
import com.bank.account.repository.AccountRepository; import com.bank.common.exception.BankException;
import lombok.RequiredArgsConstructor; import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate; import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal; import java.time.*; import java.util.*; import java.util.stream.*;
@Slf4j @Service @RequiredArgsConstructor
public class AccountService {
  private final AccountRepository repo; private final KafkaTemplate<String,Object> kafka;

  @Transactional public AccountDto open(String customerId, CreateAccountRequest req) {
    String num = genNumber(); String cur = req.getCurrency()!=null?req.getCurrency():"USD";
    BigDecimal init = req.getInitialDeposit()!=null?req.getInitialDeposit():BigDecimal.ZERO;
    Account a = Account.builder().accountNumber(num).customerId(customerId).accountType(req.getAccountType())
      .balance(init).availableBalance(init).currency(cur)
      .dailyLimit(req.getDailyLimit()!=null?req.getDailyLimit():new BigDecimal("10000"))
      .interestRate(defaultRate(req.getAccountType())).iban(genIban()).build();
    a = repo.save(a);
    kafka.send("account-events",a.getId(),Map.of("eventType","OPENED","accountId",a.getId(),"customerId",customerId,"number",num));
    return toDto(a);
  }

  @Transactional(readOnly=true) public List<AccountDto> listMine(String cid) {
    return repo.findByCustomerId(cid).stream().map(this::toDto).collect(Collectors.toList()); }

  @Transactional(readOnly=true) public AccountDto get(String id, String cid) {
    Account a=find(id); if(!a.getCustomerId().equals(cid)) throw BankException.forbidden("Not your account");
    return toDto(a); }

  @Transactional public void debit(String id, BigDecimal amount) {
    Account a=repo.findByIdLocked(id).orElseThrow(()->BankException.notFound("Account",id));
    if(a.getAvailableBalance().add(a.getOverdraftLimit()).compareTo(amount)<0) throw BankException.insufficientFunds();
    a.setBalance(a.getBalance().subtract(amount)); a.setAvailableBalance(a.getAvailableBalance().subtract(amount)); repo.save(a); }

  @Transactional public void credit(String id, BigDecimal amount) {
    Account a=repo.findByIdLocked(id).orElseThrow(()->BankException.notFound("Account",id));
    a.setBalance(a.getBalance().add(amount)); a.setAvailableBalance(a.getAvailableBalance().add(amount)); repo.save(a); }

  @Transactional public AccountDto freeze(String id, String cid) {
    Account a=find(id); if(!a.getCustomerId().equals(cid)) throw BankException.forbidden("Not your account");
    a.setStatus(Account.AccountStatus.FROZEN); return toDto(repo.save(a)); }

  @Transactional public AccountDto unfreeze(String id, String cid) {
    Account a=find(id); if(!a.getCustomerId().equals(cid)) throw BankException.forbidden("Not your account");
    a.setStatus(Account.AccountStatus.ACTIVE); return toDto(repo.save(a)); }

  @Transactional public AccountDto close(String id, String cid) {
    Account a=find(id); if(!a.getCustomerId().equals(cid)) throw BankException.forbidden("Not your account");
    if(a.getBalance().compareTo(BigDecimal.ZERO)!=0) throw BankException.badRequest("Balance must be zero to close","NON_ZERO_BALANCE");
    a.setStatus(Account.AccountStatus.CLOSED); a.setClosedAt(LocalDateTime.now()); return toDto(repo.save(a)); }

  private Account find(String id) { return repo.findById(id).orElseThrow(()->BankException.notFound("Account",id)); }
  private AccountDto toDto(Account a) {
    return AccountDto.builder().id(a.getId()).accountNumber(a.getAccountNumber()).customerId(a.getCustomerId())
      .accountType(a.getAccountType().name()).balance(a.getBalance()).availableBalance(a.getAvailableBalance())
      .currency(a.getCurrency()).interestRate(a.getInterestRate()).status(a.getStatus().name())
      .overdraftLimit(a.getOverdraftLimit()).dailyLimit(a.getDailyLimit()).iban(a.getIban())
      .openedAt(a.getOpenedAt()).createdAt(a.getCreatedAt()).build(); }
  private String genNumber() { String n; do{n="ACC"+System.currentTimeMillis()%9000000000L+1000000000L;}while(repo.existsByAccountNumber(n)); return n; }
  private String genIban() { return "US"+String.format("%02d",new Random().nextInt(99)+1)+"NEOBK"+System.currentTimeMillis()%10000000000000L; }
  private BigDecimal defaultRate(Account.AccountType t) { return switch(t){
    case SAVINGS->new BigDecimal("0.0350"); case FIXED_DEPOSIT->new BigDecimal("0.0550");
    case MONEY_MARKET->new BigDecimal("0.0450"); default->BigDecimal.ZERO;}; }
}