package com.bank.account.repository;
import com.bank.account.entity.Account; import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.*; import org.springframework.stereotype.Repository;
import java.util.*; import java.util.Optional;
@Repository public interface AccountRepository extends JpaRepository<Account,String> {
  List<Account> findByCustomerId(String customerId);
  Optional<Account> findByAccountNumber(String accountNumber);
  @Lock(LockModeType.PESSIMISTIC_WRITE) @Query("SELECT a FROM Account a WHERE a.id=:id")
  Optional<Account> findByIdLocked(String id);
  boolean existsByAccountNumber(String num);
}