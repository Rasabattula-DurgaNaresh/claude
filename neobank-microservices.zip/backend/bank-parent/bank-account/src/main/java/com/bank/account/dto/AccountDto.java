package com.bank.account.dto;
import lombok.Builder; import lombok.Data; import java.math.BigDecimal; import java.time.LocalDateTime;
@Data @Builder
public class AccountDto {
  private String id, accountNumber, customerId, accountType, currency, status, iban;
  private BigDecimal balance, availableBalance, interestRate, overdraftLimit, dailyLimit;
  private LocalDateTime openedAt, createdAt;
}