package com.bank.account;
import org.springframework.boot.SpringApplication; import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan; import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
@SpringBootApplication @EnableJpaAuditing @ComponentScan(basePackages={"com.bank.account","com.bank.common"})
public class AccountApplication { public static void main(String[] a) { SpringApplication.run(AccountApplication.class,a); } }