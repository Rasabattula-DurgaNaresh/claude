package com.bank.account.entity;
import com.bank.common.dto.BaseEntity; import jakarta.persistence.*;
import lombok.*; import java.math.BigDecimal; import java.time.LocalDateTime;
@Entity @Table(name="accounts",indexes={
  @Index(name="idx_acc_number",columnList="account_number",unique=true),
  @Index(name="idx_acc_customer",columnList="customer_id"),
  @Index(name="idx_acc_status",columnList="status")})
@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class Account extends BaseEntity {
  @Column(name="account_number",length=20,unique=true,nullable=false) private String accountNumber;
  @Column(name="customer_id",length=36,nullable=false) private String customerId;
  @Enumerated(EnumType.STRING) @Column(name="account_type",length=30,nullable=false) private AccountType accountType;
  @Column(name="balance",precision=19,scale=2,nullable=false) @Builder.Default private BigDecimal balance=BigDecimal.ZERO;
  @Column(name="available_balance",precision=19,scale=2) @Builder.Default private BigDecimal availableBalance=BigDecimal.ZERO;
  @Column(name="currency",length=3) @Builder.Default private String currency="USD";
  @Column(name="interest_rate",precision=5,scale=4) @Builder.Default private BigDecimal interestRate=BigDecimal.ZERO;
  @Enumerated(EnumType.STRING) @Column(name="status",length=20) @Builder.Default private AccountStatus status=AccountStatus.ACTIVE;
  @Column(name="overdraft_limit",precision=19,scale=2) @Builder.Default private BigDecimal overdraftLimit=BigDecimal.ZERO;
  @Column(name="daily_limit",precision=19,scale=2) @Builder.Default private BigDecimal dailyLimit=new BigDecimal("10000");
  @Column(name="opened_at") @Builder.Default private LocalDateTime openedAt=LocalDateTime.now();
  @Column(name="closed_at") private LocalDateTime closedAt;
  @Column(name="iban",length=34,unique=true) private String iban;
  public enum AccountType { CHECKING,SAVINGS,FIXED_DEPOSIT,MONEY_MARKET,CURRENT }
  public enum AccountStatus { ACTIVE,INACTIVE,FROZEN,CLOSED,PENDING }
}