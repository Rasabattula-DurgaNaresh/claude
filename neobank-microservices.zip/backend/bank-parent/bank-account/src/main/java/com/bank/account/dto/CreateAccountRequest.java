package com.bank.account.dto;
import com.bank.account.entity.Account; import jakarta.validation.constraints.*; import lombok.Data; import java.math.BigDecimal;
@Data public class CreateAccountRequest {
  @NotNull private Account.AccountType accountType;
  @Size(min=3,max=3) private String currency;
  private BigDecimal initialDeposit; private BigDecimal dailyLimit;
}