package com.bank.notification.repository;
import com.bank.notification.entity.Notification; import org.springframework.data.domain.*;
import org.springframework.data.jpa.repository.JpaRepository; import org.springframework.stereotype.Repository;
@Repository public interface NotificationRepository extends JpaRepository<Notification,String> {
  Page<Notification> findByCustomerIdOrderByCreatedAtDesc(String cid, Pageable p); }