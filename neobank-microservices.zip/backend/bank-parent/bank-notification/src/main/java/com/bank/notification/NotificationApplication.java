package com.bank.notification;
import org.springframework.boot.SpringApplication; import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing; import org.springframework.kafka.annotation.EnableKafka;
@SpringBootApplication @EnableJpaAuditing @EnableKafka
public class NotificationApplication { public static void main(String[] a) { SpringApplication.run(NotificationApplication.class,a); } }