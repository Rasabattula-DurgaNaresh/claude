package com.bank.notification.entity;
import com.bank.common.dto.BaseEntity; import jakarta.persistence.*;
import lombok.*;
@Entity @Table(name="notifications") @Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class Notification extends BaseEntity {
  @Column(name="customer_id",length=36,nullable=false) private String customerId;
  @Column(name="recipient",length=255) private String recipient;
  @Column(name="subject",length=500) private String subject;
  @Column(name="message",columnDefinition="TEXT",nullable=false) private String message;
  @Enumerated(EnumType.STRING) @Column(name="type",length=20) @Builder.Default private NotifType type=NotifType.EMAIL;
  @Enumerated(EnumType.STRING) @Column(name="status",length=20) @Builder.Default private NotifStatus status=NotifStatus.PENDING;
  @Column(name="event_type",length=100) private String eventType;
  @Column(name="error_msg",length=500) private String errorMsg;
  public enum NotifType { EMAIL,SMS,PUSH } public enum NotifStatus { PENDING,SENT,FAILED }
}