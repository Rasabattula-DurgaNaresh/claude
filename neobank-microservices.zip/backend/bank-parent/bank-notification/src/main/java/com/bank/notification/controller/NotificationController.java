package com.bank.notification.controller;
import com.bank.common.dto.*; import com.bank.notification.entity.Notification;
import com.bank.notification.repository.NotificationRepository;
import io.swagger.v3.oas.annotations.tags.Tag; import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*; import org.springframework.http.ResponseEntity; import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/v1/notifications") @RequiredArgsConstructor
@Tag(name="Notifications")
public class NotificationController {
  private final NotificationRepository repo;
  @GetMapping
  public ResponseEntity<ApiResponse<PageResponse<Notification>>> list(
      @RequestHeader("X-Customer-Id") String cid, @RequestParam(defaultValue="0") int page, @RequestParam(defaultValue="20") int size) {
    return ResponseEntity.ok(ApiResponse.ok(PageResponse.of(repo.findByCustomerIdOrderByCreatedAtDesc(cid,PageRequest.of(page,size))))); }
}