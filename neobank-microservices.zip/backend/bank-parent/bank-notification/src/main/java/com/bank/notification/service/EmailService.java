package com.bank.notification.service;
import lombok.RequiredArgsConstructor; import lombok.extern.slf4j.Slf4j;
import org.springframework.mail.SimpleMailMessage; import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
@Slf4j @Service @RequiredArgsConstructor
public class EmailService {
  private final JavaMailSender mailer;
  public void send(String to, String subject, String body) {
    SimpleMailMessage m=new SimpleMailMessage(); m.setTo(to); m.setSubject(subject); m.setText(body); m.setFrom("noreply@neobank.com");
    mailer.send(m); log.info("Email sent to {}", to); }
}