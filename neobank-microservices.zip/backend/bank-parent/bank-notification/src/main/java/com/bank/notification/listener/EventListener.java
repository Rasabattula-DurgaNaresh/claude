package com.bank.notification.listener;
import com.bank.notification.entity.Notification; import com.bank.notification.repository.NotificationRepository;
import com.bank.notification.service.EmailService;
import lombok.RequiredArgsConstructor; import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener; import org.springframework.stereotype.Component;
import java.util.Map;
@Slf4j @Component @RequiredArgsConstructor
public class EventListener {
  private final NotificationRepository repo; private final EmailService email;
  @KafkaListener(topics="customer-events",groupId="notification-service")
  public void onCustomer(Map<String,Object> ev) {
    log.info("Customer event: {}", ev.get("eventType"));
    String cid=(String)ev.get("customerId"); String e=(String)ev.get("email"); String name=(String)ev.get("name");
    save(cid,e,"Welcome to NeoBank!","Dear "+name+", welcome to NeoBank! Your account is now active.","REGISTERED");
  }
  @KafkaListener(topics="account-events",groupId="notification-service")
  public void onAccount(Map<String,Object> ev) {
    log.info("Account event: {}", ev.get("eventType"));
    String cid=(String)ev.get("customerId");
    save(cid,null,"Account Update","Your account "+ev.get("number")+" has been opened.",String.valueOf(ev.get("eventType")));
  }
  @KafkaListener(topics="transaction-events",groupId="notification-service")
  public void onTransaction(Map<String,Object> ev) {
    log.info("Transaction event: {}", ev.get("eventType"));
    String cid=(String)ev.get("customerId");
    save(cid,null,"Transaction Alert","Transfer of "+ev.get("amount")+" completed successfully.","TRANSFER_COMPLETED");
  }
  @KafkaListener(topics="loan-events",groupId="notification-service")
  public void onLoan(Map<String,Object> ev) {
    log.info("Loan event: {}", ev.get("eventType"));
    String cid=(String)ev.get("customerId");
    save(cid,null,"Loan Application","Your loan application for "+ev.get("amount")+" is under review.","LOAN_APPLIED");
  }
  private void save(String cid, String to, String subj, String msg, String eventType) {
    Notification n=Notification.builder().customerId(cid).recipient(to!=null?to:"").subject(subj).message(msg).eventType(eventType).build();
    if(to!=null){try{email.send(to,subj,msg);n.setStatus(Notification.NotifStatus.SENT);}
    catch(Exception e){n.setStatus(Notification.NotifStatus.FAILED);n.setErrorMsg(e.getMessage());}}
    else{n.setStatus(Notification.NotifStatus.SENT);}
    repo.save(n);
  }
}