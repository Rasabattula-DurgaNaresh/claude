package com.bank.loan.controller;
import com.bank.common.dto.ApiResponse; import com.bank.loan.dto.*; import com.bank.loan.service.LoanService;
import io.swagger.v3.oas.annotations.Operation; import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid; import lombok.RequiredArgsConstructor; import org.springframework.http.*;
import org.springframework.web.bind.annotation.*; import java.util.List;
@RestController @RequestMapping("/api/v1/loans") @RequiredArgsConstructor
@Tag(name="Loan Service",description="Loan applications and management")
public class LoanController {
  private final LoanService svc;
  @PostMapping("/apply") @Operation(summary="Apply for a loan")
  public ResponseEntity<ApiResponse<LoanDto>> apply(@RequestHeader("X-Customer-Id") String cid, @Valid @RequestBody LoanApplicationRequest req) {
    return ResponseEntity.status(201).body(ApiResponse.ok("Application submitted",svc.apply(cid,req))); }
  @GetMapping @Operation(summary="My loans")
  public ResponseEntity<ApiResponse<List<LoanDto>>> list(@RequestHeader("X-Customer-Id") String cid) {
    return ResponseEntity.ok(ApiResponse.ok(svc.mine(cid))); }
  @GetMapping("/{id}") @Operation(summary="Loan details")
  public ResponseEntity<ApiResponse<LoanDto>> get(@PathVariable String id, @RequestHeader("X-Customer-Id") String cid) {
    return ResponseEntity.ok(ApiResponse.ok(svc.get(id,cid))); }
  @PostMapping("/{id}/approve") @Operation(summary="Approve loan (Staff)")
  public ResponseEntity<ApiResponse<LoanDto>> approve(@PathVariable String id, @RequestParam(defaultValue="700") int creditScore) {
    return ResponseEntity.ok(ApiResponse.ok("Loan approved",svc.approve(id,creditScore))); }
  @PostMapping("/{id}/reject") @Operation(summary="Reject loan (Staff)")
  public ResponseEntity<ApiResponse<LoanDto>> reject(@PathVariable String id, @RequestParam String reason) {
    return ResponseEntity.ok(ApiResponse.ok("Loan rejected",svc.reject(id,reason))); }
}