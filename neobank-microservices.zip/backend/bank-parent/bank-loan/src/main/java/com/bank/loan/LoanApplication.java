package com.bank.loan;
import org.springframework.boot.SpringApplication; import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan; import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
@SpringBootApplication @EnableJpaAuditing @ComponentScan(basePackages={"com.bank.loan","com.bank.common"})
public class LoanApplication { public static void main(String[] a) { SpringApplication.run(LoanApplication.class,a); } }