package com.bank.loan.dto;
import com.bank.loan.entity.Loan; import jakarta.validation.constraints.*; import lombok.Data; import java.math.BigDecimal;
@Data public class LoanApplicationRequest {
  @NotNull private Loan.LoanType loanType;
  @NotNull @DecimalMin("1000") @DecimalMax("10000000") private BigDecimal principal;
  @NotNull @Min(6) @Max(360) private int tenureMonths;
  @NotBlank private String disburseAccountId;
  @Size(max=500) private String purpose;
}