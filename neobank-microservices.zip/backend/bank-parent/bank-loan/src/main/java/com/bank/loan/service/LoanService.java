package com.bank.loan.service;
import com.bank.common.exception.BankException; import com.bank.loan.dto.*;
import com.bank.loan.entity.Loan; import com.bank.loan.repository.LoanRepository;
import lombok.RequiredArgsConstructor; import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate; import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal; import java.math.RoundingMode; import java.time.*; import java.util.*;
import java.util.stream.*;
@Slf4j @Service @RequiredArgsConstructor
public class LoanService {
  private final LoanRepository repo; private final KafkaTemplate<String,Object> kafka;

  @Transactional public LoanDto apply(String cid, LoanApplicationRequest req) {
    BigDecimal rate=defaultRate(req.getLoanType()); BigDecimal emi=emi(req.getPrincipal(),rate,req.getTenureMonths());
    String num=genNum();
    Loan loan=Loan.builder().customerId(cid).loanNumber(num).loanType(req.getLoanType())
      .principal(req.getPrincipal()).outstanding(req.getPrincipal()).interestRate(rate)
      .tenureMonths(req.getTenureMonths()).emi(emi).disburseAccountId(req.getDisburseAccountId())
      .purpose(req.getPurpose()).build();
    loan=repo.save(loan);
    kafka.send("loan-events",loan.getId(),Map.of("eventType","APPLIED","loanId",loan.getId(),"customerId",cid,"amount",req.getPrincipal()));
    return toDto(loan);
  }

  @Transactional public LoanDto approve(String id, int creditScore) {
    Loan l=find(id); l.setStatus(Loan.LoanStatus.APPROVED); l.setCreditScore(creditScore);
    l.setStartDate(LocalDate.now()); l.setEndDate(LocalDate.now().plusMonths(l.getTenureMonths()));
    l.setNextDueDate(LocalDate.now().plusMonths(1)); return toDto(repo.save(l)); }

  @Transactional public LoanDto reject(String id, String reason) {
    Loan l=find(id); l.setStatus(Loan.LoanStatus.REJECTED); l.setRejectReason(reason); return toDto(repo.save(l)); }

  @Transactional(readOnly=true) public List<LoanDto> mine(String cid) {
    return repo.findByCustomerId(cid).stream().map(this::toDto).collect(Collectors.toList()); }

  @Transactional(readOnly=true) public LoanDto get(String id, String cid) {
    Loan l=find(id); if(!l.getCustomerId().equals(cid)) throw BankException.forbidden("Not your loan"); return toDto(l); }

  private Loan find(String id) { return repo.findById(id).orElseThrow(()->BankException.notFound("Loan",id)); }
  private LoanDto toDto(Loan l) { return LoanDto.builder().id(l.getId()).loanNumber(l.getLoanNumber()).loanType(l.getLoanType().name())
    .status(l.getStatus().name()).principal(l.getPrincipal()).outstanding(l.getOutstanding())
    .interestRate(l.getInterestRate()).emi(l.getEmi()).tenureMonths(l.getTenureMonths())
    .purpose(l.getPurpose()).disburseAccountId(l.getDisburseAccountId()).creditScore(l.getCreditScore())
    .rejectReason(l.getRejectReason()).startDate(l.getStartDate()).endDate(l.getEndDate())
    .nextDueDate(l.getNextDueDate()).createdAt(l.getCreatedAt()).build(); }
  private BigDecimal emi(BigDecimal p, BigDecimal ann, int n) {
    BigDecimal r=ann.divide(BigDecimal.valueOf(12),10,RoundingMode.HALF_UP);
    BigDecimal op1=BigDecimal.ONE.add(r).pow(n);
    return p.multiply(r).multiply(op1).divide(op1.subtract(BigDecimal.ONE),2,RoundingMode.HALF_UP); }
  private BigDecimal defaultRate(Loan.LoanType t) { return switch(t){
    case PERSONAL->new BigDecimal("0.1200"); case HOME->new BigDecimal("0.0875");
    case AUTO->new BigDecimal("0.0950"); case EDUCATION->new BigDecimal("0.0850");
    case BUSINESS->new BigDecimal("0.1100"); case GOLD->new BigDecimal("0.0750");}; }
  private String genNum(){String n;do{n="LOAN"+System.currentTimeMillis()%100000000L;}while(repo.existsByLoanNumber(n));return n;}
}