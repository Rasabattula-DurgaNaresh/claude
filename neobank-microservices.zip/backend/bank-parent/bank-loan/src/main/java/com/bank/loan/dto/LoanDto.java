package com.bank.loan.dto;
import lombok.Builder; import lombok.Data; import java.math.BigDecimal; import java.time.*;
@Data @Builder public class LoanDto {
  private String id,loanNumber,loanType,status,purpose,disburseAccountId;
  private BigDecimal principal,outstanding,interestRate,emi;
  private int tenureMonths; private Integer creditScore; private String rejectReason;
  private LocalDate startDate,endDate,nextDueDate; private LocalDateTime createdAt;
}