package com.bank.loan.entity;
import com.bank.common.dto.BaseEntity; import jakarta.persistence.*;
import lombok.*; import java.math.BigDecimal; import java.time.LocalDate;
@Entity @Table(name="loans",indexes={
  @Index(name="idx_loan_customer",columnList="customer_id"),
  @Index(name="idx_loan_status",columnList="status"),
  @Index(name="idx_loan_type",columnList="loan_type")})
@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class Loan extends BaseEntity {
  @Column(name="customer_id",length=36,nullable=false) private String customerId;
  @Column(name="loan_number",length=20,unique=true,nullable=false) private String loanNumber;
  @Enumerated(EnumType.STRING) @Column(name="loan_type",length=30,nullable=false) private LoanType loanType;
  @Column(name="principal",precision=19,scale=2,nullable=false) private BigDecimal principal;
  @Column(name="outstanding",precision=19,scale=2,nullable=false) private BigDecimal outstanding;
  @Column(name="interest_rate",precision=5,scale=4,nullable=false) private BigDecimal interestRate;
  @Column(name="tenure_months",nullable=false) private int tenureMonths;
  @Column(name="emi",precision=19,scale=2) private BigDecimal emi;
  @Column(name="disburse_account_id",length=36) private String disburseAccountId;
  @Enumerated(EnumType.STRING) @Column(name="status",length=30) @Builder.Default private LoanStatus status=LoanStatus.PENDING;
  @Column(name="purpose",length=500) private String purpose;
  @Column(name="start_date") private LocalDate startDate;
  @Column(name="end_date") private LocalDate endDate;
  @Column(name="next_due_date") private LocalDate nextDueDate;
  @Column(name="credit_score") private Integer creditScore;
  @Column(name="reject_reason",length=500) private String rejectReason;
  public enum LoanType { PERSONAL,HOME,AUTO,EDUCATION,BUSINESS,GOLD }
  public enum LoanStatus { PENDING,UNDER_REVIEW,APPROVED,REJECTED,ACTIVE,CLOSED,DEFAULTED }
}