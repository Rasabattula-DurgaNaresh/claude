CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE TABLE loans (
  id                VARCHAR(36)   PRIMARY KEY DEFAULT gen_random_uuid()::text,
  customer_id       VARCHAR(36)   NOT NULL,
  loan_number       VARCHAR(20)   UNIQUE NOT NULL,
  loan_type         VARCHAR(30)   NOT NULL,
  principal         NUMERIC(19,2) NOT NULL,
  outstanding       NUMERIC(19,2) NOT NULL,
  interest_rate     NUMERIC(5,4)  NOT NULL,
  tenure_months     INT           NOT NULL,
  emi               NUMERIC(19,2),
  disburse_account_id VARCHAR(36),
  status            VARCHAR(30)   NOT NULL DEFAULT 'PENDING',
  purpose           VARCHAR(500),
  start_date        DATE, end_date DATE, next_due_date DATE,
  credit_score      INT,
  reject_reason     VARCHAR(500),
  created_at        TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  version           BIGINT        NOT NULL DEFAULT 0
);
CREATE INDEX idx_loan_customer ON loans(customer_id);
CREATE INDEX idx_loan_status   ON loans(status);