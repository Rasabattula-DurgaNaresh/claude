CREATE DATABASE customerdb;
CREATE DATABASE accountdb;
CREATE DATABASE transactiondb;
CREATE DATABASE loandb;
CREATE DATABASE notificationdb;

GRANT ALL PRIVILEGES ON DATABASE customerdb     TO neobank;
GRANT ALL PRIVILEGES ON DATABASE accountdb      TO neobank;
GRANT ALL PRIVILEGES ON DATABASE transactiondb  TO neobank;
GRANT ALL PRIVILEGES ON DATABASE loandb         TO neobank;
GRANT ALL PRIVILEGES ON DATABASE notificationdb TO neobank;