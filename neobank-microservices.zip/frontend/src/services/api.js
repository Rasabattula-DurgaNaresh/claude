import axios from 'axios';
import useAuth from '../store/authStore';

const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL || '',
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' }
});

api.interceptors.request.use(config => {
  const token = useAuth.getState().token;
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  r => r,
  async err => {
    if (err.response?.status === 401 && !err.config._retry) {
      err.config._retry = true;
      try {
        const { refreshToken } = useAuth.getState();
        const { data } = await axios.post('/api/v1/auth/refresh', { refreshToken });
        useAuth.getState().updateUser(data.data.customer);
        useAuth.setState({ token: data.data.accessToken });
        err.config.headers.Authorization = `Bearer ${data.data.accessToken}`;
        return api(err.config);
      } catch { useAuth.getState().logout(); window.location.href = '/login'; }
    }
    return Promise.reject(err);
  }
);

export default api;