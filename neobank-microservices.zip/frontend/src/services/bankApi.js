import api from './api';

export const authApi    = { login: d => api.post('/api/v1/auth/login', d), register: d => api.post('/api/v1/customers/register', d) };
export const customerApi = { me: () => api.get('/api/v1/customers/me'), update: d => api.put('/api/v1/customers/me', d), changePw: d => api.post('/api/v1/customers/me/change-password', d) };
export const accountApi  = { list: () => api.get('/api/v1/accounts'), get: id => api.get(`/api/v1/accounts/${id}`), open: d => api.post('/api/v1/accounts', d), freeze: id => api.post(`/api/v1/accounts/${id}/freeze`), unfreeze: id => api.post(`/api/v1/accounts/${id}/unfreeze`), close: id => api.post(`/api/v1/accounts/${id}/close`) };
export const txApi       = { history: (page=0,size=20) => api.get(`/api/v1/transactions?page=${page}&size=${size}`), transfer: d => api.post('/api/v1/transactions/transfer', d), byRef: ref => api.get(`/api/v1/transactions/${ref}`), statement: (from,to) => api.get(`/api/v1/transactions/statement?from=${from}&to=${to}`) };
export const loanApi     = { list: () => api.get('/api/v1/loans'), get: id => api.get(`/api/v1/loans/${id}`), apply: d => api.post('/api/v1/loans/apply', d) };
export const notifApi    = { list: (p=0) => api.get(`/api/v1/notifications?page=${p}`) };