import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import api from '../services/api';

const useAuth = create(
  persist(
    (set) => ({
      user: null, token: null, refreshToken: null, isAuth: false,
      login: async (username, password) => {
        const { data } = await api.post('/api/v1/auth/login', { username, password });
        const { accessToken, refreshToken, customer } = data.data;
        set({ user: customer, token: accessToken, refreshToken, isAuth: true });
        return data.data;
      },
      register: async (payload) => {
        const { data } = await api.post('/api/v1/customers/register', payload);
        const { accessToken, refreshToken, customer } = data.data;
        set({ user: customer, token: accessToken, refreshToken, isAuth: true });
        return data.data;
      },
      logout: () => set({ user: null, token: null, refreshToken: null, isAuth: false }),
      updateUser: (user) => set({ user }),
    }),
    { name: 'neobank-auth', partialize: s => ({ user: s.user, token: s.token, refreshToken: s.refreshToken, isAuth: s.isAuth }) }
  )
);
export default useAuth;