import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import App from './App';
import './index.css';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
      <Toaster position="top-right" toastOptions={{
        style: {
          background: '#111e35', color: '#e8ecf4',
          border: '1px solid rgba(230,240,255,0.07)',
          borderRadius: '12px', fontFamily: "'DM Sans',sans-serif", fontSize: '13.5px'
        },
        success: { iconTheme: { primary: '#d4a843', secondary: '#050a14' } },
        error:   { iconTheme: { primary: '#f05252', secondary: '#e8ecf4' } }
      }} />
    </BrowserRouter>
  </React.StrictMode>
);