import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import useAuth from './store/authStore';
import Layout from './components/layout/Layout';
import LoginPage       from './pages/LoginPage';
import RegisterPage    from './pages/RegisterPage';
import DashboardPage   from './pages/DashboardPage';
import AccountsPage    from './pages/AccountsPage';
import TransactionsPage from './pages/TransactionsPage';
import TransferPage    from './pages/TransferPage';
import LoansPage       from './pages/LoansPage';
import ProfilePage     from './pages/ProfilePage';

function Guard({ children }) {
  return useAuth(s => s.isAuth) ? children : <Navigate to="/login" replace />;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login"    element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/" element={<Guard><Layout /></Guard>}>
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="dashboard"    element={<DashboardPage />} />
        <Route path="accounts"     element={<AccountsPage />} />
        <Route path="transactions" element={<TransactionsPage />} />
        <Route path="transfer"     element={<TransferPage />} />
        <Route path="loans"        element={<LoansPage />} />
        <Route path="profile"      element={<ProfilePage />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}