import React from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { LayoutDashboard, CreditCard, ArrowLeftRight, Send, TrendingUp, User, LogOut } from 'lucide-react';
import useAuth from '../../store/authStore';
import toast from 'react-hot-toast';

const NAV = [
  { to: '/dashboard',    label: 'Dashboard',    icon: LayoutDashboard },
  { to: '/accounts',     label: 'Accounts',     icon: CreditCard },
  { to: '/transactions', label: 'Transactions', icon: ArrowLeftRight },
  { to: '/transfer',     label: 'Transfer',     icon: Send },
  { to: '/loans',        label: 'Loans',        icon: TrendingUp },
  { to: '/profile',      label: 'Profile',      icon: User },
];

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const initials = user ? (user.firstName?.[0] || '') + (user.lastName?.[0] || '') : 'U';
  const handleLogout = () => { logout(); toast.success('Signed out'); navigate('/login'); };

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-top">
          <div className="brand">
            <div className="brand-icon">N</div>
            <div>
              <div className="brand-name">NeoBank</div>
              <div className="brand-tagline">Digital Banking</div>
            </div>
          </div>
        </div>

        <nav className="sidebar-nav">
          <div className="nav-group-label">Navigation</div>
          {NAV.map(({ to, label, icon: Icon }) => (
            <NavLink key={to} to={to} className={({ isActive }) => `nav-item${isActive ? ' active' : ''}`}>
              <Icon size={16} /> {label}
            </NavLink>
          ))}
        </nav>

        <div className="sidebar-foot">
          <div className="user-tile">
            <div className="user-avatar">{initials}</div>
            <div className="flex-1">
              <div className="user-name">{user?.firstName} {user?.lastName}</div>
              <div className="user-badge">{user?.role}</div>
            </div>
            <button onClick={handleLogout} className="btn btn-icon btn-ghost" style={{padding:'6px'}} title="Sign out">
              <LogOut size={14} />
            </button>
          </div>
        </div>
      </aside>

      <div className="page-body">
        <div className="page-inner"><Outlet /></div>
      </div>
    </div>
  );
}