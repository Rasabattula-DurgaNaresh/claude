import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { accountApi, txApi } from '../services/bankApi';
import useAuth from '../store/authStore';
import { Wallet, CreditCard, ArrowDownLeft, ArrowUpRight, ArrowRight, TrendingUp } from 'lucide-react';
import toast from 'react-hot-toast';

const CHART = [
  {m:'Jan',credit:5200,debit:3100},{m:'Feb',credit:4800,debit:2600},{m:'Mar',credit:6100,debit:3500},
  {m:'Apr',credit:5700,debit:3200},{m:'May',credit:7200,debit:4100},{m:'Jun',credit:6800,debit:3700},
  {m:'Jul',credit:8100,debit:4900},{m:'Aug',credit:7500,debit:4200},
];

const CT = ({ active, payload }) => active && payload?.length ? (
  <div style={{background:'#111e35',border:'1px solid rgba(230,240,255,0.07)',borderRadius:10,padding:'10px 14px',fontSize:12,fontFamily:"'DM Mono',monospace"}}>
    {payload.map((p,i) => <div key={i} style={{color:p.color}}>
      {p.name}: ${p.value.toLocaleString()}
    </div>)}
  </div>
) : null;

export default function DashboardPage() {
  const { user } = useAuth();
  const [accounts, setAccounts] = useState([]);
  const [txs, setTxs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([accountApi.list(), txApi.history(0, 5)])
      .then(([a, t]) => { setAccounts(a.data.data || []); setTxs(t.data.data?.content || []); })
      .catch(() => toast.error('Failed to load data'))
      .finally(() => setLoading(false));
  }, []);

  const total = accounts.reduce((s, a) => s + parseFloat(a.balance || 0), 0);
  const fmt = n => '$' + n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  const stats = [
    { label: 'Total Balance', value: fmt(total), meta: '↑ 2.4% this month', dir: 'up', icon: Wallet, cls: 'stat-card-ember', ic: 'var(--ember)', ib: 'rgba(212,168,67,0.12)' },
    { label: 'Active Accounts', value: accounts.filter(a => a.status === 'ACTIVE').length, meta: '', dir: '', icon: CreditCard, cls: 'stat-card-blue', ic: 'var(--blue)', ib: 'rgba(79,163,227,0.1)' },
    { label: 'Monthly Credits', value: '$6,800', meta: '↑ 12.3%', dir: 'up', icon: ArrowDownLeft, cls: 'stat-card-green', ic: 'var(--green)', ib: 'rgba(45,212,168,0.1)' },
    { label: 'Monthly Debits', value: '$3,700', meta: '↓ 4.1%', dir: 'down', icon: ArrowUpRight, cls: 'stat-card-red', ic: 'var(--red)', ib: 'rgba(240,82,82,0.1)' },
  ];

  return (
    <div>
      <div className="page-hd flex items-c justify-b">
        <div>
          <h1 className="page-title">Good {new Date().getHours() < 12 ? 'morning' : 'afternoon'}, {user?.firstName}</h1>
          <p className="page-sub">Here's a complete overview of your finances</p>
        </div>
        <div className="text-xs text-mono text-faint" style={{textAlign:'right',lineHeight:1.8}}>
          <div>{new Date().toLocaleDateString('en-US', {weekday:'long',year:'numeric',month:'long',day:'numeric'})}</div>
        </div>
      </div>

      {/* Stats */}
      <div className="stats-grid">
        {stats.map(s => (
          <div key={s.label} className={`stat-card ${s.cls}`}>
            <div style={{width:38,height:38,borderRadius:10,background:s.ib,display:'flex',alignItems:'center',justifyContent:'center',marginBottom:16}}>
              <s.icon size={17} color={s.ic}/>
            </div>
            <div className="stat-label">{s.label}</div>
            <div className="stat-value">{loading ? <span className="spin spin-ember"/> : s.value}</div>
            {s.meta && <div className={`stat-meta ${s.dir}`}>{s.meta}</div>}
          </div>
        ))}
      </div>

      {/* Chart + Actions */}
      <div style={{display:'grid',gridTemplateColumns:'1fr 320px',gap:20,marginBottom:20}}>
        <div className="card">
          <div className="card-hd">
            <div className="card-title">Cash Flow — 2024</div>
            <span className="badge badge-green" style={{fontSize:'10px',letterSpacing:'0.5px'}}>● Live</span>
          </div>
          <ResponsiveContainer width="100%" height={210}>
            <AreaChart data={CHART} margin={{left:-18,right:4,top:4}}>
              <defs>
                <linearGradient id="cg" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#2dd4a8" stopOpacity={0.18}/><stop offset="95%" stopColor="#2dd4a8" stopOpacity={0}/></linearGradient>
                <linearGradient id="dg" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#f05252" stopOpacity={0.15}/><stop offset="95%" stopColor="#f05252" stopOpacity={0}/></linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="2 4" stroke="rgba(230,240,255,0.05)"/>
              <XAxis dataKey="m" tick={{fill:'var(--cream-d)',fontSize:11,fontFamily:"'DM Mono'"}} axisLine={false} tickLine={false}/>
              <YAxis tick={{fill:'var(--cream-d)',fontSize:11,fontFamily:"'DM Mono'"}} axisLine={false} tickLine={false}/>
              <Tooltip content={<CT />}/>
              <Area type="monotone" dataKey="credit" name="Credits" stroke="#2dd4a8" strokeWidth={1.5} fill="url(#cg)"/>
              <Area type="monotone" dataKey="debit"  name="Debits"  stroke="#f05252" strokeWidth={1.5} fill="url(#dg)"/>
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <div className="card-title mb-20" style={{marginBottom:18}}>Quick Actions</div>
          {[
            { label:'Send Money', sub:'Transfer funds instantly', href:'/transfer', c:'var(--ember)' },
            { label:'Open Account', sub:'Add a new bank account', href:'/accounts', c:'var(--blue)' },
            { label:'Apply for Loan', sub:'Personal, home, auto…', href:'/loans', c:'var(--green)' },
            { label:'View History', sub:'Complete transaction log', href:'/transactions', c:'var(--purple)' },
          ].map(a => (
            <Link key={a.label} to={a.href} style={{textDecoration:'none',display:'block',marginBottom:8}}>
              <div className="flex items-c gap-14" style={{padding:'12px 14px',borderRadius:'var(--r)',background:'var(--smoke)',cursor:'pointer',transition:'background 0.15s'}}>
                <div style={{width:34,height:34,borderRadius:9,background:`${a.c}14`,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>
                  <ArrowRight size={14} color={a.c}/>
                </div>
                <div className="flex-1">
                  <div style={{fontSize:13.5,fontWeight:500}}>{a.label}</div>
                  <div className="text-xs text-faint">{a.sub}</div>
                </div>
                <ArrowRight size={13} color="var(--cream-d)"/>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Accounts + Transactions */}
      <div className="grid-2">
        <div className="card">
          <div className="card-hd">
            <div className="card-title">My Accounts</div>
            <Link to="/accounts" className="btn btn-ghost btn-sm" style={{fontSize:12}}>View all</Link>
          </div>
          {loading ? <div style={{textAlign:'center',padding:30}}><span className="spin spin-ember"/></div>
           : accounts.length === 0
             ? <div style={{textAlign:'center',padding:'28px 0',color:'var(--cream-d)'}}>No accounts — <Link to="/accounts" style={{color:'var(--ember)'}}>open one</Link></div>
             : accounts.slice(0,3).map(a => (
              <div key={a.id} className="acc-card" style={{marginBottom:10}}>
                <div className="acc-type">{a.accountType}</div>
                <div className="acc-number">{a.accountNumber?.replace(/(.{4})/g,'$1 ').trim()}</div>
                <div className="flex items-c justify-b">
                  <div><div className="acc-balance">{fmt(parseFloat(a.balance||0))}</div><div className="acc-avail">Available: {fmt(parseFloat(a.availableBalance||0))}</div></div>
                  <span className={`badge badge-${a.status==='ACTIVE'?'green':'muted'}`}>{a.status}</span>
                </div>
              </div>
            ))}
        </div>

        <div className="card">
          <div className="card-hd">
            <div className="card-title">Recent Transactions</div>
            <Link to="/transactions" className="btn btn-ghost btn-sm" style={{fontSize:12}}>View all</Link>
          </div>
          {loading ? <div style={{textAlign:'center',padding:30}}><span className="spin spin-ember"/></div>
           : txs.length === 0
             ? <div style={{textAlign:'center',padding:'28px 0',color:'var(--cream-d)'}}>No transactions yet</div>
             : txs.map(tx => (
              <div key={tx.id} className="tx-row">
                <div className={`tx-icon ${tx.type==='DEPOSIT'?'in':'out'}`}>
                  {tx.type==='DEPOSIT'?<ArrowDownLeft size={15}/>:<ArrowUpRight size={15}/>}
                </div>
                <div className="flex-1">
                  <div className="tx-desc">{tx.type}{tx.description?` — ${tx.description}`:''}</div>
                  <div className="tx-meta">{tx.reference} · {tx.createdAt ? new Date(tx.createdAt).toLocaleDateString('en-US',{month:'short',day:'numeric'}) : 'Pending'}</div>
                </div>
                <div className={`tx-amt ${tx.type==='DEPOSIT'?'in':'out'}`}>
                  {tx.type==='DEPOSIT'?'+':'-'}${parseFloat(tx.amount||0).toLocaleString('en-US',{minimumFractionDigits:2})}
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}