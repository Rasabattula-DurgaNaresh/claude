import React, { useState } from 'react';
import useAuth from '../store/authStore';
import { customerApi } from '../services/bankApi';
import { Shield, Bell, CheckCircle } from 'lucide-react';
import toast from 'react-hot-toast';

export default function ProfilePage() {
  const { user } = useAuth();
  const [pwForm, setPw] = useState({ currentPassword:'', newPassword:'' });
  const [saving, setSaving] = useState(false);

  const changePw = async e => {
    e.preventDefault(); setSaving(true);
    try { await customerApi.changePw(pwForm); toast.success('Password updated!'); setPw({currentPassword:'',newPassword:''}); }
    catch(err) { toast.error(err.response?.data?.message||'Failed to update password'); }
    finally { setSaving(false); }
  };

  const initials = user ? (user.firstName?.[0]||'') + (user.lastName?.[0]||'') : 'U';
  const fields = [
    ['Username', user?.username, true],
    ['Email', user?.email, false],
    ['Role', user?.role, true],
    ['KYC Status', user?.kycStatus, true],
    ['Account Status', user?.status, true],
    ['Phone', user?.phoneNumber||'—', false],
    ['Member Since', user?.createdAt ? new Date(user.createdAt).toLocaleDateString('en-US',{year:'numeric',month:'long',day:'numeric'}) : '—', false],
    ['Last Login', user?.lastLogin ? new Date(user.lastLogin).toLocaleString() : '—', false],
  ];

  return (
    <div>
      <div className="page-hd"><h1 className="page-title">Profile</h1><p className="page-sub">Manage your personal information and security</p></div>

      <div className="grid-2" style={{maxWidth:900}}>
        <div>
          <div className="card" style={{marginBottom:16}}>
            <div className="flex items-c gap-14" style={{marginBottom:24}}>
              <div style={{width:62,height:62,borderRadius:'var(--r-lg)',background:'linear-gradient(135deg,var(--ember-d),var(--purple))',display:'flex',alignItems:'center',justifyContent:'center',fontSize:22,fontWeight:600,color:'white',fontFamily:"'DM Mono'"}}>{initials}</div>
              <div>
                <div style={{fontFamily:'var(--serif)',fontSize:22,fontWeight:600,letterSpacing:'-0.3px'}}>{user?.firstName} {user?.lastName}</div>
                <div className="text-sm text-faint">{user?.email}</div>
                <span className={`badge badge-${user?.status==='ACTIVE'?'green':'muted'}`} style={{marginTop:6}}>{user?.status}</span>
              </div>
            </div>
            {fields.map(([label, val, mono]) => (
              <div key={label} className="flex items-c justify-b" style={{padding:'11px 0',borderBottom:'1px solid var(--border)'}}>
                <span className="text-xs text-mono text-faint" style={{textTransform:'uppercase',letterSpacing:'0.8px'}}>{label}</span>
                <span className={`text-sm ${mono ? 'text-mono' : ''}`}>{val}</span>
              </div>
            ))}
          </div>
        </div>

        <div>
          <div className="card" style={{marginBottom:16}}>
            <div className="flex items-c gap-10" style={{marginBottom:20}}>
              <Shield size={16} color="var(--ember)"/><div className="card-title">Change Password</div>
            </div>
            <form onSubmit={changePw}>
              <div className="field">
                <label className="label">Current Password</label>
                <input className="input" type="password" placeholder="Enter current password" value={pwForm.currentPassword} onChange={e => setPw({...pwForm,currentPassword:e.target.value})} required/>
              </div>
              <div className="field">
                <label className="label">New Password</label>
                <input className="input" type="password" placeholder="Min 8 chars, uppercase, digit & special" value={pwForm.newPassword} onChange={e => setPw({...pwForm,newPassword:e.target.value})} required/>
                <div className="input-hint">Requirements: 8+ chars · uppercase · digit · special character</div>
              </div>
              <button type="submit" className="btn btn-primary" disabled={saving}>
                {saving ? <><span className="spin spin-dark"/>&nbsp;Updating…</> : 'Update Password'}
              </button>
            </form>
          </div>

          <div className="card">
            <div className="flex items-c gap-10" style={{marginBottom:18}}>
              <Bell size={16} color="var(--ember)"/><div className="card-title">Notifications</div>
            </div>
            {[
              ['Email Alerts', 'Receive account activity emails'],
              ['Transaction SMS', 'Instant SMS on every transaction'],
              ['Monthly Statements', 'Email statement every month'],
              ['Security Alerts', 'Alerts for unusual activity'],
            ].map(([title, desc]) => (
              <div key={title} className="flex items-c justify-b" style={{padding:'11px 0',borderBottom:'1px solid var(--border)'}}>
                <div><div className="text-sm" style={{fontWeight:450}}>{title}</div><div className="text-xs text-faint">{desc}</div></div>
                <CheckCircle size={16} color="var(--green)"/>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}