import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import useAuth from '../store/authStore';
import toast from 'react-hot-toast';
import { Lock, Eye, EyeOff, Shield } from 'lucide-react';

export default function LoginPage() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [form, setForm] = useState({ username: '', password: '' });
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);

  const submit = async e => {
    e.preventDefault(); setLoading(true);
    try { await login(form.username, form.password); toast.success('Welcome back'); navigate('/dashboard'); }
    catch (err) { toast.error(err.response?.data?.message || 'Login failed'); }
    finally { setLoading(false); }
  };

  return (
    <div className="auth-shell">
      <div className="auth-left">
        <div className="auth-orb auth-orb-1" />
        <div className="auth-orb auth-orb-2" />
        <div className="auth-pitch">
          <div style={{display:'flex',alignItems:'center',gap:14,marginBottom:36}}>
            <div className="brand-icon" style={{width:50,height:50,fontSize:22}}>N</div>
            <div>
              <div style={{fontFamily:'var(--serif)',fontSize:22,fontWeight:600}}>NeoBank</div>
              <div style={{fontSize:11,color:'var(--cream-d)',fontFamily:'var(--mono)',textTransform:'uppercase',letterSpacing:'1.5px'}}>Modern Digital Banking</div>
            </div>
          </div>
          <h1 className="auth-headline">Banking<br/>reimagined<br/><em className="text-ember">for you.</em></h1>
          <p className="auth-sub">Manage your finances, investments, and loans with the precision of institutional banking — in the palm of your hand.</p>
          <div className="auth-feats">
            {['256-bit AES end-to-end encryption','Real-time transaction alerts','Zero-fee internal transfers','AI-powered financial insights'].map(f => (
              <div className="auth-feat" key={f}><div className="auth-dot"/><span>{f}</span></div>
            ))}
          </div>
        </div>
      </div>

      <div className="auth-panel">
        <div style={{width:'100%',maxWidth:360}}>
          <div className="flex items-c gap-10 mb-20" style={{marginBottom:28}}>
            <Shield size={18} color="var(--ember)" />
            <span className="text-xs text-mono text-faint" style={{textTransform:'uppercase',letterSpacing:'1px'}}>Secure Connection · TLS 1.3</span>
          </div>

          <div className="auth-form-title">Sign in</div>
          <div className="auth-form-sub">Access your NeoBank account</div>

          <form onSubmit={submit}>
            <div className="field">
              <label className="label">Username or Email</label>
              <input className="input" placeholder="Enter your username or email"
                value={form.username} onChange={e => setForm({...form, username: e.target.value})} required />
            </div>
            <div className="field">
              <label className="label">Password</label>
              <div style={{position:'relative'}}>
                <input className="input" type={showPw ? 'text' : 'password'}
                  placeholder="Enter your password" style={{paddingRight:44}}
                  value={form.password} onChange={e => setForm({...form, password: e.target.value})} required />
                <button type="button" onClick={() => setShowPw(!showPw)}
                  style={{position:'absolute',right:12,top:'50%',transform:'translateY(-50%)',background:'none',border:'none',color:'var(--cream-d)',cursor:'pointer',padding:4}}>
                  {showPw ? <EyeOff size={15}/> : <Eye size={15}/>}
                </button>
              </div>
            </div>
            <button type="submit" disabled={loading} className="btn btn-primary btn-full" style={{padding:'13px',marginTop:8,fontSize:14}}>
              {loading ? <><span className="spin spin-dark"/>&nbsp;Signing in…</> : <><Lock size={15}/>&nbsp;Sign In</>}
            </button>
          </form>

          <div className="divider" />
          <p className="text-sm text-muted" style={{textAlign:'center'}}>
            New to NeoBank? <Link to="/register" style={{color:'var(--ember)',textDecoration:'none',fontWeight:500}}>Open an account</Link>
          </p>
        </div>
      </div>
    </div>
  );
}