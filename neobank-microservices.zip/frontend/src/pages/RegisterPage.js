import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import useAuth from '../store/authStore';
import toast from 'react-hot-toast';

export default function RegisterPage() {
  const navigate = useNavigate();
  const { register } = useAuth();
  const [form, setForm] = useState({username:'',email:'',password:'',firstName:'',lastName:'',phoneNumber:'',nationalId:'',address:''});
  const [loading, setLoading] = useState(false);

  const f = (k, v) => setForm(p => ({...p, [k]: v}));
  const field = (key, label, type='text', placeholder='', required=true) => (
    <div className="field" key={key}>
      <label className="label">{label}</label>
      <input className="input" type={type} placeholder={placeholder||label}
        value={form[key]} onChange={e => f(key, e.target.value)} required={required} />
    </div>
  );

  const submit = async e => {
    e.preventDefault(); setLoading(true);
    try { await register(form); toast.success('Account created!'); navigate('/dashboard'); }
    catch (err) { toast.error(err.response?.data?.message || 'Registration failed'); }
    finally { setLoading(false); }
  };

  return (
    <div className="auth-shell">
      <div className="auth-left">
        <div className="auth-orb auth-orb-1" />
        <div className="auth-orb auth-orb-2" />
        <div className="auth-pitch">
          <div style={{display:'flex',alignItems:'center',gap:14,marginBottom:36}}>
            <div className="brand-icon" style={{width:50,height:50,fontSize:22}}>N</div>
            <div><div style={{fontFamily:'var(--serif)',fontSize:22,fontWeight:600}}>NeoBank</div></div>
          </div>
          <h1 className="auth-headline">Open your<br/>account in<br/><em className="text-ember">minutes.</em></h1>
          <p className="auth-sub">No paperwork. No hidden fees. Just a powerful, modern banking experience from day one.</p>
        </div>
      </div>
      <div className="auth-panel" style={{width:500,overflowY:'auto',alignItems:'flex-start',paddingTop:60,paddingBottom:60}}>
        <div style={{width:'100%'}}>
          <div className="auth-form-title">Create Account</div>
          <div className="auth-form-sub">Join thousands of NeoBank members</div>
          <form onSubmit={submit}>
            <div className="form-row form-row-2">{field('firstName','First Name')}{field('lastName','Last Name')}</div>
            {field('username','Username')}{field('email','Email','email')}
            {field('password','Password','password','Min 8 chars · uppercase · digit · special char')}
            <div className="form-row form-row-2">{field('phoneNumber','Phone',  'tel','+1234567890',false)}{field('nationalId','National ID','text','ID / Passport',false)}</div>
            {field('address','Address','text','Street, City, Country',false)}
            <button type="submit" disabled={loading} className="btn btn-primary btn-full" style={{padding:'13px',marginTop:8,fontSize:14}}>
              {loading ? <><span className="spin spin-dark"/>&nbsp;Creating Account…</> : 'Create Account'}
            </button>
          </form>
          <div className="divider"/>
          <p className="text-sm text-muted" style={{textAlign:'center'}}>
            Already a member? <Link to="/login" style={{color:'var(--ember)',textDecoration:'none',fontWeight:500}}>Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}