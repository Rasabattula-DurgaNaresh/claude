import React, { useState, useEffect } from 'react';
import { accountApi } from '../services/bankApi';
import { Plus, Snowflake, Sun, X } from 'lucide-react';
import toast from 'react-hot-toast';

const TYPE_COLOR = { CHECKING:'var(--blue)', SAVINGS:'var(--green)', FIXED_DEPOSIT:'var(--ember)', MONEY_MARKET:'var(--purple)', CURRENT:'#f97316' };
const fmt = n => '$' + parseFloat(n||0).toLocaleString('en-US', {minimumFractionDigits:2});

export default function AccountsPage() {
  const [accounts, setAccounts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ accountType:'CHECKING', currency:'USD', initialDeposit:'', dailyLimit:'' });
  const [saving, setSaving] = useState(false);

  const load = () => { setLoading(true); accountApi.list().then(r => setAccounts(r.data.data||[])).finally(() => setLoading(false)); };
  useEffect(() => { load(); }, []);

  const submit = async e => {
    e.preventDefault(); setSaving(true);
    try {
      await accountApi.open({ ...form, initialDeposit: parseFloat(form.initialDeposit)||0, dailyLimit: parseFloat(form.dailyLimit)||10000 });
      toast.success('Account opened!'); setShowForm(false); load();
    } catch(err) { toast.error(err.response?.data?.message||'Failed to open account'); }
    finally { setSaving(false); }
  };

  const action = async (fn, msg) => { try { await fn(); toast.success(msg); load(); } catch(err) { toast.error(err.response?.data?.message||'Action failed'); } };

  return (
    <div>
      <div className="page-hd flex items-c justify-b">
        <div><h1 className="page-title">Accounts</h1><p className="page-sub">Manage all your bank accounts</p></div>
        <button className="btn btn-primary" onClick={() => setShowForm(!showForm)}><Plus size={15}/> Open Account</button>
      </div>

      {showForm && (
        <div className="card mb-28" style={{marginBottom:24}}>
          <div className="card-hd"><div className="card-title">Open New Account</div><button className="btn btn-icon btn-ghost btn-sm" onClick={() => setShowForm(false)}><X size={15}/></button></div>
          <form onSubmit={submit}>
            <div className="form-row form-row-3">
              <div className="field">
                <label className="label">Account Type</label>
                <select className="select" value={form.accountType} onChange={e => setForm({...form,accountType:e.target.value})}>
                  {['CHECKING','SAVINGS','FIXED_DEPOSIT','MONEY_MARKET','CURRENT'].map(t => <option key={t}>{t}</option>)}
                </select>
              </div>
              <div className="field">
                <label className="label">Currency</label>
                <select className="select" value={form.currency} onChange={e => setForm({...form,currency:e.target.value})}>
                  {['USD','EUR','GBP','INR','JPY','AED'].map(c => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div className="field">
                <label className="label">Initial Deposit</label>
                <input className="input" type="number" min="0" step="0.01" placeholder="0.00"
                  value={form.initialDeposit} onChange={e => setForm({...form,initialDeposit:e.target.value})}/>
              </div>
            </div>
            <div className="flex gap-10">
              <button type="submit" className="btn btn-primary" disabled={saving}>
                {saving ? <><span className="spin spin-dark"/>&nbsp;Opening…</> : 'Open Account'}
              </button>
              <button type="button" className="btn btn-ghost" onClick={() => setShowForm(false)}>Cancel</button>
            </div>
          </form>
        </div>
      )}

      {loading ? <div style={{textAlign:'center',padding:60}}><span className="spin spin-ember"/></div>
       : accounts.length === 0
         ? <div className="card" style={{textAlign:'center',padding:60,color:'var(--cream-d)'}}>
             <p style={{marginBottom:16}}>No accounts yet</p>
             <button className="btn btn-primary" onClick={() => setShowForm(true)}>Open First Account</button>
           </div>
         : <div className="grid-3">
             {accounts.map(a => (
               <div key={a.id} className="acc-card">
                 <div className="acc-type" style={{color:TYPE_COLOR[a.accountType]||'var(--ember)'}}>{a.accountType}</div>
                 <div className="acc-number">{a.accountNumber?.replace(/(.{4})/g,'$1 ').trim()}</div>
                 <div className="acc-balance">{fmt(a.balance)}</div>
                 <div className="acc-avail">{a.currency} · Available: {fmt(a.availableBalance)}</div>
                 <div className="flex items-c justify-b" style={{marginTop:16}}>
                   <span className={`badge badge-${a.status==='ACTIVE'?'green':a.status==='FROZEN'?'blue':'muted'}`}>{a.status}</span>
                   <div className="flex gap-6">
                     {a.status==='ACTIVE' && <button className="btn btn-ghost btn-sm btn-icon" onClick={() => action(() => accountApi.freeze(a.id), 'Account frozen')} title="Freeze"><Snowflake size={13}/></button>}
                     {a.status==='FROZEN' && <button className="btn btn-ghost btn-sm btn-icon" onClick={() => action(() => accountApi.unfreeze(a.id), 'Account unfrozen')} title="Unfreeze"><Sun size={13}/></button>}
                   </div>
                 </div>
                 {a.iban && <div className="acc-iban">{a.iban}</div>}
               </div>
             ))}
           </div>}
    </div>
  );
}