import React, { useState, useEffect } from 'react';
import { txApi, accountApi } from '../services/bankApi';
import { Send, CheckCircle, AlertCircle } from 'lucide-react';
import toast from 'react-hot-toast';

export default function TransferPage() {
  const [accounts, setAccounts] = useState([]);
  const [form, setForm] = useState({ fromAccountId:'', toAccountNumber:'', amount:'', currency:'USD', description:'' });
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  useEffect(() => { accountApi.list().then(r => setAccounts(r.data.data||[])); }, []);

  const selected = accounts.find(a => a.id === form.fromAccountId);

  const submit = async e => {
    e.preventDefault(); setLoading(true); setResult(null);
    try {
      const r = await txApi.transfer({ ...form, amount: parseFloat(form.amount) });
      setResult({ ok: true, data: r.data.data });
      toast.success('Transfer successful!');
      setForm({ fromAccountId:'', toAccountNumber:'', amount:'', currency:'USD', description:'' });
    } catch(err) {
      setResult({ ok: false, msg: err.response?.data?.message||'Transfer failed' });
      toast.error(err.response?.data?.message||'Transfer failed');
    } finally { setLoading(false); }
  };

  return (
    <div>
      <div className="page-hd">
        <h1 className="page-title">Transfer Funds</h1>
        <p className="page-sub">Send money securely to any account</p>
      </div>

      <div style={{maxWidth:580}}>
        {result && (
          <div className="card mb-20" style={{marginBottom:18,background: result.ok ? 'rgba(45,212,168,0.06)' : 'rgba(240,82,82,0.06)', borderColor: result.ok ? 'rgba(45,212,168,0.2)':'rgba(240,82,82,0.2)'}}>
            <div className="flex items-c gap-14">
              {result.ok ? <CheckCircle size={22} color="var(--green)"/> : <AlertCircle size={22} color="var(--red)"/>}
              <div>
                <div style={{fontWeight:500,color:result.ok?'var(--green)':'var(--red)',fontSize:14}}>
                  {result.ok ? 'Transfer Completed' : 'Transfer Failed'}
                </div>
                {result.ok
                  ? <div className="text-xs text-mono text-faint mt-4">Ref: <span className="text-ember">{result.data?.reference}</span></div>
                  : <div className="text-xs text-faint mt-4">{result.msg}</div>}
              </div>
            </div>
          </div>
        )}

        <div className="card">
          <div className="card-title mb-20" style={{marginBottom:22}}>New Transfer</div>
          <form onSubmit={submit}>
            <div className="field">
              <label className="label">From Account</label>
              <select className="select" value={form.fromAccountId} onChange={e => setForm({...form,fromAccountId:e.target.value})} required>
                <option value="">Select source account</option>
                {accounts.filter(a => a.status==='ACTIVE').map(a => (
                  <option key={a.id} value={a.id}>{a.accountType} · {a.accountNumber} (${parseFloat(a.availableBalance||0).toLocaleString()})</option>
                ))}
              </select>
              {selected && <div className="input-hint">Available balance: <span className="text-green">${parseFloat(selected.availableBalance||0).toLocaleString('en-US',{minimumFractionDigits:2})}</span></div>}
            </div>
            <div className="field">
              <label className="label">To Account Number</label>
              <input className="input" placeholder="Destination account number" value={form.toAccountNumber} onChange={e => setForm({...form,toAccountNumber:e.target.value})} required/>
            </div>
            <div className="form-row form-row-2">
              <div className="field">
                <label className="label">Amount</label>
                <input className="input" type="number" step="0.01" min="0.01" placeholder="0.00" value={form.amount} onChange={e => setForm({...form,amount:e.target.value})} required/>
              </div>
              <div className="field">
                <label className="label">Currency</label>
                <select className="select" value={form.currency} onChange={e => setForm({...form,currency:e.target.value})}>
                  {['USD','EUR','GBP','INR','JPY'].map(c => <option key={c}>{c}</option>)}
                </select>
              </div>
            </div>
            <div className="field">
              <label className="label">Description (optional)</label>
              <input className="input" placeholder="e.g. Rent, utilities, personal…" value={form.description} onChange={e => setForm({...form,description:e.target.value})}/>
            </div>
            <div style={{padding:'13px 16px',background:'rgba(212,168,67,0.06)',borderRadius:'var(--r)',border:'1px solid rgba(212,168,67,0.12)',marginBottom:20,fontSize:13}}>
              <div className="flex justify-b">
                <span className="text-faint">Transfer fee</span><span className="text-ember text-mono">$1.00</span>
              </div>
              <div className="flex justify-b mt-8">
                <span className="text-faint">Estimated arrival</span><span className="text-green text-mono">Instant</span>
              </div>
            </div>
            <button type="submit" className="btn btn-primary btn-full" disabled={loading} style={{padding:'13px',fontSize:14}}>
              {loading ? <><span className="spin spin-dark"/>&nbsp;Processing…</> : <><Send size={15}/>&nbsp;Send Money</>}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}