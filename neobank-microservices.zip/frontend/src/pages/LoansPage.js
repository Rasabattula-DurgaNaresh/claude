import React, { useState, useEffect } from 'react';
import { loanApi, accountApi } from '../services/bankApi';
import { TrendingUp, Plus, X } from 'lucide-react';
import toast from 'react-hot-toast';

const SC = { PENDING:'ember', UNDER_REVIEW:'blue', APPROVED:'green', REJECTED:'red', ACTIVE:'green', CLOSED:'muted', DEFAULTED:'red' };
const RATES = { PERSONAL:'12.00%', HOME:'8.75%', AUTO:'9.50%', EDUCATION:'8.50%', BUSINESS:'11.00%', GOLD:'7.50%' };

export default function LoansPage() {
  const [loans, setLoans] = useState([]);
  const [accounts, setAccounts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ loanType:'PERSONAL', principal:'', tenureMonths:'12', disburseAccountId:'', purpose:'' });
  const [saving, setSaving] = useState(false);

  const load = () => {
    setLoading(true);
    Promise.all([loanApi.list(), accountApi.list()])
      .then(([l,a]) => { setLoans(l.data.data||[]); setAccounts(a.data.data||[]); })
      .finally(() => setLoading(false));
  };
  useEffect(() => { load(); }, []);

  const submit = async e => {
    e.preventDefault(); setSaving(true);
    try {
      await loanApi.apply({ ...form, principal: parseFloat(form.principal), tenureMonths: parseInt(form.tenureMonths) });
      toast.success('Application submitted!'); setShowForm(false); load();
    } catch(err) { toast.error(err.response?.data?.message||'Application failed'); }
    finally { setSaving(false); }
  };

  return (
    <div>
      <div className="page-hd flex items-c justify-b">
        <div><h1 className="page-title">Loans</h1><p className="page-sub">Apply for loans and track applications</p></div>
        <button className="btn btn-primary" onClick={() => setShowForm(!showForm)}><Plus size={15}/> Apply for Loan</button>
      </div>

      {showForm && (
        <div className="card" style={{marginBottom:24}}>
          <div className="card-hd"><div className="card-title">Loan Application</div><button className="btn btn-icon btn-ghost btn-sm" onClick={() => setShowForm(false)}><X size={15}/></button></div>
          <form onSubmit={submit}>
            <div className="form-row form-row-3">
              <div className="field">
                <label className="label">Loan Type</label>
                <select className="select" value={form.loanType} onChange={e => setForm({...form,loanType:e.target.value})}>
                  {Object.keys(RATES).map(t => <option key={t}>{t}</option>)}
                </select>
                <div className="input-hint">Interest rate: <span className="text-ember">{RATES[form.loanType]} p.a.</span></div>
              </div>
              <div className="field">
                <label className="label">Loan Amount ($)</label>
                <input className="input" type="number" min="1000" max="10000000" step="100" placeholder="e.g. 50000" value={form.principal} onChange={e => setForm({...form,principal:e.target.value})} required/>
              </div>
              <div className="field">
                <label className="label">Tenure (Months)</label>
                <input className="input" type="number" min="6" max="360" step="6" value={form.tenureMonths} onChange={e => setForm({...form,tenureMonths:e.target.value})} required/>
              </div>
            </div>
            <div className="field">
              <label className="label">Disbursement Account</label>
              <select className="select" value={form.disburseAccountId} onChange={e => setForm({...form,disburseAccountId:e.target.value})} required>
                <option value="">Choose account for disbursement</option>
                {accounts.filter(a => a.status==='ACTIVE').map(a => <option key={a.id} value={a.id}>{a.accountType} — {a.accountNumber}</option>)}
              </select>
            </div>
            <div className="field">
              <label className="label">Purpose</label>
              <input className="input" placeholder="What will this loan be used for?" value={form.purpose} onChange={e => setForm({...form,purpose:e.target.value})}/>
            </div>
            <div className="flex gap-10">
              <button type="submit" className="btn btn-primary" disabled={saving}>
                {saving ? <><span className="spin spin-dark"/>&nbsp;Submitting…</> : 'Submit Application'}
              </button>
              <button type="button" className="btn btn-ghost" onClick={() => setShowForm(false)}>Cancel</button>
            </div>
          </form>
        </div>
      )}

      {loading ? <div style={{textAlign:'center',padding:60}}><span className="spin spin-ember"/></div>
       : loans.length === 0
         ? <div className="card" style={{textAlign:'center',padding:60}}>
             <TrendingUp size={44} color="var(--cream-d)" style={{marginBottom:14}}/>
             <p style={{color:'var(--cream-d)',marginBottom:14}}>No loan applications yet</p>
             <button className="btn btn-primary" onClick={() => setShowForm(true)}>Apply for Loan</button>
           </div>
         : <div className="card">
             <div className="table-wrap">
               <table className="tbl">
                 <thead><tr><th>Loan #</th><th>Type</th><th>Principal</th><th>Outstanding</th><th>EMI/mo</th><th>Rate</th><th>Tenure</th><th>Status</th><th>Applied</th></tr></thead>
                 <tbody>
                   {loans.map(l => (
                     <tr key={l.id}>
                       <td><span className="text-mono text-ember text-xs">{l.loanNumber}</span></td>
                       <td className="text-sm">{l.loanType}</td>
                       <td><span className="text-mono">${parseFloat(l.principal||0).toLocaleString()}</span></td>
                       <td><span className="text-mono text-red">${parseFloat(l.outstanding||0).toLocaleString()}</span></td>
                       <td><span className="text-mono text-sm">${parseFloat(l.emi||0).toLocaleString()}</span></td>
                       <td><span className="text-ember text-mono text-xs">{(parseFloat(l.interestRate||0)*100).toFixed(2)}%</span></td>
                       <td className="text-sm text-muted">{l.tenureMonths} mo</td>
                       <td><span className={`badge badge-${SC[l.status]||'muted'}`}>{l.status}</span></td>
                       <td className="text-xs text-mono text-faint">{l.createdAt ? new Date(l.createdAt).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'}) : ''}</td>
                     </tr>
                   ))}
                 </tbody>
               </table>
             </div>
           </div>}
    </div>
  );
}