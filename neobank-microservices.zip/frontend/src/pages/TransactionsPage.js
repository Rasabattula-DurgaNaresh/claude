import React, { useState, useEffect } from 'react';
import { txApi } from '../services/bankApi';
import { ArrowUpRight, ArrowDownLeft, RefreshCw } from 'lucide-react';
import toast from 'react-hot-toast';

const SCOL = { COMPLETED:'green', FAILED:'red', PENDING:'blue', PROCESSING:'ember', REVERSED:'muted' };
const TCOL = { DEPOSIT:'in', TRANSFER:'out', WITHDRAWAL:'out', PAYMENT:'out', REFUND:'in', FEE:'out', INTEREST:'in' };

export default function TransactionsPage() {
  const [data, setData] = useState({ content:[], totalPages:0 });
  const [page, setPage] = useState(0);
  const [loading, setLoading] = useState(true);

  const load = (p) => {
    setLoading(true);
    txApi.history(p).then(r => setData(r.data.data||{content:[],totalPages:0}))
      .catch(() => toast.error('Failed to load')).finally(() => setLoading(false));
  };
  useEffect(() => { load(page); }, [page]);

  return (
    <div>
      <div className="page-hd flex items-c justify-b">
        <div><h1 className="page-title">Transactions</h1><p className="page-sub">Complete transaction history and statements</p></div>
        <button className="btn btn-ghost" onClick={() => load(page)}><RefreshCw size={14}/> Refresh</button>
      </div>

      <div className="card">
        {loading ? <div style={{textAlign:'center',padding:60}}><span className="spin spin-ember"/></div>
         : data.content?.length === 0
           ? <div style={{textAlign:'center',padding:60,color:'var(--cream-d)'}}>No transactions found</div>
           : <div className="table-wrap">
               <table className="tbl">
                 <thead><tr>
                   <th>Reference</th><th>Type</th><th>Amount</th><th>Fee</th>
                   <th>Status</th><th>From</th><th>To</th><th>Description</th><th>Date</th>
                 </tr></thead>
                 <tbody>
                   {data.content.map(tx => (
                     <tr key={tx.id}>
                       <td><span className="text-mono text-ember text-xs">{tx.reference}</span></td>
                       <td>
                         <div className="flex items-c gap-6">
                           <span className={`tx-icon ${TCOL[tx.type]||'pnd'}`} style={{width:28,height:28,borderRadius:7}}>
                             {TCOL[tx.type]==='in'?<ArrowDownLeft size={13}/>:<ArrowUpRight size={13}/>}
                           </span>
                           <span className="text-sm">{tx.type}</span>
                         </div>
                       </td>
                       <td><span className={`text-mono ${TCOL[tx.type]==='in'?'text-green':'text-red'}`}>{TCOL[tx.type]==='in'?'+':'-'}${parseFloat(tx.amount||0).toLocaleString()}</span></td>
                       <td><span className="text-mono text-faint text-xs">${parseFloat(tx.fee||0).toFixed(2)}</span></td>
                       <td><span className={`badge badge-${SCOL[tx.status]||'muted'}`}>{tx.status}</span></td>
                       <td><span className="text-mono text-xs text-faint">{tx.fromAccountNumber||'—'}</span></td>
                       <td><span className="text-mono text-xs text-faint">{tx.toAccountNumber||'—'}</span></td>
                       <td className="text-sm text-muted" style={{maxWidth:180,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{tx.description||'—'}</td>
                       <td className="text-xs text-faint text-mono">{tx.createdAt?new Date(tx.createdAt).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'}):''}</td>
                     </tr>
                   ))}
                 </tbody>
               </table>
             </div>}
        {data.totalPages > 1 && (
          <div className="flex items-c justify-b" style={{marginTop:18,paddingTop:18,borderTop:'1px solid var(--border)'}}>
            <button className="btn btn-ghost btn-sm" disabled={page===0} onClick={() => setPage(p => p-1)}>← Previous</button>
            <span className="text-xs text-mono text-faint">Page {page+1} of {data.totalPages}</span>
            <button className="btn btn-ghost btn-sm" disabled={page>=data.totalPages-1} onClick={() => setPage(p => p+1)}>Next →</button>
          </div>
        )}
      </div>
    </div>
  );
}