# Amazon Clone — Full-Stack Microservices

**Spring Boot 3.2 · Oracle DB · Redis · Kafka · React 18 · Docker Compose**

---

## 🚀 Quick Start

```bash
# 1. Clone and start everything
cd amazon-clone
cp .env.example .env

docker-compose up -d

# 2. Wait ~3 minutes for Oracle to initialise
docker-compose logs -f oracle-db   # watch for "DATABASE IS READY"

# 3. Open
open http://localhost:3000          # React frontend
open http://localhost:8761          # Eureka dashboard
open http://localhost:8080/swagger-ui.html  # API docs

# Demo login:  admin@amazon.in / Admin@123456
```

---

## 🏗️ Architecture

```
React Frontend (:3000)
        │
API Gateway (:8080)  ← JWT auth filter, CORS, rate limiting
        │
        ├── User Service       (:8081)  Auth, profiles, addresses
        ├── Product Service    (:8082)  Catalog, categories, search
        ├── Order Service      (:8083)  Orders, order items, status
        ├── Cart Service       (:8084)  Redis-backed cart + product Feign
        ├── Payment Service    (:8085)  Payment simulation, refunds, Kafka
        ├── Review Service     (:8086)  Product reviews, ratings
        └── Notification Svc   (:8087)  Kafka consumer → email/SMS

Supporting:
  Eureka     (:8761) — service discovery
  Oracle XE  (:1521) — persistent data (one schema per service)
  Redis      (:6379) — cart cache, JWT sessions
  Kafka      (:9092) — order/payment/product events
```

---

## 📦 Service Details

| Service | Port | Database | Key Tech |
|---------|------|----------|----------|
| API Gateway | 8080 | — | Spring Cloud Gateway, JWT |
| Eureka Server | 8761 | — | Netflix Eureka |
| User Service | 8081 | Oracle (AMAZON_USERS) | BCrypt, JWT, Flyway |
| Product Service | 8082 | Oracle (PRODUCTS) | JPA, Kafka, Flyway |
| Order Service | 8083 | Oracle (ORDERS) | Feign, Kafka, Flyway |
| Cart Service | 8084 | Redis | Redis Hash, Feign |
| Payment Service | 8085 | Oracle (PAYMENTS) | Kafka, simulation |
| Review Service | 8086 | Oracle (PRODUCT_REVIEWS) | JPA, Flyway |
| Notification Service | 8087 | — | Kafka consumer |

---

## 🎨 React Pages

| Route | Page | Features |
|-------|------|---------|
| `/` | Home | Hero carousel, category grid, product grid |
| `/search` | Search | Filters (price, category), sort, pagination |
| `/product/:id` | Product Detail | Image carousel, buy box, reviews, ratings |
| `/cart` | Cart | Qty controls, price breakdown, free shipping |
| `/checkout` | Checkout | 3-step: address → payment → review & place |
| `/orders` | My Orders | Order history with status |
| `/orders/:id` | Order Detail | Progress tracker, items, cancel |
| `/login` | Login | Email/phone + password |
| `/register` | Register | Customer signup |
| `/profile` | Profile | Edit details, manage addresses |
| `/seller` | Seller Hub | List products, inventory table |

---

## 📡 Key API Endpoints

```
POST /api/auth/register        Register new customer
POST /api/auth/login           Login → returns JWT

GET  /api/products?keyword=    Search products
GET  /api/products/:id         Product detail
POST /api/products             Create product (seller)

GET  /api/cart                 Get cart with live pricing
POST /api/cart/items           Add item
PUT  /api/cart/items/:id       Update quantity
DELETE /api/cart/items/:id     Remove item

POST /api/orders               Place order
GET  /api/orders               My order history
GET  /api/orders/:id           Order detail
POST /api/orders/:id/cancel    Cancel order

POST /api/payments/initiate    Initiate payment
GET  /api/payments/order/:id   Payment for order

GET  /api/reviews/public/product/:id   Reviews list
POST /api/reviews/product/:id          Add review
```

---

## 🗄️ Oracle Schema Objects

```sql
-- User Service
AMAZON_USERS, USER_ADDRESSES

-- Product Service
PRODUCT_CATEGORIES, PRODUCTS, PRODUCT_IMAGES

-- Order Service
ORDERS, ORDER_ITEMS

-- Payment Service
PAYMENTS

-- Review Service
PRODUCT_REVIEWS
```

---

## 🔐 Security

- JWT Bearer tokens validated at API Gateway level
- Downstream services receive `X-User-Id`, `X-User-Email`, `X-User-Role` headers
- BCrypt (cost=12) for password hashing
- Public endpoints: `/api/auth/**`, `/api/products/**`, `/api/reviews/public/**`
- All other endpoints require valid JWT