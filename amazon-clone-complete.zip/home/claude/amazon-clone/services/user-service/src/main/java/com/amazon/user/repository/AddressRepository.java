package com.amazon.user.repository;
import com.amazon.user.entity.Address;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
public interface AddressRepository extends JpaRepository<Address, Long> {
    List<Address> findByUser_UserId(Long userId);
    Optional<Address> findByUser_UserIdAndIsDefaultTrue(Long userId);
}