package com.amazon.user.repository;
import com.amazon.user.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.Optional;
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    boolean existsByEmail(String email);
    boolean existsByPhoneNo(String phone);
    @Query("SELECT u FROM User u WHERE u.email = :login OR u.phoneNo = :login")
    Optional<User> findByEmailOrPhone(String login);
}