package com.amazon.user.service;

import com.amazon.user.entity.User;
import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Service
public class JwtService {
    @Value("${jwt.secret}")   private String secret;
    @Value("${jwt.access-expiry-ms:3600000}")  private long accessExpiry;
    @Value("${jwt.refresh-expiry-ms:604800000}") private long refreshExpiry;

    private SecretKey key() { return Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8)); }

    public String generateAccessToken(User u) {
        return Jwts.builder()
            .subject(String.valueOf(u.getUserId()))
            .claims(Map.of("email", u.getEmail(), "role", u.getRole().name(),
                           "name", u.getFullName(), "prime", u.isPrimeMember()))
            .issuedAt(new Date())
            .expiration(new Date(System.currentTimeMillis() + accessExpiry))
            .signWith(key()).compact();
    }

    public String generateRefreshToken(User u) {
        return Jwts.builder().subject(String.valueOf(u.getUserId()))
            .claims(Map.of("type","REFRESH"))
            .issuedAt(new Date())
            .expiration(new Date(System.currentTimeMillis() + refreshExpiry))
            .signWith(key()).compact();
    }

    public Claims parse(String token) {
        return Jwts.parser().verifyWith(key()).build().parseSignedClaims(token).getPayload();
    }

    public boolean isValid(String token) {
        try { parse(token); return true; } catch (Exception e) { return false; }
    }
}