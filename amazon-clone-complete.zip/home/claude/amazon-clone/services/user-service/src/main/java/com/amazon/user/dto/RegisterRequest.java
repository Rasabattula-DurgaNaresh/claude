package com.amazon.user.dto;
import jakarta.validation.constraints.*;
import lombok.Data;
@Data
public class RegisterRequest {
    @NotBlank @Size(min=2,max=50)  private String firstName;
    @NotBlank @Size(min=2,max=50)  private String lastName;
    @Email @NotBlank               private String email;
    @Pattern(regexp="^\\+?[0-9]{10,15}$") private String phoneNo;
    @NotBlank @Size(min=8)         private String password;
}