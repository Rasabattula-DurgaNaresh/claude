package com.amazon.user.service;

import com.amazon.user.dto.*;
import com.amazon.user.entity.User;
import com.amazon.user.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service @RequiredArgsConstructor @Slf4j
public class AuthService {

    private final UserRepository  userRepo;
    private final JwtService      jwtService;
    private final PasswordEncoder passwordEncoder;

    @Transactional
    public AuthResponse register(RegisterRequest req) {
        if (userRepo.existsByEmail(req.getEmail()))
            throw new IllegalArgumentException("Email already registered");

        User user = User.builder()
            .firstName(req.getFirstName()).lastName(req.getLastName())
            .email(req.getEmail().toLowerCase()).phoneNo(req.getPhoneNo())
            .passwordHash(passwordEncoder.encode(req.getPassword()))
            .role(User.Role.CUSTOMER).build();

        user = userRepo.save(user);
        log.info("Registered user: {}", user.getEmail());
        return buildResponse(user);
    }

    @Transactional
    public AuthResponse login(LoginRequest req) {
        User user = userRepo.findByEmailOrPhone(req.getLogin())
            .orElseThrow(() -> new IllegalArgumentException("Invalid credentials"));

        if (!passwordEncoder.matches(req.getPassword(), user.getPasswordHash()))
            throw new IllegalArgumentException("Invalid credentials");

        if (user.getStatus() != User.UserStatus.ACTIVE)
            throw new IllegalStateException("Account " + user.getStatus());

        user.setLastLoginAt(LocalDateTime.now());
        userRepo.save(user);
        return buildResponse(user);
    }

    private AuthResponse buildResponse(User u) {
        return AuthResponse.builder()
            .accessToken(jwtService.generateAccessToken(u))
            .refreshToken(jwtService.generateRefreshToken(u))
            .userId(u.getUserId()).email(u.getEmail())
            .fullName(u.getFullName()).role(u.getRole().name())
            .primeMember(u.isPrimeMember()).build();
    }
}