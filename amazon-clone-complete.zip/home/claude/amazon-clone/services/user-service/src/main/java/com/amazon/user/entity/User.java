package com.amazon.user.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import java.time.LocalDateTime;
import java.util.*;

@Entity @Table(name = "AMAZON_USERS",
    uniqueConstraints = {
        @UniqueConstraint(columnNames="EMAIL",    name="UQ_USER_EMAIL"),
        @UniqueConstraint(columnNames="PHONE_NO", name="UQ_USER_PHONE")
    })
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class User {
    @Id @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq_user")
    @SequenceGenerator(name="seq_user", sequenceName="SEQ_AMAZON_USERS", allocationSize=50, initialValue=1001)
    @Column(name="USER_ID") private Long userId;

    @Column(name="FIRST_NAME",  nullable=false, length=50)  private String firstName;
    @Column(name="LAST_NAME",   nullable=false, length=50)  private String lastName;
    @Column(name="EMAIL",       nullable=false, length=100) private String email;
    @Column(name="PHONE_NO",    length=15)                  private String phoneNo;
    @Column(name="PASSWORD_HASH", nullable=false)           private String passwordHash;
    @Column(name="PROFILE_IMAGE_URL")                       private String profileImageUrl;
    @Column(name="DATE_OF_BIRTH")                           private java.time.LocalDate dateOfBirth;

    @Enumerated(EnumType.STRING)
    @Column(name="ROLE", nullable=false, length=20)
    @Builder.Default private Role role = Role.CUSTOMER;

    @Enumerated(EnumType.STRING)
    @Column(name="STATUS", nullable=false, length=20)
    @Builder.Default private UserStatus status = UserStatus.ACTIVE;

    @Column(name="IS_EMAIL_VERIFIED") @Builder.Default private boolean emailVerified = false;
    @Column(name="IS_PRIME_MEMBER")   @Builder.Default private boolean primeMember   = false;
    @Column(name="PRIME_EXPIRY")                          private LocalDateTime primeExpiry;
    @Column(name="TOTAL_ORDERS")      @Builder.Default private int totalOrders = 0;
    @Column(name="TOTAL_SPENT")       @Builder.Default private java.math.BigDecimal totalSpent = java.math.BigDecimal.ZERO;

    @Version @Column(name="VERSION") private Long version;
    @CreationTimestamp @Column(name="CREATED_AT", updatable=false) private LocalDateTime createdAt;
    @UpdateTimestamp   @Column(name="UPDATED_AT")                  private LocalDateTime updatedAt;
    @Column(name="LAST_LOGIN_AT")                                  private LocalDateTime lastLoginAt;

    @OneToMany(mappedBy="user", cascade=CascadeType.ALL, fetch=FetchType.LAZY)
    @Builder.Default private List<Address> addresses = new ArrayList<>();

    public enum Role       { CUSTOMER, SELLER, ADMIN }
    public enum UserStatus { ACTIVE, SUSPENDED, DEACTIVATED }
    public String getFullName() { return firstName + " " + lastName; }
}