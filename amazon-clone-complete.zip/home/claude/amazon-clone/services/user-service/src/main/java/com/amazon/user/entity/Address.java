package com.amazon.user.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity @Table(name="USER_ADDRESSES")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Address {
    @Id @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq_addr")
    @SequenceGenerator(name="seq_addr", sequenceName="SEQ_USER_ADDRESSES", allocationSize=10, initialValue=1)
    @Column(name="ADDRESS_ID") private Long addressId;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="USER_ID", nullable=false)
    private User user;

    @Column(name="ADDRESS_TYPE",  length=20)  private String addressType;  // HOME, WORK, OTHER
    @Column(name="FULL_NAME",     nullable=false) private String fullName;
    @Column(name="PHONE_NO",      length=15)  private String phoneNo;
    @Column(name="LINE1",         nullable=false) private String line1;
    @Column(name="LINE2")                     private String line2;
    @Column(name="CITY",          nullable=false) private String city;
    @Column(name="STATE",         nullable=false) private String state;
    @Column(name="PINCODE",       nullable=false, length=10) private String pincode;
    @Column(name="COUNTRY",       nullable=false, length=50) @Builder.Default private String country = "India";
    @Column(name="IS_DEFAULT")    @Builder.Default private boolean isDefault = false;
    @Column(name="LATITUDE")  private Double latitude;
    @Column(name="LONGITUDE") private Double longitude;
}