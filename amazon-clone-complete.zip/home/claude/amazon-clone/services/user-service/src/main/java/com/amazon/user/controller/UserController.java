package com.amazon.user.controller;

import com.amazon.user.entity.*;
import com.amazon.user.repository.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController @RequestMapping("/api/users")
@RequiredArgsConstructor @Tag(name = "User Management")
public class UserController {

    private final UserRepository    userRepo;
    private final AddressRepository addressRepo;

    @GetMapping("/me")
    @Operation(summary = "Get current user profile")
    public ResponseEntity<User> getMe(@RequestHeader("X-User-Id") String userId) {
        return userRepo.findById(Long.parseLong(userId))
            .map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/me")
    public ResponseEntity<User> updateProfile(
            @RequestHeader("X-User-Id") String userId,
            @RequestBody Map<String, Object> updates) {
        return userRepo.findById(Long.parseLong(userId)).map(user -> {
            if (updates.containsKey("firstName")) user.setFirstName((String) updates.get("firstName"));
            if (updates.containsKey("lastName"))  user.setLastName((String)  updates.get("lastName"));
            if (updates.containsKey("phoneNo"))   user.setPhoneNo((String)   updates.get("phoneNo"));
            return ResponseEntity.ok(userRepo.save(user));
        }).orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/me/addresses")
    public ResponseEntity<List<Address>> getAddresses(@RequestHeader("X-User-Id") String userId) {
        return ResponseEntity.ok(addressRepo.findByUser_UserId(Long.parseLong(userId)));
    }

    @PostMapping("/me/addresses")
    public ResponseEntity<Address> addAddress(
            @RequestHeader("X-User-Id") String userId,
            @RequestBody Address req) {
        return userRepo.findById(Long.parseLong(userId)).map(user -> {
            req.setUser(user);
            if (req.isDefault()) {
                addressRepo.findByUser_UserIdAndIsDefaultTrue(user.getUserId())
                    .ifPresent(a -> { a.setDefault(false); addressRepo.save(a); });
            }
            return ResponseEntity.ok(addressRepo.save(req));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/me/addresses/{addressId}")
    public ResponseEntity<Void> deleteAddress(@PathVariable Long addressId) {
        addressRepo.deleteById(addressId);
        return ResponseEntity.noContent().build();
    }
}