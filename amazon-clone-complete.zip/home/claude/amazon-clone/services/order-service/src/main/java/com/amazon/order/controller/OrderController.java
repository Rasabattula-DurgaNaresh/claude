package com.amazon.order.controller;

import com.amazon.order.dto.PlaceOrderRequest;
import com.amazon.order.entity.Order;
import com.amazon.order.service.OrderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController @RequestMapping("/api/orders")
@RequiredArgsConstructor @Tag(name = "Orders")
public class OrderController {

    private final OrderService orderService;

    @PostMapping
    @Operation(summary = "Place a new order")
    public ResponseEntity<Order> placeOrder(
            @RequestHeader("X-User-Id") String userId,
            @RequestBody @Valid PlaceOrderRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(orderService.placeOrder(Long.parseLong(userId), req));
    }

    @GetMapping
    public ResponseEntity<Page<Order>> getMyOrders(
            @RequestHeader("X-User-Id") String userId,
            @RequestParam(defaultValue="0")  int page,
            @RequestParam(defaultValue="10") int size) {
        return ResponseEntity.ok(orderService.getUserOrders(Long.parseLong(userId), page, size));
    }

    @GetMapping("/{orderId}")
    public ResponseEntity<Order> getOrder(
            @PathVariable Long orderId,
            @RequestHeader("X-User-Id") String userId) {
        return ResponseEntity.ok(orderService.getOrder(orderId, Long.parseLong(userId)));
    }

    @PostMapping("/{orderId}/cancel")
    public ResponseEntity<Order> cancelOrder(
            @PathVariable Long orderId,
            @RequestHeader("X-User-Id") String userId,
            @RequestBody Map<String, String> body) {
        return ResponseEntity.ok(orderService.cancelOrder(orderId, Long.parseLong(userId), body.get("reason")));
    }

    @PatchMapping("/{orderId}/status")
    public ResponseEntity<Order> updateStatus(
            @PathVariable Long orderId,
            @RequestBody Map<String, String> body) {
        return ResponseEntity.ok(orderService.updateStatus(
            orderId, Order.OrderStatus.valueOf(body.get("status")), body.get("trackingNumber")));
    }
}