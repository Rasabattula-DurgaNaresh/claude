package com.amazon.order.client;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
@FeignClient(name="product-service", path="/api/products")
public interface ProductClient {
    @GetMapping("/{id}")
    ProductInfo getProduct(@PathVariable Long id);
    @PatchMapping("/{id}/reserve")
    boolean reserveStock(@PathVariable Long id, @RequestParam int qty);
    record ProductInfo(Long productId, String name, String sku, String thumbnailUrl,
                       BigDecimal sellingPrice, BigDecimal discountPct, int stockQuantity,
                       Long sellerId) {}
}