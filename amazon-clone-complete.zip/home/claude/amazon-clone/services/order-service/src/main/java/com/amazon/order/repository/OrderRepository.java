package com.amazon.order.repository;
import com.amazon.order.entity.Order;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.util.Optional;
public interface OrderRepository extends JpaRepository<Order, Long> {
    Optional<Order> findByOrderNumber(String orderNumber);
    Page<Order> findByUserIdOrderByCreatedAtDesc(Long userId, Pageable p);
    @Query("SELECT COUNT(o) FROM Order o WHERE o.userId = :uid AND o.status NOT IN ('CANCELLED','RETURNED')")
    long countActiveByUser(@Param("uid") Long userId);
}