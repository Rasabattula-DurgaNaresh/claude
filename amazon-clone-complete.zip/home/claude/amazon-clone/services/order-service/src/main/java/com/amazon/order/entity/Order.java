package com.amazon.order.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity @Table(name = "ORDERS")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Order {
    @Id @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq_order")
    @SequenceGenerator(name="seq_order", sequenceName="SEQ_ORDERS", allocationSize=1, initialValue=100001)
    @Column(name="ORDER_ID") private Long orderId;

    @Column(name="ORDER_NUMBER",  nullable=false, unique=true, length=30)  private String orderNumber;
    @Column(name="USER_ID",       nullable=false)  private Long   userId;
    @Column(name="ADDRESS_ID")                     private Long   addressId;
    @Column(name="DELIVERY_NAME",  length=100)     private String deliveryName;
    @Column(name="DELIVERY_PHONE", length=15)      private String deliveryPhone;
    @Column(name="DELIVERY_LINE1", length=200)     private String deliveryLine1;
    @Column(name="DELIVERY_LINE2", length=200)     private String deliveryLine2;
    @Column(name="DELIVERY_CITY",  length=100)     private String deliveryCity;
    @Column(name="DELIVERY_STATE", length=100)     private String deliveryState;
    @Column(name="DELIVERY_PINCODE",length=10)     private String deliveryPincode;

    @Column(name="SUBTOTAL",     nullable=false, precision=19, scale=2) private BigDecimal subtotal;
    @Column(name="DISCOUNT_AMT", precision=19, scale=2) @Builder.Default private BigDecimal discountAmt = BigDecimal.ZERO;
    @Column(name="SHIPPING_AMT", precision=19, scale=2) @Builder.Default private BigDecimal shippingAmt = BigDecimal.ZERO;
    @Column(name="TAX_AMT",      precision=19, scale=2) @Builder.Default private BigDecimal taxAmt      = BigDecimal.ZERO;
    @Column(name="TOTAL_AMT",    nullable=false, precision=19, scale=2) private BigDecimal totalAmt;
    @Column(name="COUPON_CODE",  length=30)  private String couponCode;

    @Enumerated(EnumType.STRING)
    @Column(name="STATUS", nullable=false, length=30)
    @Builder.Default private OrderStatus status = OrderStatus.PENDING;

    @Column(name="PAYMENT_METHOD",  length=30) private String paymentMethod;
    @Column(name="PAYMENT_STATUS",  length=20) @Builder.Default private String paymentStatus = "PENDING";
    @Column(name="PAYMENT_TXN_ID",  length=100) private String paymentTxnId;
    @Column(name="TRACKING_NUMBER", length=50)  private String trackingNumber;
    @Column(name="CARRIER",         length=50)  private String carrier;
    @Column(name="ESTIMATED_DELIVERY") private LocalDateTime estimatedDelivery;
    @Column(name="DELIVERED_AT")       private LocalDateTime deliveredAt;
    @Column(name="CANCELLED_AT")       private LocalDateTime cancelledAt;
    @Column(name="CANCEL_REASON",   length=500) private String cancelReason;
    @Column(name="IS_PRIME_ORDER") @Builder.Default private boolean primeOrder = false;

    @OneToMany(mappedBy="order", cascade=CascadeType.ALL, fetch=FetchType.EAGER)
    @Builder.Default private List<OrderItem> items = new ArrayList<>();

    @CreationTimestamp @Column(name="CREATED_AT", updatable=false) private LocalDateTime createdAt;
    @UpdateTimestamp   @Column(name="UPDATED_AT")                  private LocalDateTime updatedAt;

    public enum OrderStatus {
        PENDING, CONFIRMED, PROCESSING, SHIPPED, OUT_FOR_DELIVERY,
        DELIVERED, CANCELLED, RETURN_REQUESTED, RETURNED, REFUNDED
    }
}