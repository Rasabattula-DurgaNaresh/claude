package com.amazon.order.dto;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.util.List;
@Data
public class PlaceOrderRequest {
    @NotNull private Long addressId;
    private String deliveryName, deliveryPhone, deliveryLine1, deliveryCity, deliveryState, deliveryPincode;
    @NotEmpty private List<OrderItemRequest> items;
    @NotBlank private String paymentMethod;
    @Data
    public static class OrderItemRequest {
        @NotNull private Long productId;
        @Min(1)  private int  quantity;
    }
}