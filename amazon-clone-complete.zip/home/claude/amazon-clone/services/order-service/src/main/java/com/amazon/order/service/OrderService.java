package com.amazon.order.service;

import com.amazon.order.client.ProductClient;
import com.amazon.order.dto.*;
import com.amazon.order.entity.*;
import com.amazon.order.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.*;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

@Service @RequiredArgsConstructor @Slf4j
public class OrderService {

    private final OrderRepository orderRepo;
    private final ProductClient   productClient;
    private final KafkaTemplate<String, Object> kafka;

    @Transactional
    public Order placeOrder(Long userId, PlaceOrderRequest req) {
        List<OrderItem> items = new ArrayList<>();
        BigDecimal subtotal = BigDecimal.ZERO;

        for (PlaceOrderRequest.OrderItemRequest ir : req.getItems()) {
            ProductClient.ProductInfo product = productClient.getProduct(ir.getProductId());
            if (product.stockQuantity() < ir.getQuantity())
                throw new IllegalStateException("Insufficient stock for: " + product.name());

            BigDecimal total = product.sellingPrice().multiply(BigDecimal.valueOf(ir.getQuantity()));
            subtotal = subtotal.add(total);

            items.add(OrderItem.builder()
                .productId(product.productId())
                .sellerId(product.sellerId())
                .productName(product.name())
                .productSku(product.sku())
                .thumbnailUrl(product.thumbnailUrl())
                .quantity(ir.getQuantity())
                .unitPrice(product.sellingPrice())
                .totalPrice(total)
                .discountPct(product.discountPct())
                .build());
        }

        BigDecimal shipping = subtotal.compareTo(new BigDecimal("499")) >= 0 ? BigDecimal.ZERO : new BigDecimal("49");
        BigDecimal tax      = subtotal.multiply(new BigDecimal("0.18")).setScale(2, java.math.RoundingMode.HALF_UP);
        BigDecimal total    = subtotal.add(shipping).add(tax);

        String orderNum = "OD" + System.currentTimeMillis() % 10_000_000_000L;

        Order order = Order.builder()
            .orderNumber(orderNum)
            .userId(userId)
            .addressId(req.getAddressId())
            .deliveryName(req.getDeliveryName())
            .deliveryPhone(req.getDeliveryPhone())
            .deliveryLine1(req.getDeliveryLine1())
            .deliveryCity(req.getDeliveryCity())
            .deliveryState(req.getDeliveryState())
            .deliveryPincode(req.getDeliveryPincode())
            .subtotal(subtotal)
            .shippingAmt(shipping)
            .taxAmt(tax)
            .totalAmt(total)
            .paymentMethod(req.getPaymentMethod())
            .status(Order.OrderStatus.PENDING)
            .estimatedDelivery(LocalDateTime.now().plusDays(3))
            .items(items)
            .build();

        items.forEach(item -> item.setOrder(order));
        Order saved = orderRepo.save(order);

        kafka.send("order-events", Map.of(
            "event", "ORDER_PLACED",
            "orderId", saved.getOrderId(),
            "orderNumber", saved.getOrderNumber(),
            "userId", userId,
            "total", total,
            "items", items.size()
        ));

        log.info("Order {} placed by user {} — total {}", orderNum, userId, total);
        return saved;
    }

    @Transactional(readOnly = true)
    public Page<Order> getUserOrders(Long userId, int page, int size) {
        return orderRepo.findByUserIdOrderByCreatedAtDesc(userId, PageRequest.of(page, size));
    }

    @Transactional(readOnly = true)
    public Order getOrder(Long orderId, Long userId) {
        Order order = orderRepo.findById(orderId)
            .orElseThrow(() -> new RuntimeException("Order not found"));
        if (!order.getUserId().equals(userId))
            throw new SecurityException("Access denied");
        return order;
    }

    @Transactional
    public Order cancelOrder(Long orderId, Long userId, String reason) {
        Order order = getOrder(orderId, userId);
        if (!List.of(Order.OrderStatus.PENDING, Order.OrderStatus.CONFIRMED).contains(order.getStatus()))
            throw new IllegalStateException("Cannot cancel order in status: " + order.getStatus());
        order.setStatus(Order.OrderStatus.CANCELLED);
        order.setCancelledAt(LocalDateTime.now());
        order.setCancelReason(reason);
        Order saved = orderRepo.save(order);
        kafka.send("order-events", Map.of("event","ORDER_CANCELLED","orderId",orderId,"userId",userId));
        return saved;
    }

    @Transactional
    public Order updateStatus(Long orderId, Order.OrderStatus newStatus, String trackingNumber) {
        Order order = orderRepo.findById(orderId)
            .orElseThrow(() -> new RuntimeException("Order not found"));
        order.setStatus(newStatus);
        if (trackingNumber != null) order.setTrackingNumber(trackingNumber);
        if (newStatus == Order.OrderStatus.DELIVERED) order.setDeliveredAt(LocalDateTime.now());
        return orderRepo.save(order);
    }
}