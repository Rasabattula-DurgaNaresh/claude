package com.amazon.order.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;

@Entity @Table(name = "ORDER_ITEMS")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class OrderItem {
    @Id @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq_oi")
    @SequenceGenerator(name="seq_oi", sequenceName="SEQ_ORDER_ITEMS", allocationSize=5, initialValue=1)
    @Column(name="ITEM_ID") private Long itemId;

    @ManyToOne(fetch=FetchType.LAZY) @JoinColumn(name="ORDER_ID") private Order order;

    @Column(name="PRODUCT_ID",   nullable=false)       private Long   productId;
    @Column(name="SELLER_ID",    nullable=false)       private Long   sellerId;
    @Column(name="PRODUCT_NAME", nullable=false, length=300) private String productName;
    @Column(name="PRODUCT_SKU",  length=50)            private String productSku;
    @Column(name="THUMBNAIL_URL",length=500)           private String thumbnailUrl;
    @Column(name="QUANTITY",     nullable=false)       private int    quantity;
    @Column(name="UNIT_PRICE",   nullable=false, precision=19, scale=2) private BigDecimal unitPrice;
    @Column(name="TOTAL_PRICE",  nullable=false, precision=19, scale=2) private BigDecimal totalPrice;
    @Column(name="DISCOUNT_PCT", precision=5, scale=2) private BigDecimal discountPct;
    @Enumerated(EnumType.STRING)
    @Column(name="ITEM_STATUS",  length=20)
    @Builder.Default private ItemStatus itemStatus = ItemStatus.ACTIVE;
    @Column(name="RETURN_REASON", length=500) private String returnReason;

    public enum ItemStatus { ACTIVE, CANCELLED, RETURN_REQUESTED, RETURNED }
}