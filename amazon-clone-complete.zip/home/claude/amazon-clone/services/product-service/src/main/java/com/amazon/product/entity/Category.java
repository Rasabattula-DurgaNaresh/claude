package com.amazon.product.entity;
import jakarta.persistence.*;
import lombok.*;
import java.util.List;

@Entity @Table(name = "PRODUCT_CATEGORIES")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Category {
    @Id @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq_cat")
    @SequenceGenerator(name="seq_cat", sequenceName="SEQ_PRODUCT_CATEGORIES", allocationSize=1, initialValue=1)
    @Column(name="CATEGORY_ID") private Long categoryId;
    @Column(name="NAME",         nullable=false, length=100, unique=true) private String name;
    @Column(name="DESCRIPTION",  length=500)  private String description;
    @Column(name="IMAGE_URL")                 private String imageUrl;
    @Column(name="ICON")                      private String icon;
    @ManyToOne(fetch=FetchType.LAZY) @JoinColumn(name="PARENT_ID") private Category parent;
    @OneToMany(mappedBy="parent", fetch=FetchType.LAZY) private List<Category> children;
    @Column(name="SORT_ORDER") @Builder.Default private int sortOrder = 0;
    @Column(name="IS_ACTIVE")  @Builder.Default private boolean active = true;
}