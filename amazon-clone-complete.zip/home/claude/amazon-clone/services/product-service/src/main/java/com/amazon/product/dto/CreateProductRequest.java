package com.amazon.product.dto;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.math.BigDecimal;
import java.util.List;
@Data
public class CreateProductRequest {
    @NotBlank  @Size(max=300)  private String name;
    @NotNull                   private Long   categoryId;
    private String  description, brand, tags, specifications, thumbnailUrl;
    private List<String> imageUrls;
    @NotNull @DecimalMin("0.01") private BigDecimal mrpPrice;
    @NotNull @DecimalMin("0.01") private BigDecimal sellingPrice;
    @Min(0)                    private int stockQuantity;
    private Integer weightGrams;
}