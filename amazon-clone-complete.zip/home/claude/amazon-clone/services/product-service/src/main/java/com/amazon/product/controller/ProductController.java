package com.amazon.product.controller;

import com.amazon.product.dto.CreateProductRequest;
import com.amazon.product.entity.*;
import com.amazon.product.repository.CategoryRepository;
import com.amazon.product.service.ProductService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController @RequestMapping("/api/products")
@RequiredArgsConstructor @Tag(name = "Products")
public class ProductController {

    private final ProductService    productService;
    private final CategoryRepository categoryRepo;

    @GetMapping
    @Operation(summary = "Search and browse products")
    public ResponseEntity<Page<Product>> search(
            @RequestParam(required=false) String keyword,
            @RequestParam(required=false) Long   categoryId,
            @RequestParam(required=false) BigDecimal minPrice,
            @RequestParam(required=false) BigDecimal maxPrice,
            @RequestParam(defaultValue="relevance") String sortBy,
            @RequestParam(defaultValue="desc")      String sortDir,
            @RequestParam(defaultValue="0")  int page,
            @RequestParam(defaultValue="20") int size) {
        return ResponseEntity.ok(productService.searchProducts(keyword, categoryId, minPrice, maxPrice, sortBy, sortDir, page, size));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Product> getProduct(@PathVariable Long id) {
        return ResponseEntity.ok(productService.getProduct(id));
    }

    @PostMapping
    public ResponseEntity<Product> createProduct(
            @RequestHeader("X-User-Id") String sellerId,
            @RequestBody @Valid CreateProductRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(productService.createProduct(Long.parseLong(sellerId), req));
    }

    @PatchMapping("/{id}")
    public ResponseEntity<Product> updateProduct(
            @PathVariable Long id,
            @RequestHeader("X-User-Id") String sellerId,
            @RequestBody Map<String, Object> updates) {
        return ResponseEntity.ok(productService.updateProduct(id, Long.parseLong(sellerId), updates));
    }

    @GetMapping("/featured")
    public ResponseEntity<Page<Product>> getFeatured(
            @RequestParam(defaultValue="0")  int page,
            @RequestParam(defaultValue="10") int size) {
        return ResponseEntity.ok(productService.searchProducts(null, null, null, null, "newest", "desc", page, size));
    }
}