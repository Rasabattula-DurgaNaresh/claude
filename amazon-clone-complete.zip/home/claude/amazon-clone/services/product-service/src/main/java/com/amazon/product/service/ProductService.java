package com.amazon.product.service;

import com.amazon.product.dto.*;
import com.amazon.product.entity.*;
import com.amazon.product.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.*;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;
import java.util.UUID;

@Service @RequiredArgsConstructor @Slf4j
public class ProductService {

    private final ProductRepository  productRepo;
    private final CategoryRepository categoryRepo;
    private final KafkaTemplate<String, Object> kafka;

    @Transactional
    public Product createProduct(Long sellerId, CreateProductRequest req) {
        Category category = categoryRepo.findById(req.getCategoryId())
            .orElseThrow(() -> new IllegalArgumentException("Category not found"));

        BigDecimal discount = req.getMrpPrice().subtract(req.getSellingPrice())
            .divide(req.getMrpPrice(), 4, RoundingMode.HALF_UP)
            .multiply(BigDecimal.valueOf(100))
            .setScale(2, RoundingMode.HALF_UP);

        Product product = Product.builder()
            .sellerId(sellerId)
            .name(req.getName())
            .description(req.getDescription())
            .brand(req.getBrand())
            .sku("SKU-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase())
            .asin("B" + System.currentTimeMillis() % 1_000_000_000L)
            .category(category)
            .mrpPrice(req.getMrpPrice())
            .sellingPrice(req.getSellingPrice())
            .discountPct(discount)
            .stockQuantity(req.getStockQuantity())
            .thumbnailUrl(req.getThumbnailUrl())
            .imageUrls(req.getImageUrls() != null ? req.getImageUrls() : java.util.List.of())
            .weightGrams(req.getWeightGrams())
            .specifications(req.getSpecifications())
            .tags(req.getTags())
            .primeEligible(true)
            .build();

        product = productRepo.save(product);

        kafka.send("product-events", Map.of(
            "event", "PRODUCT_CREATED",
            "productId", product.getProductId(),
            "name", product.getName(),
            "sellerId", sellerId
        ));

        log.info("Product created: {} by seller {}", product.getProductId(), sellerId);
        return product;
    }

    @Transactional(readOnly = true)
    public Page<Product> searchProducts(String keyword, Long categoryId,
                                        BigDecimal minPrice, BigDecimal maxPrice,
                                        String sortBy, String sortDir, int page, int size) {
        Sort sort = Sort.by(
            "asc".equalsIgnoreCase(sortDir) ? Sort.Direction.ASC : Sort.Direction.DESC,
            switch (sortBy != null ? sortBy : "relevance") {
                case "price"  -> "sellingPrice";
                case "rating" -> "ratingAvg";
                case "newest" -> "createdAt";
                default       -> "totalSold";
            }
        );
        Pageable pageable = PageRequest.of(page, size, sort);

        if (categoryId != null) {
            return productRepo.findByCategoryId(categoryId, pageable);
        }
        return productRepo.search(keyword, minPrice, maxPrice, pageable);
    }

    @Transactional(readOnly = true)
    public Product getProduct(Long productId) {
        return productRepo.findById(productId)
            .orElseThrow(() -> new RuntimeException("Product not found: " + productId));
    }

    @Transactional
    public boolean reserveStock(Long productId, int qty) {
        int updated = productRepo.decrementStock(productId, qty);
        return updated > 0;
    }

    @Transactional
    public Product updateProduct(Long productId, Long sellerId, Map<String, Object> updates) {
        Product p = productRepo.findById(productId)
            .orElseThrow(() -> new RuntimeException("Product not found"));
        if (!p.getSellerId().equals(sellerId))
            throw new SecurityException("Not your product");

        if (updates.containsKey("name"))          p.setName((String) updates.get("name"));
        if (updates.containsKey("sellingPrice"))   p.setSellingPrice(new BigDecimal(updates.get("sellingPrice").toString()));
        if (updates.containsKey("stockQuantity"))  p.setStockQuantity((Integer) updates.get("stockQuantity"));
        if (updates.containsKey("description"))    p.setDescription((String) updates.get("description"));
        return productRepo.save(p);
    }
}