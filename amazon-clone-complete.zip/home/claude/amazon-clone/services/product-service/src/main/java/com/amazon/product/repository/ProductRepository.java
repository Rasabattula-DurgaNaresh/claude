package com.amazon.product.repository;

import com.amazon.product.entity.Product;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

public interface ProductRepository extends JpaRepository<Product, Long> {
    Optional<Product> findByAsin(String asin);
    Optional<Product> findBySku(String sku);
    Page<Product> findByCategoryAndStatus(com.amazon.product.entity.Category cat, Product.ProductStatus status, Pageable p);
    Page<Product> findBySellerIdAndStatus(Long sellerId, Product.ProductStatus status, Pageable p);
    Page<Product> findByFeaturedTrueAndStatus(Product.ProductStatus status, Pageable p);

    @Query("SELECT p FROM Product p WHERE p.status = 'ACTIVE' AND " +
           "(:keyword IS NULL OR LOWER(p.name) LIKE LOWER(CONCAT('%',:keyword,'%')) OR " +
           "LOWER(p.brand) LIKE LOWER(CONCAT('%',:keyword,'%'))) AND " +
           "(:minPrice IS NULL OR p.sellingPrice >= :minPrice) AND " +
           "(:maxPrice IS NULL OR p.sellingPrice <= :maxPrice)")
    Page<Product> search(@Param("keyword") String keyword,
                         @Param("minPrice") BigDecimal minPrice,
                         @Param("maxPrice") BigDecimal maxPrice,
                         Pageable pageable);

    @Query("SELECT p FROM Product p WHERE p.category.categoryId = :catId AND p.status = 'ACTIVE'")
    Page<Product> findByCategoryId(@Param("catId") Long catId, Pageable p);

    @Modifying @Transactional
    @Query("UPDATE Product p SET p.stockQuantity = p.stockQuantity - :qty, p.totalSold = p.totalSold + :qty WHERE p.productId = :id AND p.stockQuantity >= :qty")
    int decrementStock(@Param("id") Long productId, @Param("qty") int qty);

    @Modifying @Transactional
    @Query("UPDATE Product p SET p.ratingAvg = :avg, p.ratingCount = :count WHERE p.productId = :id")
    void updateRating(@Param("id") Long productId, @Param("avg") BigDecimal avg, @Param("count") int count);
}