package com.amazon.product.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity @Table(name = "PRODUCTS",
    indexes = {
        @Index(name="IDX_PROD_SELLER",   columnList="SELLER_ID"),
        @Index(name="IDX_PROD_CATEGORY", columnList="CATEGORY_ID"),
        @Index(name="IDX_PROD_STATUS",   columnList="STATUS"),
        @Index(name="IDX_PROD_PRICE",    columnList="SELLING_PRICE")
    })
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Product {
    @Id @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq_prod")
    @SequenceGenerator(name="seq_prod", sequenceName="SEQ_PRODUCTS", allocationSize=50, initialValue=1001)
    @Column(name="PRODUCT_ID") private Long productId;

    @Column(name="SELLER_ID",   nullable=false)           private Long   sellerId;
    @Column(name="NAME",        nullable=false, length=300) private String name;
    @Column(name="DESCRIPTION", columnDefinition="CLOB")  private String description;
    @Column(name="BRAND",       length=100)               private String brand;
    @Column(name="SKU",         length=50, unique=true)   private String sku;
    @Column(name="ASIN",        length=20, unique=true)   private String asin;

    @ManyToOne(fetch=FetchType.EAGER) @JoinColumn(name="CATEGORY_ID")
    private Category category;

    @Column(name="MRP_PRICE",      nullable=false, precision=19, scale=2) private BigDecimal mrpPrice;
    @Column(name="SELLING_PRICE",  nullable=false, precision=19, scale=2) private BigDecimal sellingPrice;
    @Column(name="DISCOUNT_PCT",   precision=5, scale=2)                  private BigDecimal discountPct;
    @Column(name="STOCK_QUANTITY", nullable=false) @Builder.Default private int stockQuantity = 0;
    @Column(name="RESERVED_QTY")                  @Builder.Default private int reservedQty   = 0;
    @Column(name="WEIGHT_GRAMS")                   private Integer weightGrams;
    @Column(name="DIMENSIONS",     length=100)     private String  dimensions;
    @Column(name="THUMBNAIL_URL")                  private String  thumbnailUrl;
    @Column(name="VIDEO_URL")                      private String  videoUrl;

    @ElementCollection(fetch=FetchType.EAGER)
    @CollectionTable(name="PRODUCT_IMAGES", joinColumns=@JoinColumn(name="PRODUCT_ID"))
    @Column(name="IMAGE_URL")
    @Builder.Default private List<String> imageUrls = new ArrayList<>();

    @Column(name="RATING_AVG",   precision=3, scale=2) @Builder.Default private BigDecimal ratingAvg   = BigDecimal.ZERO;
    @Column(name="RATING_COUNT")                       @Builder.Default private int         ratingCount = 0;
    @Column(name="TOTAL_SOLD")                         @Builder.Default private int         totalSold   = 0;

    @Enumerated(EnumType.STRING)
    @Column(name="STATUS", nullable=false, length=20)
    @Builder.Default private ProductStatus status = ProductStatus.ACTIVE;

    @Column(name="IS_PRIME_ELIGIBLE") @Builder.Default private boolean primeEligible = true;
    @Column(name="IS_FEATURED")       @Builder.Default private boolean featured      = false;
    @Column(name="TAGS",              length=500)       private String tags;
    @Column(name="SPECIFICATIONS",    columnDefinition="CLOB") private String specifications;

    @Version @Column(name="VERSION") private Long version;
    @CreationTimestamp @Column(name="CREATED_AT", updatable=false) private LocalDateTime createdAt;
    @UpdateTimestamp   @Column(name="UPDATED_AT")                  private LocalDateTime updatedAt;

    public enum ProductStatus { ACTIVE, INACTIVE, OUT_OF_STOCK, DISCONTINUED }

    public int  getAvailableStock() { return stockQuantity - reservedQty; }
    public boolean isInStock()      { return getAvailableStock() > 0; }
}