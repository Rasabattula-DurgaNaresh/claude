package com.amazon.product.controller;
import com.amazon.product.entity.Category;
import com.amazon.product.repository.CategoryRepository;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/categories")
@RequiredArgsConstructor @Tag(name = "Categories")
public class CategoryController {
    private final CategoryRepository categoryRepo;
    @GetMapping
    public ResponseEntity<List<Category>> getRootCategories() {
        return ResponseEntity.ok(categoryRepo.findByParentIsNullAndActiveTrue());
    }
    @GetMapping("/{id}/subcategories")
    public ResponseEntity<List<Category>> getSubcategories(@PathVariable Long id) {
        return ResponseEntity.ok(categoryRepo.findByParent_CategoryIdAndActiveTrue(id));
    }
    @GetMapping("/{id}")
    public ResponseEntity<Category> getCategory(@PathVariable Long id) {
        return categoryRepo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
}