package com.amazon.review.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;

@Entity @Table(name="PRODUCT_REVIEWS",
    uniqueConstraints = @UniqueConstraint(columnNames={"PRODUCT_ID","USER_ID"}, name="UQ_REVIEW_USER_PRODUCT"))
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Review {
    @Id @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq_rev")
    @SequenceGenerator(name="seq_rev", sequenceName="SEQ_PRODUCT_REVIEWS", allocationSize=10, initialValue=1)
    @Column(name="REVIEW_ID")      private Long   reviewId;
    @Column(name="PRODUCT_ID",     nullable=false) private Long   productId;
    @Column(name="USER_ID",        nullable=false) private Long   userId;
    @Column(name="USER_NAME",      length=100)     private String userName;
    @Column(name="RATING",         nullable=false) private int    rating;   // 1-5
    @Column(name="TITLE",          length=200)     private String title;
    @Column(name="BODY",           columnDefinition="CLOB") private String body;
    @Column(name="VERIFIED_PURCHASE") @Builder.Default private boolean verifiedPurchase = false;
    @Column(name="HELPFUL_COUNT")  @Builder.Default private int    helpfulCount = 0;
    @Column(name="IS_APPROVED")    @Builder.Default private boolean approved = true;
    @CreationTimestamp @Column(name="CREATED_AT", updatable=false) private LocalDateTime createdAt;
}