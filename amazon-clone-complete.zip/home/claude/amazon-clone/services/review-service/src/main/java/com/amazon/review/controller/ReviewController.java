package com.amazon.review.controller;

import com.amazon.review.entity.Review;
import com.amazon.review.repository.ReviewRepository;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController @RequestMapping("/api/reviews")
@RequiredArgsConstructor
public class ReviewController {

    private final ReviewRepository reviewRepo;

    @GetMapping("/public/product/{productId}")
    public ResponseEntity<Page<Review>> getProductReviews(
            @PathVariable Long productId,
            @RequestParam(defaultValue="0")  int page,
            @RequestParam(defaultValue="10") int size) {
        return ResponseEntity.ok(reviewRepo.findByProductIdAndApprovedTrueOrderByCreatedAtDesc(
            productId, PageRequest.of(page, size)));
    }

    @GetMapping("/public/product/{productId}/stats")
    public ResponseEntity<Map<String, Object>> getStats(@PathVariable Long productId) {
        Object[] stats = reviewRepo.getStats(productId);
        return ResponseEntity.ok(Map.of(
            "averageRating", stats[0] != null ? stats[0] : 0,
            "totalReviews",  stats[1] != null ? stats[1] : 0
        ));
    }

    @PostMapping("/product/{productId}")
    public ResponseEntity<Review> addReview(
            @PathVariable Long productId,
            @RequestHeader("X-User-Id")    String userId,
            @RequestHeader("X-User-Name") String userName,
            @RequestBody @Valid ReviewRequest req) {

        if (reviewRepo.findByProductIdAndUserId(productId, Long.parseLong(userId)).isPresent())
            return ResponseEntity.status(HttpStatus.CONFLICT).build();

        Review review = Review.builder()
            .productId(productId).userId(Long.parseLong(userId))
            .userName(userName).rating(req.getRating())
            .title(req.getTitle()).body(req.getBody()).build();

        return ResponseEntity.status(HttpStatus.CREATED).body(reviewRepo.save(review));
    }

    @PostMapping("/{reviewId}/helpful")
    public ResponseEntity<Void> markHelpful(@PathVariable Long reviewId) {
        reviewRepo.findById(reviewId).ifPresent(r -> {
            r.setHelpfulCount(r.getHelpfulCount() + 1);
            reviewRepo.save(r);
        });
        return ResponseEntity.ok().build();
    }

    @Data
    public static class ReviewRequest {
        @Min(1) @Max(5) private int rating;
        @NotBlank @Size(max=200) private String title;
        @NotBlank @Size(max=5000) private String body;
    }
}