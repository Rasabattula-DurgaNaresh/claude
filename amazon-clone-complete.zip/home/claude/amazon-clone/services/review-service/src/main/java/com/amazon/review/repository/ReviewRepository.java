package com.amazon.review.repository;
import com.amazon.review.entity.Review;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.util.Optional;
public interface ReviewRepository extends JpaRepository<Review, Long> {
    Page<Review> findByProductIdAndApprovedTrueOrderByCreatedAtDesc(Long productId, Pageable p);
    Optional<Review> findByProductIdAndUserId(Long productId, Long userId);
    @Query("SELECT AVG(r.rating), COUNT(r) FROM Review r WHERE r.productId = :pid AND r.approved = true")
    Object[] getStats(@Param("pid") Long productId);
}