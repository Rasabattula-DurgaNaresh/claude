package com.amazon.notification.consumer;

import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import java.util.Map;

@Component @Slf4j
public class EventConsumer {

    @KafkaListener(topics="order-events",   groupId="notification-group")
    public void handleOrder(Map<String, Object> event) {
        String type = (String) event.get("event");
        log.info("[Notify] Order event: {}", type);
        switch (type) {
            case "ORDER_PLACED"    -> log.info("  📧 Send order confirmation email for order {}", event.get("orderNumber"));
            case "ORDER_CANCELLED" -> log.info("  📧 Send cancellation email for order {}", event.get("orderId"));
            default                -> {}
        }
    }

    @KafkaListener(topics="payment-events", groupId="notification-group")
    public void handlePayment(Map<String, Object> event) {
        String type = (String) event.get("event");
        log.info("[Notify] Payment event: {}", type);
        switch (type) {
            case "PAYMENT_SUCCESS" -> log.info("  📧 Send payment receipt for txn {}", event.get("txnId"));
            case "PAYMENT_FAILED"  -> log.info("  📧 Send payment failure notification");
            case "PAYMENT_REFUNDED"-> log.info("  📧 Send refund notification");
            default                -> {}
        }
    }

    @KafkaListener(topics="product-events", groupId="notification-group")
    public void handleProduct(Map<String, Object> event) {
        log.info("[Notify] Product event: {}", event.get("event"));
    }
}