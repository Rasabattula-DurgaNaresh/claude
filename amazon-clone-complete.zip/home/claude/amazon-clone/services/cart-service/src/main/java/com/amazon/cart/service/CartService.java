package com.amazon.cart.service;

import com.amazon.cart.client.ProductClient;
import com.amazon.cart.dto.CartDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * Cart stored in Redis as hash: cart:{userId} → {productId: qty}
 * Expires in 30 days. Product details fetched from product-service.
 */
@Service @RequiredArgsConstructor @Slf4j
public class CartService {

    private final RedisTemplate<String, Object> redisTemplate;
    private final ProductClient productClient;

    private static final String KEY_PREFIX = "cart:";
    private static final long   TTL_DAYS   = 30;

    private String key(Long userId) { return KEY_PREFIX + userId; }

    private HashOperations<String, String, Integer> hash() {
        return redisTemplate.opsForHash();
    }

    public void addItem(Long userId, Long productId, int quantity) {
        String k   = key(userId);
        String pid = productId.toString();
        Integer current = hash().get(k, pid);
        int newQty = (current == null ? 0 : current) + quantity;
        hash().put(k, pid, newQty);
        redisTemplate.expire(k, TTL_DAYS, TimeUnit.DAYS);
        log.info("Cart add: user={} product={} qty={}", userId, productId, newQty);
    }

    public void updateItem(Long userId, Long productId, int quantity) {
        String k   = key(userId);
        String pid = productId.toString();
        if (quantity <= 0) {
            hash().delete(k, pid);
        } else {
            hash().put(k, pid, quantity);
            redisTemplate.expire(k, TTL_DAYS, TimeUnit.DAYS);
        }
    }

    public void removeItem(Long userId, Long productId) {
        hash().delete(key(userId), productId.toString());
    }

    public void clearCart(Long userId) {
        redisTemplate.delete(key(userId));
    }

    public CartDto getCart(Long userId) {
        Map<String, Integer> cartMap = hash().entries(key(userId));
        if (cartMap == null || cartMap.isEmpty()) {
            return CartDto.builder().userId(userId).items(List.of())
                .subtotal(BigDecimal.ZERO).discount(BigDecimal.ZERO)
                .shipping(BigDecimal.ZERO).tax(BigDecimal.ZERO)
                .total(BigDecimal.ZERO).itemCount(0).freeShipping(true).build();
        }

        List<CartDto.CartItemDto> items = new ArrayList<>();
        BigDecimal subtotal  = BigDecimal.ZERO;
        BigDecimal mrpTotal  = BigDecimal.ZERO;
        int        itemCount = 0;

        for (Map.Entry<String, Integer> entry : cartMap.entrySet()) {
            Long productId = Long.parseLong(entry.getKey());
            int  qty       = entry.getValue();
            try {
                ProductClient.ProductInfo p = productClient.getProduct(productId);
                if (!"ACTIVE".equals(p.status())) continue;

                BigDecimal lineTotal = p.sellingPrice().multiply(BigDecimal.valueOf(qty));
                BigDecimal mrpLine   = p.mrpPrice().multiply(BigDecimal.valueOf(qty));
                subtotal  = subtotal.add(lineTotal);
                mrpTotal  = mrpTotal.add(mrpLine);
                itemCount += qty;

                items.add(CartDto.CartItemDto.builder()
                    .productId(p.productId()).name(p.name()).brand(p.brand())
                    .thumbnailUrl(p.thumbnailUrl()).mrpPrice(p.mrpPrice())
                    .sellingPrice(p.sellingPrice()).discountPct(p.discountPct())
                    .quantity(qty).maxQty(Math.min(p.stockQuantity(), 10))
                    .inStock(p.stockQuantity() > 0).primeEligible(p.primeEligible())
                    .sellerId(p.sellerId()).build());
            } catch (Exception e) {
                log.warn("Failed to fetch product {}: {}", productId, e.getMessage());
            }
        }

        boolean freeShip = subtotal.compareTo(new BigDecimal("499")) >= 0;
        BigDecimal ship  = freeShip ? BigDecimal.ZERO : new BigDecimal("49");
        BigDecimal tax   = subtotal.multiply(new BigDecimal("0.18")).setScale(2, RoundingMode.HALF_UP);
        BigDecimal disc  = mrpTotal.subtract(subtotal).setScale(2, RoundingMode.HALF_UP);

        return CartDto.builder()
            .userId(userId).items(items).subtotal(subtotal)
            .discount(disc).shipping(ship).tax(tax)
            .total(subtotal.add(ship).add(tax))
            .itemCount(itemCount).freeShipping(freeShip).build();
    }

    public int getCartCount(Long userId) {
        Map<String, Integer> m = hash().entries(key(userId));
        if (m == null) return 0;
        return m.values().stream().mapToInt(Integer::intValue).sum();
    }
}