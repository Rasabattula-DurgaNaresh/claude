package com.amazon.cart.controller;

import com.amazon.cart.dto.CartDto;
import com.amazon.cart.service.CartService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController @RequestMapping("/api/cart")
@RequiredArgsConstructor @Tag(name = "Shopping Cart")
public class CartController {

    private final CartService cartService;

    @GetMapping
    @Operation(summary = "Get cart contents with totals")
    public ResponseEntity<CartDto> getCart(@RequestHeader("X-User-Id") String userId) {
        return ResponseEntity.ok(cartService.getCart(Long.parseLong(userId)));
    }

    @PostMapping("/items")
    @Operation(summary = "Add item to cart")
    public ResponseEntity<Map<String,Object>> addItem(
            @RequestHeader("X-User-Id") String userId,
            @RequestBody Map<String, Object> body) {
        Long productId = Long.parseLong(body.get("productId").toString());
        int  qty       = Integer.parseInt(body.getOrDefault("quantity", "1").toString());
        cartService.addItem(Long.parseLong(userId), productId, qty);
        return ResponseEntity.ok(Map.of("message", "Added to cart",
            "cartCount", cartService.getCartCount(Long.parseLong(userId))));
    }

    @PutMapping("/items/{productId}")
    public ResponseEntity<CartDto> updateItem(
            @RequestHeader("X-User-Id") String userId,
            @PathVariable Long productId,
            @RequestBody Map<String, Integer> body) {
        cartService.updateItem(Long.parseLong(userId), productId, body.get("quantity"));
        return ResponseEntity.ok(cartService.getCart(Long.parseLong(userId)));
    }

    @DeleteMapping("/items/{productId}")
    public ResponseEntity<CartDto> removeItem(
            @RequestHeader("X-User-Id") String userId,
            @PathVariable Long productId) {
        cartService.removeItem(Long.parseLong(userId), productId);
        return ResponseEntity.ok(cartService.getCart(Long.parseLong(userId)));
    }

    @DeleteMapping
    public ResponseEntity<Void> clearCart(@RequestHeader("X-User-Id") String userId) {
        cartService.clearCart(Long.parseLong(userId));
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/count")
    public ResponseEntity<Map<String,Integer>> getCount(@RequestHeader("X-User-Id") String userId) {
        return ResponseEntity.ok(Map.of("count", cartService.getCartCount(Long.parseLong(userId))));
    }
}