package com.amazon.cart.dto;

import lombok.*;
import java.math.BigDecimal;
import java.util.*;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class CartDto {
    private Long userId;
    private List<CartItemDto> items;
    private BigDecimal subtotal;
    private BigDecimal discount;
    private BigDecimal shipping;
    private BigDecimal tax;
    private BigDecimal total;
    private int itemCount;
    private boolean freeShipping;
    private String couponCode;

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class CartItemDto {
        private Long   productId;
        private String name;
        private String thumbnailUrl;
        private String brand;
        private BigDecimal mrpPrice;
        private BigDecimal sellingPrice;
        private BigDecimal discountPct;
        private int    quantity;
        private int    maxQty;
        private boolean inStock;
        private boolean primeEligible;
        private Long   sellerId;
    }
}