package com.amazon.cart.client;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import java.math.BigDecimal;
@FeignClient(name="product-service", path="/api/products")
public interface ProductClient {
    @GetMapping("/{id}")
    ProductInfo getProduct(@PathVariable Long id);
    record ProductInfo(Long productId, String name, String brand, String thumbnailUrl,
                       BigDecimal mrpPrice, BigDecimal sellingPrice, BigDecimal discountPct,
                       int stockQuantity, boolean primeEligible, Long sellerId,
                       String status) {}
}