package com.amazon.payment.controller;

import com.amazon.payment.entity.Payment;
import com.amazon.payment.service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.util.Map;

@RestController @RequestMapping("/api/payments")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService paymentService;

    @PostMapping("/initiate")
    public ResponseEntity<Payment> initiatePayment(
            @RequestHeader("X-User-Id") String userId,
            @RequestBody Map<String, Object> body) {
        return ResponseEntity.ok(paymentService.initiatePayment(
            Long.parseLong(body.get("orderId").toString()),
            Long.parseLong(userId),
            new BigDecimal(body.get("amount").toString()),
            body.get("method").toString()
        ));
    }

    @GetMapping("/order/{orderId}")
    public ResponseEntity<Payment> getPaymentByOrder(@PathVariable Long orderId) {
        return ResponseEntity.ok(paymentService.getByOrderId(orderId));
    }

    @PostMapping("/refund/{orderId}")
    public ResponseEntity<Payment> refund(
            @PathVariable Long orderId,
            @RequestBody Map<String, Object> body) {
        return ResponseEntity.ok(paymentService.refund(
            orderId,
            new BigDecimal(body.get("amount").toString()),
            body.get("reason").toString()
        ));
    }
}