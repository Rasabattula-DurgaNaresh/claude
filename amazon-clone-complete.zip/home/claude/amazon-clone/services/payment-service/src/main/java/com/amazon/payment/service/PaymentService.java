package com.amazon.payment.service;

import com.amazon.payment.entity.Payment;
import com.amazon.payment.repository.PaymentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;

@Service @RequiredArgsConstructor @Slf4j
public class PaymentService {

    private final PaymentRepository paymentRepo;
    private final KafkaTemplate<String, Object> kafka;

    @Transactional
    public Payment initiatePayment(Long orderId, Long userId, BigDecimal amount, String method) {
        String txnId = "TXN" + UUID.randomUUID().toString().replace("-", "").substring(0, 20).toUpperCase();

        Payment payment = Payment.builder()
            .orderId(orderId).userId(userId)
            .txnId(txnId).amount(amount)
            .method(method).gateway("RAZORPAY")
            .status("INITIATED").build();

        payment = paymentRepo.save(payment);

        // Simulate payment gateway call
        boolean success = simulatePaymentGateway(amount, method);

        if (success) {
            payment.setStatus("SUCCESS");
            payment.setGatewayTxnId("GW" + System.currentTimeMillis());
            payment.setCompletedAt(LocalDateTime.now());
        } else {
            payment.setStatus("FAILED");
            payment.setFailureReason("Payment declined by bank");
        }

        payment = paymentRepo.save(payment);

        kafka.send("payment-events", Map.of(
            "event", success ? "PAYMENT_SUCCESS" : "PAYMENT_FAILED",
            "paymentId", payment.getPaymentId(),
            "orderId", orderId,
            "txnId", txnId,
            "amount", amount,
            "status", payment.getStatus()
        ));

        log.info("Payment {} for order {}: {}", txnId, orderId, payment.getStatus());
        return payment;
    }

    @Transactional
    public Payment refund(Long orderId, BigDecimal refundAmount, String reason) {
        Payment payment = paymentRepo.findByOrderId(orderId)
            .orElseThrow(() -> new RuntimeException("Payment not found for order: " + orderId));

        payment.setRefundAmount(refundAmount);
        payment.setRefundStatus("REFUNDED");
        payment.setRefundedAt(LocalDateTime.now());
        payment = paymentRepo.save(payment);

        kafka.send("payment-events", Map.of("event", "PAYMENT_REFUNDED",
            "orderId", orderId, "refundAmount", refundAmount));
        return payment;
    }

    public Payment getByOrderId(Long orderId) {
        return paymentRepo.findByOrderId(orderId)
            .orElseThrow(() -> new RuntimeException("Payment not found"));
    }

    private boolean simulatePaymentGateway(BigDecimal amount, String method) {
        // Simulate: 95% success rate
        return Math.random() > 0.05;
    }
}