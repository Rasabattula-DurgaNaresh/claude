package com.amazon.payment.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity @Table(name="PAYMENTS")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Payment {
    @Id @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq_pay")
    @SequenceGenerator(name="seq_pay", sequenceName="SEQ_PAYMENTS", allocationSize=1, initialValue=1)
    @Column(name="PAYMENT_ID")   private Long paymentId;
    @Column(name="ORDER_ID",     nullable=false)                  private Long   orderId;
    @Column(name="USER_ID",      nullable=false)                  private Long   userId;
    @Column(name="TXN_ID",       unique=true, length=100)         private String txnId;
    @Column(name="GATEWAY_TXN_ID",length=200)                    private String gatewayTxnId;
    @Column(name="AMOUNT",       nullable=false, precision=19, scale=2) private BigDecimal amount;
    @Column(name="CURRENCY",     length=5) @Builder.Default       private String currency = "INR";
    @Column(name="METHOD",       length=30)                       private String method;
    @Column(name="GATEWAY",      length=30)                       private String gateway;
    @Column(name="STATUS",       length=20) @Builder.Default      private String status = "INITIATED";
    @Column(name="FAILURE_REASON",length=500)                     private String failureReason;
    @Column(name="REFUND_AMOUNT",precision=19, scale=2)           private BigDecimal refundAmount;
    @Column(name="REFUND_STATUS",length=20)                       private String refundStatus;
    @Column(name="REFUNDED_AT")                                   private LocalDateTime refundedAt;
    @CreationTimestamp @Column(name="CREATED_AT", updatable=false) private LocalDateTime createdAt;
    @Column(name="COMPLETED_AT")                                  private LocalDateTime completedAt;
}