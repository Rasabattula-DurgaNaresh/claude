import { create } from 'zustand'
export const useCartStore = create(set => ({
  count: 0,
  cart:  null,
  setCount: n    => set({ count: n }),
  setCart:  cart => set({ cart, count: cart?.itemCount ?? 0 }),
}))