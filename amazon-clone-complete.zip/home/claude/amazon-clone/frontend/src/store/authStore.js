import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export const useAuthStore = create(
  persist(
    (set, get) => ({
      user:  null,
      token: null,
      isAuthenticated: false,
      login: data => set({
        user:  { userId: data.userId, email: data.email, fullName: data.fullName,
                 role: data.role, primeMember: data.primeMember },
        token: data.accessToken,
        isAuthenticated: true
      }),
      logout: () => set({ user: null, token: null, isAuthenticated: false }),
      updateUser: updates => set(s => ({ user: { ...s.user, ...updates } })),
    }),
    { name: 'amazon-auth' }
  )
)