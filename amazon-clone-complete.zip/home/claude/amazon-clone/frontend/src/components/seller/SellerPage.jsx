import React, { useState, useEffect } from 'react'
import { productApi, categoryApi } from '../../utils/api'
import toast from 'react-hot-toast'
import { Package, Plus, TrendingUp } from 'lucide-react'

export default function SellerPage() {
  const [products, setProducts] = useState([])
  const [categories, setCategories] = useState([])
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ name:'', categoryId:'', brand:'', mrpPrice:'', sellingPrice:'', stockQuantity:'', description:'', thumbnailUrl:'', tags:'' })
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    productApi.search({ size:50 }).then(r => setProducts(r.data?.content || [])).catch(()=>{})
    categoryApi.getAll().then(r => setCategories(r.data || [])).catch(()=>{})
  }, [])

  const submit = async e => {
    e.preventDefault(); setSaving(true)
    try {
      await productApi.create({ ...form, categoryId: Number(form.categoryId), mrpPrice: parseFloat(form.mrpPrice), sellingPrice: parseFloat(form.sellingPrice), stockQuantity: parseInt(form.stockQuantity) })
      toast.success('Product listed!')
      setShowForm(false)
      productApi.search({ size:50 }).then(r => setProducts(r.data?.content || []))
    } catch(err) { toast.error(err.response?.data?.message || 'Failed to create product') }
    finally { setSaving(false) }
  }

  const F = ({ label, field, type='text', placeholder, required=true }) => (
    <div>
      <label style={{ display:'block', fontSize:'12px', fontWeight:600, marginBottom:'3px', color:'#555' }}>{label}</label>
      <input type={type} required={required} placeholder={placeholder} value={form[field]}
        onChange={e=>setForm(f=>({...f,[field]:e.target.value}))}
        style={{ width:'100%', padding:'8px', border:'1px solid #ccc', borderRadius:'4px', fontSize:'13px' }} />
    </div>
  )

  return (
    <div style={{ maxWidth:'1100px', margin:'0 auto', padding:'24px 16px' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'24px' }}>
        <div>
          <h1 style={{ fontSize:'24px', fontWeight:700 }}>Seller Hub</h1>
          <p style={{ color:'#555', fontSize:'14px' }}>Manage your product listings</p>
        </div>
        <button onClick={()=>setShowForm(s=>!s)} style={{ display:'flex', alignItems:'center', gap:'6px', padding:'10px 20px', background:'#ffd814', border:'1px solid #fcd200', borderRadius:'6px', cursor:'pointer', fontWeight:600, fontSize:'14px' }}>
          <Plus size={16} /> Add Product
        </button>
      </div>

      {/* Stats */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(160px,1fr))', gap:'12px', marginBottom:'24px' }}>
        {[['Active Listings', products.length, Package],['Total Revenue', '₹0', TrendingUp]].map(([l,v,Icon])=>(
          <div key={l} style={{ background:'#fff', border:'1px solid #ddd', borderRadius:'8px', padding:'16px', display:'flex', gap:'12px', alignItems:'center' }}>
            <Icon size={24} color="#f08804" />
            <div><div style={{ fontSize:'12px', color:'#555' }}>{l}</div><div style={{ fontSize:'22px', fontWeight:700 }}>{v}</div></div>
          </div>
        ))}
      </div>

      {/* Add product form */}
      {showForm && (
        <div style={{ background:'#fff', border:'1px solid #ddd', borderRadius:'8px', padding:'24px', marginBottom:'24px' }}>
          <h2 style={{ fontSize:'18px', marginBottom:'16px' }}>List New Product</h2>
          <form onSubmit={submit} style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'12px' }}>
            <div style={{ gridColumn:'1/-1' }}><F label="Product Name" field="name" placeholder="Full product name" /></div>
            <div>
              <label style={{ display:'block', fontSize:'12px', fontWeight:600, marginBottom:'3px', color:'#555' }}>Category</label>
              <select required value={form.categoryId} onChange={e=>setForm(f=>({...f,categoryId:e.target.value}))}
                style={{ width:'100%', padding:'8px', border:'1px solid #ccc', borderRadius:'4px', fontSize:'13px' }}>
                <option value="">Select category</option>
                {categories.map(c=><option key={c.categoryId} value={c.categoryId}>{c.name}</option>)}
              </select>
            </div>
            <F label="Brand" field="brand" placeholder="Brand name" required={false} />
            <F label="MRP Price (₹)" field="mrpPrice" type="number" placeholder="0.00" />
            <F label="Selling Price (₹)" field="sellingPrice" type="number" placeholder="0.00" />
            <F label="Stock Quantity" field="stockQuantity" type="number" placeholder="0" />
            <F label="Thumbnail URL" field="thumbnailUrl" placeholder="https://..." required={false} />
            <F label="Tags (comma separated)" field="tags" placeholder="mobile, android, 5G" required={false} />
            <div style={{ gridColumn:'1/-1' }}>
              <label style={{ display:'block', fontSize:'12px', fontWeight:600, marginBottom:'3px', color:'#555' }}>Description</label>
              <textarea value={form.description} onChange={e=>setForm(f=>({...f,description:e.target.value}))}
                rows={4} placeholder="Product description..."
                style={{ width:'100%', padding:'8px', border:'1px solid #ccc', borderRadius:'4px', fontSize:'13px', resize:'vertical' }} />
            </div>
            <div style={{ gridColumn:'1/-1', display:'flex', gap:'8px' }}>
              <button type="submit" disabled={saving} style={{ padding:'10px 24px', background:'#ffd814', border:'1px solid #fcd200', borderRadius:'6px', cursor:'pointer', fontWeight:600, opacity:saving?0.7:1 }}>
                {saving ? 'Saving...' : 'List Product'}
              </button>
              <button type="button" onClick={()=>setShowForm(false)} style={{ padding:'10px 24px', background:'#f3f3f3', border:'1px solid #ccc', borderRadius:'6px', cursor:'pointer' }}>Cancel</button>
            </div>
          </form>
        </div>
      )}

      {/* Products table */}
      <div style={{ background:'#fff', border:'1px solid #ddd', borderRadius:'8px', overflow:'hidden' }}>
        <table style={{ width:'100%', borderCollapse:'collapse' }}>
          <thead>
            <tr style={{ background:'#f7f7f7', borderBottom:'1px solid #ddd' }}>
              {['Product','Category','Price','Stock','Rating','Status'].map(h=>(
                <th key={h} style={{ padding:'12px 16px', textAlign:'left', fontSize:'13px', fontWeight:600, color:'#555' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {products.length === 0 ? (
              <tr><td colSpan={6} style={{ padding:'48px', textAlign:'center', color:'#888' }}>No products yet. Add your first product!</td></tr>
            ) : products.map(p => (
              <tr key={p.productId} style={{ borderBottom:'1px solid #eee', transition:'background 0.1s' }}
                onMouseEnter={e=>e.currentTarget.style.background='#f9f9f9'}
                onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                <td style={{ padding:'12px 16px' }}>
                  <div style={{ display:'flex', alignItems:'center', gap:'12px' }}>
                    <img src={p.thumbnailUrl||`https://picsum.photos/seed/${p.productId}/40/40`} style={{ width:'40px', height:'40px', objectFit:'contain' }} />
                    <div>
                      <p style={{ fontSize:'13px', fontWeight:500, maxWidth:'200px', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{p.name}</p>
                      <p style={{ fontSize:'11px', color:'#555' }}>{p.sku}</p>
                    </div>
                  </div>
                </td>
                <td style={{ padding:'12px 16px', fontSize:'13px', color:'#555' }}>{p.category?.name}</td>
                <td style={{ padding:'12px 16px' }}>
                  <div style={{ fontSize:'14px', fontWeight:700 }}>₹{Number(p.sellingPrice).toLocaleString('en-IN')}</div>
                  {p.discountPct > 0 && <div style={{ fontSize:'11px', color:'#007600' }}>{Math.round(p.discountPct)}% off</div>}
                </td>
                <td style={{ padding:'12px 16px', fontSize:'13px', color: p.stockQuantity > 10 ? '#007600' : p.stockQuantity > 0 ? '#f08804' : '#c0392b', fontWeight:600 }}>
                  {p.stockQuantity}
                </td>
                <td style={{ padding:'12px 16px', fontSize:'13px' }}>
                  ⭐ {Number(p.ratingAvg||0).toFixed(1)} ({p.ratingCount||0})
                </td>
                <td style={{ padding:'12px 16px' }}>
                  <span style={{ padding:'3px 10px', borderRadius:'12px', fontSize:'11px', fontWeight:600, background: p.status==='ACTIVE'?'#d4edda':'#f8d7da', color: p.status==='ACTIVE'?'#155724':'#721c24' }}>
                    {p.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}