import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { CheckCircle } from 'lucide-react'
import { cartApi, orderApi, userApi } from '../../utils/api'
import { useCartStore } from '../../store/cartStore'
import toast from 'react-hot-toast'

const PAYMENT_METHODS = [
  { id:'UPI',          label:'UPI',              icon:'📱' },
  { id:'DEBIT_CARD',   label:'Debit Card',       icon:'💳' },
  { id:'CREDIT_CARD',  label:'Credit Card',      icon:'💳' },
  { id:'NET_BANKING',  label:'Net Banking',      icon:'🏦' },
  { id:'CASH_ON_DELIVERY', label:'Cash on Delivery', icon:'💵' },
]

export default function CheckoutPage() {
  const nav = useNavigate()
  const { cart, setCart, setCount } = useCartStore()
  const [addresses, setAddresses] = useState([])
  const [selectedAddr, setSelectedAddr] = useState(null)
  const [payment, setPayment] = useState('UPI')
  const [step, setStep]       = useState(1)
  const [placing, setPlacing] = useState(false)
  const [orderId, setOrderId] = useState(null)
  const [newAddr, setNewAddr] = useState({ fullName:'',phoneNo:'',line1:'',city:'',state:'',pincode:'',isDefault:false })

  useEffect(() => {
    if (!cart) cartApi.get().then(r => setCart(r.data)).catch(()=>{})
    userApi.getAddresses().then(r => {
      const addrs = r.data || []
      setAddresses(addrs)
      const def = addrs.find(a => a.isDefault) || addrs[0]
      if (def) setSelectedAddr(def)
    }).catch(()=>{})
  }, [])

  const addAddress = async () => {
    try {
      const r = await userApi.addAddress(newAddr)
      setAddresses(prev => [...prev, r.data])
      setSelectedAddr(r.data)
      toast.success('Address added')
    } catch { toast.error('Failed to add address') }
  }

  const placeOrder = async () => {
    if (!selectedAddr) { toast.error('Please select a delivery address'); return }
    setPlacing(true)
    try {
      const items = (cart?.items || []).map(i => ({ productId: i.productId, quantity: i.quantity }))
      const { data } = await orderApi.place({
        addressId: selectedAddr.addressId,
        deliveryName: selectedAddr.fullName, deliveryPhone: selectedAddr.phoneNo,
        deliveryLine1: selectedAddr.line1, deliveryCity: selectedAddr.city,
        deliveryState: selectedAddr.state, deliveryPincode: selectedAddr.pincode,
        items, paymentMethod: payment
      })
      setOrderId(data.orderId)
      await cartApi.clear()
      setCart(null); setCount(0)
      setStep(4)
    } catch(err) { toast.error(err.response?.data?.message || 'Order failed') }
    finally { setPlacing(false) }
  }

  if (step === 4) return (
    <div style={{ maxWidth:'600px', margin:'48px auto', padding:'24px', textAlign:'center' }}>
      <div style={{ background:'#fff', border:'1px solid #ddd', borderRadius:'8px', padding:'48px 32px' }}>
        <CheckCircle size={80} color="#007600" style={{ marginBottom:'24px' }} />
        <h1 style={{ fontSize:'26px', marginBottom:'12px' }}>Order Placed Successfully!</h1>
        <p style={{ color:'#555', marginBottom:'24px' }}>Thank you! Your order #{orderId} has been placed. You'll receive a confirmation email shortly.</p>
        <div style={{ display:'flex', gap:'12px', justifyContent:'center' }}>
          <button onClick={()=>nav('/orders')} style={{ padding:'12px 24px', background:'#ffd814', border:'1px solid #fcd200', borderRadius:'20px', cursor:'pointer', fontWeight:600 }}>View Order</button>
          <button onClick={()=>nav('/')} style={{ padding:'12px 24px', background:'#f3f3f3', border:'1px solid #ccc', borderRadius:'20px', cursor:'pointer' }}>Continue Shopping</button>
        </div>
      </div>
    </div>
  )

  const items = cart?.items || []

  return (
    <div style={{ maxWidth:'960px', margin:'0 auto', padding:'16px', display:'grid', gridTemplateColumns:'1fr 300px', gap:'16px', alignItems:'start' }}>
      <div>
        <h1 style={{ fontSize:'22px', fontWeight:400, marginBottom:'20px', background:'#fff', border:'1px solid #ddd', borderRadius:'8px', padding:'16px' }}>Checkout</h1>

        {/* Step 1: Address */}
        <div style={{ background:'#fff', border:`2px solid ${step===1?'#f08804':'#ddd'}`, borderRadius:'8px', padding:'20px', marginBottom:'12px' }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'16px' }}>
            <h2 style={{ fontSize:'16px', fontWeight:700 }}>1. Delivery Address</h2>
            {step > 1 && <button onClick={()=>setStep(1)} style={{ color:'#007185', background:'none', border:'none', cursor:'pointer', fontSize:'13px' }}>Change</button>}
          </div>
          {step === 1 && (
            <div>
              {addresses.map(a => (
                <label key={a.addressId} style={{ display:'flex', gap:'12px', padding:'12px', border:`1px solid ${selectedAddr?.addressId===a.addressId?'#007185':'#ddd'}`, borderRadius:'6px', cursor:'pointer', marginBottom:'8px' }}>
                  <input type="radio" name="addr" checked={selectedAddr?.addressId===a.addressId} onChange={()=>setSelectedAddr(a)} />
                  <div style={{ fontSize:'13px' }}>
                    <div style={{ fontWeight:600 }}>{a.fullName}</div>
                    <div style={{ color:'#555' }}>{a.line1}, {a.city}, {a.state} {a.pincode}</div>
                    <div style={{ color:'#555' }}>{a.phoneNo}</div>
                  </div>
                </label>
              ))}
              <div style={{ marginTop:'12px', padding:'12px', border:'1px dashed #ccc', borderRadius:'6px' }}>
                <p style={{ fontSize:'13px', fontWeight:600, marginBottom:'8px' }}>Add new address</p>
                <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'8px' }}>
                  {[['fullName','Full Name'],['phoneNo','Phone'],['line1','Address Line 1'],['city','City'],['state','State'],['pincode','Pincode']].map(([f,l])=>(
                    <input key={f} placeholder={l} value={newAddr[f]}
                      onChange={e=>setNewAddr(p=>({...p,[f]:e.target.value}))}
                      style={{ padding:'8px', border:'1px solid #ccc', borderRadius:'4px', fontSize:'13px' }} />
                  ))}
                </div>
                <button onClick={addAddress} style={{ marginTop:'8px', padding:'8px 16px', background:'#fff', border:'1px solid #ccc', borderRadius:'4px', cursor:'pointer', fontSize:'13px' }}>
                  Add Address
                </button>
              </div>
              <button onClick={()=>selectedAddr&&setStep(2)} disabled={!selectedAddr}
                style={{ marginTop:'12px', padding:'10px 24px', background:'#ffd814', border:'1px solid #fcd200', borderRadius:'20px', cursor:'pointer', opacity:selectedAddr?1:0.5 }}>
                Use this address
              </button>
            </div>
          )}
          {step > 1 && selectedAddr && (
            <p style={{ fontSize:'13px', color:'#555' }}>{selectedAddr.fullName} — {selectedAddr.line1}, {selectedAddr.city} {selectedAddr.pincode}</p>
          )}
        </div>

        {/* Step 2: Payment */}
        <div style={{ background:'#fff', border:`2px solid ${step===2?'#f08804':'#ddd'}`, borderRadius:'8px', padding:'20px', marginBottom:'12px', opacity:step<2?0.6:1 }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'16px' }}>
            <h2 style={{ fontSize:'16px', fontWeight:700 }}>2. Payment Method</h2>
            {step > 2 && <button onClick={()=>setStep(2)} style={{ color:'#007185', background:'none', border:'none', cursor:'pointer', fontSize:'13px' }}>Change</button>}
          </div>
          {step === 2 && (
            <div>
              {PAYMENT_METHODS.map(pm => (
                <label key={pm.id} style={{ display:'flex', gap:'12px', padding:'12px', border:`1px solid ${payment===pm.id?'#007185':'#ddd'}`, borderRadius:'6px', cursor:'pointer', marginBottom:'8px', alignItems:'center' }}>
                  <input type="radio" name="pay" value={pm.id} checked={payment===pm.id} onChange={()=>setPayment(pm.id)} />
                  <span style={{ fontSize:'1.2rem' }}>{pm.icon}</span>
                  <span style={{ fontSize:'14px' }}>{pm.label}</span>
                </label>
              ))}
              <button onClick={()=>setStep(3)} style={{ marginTop:'12px', padding:'10px 24px', background:'#ffd814', border:'1px solid #fcd200', borderRadius:'20px', cursor:'pointer' }}>
                Continue
              </button>
            </div>
          )}
          {step > 2 && <p style={{ fontSize:'13px', color:'#555' }}>{PAYMENT_METHODS.find(p=>p.id===payment)?.icon} {PAYMENT_METHODS.find(p=>p.id===payment)?.label}</p>}
        </div>

        {/* Step 3: Review */}
        {step >= 3 && (
          <div style={{ background:'#fff', border:`2px solid ${step===3?'#f08804':'#ddd'}`, borderRadius:'8px', padding:'20px' }}>
            <h2 style={{ fontSize:'16px', fontWeight:700, marginBottom:'16px' }}>3. Review & Place Order</h2>
            {items.slice(0,3).map(item=>(
              <div key={item.productId} style={{ display:'flex', gap:'12px', marginBottom:'12px' }}>
                <img src={item.thumbnailUrl||`https://picsum.photos/seed/${item.productId}/60/60`} style={{ width:'60px', height:'60px', objectFit:'contain' }} />
                <div style={{ fontSize:'13px' }}>
                  <p style={{ fontWeight:500 }}>{item.name}</p>
                  <p style={{ color:'#555' }}>Qty: {item.quantity} × ₹{Number(item.sellingPrice).toLocaleString('en-IN')}</p>
                </div>
              </div>
            ))}
            {items.length > 3 && <p style={{ fontSize:'13px', color:'#555' }}>+{items.length-3} more items</p>}
            <button onClick={placeOrder} disabled={placing}
              style={{ width:'100%', marginTop:'16px', padding:'14px', background:'#ffa41c', border:'1px solid #e59400', borderRadius:'20px', cursor:'pointer', fontSize:'16px', fontWeight:600, opacity:placing?0.7:1 }}>
              {placing ? 'Placing Order...' : 'Place your order'}
            </button>
            <p style={{ fontSize:'11px', color:'#555', marginTop:'8px', textAlign:'center' }}>
              By placing your order, you agree to Amazon's Conditions of Use
            </p>
          </div>
        )}
      </div>

      {/* Summary */}
      <div style={{ background:'#fff', border:'1px solid #ddd', borderRadius:'8px', padding:'20px', position:'sticky', top:'80px' }}>
        <button onClick={placeOrder} disabled={placing||step<3}
          style={{ width:'100%', padding:'12px', background:'#ffa41c', border:'1px solid #e59400', borderRadius:'20px', cursor:'pointer', fontSize:'14px', fontWeight:600, marginBottom:'16px', opacity:(placing||step<3)?0.5:1 }}>
          {placing ? 'Placing...' : 'Place your order'}
        </button>
        <p style={{ fontSize:'11px', color:'#555', marginBottom:'16px', textAlign:'center' }}>
          Order Total: <strong>₹{Number(cart?.total||0).toLocaleString('en-IN')}</strong>
        </p>
        <hr />
        <h3 style={{ fontSize:'14px', marginTop:'12px', marginBottom:'8px' }}>Order Summary</h3>
        {[['Items', cart?.subtotal],['Shipping', cart?.shipping],['Tax', cart?.tax]].map(([l,v])=>(
          <div key={l} style={{ display:'flex', justifyContent:'space-between', fontSize:'13px', marginBottom:'6px' }}>
            <span>{l}:</span><span>₹{Number(v||0).toLocaleString('en-IN')}</span>
          </div>
        ))}
        <hr style={{ margin:'8px 0' }} />
        <div style={{ display:'flex', justifyContent:'space-between', fontWeight:700, fontSize:'16px', color:'#B12704' }}>
          <span>Order Total:</span><span>₹{Number(cart?.total||0).toLocaleString('en-IN')}</span>
        </div>
      </div>
    </div>
  )
}