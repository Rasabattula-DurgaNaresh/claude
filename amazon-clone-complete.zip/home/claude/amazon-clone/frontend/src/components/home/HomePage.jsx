import React, { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { ChevronRight, Star, Truck, RotateCcw, Shield, Headphones } from 'lucide-react'
import ProductCard   from '../shared/ProductCard'
import { productApi, categoryApi } from '../../utils/api'

const HERO_BANNERS = [
  { bg:'linear-gradient(135deg,#1a1a2e,#16213e)', title:'Latest Electronics', sub:'Up to 70% off on Mobiles & Laptops', btn:'Shop Now', path:'/search?categoryId=1', img:'📱' },
  { bg:'linear-gradient(135deg,#2d1b69,#11998e)', title:'Fashion Sale', sub:'Mega End of Season Sale', btn:'Explore', path:'/search?categoryId=2', img:'👗' },
  { bg:'linear-gradient(135deg,#c0392b,#8e44ad)', title:'Home & Kitchen', sub:'Refresh Your Home', btn:'Discover', path:'/search?categoryId=3', img:'🏠' },
]

const CategoryCard = ({ cat }) => (
  <Link to={`/search?categoryId=${cat.categoryId}`}
    style={{ background:'#fff', border:'1px solid #e0e0e0', borderRadius:'8px', padding:'16px', textAlign:'center', textDecoration:'none', color:'inherit', display:'flex', flexDirection:'column', alignItems:'center', gap:'8px', transition:'all 0.2s' }}
    onMouseEnter={e=>{e.currentTarget.style.boxShadow='0 4px 12px rgba(0,0,0,0.12)';e.currentTarget.style.transform='translateY(-2px)'}}
    onMouseLeave={e=>{e.currentTarget.style.boxShadow='none';e.currentTarget.style.transform='none'}}>
    <span style={{ fontSize:'2.5rem' }}>{cat.icon || '📦'}</span>
    <span style={{ fontSize:'13px', fontWeight:600, color:'#0f1111' }}>{cat.name}</span>
  </Link>
)

export default function HomePage() {
  const nav = useNavigate()
  const [products, setProducts] = useState([])
  const [categories, setCategories] = useState([])
  const [heroIdx, setHeroIdx] = useState(0)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([
      productApi.getFeatured(),
      categoryApi.getAll()
    ]).then(([pr, cr]) => {
      setProducts(pr.data?.content || pr.data || [])
      setCategories(cr.data || [])
    }).catch(()=>{}).finally(() => setLoading(false))
  }, [])

  useEffect(() => {
    const iv = setInterval(() => setHeroIdx(i => (i + 1) % HERO_BANNERS.length), 4000)
    return () => clearInterval(iv)
  }, [])

  const hero = HERO_BANNERS[heroIdx]

  return (
    <main style={{ background:'#f3f3f3', minHeight:'100vh' }}>

      {/* Hero Banner */}
      <div style={{ background: hero.bg, color:'#fff', padding:'0', overflow:'hidden', position:'relative' }}>
        <div style={{ maxWidth:'1400px', margin:'0 auto', padding:'60px 32px', display:'flex', alignItems:'center', justifyContent:'space-between', gap:'32px' }}>
          <div style={{ flex:1 }}>
            <h1 style={{ fontSize:'3rem', fontWeight:800, marginBottom:'12px', lineHeight:1.1 }}>{hero.title}</h1>
            <p  style={{ fontSize:'1.2rem', marginBottom:'28px', opacity:0.9 }}>{hero.sub}</p>
            <button onClick={() => nav(hero.path)}
              style={{ background:'#ffd814', color:'#111', padding:'14px 32px', borderRadius:'25px', border:'none', fontSize:'16px', fontWeight:700, cursor:'pointer', transition:'all 0.2s' }}
              onMouseEnter={e=>e.currentTarget.style.background='#f7ca00'}
              onMouseLeave={e=>e.currentTarget.style.background='#ffd814'}>
              {hero.btn} →
            </button>
          </div>
          <div style={{ fontSize:'8rem', opacity:0.8 }}>{hero.img}</div>
        </div>
        {/* Dots */}
        <div style={{ position:'absolute', bottom:'12px', left:'50%', transform:'translateX(-50%)', display:'flex', gap:'6px' }}>
          {HERO_BANNERS.map((_,i) => (
            <div key={i} onClick={() => setHeroIdx(i)} style={{ width:'8px', height:'8px', borderRadius:'50%', background: i===heroIdx?'#ffd814':'rgba(255,255,255,0.5)', cursor:'pointer', transition:'background 0.2s' }} />
          ))}
        </div>
      </div>

      <div style={{ maxWidth:'1400px', margin:'0 auto', padding:'24px 16px' }}>

        {/* Trust signals */}
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))', gap:'12px', marginBottom:'32px' }}>
          {[
            { icon:<Truck size={20} color="#232f3e"/>,   title:'Free Delivery',    sub:'On orders above ₹499' },
            { icon:<RotateCcw size={20} color="#232f3e"/>,title:'Easy Returns',     sub:'10-day return policy' },
            { icon:<Shield size={20} color="#232f3e"/>,  title:'Secure Payments',  sub:'100% secure checkout' },
            { icon:<Headphones size={20} color="#232f3e"/>,title:'24/7 Support',   sub:'Dedicated customer care' },
          ].map((t, i) => (
            <div key={i} style={{ background:'#fff', border:'1px solid #e0e0e0', borderRadius:'8px', padding:'16px', display:'flex', alignItems:'center', gap:'12px' }}>
              <div style={{ padding:'10px', background:'#fff8e7', borderRadius:'8px' }}>{t.icon}</div>
              <div>
                <div style={{ fontWeight:700, fontSize:'14px' }}>{t.title}</div>
                <div style={{ fontSize:'12px', color:'#555' }}>{t.sub}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Categories */}
        <section style={{ marginBottom:'32px' }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'16px' }}>
            <h2 style={{ fontSize:'20px', fontWeight:700 }}>Shop by Category</h2>
            <Link to="/search" style={{ color:'#007185', fontSize:'13px', display:'flex', alignItems:'center', gap:'4px' }}>
              See all <ChevronRight size={14} />
            </Link>
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(110px,1fr))', gap:'12px' }}>
            {categories.map(c => <CategoryCard key={c.categoryId} cat={c} />)}
          </div>
        </section>

        {/* Products */}
        <section>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'16px' }}>
            <h2 style={{ fontSize:'20px', fontWeight:700 }}>Today's Deals</h2>
            <Link to="/search" style={{ color:'#007185', fontSize:'13px', display:'flex', alignItems:'center', gap:'4px' }}>
              See all deals <ChevronRight size={14} />
            </Link>
          </div>
          {loading ? (
            <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(200px,1fr))', gap:'12px' }}>
              {[...Array(8)].map((_,i) => (
                <div key={i} style={{ background:'#fff', border:'1px solid #ddd', borderRadius:'4px', height:'380px', animation:'pulse 1.5s ease infinite' }}>
                  <style>{`@keyframes pulse{0%,100%{opacity:1}50%{opacity:0.5}}`}</style>
                </div>
              ))}
            </div>
          ) : (
            <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(200px,1fr))', gap:'12px' }}>
              {products.slice(0, 20).map(p => <ProductCard key={p.productId} product={p} />)}
            </div>
          )}
          {!loading && products.length === 0 && (
            <div style={{ textAlign:'center', padding:'60px', color:'#888', background:'#fff', borderRadius:'8px' }}>
              <p style={{ fontSize:'18px', marginBottom:'8px' }}>No products yet</p>
              <p>Add products via the Seller Hub</p>
            </div>
          )}
        </section>
      </div>
    </main>
  )
}