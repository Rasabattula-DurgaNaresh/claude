import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import { authApi } from '../../utils/api'
import { useAuthStore } from '../../store/authStore'

export default function LoginPage() {
  const nav = useNavigate()
  const login = useAuthStore(s => s.login)
  const [form, setForm] = useState({ login:'', password:'' })
  const [loading, setLoading] = useState(false)

  const handle = async e => {
    e.preventDefault(); setLoading(true)
    try {
      const { data } = await authApi.login(form)
      login(data)
      toast.success(`Welcome back, ${data.fullName}!`)
      nav('/')
    } catch(err) { toast.error(err.response?.data?.message || 'Invalid credentials') }
    finally { setLoading(false) }
  }

  return (
    <div style={{ minHeight:'80vh', display:'flex', alignItems:'center', justifyContent:'center', padding:'24px', background:'#f3f3f3' }}>
      <div style={{ width:'100%', maxWidth:'380px' }}>
        <div style={{ textAlign:'center', marginBottom:'20px' }}>
          <Link to="/" style={{ fontSize:'2rem', fontWeight:900, letterSpacing:'-1px' }}>
            amazon<span style={{ color:'#f08804' }}>.in</span>
          </Link>
        </div>
        <div style={{ background:'#fff', border:'1px solid #d5d9d9', borderRadius:'8px', padding:'28px 24px' }}>
          <h1 style={{ fontSize:'22px', fontWeight:400, marginBottom:'20px' }}>Sign in</h1>
          <form onSubmit={handle}>
            <div style={{ marginBottom:'14px' }}>
              <label style={{ display:'block', fontSize:'13px', fontWeight:700, marginBottom:'4px' }}>Email or mobile phone number</label>
              <input type="text" required placeholder="Email or phone" value={form.login}
                onChange={e=>setForm(f=>({...f,login:e.target.value}))}
                style={{ width:'100%', padding:'8px', border:'1px solid #a6a6a6', borderRadius:'4px', fontSize:'13px', outline:'none' }} />
            </div>
            <div style={{ marginBottom:'18px' }}>
              <label style={{ display:'block', fontSize:'13px', fontWeight:700, marginBottom:'4px' }}>Password</label>
              <input type="password" required placeholder="Password" value={form.password}
                onChange={e=>setForm(f=>({...f,password:e.target.value}))}
                style={{ width:'100%', padding:'8px', border:'1px solid #a6a6a6', borderRadius:'4px', fontSize:'13px', outline:'none' }} />
            </div>
            <button type="submit" disabled={loading}
              style={{ width:'100%', padding:'9px', background:'#ffd814', border:'1px solid #fcd200', borderRadius:'8px', fontSize:'13px', cursor:'pointer', opacity:loading?0.7:1 }}>
              {loading ? 'Signing in...' : 'Continue'}
            </button>
          </form>
          <p style={{ fontSize:'11px', color:'#555', margin:'12px 0' }}>
            By continuing, you agree to Amazon's Conditions of Use and Privacy Notice.
          </p>
        </div>
        <div style={{ border:'1px solid #d5d9d9', borderRadius:'8px', padding:'16px', marginTop:'16px', textAlign:'center', background:'#fff' }}>
          <span style={{ fontSize:'13px', color:'#555' }}>New to Amazon? </span>
          <Link to="/register" style={{ color:'#007185', fontSize:'13px' }}>Create your Amazon account</Link>
        </div>

        <div style={{ marginTop:'20px', padding:'12px', background:'#fff8e7', border:'1px solid #ffd814', borderRadius:'6px', fontSize:'12px' }}>
          <strong>Demo credentials:</strong><br />
          admin@amazon.in / Admin@123456
        </div>
      </div>
    </div>
  )
}