import React, { useState, useEffect } from 'react'
import { useAuthStore } from '../../store/authStore'
import { userApi } from '../../utils/api'
import toast from 'react-hot-toast'
import { User, MapPin, Package, Crown } from 'lucide-react'

export default function ProfilePage() {
  const { user, updateUser } = useAuthStore()
  const [addresses, setAddresses] = useState([])
  const [tab, setTab] = useState('profile')
  const [editing, setEditing] = useState(false)
  const [form, setForm] = useState({ firstName: user?.fullName?.split(' ')[0] || '', lastName: user?.fullName?.split(' ')[1] || '' })

  useEffect(() => {
    userApi.getAddresses().then(r => setAddresses(r.data || [])).catch(()=>{})
  }, [])

  const saveProfile = async e => {
    e.preventDefault()
    try {
      const { data } = await userApi.updateMe(form)
      updateUser({ fullName: `${form.firstName} ${form.lastName}` })
      toast.success('Profile updated')
      setEditing(false)
    } catch { toast.error('Update failed') }
  }

  const btnStyle = active => ({
    padding:'10px 20px', border:'none', borderRadius:'6px', cursor:'pointer', fontSize:'14px', fontWeight:500,
    background: active ? '#232f3e' : '#f3f3f3', color: active ? '#fff' : '#333'
  })

  return (
    <div style={{ maxWidth:'960px', margin:'0 auto', padding:'24px 16px', minHeight:'70vh' }}>
      <h1 style={{ fontSize:'24px', fontWeight:700, marginBottom:'24px' }}>Your Account</h1>
      <div style={{ display:'flex', gap:'12px', marginBottom:'24px', flexWrap:'wrap' }}>
        {[['profile','Profile',User],['addresses','Addresses',MapPin],['orders','Orders',Package]].map(([id,label,Icon])=>(
          <button key={id} onClick={()=>setTab(id)} style={btnStyle(tab===id)}>
            <Icon size={14} style={{ marginRight:'6px', verticalAlign:'middle' }} />{label}
          </button>
        ))}
      </div>

      {tab === 'profile' && (
        <div style={{ background:'#fff', border:'1px solid #ddd', borderRadius:'8px', padding:'24px' }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:'20px' }}>
            <div style={{ display:'flex', alignItems:'center', gap:'16px' }}>
              <div style={{ width:'64px', height:'64px', borderRadius:'50%', background:'#ff9900', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'24px', color:'#fff', fontWeight:700 }}>
                {user?.fullName?.[0] || 'U'}
              </div>
              <div>
                <h2 style={{ fontSize:'20px', fontWeight:700 }}>{user?.fullName}</h2>
                <p style={{ color:'#555', fontSize:'14px' }}>{user?.email}</p>
                {user?.primeMember && (
                  <span style={{ background:'#232f3e', color:'#00a8cc', padding:'2px 8px', borderRadius:'12px', fontSize:'11px', fontWeight:700, display:'inline-flex', alignItems:'center', gap:'4px', marginTop:'4px' }}>
                    <Crown size={10} /> prime member
                  </span>
                )}
              </div>
            </div>
            {!editing && <button onClick={()=>setEditing(true)} style={{ padding:'8px 16px', background:'#ffd814', border:'1px solid #fcd200', borderRadius:'6px', cursor:'pointer', fontSize:'13px' }}>Edit</button>}
          </div>

          {editing ? (
            <form onSubmit={saveProfile}>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'12px', maxWidth:'480px' }}>
                <div>
                  <label style={{ display:'block', fontSize:'13px', fontWeight:600, marginBottom:'4px' }}>First Name</label>
                  <input value={form.firstName} onChange={e=>setForm(f=>({...f,firstName:e.target.value}))} style={{ width:'100%', padding:'8px', border:'1px solid #ccc', borderRadius:'4px' }} />
                </div>
                <div>
                  <label style={{ display:'block', fontSize:'13px', fontWeight:600, marginBottom:'4px' }}>Last Name</label>
                  <input value={form.lastName} onChange={e=>setForm(f=>({...f,lastName:e.target.value}))} style={{ width:'100%', padding:'8px', border:'1px solid #ccc', borderRadius:'4px' }} />
                </div>
              </div>
              <div style={{ display:'flex', gap:'8px', marginTop:'16px' }}>
                <button type="submit" style={{ padding:'8px 20px', background:'#ffd814', border:'1px solid #fcd200', borderRadius:'6px', cursor:'pointer' }}>Save</button>
                <button type="button" onClick={()=>setEditing(false)} style={{ padding:'8px 20px', background:'#f3f3f3', border:'1px solid #ccc', borderRadius:'6px', cursor:'pointer' }}>Cancel</button>
              </div>
            </form>
          ) : (
            <div style={{ fontSize:'14px', color:'#555' }}>
              <div style={{ marginBottom:'8px' }}><strong>Role:</strong> {user?.role}</div>
            </div>
          )}
        </div>
      )}

      {tab === 'addresses' && (
        <div style={{ background:'#fff', border:'1px solid #ddd', borderRadius:'8px', padding:'24px' }}>
          <h3 style={{ marginBottom:'16px' }}>Your Addresses</h3>
          {addresses.length === 0 ? (
            <p style={{ color:'#888' }}>No saved addresses. Add one at checkout.</p>
          ) : (
            <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(280px,1fr))', gap:'12px' }}>
              {addresses.map(a => (
                <div key={a.addressId} style={{ border:`2px solid ${a.isDefault?'#007185':'#ddd'}`, borderRadius:'6px', padding:'16px', fontSize:'13px' }}>
                  {a.isDefault && <div style={{ color:'#007185', fontWeight:700, marginBottom:'4px' }}>Default Address</div>}
                  <div style={{ fontWeight:600, marginBottom:'4px' }}>{a.fullName}</div>
                  <div style={{ color:'#555', lineHeight:1.6 }}>
                    {a.line1}{a.line2 && `, ${a.line2}`}<br/>
                    {a.city}, {a.state} {a.pincode}<br/>
                    {a.country}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  )
}