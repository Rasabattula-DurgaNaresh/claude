import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import { authApi } from '../../utils/api'
import { useAuthStore } from '../../store/authStore'

export default function RegisterPage() {
  const nav = useNavigate()
  const login = useAuthStore(s => s.login)
  const [form, setForm] = useState({ firstName:'', lastName:'', email:'', phoneNo:'', password:'' })
  const [loading, setLoading] = useState(false)

  const handle = async e => {
    e.preventDefault(); setLoading(true)
    try {
      const { data } = await authApi.register(form)
      login(data)
      toast.success('Account created!')
      nav('/')
    } catch(err) { toast.error(err.response?.data?.message || 'Registration failed') }
    finally { setLoading(false) }
  }

  const F = ({ label, field, type='text', placeholder }) => (
    <div style={{ marginBottom:'14px' }}>
      <label style={{ display:'block', fontSize:'13px', fontWeight:700, marginBottom:'4px' }}>{label}</label>
      <input type={type} required placeholder={placeholder}
        value={form[field]} onChange={e=>setForm(f=>({...f,[field]:e.target.value}))}
        style={{ width:'100%', padding:'8px', border:'1px solid #a6a6a6', borderRadius:'4px', fontSize:'13px', outline:'none' }} />
    </div>
  )

  return (
    <div style={{ minHeight:'80vh', display:'flex', alignItems:'center', justifyContent:'center', padding:'24px', background:'#f3f3f3' }}>
      <div style={{ width:'100%', maxWidth:'400px' }}>
        <div style={{ textAlign:'center', marginBottom:'20px' }}>
          <Link to="/" style={{ fontSize:'2rem', fontWeight:900, letterSpacing:'-1px' }}>
            amazon<span style={{ color:'#f08804' }}>.in</span>
          </Link>
        </div>
        <div style={{ background:'#fff', border:'1px solid #d5d9d9', borderRadius:'8px', padding:'28px 24px' }}>
          <h1 style={{ fontSize:'22px', fontWeight:400, marginBottom:'20px' }}>Create account</h1>
          <form onSubmit={handle}>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'12px' }}>
              <F label="First name" field="firstName" placeholder="John" />
              <F label="Last name"  field="lastName"  placeholder="Doe" />
            </div>
            <F label="Email"    field="email"    type="email"    placeholder="you@email.com" />
            <F label="Phone"    field="phoneNo"  placeholder="+91..." />
            <F label="Password" field="password" type="password" placeholder="Min 8 characters" />
            <button type="submit" disabled={loading}
              style={{ width:'100%', padding:'9px', background:'#ffd814', border:'1px solid #fcd200', borderRadius:'8px', fontSize:'13px', cursor:'pointer', opacity:loading?0.7:1 }}>
              {loading ? 'Creating...' : 'Create your Amazon account'}
            </button>
          </form>
        </div>
        <div style={{ border:'1px solid #d5d9d9', borderRadius:'8px', padding:'16px', marginTop:'16px', textAlign:'center', background:'#fff' }}>
          <span style={{ fontSize:'13px', color:'#555' }}>Already have an account? </span>
          <Link to="/login" style={{ color:'#007185', fontSize:'13px' }}>Sign in</Link>
        </div>
      </div>
    </div>
  )
}