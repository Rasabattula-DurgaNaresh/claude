import React, { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Trash2, Plus, Minus, ShoppingBag } from 'lucide-react'
import { cartApi } from '../../utils/api'
import { useCartStore } from '../../store/cartStore'
import { useAuthStore } from '../../store/authStore'
import toast from 'react-hot-toast'

export default function CartPage() {
  const nav = useNavigate()
  const isAuth  = useAuthStore(s => s.isAuthenticated)
  const { cart, setCart, setCount } = useCartStore()
  const [loading, setLoading] = useState(true)

  const loadCart = async () => {
    if (!isAuth) { setLoading(false); return }
    try {
      const r = await cartApi.get()
      setCart(r.data)
    } catch {} finally { setLoading(false) }
  }

  useEffect(() => { loadCart() }, [isAuth])

  const update = async (productId, qty) => {
    try {
      if (qty === 0) {
        const r = await cartApi.remove(productId)
        setCart(r.data)
        setCount(r.data.itemCount)
        toast.success('Item removed')
      } else {
        const r = await cartApi.update(productId, qty)
        setCart(r.data)
        setCount(r.data.itemCount)
      }
    } catch { toast.error('Failed to update cart') }
  }

  if (!isAuth) return (
    <div style={{ maxWidth:'800px', margin:'0 auto', padding:'48px 24px', textAlign:'center' }}>
      <ShoppingBag size={64} color="#ccc" style={{ marginBottom:'16px' }} />
      <h2 style={{ marginBottom:'8px' }}>Your Amazon Cart is empty</h2>
      <p style={{ color:'#555', marginBottom:'24px' }}>Sign in to see items added to your cart</p>
      <Link to="/login" style={{ background:'#ffd814', padding:'10px 24px', borderRadius:'20px', color:'#111', fontWeight:600 }}>Sign in to your account</Link>
    </div>
  )

  if (loading) return <div style={{ padding:'48px', textAlign:'center', color:'#555' }}>Loading cart...</div>

  const items = cart?.items || []

  return (
    <div style={{ maxWidth:'1100px', margin:'0 auto', padding:'16px', display:'grid', gridTemplateColumns:'1fr 300px', gap:'16px', alignItems:'start' }}>
      {/* Cart items */}
      <div style={{ background:'#fff', border:'1px solid #ddd', borderRadius:'8px', padding:'24px' }}>
        <h1 style={{ fontSize:'24px', fontWeight:400, marginBottom:'16px' }}>Shopping Cart</h1>
        {items.length === 0 ? (
          <div style={{ textAlign:'center', padding:'48px' }}>
            <ShoppingBag size={64} color="#ccc" style={{ marginBottom:'16px' }} />
            <h3>Your cart is empty</h3>
            <Link to="/" style={{ display:'inline-block', marginTop:'16px', color:'#007185' }}>Continue Shopping</Link>
          </div>
        ) : (
          <>
            {items.map(item => (
              <div key={item.productId} style={{ display:'grid', gridTemplateColumns:'100px 1fr auto', gap:'16px', alignItems:'center', paddingBottom:'20px', marginBottom:'20px', borderBottom:'1px solid #eee' }}>
                <Link to={`/product/${item.productId}`}>
                  <img src={item.thumbnailUrl || `https://picsum.photos/seed/${item.productId}/100/100`}
                    alt={item.name} style={{ width:'100px', height:'100px', objectFit:'contain' }} />
                </Link>
                <div>
                  <Link to={`/product/${item.productId}`} style={{ fontSize:'14px', color:'#007185', marginBottom:'4px', display:'block' }}>{item.name}</Link>
                  {item.brand && <p style={{ fontSize:'12px', color:'#555', marginBottom:'4px' }}>{item.brand}</p>}
                  <p style={{ color: item.inStock ? '#007600' : '#c0392b', fontSize:'12px', marginBottom:'8px' }}>
                    {item.inStock ? 'In Stock' : 'Out of Stock'}
                  </p>
                  <div style={{ display:'flex', alignItems:'center', gap:'8px' }}>
                    <div style={{ display:'flex', alignItems:'center', border:'1px solid #ccc', borderRadius:'4px' }}>
                      <button onClick={() => update(item.productId, item.quantity - 1)}
                        style={{ padding:'4px 10px', background:'#f3f3f3', border:'none', cursor:'pointer', borderRadius:'4px 0 0 4px' }}>
                        {item.quantity === 1 ? <Trash2 size={14} color="#c0392b" /> : <Minus size={14} />}
                      </button>
                      <span style={{ padding:'4px 12px', fontSize:'14px', fontWeight:600 }}>{item.quantity}</span>
                      <button onClick={() => update(item.productId, item.quantity + 1)} disabled={item.quantity >= item.maxQty}
                        style={{ padding:'4px 10px', background:'#f3f3f3', border:'none', cursor:'pointer', borderRadius:'0 4px 4px 0', opacity: item.quantity >= item.maxQty ? 0.4 : 1 }}>
                        <Plus size={14} />
                      </button>
                    </div>
                    <button onClick={() => update(item.productId, 0)} style={{ background:'none', border:'none', color:'#c0392b', cursor:'pointer', fontSize:'12px' }}>
                      Delete
                    </button>
                  </div>
                </div>
                <div style={{ textAlign:'right' }}>
                  <p style={{ fontSize:'18px', fontWeight:700, color:'#B12704' }}>₹{Number(item.sellingPrice * item.quantity).toLocaleString('en-IN')}</p>
                  {item.discountPct > 0 && (
                    <p style={{ fontSize:'12px', color:'#007600' }}>Save {Math.round(item.discountPct)}%</p>
                  )}
                </div>
              </div>
            ))}
            <div style={{ textAlign:'right', fontSize:'16px' }}>
              Subtotal ({cart?.itemCount || 0} items): <strong style={{ fontSize:'18px' }}>₹{Number(cart?.subtotal || 0).toLocaleString('en-IN')}</strong>
            </div>
          </>
        )}
      </div>

      {/* Order summary */}
      {items.length > 0 && (
        <div style={{ background:'#fff', border:'1px solid #ddd', borderRadius:'8px', padding:'20px', position:'sticky', top:'80px' }}>
          <h2 style={{ fontSize:'18px', marginBottom:'16px' }}>Order Summary</h2>
          {[
            ['Subtotal', cart?.subtotal],
            ['Discount', cart?.discount, true],
            ['Shipping', cart?.shipping],
            ['Tax (18% GST)', cart?.tax],
          ].map(([label, val, isDiscount]) => (
            <div key={label} style={{ display:'flex', justifyContent:'space-between', fontSize:'14px', marginBottom:'8px' }}>
              <span style={{ color:'#555' }}>{label}</span>
              <span style={{ color: isDiscount && val > 0 ? '#007600' : '#0f1111' }}>
                {isDiscount && val > 0 && '-'}₹{Number(val || 0).toLocaleString('en-IN')}
              </span>
            </div>
          ))}
          {cart?.freeShipping && <div style={{ color:'#007600', fontSize:'12px', marginBottom:'8px' }}>✓ Your order qualifies for FREE delivery</div>}
          <hr style={{ margin:'12px 0' }} />
          <div style={{ display:'flex', justifyContent:'space-between', fontWeight:700, fontSize:'18px', marginBottom:'20px' }}>
            <span>Order Total</span>
            <span style={{ color:'#B12704' }}>₹{Number(cart?.total || 0).toLocaleString('en-IN')}</span>
          </div>
          <button onClick={() => nav('/checkout')}
            style={{ width:'100%', padding:'12px', background:'#ffd814', border:'1px solid #fcd200', borderRadius:'20px', cursor:'pointer', fontSize:'16px', fontWeight:500 }}>
            Proceed to Checkout
          </button>
        </div>
      )}
    </div>
  )
}