import React, { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { Star, ShoppingCart, Zap, Shield, Truck, ChevronLeft, ChevronRight, ThumbsUp } from 'lucide-react'
import { productApi, cartApi, reviewApi } from '../../utils/api'
import { useAuthStore }  from '../../store/authStore'
import { useCartStore }  from '../../store/cartStore'
import toast from 'react-hot-toast'

const Stars = ({ rating, size=16 }) => (
  <span style={{ display:'inline-flex', color:'#f0a500' }}>
    {[1,2,3,4,5].map(i => <Star key={i} size={size} fill={i<=Math.round(rating)?'#f0a500':'none'} strokeWidth={1} />)}
  </span>
)

export default function ProductPage() {
  const { id } = useParams()
  const nav = useNavigate()
  const isAuth   = useAuthStore(s => s.isAuthenticated)
  const setCount = useCartStore(s => s.setCount)
  const count    = useCartStore(s => s.count)

  const [product, setProduct]   = useState(null)
  const [reviews, setReviews]   = useState([])
  const [stats,   setStats]     = useState(null)
  const [qty,     setQty]       = useState(1)
  const [imgIdx,  setImgIdx]    = useState(0)
  const [loading, setLoading]   = useState(true)
  const [adding,  setAdding]    = useState(false)
  const [tab,     setTab]       = useState('desc')

  useEffect(() => {
    setLoading(true)
    Promise.all([
      productApi.getById(id),
      reviewApi.getByProduct(id),
      reviewApi.getStats(id)
    ]).then(([pr, rr, sr]) => {
      setProduct(pr.data)
      setReviews(rr.data?.content || [])
      setStats(sr.data)
    }).catch(() => toast.error('Product not found'))
    .finally(() => setLoading(false))
  }, [id])

  const addToCart = async () => {
    if (!isAuth) { nav('/login'); return }
    setAdding(true)
    try {
      await cartApi.add(product.productId, qty)
      setCount(count + qty)
      toast.success(`${qty} item${qty>1?'s':''} added to cart`)
    } catch { toast.error('Failed to add to cart') }
    finally { setAdding(false) }
  }

  const buyNow = async () => {
    await addToCart()
    nav('/cart')
  }

  if (loading) return (
    <div style={{ maxWidth:'1200px', margin:'0 auto', padding:'24px', display:'flex', justifyContent:'center', alignItems:'center', minHeight:'60vh' }}>
      <div style={{ fontSize:'16px', color:'#555' }}>Loading product...</div>
    </div>
  )

  if (!product) return (
    <div style={{ maxWidth:'1200px', margin:'0 auto', padding:'24px', textAlign:'center', minHeight:'60vh' }}>
      <h2 style={{ color:'#555' }}>Product not found</h2>
    </div>
  )

  const images = [product.thumbnailUrl, ...(product.imageUrls||[])].filter(Boolean)
  if (!images.length) images.push(`https://picsum.photos/seed/${id}/400/400`)
  const discount = product.discountPct ? Math.round(product.discountPct) : 0

  return (
    <div style={{ background:'#f3f3f3', minHeight:'100vh' }}>
      <div style={{ maxWidth:'1200px', margin:'0 auto', padding:'16px' }}>
        <div style={{ background:'#fff', border:'1px solid #ddd', borderRadius:'8px', padding:'24px', marginBottom:'16px' }}>
          <div style={{ display:'grid', gridTemplateColumns:'400px 1fr 260px', gap:'24px' }}>

            {/* Images */}
            <div>
              <div style={{ border:'1px solid #ddd', borderRadius:'4px', padding:'16px', background:'#f7f7f7', height:'380px', display:'flex', alignItems:'center', justifyContent:'center', position:'relative', marginBottom:'12px' }}>
                <img src={images[imgIdx]} alt={product.name}
                  style={{ maxWidth:'100%', maxHeight:'350px', objectFit:'contain' }} />
                {images.length > 1 && (<>
                  <button onClick={()=>setImgIdx(i=>(i-1+images.length)%images.length)}
                    style={{ position:'absolute', left:'8px', background:'rgba(0,0,0,0.4)', border:'none', borderRadius:'50%', width:'32px', height:'32px', display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer', color:'#fff' }}>
                    <ChevronLeft size={16} />
                  </button>
                  <button onClick={()=>setImgIdx(i=>(i+1)%images.length)}
                    style={{ position:'absolute', right:'8px', background:'rgba(0,0,0,0.4)', border:'none', borderRadius:'50%', width:'32px', height:'32px', display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer', color:'#fff' }}>
                    <ChevronRight size={16} />
                  </button>
                </>)}
              </div>
              <div style={{ display:'flex', gap:'8px', flexWrap:'wrap' }}>
                {images.map((img,i) => (
                  <img key={i} src={img} alt="" onClick={()=>setImgIdx(i)}
                    style={{ width:'60px', height:'60px', objectFit:'contain', border:`2px solid ${i===imgIdx?'#ff9900':'#ddd'}`, borderRadius:'4px', cursor:'pointer', padding:'4px', background:'#f7f7f7' }} />
                ))}
              </div>
            </div>

            {/* Info */}
            <div>
              {product.brand && <p style={{ color:'#007185', fontSize:'13px', marginBottom:'4px' }}>{product.brand}</p>}
              <h1 style={{ fontSize:'20px', fontWeight:400, lineHeight:1.4, marginBottom:'12px' }}>{product.name}</h1>
              <div style={{ display:'flex', alignItems:'center', gap:'8px', marginBottom:'12px' }}>
                <Stars rating={stats?.averageRating || 0} />
                <span style={{ color:'#007185', fontSize:'13px' }}>{stats?.averageRating?.toFixed(1) || 0}</span>
                <span style={{ color:'#007185', fontSize:'13px' }}>{stats?.totalReviews?.toLocaleString() || 0} ratings</span>
              </div>
              <hr style={{ margin:'12px 0', borderColor:'#eee' }} />

              <div style={{ marginBottom:'16px' }}>
                <span style={{ fontSize:'13px', color:'#555' }}>Price: </span>
                <span style={{ fontSize:'28px', color:'#B12704', fontWeight:400 }}>₹{Number(product.sellingPrice).toLocaleString('en-IN')}</span>
                {discount > 0 && (
                  <span style={{ marginLeft:'8px', fontSize:'13px', color:'#555' }}>
                    M.R.P.: <del>₹{Number(product.mrpPrice).toLocaleString('en-IN')}</del>
                    <span style={{ color:'#B12704', marginLeft:'6px' }}>({discount}% off)</span>
                  </span>
                )}
              </div>

              {product.primeEligible && (
                <div style={{ display:'flex', alignItems:'center', gap:'6px', color:'#00a8cc', fontSize:'13px', marginBottom:'12px', padding:'8px', background:'#f0faff', borderRadius:'4px' }}>
                  <Zap size={14} fill="#00a8cc" />
                  FREE Delivery with Prime | Get it by Tomorrow
                </div>
              )}

              <div style={{ marginBottom:'16px', display:'flex', flexDirection:'column', gap:'6px' }}>
                {[<><Shield size={14} color="#555" style={{marginRight:'6px'}}/>Secure transaction</>,
                  <><Truck size={14} color="#555" style={{marginRight:'6px'}}/>Sold by Amazon.in</>,
                ].map((item,i)=>(
                  <div key={i} style={{ display:'flex', alignItems:'center', fontSize:'13px', color:'#555' }}>{item}</div>
                ))}
              </div>

              <div style={{ marginBottom:'16px' }}>
                <p style={{ fontSize:'13px', fontWeight:700, marginBottom:'8px' }}>About this item</p>
                <p style={{ fontSize:'13px', color:'#333', lineHeight:1.6 }}>
                  {product.description?.substring(0,400) || 'Quality product with excellent features.'}
                </p>
              </div>

              {product.tags && (
                <div style={{ display:'flex', flexWrap:'wrap', gap:'6px' }}>
                  {product.tags.split(',').map((tag,i)=>(
                    <span key={i} style={{ background:'#f3f3f3', border:'1px solid #ddd', borderRadius:'12px', padding:'3px 10px', fontSize:'11px', color:'#555' }}>
                      {tag.trim()}
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* Buy box */}
            <div style={{ border:'1px solid #ddd', borderRadius:'8px', padding:'16px', height:'fit-content' }}>
              <div style={{ fontSize:'22px', color:'#B12704', marginBottom:'8px' }}>
                ₹{Number(product.sellingPrice).toLocaleString('en-IN')}
              </div>
              {product.primeEligible && (
                <div style={{ color:'#00a8cc', fontSize:'12px', fontWeight:700, marginBottom:'8px' }}>
                  FREE Delivery Tomorrow if ordered now
                </div>
              )}
              <div style={{ color: product.stockQuantity > 0 ? '#007600' : '#c0392b', fontSize:'16px', fontWeight:700, marginBottom:'12px' }}>
                {product.stockQuantity > 0 ? (product.stockQuantity < 10 ? `Only ${product.stockQuantity} left in stock` : 'In Stock') : 'Currently unavailable'}
              </div>

              {product.stockQuantity > 0 && (
                <>
                  <div style={{ marginBottom:'12px' }}>
                    <label style={{ fontSize:'13px', color:'#555', display:'block', marginBottom:'4px' }}>Qty:</label>
                    <select value={qty} onChange={e=>setQty(Number(e.target.value))}
                      style={{ padding:'6px 10px', border:'1px solid #ccc', borderRadius:'4px', fontSize:'13px' }}>
                      {[...Array(Math.min(product.stockQuantity, 10))].map((_,i)=>(
                        <option key={i} value={i+1}>{i+1}</option>
                      ))}
                    </select>
                  </div>
                  <button onClick={addToCart} disabled={adding}
                    style={{ width:'100%', padding:'10px', background:'#ffd814', border:'1px solid #fcd200', borderRadius:'20px', cursor:'pointer', fontSize:'14px', marginBottom:'8px', opacity:adding?0.7:1 }}>
                    {adding ? 'Adding...' : 'Add to Cart'}
                  </button>
                  <button onClick={buyNow} disabled={adding}
                    style={{ width:'100%', padding:'10px', background:'#ffa41c', border:'1px solid #e59400', borderRadius:'20px', cursor:'pointer', fontSize:'14px', opacity:adding?0.7:1 }}>
                    Buy Now
                  </button>
                </>
              )}

              <div style={{ marginTop:'12px', fontSize:'12px', color:'#555' }}>
                <div style={{ display:'flex', alignItems:'center', gap:'4px' }}>
                  <Shield size={12} /> Secure transaction
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Reviews */}
        <div style={{ background:'#fff', border:'1px solid #ddd', borderRadius:'8px', padding:'24px' }}>
          <h2 style={{ fontSize:'20px', marginBottom:'20px' }}>Customer Reviews</h2>
          {reviews.length === 0 ? (
            <p style={{ color:'#888' }}>No reviews yet. Be the first to review this product!</p>
          ) : (
            <div style={{ display:'flex', flexDirection:'column', gap:'20px' }}>
              {reviews.map(r => (
                <div key={r.reviewId} style={{ borderBottom:'1px solid #eee', paddingBottom:'20px' }}>
                  <div style={{ display:'flex', alignItems:'center', gap:'8px', marginBottom:'4px' }}>
                    <div style={{ width:'32px', height:'32px', borderRadius:'50%', background:'#ff9900', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontWeight:700 }}>
                      {r.userName?.[0] || 'A'}
                    </div>
                    <span style={{ fontWeight:600, fontSize:'14px' }}>{r.userName || 'Anonymous'}</span>
                    {r.verifiedPurchase && <span style={{ color:'#c45500', fontSize:'11px' }}>✓ Verified Purchase</span>}
                  </div>
                  <div style={{ display:'flex', alignItems:'center', gap:'8px', marginBottom:'6px' }}>
                    <Stars rating={r.rating} size={14} />
                    <span style={{ fontWeight:700, fontSize:'14px' }}>{r.title}</span>
                  </div>
                  <p style={{ fontSize:'13px', color:'#333', lineHeight:1.6, marginBottom:'8px' }}>{r.body}</p>
                  <div style={{ display:'flex', alignItems:'center', gap:'8px', fontSize:'12px', color:'#888' }}>
                    <span>{new Date(r.createdAt).toLocaleDateString('en-IN')}</span>
                    {r.helpfulCount > 0 && <span>{r.helpfulCount} people found this helpful</span>}
                    <button onClick={() => reviewApi.markHelpful(r.reviewId).catch(()=>{})}
                      style={{ background:'none', border:'1px solid #ccc', borderRadius:'4px', padding:'2px 8px', cursor:'pointer', fontSize:'12px', display:'flex', alignItems:'center', gap:'3px' }}>
                      <ThumbsUp size={11} /> Helpful
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}