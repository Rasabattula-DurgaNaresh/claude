import React, { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { SlidersHorizontal, ChevronDown, X } from 'lucide-react'
import ProductCard   from '../shared/ProductCard'
import { productApi } from '../../utils/api'

const SORT_OPTIONS = [
  { value:'relevance', label:'Most Relevant' },
  { value:'price',     label:'Price: Low to High' },
  { value:'price-desc',label:'Price: High to Low' },
  { value:'rating',    label:'Avg. Customer Review' },
  { value:'newest',    label:'Newest Arrivals' },
]

export default function SearchPage() {
  const [sp] = useSearchParams()
  const keyword    = sp.get('keyword')    || ''
  const categoryId = sp.get('categoryId') || null

  const [products, setProducts]   = useState([])
  const [totalPages, setTotalPages] = useState(0)
  const [totalElements, setTotalElements] = useState(0)
  const [page, setPage]           = useState(0)
  const [sortBy, setSortBy]       = useState('relevance')
  const [minPrice, setMinPrice]   = useState('')
  const [maxPrice, setMaxPrice]   = useState('')
  const [loading, setLoading]     = useState(true)
  const [showFilters, setShowFilters] = useState(false)

  useEffect(() => { setPage(0) }, [keyword, categoryId, sortBy, minPrice, maxPrice])

  useEffect(() => {
    setLoading(true)
    const params = { keyword, categoryId, page, size: 20,
      sortBy: sortBy === 'price-desc' ? 'price' : sortBy,
      sortDir: sortBy === 'price-desc' ? 'asc' : 'desc',
      minPrice: minPrice || undefined, maxPrice: maxPrice || undefined }
    productApi.search(params)
      .then(r => {
        const d = r.data
        setProducts(d?.content || d || [])
        setTotalPages(d?.totalPages || 0)
        setTotalElements(d?.totalElements || (Array.isArray(d) ? d.length : 0))
      }).catch(()=>setProducts([]))
      .finally(() => setLoading(false))
  }, [keyword, categoryId, page, sortBy, minPrice, maxPrice])

  return (
    <div style={{ maxWidth:'1400px', margin:'0 auto', padding:'16px' }}>
      {/* Results header */}
      <div style={{ background:'#fff', border:'1px solid #ddd', borderRadius:'4px', padding:'12px 16px', marginBottom:'16px', display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:'8px' }}>
        <div style={{ fontSize:'14px' }}>
          {keyword && <><span style={{ fontWeight:600 }}>"{keyword}"</span>  — </>}
          <span style={{ color:'#555' }}>{totalElements.toLocaleString()} results</span>
        </div>
        <div style={{ display:'flex', gap:'12px', alignItems:'center' }}>
          <button onClick={()=>setShowFilters(s=>!s)} style={{ display:'flex', alignItems:'center', gap:'6px', padding:'6px 12px', background:'#f3f3f3', border:'1px solid #ccc', borderRadius:'4px', cursor:'pointer', fontSize:'13px' }}>
            <SlidersHorizontal size={14} /> Filters
          </button>
          <select value={sortBy} onChange={e=>setSortBy(e.target.value)}
            style={{ padding:'6px 8px', border:'1px solid #ccc', borderRadius:'4px', fontSize:'13px', cursor:'pointer' }}>
            {SORT_OPTIONS.map(o=><option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        </div>
      </div>

      <div style={{ display:'flex', gap:'16px' }}>
        {/* Filters panel */}
        {showFilters && (
          <div style={{ width:'220px', flexShrink:0, background:'#fff', border:'1px solid #ddd', borderRadius:'4px', padding:'16px', height:'fit-content' }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'12px' }}>
              <strong>Filters</strong>
              <X size={16} style={{ cursor:'pointer' }} onClick={()=>setShowFilters(false)} />
            </div>
            <div style={{ marginBottom:'16px' }}>
              <p style={{ fontSize:'13px', fontWeight:700, marginBottom:'8px', color:'#555' }}>PRICE RANGE</p>
              <div style={{ display:'flex', gap:'8px', alignItems:'center' }}>
                <input type="number" placeholder="Min" value={minPrice} onChange={e=>setMinPrice(e.target.value)}
                  style={{ width:'80px', padding:'6px', border:'1px solid #ccc', borderRadius:'4px', fontSize:'12px' }} />
                <span style={{ fontSize:'12px' }}>to</span>
                <input type="number" placeholder="Max" value={maxPrice} onChange={e=>setMaxPrice(e.target.value)}
                  style={{ width:'80px', padding:'6px', border:'1px solid #ccc', borderRadius:'4px', fontSize:'12px' }} />
              </div>
              {(minPrice||maxPrice) && (
                <button onClick={()=>{setMinPrice('');setMaxPrice('')}}
                  style={{ marginTop:'6px', fontSize:'12px', color:'#007185', background:'none', border:'none', cursor:'pointer' }}>
                  Clear
                </button>
              )}
            </div>
            <div>
              <p style={{ fontSize:'13px', fontWeight:700, marginBottom:'8px', color:'#555' }}>AVAILABILITY</p>
              <label style={{ display:'flex', alignItems:'center', gap:'6px', fontSize:'13px', cursor:'pointer' }}>
                <input type="checkbox" /> In Stock Only
              </label>
            </div>
          </div>
        )}

        {/* Product grid */}
        <div style={{ flex:1 }}>
          {loading ? (
            <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(200px,1fr))', gap:'12px' }}>
              {[...Array(12)].map((_,i)=><div key={i} style={{ background:'#fff', height:'380px', borderRadius:'4px', animation:'pulse 1.5s ease infinite' }}><style>{`@keyframes pulse{0%,100%{opacity:1}50%{opacity:0.5}}`}</style></div>)}
            </div>
          ) : products.length === 0 ? (
            <div style={{ background:'#fff', border:'1px solid #ddd', borderRadius:'4px', padding:'48px', textAlign:'center' }}>
              <p style={{ fontSize:'24px', marginBottom:'8px' }}>🔍</p>
              <p style={{ fontSize:'18px', fontWeight:600, marginBottom:'8px' }}>No results found</p>
              <p style={{ color:'#555', fontSize:'14px' }}>Try different keywords or remove filters</p>
            </div>
          ) : (
            <>
              <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(200px,1fr))', gap:'12px' }}>
                {products.map(p => <ProductCard key={p.productId} product={p} />)}
              </div>
              {totalPages > 1 && (
                <div style={{ display:'flex', justifyContent:'center', gap:'8px', marginTop:'24px', flexWrap:'wrap' }}>
                  {[...Array(Math.min(totalPages, 10))].map((_,i) => (
                    <button key={i} onClick={()=>setPage(i)}
                      style={{ width:'36px', height:'36px', border: i===page?'1px solid #f08804':'1px solid #ddd', background: i===page?'#fff8e7':'#fff', borderRadius:'4px', cursor:'pointer', fontWeight: i===page?700:400 }}>
                      {i+1}
                    </button>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}