import React, { useState, useEffect } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { ShoppingCart, Search, User, MapPin, ChevronDown, Menu } from 'lucide-react'
import { useAuthStore }  from '../../store/authStore'
import { useCartStore }  from '../../store/cartStore'
import { categoryApi }   from '../../utils/api'

export default function Navbar() {
  const nav = useNavigate()
  const [sp, setSp] = useSearchParams()
  const { user, isAuthenticated, logout } = useAuthStore()
  const cartCount = useCartStore(s => s.count)
  const [query, setQuery] = useState(sp.get('keyword') || '')
  const [categories, setCategories] = useState([])
  const [showUser, setShowUser] = useState(false)

  useEffect(() => {
    categoryApi.getAll().then(r => setCategories(r.data || [])).catch(() => {})
  }, [])

  const search = e => {
    e.preventDefault()
    if (query.trim()) nav(`/search?keyword=${encodeURIComponent(query.trim())}`)
  }

  const handleLogout = () => { logout(); nav('/'); setShowUser(false) }

  return (
    <header style={{ position:'sticky', top:0, zIndex:1000 }}>
      {/* Top bar */}
      <div style={{ background:'#131921', padding:'0.55rem 1rem', display:'flex', alignItems:'center', gap:'0.75rem' }}>
        {/* Logo */}
        <Link to="/" style={{ color:'white', fontWeight:900, fontSize:'1.55rem', letterSpacing:'-1px', flexShrink:0, border:'1px solid transparent', padding:'2px 4px', borderRadius:'2px' }}
          onMouseEnter={e=>e.currentTarget.style.borderColor='#fff'}
          onMouseLeave={e=>e.currentTarget.style.borderColor='transparent'}>
          amazon<span style={{ color:'#ff9900' }}>.in</span>
        </Link>

        {/* Deliver to */}
        <div style={{ color:'#ccc', fontSize:'12px', flexShrink:0, cursor:'pointer' }}>
          <div style={{ fontSize:'10px' }}>Deliver to</div>
          <div style={{ color:'#fff', fontWeight:700, display:'flex', alignItems:'center', gap:'2px' }}>
            <MapPin size={14} /> India
          </div>
        </div>

        {/* Search bar */}
        <form onSubmit={search} style={{ flex:1, display:'flex', maxWidth:'900px' }}>
          <select style={{ background:'#f3f3f3', border:'none', padding:'0 8px', borderRadius:'4px 0 0 4px', fontSize:'12px', color:'#555', height:'40px', cursor:'pointer' }}>
            <option>All</option>
            {categories.map(c => <option key={c.categoryId}>{c.name}</option>)}
          </select>
          <input
            value={query} onChange={e => setQuery(e.target.value)}
            placeholder="Search Amazon.in"
            style={{ flex:1, height:'40px', padding:'0 12px', border:'none', outline:'none', fontSize:'15px' }}
          />
          <button type="submit" style={{ width:'46px', height:'40px', background:'#febd69', border:'none', borderRadius:'0 4px 4px 0', display:'flex', alignItems:'center', justifyContent:'center' }}>
            <Search size={20} color="#131921" />
          </button>
        </form>

        {/* Account */}
        <div style={{ position:'relative' }}>
          <div onClick={() => setShowUser(s => !s)}
            style={{ color:'#fff', cursor:'pointer', padding:'4px', borderRadius:'2px', border:'1px solid transparent', userSelect:'none' }}
            onMouseEnter={e=>e.currentTarget.style.borderColor='#fff'}
            onMouseLeave={e=>e.currentTarget.style.borderColor='transparent'}>
            <div style={{ fontSize:'11px', color:'#ccc' }}>{isAuthenticated ? `Hello, ${user?.fullName?.split(' ')[0]}` : 'Hello, sign in'}</div>
            <div style={{ fontWeight:700, fontSize:'13px', display:'flex', alignItems:'center', gap:'2px' }}>
              Account <ChevronDown size={12} />
            </div>
          </div>
          {showUser && (
            <div style={{ position:'absolute', right:0, top:'100%', background:'#fff', border:'1px solid #ddd', borderRadius:'4px', padding:'8px 0', minWidth:'180px', boxShadow:'0 4px 12px rgba(0,0,0,0.15)', zIndex:100 }}>
              {isAuthenticated ? (<>
                <Link to="/profile" onClick={()=>setShowUser(false)} style={{ display:'block', padding:'8px 16px', fontSize:'13px', color:'#111' }} className="dd-item">My Profile</Link>
                <Link to="/orders"  onClick={()=>setShowUser(false)} style={{ display:'block', padding:'8px 16px', fontSize:'13px', color:'#111' }}>My Orders</Link>
                {user?.role === 'SELLER' && <Link to="/seller" onClick={()=>setShowUser(false)} style={{ display:'block', padding:'8px 16px', fontSize:'13px', color:'#111' }}>Seller Hub</Link>}
                <hr style={{ margin:'4px 0' }} />
                <button onClick={handleLogout} style={{ width:'100%', padding:'8px 16px', textAlign:'left', background:'none', border:'none', fontSize:'13px', color:'#c0392b' }}>Sign Out</button>
              </>) : (<>
                <Link to="/login"    onClick={()=>setShowUser(false)} style={{ display:'block', padding:'8px 16px', fontSize:'13px' }}>Sign In</Link>
                <Link to="/register" onClick={()=>setShowUser(false)} style={{ display:'block', padding:'8px 16px', fontSize:'13px' }}>Create Account</Link>
              </>)}
            </div>
          )}
        </div>

        {/* Orders */}
        <Link to="/orders" style={{ color:'#fff', flexShrink:0, border:'1px solid transparent', padding:'4px', borderRadius:'2px' }}
          onMouseEnter={e=>e.currentTarget.style.borderColor='#fff'}
          onMouseLeave={e=>e.currentTarget.style.borderColor='transparent'}>
          <div style={{ fontSize:'11px', color:'#ccc' }}>Returns</div>
          <div style={{ fontWeight:700, fontSize:'13px' }}>& Orders</div>
        </Link>

        {/* Cart */}
        <Link to="/cart" style={{ color:'#fff', display:'flex', alignItems:'center', gap:'4px', flexShrink:0, border:'1px solid transparent', padding:'4px', borderRadius:'2px' }}
          onMouseEnter={e=>e.currentTarget.style.borderColor='#fff'}
          onMouseLeave={e=>e.currentTarget.style.borderColor='transparent'}>
          <div style={{ position:'relative' }}>
            <ShoppingCart size={32} strokeWidth={1.5} />
            <span style={{ position:'absolute', top:'-4px', right:'-4px', background:'#f08804', color:'#111', borderRadius:'50%', width:'20px', height:'20px', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'12px', fontWeight:700 }}>
              {cartCount || 0}
            </span>
          </div>
          <span style={{ fontWeight:700, fontSize:'13px' }}>Cart</span>
        </Link>
      </div>

      {/* Category nav */}
      <div style={{ background:'#232f3e', padding:'6px 12px', display:'flex', gap:'0', overflowX:'auto' }}>
        {[{name:'All', path:'/search'}, ...categories.slice(0,8).map(c=>({name:c.name, path:`/search?categoryId=${c.categoryId}`}))].map((item, i) => (
          <Link key={i} to={item.path}
            style={{ color:'#fff', fontSize:'13px', padding:'4px 10px', borderRadius:'2px', whiteSpace:'nowrap', border:'1px solid transparent', flexShrink:0 }}
            onMouseEnter={e=>e.currentTarget.style.borderColor='#fff'}
            onMouseLeave={e=>e.currentTarget.style.borderColor='transparent'}>
            {item.name}
          </Link>
        ))}
      </div>
    </header>
  )
}