import React from 'react'
import { Link } from 'react-router-dom'
import { Star, ShoppingCart, Zap } from 'lucide-react'
import { cartApi } from '../../utils/api'
import { useCartStore } from '../../store/cartStore'
import { useAuthStore } from '../../store/authStore'
import toast from 'react-hot-toast'

const Stars = ({ rating = 0, count = 0 }) => (
  <div style={{ display:'flex', alignItems:'center', gap:'4px', marginBottom:'4px' }}>
    <div style={{ display:'flex', color:'#f0a500' }}>
      {[1,2,3,4,5].map(i => <Star key={i} size={13} fill={i <= Math.round(rating) ? '#f0a500' : 'none'} strokeWidth={1} />)}
    </div>
    <span style={{ color:'#007185', fontSize:'12px' }}>{count > 0 ? count.toLocaleString() : ''}</span>
  </div>
)

export default function ProductCard({ product }) {
  const isAuth   = useAuthStore(s => s.isAuthenticated)
  const setCount = useCartStore(s => s.setCount)
  const count    = useCartStore(s => s.count)

  const addToCart = async e => {
    e.preventDefault()
    if (!isAuth) { toast.error('Please sign in'); return }
    try {
      await cartApi.add(product.productId)
      setCount(count + 1)
      toast.success('Added to cart')
    } catch { toast.error('Failed to add to cart') }
  }

  const discount = product.discountPct ? Math.round(product.discountPct) : 0

  return (
    <Link to={`/product/${product.productId}`}
      style={{ background:'#fff', border:'1px solid #ddd', borderRadius:'4px', overflow:'hidden', display:'flex', flexDirection:'column', transition:'box-shadow 0.2s' }}
      onMouseEnter={e=>e.currentTarget.style.boxShadow='0 2px 12px rgba(0,0,0,0.15)'}
      onMouseLeave={e=>e.currentTarget.style.boxShadow='none'}>

      <div style={{ position:'relative', background:'#f7f7f7', padding:'12px', height:'200px', display:'flex', alignItems:'center', justifyContent:'center' }}>
        <img src={product.thumbnailUrl || `https://picsum.photos/seed/${product.productId}/200/200`}
          alt={product.name} style={{ maxWidth:'100%', maxHeight:'176px', objectFit:'contain' }} />
        {discount > 0 && (
          <span style={{ position:'absolute', top:'8px', left:'8px', background:'#cc0c39', color:'#fff', padding:'2px 6px', borderRadius:'2px', fontSize:'11px', fontWeight:700 }}>
            -{discount}%
          </span>
        )}
        {product.primeEligible && (
          <span style={{ position:'absolute', top:'8px', right:'8px', background:'#00a8cc', color:'#fff', padding:'2px 6px', borderRadius:'2px', fontSize:'10px', fontWeight:700 }}>
            prime
          </span>
        )}
      </div>

      <div style={{ padding:'12px', flex:1, display:'flex', flexDirection:'column' }}>
        <p style={{ fontSize:'13px', color:'#0f1111', lineHeight:'1.4', marginBottom:'6px', WebkitLineClamp:2, display:'-webkit-box', WebkitBoxOrient:'vertical', overflow:'hidden' }}>
          {product.name}
        </p>
        {product.brand && <p style={{ fontSize:'12px', color:'#555', marginBottom:'4px' }}>{product.brand}</p>}

        <Stars rating={product.ratingAvg} count={product.ratingCount} />

        <div style={{ marginTop:'auto' }}>
          <div style={{ display:'flex', alignItems:'baseline', gap:'6px', flexWrap:'wrap' }}>
            <span style={{ fontSize:'18px', fontWeight:700, color:'#B12704' }}>
              ₹{Number(product.sellingPrice).toLocaleString('en-IN')}
            </span>
            {product.mrpPrice !== product.sellingPrice && (
              <span style={{ fontSize:'12px', color:'#888', textDecoration:'line-through' }}>
                ₹{Number(product.mrpPrice).toLocaleString('en-IN')}
              </span>
            )}
          </div>

          {product.primeEligible && (
            <div style={{ display:'flex', alignItems:'center', gap:'4px', color:'#00a8cc', fontSize:'11px', margin:'4px 0' }}>
              <Zap size={11} fill="#00a8cc" /> FREE Delivery by Prime
            </div>
          )}

          <div style={{ fontSize:'12px', color: product.stockQuantity > 0 ? '#007600' : '#c0392b', marginBottom:'8px' }}>
            {product.stockQuantity > 0 ? (product.stockQuantity < 10 ? `Only ${product.stockQuantity} left` : 'In Stock') : 'Out of Stock'}
          </div>

          <button onClick={addToCart} disabled={!product.stockQuantity}
            style={{ width:'100%', padding:'8px', background: product.stockQuantity ? '#ffd814' : '#ddd', border:'none', borderRadius:'20px', fontSize:'13px', fontWeight:500, cursor: product.stockQuantity ? 'pointer' : 'not-allowed', display:'flex', alignItems:'center', justifyContent:'center', gap:'6px', transition:'background 0.15s' }}
            onMouseEnter={e=>{ if(product.stockQuantity) e.currentTarget.style.background='#f7ca00' }}
            onMouseLeave={e=>{ if(product.stockQuantity) e.currentTarget.style.background='#ffd814' }}>
            <ShoppingCart size={14} /> Add to Cart
          </button>
        </div>
      </div>
    </Link>
  )
}