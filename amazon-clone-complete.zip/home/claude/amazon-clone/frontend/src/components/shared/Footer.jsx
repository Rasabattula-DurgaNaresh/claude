import React from 'react'
import { Link } from 'react-router-dom'

const Col = ({ title, links }) => (
  <div>
    <h4 style={{ color:'#fff', marginBottom:'12px', fontSize:'15px' }}>{title}</h4>
    {links.map(([label, href]) => (
      <Link key={label} to={href} style={{ display:'block', color:'#ddd', fontSize:'13px', marginBottom:'6px', opacity:0.85 }}
        onMouseEnter={e=>e.currentTarget.style.opacity=1}
        onMouseLeave={e=>e.currentTarget.style.opacity=0.85}>
        {label}
      </Link>
    ))}
  </div>
)

export default function Footer() {
  return (
    <footer>
      <div onClick={() => window.scrollTo({top:0,behavior:'smooth'})}
        style={{ background:'#37475a', color:'#fff', textAlign:'center', padding:'14px', cursor:'pointer', fontSize:'13px' }}>
        Back to top
      </div>
      <div style={{ background:'#232f3e', padding:'2.5rem 3rem', display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(160px,1fr))', gap:'2rem' }}>
        <Col title="Get to Know Us" links={[['About Amazon','/'],[`Careers`,'/'],[`Press Releases`,'/'],[`Amazon Science`,'/']]} />
        <Col title="Connect with Us" links={[['Facebook','/'],[`Twitter`,'/'],[`Instagram`,'/'],[`YouTube`,'/']]} />
        <Col title="Make Money with Us" links={[['Sell on Amazon','/'],[`Sell under Amazon Accelerator`,'/'],[`Advertise Your Products`,'/'],[`Amazon Pay`,'/']]} />
        <Col title="Let Us Help You" links={[['COVID-19 and Amazon','/'],[`Your Account`,'/'],[`Returns & Replacements`,'/'],[`Help`,'/']]} />
      </div>
      <div style={{ background:'#131921', padding:'1.5rem', textAlign:'center', color:'#888', fontSize:'12px' }}>
        <div style={{ marginBottom:'8px' }}>
          <a href="#" style={{ color:'#ddd', marginRight:'16px' }}>Conditions of Use & Sale</a>
          <a href="#" style={{ color:'#ddd', marginRight:'16px' }}>Privacy Notice</a>
          <a href="#" style={{ color:'#ddd' }}>Interest-Based Ads</a>
        </div>
        © 2024, Amazon.com, Inc. or its affiliates
      </div>
    </footer>
  )
}