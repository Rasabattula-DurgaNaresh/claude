import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Package, ChevronRight } from 'lucide-react'
import { orderApi } from '../../utils/api'
import { format } from 'date-fns'

const statusColor = s => ({ DELIVERED:'#007600', CANCELLED:'#c0392b', PENDING:'#f08804', SHIPPED:'#007185', PROCESSING:'#555' }[s] || '#555')

export default function OrdersPage() {
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(0)
  const [totalPages, setTotalPages] = useState(0)

  useEffect(() => {
    setLoading(true)
    orderApi.getAll(page).then(r => {
      setOrders(r.data?.content || [])
      setTotalPages(r.data?.totalPages || 0)
    }).catch(()=>{}).finally(()=>setLoading(false))
  }, [page])

  return (
    <div style={{ maxWidth:'1000px', margin:'0 auto', padding:'24px 16px' }}>
      <h1 style={{ fontSize:'24px', fontWeight:400, marginBottom:'20px' }}>Your Orders</h1>
      {loading ? (
        <div style={{ padding:'48px', textAlign:'center', color:'#555' }}>Loading orders...</div>
      ) : orders.length === 0 ? (
        <div style={{ background:'#fff', border:'1px solid #ddd', borderRadius:'8px', padding:'48px', textAlign:'center' }}>
          <Package size={64} color="#ccc" style={{ marginBottom:'16px' }} />
          <h3>No orders yet</h3>
          <Link to="/" style={{ display:'inline-block', marginTop:'16px', color:'#007185' }}>Start shopping</Link>
        </div>
      ) : (
        orders.map(order => (
          <div key={order.orderId} style={{ background:'#fff', border:'1px solid #ddd', borderRadius:'8px', marginBottom:'12px', overflow:'hidden' }}>
            <div style={{ background:'#f7f7f7', padding:'12px 16px', display:'grid', gridTemplateColumns:'auto auto auto 1fr auto', gap:'24px', alignItems:'center', borderBottom:'1px solid #ddd', fontSize:'13px' }}>
              <div><div style={{ color:'#555', fontSize:'11px', textTransform:'uppercase', marginBottom:'2px' }}>Order Placed</div><div>{order.createdAt ? format(new Date(order.createdAt), 'dd MMM yyyy') : '—'}</div></div>
              <div><div style={{ color:'#555', fontSize:'11px', textTransform:'uppercase', marginBottom:'2px' }}>Total</div><div style={{ fontWeight:700 }}>₹{Number(order.totalAmt).toLocaleString('en-IN')}</div></div>
              <div><div style={{ color:'#555', fontSize:'11px', textTransform:'uppercase', marginBottom:'2px' }}>Status</div><div style={{ color: statusColor(order.status), fontWeight:600 }}>{order.status?.replace(/_/g,' ')}</div></div>
              <div><div style={{ color:'#555', fontSize:'11px', textTransform:'uppercase', marginBottom:'2px' }}>Order #</div><div style={{ color:'#007185' }}>{order.orderNumber}</div></div>
              <Link to={`/orders/${order.orderId}`} style={{ display:'flex', alignItems:'center', gap:'4px', color:'#007185', fontSize:'13px' }}>
                Order Details <ChevronRight size={14} />
              </Link>
            </div>
            <div style={{ padding:'16px', display:'flex', gap:'16px', flexWrap:'wrap' }}>
              {(order.items||[]).map(item => (
                <div key={item.itemId} style={{ display:'flex', gap:'12px', alignItems:'center' }}>
                  <img src={item.thumbnailUrl||`https://picsum.photos/seed/${item.productId}/60/60`} style={{ width:'60px', height:'60px', objectFit:'contain' }} />
                  <div style={{ fontSize:'13px' }}>
                    <Link to={`/product/${item.productId}`} style={{ color:'#007185' }}>{item.productName}</Link>
                    <p style={{ color:'#555' }}>Qty: {item.quantity}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))
      )}
      {totalPages > 1 && (
        <div style={{ display:'flex', justifyContent:'center', gap:'8px', marginTop:'16px' }}>
          {[...Array(totalPages)].map((_,i)=>(
            <button key={i} onClick={()=>setPage(i)}
              style={{ width:'36px', height:'36px', border:`1px solid ${i===page?'#f08804':'#ddd'}`, background: i===page?'#fff8e7':'#fff', borderRadius:'4px', cursor:'pointer', fontWeight:i===page?700:400 }}>
              {i+1}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}