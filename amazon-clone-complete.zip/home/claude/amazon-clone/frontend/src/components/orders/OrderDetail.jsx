import React, { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { orderApi } from '../../utils/api'
import toast from 'react-hot-toast'
import { format } from 'date-fns'

const statusColor = s => ({ DELIVERED:'#007600', CANCELLED:'#c0392b', PENDING:'#f08804', SHIPPED:'#007185', PROCESSING:'#555' }[s] || '#555')

const STEPS = ['PENDING','CONFIRMED','PROCESSING','SHIPPED','OUT_FOR_DELIVERY','DELIVERED']

export default function OrderDetail() {
  const { id } = useParams()
  const nav = useNavigate()
  const [order, setOrder] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    orderApi.getById(id).then(r => setOrder(r.data)).catch(()=>{}).finally(()=>setLoading(false))
  }, [id])

  const cancel = async () => {
    if (!window.confirm('Cancel this order?')) return
    try {
      const r = await orderApi.cancel(id, 'Customer request')
      setOrder(r.data)
      toast.success('Order cancelled')
    } catch { toast.error('Cannot cancel this order') }
  }

  if (loading) return <div style={{ padding:'48px', textAlign:'center' }}>Loading...</div>
  if (!order)  return <div style={{ padding:'48px', textAlign:'center', color:'#c0392b' }}>Order not found</div>

  const stepIdx = STEPS.indexOf(order.status)
  const canCancel = ['PENDING','CONFIRMED'].includes(order.status)

  return (
    <div style={{ maxWidth:'960px', margin:'0 auto', padding:'24px 16px' }}>
      <button onClick={()=>nav('/orders')} style={{ background:'none', border:'none', color:'#007185', cursor:'pointer', marginBottom:'16px', fontSize:'14px' }}>← Back to orders</button>

      <div style={{ background:'#fff', border:'1px solid #ddd', borderRadius:'8px', padding:'24px', marginBottom:'16px' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:'20px' }}>
          <div>
            <h1 style={{ fontSize:'20px', fontWeight:700 }}>Order #{order.orderNumber}</h1>
            <p style={{ color:'#555', fontSize:'13px' }}>Placed on {order.createdAt ? format(new Date(order.createdAt),'dd MMMM yyyy') : '—'}</p>
          </div>
          <div style={{ textAlign:'right' }}>
            <div style={{ fontWeight:700, fontSize:'18px', color: statusColor(order.status) }}>{order.status?.replace(/_/g,' ')}</div>
            {canCancel && <button onClick={cancel} style={{ marginTop:'8px', padding:'6px 12px', background:'#fff', border:'1px solid #ccc', borderRadius:'4px', cursor:'pointer', color:'#c0392b', fontSize:'13px' }}>Cancel Order</button>}
          </div>
        </div>

        {/* Progress tracker */}
        {!['CANCELLED','RETURNED','REFUNDED'].includes(order.status) && (
          <div style={{ display:'flex', alignItems:'center', marginBottom:'24px', overflowX:'auto', paddingBottom:'8px' }}>
            {STEPS.map((s,i) => (
              <React.Fragment key={s}>
                <div style={{ textAlign:'center', minWidth:'80px' }}>
                  <div style={{ width:'32px', height:'32px', borderRadius:'50%', margin:'0 auto 6px', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'14px', fontWeight:700, background: i<=stepIdx?'#007185':'#ddd', color: i<=stepIdx?'#fff':'#999' }}>
                    {i<stepIdx ? '✓' : i+1}
                  </div>
                  <div style={{ fontSize:'11px', color: i<=stepIdx?'#007185':'#999' }}>{s.replace(/_/g,' ')}</div>
                </div>
                {i<STEPS.length-1 && <div style={{ flex:1, height:'2px', background: i<stepIdx?'#007185':'#ddd', minWidth:'24px' }} />}
              </React.Fragment>
            ))}
          </div>
        )}

        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'24px' }}>
          <div>
            <h3 style={{ fontSize:'14px', fontWeight:700, marginBottom:'8px' }}>Delivery Address</h3>
            <div style={{ fontSize:'13px', color:'#555', lineHeight:1.8 }}>
              <div style={{ fontWeight:600, color:'#0f1111' }}>{order.deliveryName}</div>
              {order.deliveryLine1}<br/>{order.deliveryCity}, {order.deliveryState} {order.deliveryPincode}
            </div>
          </div>
          <div>
            <h3 style={{ fontSize:'14px', fontWeight:700, marginBottom:'8px' }}>Payment</h3>
            <div style={{ fontSize:'13px', color:'#555' }}>
              <div>Method: {order.paymentMethod?.replace(/_/g,' ')}</div>
              <div>Status: <span style={{ color:'#007600' }}>{order.paymentStatus}</span></div>
              {order.trackingNumber && <div style={{ marginTop:'6px' }}>Tracking: <strong>{order.trackingNumber}</strong></div>}
            </div>
          </div>
        </div>
      </div>

      {/* Items */}
      <div style={{ background:'#fff', border:'1px solid #ddd', borderRadius:'8px', padding:'24px', marginBottom:'16px' }}>
        <h2 style={{ fontSize:'18px', marginBottom:'16px' }}>Items</h2>
        {(order.items||[]).map(item => (
          <div key={item.itemId} style={{ display:'flex', gap:'16px', alignItems:'center', paddingBottom:'16px', marginBottom:'16px', borderBottom:'1px solid #eee' }}>
            <img src={item.thumbnailUrl||`https://picsum.photos/seed/${item.productId}/80/80`} style={{ width:'80px', height:'80px', objectFit:'contain' }} />
            <div style={{ flex:1 }}>
              <p style={{ fontWeight:500, marginBottom:'4px' }}>{item.productName}</p>
              <p style={{ fontSize:'13px', color:'#555' }}>Qty: {item.quantity}</p>
              <p style={{ fontSize:'13px', color:'#555' }}>₹{Number(item.unitPrice).toLocaleString('en-IN')} each</p>
            </div>
            <p style={{ fontWeight:700, fontSize:'16px' }}>₹{Number(item.totalPrice).toLocaleString('en-IN')}</p>
          </div>
        ))}
      </div>

      {/* Summary */}
      <div style={{ background:'#fff', border:'1px solid #ddd', borderRadius:'8px', padding:'24px', maxWidth:'360px', marginLeft:'auto' }}>
        <h3 style={{ marginBottom:'12px' }}>Order Total</h3>
        {[['Subtotal', order.subtotal],['Shipping', order.shippingAmt],['Tax', order.taxAmt]].map(([l,v])=>(
          <div key={l} style={{ display:'flex', justifyContent:'space-between', fontSize:'14px', marginBottom:'6px' }}>
            <span style={{ color:'#555' }}>{l}</span><span>₹{Number(v||0).toLocaleString('en-IN')}</span>
          </div>
        ))}
        <hr style={{ margin:'8px 0' }} />
        <div style={{ display:'flex', justifyContent:'space-between', fontWeight:700, fontSize:'18px' }}>
          <span>Total</span><span style={{ color:'#B12704' }}>₹{Number(order.totalAmt||0).toLocaleString('en-IN')}</span>
        </div>
      </div>
    </div>
  )
}