import axios from 'axios'
import { useAuthStore } from '../store/authStore'

const api = axios.create({ baseURL: '/api', timeout: 15000 })

api.interceptors.request.use(cfg => {
  const token = useAuthStore.getState().token
  if (token) cfg.headers.Authorization = `Bearer ${token}`
  return cfg
})

api.interceptors.response.use(r => r, err => {
  if (err.response?.status === 401) {
    useAuthStore.getState().logout()
    window.location.href = '/login'
  }
  return Promise.reject(err)
})

export const authApi = {
  register: d => api.post('/auth/register', d),
  login:    d => api.post('/auth/login', d),
}

export const productApi = {
  search:      (params) => api.get('/products', { params }),
  getById:     id       => api.get(`/products/${id}`),
  getFeatured: ()       => api.get('/products?size=20&sortBy=newest'),
  create:      d        => api.post('/products', d),
}

export const categoryApi = {
  getAll: () => api.get('/categories'),
}

export const cartApi = {
  get:    ()           => api.get('/cart'),
  add:    (productId, quantity=1) => api.post('/cart/items', { productId, quantity }),
  update: (productId, quantity)   => api.put(`/cart/items/${productId}`, { quantity }),
  remove: (productId)             => api.delete(`/cart/items/${productId}`),
  clear:  ()           => api.delete('/cart'),
  count:  ()           => api.get('/cart/count'),
}

export const orderApi = {
  place:      d        => api.post('/orders', d),
  getAll:     (page=0) => api.get(`/orders?page=${page}&size=10`),
  getById:    id       => api.get(`/orders/${id}`),
  cancel:     (id, reason) => api.post(`/orders/${id}/cancel`, { reason }),
}

export const reviewApi = {
  getByProduct: (productId, page=0) => api.get(`/reviews/public/product/${productId}?page=${page}`),
  getStats:     productId => api.get(`/reviews/public/product/${productId}/stats`),
  add:          (productId, d) => api.post(`/reviews/product/${productId}`, d),
}

export const userApi = {
  getMe:         () => api.get('/users/me'),
  updateMe:      d  => api.put('/users/me', d),
  getAddresses:  () => api.get('/users/me/addresses'),
  addAddress:    d  => api.post('/users/me/addresses', d),
  deleteAddress: id => api.delete(`/users/me/addresses/${id}`),
}

export default api