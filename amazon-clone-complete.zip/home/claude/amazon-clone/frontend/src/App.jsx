import React, { useEffect } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { useAuthStore }  from './store/authStore'
import { useCartStore }  from './store/cartStore'
import { cartApi }       from './utils/api'
import Navbar         from './components/shared/Navbar'
import Footer         from './components/shared/Footer'
import HomePage       from './components/home/HomePage'
import ProductPage    from './components/product/ProductPage'
import SearchPage     from './components/product/SearchPage'
import CartPage       from './components/cart/CartPage'
import CheckoutPage   from './components/checkout/CheckoutPage'
import OrdersPage     from './components/orders/OrdersPage'
import OrderDetail    from './components/orders/OrderDetail'
import LoginPage      from './components/auth/LoginPage'
import RegisterPage   from './components/auth/RegisterPage'
import ProfilePage    from './components/auth/ProfilePage'
import SellerPage     from './components/seller/SellerPage'

const Guard = ({ children }) => {
  const isAuth = useAuthStore(s => s.isAuthenticated)
  return isAuth ? children : <Navigate to="/login" replace />
}

export default function App() {
  const isAuth   = useAuthStore(s => s.isAuthenticated)
  const setCount = useCartStore(s => s.setCount)

  useEffect(() => {
    if (isAuth) {
      cartApi.count().then(r => setCount(r.data.count)).catch(() => {})
    }
  }, [isAuth])

  return (
    <BrowserRouter>
      <Toaster position="top-center" toastOptions={{
        style: { fontFamily: 'Arial', fontSize: '14px' },
        success: { style: { background: '#232f3e', color: '#fff' } },
        error:   { style: { background: '#c0392b', color: '#fff' } }
      }} />
      <Navbar />
      <Routes>
        <Route path="/"              element={<HomePage />} />
        <Route path="/product/:id"  element={<ProductPage />} />
        <Route path="/search"       element={<SearchPage />} />
        <Route path="/login"        element={<LoginPage />} />
        <Route path="/register"     element={<RegisterPage />} />
        <Route path="/cart"         element={<CartPage />} />
        <Route path="/checkout"     element={<Guard><CheckoutPage /></Guard>} />
        <Route path="/orders"       element={<Guard><OrdersPage /></Guard>} />
        <Route path="/orders/:id"   element={<Guard><OrderDetail /></Guard>} />
        <Route path="/profile"      element={<Guard><ProfilePage /></Guard>} />
        <Route path="/seller"       element={<Guard><SellerPage /></Guard>} />
        <Route path="*"             element={<Navigate to="/" replace />} />
      </Routes>
      <Footer />
    </BrowserRouter>
  )
}