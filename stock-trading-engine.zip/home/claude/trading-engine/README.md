# Stock Market Order Processing Engine
## Java Multithreading & Concurrency — Complete Demo Project

### How to Run

**Requirements:** Java 17+ and Maven 3.8+

```bash
# Build
cd trading-engine
mvn clean package -q

# Run
java -jar target/trading-engine.jar
```

**Quick one-liner (with javac in PATH):**
```bash
find src -name "*.java" | xargs javac -d target/classes && java -cp target/classes com.trading.Main
```

---

### Architecture
```
  10 Client Threads
       │  (Runnable lambdas in FixedThreadPool)
       ▼
  BlockingQueue<Order>          ← LinkedBlockingQueue(50,000)
       │  (OrderConsumer thread — take() blocks when empty)
       ▼
  ValidationService             ← FixedThreadPool(4) + Callable + ThreadLocal
       │  (CompletableFuture.supplyAsync)
       ▼
  OrderBook (per symbol)        ← ReentrantLock + StampedLock + TreeMap
       │  (price-time priority matching)
       ▼
  BlockingQueue<Trade>          ← LinkedBlockingQueue (pending settlement)
       │  (SettlementConsumer thread)
       ▼
  TradeSettlementService        ← CountDownLatch(2) + CompletableFuture
       │  debit buyer + credit seller (concurrent, both must succeed)
       ▼
  AccountService                ← ConcurrentHashMap + AtomicLong (CAS loop)
       │  (Semaphore-gated ConnectionPool: max 10 concurrent DB ops)
       ▼
  MetricsCollector              ← LongAdder + ScheduledExecutorService
       │  (dashboard every 3s)
       ▼
  ReportGenerator               ← ForkJoinPool + RecursiveTask + CyclicBarrier + Phaser
```

---

### Concurrency Concepts Map

| File | Concepts |
|------|----------|
| `Main.java` | FixedThreadPool, CountDownLatch, Runnable lambda, daemon threads |
| `TradingEngine.java` | BlockingQueue, CompletableFuture pipeline, volatile, AtomicLong |
| `OrderBook.java` | ReentrantLock (fair), StampedLock (optimistic read), volatile |
| `TradeSettlementService.java` | CountDownLatch(2), CompletableFuture, ExecutorService |
| `ReportGenerator.java` | ForkJoinPool, RecursiveTask, CyclicBarrier, Phaser |
| `AccountService.java` | ConcurrentHashMap, AtomicLong (CAS loop), Semaphore |
| `ValidationService.java` | ExecutorService (FixedThreadPool), Callable, ThreadLocal |
| `MarketDataService.java` | ScheduledExecutorService, volatile, CopyOnWriteArrayList |
| `MetricsCollector.java` | LongAdder, AtomicLong, ScheduledExecutorService |
| `ConnectionPool.java` | Semaphore (fair, bounded resource) |
| `CircuitBreaker.java` | AtomicReference state machine (CLOSED/OPEN/HALF_OPEN) |
| `ThreadLocalContext.java` | ThreadLocal, InheritableThreadLocal |
| `MarketData.java` | volatile (price fields), AtomicLong (CAS high/low), LongAdder |
| `Order.java` | volatile (price, status), AtomicReference (CAS transitions) |

---

### Key Design Decisions

**Why ReentrantLock over synchronized in OrderBook?**
- `tryLock(timeout)` prevents deadlock in cross-symbol arbitrage
- Fair mode ensures FIFO ordering (no thread starvation)
- Can be interrupted while waiting for lock

**Why StampedLock for best bid/ask reads?**
- Market depth is read thousands of times per second for each price tick
- Optimistic read: zero lock overhead when no write is happening (the common case)
- Falls back to read lock only when a write is detected during read

**Why LongAdder over AtomicLong for metrics?**
- AtomicLong uses a single cell: all threads contend on ONE CAS → high contention
- LongAdder uses a stripe of cells: each thread updates its own cell → near-zero contention
- `sum()` aggregates all cells: slightly more work on read, much less on write

**Why CopyOnWriteArrayList for market data listeners?**
- Listeners are added/removed rarely (low write frequency)
- Listeners are called on every price tick (very high read frequency)
- COW: iteration is lock-free (reads a snapshot); writes create a new array copy
- Perfect ratio for event-listener / observer patterns

**Why CountDownLatch(2) for settlement?**
- A trade involves two accounts: debiting buyer AND crediting seller
- Both must succeed for the trade to be valid (no partial settlement)
- `latch.await()` blocks until both operations complete (or timeout)
- `countDown()` called in each operation's `finally` block

**Why ForkJoinPool for report generation?**
- P&L / sum / max across thousands of trades is CPU-bound
- Work-stealing: if one thread finishes early, it steals tasks from busy threads
- RecursiveTask splits array in half recursively → utilises all CPU cores

