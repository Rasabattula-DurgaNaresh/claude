# Redis In Depth — Complete Reference Guide

> **Data Structures · Persistence · Replication · Clustering · Patterns · Performance · Interview Q&A**

---

## Diagram Index

| Diagram | Covers |
|---------|--------|
| `diagrams/01_redis_architecture.png` | Full Redis server architecture, all data types, use cases |
| `diagrams/02_data_structures.png` | String, List, Hash, Set, Sorted Set, Stream internals + all commands |
| `diagrams/03_persistence_replication.png` | RDB vs AOF, Master-Replica setup, Redis Cluster (hash slots) |
| `diagrams/04_patterns.png` | Caching patterns, Pub/Sub, Transactions, Rate Limiting, Leaderboard |
| `diagrams/05_performance_eviction.png` | Eviction policies, pipelining, performance tips, top 8 interview Q&As |

---

# PART 1: Redis Fundamentals

## What is Redis?

Redis (Remote Dictionary Server) is an open-source, **in-memory data structure store** used as:
- **Database** — persistent store with rich data types
- **Cache** — sub-millisecond latency key-value store
- **Message Broker** — Pub/Sub and Streams
- **Session Store** — TTL-based expiring data

**Key design decisions:**
- Data stored in **RAM** (optionally persisted to disk)
- **Single-threaded** command processing (no locking needed)
- **Event-loop** based I/O (non-blocking, handles thousands of connections)
- **RESP** (Redis Serialization Protocol) over TCP port 6379
- Redis 6+ supports **multi-threaded I/O** while keeping single-threaded command execution

```bash
# Install
sudo apt install redis-server  # Ubuntu
brew install redis              # macOS
docker run -d -p 6379:6379 redis:latest  # Docker

# Connect
redis-cli
redis-cli -h hostname -p 6379 -a password

# Key commands
PING                    # PONG
INFO                    # server info
CONFIG GET maxmemory    # get config
CONFIG SET maxmemory 2gb # set live config
DBSIZE                  # number of keys
SELECT 0                # switch database (0-15)
FLUSHDB                 # delete all keys in current DB
FLUSHDB ASYNC           # non-blocking flush
```

---

# PART 2: Data Structures

## 1. Strings

The most basic Redis type. Can hold text, numbers, binary data (JSON, images, serialized objects). Max size: **512 MB**.

**Internal implementation:** SDS (Simple Dynamic String) — O(1) length, O(1) append, binary safe.

```bash
# Basic
SET name "Alice"
GET name                    # "Alice"
DEL name                    # delete
EXISTS name                 # 1 or 0
TYPE name                   # string

# With expiry
SET token "abc123" EX 3600  # expire in 3600 seconds
SET token "abc123" PX 60000 # expire in 60000 ms
SETEX session 1800 "data"   # set with expiry
TTL key                     # seconds remaining (-1=no expiry, -2=not exists)
PERSIST key                 # remove expiry
EXPIREAT key 1700000000     # expire at Unix timestamp

# Conditional set
SETNX key value             # Set if Not eXists (for locks)
SET key value NX            # same as SETNX
SET key value XX            # only set if EXISTS
SET key value NX EX 30      # atomic lock with 30s expiry

# Multiple keys
MSET k1 v1 k2 v2 k3 v3
MGET k1 k2 k3              # returns list
MSETNX k1 v1 k2 v2         # all or nothing

# Numeric operations (atomic)
SET counter 0
INCR counter               # → 1
INCRBY counter 10          # → 11
DECR counter               # → 10
DECRBY counter 5           # → 5
INCRBYFLOAT price 0.50     # supports floats

# String manipulation
APPEND greeting " World"
STRLEN key
GETRANGE key 0 4           # substring (0-based, inclusive)
SETRANGE key 6 "Redis"     # overwrite at offset
GETSET key newvalue        # get old, set new (atomic)
GETDEL key                 # get and delete
GETEX key EX 3600          # get and set expiry

# Bit operations
SETBIT mykey 7 1           # set bit at position 7
GETBIT mykey 7
BITCOUNT mykey             # count set bits
BITPOS mykey 1             # first set bit position
BITOP AND destkey k1 k2    # bitwise AND
```

**Use cases:** Session tokens, counters, rate limiting, feature flags, cached API responses.

---

## 2. Lists

Doubly linked list of strings. **O(1)** push/pop at either end. **O(n)** for index access.

```bash
# Push
LPUSH mylist "a" "b" "c"   # adds to HEAD: c,b,a
RPUSH mylist "d" "e"       # adds to TAIL: c,b,a,d,e

# Pop
LPOP mylist                # removes from HEAD → "c"
RPOP mylist                # removes from TAIL → "e"
LPOP mylist 3              # pop 3 elements (Redis 6.2+)

# Read
LRANGE mylist 0 -1         # all elements (0=first, -1=last)
LRANGE mylist 0 9          # first 10
LINDEX mylist 2            # element at index 2
LLEN mylist                # length

# Modify
LSET mylist 0 "new_value"  # set by index
LINSERT mylist BEFORE "b" "x" # insert before element
LINSERT mylist AFTER "b" "y"
LREM mylist 2 "a"          # remove 2 occurrences of "a"
LTRIM mylist 0 99          # keep only first 100 elements

# Move
LMOVE src dst LEFT RIGHT   # atomic move between lists
RPOPLPUSH src dst          # pop from src tail, push to dst head

# Blocking operations (for queues)
BLPOP list1 list2 30       # block for 30s waiting for element
BRPOP list 0               # block indefinitely
BLMOVE src dst LEFT RIGHT 30

# Implementation pattern: Message Queue
RPUSH jobs "task1"         # Producer
BLPOP jobs 0               # Consumer (blocks until job available)
```

**Use cases:** Message queues, activity feeds, task lists, log collection, undo history.

---

## 3. Hashes

Map of field-value pairs within a single key. Like a flat object/dict/struct.

```bash
# Set
HSET user:1 name "Alice" age 30 city "NYC"
HMSET user:1 role admin active 1    # deprecated but works

# Get
HGET user:1 name           # "Alice"
HMGET user:1 name age      # ["Alice", "30"]
HGETALL user:1             # all fields and values
HKEYS user:1               # all field names
HVALS user:1               # all values
HLEN user:1                # number of fields

# Check & delete
HEXISTS user:1 email       # 0 or 1
HDEL user:1 city           # delete field(s)

# Numeric operations
HINCRBY user:1 age 1       # increment integer field
HINCRBYFLOAT user:1 score 1.5

# Scan large hashes
HSCAN user:1 0 MATCH name* COUNT 100

# Conditional
HSETNX user:1 email "alice@example.com" # set only if field missing
```

**Internal:** Uses ziplist (small hashes) → hashtable (large hashes). Threshold: `hash-max-ziplist-entries 128`.

**Use cases:** User profiles, product data, session attributes, configuration objects.

---

## 4. Sets

Unordered collection of unique strings. **O(1)** add/remove/check. Supports set math operations.

```bash
# Add/Remove
SADD fruits "apple" "banana" "mango" "cherry"
SREM fruits "banana"
SPOP fruits                # remove and return random member
SRANDMEMBER fruits 3       # return 3 random (no removal)

# Read
SMEMBERS fruits            # all members (no order guarantee)
SISMEMBER fruits "apple"   # 1 or 0
SMISMEMBER fruits "apple" "xyz"  # check multiple (Redis 6.2+)
SCARD fruits               # count members

# Set operations
SADD setA "a" "b" "c" "d"
SADD setB "c" "d" "e" "f"

SUNION setA setB           # union: a,b,c,d,e,f
SINTER setA setB           # intersection: c,d
SDIFF setA setB            # difference (in A not in B): a,b
SDIFFSTORE dest setA setB  # store result in dest

SUNIONSTORE dest setA setB
SINTERSTORE dest setA setB

# Move
SMOVE setA setB "a"        # atomic move member between sets

# Scan
SSCAN myset 0 MATCH a* COUNT 100
```

**Use cases:** Tags, followers/following, unique visitors, online users, permissions, friend lists.

---

## 5. Sorted Sets (ZSets)

Ordered collection where each member has a floating-point **score**. Members are unique; scores can repeat.

**Internal:** Skip list + hash table. O(log n) for most operations.

```bash
# Add
ZADD leaderboard 5000 "Alice"
ZADD leaderboard 7200 "Bob" 6100 "Carol"
ZADD leaderboard NX 4000 "Dave"  # only if not exists
ZADD leaderboard XX 5500 "Alice" # only update if exists
ZADD leaderboard GT 6000 "Alice" # update only if new > current
ZADD leaderboard INCR 500 "Alice" # add 500 to score, return new

# Read by rank (0-indexed, ascending)
ZRANGE leaderboard 0 -1 WITHSCORES  # lowest to highest
ZREVRANGE leaderboard 0 9           # top 10 (highest first)
ZRANK leaderboard "Alice"           # rank (0=lowest)
ZREVRANK leaderboard "Alice"        # reverse rank (0=highest)
ZSCORE leaderboard "Alice"          # get score

# Read by score
ZRANGEBYSCORE lb 5000 7000 WITHSCORES LIMIT 0 10
ZREVRANGEBYSCORE lb +inf 5000
ZRANGEBYSCORE lb -inf +inf          # all members
ZCOUNT lb 5000 7000                 # count in range

# Lexicographic range (same-score members)
ZRANGEBYLEX myset "[a" "[z"         # all members starting a-z

# Modify/Remove
ZINCRBY leaderboard 100 "Alice"     # add to score
ZREM leaderboard "Dave"
ZPOPMIN leaderboard 3               # pop 3 with lowest scores
ZPOPMAX leaderboard 3               # pop 3 with highest scores
ZREMRANGEBYRANK lb 0 9              # remove by rank range
ZREMRANGEBYSCORE lb -inf 1000       # remove by score range

# Blocking pop (Redis 5.0+)
BZPOPMIN key timeout                # block until element available

# Set operations (with weights)
ZUNIONSTORE out 2 z1 z2 WEIGHTS 2 3
ZINTERSTORE out 2 z1 z2 AGGREGATE MIN

# Scan
ZSCAN myset 0 MATCH a* COUNT 100
```

**Use cases:** Leaderboards, priority queues, ranking systems, time-series with score=timestamp, autocomplete.

---

## 6. Streams

Append-only log of messages, inspired by Kafka. Each entry has a unique ID (timestamp-sequence).

```bash
# Add entries
XADD mystream * user "alice" action "login"  # auto-generate ID
XADD mystream 1638000000000-0 user "bob"     # explicit ID
XADD mystream MAXLEN ~ 1000 * field value    # cap at 1000 entries (~=approximate)

# Read
XREAD COUNT 10 STREAMS mystream 0             # read from start
XREAD COUNT 10 STREAMS mystream $             # only new messages
XRANGE mystream - +                           # all entries
XRANGE mystream - + COUNT 10                 # first 10
XREVRANGE mystream + -                       # reverse

# Length and trim
XLEN mystream
XTRIM mystream MAXLEN 1000                   # trim to 1000 entries
XDEL mystream entryId                        # delete specific entry

# Consumer Groups (distributed processing)
XGROUP CREATE mystream mygroup $ MKSTREAM    # create group from last
XGROUP CREATE mystream mygroup 0             # process from beginning

# Read as consumer in group
XREADGROUP GROUP mygroup consumer1 COUNT 10 STREAMS mystream >
# > means "pending entries not yet delivered"

# Acknowledge processing
XACK mystream mygroup entry-id

# See pending (not yet acked)
XPENDING mystream mygroup - + 10
XPENDING mystream mygroup - + 10 consumer1

# Claim timed-out pending messages (for failover)
XCLAIM mystream mygroup consumer2 60000 entry-id  # claim if pending > 60s

# Stream info
XINFO STREAM mystream
XINFO GROUPS mystream
XINFO CONSUMERS mystream mygroup
```

**Use cases:** Event sourcing, activity logs, real-time data pipelines, audit trails, sensor data.

---

## 7. Bitmaps

Not a separate type — operations on string bytes. Treat string as array of bits.

```bash
SETBIT visits 100 1          # set bit at offset 100
GETBIT visits 100
BITCOUNT visits              # count set bits
BITCOUNT visits 0 3          # count in bytes 0-3
BITPOS visits 1              # position of first set bit
BITPOS visits 0              # position of first 0 bit

# Bitwise operations
BITOP AND dest key1 key2     # AND all bits
BITOP OR dest key1 key2
BITOP XOR dest key1 key2
BITOP NOT dest key1

# Use case: Daily active users
# User 42 visited on day 1638000000:
SETBIT dau:1638000000 42 1
# How many users visited?
BITCOUNT dau:1638000000
# Which users visited on BOTH days?
BITOP AND both_days dau:day1 dau:day2
BITCOUNT both_days
```

**Use cases:** User activity tracking, feature flags per user, DAU/WAU/MAU counting, bloom filter basics.

---

## 8. HyperLogLog

Probabilistic data structure for approximate cardinality counting. Uses constant ~12KB memory regardless of set size. Error rate: **~0.81%**.

```bash
PFADD unique_users "alice" "bob" "charlie" "alice"  # adds, deduplicates
PFCOUNT unique_users          # approximate count: ~3
PFMERGE combined hll1 hll2    # merge two HLLs
```

**Use cases:** Unique visitor counts, unique search queries, approximate distinct counts at scale.

---

## 9. Geospatial

Store and query geographic coordinates. Internally uses sorted set with geohash as score.

```bash
GEOADD locations 13.361389 38.115556 "Palermo"
GEOADD locations 15.087269 37.502669 "Catania"
GEOADD locations -73.9857 40.7484 "NewYork"

GEODIST locations "Palermo" "Catania" km    # distance in km
GEOPOS locations "Palermo"                  # get coordinates
GEOSEARCH locations FROMMEMBER "Palermo" BYRADIUS 200 km ASC
GEOSEARCH locations FROMLONLAT 15 37 BYBOX 400 400 km ASC
GEOHASH locations "Palermo"                # geohash string
```

**Use cases:** Nearby search, location-based filtering, delivery radius, store locators.

---

## 10. Lua Scripting

Execute Lua scripts atomically on the server. Scripts can access all Redis commands.

```lua
-- EVAL script numkeys key [key ...] arg [arg ...]
EVAL "return redis.call('SET', KEYS[1], ARGV[1])" 1 mykey myvalue

-- Load and cache script (returns SHA)
SCRIPT LOAD "return redis.call('GET', KEYS[1])"
-- Execute by SHA (more efficient)
EVALSHA sha1 1 mykey

-- Atomic increment with max check (rate limiting)
local current = redis.call('INCR', KEYS[1])
if current == 1 then redis.call('EXPIRE', KEYS[1], ARGV[1]) end
if current > tonumber(ARGV[2]) then return 0 end
return 1

-- Script management
SCRIPT EXISTS sha1 sha2
SCRIPT FLUSH                -- clear script cache
SCRIPT KILL                 -- kill running script
```

---

# PART 3: Persistence

> See diagram: `diagrams/03_persistence_replication.png`

## RDB (Redis Database) — Snapshots

Periodically saves a point-in-time snapshot to `dump.rdb`.

```bash
# redis.conf
save 900 1       # save if 1 key changed in 900s
save 300 10      # save if 10 keys changed in 300s
save 60 10000    # save if 10000 keys changed in 60s

dbfilename dump.rdb
dir /var/lib/redis

# Manual trigger
BGSAVE              # async (fork child, recommended)
SAVE                # synchronous (blocks server!)
LASTSAVE            # timestamp of last successful save
```

**How it works:**
1. Server calls `fork()` — creates child process (copy-on-write)
2. Child writes RDB file to temp file
3. Parent continues serving requests (may diverge from snapshot)
4. Child completes, atomically replaces old dump.rdb

**Pros:** Compact single file, fast restart, good for backups
**Cons:** Data loss between snapshots (minutes), large fork overhead

---

## AOF (Append-Only File)

Logs every write command. On restart, replays all commands.

```bash
# redis.conf
appendonly yes
appendfilename "appendonly.aof"

appendfsync always    # every command (safest, slowest)
appendfsync everysec  # every second (default, good balance)
appendfsync no        # OS decides (fastest, least safe)

# Auto-rewrite when AOF is 100% larger than last rewrite
auto-aof-rewrite-percentage 100
auto-aof-rewrite-min-size 64mb

# Manual rewrite
BGREWRITEAOF        # compact AOF in background
```

**Pros:** Durable (very little data loss), human-readable, point-in-time recovery
**Cons:** Larger file size, slower startup, higher disk I/O

---

## Hybrid Mode (RDB + AOF)

Best of both worlds: fast restart from RDB + full durability from AOF.

```bash
# redis.conf
aof-use-rdb-preamble yes  # write RDB preamble in AOF
```

---

# PART 4: Replication & High Availability

## Master-Replica Replication

```bash
# On replica (redis.conf or runtime)
REPLICAOF master_ip 6379
# or
SLAVEOF master_ip 6379   # deprecated alias

# Runtime
REPLICAOF NO ONE          # promote to master (break replication)

# Info
INFO replication          # replication status
```

**How initial sync works:**
1. Replica connects and sends `REPLCONF listening-port`
2. Master sends `FULLRESYNC`: forks, writes RDB, sends to replica
3. Replica loads RDB, then receives incremental command stream
4. Replica executes all commands to stay in sync

**Partial resync (PSYNC):** If replica briefly disconnects, master keeps a replication backlog. Replica can re-sync without full RDB transfer using replication offset.

```bash
# replica config
replica-read-only yes         # replicas are read-only
replica-lazy-flush yes        # async flush on new sync
min-replicas-to-write 1       # require at least 1 replica for writes
min-replicas-max-lag 10       # replica must be in sync within 10s
```

---

## Redis Sentinel — Auto-failover

Monitor masters/replicas and automatically promote replica on master failure.

```bash
# sentinel.conf
sentinel monitor mymaster 127.0.0.1 6379 2  # quorum=2
sentinel down-after-milliseconds mymaster 5000
sentinel failover-timeout mymaster 10000
sentinel parallel-syncs mymaster 1

# Start sentinel
redis-sentinel /etc/redis/sentinel.conf
redis-server /etc/redis/sentinel.conf --sentinel

# Query sentinel
redis-cli -p 26379 SENTINEL masters
redis-cli -p 26379 SENTINEL get-master-addr-by-name mymaster
```

**Sentinel process:**
1. Sentinels monitor master health (send PING)
2. If master doesn't respond: sentinel marks as `subjectively down`
3. When quorum sentinels agree: `objectively down`
4. Sentinels elect a leader sentinel
5. Leader selects best replica, sends `SLAVEOF NO ONE`
6. Other replicas point to new master
7. Old master reconfigured as replica when it returns

---

## Redis Cluster — Horizontal Scaling

Automatic sharding across multiple nodes using **hash slots** (16384 slots).

```
Key → CRC16(key) mod 16384 = slot → assigned to a shard
```

```bash
# Create cluster (6 nodes minimum: 3 master + 3 replica)
redis-cli --cluster create \
  127.0.0.1:7000 127.0.0.1:7001 127.0.0.1:7002 \
  127.0.0.1:7003 127.0.0.1:7004 127.0.0.1:7005 \
  --cluster-replicas 1

# Cluster info
redis-cli -c -p 7000 CLUSTER INFO
redis-cli -p 7000 CLUSTER NODES
redis-cli -p 7000 CLUSTER SLOTS

# Hash tags — force keys to same slot
SET {user:1}:profile "data"
SET {user:1}:session "token"  # same slot as {user:1}:profile

# Cluster config
cluster-enabled yes
cluster-config-file nodes.conf
cluster-node-timeout 5000
cluster-require-full-coverage yes  # reject writes if any slot unavailable
```

**MOVED redirect:** When a key belongs to a different node, server returns `MOVED slot ip:port`. Smart clients (Jedis, Lettuce) handle this automatically.

---

# PART 5: Eviction Policies

When `maxmemory` is reached, Redis uses the configured eviction policy:

| Policy | Description | Recommendation |
|--------|-------------|----------------|
| `noeviction` | Return error on write | For databases (not cache) |
| `allkeys-lru` | Evict least recently used from all keys | **Best for general cache** |
| `volatile-lru` | Evict LRU from keys with TTL | When mixing persistent + cached data |
| `allkeys-lfu` | Evict least frequently used from all | Hot/cold access patterns |
| `volatile-lfu` | Evict LFU from keys with TTL | Same but only TTL keys |
| `allkeys-random` | Evict random key | Rarely appropriate |
| `volatile-random` | Evict random key with TTL | Rarely appropriate |
| `volatile-ttl` | Evict key with shortest TTL | When you control TTL carefully |

```bash
# redis.conf
maxmemory 2gb
maxmemory-policy allkeys-lru

# LFU tuning
lfu-log-factor 10         # higher = count more slowly
lfu-decay-time 1          # minutes before frequency decays

# Check eviction stats
INFO stats | grep evicted_keys
```

---

# PART 6: Patterns & Use Cases

> See diagram: `diagrams/04_patterns.png`

## Caching Patterns

### Cache-Aside (Lazy Loading)
```python
def get_user(user_id):
    cache_key = f"user:{user_id}"
    data = redis.get(cache_key)
    if data is None:
        data = db.query("SELECT * FROM users WHERE id=?", user_id)
        redis.setex(cache_key, 3600, json.dumps(data))
    return json.loads(data)
```

### Write-Through
```python
def update_user(user_id, data):
    db.update("users", user_id, data)     # write to DB
    redis.setex(f"user:{user_id}", 3600, json.dumps(data))  # update cache
```

### Cache Stampede Prevention
```python
# Probabilistic early expiration
def get_with_protection(key, ttl, recompute_fn):
    val = redis.get(key)
    remaining = redis.ttl(key)
    if val and remaining > 0:
        # Randomly refresh before expiry
        if remaining < ttl * 0.1 and random.random() < 0.1:
            val = recompute_fn()
            redis.setex(key, ttl, val)
    elif not val:
        val = recompute_fn()
        redis.setex(key, ttl, val)
    return val
```

---

## Pub/Sub Messaging

```bash
# Terminal 1 — Subscriber
SUBSCRIBE news:tech sports:live

# Terminal 2 — Another subscriber (pattern)
PSUBSCRIBE news:*

# Terminal 3 — Publisher
PUBLISH news:tech "AI breakthrough announced"
PUBLISH sports:live "Goal scored!"

# Active channels
PUBSUB CHANNELS news:*      # channels matching pattern
PUBSUB NUMSUB news:tech     # subscriber count per channel
PUBSUB NUMPAT               # number of pattern subscribers
```

**Limitations:** Fire-and-forget, no persistence. Use **Streams** for durability.

---

## Transactions

```bash
MULTI
SET balance 100
INCR transaction_count
HSET account:1 last_tx "2024-01-01"
EXEC              # execute all atomically

MULTI
SET key "value"
DISCARD           # cancel all queued commands
```

**WATCH for optimistic locking:**
```bash
WATCH balance
MULTI
val = GET balance          # read current value
SET balance (val + amount) # conditional write
result = EXEC              # nil if balance changed since WATCH
if result is nil:
    retry()                # balance was modified by another client
```

---

## Rate Limiting

```bash
# Fixed window (simple)
def is_allowed(user_id, limit=100, window=3600):
    key = f"rl:{user_id}:{int(time.time()/window)}"
    count = redis.incr(key)
    if count == 1: redis.expire(key, window)
    return count <= limit

# Sliding window log (precise)
def is_allowed_sliding(user_id, limit=100, window=60):
    now = time.time()
    key = f"rl:sliding:{user_id}"
    pipe = redis.pipeline()
    pipe.zremrangebyscore(key, 0, now - window)
    pipe.zadd(key, {str(now): now})
    pipe.zcard(key)
    pipe.expire(key, window)
    results = pipe.execute()
    return results[2] <= limit

# Token bucket (Lua script for atomicity)
EVAL """
local tokens_key = KEYS[1]
local timestamp_key = KEYS[2]
local rate = tonumber(ARGV[1])
local capacity = tonumber(ARGV[2])
local now = tonumber(ARGV[3])
local requested = tonumber(ARGV[4])
local last_tokens = tonumber(redis.call('get', tokens_key) or capacity)
local last_refreshed = tonumber(redis.call('get', timestamp_key) or 0)
local delta = math.max(0, now - last_refreshed)
local filled_tokens = math.min(capacity, last_tokens + delta * rate)
local allowed = filled_tokens >= requested
if allowed then filled_tokens = filled_tokens - requested end
redis.call('set', tokens_key, filled_tokens)
redis.call('set', timestamp_key, now)
return allowed and 1 or 0
""" 2 tokens:{user} ts:{user} 10 100 {now} 1
```

---

## Distributed Locking (Redlock Algorithm)

```bash
# Single instance lock
SET lock:resource "unique_token" NX PX 30000  # 30s expiry

# Release (Lua ensures atomic check-and-delete)
EVAL "
  if redis.call('get', KEYS[1]) == ARGV[1] then
    return redis.call('del', KEYS[1])
  else
    return 0
  end
" 1 lock:resource unique_token
```

**Redlock (multiple instances for safety):**
1. Acquire lock on N/2+1 Redis instances within time limit
2. Lock valid if acquired on majority before expiry
3. Release on all instances (even failures)

---

## Job Queue (Reliable Queue Pattern)

```bash
# Producer
RPUSH jobs:pending '{"type":"email","to":"alice@example.com"}'

# Consumer (atomic pop + processing)
job = BRPOPLPUSH jobs:pending jobs:processing 30
# If consumer crashes, job stays in jobs:processing for recovery
process(job)
LREM jobs:processing 1 job  # on success

# Recovery: requeue stuck jobs
stuck = LRANGE jobs:processing 0 -1
for job in stuck:
    RPUSH jobs:pending job
    LREM jobs:processing 1 job
```

---

# PART 7: Performance Optimization

> See diagram: `diagrams/05_performance_eviction.png`

## Pipelining

Batch multiple commands to reduce network round-trips:

```python
# Without pipelining: N round trips
for i in range(100):
    redis.set(f"key:{i}", i)

# With pipelining: 1 round trip
pipe = redis.pipeline()
for i in range(100):
    pipe.set(f"key:{i}", i)
pipe.execute()

# Non-transactional pipeline (no MULTI/EXEC overhead)
pipe = redis.pipeline(transaction=False)
```

---

## Key Naming Conventions

```bash
# Good patterns
user:1:profile           # type:id:field
user:1001:orders         # colon as separator
session:abc123           # feature:identifier
rate:limit:user:1:hour   # rate:limit:entity:id:window
cache:api:v2:/products   # cache:feature:version:path

# Avoid
veryLongKeyNameThatWastesMemory  # long keys waste memory
x1                               # cryptic
```

---

## Memory Optimization

```bash
# Check memory
INFO memory
MEMORY USAGE key           # memory for specific key
MEMORY DOCTOR              # get recommendations
MEMORY MALLOC-STATS        # allocator stats

# Optimize data structures
hash-max-ziplist-entries 128    # use ziplist for small hashes
hash-max-ziplist-value 64       # max value size in ziplist
list-max-ziplist-size -2        # -2 = 8kb per zipnode
set-max-intset-entries 512      # integer set optimization
zset-max-ziplist-entries 128    # sorted set ziplist threshold

# Key patterns
SCAN 0 MATCH user:* COUNT 100   # iterate keys safely (never KEYS *)
SCAN cursor [MATCH pattern] [COUNT count] [TYPE type]
```

---

## Slow Log

```bash
# redis.conf
slowlog-log-slower-than 10000   # microseconds (10ms)
slowlog-max-len 128

# View slow queries
SLOWLOG GET 10          # last 10 slow commands
SLOWLOG LEN             # total slow commands
SLOWLOG RESET           # clear slow log
```

---

## Benchmarking

```bash
redis-benchmark -h 127.0.0.1 -p 6379 -n 100000 -c 50

# Specific commands
redis-benchmark -t set,get -n 100000 -q
redis-benchmark -t set -n 1000000 -d 100 -c 100 --pipeline 16

# Results show ops/sec for each command type
```

---

## redis.conf Key Settings

```bash
# Network
bind 127.0.0.1 -::1        # listen address
port 6379
protected-mode yes
requirepass your-password   # AUTH command

# Memory
maxmemory 2gb
maxmemory-policy allkeys-lru

# Performance
tcp-backlog 511
tcp-keepalive 300
databases 16                # number of databases (0-15)
hz 10                       # background task frequency

# Slow log
slowlog-log-slower-than 10000
slowlog-max-len 128

# Lazy operations
lazyfree-lazy-eviction yes
lazyfree-lazy-expire yes
lazyfree-lazy-server-del yes
replica-lazy-flush yes

# Logging
loglevel notice
logfile /var/log/redis/redis.log

# TLS/SSL (Redis 6+)
tls-port 6380
tls-cert-file /path/to/cert.pem
tls-key-file /path/to/key.pem
tls-ca-cert-file /path/to/ca.pem
```

---

# PART 8: Security

```bash
# Authentication
requirepass "strongpassword"
AUTH password

# ACL (Access Control Lists — Redis 6+)
ACL SETUSER alice on >password ~cache:* +GET +SET +DEL
ACL SETUSER bob on >password ~* +@read   # read-only
ACL SETUSER admin on >adminpass ~* +@all # full access
ACL LIST                                  # show all users
ACL WHOAMI                               # current user
ACL GETUSER alice                        # user details

# Command restriction (redis.conf)
rename-command FLUSHALL ""               # disable command
rename-command FLUSHDB "FLUSHDB_SECRET"  # rename command
rename-command CONFIG ""                 # disable CONFIG

# Network security
bind 127.0.0.1                          # bind to localhost only
protected-mode yes                       # reject external connections

# TLS encryption (Redis 6+)
tls-port 6380
# Enable mutual TLS for cluster communication
```

---

# PART 9: Monitoring

```bash
# Key info commands
INFO                        # all sections
INFO server                 # version, uptime, memory
INFO clients                # connected clients
INFO memory                 # memory usage
INFO stats                  # operations stats
INFO replication            # master/replica info
INFO cpu                    # CPU usage
INFO keyspace               # key counts per database

# Real-time monitoring
MONITOR                     # stream all commands (development only!)
CLIENT LIST                 # all connected clients
CLIENT GETNAME              # current connection name
CLIENT SETNAME "myservice"  # set connection name
CLIENT KILL ID 100          # kill a connection

# Stats
DBSIZE                      # number of keys
OBJECT ENCODING key         # internal encoding
OBJECT IDLETIME key         # seconds since last access
OBJECT FREQ key             # access frequency (LFU)
OBJECT HELP                 # available subcommands

# DEBUG
DEBUG SLEEP 2               # sleep 2 seconds (testing)
DEBUG JMAP                  # Java heap dump (test env)
DEBUG RELOAD                # force RDB reload
DEBUG FLUSHALL              # flush all keys fast
```

---

# PART 10: Top Interview Questions

## Q1: What is Redis and why is it so fast?

Redis is an in-memory data structure store. It's fast because:
1. **In-memory:** No disk I/O for data access
2. **Single-threaded:** No mutex/locking overhead for command execution
3. **Non-blocking I/O:** Epoll/kqueue for handling thousands of connections
4. **Efficient data structures:** SDS strings, skip lists, hash tables
5. **Simple protocol:** RESP is lightweight and easy to parse

## Q2: Redis vs Memcached

| Feature | Redis | Memcached |
|---------|-------|-----------|
| Data Types | 10+ (String, List, Hash, Set, ZSet, Stream...) | Strings only |
| Persistence | RDB + AOF | None |
| Replication | Master-Replica | None |
| Clustering | Redis Cluster | Client-side |
| Pub/Sub | Yes | No |
| Transactions | MULTI/EXEC | No |
| Lua Scripting | Yes | No |
| Memory | Efficient | Slightly lower overhead |
| Use Case | General purpose | Pure cache |

## Q3: Is Redis single-threaded?

**Command execution:** Single-threaded (one command at a time — no locking needed).
**I/O handling (Redis 6+):** Multi-threaded (reading/writing sockets).
**Background tasks:** Always multi-threaded (persistence, replication, expiry).

## Q4: Explain Redis persistence options

- **RDB:** Periodic snapshots. Fast restart, potential data loss. Good for backups.
- **AOF:** Log every write. Very durable, larger file, slower startup.
- **Hybrid:** RDB preamble + AOF tail. Best of both worlds.
- **No persistence:** Pure cache. All data lost on restart.

## Q5: What is a Redis Cluster?

Horizontal sharding across multiple nodes using 16384 hash slots. Each key is assigned `CRC16(key) mod 16384`. Minimum: 3 masters + 3 replicas. Handles automatic failover. Multi-key commands require keys in same slot (use hash tags `{tag}`).

## Q6: How do you prevent Cache Stampede?

Cache stampede: many requests hit DB simultaneously when cache expires.
- **Probabilistic refresh:** Randomly refresh before expiry
- **Mutex lock:** Only one request populates cache (`SETNX lock`)
- **Background refresh:** Pre-warm cache before expiry
- **Stale-while-revalidate:** Serve stale data while refreshing async

## Q7: WATCH vs MULTI?

- `MULTI`: Starts a transaction block. Commands are queued and executed atomically on `EXEC`.
- `WATCH key`: Sets an optimistic lock. If `key` changes before `EXEC`, the transaction is aborted (returns nil).
- Together they implement Check-And-Set (CAS) for safe Read-Modify-Write.

## Q8: How to find and delete large keys?

```bash
# Find large keys
redis-cli --bigkeys              # sample keys, find largest
MEMORY USAGE key                 # memory for specific key

# Scan and process (never KEYS * in production)
SCAN 0 MATCH pattern COUNT 100

# Delete large keys safely (avoid blocking)
UNLINK key                       # async delete (Redis 4+)
redis-cli SCAN 0 | xargs redis-cli DEL  # batch delete with SCAN
```

## Q9: What eviction policy should I use?

- **General cache:** `allkeys-lru` — evicts least recently used from all keys
- **Mixed use (cache + persistent):** `volatile-lru` — only evicts TTL keys
- **Hot/cold data:** `allkeys-lfu` — evicts least frequently used
- **Never evict:** `noeviction` — for databases, returns error when full

## Q10: How does Pub/Sub differ from Streams?

| Feature | Pub/Sub | Streams |
|---------|---------|---------|
| Persistence | No | Yes |
| Consumer Groups | No | Yes |
| Message replay | No | Yes |
| Guaranteed delivery | No | Yes (with ACK) |
| Backpressure | No | Yes (MAXLEN) |
| Use case | Fire-and-forget events | Durable messaging, event sourcing |

---

# PART 11: Common Patterns Cheat Sheet

```bash
# ─── Atomic Counter ───────────────────────────────
INCR pageviews:home
INCRBY score:user:1 10

# ─── Rate Limiter ─────────────────────────────────
INCR limit:user:123:minute
EXPIRE limit:user:123:minute 60

# ─── Cache with TTL ───────────────────────────────
SET cache:user:1 '{"name":"Alice"}' EX 3600
GETEX cache:user:1 EX 3600          # get + refresh TTL

# ─── Distributed Lock ─────────────────────────────
SET lock:resource uuid NX PX 30000  # acquire
# ... critical section ...
EVAL "if redis.call('get',KEYS[1])==ARGV[1] then return redis.call('del',KEYS[1]) else return 0 end" 1 lock:resource uuid

# ─── Job Queue ────────────────────────────────────
RPUSH queue:jobs '{"type":"email","data":{...}}'
BLPOP queue:jobs 30                 # blocking dequeue

# ─── Leaderboard ──────────────────────────────────
ZADD leaderboard 5000 "alice"
ZINCRBY leaderboard 100 "alice"
ZREVRANGE leaderboard 0 9 WITHSCORES

# ─── Tags / Many-to-Many ──────────────────────────
SADD tag:redis article:1 article:2 article:5
SADD tag:cache article:1 article:3 article:5
SINTER tag:redis tag:cache          # articles with both tags

# ─── Geospatial ───────────────────────────────────
GEOADD stores -73.985 40.748 "store:1"
GEOSEARCH stores FROMLONLAT -74 40.7 BYRADIUS 5 km ASC COUNT 10

# ─── Unique Visitors (HyperLogLog) ────────────────
PFADD visitors:2024-01-15 "user:123"
PFCOUNT visitors:2024-01-15

# ─── Time Series (Stream) ─────────────────────────
XADD sensor:temp * value 22.5 unit celsius
XRANGE sensor:temp - + COUNT 100
XREAD COUNT 10 BLOCK 0 STREAMS sensor:temp $  # wait for new data

# ─── User Session ─────────────────────────────────
HSET session:abc user_id 1 role admin expires 1700000000
HGETALL session:abc
EXPIRE session:abc 1800

# ─── Feature Flags ────────────────────────────────
SADD feature:dark_mode user:1 user:5 user:100
SISMEMBER feature:dark_mode user:1  # is user in group?

# ─── Autocomplete ─────────────────────────────────
ZADD search:index 0 "redis"
ZADD search:index 0 "redis cluster"
ZADD search:index 0 "redis sentinel"
ZRANGEBYLEX search:index "[redi" "[redi\xff"  # prefix search
```

---

# Quick Reference Card

## Key Expiry Commands
```bash
EXPIRE key seconds         SET expiry in seconds
PEXPIRE key milliseconds   SET expiry in ms
EXPIREAT key timestamp     SET expiry at Unix timestamp
PEXPIREAT key ms-timestamp Set expiry at Unix ms timestamp
TTL key                    Seconds remaining (-1=no expiry, -2=gone)
PTTL key                   Milliseconds remaining
PERSIST key                Remove expiry (make permanent)
```

## Key Operations
```bash
DEL key [key ...]          Delete synchronously
UNLINK key [key ...]       Delete asynchronously (Redis 4+)
EXISTS key [key ...]       Check existence (returns count)
RENAME key newkey          Rename key
RENAMENX key newkey        Rename only if newkey doesn't exist
COPY source dest           Copy key (Redis 6.2+)
MOVE key db                Move to another database
TYPE key                   Get type (string/list/set/zset/hash/stream)
OBJECT ENCODING key        Get internal encoding
DUMP key / RESTORE         Serialize/deserialize key
SCAN cursor [MATCH] [COUNT] [TYPE]  Iterate keys safely
WAIT numreplicas timeout   Wait for replicas to sync
```

*Redis In Depth — Complete Reference | All Data Types · Persistence · Patterns · Performance · Interview Q&A*
