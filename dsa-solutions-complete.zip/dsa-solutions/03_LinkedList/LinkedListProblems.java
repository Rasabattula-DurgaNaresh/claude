/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║      LINKED LIST - LeetCode & GeeksForGeeks Solutions        ║
 * ╚══════════════════════════════════════════════════════════════╝
 * LC2   Add Two Numbers
 * LC19  Remove Nth Node From End
 * LC21  Merge Two Sorted Lists
 * LC23  Merge K Sorted Lists
 * LC24  Swap Nodes in Pairs
 * LC25  Reverse Nodes in k-Group
 * LC61  Rotate List
 * LC82  Remove Duplicates from Sorted List II
 * LC83  Remove Duplicates from Sorted List
 * LC92  Reverse Linked List II
 * LC141 Linked List Cycle
 * LC142 Linked List Cycle II
 * LC160 Intersection of Two Linked Lists
 * LC206 Reverse Linked List
 * LC234 Palindrome Linked List
 * GFG   Detect and Remove Loop
 * GFG   Merge Sort on Linked List
 * GFG   Flatten a Linked List
 * GFG   Add 1 to a number represented as LL
 */
import java.util.*;

public class LinkedListProblems {

    static class ListNode {
        int val; ListNode next;
        ListNode(int v) { val = v; }
        static ListNode of(int... vals) {
            ListNode dummy = new ListNode(0), cur = dummy;
            for (int v : vals) { cur.next = new ListNode(v); cur = cur.next; }
            return dummy.next;
        }
        static String str(ListNode h) {
            StringBuilder sb = new StringBuilder("[");
            Set<ListNode> seen = new HashSet<>();
            while (h != null && !seen.contains(h)) {
                seen.add(h); sb.append(h.val); if(h.next!=null&&!seen.contains(h.next)) sb.append("->");
                h = h.next;
            }
            if (h != null) sb.append("...CYCLE");
            return sb.append("]").toString();
        }
    }

    // LC206 - REVERSE LINKED LIST
    /**
     * APPROACH: Iterative — 3 pointers (prev, cur, next)
     * TIME: O(n)  SPACE: O(1)
     */
    static ListNode reverseList(ListNode head) {
        ListNode prev = null, cur = head;
        while (cur != null) {
            ListNode next = cur.next; cur.next = prev; prev = cur; cur = next;
        }
        return prev;
    }

    // LC21 - MERGE TWO SORTED LISTS
    /**
     * APPROACH: Dummy node, greedily pick smaller head
     * TIME: O(n+m)  SPACE: O(1)
     */
    static ListNode mergeTwoLists(ListNode l1, ListNode l2) {
        ListNode dummy = new ListNode(0), cur = dummy;
        while (l1 != null && l2 != null) {
            if (l1.val <= l2.val) { cur.next = l1; l1 = l1.next; }
            else                  { cur.next = l2; l2 = l2.next; }
            cur = cur.next;
        }
        cur.next = (l1 != null) ? l1 : l2;
        return dummy.next;
    }

    // LC2 - ADD TWO NUMBERS (digits in reverse order)
    /**
     * APPROACH: Simulate addition with carry
     * TIME: O(max(n,m))  SPACE: O(max(n,m))
     * EXAMPLE: [2,4,3] + [5,6,4] → [7,0,8] (342+465=807)
     */
    static ListNode addTwoNumbers(ListNode l1, ListNode l2) {
        ListNode dummy = new ListNode(0), cur = dummy;
        int carry = 0;
        while (l1 != null || l2 != null || carry != 0) {
            int sum = carry;
            if (l1 != null) { sum += l1.val; l1 = l1.next; }
            if (l2 != null) { sum += l2.val; l2 = l2.next; }
            carry = sum / 10;
            cur.next = new ListNode(sum % 10); cur = cur.next;
        }
        return dummy.next;
    }

    // LC19 - REMOVE NTH NODE FROM END
    /**
     * APPROACH: Two pointers — fast is n ahead of slow
     *   When fast reaches end, slow is at node before target
     * TIME: O(n)  SPACE: O(1)
     */
    static ListNode removeNthFromEnd(ListNode head, int n) {
        ListNode dummy = new ListNode(0); dummy.next = head;
        ListNode fast = dummy, slow = dummy;
        for (int i = 0; i <= n; i++) fast = fast.next;
        while (fast != null) { slow = slow.next; fast = fast.next; }
        slow.next = slow.next.next; // skip target
        return dummy.next;
    }

    // LC23 - MERGE K SORTED LISTS
    /**
     * APPROACH: Min-Heap — always extract the smallest current node
     * TIME: O(n log k)  SPACE: O(k)
     */
    static ListNode mergeKLists(ListNode[] lists) {
        PriorityQueue<ListNode> heap = new PriorityQueue<>(Comparator.comparingInt(n -> n.val));
        for (ListNode node : lists) if (node != null) heap.offer(node);
        ListNode dummy = new ListNode(0), cur = dummy;
        while (!heap.isEmpty()) {
            cur.next = heap.poll(); cur = cur.next;
            if (cur.next != null) heap.offer(cur.next);
        }
        return dummy.next;
    }

    // LC24 - SWAP NODES IN PAIRS
    /**
     * APPROACH: Pointer manipulation — swap adjacent pairs iteratively
     * TIME: O(n)  SPACE: O(1)
     * EXAMPLE: 1->2->3->4 → 2->1->4->3
     */
    static ListNode swapPairs(ListNode head) {
        ListNode dummy = new ListNode(0); dummy.next = head;
        ListNode prev = dummy;
        while (prev.next != null && prev.next.next != null) {
            ListNode a = prev.next, b = prev.next.next;
            prev.next = b; a.next = b.next; b.next = a;
            prev = a;
        }
        return dummy.next;
    }

    // LC25 - REVERSE NODES IN K-GROUP
    /**
     * APPROACH: Reverse k nodes at a time, recurse for rest
     * TIME: O(n)  SPACE: O(n/k) recursion
     */
    static ListNode reverseKGroup(ListNode head, int k) {
        ListNode cur = head; int count = 0;
        while (cur != null && count < k) { cur = cur.next; count++; }
        if (count < k) return head;
        ListNode prev = null; cur = head;
        for (int i = 0; i < k; i++) { ListNode next=cur.next; cur.next=prev; prev=cur; cur=next; }
        head.next = reverseKGroup(cur, k);
        return prev;
    }

    // LC61 - ROTATE LIST
    /**
     * APPROACH: Find tail, make circular, then break at right position
     * TIME: O(n)  SPACE: O(1)
     */
    static ListNode rotateRight(ListNode head, int k) {
        if (head == null || head.next == null) return head;
        int len = 1; ListNode tail = head;
        while (tail.next != null) { tail = tail.next; len++; }
        k %= len; if (k == 0) return head;
        tail.next = head; // make circular
        ListNode newTail = head;
        for (int i = 0; i < len - k - 1; i++) newTail = newTail.next;
        ListNode newHead = newTail.next; newTail.next = null;
        return newHead;
    }

    // LC92 - REVERSE LINKED LIST II (reverse between left and right)
    /**
     * APPROACH: Reach node before left, then reverse right-left+1 nodes
     * TIME: O(n)  SPACE: O(1)
     */
    static ListNode reverseBetween(ListNode head, int left, int right) {
        ListNode dummy = new ListNode(0); dummy.next = head;
        ListNode prev = dummy;
        for (int i = 1; i < left; i++) prev = prev.next;
        ListNode cur = prev.next, tail = cur, revPrev = null;
        for (int i = left; i <= right; i++) {
            ListNode next = cur.next; cur.next = revPrev; revPrev = cur; cur = next;
        }
        prev.next = revPrev; tail.next = cur;
        return dummy.next;
    }

    // LC141 - LINKED LIST CYCLE (Floyd's)
    /**
     * APPROACH: Fast/Slow pointers — if cycle exists they meet
     * TIME: O(n)  SPACE: O(1)
     */
    static boolean hasCycle(ListNode head) {
        ListNode slow = head, fast = head;
        while (fast != null && fast.next != null) {
            slow = slow.next; fast = fast.next.next;
            if (slow == fast) return true;
        }
        return false;
    }

    // LC142 - LINKED LIST CYCLE II (find cycle start)
    /**
     * APPROACH: Floyd's → after meeting, reset one to head → meet again at cycle start
     * TIME: O(n)  SPACE: O(1)
     */
    static ListNode detectCycle(ListNode head) {
        ListNode slow = head, fast = head;
        while (fast != null && fast.next != null) {
            slow = slow.next; fast = fast.next.next;
            if (slow == fast) {
                slow = head;
                while (slow != fast) { slow = slow.next; fast = fast.next; }
                return slow;
            }
        }
        return null;
    }

    // LC160 - INTERSECTION OF TWO LINKED LISTS
    /**
     * APPROACH: Two pointers — when one ends, redirect to other's head
     *   They meet at intersection after equal total distance
     * TIME: O(n+m)  SPACE: O(1)
     */
    static ListNode getIntersectionNode(ListNode headA, ListNode headB) {
        ListNode a = headA, b = headB;
        while (a != b) {
            a = (a == null) ? headB : a.next;
            b = (b == null) ? headA : b.next;
        }
        return a;
    }

    // LC234 - PALINDROME LINKED LIST
    /**
     * APPROACH: Find middle → reverse second half → compare
     * TIME: O(n)  SPACE: O(1)
     */
    static boolean isPalindrome(ListNode head) {
        ListNode slow = head, fast = head;
        while (fast != null && fast.next != null) { slow = slow.next; fast = fast.next.next; }
        ListNode prev = null, cur = slow;
        while (cur != null) { ListNode next=cur.next; cur.next=prev; prev=cur; cur=next; }
        ListNode left = head, right = prev;
        while (right != null) { if (left.val != right.val) return false; left=left.next; right=right.next; }
        return true;
    }

    // LC82 - REMOVE DUPLICATES II (remove ALL nodes with duplicate values)
    /**
     * APPROACH: Dummy node — skip all nodes with value equal to current duplicate
     * TIME: O(n)  SPACE: O(1)
     */
    static ListNode deleteDuplicatesII(ListNode head) {
        ListNode dummy = new ListNode(0); dummy.next = head;
        ListNode prev = dummy;
        while (prev.next != null) {
            if (prev.next.next != null && prev.next.val == prev.next.next.val) {
                int dupVal = prev.next.val;
                while (prev.next != null && prev.next.val == dupVal) prev.next = prev.next.next;
            } else prev = prev.next;
        }
        return dummy.next;
    }

    // GFG - MERGE SORT ON LINKED LIST
    static ListNode mergeSort(ListNode head) {
        if (head == null || head.next == null) return head;
        ListNode slow = head, fast = head.next;
        while (fast != null && fast.next != null) { slow = slow.next; fast = fast.next.next; }
        ListNode mid = slow.next; slow.next = null;
        ListNode left = mergeSort(head), right = mergeSort(mid);
        return mergeTwoLists(left, right);
    }

    // GFG - ADD 1 TO NUMBER REPRESENTED AS LINKED LIST
    /**
     * APPROACH: Reverse → add 1 → reverse back
     * EXAMPLE: 1->9->9 → 2->0->0
     */
    static ListNode addOne(ListNode head) {
        head = reverseList(head);
        ListNode cur = head; int carry = 1;
        while (cur != null && carry > 0) {
            int sum = cur.val + carry; cur.val = sum % 10; carry = sum / 10;
            if (cur.next == null && carry > 0) { cur.next = new ListNode(carry); carry = 0; }
            cur = cur.next;
        }
        return reverseList(head);
    }

    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║    LINKED LIST PROBLEMS - ALL SOLUTIONS  ║");
        System.out.println("╚══════════════════════════════════════════╝\n");

        System.out.println("LC206 reverseList([1,2,3,4,5])        = " + ListNode.str(reverseList(ListNode.of(1,2,3,4,5))));
        System.out.println("LC21  mergeTwoSorted                   = " + ListNode.str(mergeTwoLists(ListNode.of(1,2,4),ListNode.of(1,3,4))));
        System.out.println("LC2   addTwoNumbers(342+465)           = " + ListNode.str(addTwoNumbers(ListNode.of(2,4,3),ListNode.of(5,6,4))));
        System.out.println("LC19  removeNthFromEnd([1..5], n=2)    = " + ListNode.str(removeNthFromEnd(ListNode.of(1,2,3,4,5),2)));
        System.out.println("LC23  mergeKLists                      = " + ListNode.str(mergeKLists(new ListNode[]{ListNode.of(1,4,5),ListNode.of(1,3,4),ListNode.of(2,6)})));
        System.out.println("LC24  swapPairs([1,2,3,4])             = " + ListNode.str(swapPairs(ListNode.of(1,2,3,4))));
        System.out.println("LC25  reverseKGroup([1..6], k=2)       = " + ListNode.str(reverseKGroup(ListNode.of(1,2,3,4,5,6),2)));
        System.out.println("LC61  rotateRight([1..5], k=2)         = " + ListNode.str(rotateRight(ListNode.of(1,2,3,4,5),2)));
        System.out.println("LC92  reverseBetween([1..5], 2,4)      = " + ListNode.str(reverseBetween(ListNode.of(1,2,3,4,5),2,4)));

        ListNode cycleList = ListNode.of(1,2,3,4,5);
        ListNode node3 = cycleList.next.next; ListNode tail = cycleList;
        while(tail.next!=null) tail=tail.next; tail.next=node3;
        System.out.println("LC141 hasCycle(with cycle)             = " + hasCycle(cycleList));
        System.out.println("LC142 detectCycle(val)                 = " + detectCycle(cycleList).val);

        System.out.println("LC234 isPalindrome([1,2,2,1])          = " + isPalindrome(ListNode.of(1,2,2,1)));
        System.out.println("LC82  deleteDuplicatesII([1,2,3,3,4])  = " + ListNode.str(deleteDuplicatesII(ListNode.of(1,2,3,3,4,4,5))));
        System.out.println("GFG   mergeSort([4,2,1,3])             = " + ListNode.str(mergeSort(ListNode.of(4,2,1,3))));
        System.out.println("GFG   addOne([1,9,9])                  = " + ListNode.str(addOne(ListNode.of(1,9,9))));
    }
}
