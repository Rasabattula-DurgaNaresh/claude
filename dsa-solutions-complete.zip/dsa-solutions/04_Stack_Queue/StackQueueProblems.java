/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║       STACK & QUEUE - LeetCode & GeeksForGeeks Solutions     ║
 * ╚══════════════════════════════════════════════════════════════╝
 * LC20  Valid Parentheses
 * LC84  Largest Rectangle in Histogram
 * LC85  Maximal Rectangle (uses LC84)
 * LC150 Evaluate Reverse Polish Notation
 * LC155 Min Stack
 * LC225 Implement Stack using Queues
 * LC232 Implement Queue using Stacks
 * LC239 Sliding Window Maximum
 * LC316 Remove Duplicate Letters
 * LC394 Decode String
 * LC402 Remove K Digits
 * LC496 Next Greater Element I
 * LC739 Daily Temperatures
 * LC901 Online Stock Span
 * GFG   Get Minimum Element from Stack
 * GFG   Circular Tour (Petrol Pump)
 * GFG   Rotten Oranges (BFS)
 * GFG   Implement two stacks in an array
 */
import java.util.*;

public class StackQueueProblems {

    // LC155 - MIN STACK
    /**
     * APPROACH: Two stacks — main stack and sync min stack
     *   minStack always has current minimum at top
     * TIME: O(1) all ops  SPACE: O(n)
     */
    static class MinStack {
        Deque<Integer> stack = new ArrayDeque<>();
        Deque<Integer> minStack = new ArrayDeque<>();

        void push(int val) {
            stack.push(val);
            minStack.push(minStack.isEmpty() ? val : Math.min(val, minStack.peek()));
        }
        void pop()       { stack.pop(); minStack.pop(); }
        int top()        { return stack.peek(); }
        int getMin()     { return minStack.peek(); }
    }

    // LC232 - IMPLEMENT QUEUE USING STACKS
    /**
     * APPROACH: Two stacks — s1 (input), s2 (output)
     *   Push to s1. For pop/peek, if s2 empty, pour all s1 into s2
     * Amortized O(1) per operation
     */
    static class MyQueue {
        Deque<Integer> s1 = new ArrayDeque<>(), s2 = new ArrayDeque<>();

        void push(int x) { s1.push(x); }
        int pop()  { if (s2.isEmpty()) while (!s1.isEmpty()) s2.push(s1.pop()); return s2.pop(); }
        int peek() { if (s2.isEmpty()) while (!s1.isEmpty()) s2.push(s1.pop()); return s2.peek(); }
        boolean empty() { return s1.isEmpty() && s2.isEmpty(); }
    }

    // LC225 - IMPLEMENT STACK USING QUEUES
    /**
     * APPROACH: On push, add to queue then rotate all previous elements to back
     * TIME: O(n) push, O(1) pop/top
     */
    static class MyStack {
        Deque<Integer> q = new ArrayDeque<>();
        void push(int x) {
            q.offer(x);
            for (int i = 0; i < q.size() - 1; i++) q.offer(q.poll()); // rotate
        }
        int pop()        { return q.poll(); }
        int top()        { return q.peek(); }
        boolean empty()  { return q.isEmpty(); }
    }

    // LC84 - LARGEST RECTANGLE IN HISTOGRAM
    /**
     * APPROACH: Monotonic Stack
     *   Maintain increasing stack of indices
     *   When current bar is shorter than stack top → calculate area
     *   Width = i - stack[peek-1] - 1
     * TIME: O(n)  SPACE: O(n)
     * EXAMPLE: [2,1,5,6,2,3] → 10 (5*2 from indices 2,3)
     */
    static int largestRectangleArea(int[] heights) {
        int n = heights.length, maxArea = 0;
        Deque<Integer> stack = new ArrayDeque<>();
        for (int i = 0; i <= n; i++) {
            int curH = (i == n) ? 0 : heights[i];
            while (!stack.isEmpty() && heights[stack.peek()] > curH) {
                int h = heights[stack.pop()];
                int w = stack.isEmpty() ? i : i - stack.peek() - 1;
                maxArea = Math.max(maxArea, h * w);
            }
            stack.push(i);
        }
        return maxArea;
    }

    // LC85 - MAXIMAL RECTANGLE
    /**
     * APPROACH: Build histogram for each row, apply LC84 logic
     * TIME: O(m*n)  SPACE: O(n)
     */
    static int maximalRectangle(char[][] matrix) {
        if (matrix.length == 0) return 0;
        int maxArea = 0;
        int[] heights = new int[matrix[0].length];
        for (char[] row : matrix) {
            for (int j = 0; j < heights.length; j++)
                heights[j] = row[j] == '1' ? heights[j] + 1 : 0;
            maxArea = Math.max(maxArea, largestRectangleArea(heights));
        }
        return maxArea;
    }

    // LC150 - EVALUATE REVERSE POLISH NOTATION
    /**
     * APPROACH: Stack — push numbers, pop two on operator, push result
     * TIME: O(n)  SPACE: O(n)
     * EXAMPLE: ["2","1","+","3","*"] → 9
     */
    static int evalRPN(String[] tokens) {
        Deque<Integer> stack = new ArrayDeque<>();
        for (String token : tokens) {
            if ("+-*/".contains(token) && token.length() == 1) {
                int b = stack.pop(), a = stack.pop();
                switch (token) {
                    case "+" -> stack.push(a + b);
                    case "-" -> stack.push(a - b);
                    case "*" -> stack.push(a * b);
                    case "/" -> stack.push(a / b);
                }
            } else stack.push(Integer.parseInt(token));
        }
        return stack.pop();
    }

    // LC239 - SLIDING WINDOW MAXIMUM
    /**
     * APPROACH: Monotonic Deque (decreasing)
     *   Front = current window max (index)
     *   Remove from front if outside window
     *   Remove from back if smaller than current (useless)
     * TIME: O(n)  SPACE: O(k)
     */
    static int[] maxSlidingWindow(int[] nums, int k) {
        int n = nums.length;
        int[] result = new int[n - k + 1];
        Deque<Integer> dq = new ArrayDeque<>(); // stores indices
        for (int i = 0; i < n; i++) {
            if (!dq.isEmpty() && dq.peekFirst() < i - k + 1) dq.pollFirst(); // out of window
            while (!dq.isEmpty() && nums[dq.peekLast()] < nums[i]) dq.pollLast(); // smaller than current
            dq.offerLast(i);
            if (i >= k - 1) result[i - k + 1] = nums[dq.peekFirst()];
        }
        return result;
    }

    // LC496 - NEXT GREATER ELEMENT I
    /**
     * APPROACH: Monotonic stack on nums2, build map
     *   Process nums2 right to left with decreasing stack
     * TIME: O(m+n)  SPACE: O(m)
     */
    static int[] nextGreaterElement(int[] nums1, int[] nums2) {
        Map<Integer, Integer> nextGreater = new HashMap<>();
        Deque<Integer> stack = new ArrayDeque<>();
        for (int n : nums2) {
            while (!stack.isEmpty() && stack.peek() < n) nextGreater.put(stack.pop(), n);
            stack.push(n);
        }
        int[] result = new int[nums1.length];
        for (int i = 0; i < nums1.length; i++) result[i] = nextGreater.getOrDefault(nums1[i], -1);
        return result;
    }

    // LC739 - DAILY TEMPERATURES
    /**
     * APPROACH: Monotonic decreasing stack of indices
     *   When warmer day found, pop and record distance
     * TIME: O(n)  SPACE: O(n)
     */
    static int[] dailyTemperatures(int[] temps) {
        int n = temps.length;
        int[] result = new int[n];
        Deque<Integer> stack = new ArrayDeque<>();
        for (int i = 0; i < n; i++) {
            while (!stack.isEmpty() && temps[stack.peek()] < temps[i])
                result[stack.peek()] = i - stack.pop();
            stack.push(i);
        }
        return result;
    }

    // LC394 - DECODE STRING
    /**
     * APPROACH: Two stacks — one for counts, one for strings
     *   On '[': push current string and count to stacks
     *   On ']': pop and repeat current string, append to popped string
     * TIME: O(n)  SPACE: O(n)
     * EXAMPLE: "3[a2[c]]" → "accaccacc"
     */
    static String decodeString(String s) {
        Deque<Integer> countStack = new ArrayDeque<>();
        Deque<StringBuilder> strStack = new ArrayDeque<>();
        StringBuilder cur = new StringBuilder(); int count = 0;
        for (char c : s.toCharArray()) {
            if (Character.isDigit(c)) { count = count * 10 + (c - '0'); }
            else if (c == '[') { countStack.push(count); strStack.push(cur); cur = new StringBuilder(); count = 0; }
            else if (c == ']') {
                int k = countStack.pop(); StringBuilder prev = strStack.pop();
                String repeated = cur.toString().repeat(k);
                cur = prev.append(repeated);
            } else cur.append(c);
        }
        return cur.toString();
    }

    // LC402 - REMOVE K DIGITS (smallest resulting number)
    /**
     * APPROACH: Monotonic increasing stack
     *   If current digit < stack top, pop (remove larger digit from front)
     *   Remove leading zeros
     * TIME: O(n)  SPACE: O(n)
     * EXAMPLE: "1432219", k=3 → "1219"
     */
    static String removeKdigits(String num, int k) {
        Deque<Character> stack = new ArrayDeque<>();
        for (char c : num.toCharArray()) {
            while (k > 0 && !stack.isEmpty() && stack.peek() > c) { stack.pop(); k--; }
            stack.push(c);
        }
        while (k-- > 0) stack.pop(); // remove from end
        StringBuilder sb = new StringBuilder(); boolean leading = true;
        for (char c : stack) {
            if (leading && c == '0') continue;
            leading = false; sb.append(c);
        }
        return sb.length() == 0 ? "0" : sb.reverse().toString();
    }

    // LC316 - REMOVE DUPLICATE LETTERS (lexicographically smallest)
    /**
     * APPROACH: Greedy + monotonic stack
     *   Only remove if char appears later (can be added again)
     *   Pop stack if current < top AND top appears again
     * TIME: O(n)  SPACE: O(1)
     * EXAMPLE: "bcabc" → "abc"
     */
    static String removeDuplicateLetters(String s) {
        int[] count = new int[26]; boolean[] inStack = new boolean[26];
        for (char c : s.toCharArray()) count[c-'a']++;
        Deque<Character> stack = new ArrayDeque<>();
        for (char c : s.toCharArray()) {
            count[c-'a']--;
            if (inStack[c-'a']) continue;
            while (!stack.isEmpty() && stack.peek() > c && count[stack.peek()-'a'] > 0) {
                inStack[stack.pop()-'a'] = false;
            }
            stack.push(c); inStack[c-'a'] = true;
        }
        StringBuilder sb = new StringBuilder();
        for (char c : stack) sb.append(c);
        return sb.reverse().toString();
    }

    // LC901 - ONLINE STOCK SPAN
    /**
     * APPROACH: Monotonic stack storing (price, span) pairs
     *   Span = consecutive days with price <= current
     *   Merge spans when popping smaller prices
     * TIME: O(1) amortized
     */
    static class StockSpanner {
        Deque<int[]> stack = new ArrayDeque<>(); // [price, span]
        int next(int price) {
            int span = 1;
            while (!stack.isEmpty() && stack.peek()[0] <= price) span += stack.pop()[1];
            stack.push(new int[]{price, span});
            return span;
        }
    }

    // GFG - CIRCULAR TOUR (Petrol Pump)
    /**
     * APPROACH: Start from 0, track deficit
     *   If at any point fuel goes negative, start from next station
     *   If total fuel >= total cost, answer exists
     * TIME: O(n)  SPACE: O(1)
     */
    static int circularTour(int[] petrol, int[] distance) {
        int start = 0, currFuel = 0, deficit = 0;
        for (int i = 0; i < petrol.length; i++) {
            currFuel += petrol[i] - distance[i];
            if (currFuel < 0) { deficit += currFuel; start = i + 1; currFuel = 0; }
        }
        return (currFuel + deficit >= 0) ? start : -1;
    }

    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║   STACK & QUEUE PROBLEMS - ALL SOLUTIONS ║");
        System.out.println("╚══════════════════════════════════════════╝\n");

        MinStack ms = new MinStack(); ms.push(-2); ms.push(0); ms.push(-3);
        System.out.println("LC155 MinStack.getMin()               = " + ms.getMin());
        ms.pop(); System.out.println("      after pop, getMin()            = " + ms.getMin());

        MyQueue mq = new MyQueue(); mq.push(1); mq.push(2);
        System.out.println("LC232 Queue using Stacks peek         = " + mq.peek() + " pop=" + mq.pop());

        System.out.println("LC84  largestRectangle([2,1,5,6,2,3]) = " + largestRectangleArea(new int[]{2,1,5,6,2,3}));

        char[][] mat = {{'1','0','1','0','0'},{'1','0','1','1','1'},{'1','1','1','1','1'},{'1','0','0','1','0'}};
        System.out.println("LC85  maximalRectangle               = " + maximalRectangle(mat));

        System.out.println("LC150 evalRPN([2,1,+,3,*])           = " + evalRPN(new String[]{"2","1","+","3","*"}));
        System.out.println("LC239 maxSlidingWindow([1,3,-1,-3,5,3,6,7],k=3) = " + Arrays.toString(maxSlidingWindow(new int[]{1,3,-1,-3,5,3,6,7},3)));
        System.out.println("LC496 nextGreaterElement             = " + Arrays.toString(nextGreaterElement(new int[]{4,1,2},new int[]{1,3,4,2})));
        System.out.println("LC739 dailyTemperatures([73,74,75,71,69,72,76,73]) = " + Arrays.toString(dailyTemperatures(new int[]{73,74,75,71,69,72,76,73})));
        System.out.println("LC394 decodeString(3[a2[c]])         = " + decodeString("3[a2[c]]"));
        System.out.println("LC402 removeKdigits(1432219,k=3)     = " + removeKdigits("1432219",3));
        System.out.println("LC316 removeDuplicateLetters(bcabc)  = " + removeDuplicateLetters("bcabc"));

        StockSpanner ss = new StockSpanner();
        int[] spanPrices = {100,80,60,70,60,75,85};
        System.out.print("LC901 stockSpan                      = [");
        for (int p : spanPrices) System.out.print(ss.next(p) + " ");
        System.out.println("]");

        System.out.println("GFG  circularTour                    = " + circularTour(new int[]{4,6,7,4}, new int[]{6,5,3,5}));
    }
}
