/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║     BACKTRACKING - LeetCode & GeeksForGeeks Solutions        ║
 * ╚══════════════════════════════════════════════════════════════╝
 * LC17  Letter Combinations of Phone Number
 * LC22  Generate Parentheses
 * LC37  Sudoku Solver
 * LC39  Combination Sum
 * LC40  Combination Sum II
 * LC46  Permutations
 * LC47  Permutations II
 * LC51  N-Queens
 * LC52  N-Queens II
 * LC77  Combinations
 * LC78  Subsets
 * LC79  Word Search
 * LC90  Subsets II
 * LC93  Restore IP Addresses
 * LC131 Palindrome Partitioning
 * GFG   Rat in a Maze
 * GFG   M-Coloring Problem
 */
import java.util.*;

public class BacktrackingProblems {

    // LC51 - N-QUEENS
    /**
     * APPROACH: Place queen row by row, check conflicts using sets
     *   cols: occupied columns
     *   diag1 (row-col): top-left to bottom-right diagonals
     *   diag2 (row+col): top-right to bottom-left diagonals
     * TIME: O(n!)  SPACE: O(n)
     */
    static List<List<String>> solveNQueens(int n) {
        List<List<String>> result = new ArrayList<>();
        char[][] board = new char[n][n];
        for (char[] row : board) Arrays.fill(row, '.');
        solveNQ(board, 0, new HashSet<>(), new HashSet<>(), new HashSet<>(), result);
        return result;
    }
    static void solveNQ(char[][] board, int row, Set<Integer> cols, Set<Integer> d1, Set<Integer> d2, List<List<String>> result) {
        if (row == board.length) {
            List<String> sol = new ArrayList<>();
            for (char[] r : board) sol.add(new String(r));
            result.add(sol); return;
        }
        for (int col = 0; col < board.length; col++) {
            if (cols.contains(col) || d1.contains(row-col) || d2.contains(row+col)) continue;
            board[row][col]='Q'; cols.add(col); d1.add(row-col); d2.add(row+col);
            solveNQ(board, row+1, cols, d1, d2, result);
            board[row][col]='.'; cols.remove(col); d1.remove(row-col); d2.remove(row+col);
        }
    }

    // LC46 - PERMUTATIONS
    static List<List<Integer>> permute(int[] nums) {
        List<List<Integer>> result = new ArrayList<>();
        btPermute(nums, new boolean[nums.length], new ArrayList<>(), result);
        return result;
    }
    static void btPermute(int[] nums, boolean[] used, List<Integer> cur, List<List<Integer>> result) {
        if (cur.size()==nums.length) { result.add(new ArrayList<>(cur)); return; }
        for (int i=0; i<nums.length; i++) {
            if (used[i]) continue;
            used[i]=true; cur.add(nums[i]);
            btPermute(nums, used, cur, result);
            used[i]=false; cur.remove(cur.size()-1);
        }
    }

    // LC47 - PERMUTATIONS II (with duplicates)
    static List<List<Integer>> permuteUnique(int[] nums) {
        Arrays.sort(nums);
        List<List<Integer>> result = new ArrayList<>();
        btPermuteUnique(nums, new boolean[nums.length], new ArrayList<>(), result);
        return result;
    }
    static void btPermuteUnique(int[] nums, boolean[] used, List<Integer> cur, List<List<Integer>> result) {
        if (cur.size()==nums.length) { result.add(new ArrayList<>(cur)); return; }
        for (int i=0; i<nums.length; i++) {
            if (used[i]) continue;
            if (i>0 && nums[i]==nums[i-1] && !used[i-1]) continue; // skip dup
            used[i]=true; cur.add(nums[i]);
            btPermuteUnique(nums, used, cur, result);
            used[i]=false; cur.remove(cur.size()-1);
        }
    }

    // LC39 - COMBINATION SUM (can reuse)
    static List<List<Integer>> combinationSum(int[] candidates, int target) {
        Arrays.sort(candidates);
        List<List<Integer>> result = new ArrayList<>();
        btCombSum(candidates, 0, target, new ArrayList<>(), result);
        return result;
    }
    static void btCombSum(int[] c, int start, int rem, List<Integer> cur, List<List<Integer>> result) {
        if (rem==0) { result.add(new ArrayList<>(cur)); return; }
        for (int i=start; i<c.length && c[i]<=rem; i++) {
            cur.add(c[i]); btCombSum(c, i, rem-c[i], cur, result); cur.remove(cur.size()-1);
        }
    }

    // LC40 - COMBINATION SUM II (no reuse, with dups)
    static List<List<Integer>> combinationSum2(int[] candidates, int target) {
        Arrays.sort(candidates);
        List<List<Integer>> result = new ArrayList<>();
        btCombSum2(candidates, 0, target, new ArrayList<>(), result);
        return result;
    }
    static void btCombSum2(int[] c, int start, int rem, List<Integer> cur, List<List<Integer>> result) {
        if (rem==0) { result.add(new ArrayList<>(cur)); return; }
        for (int i=start; i<c.length && c[i]<=rem; i++) {
            if (i>start && c[i]==c[i-1]) continue; // skip dup
            cur.add(c[i]); btCombSum2(c, i+1, rem-c[i], cur, result); cur.remove(cur.size()-1);
        }
    }

    // LC78 - SUBSETS
    static List<List<Integer>> subsets(int[] nums) {
        List<List<Integer>> result = new ArrayList<>();
        result.add(new ArrayList<>());
        for (int num : nums) {
            int sz = result.size();
            for (int i=0; i<sz; i++) {
                List<Integer> sub = new ArrayList<>(result.get(i)); sub.add(num); result.add(sub);
            }
        }
        return result;
    }

    // LC90 - SUBSETS II (with duplicates)
    static List<List<Integer>> subsetsWithDup(int[] nums) {
        Arrays.sort(nums);
        List<List<Integer>> result = new ArrayList<>(); result.add(new ArrayList<>());
        int start=0, end=0;
        for (int i=0; i<nums.length; i++) {
            start = (i>0 && nums[i]==nums[i-1]) ? end : 0;
            end = result.size();
            for (int j=start; j<end; j++) {
                List<Integer> sub = new ArrayList<>(result.get(j)); sub.add(nums[i]); result.add(sub);
            }
        }
        return result;
    }

    // LC22 - GENERATE PARENTHESES
    static List<String> generateParenthesis(int n) {
        List<String> result = new ArrayList<>();
        btParens(n, 0, 0, new StringBuilder(), result);
        return result;
    }
    static void btParens(int n, int open, int close, StringBuilder cur, List<String> result) {
        if (cur.length()==2*n) { result.add(cur.toString()); return; }
        if (open<n)     { cur.append('('); btParens(n,open+1,close,cur,result); cur.deleteCharAt(cur.length()-1); }
        if (close<open) { cur.append(')'); btParens(n,open,close+1,cur,result); cur.deleteCharAt(cur.length()-1); }
    }

    // LC17 - LETTER COMBINATIONS
    static List<String> letterCombinations(String digits) {
        if (digits.isEmpty()) return new ArrayList<>();
        String[] map={"","","abc","def","ghi","jkl","mno","pqrs","tuv","wxyz"};
        List<String> result = new ArrayList<>();
        btPhone(digits, 0, map, new StringBuilder(), result);
        return result;
    }
    static void btPhone(String d, int idx, String[] map, StringBuilder cur, List<String> result) {
        if (idx==d.length()) { result.add(cur.toString()); return; }
        for (char c : map[d.charAt(idx)-'0'].toCharArray()) {
            cur.append(c); btPhone(d,idx+1,map,cur,result); cur.deleteCharAt(cur.length()-1);
        }
    }

    // LC79 - WORD SEARCH
    static boolean exist(char[][] board, String word) {
        int rows=board.length, cols=board[0].length;
        for (int r=0; r<rows; r++) for (int c=0; c<cols; c++)
            if (dfsWord(board,word,r,c,0,rows,cols)) return true;
        return false;
    }
    static boolean dfsWord(char[][] b, String w, int r, int c, int idx, int rows, int cols) {
        if (idx==w.length()) return true;
        if (r<0||r>=rows||c<0||c>=cols||b[r][c]!=w.charAt(idx)) return false;
        char tmp=b[r][c]; b[r][c]='#';
        boolean found=dfsWord(b,w,r+1,c,idx+1,rows,cols)||dfsWord(b,w,r-1,c,idx+1,rows,cols)
                    ||dfsWord(b,w,r,c+1,idx+1,rows,cols)||dfsWord(b,w,r,c-1,idx+1,rows,cols);
        b[r][c]=tmp; return found;
    }

    // LC131 - PALINDROME PARTITIONING
    static List<List<String>> partition(String s) {
        List<List<String>> result = new ArrayList<>();
        btPalin(s, 0, new ArrayList<>(), result);
        return result;
    }
    static void btPalin(String s, int start, List<String> path, List<List<String>> result) {
        if (start==s.length()) { result.add(new ArrayList<>(path)); return; }
        for (int end=start+1; end<=s.length(); end++) {
            String sub=s.substring(start,end);
            if (isPalin(sub)) { path.add(sub); btPalin(s,end,path,result); path.remove(path.size()-1); }
        }
    }
    static boolean isPalin(String s) {
        int l=0,r=s.length()-1; while(l<r) if(s.charAt(l++)!=s.charAt(r--)) return false; return true;
    }

    // LC37 - SUDOKU SOLVER
    static boolean solveSudoku(char[][] board) {
        for (int r=0; r<9; r++) for (int c=0; c<9; c++) {
            if (board[r][c]!='.') continue;
            for (char d='1'; d<='9'; d++) {
                if (isValidPlacement(board,r,c,d)) {
                    board[r][c]=d;
                    if (solveSudoku(board)) return true;
                    board[r][c]='.';
                }
            }
            return false;
        }
        return true;
    }
    static boolean isValidPlacement(char[][] b, int row, int col, char d) {
        for (int i=0; i<9; i++) {
            if (b[row][i]==d||b[i][col]==d||b[3*(row/3)+i/3][3*(col/3)+i%3]==d) return false;
        }
        return true;
    }

    // GFG - RAT IN A MAZE
    static List<String> findPath(int[][] mat) {
        List<String> result = new ArrayList<>();
        if (mat[0][0]==0) return result;
        boolean[][] visited = new boolean[mat.length][mat[0].length];
        dfsRat(mat, 0, 0, mat.length, visited, new StringBuilder(), result);
        return result;
    }
    static void dfsRat(int[][] mat, int r, int c, int n, boolean[][] visited, StringBuilder path, List<String> result) {
        if (r==n-1&&c==n-1) { result.add(path.toString()); return; }
        int[][] dirs={{1,0},{-1,0},{0,1},{0,-1}};
        char[] dirChars={'D','U','R','L'};
        for (int d=0; d<4; d++) {
            int nr=r+dirs[d][0], nc=c+dirs[d][1];
            if (nr>=0&&nr<n&&nc>=0&&nc<n&&!visited[nr][nc]&&mat[nr][nc]==1) {
                visited[r][c]=true; path.append(dirChars[d]);
                dfsRat(mat,nr,nc,n,visited,path,result);
                path.deleteCharAt(path.length()-1); visited[r][c]=false;
            }
        }
    }

    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║   BACKTRACKING PROBLEMS - ALL SOLUTIONS  ║");
        System.out.println("╚══════════════════════════════════════════╝\n");

        System.out.println("LC51  N-Queens(4): " + solveNQueens(4).size() + " solutions");
        solveNQueens(4).get(0).forEach(r -> System.out.println("   " + r));
        System.out.println("LC46  permute([1,2,3]).size            = " + permute(new int[]{1,2,3}).size());
        System.out.println("LC47  permuteUnique([1,1,2])           = " + permuteUnique(new int[]{1,1,2}));
        System.out.println("LC39  combinationSum([2,3,6,7], 7)     = " + combinationSum(new int[]{2,3,6,7},7));
        System.out.println("LC40  combinationSum2([10,1,2,7,6,1,5],8) = " + combinationSum2(new int[]{10,1,2,7,6,1,5},8));
        System.out.println("LC78  subsets([1,2,3])                 = " + subsets(new int[]{1,2,3}));
        System.out.println("LC90  subsetsWithDup([1,2,2])          = " + subsetsWithDup(new int[]{1,2,2}));
        System.out.println("LC22  generateParenthesis(3)           = " + generateParenthesis(3));
        System.out.println("LC17  letterCombinations(\"23\")        = " + letterCombinations("23"));
        char[][] wordBoard = {{'A','B','C','E'},{'S','F','C','S'},{'A','D','E','E'}};
        System.out.println("LC79  wordSearch(ABCCED)               = " + exist(wordBoard,"ABCCED"));
        System.out.println("LC131 palindromePartition(aab)         = " + partition("aab"));
        int[][] maze = {{1,0,0,0},{1,1,0,1},{1,1,0,0},{0,1,1,1}};
        System.out.println("GFG   ratInMaze                        = " + findPath(maze));
    }
}
