/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║       MATH & NUMBER THEORY - LeetCode & GFG Solutions        ║
 * ╚══════════════════════════════════════════════════════════════╝
 * LC7   Reverse Integer
 * LC9   Palindrome Number
 * LC12  Integer to Roman
 * LC13  Roman to Integer
 * LC43  Multiply Strings
 * LC50  Pow(x, n)
 * LC60  Permutation Sequence
 * LC66  Plus One
 * LC67  Add Binary
 * LC69  Sqrt(x)
 * LC149 Max Points on a Line
 * LC168 Excel Sheet Column Title
 * LC171 Excel Sheet Column Number
 * LC172 Factorial Trailing Zeroes
 * LC202 Happy Number
 * LC204 Count Primes (Sieve)
 * LC223 Rectangle Area
 * LC224 Basic Calculator
 * LC233 Number of Digit One
 * LC263 Ugly Number
 * LC264 Ugly Number II
 * LC279 Perfect Squares
 * LC292 Nim Game
 * LC319 Bulb Switcher
 * GFG   GCD and LCM
 * GFG   Modular Exponentiation
 * GFG   Catalan Numbers
 * GFG   Pascal's Triangle
 */
import java.util.*;

public class MathProblems {

    // GFG - GCD (Euclidean Algorithm)
    /**
     * APPROACH: gcd(a,b) = gcd(b, a%b) until b=0
     * TIME: O(log min(a,b))
     */
    static int gcd(int a, int b) { return b == 0 ? a : gcd(b, a%b); }
    static int lcm(int a, int b) { return a / gcd(a,b) * b; }

    // GFG - MODULAR EXPONENTIATION
    /**
     * APPROACH: Fast exponentiation with modulo
     *   base^exp % mod
     * TIME: O(log exp)  SPACE: O(1)
     */
    static long modPow(long base, long exp, long mod) {
        long result = 1; base %= mod;
        while (exp > 0) {
            if ((exp & 1) == 1) result = result * base % mod;
            exp >>= 1; base = base * base % mod;
        }
        return result;
    }

    // LC204 - COUNT PRIMES (Sieve of Eratosthenes)
    /**
     * APPROACH: Mark composites — for each prime p, mark p², p²+p, p²+2p...
     * TIME: O(n log log n)  SPACE: O(n)
     */
    static int countPrimes(int n) {
        boolean[] isComposite = new boolean[n];
        int count = 0;
        for (int i = 2; i < n; i++) {
            if (!isComposite[i]) {
                count++;
                for (long j = (long)i*i; j < n; j += i) isComposite[(int)j] = true;
            }
        }
        return count;
    }

    // LC7 - REVERSE INTEGER
    /**
     * APPROACH: Pop last digit, push to result, check overflow before each push
     * TIME: O(log n)
     */
    static int reverse(int x) {
        long result = 0;
        while (x != 0) { result = result * 10 + x % 10; x /= 10; }
        return (result > Integer.MAX_VALUE || result < Integer.MIN_VALUE) ? 0 : (int)result;
    }

    // LC9 - PALINDROME NUMBER
    /**
     * APPROACH: Reverse second half, compare with first half
     * TIME: O(log n)  SPACE: O(1)
     */
    static boolean isPalindrome(int x) {
        if (x < 0 || (x % 10 == 0 && x != 0)) return false;
        int rev = 0;
        while (x > rev) { rev = rev*10 + x%10; x /= 10; }
        return x == rev || x == rev/10; // odd length: ignore middle digit
    }

    // LC172 - FACTORIAL TRAILING ZEROES
    /**
     * APPROACH: Count factors of 5 (2s are always more abundant)
     *   n! trailing zeros = floor(n/5) + floor(n/25) + floor(n/125) + ...
     * TIME: O(log n)
     */
    static int trailingZeroes(int n) {
        int count = 0;
        while (n >= 5) { n /= 5; count += n; }
        return count;
    }

    // LC279 - PERFECT SQUARES
    /**
     * APPROACH: DP — dp[i] = min squares summing to i
     *   By Lagrange's four-square theorem, answer is always 1, 2, 3, or 4
     * TIME: O(n * sqrt(n))  SPACE: O(n)
     */
    static int numSquares(int n) {
        int[] dp = new int[n+1]; Arrays.fill(dp, n+1); dp[0] = 0;
        for (int i = 1; i <= n; i++)
            for (int j = 1; j*j <= i; j++) dp[i] = Math.min(dp[i], dp[i-j*j]+1);
        return dp[n];
    }

    // LC264 - UGLY NUMBER II (only prime factors 2, 3, 5)
    /**
     * APPROACH: 3-pointer DP
     *   Next ugly = min(dp[p2]*2, dp[p3]*3, dp[p5]*5)
     * TIME: O(n)  SPACE: O(n)
     */
    static int nthUglyNumber(int n) {
        int[] ugly = new int[n]; ugly[0] = 1;
        int p2 = 0, p3 = 0, p5 = 0;
        for (int i = 1; i < n; i++) {
            int next = Math.min(ugly[p2]*2, Math.min(ugly[p3]*3, ugly[p5]*5));
            ugly[i] = next;
            if (next == ugly[p2]*2) p2++;
            if (next == ugly[p3]*3) p3++;
            if (next == ugly[p5]*5) p5++;
        }
        return ugly[n-1];
    }

    // LC168 - EXCEL COLUMN TITLE
    /**
     * APPROACH: Base-26 but 1-indexed (A=1, not 0)
     *   n-- then take n%26 as index
     * TIME: O(log n)
     * EXAMPLE: 28 → "AB"
     */
    static String convertToTitle(int n) {
        StringBuilder sb = new StringBuilder();
        while (n > 0) {
            n--; sb.append((char)('A' + n%26)); n /= 26;
        }
        return sb.reverse().toString();
    }

    // LC171 - EXCEL COLUMN NUMBER
    static int titleToNumber(String columnTitle) {
        int result = 0;
        for (char c : columnTitle.toCharArray()) result = result*26 + (c - 'A' + 1);
        return result;
    }

    // LC43 - MULTIPLY STRINGS
    /**
     * APPROACH: Grade school multiplication using arrays
     *   num1[i] * num2[j] contributes to result[i+j] and result[i+j+1]
     * TIME: O(m*n)  SPACE: O(m+n)
     */
    static String multiply(String num1, String num2) {
        int m=num1.length(), n=num2.length();
        int[] pos = new int[m+n];
        for (int i=m-1;i>=0;i--) for (int j=n-1;j>=0;j--) {
            int mul=(num1.charAt(i)-'0')*(num2.charAt(j)-'0');
            int p1=i+j, p2=i+j+1, sum=mul+pos[p2];
            pos[p2]=sum%10; pos[p1]+=sum/10;
        }
        StringBuilder sb=new StringBuilder();
        for (int p:pos) if(!(sb.length()==0&&p==0)) sb.append(p);
        return sb.length()==0?"0":sb.toString();
    }

    // LC60 - PERMUTATION SEQUENCE (kth permutation of 1..n)
    /**
     * APPROACH: Factoradic number system
     *   Determine each digit by dividing k by (n-1)!
     * TIME: O(n²)  SPACE: O(n)
     */
    static String getPermutation(int n, int k) {
        List<Integer> nums=new ArrayList<>(); int[] fact=new int[n+1];
        fact[0]=1; for(int i=1;i<=n;i++){fact[i]=fact[i-1]*i;nums.add(i);}
        k--; StringBuilder sb=new StringBuilder();
        for (int i=n;i>=1;i--) {
            int idx=k/fact[i-1]; sb.append(nums.get(idx));
            nums.remove(idx); k%=fact[i-1];
        }
        return sb.toString();
    }

    // GFG - CATALAN NUMBERS
    /**
     * C(n) = C(0)*C(n-1) + C(1)*C(n-2) + ... + C(n-1)*C(0)
     * Applications: BSTs, polygon triangulations, balanced parentheses
     * TIME: O(n²)
     */
    static long catalan(int n) {
        long[] C = new long[n+1]; C[0] = C[1] = 1;
        for (int i=2;i<=n;i++) for (int j=0;j<i;j++) C[i]+=C[j]*C[i-j-1];
        return C[n];
    }

    // GFG - PASCAL'S TRIANGLE ROW
    static List<Integer> pascalRow(int n) {
        List<Integer> row = new ArrayList<>(); row.add(1);
        for (int i=1;i<=n;i++) row.add((int)((long)row.get(i-1)*(n-i+1)/i));
        return row;
    }

    // LC292 - NIM GAME
    /**
     * You win if n % 4 != 0 (opponent always loses if they face multiple of 4)
     */
    static boolean canWinNim(int n) { return n % 4 != 0; }

    // LC319 - BULB SWITCHER
    /**
     * After n rounds, only perfect square positions remain ON
     * (each has odd number of divisors = perfect square)
     */
    static int bulbSwitch(int n) { return (int)Math.sqrt(n); }

    // LC263 - UGLY NUMBER (factors only 2,3,5)
    static boolean isUgly(int n) {
        if (n<=0) return false;
        while (n%2==0) n/=2; while (n%3==0) n/=3; while (n%5==0) n/=5;
        return n==1;
    }

    // LC233 - NUMBER OF DIGIT ONE (count 1s in 1..n)
    /**
     * APPROACH: For each digit position, count how many 1s appear there
     * TIME: O(log n)
     */
    static int countDigitOne(int n) {
        int count=0; long factor=1;
        while (factor<=n) {
            long low=n%(factor*10), cur=(low/factor)%10, high=n/(factor*10);
            count+=high*factor;
            if (cur==1) count+=low%factor+1;
            else if (cur>1) count+=factor;
            factor*=10;
        }
        return count;
    }

    // LC66 - PLUS ONE
    static int[] plusOne(int[] digits) {
        for (int i=digits.length-1;i>=0;i--) {
            if (digits[i]<9){digits[i]++;return digits;}
            digits[i]=0;
        }
        int[] result=new int[digits.length+1]; result[0]=1;
        return result;
    }

    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║    MATH & NUMBER THEORY - ALL SOLUTIONS  ║");
        System.out.println("╚══════════════════════════════════════════╝\n");
        System.out.println("GFG   gcd(48,18)              = " + gcd(48,18));
        System.out.println("GFG   lcm(12,18)              = " + lcm(12,18));
        System.out.println("GFG   modPow(2,10,1000)       = " + modPow(2,10,1000));
        System.out.println("LC204 countPrimes(100)         = " + countPrimes(100));
        System.out.println("LC7   reverse(123)             = " + reverse(123));
        System.out.println("LC9   isPalindrome(121)        = " + isPalindrome(121));
        System.out.println("LC172 trailingZeroes(100)      = " + trailingZeroes(100));
        System.out.println("LC279 numSquares(12)           = " + numSquares(12));
        System.out.println("LC264 nthUglyNumber(10)        = " + nthUglyNumber(10));
        System.out.println("LC168 convertToTitle(28)       = " + convertToTitle(28));
        System.out.println("LC171 titleToNumber(AB)        = " + titleToNumber("AB"));
        System.out.println("LC43  multiply(123*456)        = " + multiply("123","456"));
        System.out.println("LC60  getPermutation(4,9)      = " + getPermutation(4,9));
        System.out.println("GFG   catalan(6)               = " + catalan(6));
        System.out.println("GFG   pascalRow(5)             = " + pascalRow(5));
        System.out.println("LC292 canWinNim(4)             = " + canWinNim(4));
        System.out.println("LC319 bulbSwitch(100)          = " + bulbSwitch(100));
        System.out.println("LC263 isUgly(14)               = " + isUgly(14));
        System.out.println("LC233 countDigitOne(13)        = " + countDigitOne(13));
        System.out.println("LC66  plusOne([1,2,9])         = " + Arrays.toString(plusOne(new int[]{1,2,9})));
    }
}
