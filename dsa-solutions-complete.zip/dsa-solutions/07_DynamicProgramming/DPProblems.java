/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║   DYNAMIC PROGRAMMING - LeetCode & GeeksForGeeks Solutions   ║
 * ╚══════════════════════════════════════════════════════════════╝
 * LC53   Maximum Subarray (Kadane's)
 * LC62   Unique Paths
 * LC63   Unique Paths II (with obstacles)
 * LC64   Minimum Path Sum
 * LC70   Climbing Stairs
 * LC72   Edit Distance
 * LC91   Decode Ways
 * LC96   Unique Binary Search Trees
 * LC115  Distinct Subsequences
 * LC120  Triangle (min path sum)
 * LC121  Best Time to Buy/Sell Stock
 * LC123  Best Time III (at most 2 transactions)
 * LC152  Maximum Product Subarray
 * LC198  House Robber
 * LC213  House Robber II (circular)
 * LC300  Longest Increasing Subsequence
 * LC309  Stock with Cooldown
 * LC322  Coin Change
 * LC338  Counting Bits
 * LC343  Integer Break
 * LC377  Combination Sum IV
 * LC416  Partition Equal Subset Sum
 * LC518  Coin Change II
 * LC647  Palindromic Substrings
 * LC674  Longest Continuous Increasing Subsequence
 * LC714  Stock with Transaction Fee
 * LC746  Min Cost Climbing Stairs
 * GFG    0-1 Knapsack
 * GFG    Longest Common Subsequence
 * GFG    Matrix Chain Multiplication
 */
import java.util.*;

public class DPProblems {

    // LC70 - CLIMBING STAIRS
    /**
     * APPROACH: dp[i] = dp[i-1] + dp[i-2] (Fibonacci pattern)
     *   Can take 1 or 2 steps; ways to reach i = ways from i-1 + ways from i-2
     * TIME: O(n)  SPACE: O(1)
     * EXAMPLE: n=3 → 3 ways: (1,1,1),(1,2),(2,1)
     */
    static int climbStairs(int n) {
        if (n <= 2) return n;
        int a = 1, b = 2;
        for (int i = 3; i <= n; i++) { int c = a + b; a = b; b = c; }
        return b;
    }

    // LC746 - MIN COST CLIMBING STAIRS
    /**
     * TIME: O(n)  SPACE: O(1)
     * EXAMPLE: cost=[10,15,20] → 15
     */
    static int minCostClimbingStairs(int[] cost) {
        int n = cost.length;
        int a = cost[0], b = cost[1];
        for (int i = 2; i < n; i++) { int c = cost[i] + Math.min(a,b); a = b; b = c; }
        return Math.min(a, b);
    }

    // LC198 - HOUSE ROBBER
    /**
     * APPROACH: dp[i] = max(dp[i-1], dp[i-2] + nums[i])
     * TIME: O(n)  SPACE: O(1)
     * EXAMPLE: [2,7,9,3,1] → 12
     */
    static int rob(int[] nums) {
        int prev = 0, curr = 0;
        for (int n : nums) { int tmp = Math.max(curr, prev + n); prev = curr; curr = tmp; }
        return curr;
    }

    // LC213 - HOUSE ROBBER II (circular)
    /**
     * APPROACH: Rob either first or last house (not both), take max
     */
    static int robII(int[] nums) {
        int n = nums.length;
        if (n == 1) return nums[0];
        return Math.max(robRange(nums, 0, n-2), robRange(nums, 1, n-1));
    }
    static int robRange(int[] nums, int l, int r) {
        int prev = 0, curr = 0;
        for (int i = l; i <= r; i++) { int tmp = Math.max(curr, prev+nums[i]); prev=curr; curr=tmp; }
        return curr;
    }

    // LC62 - UNIQUE PATHS
    /**
     * APPROACH: dp[i][j] = dp[i-1][j] + dp[i][j-1]
     *   Use 1D array: dp[j] += dp[j-1]
     * TIME: O(m*n)  SPACE: O(n)
     */
    static int uniquePaths(int m, int n) {
        int[] dp = new int[n]; Arrays.fill(dp, 1);
        for (int i = 1; i < m; i++) for (int j = 1; j < n; j++) dp[j] += dp[j-1];
        return dp[n-1];
    }

    // LC64 - MINIMUM PATH SUM
    static int minPathSum(int[][] grid) {
        int m = grid.length, n = grid[0].length;
        int[] dp = new int[n];
        dp[0] = grid[0][0];
        for (int j = 1; j < n; j++) dp[j] = dp[j-1] + grid[0][j];
        for (int i = 1; i < m; i++) {
            dp[0] += grid[i][0];
            for (int j = 1; j < n; j++) dp[j] = Math.min(dp[j], dp[j-1]) + grid[i][j];
        }
        return dp[n-1];
    }

    // LC300 - LONGEST INCREASING SUBSEQUENCE (O(n log n) patience sort)
    /**
     * APPROACH: Maintain tails array (smallest tail for each LIS length)
     *   Binary search for position to insert/replace
     * TIME: O(n log n)  SPACE: O(n)
     */
    static int lengthOfLIS(int[] nums) {
        int[] tails = new int[nums.length]; int size = 0;
        for (int n : nums) {
            int l = 0, r = size;
            while (l < r) { int m=(l+r)/2; if(tails[m]<n) l=m+1; else r=m; }
            tails[l] = n; if (l == size) size++;
        }
        return size;
    }

    // LC322 - COIN CHANGE
    /**
     * APPROACH: dp[i] = min coins to make amount i
     *   dp[i] = min(dp[i], dp[i-coin]+1) for each coin
     * TIME: O(n*m)  SPACE: O(n)
     */
    static int coinChange(int[] coins, int amount) {
        int[] dp = new int[amount+1]; Arrays.fill(dp, amount+1); dp[0]=0;
        for (int i = 1; i <= amount; i++)
            for (int coin : coins) if (coin<=i) dp[i]=Math.min(dp[i], dp[i-coin]+1);
        return dp[amount]>amount ? -1 : dp[amount];
    }

    // LC518 - COIN CHANGE II (count combinations)
    /**
     * APPROACH: For each coin, update dp forward (unbounded knapsack)
     * TIME: O(n*m)  SPACE: O(n)
     */
    static int change(int amount, int[] coins) {
        int[] dp = new int[amount+1]; dp[0]=1;
        for (int coin : coins) for (int j=coin; j<=amount; j++) dp[j]+=dp[j-coin];
        return dp[amount];
    }

    // LC416 - PARTITION EQUAL SUBSET SUM
    /**
     * APPROACH: 0/1 knapsack — can we fill exactly half the total?
     * TIME: O(n*sum)  SPACE: O(sum)
     */
    static boolean canPartition(int[] nums) {
        int total = 0; for (int n : nums) total += n;
        if (total%2 != 0) return false;
        int target = total/2;
        boolean[] dp = new boolean[target+1]; dp[0]=true;
        for (int n : nums) for (int j=target; j>=n; j--) dp[j]|=dp[j-n];
        return dp[target];
    }

    // LC72 - EDIT DISTANCE
    /**
     * APPROACH: dp[i][j] = min ops to convert word1[0..i] to word2[0..j]
     *   Same char: dp[i-1][j-1]
     *   Diff char: 1 + min(insert, delete, replace)
     * TIME: O(m*n)  SPACE: O(m*n)
     */
    static int minDistance(String word1, String word2) {
        int m=word1.length(), n=word2.length();
        int[][] dp = new int[m+1][n+1];
        for (int i=0;i<=m;i++) dp[i][0]=i;
        for (int j=0;j<=n;j++) dp[0][j]=j;
        for (int i=1;i<=m;i++) for (int j=1;j<=n;j++)
            dp[i][j] = word1.charAt(i-1)==word2.charAt(j-1)
                ? dp[i-1][j-1]
                : 1+Math.min(dp[i-1][j-1], Math.min(dp[i-1][j], dp[i][j-1]));
        return dp[m][n];
    }

    // LC91 - DECODE WAYS
    /**
     * APPROACH: dp[i] = ways to decode s[0..i-1]
     *   Single digit: dp[i] += dp[i-1] if valid
     *   Two digits:   dp[i] += dp[i-2] if valid (10-26)
     * TIME: O(n)  SPACE: O(n)
     */
    static int numDecodings(String s) {
        if (s.charAt(0)=='0') return 0;
        int n=s.length();
        int[] dp = new int[n+1]; dp[0]=1; dp[1]=1;
        for (int i=2;i<=n;i++) {
            int one=s.charAt(i-1)-'0';
            int two=Integer.parseInt(s.substring(i-2,i));
            if (one>=1) dp[i]+=dp[i-1];
            if (two>=10&&two<=26) dp[i]+=dp[i-2];
        }
        return dp[n];
    }

    // LC309 - BEST TIME TO BUY AND SELL STOCK WITH COOLDOWN
    /**
     * APPROACH: States: hold, sold (just sold), rest (cooldown or waiting)
     *   hold = max(hold, rest-price)
     *   sold = hold + price
     *   rest = max(rest, sold)
     * TIME: O(n)  SPACE: O(1)
     */
    static int maxProfitCooldown(int[] prices) {
        int hold=Integer.MIN_VALUE, sold=0, rest=0;
        for (int p : prices) {
            int prevSold=sold;
            sold=hold+p; hold=Math.max(hold, rest-p); rest=Math.max(rest, prevSold);
        }
        return Math.max(sold, rest);
    }

    // LC120 - TRIANGLE MINIMUM PATH SUM
    /**
     * APPROACH: Bottom-up DP — start from second-to-last row
     *   dp[j] = triangle[i][j] + min(dp[j], dp[j+1])
     * TIME: O(n²)  SPACE: O(n)
     */
    static int minimumTotal(List<List<Integer>> triangle) {
        int n=triangle.size();
        int[] dp=new int[n];
        for (int j=0;j<n;j++) dp[j]=triangle.get(n-1).get(j);
        for (int i=n-2;i>=0;i--)
            for (int j=0;j<=i;j++)
                dp[j]=triangle.get(i).get(j)+Math.min(dp[j], dp[j+1]);
        return dp[0];
    }

    // LC96 - UNIQUE BINARY SEARCH TREES (Catalan numbers)
    /**
     * APPROACH: G(n) = sum of G(i-1)*G(n-i) for i=1..n
     * TIME: O(n²)  SPACE: O(n)
     */
    static int numTrees(int n) {
        int[] dp = new int[n+1]; dp[0]=dp[1]=1;
        for (int i=2;i<=n;i++) for (int j=1;j<=i;j++) dp[i]+=dp[j-1]*dp[i-j];
        return dp[n];
    }

    // GFG - 0/1 KNAPSACK
    static int knapsack01(int[] weights, int[] values, int capacity) {
        int n=weights.length;
        int[] dp=new int[capacity+1];
        for (int i=0;i<n;i++) for (int w=capacity;w>=weights[i];w--)
            dp[w]=Math.max(dp[w], dp[w-weights[i]]+values[i]);
        return dp[capacity];
    }

    // GFG - LONGEST COMMON SUBSEQUENCE
    static int lcs(String s1, String s2) {
        int m=s1.length(), n=s2.length();
        int[][] dp=new int[m+1][n+1];
        for (int i=1;i<=m;i++) for (int j=1;j<=n;j++)
            dp[i][j]=s1.charAt(i-1)==s2.charAt(j-1)?dp[i-1][j-1]+1:Math.max(dp[i-1][j],dp[i][j-1]);
        return dp[m][n];
    }

    // LC338 - COUNTING BITS
    /**
     * APPROACH: dp[i] = dp[i>>1] + (i&1)
     *   i>>1 removes last bit; (i&1) is last bit value
     * TIME: O(n)  SPACE: O(n)
     */
    static int[] countBits(int n) {
        int[] dp=new int[n+1];
        for (int i=1;i<=n;i++) dp[i]=dp[i>>1]+(i&1);
        return dp;
    }

    // LC343 - INTEGER BREAK
    /**
     * APPROACH: dp[i] = max product breaking i into >= 2 parts
     *   Try all j from 2 to i: max(j*(i-j), j*dp[i-j])
     * TIME: O(n²)  SPACE: O(n)
     */
    static int integerBreak(int n) {
        int[] dp=new int[n+1]; dp[1]=1;
        for (int i=2;i<=n;i++) for (int j=1;j<i;j++)
            dp[i]=Math.max(dp[i], Math.max(j*(i-j), j*dp[i-j]));
        return dp[n];
    }

    // LC377 - COMBINATION SUM IV
    /**
     * APPROACH: dp[i] = number of combinations to reach i
     *   Order matters (permutation, not combination)
     * TIME: O(n*m)  SPACE: O(n)
     */
    static int combinationSum4(int[] nums, int target) {
        int[] dp=new int[target+1]; dp[0]=1;
        for (int i=1;i<=target;i++) for (int n:nums) if (n<=i) dp[i]+=dp[i-n];
        return dp[target];
    }

    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║   DYNAMIC PROGRAMMING - ALL SOLUTIONS    ║");
        System.out.println("╚══════════════════════════════════════════╝\n");

        System.out.println("LC70  climbStairs(10)                    = " + climbStairs(10));
        System.out.println("LC746 minCostClimbingStairs([10,15,20])  = " + minCostClimbingStairs(new int[]{10,15,20}));
        System.out.println("LC198 houseRobber([2,7,9,3,1])           = " + rob(new int[]{2,7,9,3,1}));
        System.out.println("LC213 houseRobberII([2,3,2])             = " + robII(new int[]{2,3,2}));
        System.out.println("LC62  uniquePaths(3,7)                   = " + uniquePaths(3,7));
        System.out.println("LC64  minPathSum                         = " + minPathSum(new int[][]{{1,3,1},{1,5,1},{4,2,1}}));
        System.out.println("LC300 LIS([10,9,2,5,3,7,101,18])         = " + lengthOfLIS(new int[]{10,9,2,5,3,7,101,18}));
        System.out.println("LC322 coinChange([1,5,10,25],41)         = " + coinChange(new int[]{1,5,10,25},41));
        System.out.println("LC518 coinChangeII([1,2,5],5)            = " + change(5,new int[]{1,2,5}));
        System.out.println("LC416 canPartition([1,5,11,5])           = " + canPartition(new int[]{1,5,11,5}));
        System.out.println("LC72  editDistance(horse,ros)            = " + minDistance("horse","ros"));
        System.out.println("LC91  numDecodings(\"226\")               = " + numDecodings("226"));
        System.out.println("LC309 maxProfitCooldown([1,2,3,0,2])     = " + maxProfitCooldown(new int[]{1,2,3,0,2}));
        System.out.println("LC96  numTrees(5)                        = " + numTrees(5));
        System.out.println("LC338 countBits(5)                       = " + Arrays.toString(countBits(5)));
        System.out.println("LC343 integerBreak(10)                   = " + integerBreak(10));
        System.out.println("LC377 combinationSum4([1,2,3],4)         = " + combinationSum4(new int[]{1,2,3},4));
        System.out.println("GFG   knapsack01                         = " + knapsack01(new int[]{1,3,4,5}, new int[]{1,4,5,7}, 7));
        System.out.println("GFG   lcs(ABCBDAB,BDCAB)                 = " + lcs("ABCBDAB","BDCAB"));
    }
}
