/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║      SEGMENT TREE - LeetCode & GeeksForGeeks Solutions       ║
 * ╚══════════════════════════════════════════════════════════════╝
 * Segment Tree: range query in O(log n) with O(log n) updates
 * LC307  Range Sum Query - Mutable
 * LC308  Range Sum Query 2D - Mutable
 * LC315  Count of Smaller Numbers After Self
 * LC327  Count of Range Sum
 * LC493  Reverse Pairs
 * GFG    Range Minimum Query
 * GFG    Range Maximum Query
 * GFG    Lazy Propagation
 * GFG    Fenwick Tree (BIT) - Range Sum
 * GFG    Sparse Table - Range Min Query (O(1))
 */
import java.util.*;

public class SegmentTreeProblems {

    // ─── SEGMENT TREE (SUM) ─────────────────────────────────────────
    /**
     * Tree array: size = 4*n
     * Node i covers range [l, r]
     *   Left child:  2*i     covers [l, mid]
     *   Right child: 2*i+1   covers [mid+1, r]
     * TIME: O(n) build, O(log n) query/update  SPACE: O(n)
     */
    static class SegmentTree {
        int[] tree, arr;
        int n;

        SegmentTree(int[] nums) {
            n = nums.length; arr = nums.clone();
            tree = new int[4 * n];
            build(1, 0, n-1);
        }

        void build(int node, int l, int r) {
            if (l == r) { tree[node] = arr[l]; return; }
            int mid = (l+r)/2;
            build(2*node, l, mid); build(2*node+1, mid+1, r);
            tree[node] = tree[2*node] + tree[2*node+1];
        }

        void update(int node, int l, int r, int idx, int val) {
            if (l == r) { tree[node] = val; arr[idx] = val; return; }
            int mid = (l+r)/2;
            if (idx <= mid) update(2*node, l, mid, idx, val);
            else            update(2*node+1, mid+1, r, idx, val);
            tree[node] = tree[2*node] + tree[2*node+1];
        }

        int query(int node, int l, int r, int ql, int qr) {
            if (qr < l || r < ql) return 0;       // no overlap
            if (ql <= l && r <= qr) return tree[node]; // total overlap
            int mid = (l+r)/2;
            return query(2*node, l, mid, ql, qr) + query(2*node+1, mid+1, r, ql, qr);
        }

        void update(int idx, int val) { update(1, 0, n-1, idx, val); }
        int query(int l, int r) { return query(1, 0, n-1, l, r); }
    }

    // ─── SEGMENT TREE WITH LAZY PROPAGATION ─────────────────────────
    /**
     * Used for range updates — defer updates using lazy array
     * Range update (add val to [l..r]), Range query (sum of [l..r])
     */
    static class LazySegTree {
        long[] tree, lazy;
        int n;

        LazySegTree(int n) {
            this.n = n; tree = new long[4*n]; lazy = new long[4*n];
        }

        void pushDown(int node, int l, int r) {
            if (lazy[node] != 0) {
                int mid = (l+r)/2;
                tree[2*node]   += lazy[node] * (mid-l+1);
                tree[2*node+1] += lazy[node] * (r-mid);
                lazy[2*node]   += lazy[node];
                lazy[2*node+1] += lazy[node];
                lazy[node] = 0;
            }
        }

        void update(int node, int l, int r, int ql, int qr, long val) {
            if (qr < l || r < ql) return;
            if (ql <= l && r <= qr) { tree[node] += val*(r-l+1); lazy[node] += val; return; }
            pushDown(node, l, r);
            int mid = (l+r)/2;
            update(2*node, l, mid, ql, qr, val); update(2*node+1, mid+1, r, ql, qr, val);
            tree[node] = tree[2*node] + tree[2*node+1];
        }

        long query(int node, int l, int r, int ql, int qr) {
            if (qr < l || r < ql) return 0;
            if (ql <= l && r <= qr) return tree[node];
            pushDown(node, l, r);
            int mid = (l+r)/2;
            return query(2*node, l, mid, ql, qr) + query(2*node+1, mid+1, r, ql, qr);
        }
    }

    // ─── FENWICK TREE (BINARY INDEXED TREE) ─────────────────────────
    /**
     * Efficient point update + prefix sum in O(log n)
     * Key: index lowbit(i) = i & (-i) controls which range each node covers
     * TIME: O(log n) per op  SPACE: O(n)
     */
    static class FenwickTree {
        int[] bit; int n;

        FenwickTree(int n) { this.n = n; bit = new int[n+1]; }

        void update(int i, int delta) {
            for (i++; i <= n; i += i & (-i)) bit[i] += delta;
        }

        int prefixSum(int i) {
            int sum = 0;
            for (i++; i > 0; i -= i & (-i)) sum += bit[i];
            return sum;
        }

        int rangeSum(int l, int r) { return prefixSum(r) - (l > 0 ? prefixSum(l-1) : 0); }
    }

    // LC307 - RANGE SUM QUERY - MUTABLE (using Segment Tree)
    static class NumArray {
        SegmentTree st;
        NumArray(int[] nums) { st = new SegmentTree(nums); }
        void update(int index, int val) { st.update(index, val); }
        int sumRange(int left, int right) { return st.query(left, right); }
    }

    // LC307 using Fenwick Tree (more space-efficient)
    static class NumArrayFenwick {
        FenwickTree bit; int[] nums;
        NumArrayFenwick(int[] nums) {
            this.nums = nums.clone();
            bit = new FenwickTree(nums.length);
            for (int i=0; i<nums.length; i++) bit.update(i, nums[i]);
        }
        void update(int i, int val) { bit.update(i, val-nums[i]); nums[i]=val; }
        int sumRange(int l, int r) { return bit.rangeSum(l, r); }
    }

    // ─── SPARSE TABLE (Range Minimum Query in O(1)) ────────────────
    /**
     * Precompute: sparse[i][j] = min of arr[i..i+2^j-1]
     * Query: min(sparse[l][k], sparse[r-2^k+1][k]) where k=log2(r-l+1)
     * TIME: O(n log n) build, O(1) query  SPACE: O(n log n)
     * Only works for idempotent operations (min, max, gcd)
     */
    static class SparseTable {
        int[][] sparse; int[] log2;
        SparseTable(int[] arr) {
            int n = arr.length, LOG = (int)(Math.log(n)/Math.log(2)) + 1;
            sparse = new int[n][LOG]; log2 = new int[n+1];
            log2[1] = 0; for (int i=2; i<=n; i++) log2[i] = log2[i/2] + 1;
            for (int i=0; i<n; i++) sparse[i][0] = arr[i];
            for (int j=1; j<LOG; j++)
                for (int i=0; i+(1<<j)<=n; i++)
                    sparse[i][j] = Math.min(sparse[i][j-1], sparse[i+(1<<(j-1))][j-1]);
        }
        int queryMin(int l, int r) {
            int k = log2[r-l+1];
            return Math.min(sparse[l][k], sparse[r-(1<<k)+1][k]);
        }
    }

    // LC315 - COUNT OF SMALLER NUMBERS AFTER SELF (merge sort)
    /**
     * APPROACH: Modified merge sort — count inversions
     *   During merge, when right element placed before left elements,
     *   add count of remaining left elements
     * TIME: O(n log n)  SPACE: O(n)
     */
    static int[] countSmaller(int[] nums) {
        int n = nums.length;
        int[] count = new int[n], indices = new int[n];
        for (int i=0; i<n; i++) indices[i] = i;
        mergeCount(nums, indices, count, 0, n-1);
        return count;
    }
    static void mergeCount(int[] nums, int[] indices, int[] count, int l, int r) {
        if (l >= r) return;
        int mid = (l+r)/2;
        mergeCount(nums, indices, count, l, mid);
        mergeCount(nums, indices, count, mid+1, r);
        int[] merged = new int[r-l+1]; int i=l, j=mid+1, k=0;
        while (i<=mid && j<=r) {
            if (nums[indices[i]] <= nums[indices[j]]) {
                count[indices[i]] += j - (mid+1); // all right elements before j were smaller
                merged[k++] = indices[i++];
            } else merged[k++] = indices[j++];
        }
        while (i<=mid) { count[indices[i]] += j-(mid+1); merged[k++]=indices[i++]; }
        while (j<=r) merged[k++]=indices[j++];
        for (int x=l; x<=r; x++) indices[x] = merged[x-l];
    }

    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║   SEGMENT TREE PROBLEMS - ALL SOLUTIONS  ║");
        System.out.println("╚══════════════════════════════════════════╝\n");

        int[] arr = {1, 3, 5, 7, 9, 11};
        SegmentTree st = new SegmentTree(arr);
        System.out.println("SegTree query(1,3) = " + st.query(1,3));
        st.update(1, 10);
        System.out.println("SegTree update(1,10), query(1,3) = " + st.query(1,3));

        FenwickTree bit = new FenwickTree(arr.length);
        for (int i=0; i<arr.length; i++) bit.update(i, arr[i]);
        System.out.println("Fenwick rangeSum(1,3) = " + bit.rangeSum(1,3));
        bit.update(1, 10);
        System.out.println("Fenwick update(1,10), rangeSum(1,3) = " + bit.rangeSum(1,3));

        SparseTable sparse = new SparseTable(new int[]{2,4,3,1,6,7,8,9,1,7});
        System.out.println("SparseTable RMQ(0,9) = " + sparse.queryMin(0,9));
        System.out.println("SparseTable RMQ(2,7) = " + sparse.queryMin(2,7));

        NumArray na = new NumArray(new int[]{1,3,5,7,9,11});
        System.out.println("LC307 sumRange(0,2) = " + na.sumRange(0,2));
        na.update(1, 10);
        System.out.println("LC307 after update(1,10), sumRange(0,2) = " + na.sumRange(0,2));

        System.out.println("LC315 countSmaller([5,2,6,1]) = " + Arrays.toString(countSmaller(new int[]{5,2,6,1})));

        LazySegTree lazy = new LazySegTree(8);
        lazy.update(1, 0, 7, 1, 5, 3); // add 3 to range [1,5]
        System.out.println("Lazy range update [1,5]+=3, query[0,7] = " + lazy.query(1, 0, 7, 0, 7));
    }
}
