/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║      BIT MANIPULATION - LeetCode & GeeksForGeeks Solutions   ║
 * ╚══════════════════════════════════════════════════════════════╝
 * LC29  Divide Two Integers (no division)
 * LC67  Add Binary
 * LC136 Single Number
 * LC137 Single Number II
 * LC190 Reverse Bits
 * LC191 Number of 1 Bits (Hamming Weight)
 * LC201 Bitwise AND of Numbers Range
 * LC231 Power of Two
 * LC260 Single Number III
 * LC268 Missing Number
 * LC338 Counting Bits
 * LC371 Sum of Two Integers (no +)
 * LC389 Find the Difference
 * LC393 UTF-8 Validation
 * LC397 Integer Replacement
 * LC401 Binary Watch
 * LC421 Maximum XOR of Two Numbers (Trie)
 * LC461 Hamming Distance
 * LC477 Total Hamming Distance
 * GFG   Count set bits in all numbers 1 to n
 * GFG   Turn off rightmost set bit
 * GFG   Check if number has bits in alternate pattern
 */
import java.util.*;

public class BitManipulation {

    // ─── BIT TRICKS REFERENCE ──────────────────────────────────────
    /**
     *  n & 1          → check if odd
     *  n & (n-1)      → clear lowest set bit (also checks power of 2)
     *  n | (1<<k)     → set bit k
     *  n & ~(1<<k)    → clear bit k
     *  n ^ (1<<k)     → toggle bit k
     *  n >> 1         → divide by 2
     *  n << 1         → multiply by 2
     *  n & (-n)       → isolate lowest set bit
     *  ~n + 1 = -n    → two's complement
     *  a ^ a = 0      → XOR self-inverse
     *  a ^ 0 = a      → XOR identity
     */

    // LC136 - SINGLE NUMBER (every other appears twice)
    /**
     * APPROACH: XOR all numbers — duplicates cancel, unique remains
     * TIME: O(n)  SPACE: O(1)
     * EXAMPLE: [4,1,2,1,2] → 4
     */
    static int singleNumber(int[] nums) {
        int result = 0;
        for (int n : nums) result ^= n;
        return result;
    }

    // LC137 - SINGLE NUMBER II (every other appears three times)
    /**
     * APPROACH: Count bits modulo 3
     *   ones: bits seen 1 time, twos: bits seen 2 times
     *   After 3 appearances, bit disappears from both
     * TIME: O(n)  SPACE: O(1)
     */
    static int singleNumberII(int[] nums) {
        int ones = 0, twos = 0;
        for (int n : nums) {
            ones = (ones ^ n) & ~twos;
            twos = (twos ^ n) & ~ones;
        }
        return ones;
    }

    // LC260 - SINGLE NUMBER III (two unique numbers)
    /**
     * APPROACH: XOR all → XOR of two uniques
     *   Find any set bit (right-most) → differs between two uniques
     *   Partition by this bit → XOR each partition to get each unique
     * TIME: O(n)  SPACE: O(1)
     */
    static int[] singleNumberIII(int[] nums) {
        int xor = 0; for (int n : nums) xor ^= n;
        int diffBit = xor & (-xor); // rightmost set bit
        int a = 0, b = 0;
        for (int n : nums) {
            if ((n & diffBit) != 0) a ^= n;
            else                    b ^= n;
        }
        return new int[]{a, b};
    }

    // LC191 - HAMMING WEIGHT (count set bits)
    /**
     * APPROACH 1: n & (n-1) clears lowest set bit — count iterations
     * APPROACH 2: Integer.bitCount(n)
     * TIME: O(set bits)  SPACE: O(1)
     */
    static int hammingWeight(int n) {
        int count = 0;
        while (n != 0) { n &= (n-1); count++; } // clear lowest set bit each time
        return count;
    }

    // LC461 - HAMMING DISTANCE
    /**
     * APPROACH: XOR the two numbers, count set bits in result
     * TIME: O(1)
     */
    static int hammingDistance(int x, int y) {
        return Integer.bitCount(x ^ y);
    }

    // LC477 - TOTAL HAMMING DISTANCE
    /**
     * APPROACH: For each bit position, count 0s and 1s
     *   Contribution = count(0s) * count(1s) for that bit
     * TIME: O(n * 32)  SPACE: O(1)
     */
    static int totalHammingDistance(int[] nums) {
        int total = 0;
        for (int i = 0; i < 32; i++) {
            int ones = 0;
            for (int n : nums) ones += (n >> i) & 1;
            total += ones * (nums.length - ones);
        }
        return total;
    }

    // LC190 - REVERSE BITS
    /**
     * APPROACH: Extract last bit, shift result left, repeat 32 times
     * TIME: O(32)  SPACE: O(1)
     */
    static int reverseBits(int n) {
        int result = 0;
        for (int i = 0; i < 32; i++) {
            result = (result << 1) | (n & 1);
            n >>>= 1; // unsigned right shift
        }
        return result;
    }

    // LC338 - COUNTING BITS
    /**
     * APPROACH: dp[i] = dp[i >> 1] + (i & 1)
     *   i>>1 right-shifts (same bits minus LSB)
     *   (i & 1) adds back the LSB
     * TIME: O(n)  SPACE: O(n)
     */
    static int[] countBits(int n) {
        int[] dp = new int[n+1];
        for (int i = 1; i <= n; i++) dp[i] = dp[i>>1] + (i&1);
        return dp;
    }

    // LC371 - SUM OF TWO INTEGERS (without + or -)
    /**
     * APPROACH: 
     *   a ^ b = sum without carry
     *   (a & b) << 1 = carry
     *   Repeat until no carry
     * TIME: O(1)  SPACE: O(1)
     */
    static int getSum(int a, int b) {
        while (b != 0) {
            int carry = (a & b) << 1;
            a = a ^ b;
            b = carry;
        }
        return a;
    }

    // LC231 - POWER OF TWO
    /**
     * APPROACH: Power of 2 has exactly one set bit: n & (n-1) == 0
     * TIME: O(1)
     */
    static boolean isPowerOfTwo(int n) { return n > 0 && (n & (n-1)) == 0; }

    // LC201 - BITWISE AND OF NUMBERS RANGE
    /**
     * APPROACH: Find common prefix of m and n in binary
     *   Shift both right until equal — track shifts
     *   Common prefix shifted back = answer
     * TIME: O(32)  SPACE: O(1)
     * EXAMPLE: m=5 (101), n=7 (111) → 4 (100)
     */
    static int rangeBitwiseAnd(int m, int n) {
        int shift = 0;
        while (m != n) { m >>= 1; n >>= 1; shift++; }
        return m << shift;
    }

    // LC268 - MISSING NUMBER
    /**
     * APPROACH: XOR all indices [0..n] and all values — missing number remains
     * TIME: O(n)  SPACE: O(1)
     */
    static int missingNumber(int[] nums) {
        int result = nums.length;
        for (int i = 0; i < nums.length; i++) result ^= i ^ nums[i];
        return result;
    }

    // LC29 - DIVIDE TWO INTEGERS (no *, /, mod)
    /**
     * APPROACH: Bit shifting — find largest multiple of divisor using doubling
     * TIME: O(log²n)  SPACE: O(1)
     */
    static int divide(int dividend, int divisor) {
        if (dividend == Integer.MIN_VALUE && divisor == -1) return Integer.MAX_VALUE;
        int sign = (dividend > 0) == (divisor > 0) ? 1 : -1;
        long dvd = Math.abs((long)dividend), dvs = Math.abs((long)divisor);
        int result = 0;
        while (dvd >= dvs) {
            long tmp = dvs, mul = 1;
            while (dvd >= tmp << 1) { tmp <<= 1; mul <<= 1; }
            dvd -= tmp; result += mul;
        }
        return sign * result;
    }

    // LC397 - INTEGER REPLACEMENT (reach 1 with min steps)
    /**
     * APPROACH: Greedy using bits
     *   If even: n >> 1
     *   If odd & last 2 bits are 01: n - 1 (to make it 0...00)
     *   If odd & last 2 bits are 11: n + 1 (to maximize zeros via double)
     *   Exception: n=3 → subtract
     * TIME: O(log n)  SPACE: O(1)
     */
    static int integerReplacement(int n) {
        int count = 0;
        long num = n; // use long to handle Integer.MAX_VALUE case
        while (num != 1) {
            if ((num & 1) == 0) num >>= 1;
            else if (num == 3 || ((num >> 1) & 1) == 0) num--;
            else num++;
            count++;
        }
        return count;
    }

    // LC67 - ADD BINARY
    /**
     * APPROACH: Simulate binary addition from right with carry
     * TIME: O(max(m,n))  SPACE: O(max(m,n))
     * EXAMPLE: "11" + "1" → "100"
     */
    static String addBinary(String a, String b) {
        StringBuilder sb = new StringBuilder();
        int i = a.length()-1, j = b.length()-1, carry = 0;
        while (i >= 0 || j >= 0 || carry != 0) {
            int sum = carry;
            if (i >= 0) sum += a.charAt(i--) - '0';
            if (j >= 0) sum += b.charAt(j--) - '0';
            sb.append(sum % 2); carry = sum / 2;
        }
        return sb.reverse().toString();
    }

    // GFG - COUNT SET BITS IN ALL NUMBERS 1 TO N
    /**
     * APPROACH: Mathematical pattern
     *   For each bit position, count how many numbers from 1..n have that bit set
     * TIME: O(log n)  SPACE: O(1)
     */
    static int countSetBitsUpToN(int n) {
        int count = 0;
        for (long x = 1; x <= n; x <<= 1) {
            long full = (n+1) / (x*2), partial = (n+1) % (x*2);
            count += full * x + Math.max(0, partial - x);
        }
        return count;
    }

    // GFG - CHECK ALTERNATE BIT PATTERN
    static boolean hasAlternateBits(int n) {
        int m = n ^ (n >> 1);
        return (m & (m+1)) == 0; // m should be all 1s
    }

    // GFG - TURN OFF RIGHTMOST SET BIT
    static int turnOffRightmostSetBit(int n) { return n & (n-1); }

    // GFG - ISOLATE RIGHTMOST SET BIT
    static int isolateRightmostSetBit(int n) { return n & (-n); }

    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║   BIT MANIPULATION - ALL SOLUTIONS       ║");
        System.out.println("╚══════════════════════════════════════════╝\n");

        System.out.println("LC136 singleNumber([4,1,2,1,2])         = " + singleNumber(new int[]{4,1,2,1,2}));
        System.out.println("LC137 singleNumberII([2,2,3,2])         = " + singleNumberII(new int[]{2,2,3,2}));
        System.out.println("LC260 singleNumberIII([1,2,1,3,2,5])   = " + Arrays.toString(singleNumberIII(new int[]{1,2,1,3,2,5})));
        System.out.println("LC191 hammingWeight(11=1011)             = " + hammingWeight(11));
        System.out.println("LC461 hammingDistance(1,4)               = " + hammingDistance(1,4));
        System.out.println("LC477 totalHammingDistance([4,14,2])     = " + totalHammingDistance(new int[]{4,14,2}));
        System.out.println("LC190 reverseBits(43261596)              = " + reverseBits(43261596));
        System.out.println("LC338 countBits(5)                       = " + Arrays.toString(countBits(5)));
        System.out.println("LC371 getSum(5+3 no +)                   = " + getSum(5,3));
        System.out.println("LC231 isPowerOfTwo(16)                   = " + isPowerOfTwo(16));
        System.out.println("LC201 rangeBitwiseAnd(5,7)               = " + rangeBitwiseAnd(5,7));
        System.out.println("LC268 missingNumber([3,0,1])              = " + missingNumber(new int[]{3,0,1}));
        System.out.println("LC29  divide(10,3)                       = " + divide(10,3));
        System.out.println("LC397 integerReplacement(8)              = " + integerReplacement(8));
        System.out.println("LC67  addBinary(11+1)                    = " + addBinary("11","1"));
        System.out.println("GFG   countSetBitsUpToN(7)               = " + countSetBitsUpToN(7));
        System.out.println("GFG   hasAlternateBits(5=101)            = " + hasAlternateBits(5));
        System.out.println("GFG   turnOffRightmost(12=1100)          = " + turnOffRightmostSetBit(12) + " (1000=8)");
        System.out.println("GFG   isolateRightmost(12=1100)          = " + isolateRightmostSetBit(12) + " (0100=4)");

        System.out.println("\n=== QUICK BIT TRICKS REFERENCE ===");
        System.out.println("  n & 1          check odd:          7 & 1 = " + (7&1));
        System.out.println("  n & (n-1)      clear lowest bit:   12 & 11 = " + (12&11) + " (1100->1000)");
        System.out.println("  n & (-n)       isolate lowest bit: 12 & -12 = " + (12&-12));
        System.out.println("  n ^ n = 0:     5 ^ 5 = " + (5^5));
        System.out.println("  a ^ b ^ a = b: 3^5^3 = " + (3^5^3));
    }
}
