/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║          HASHING - LeetCode & GeeksForGeeks Solutions        ║
 * ╚══════════════════════════════════════════════════════════════╝
 * LC1   Two Sum
 * LC36  Valid Sudoku
 * LC49  Group Anagrams
 * LC128 Longest Consecutive Sequence
 * LC149 Max Points on a Line
 * LC166 Fraction to Recurring Decimal
 * LC187 Repeated DNA Sequences
 * LC202 Happy Number
 * LC204 Count Primes (Sieve)
 * LC205 Isomorphic Strings
 * LC217 Contains Duplicate
 * LC219 Contains Duplicate II
 * LC242 Valid Anagram
 * LC290 Word Pattern
 * LC299 Bulls and Cows
 * LC340 Longest Substr with K Distinct Chars
 * LC349 Intersection of Two Arrays
 * LC350 Intersection of Two Arrays II
 * LC380 Insert Delete GetRandom O(1)
 * LC454 4Sum II
 * LC560 Subarray Sum Equals K
 * GFG   Count Distinct Elements in Window
 * GFG   First Non-Repeating Character in Stream
 */
import java.util.*;

public class HashingProblems {

    // LC217 - CONTAINS DUPLICATE
    static boolean containsDuplicate(int[] nums) {
        Set<Integer> seen=new HashSet<>();
        for (int n:nums) if(!seen.add(n)) return true;
        return false;
    }

    // LC219 - CONTAINS DUPLICATE II (within k distance)
    static boolean containsNearbyDuplicate(int[] nums, int k) {
        Map<Integer,Integer> map=new HashMap<>();
        for (int i=0;i<nums.length;i++) {
            if (map.containsKey(nums[i])&&i-map.get(nums[i])<=k) return true;
            map.put(nums[i],i);
        }
        return false;
    }

    // LC36 - VALID SUDOKU
    /**
     * APPROACH: Three sets of 9 sets each — rows, cols, boxes
     * TIME: O(1) (fixed 81 cells)
     */
    static boolean isValidSudoku(char[][] board) {
        Set<String> seen=new HashSet<>();
        for (int r=0;r<9;r++) for (int c=0;c<9;c++) {
            char ch=board[r][c]; if(ch=='.') continue;
            if (!seen.add(ch+" in row "+r)) return false;
            if (!seen.add(ch+" in col "+c)) return false;
            if (!seen.add(ch+" in box "+(r/3)+","+(c/3))) return false;
        }
        return true;
    }

    // LC128 - LONGEST CONSECUTIVE SEQUENCE
    static int longestConsecutive(int[] nums) {
        Set<Integer> set=new HashSet<>(); for(int n:nums) set.add(n);
        int maxLen=0;
        for (int n:set) {
            if (!set.contains(n-1)) { // sequence start
                int streak=1; while(set.contains(n+streak)) streak++;
                maxLen=Math.max(maxLen,streak);
            }
        }
        return maxLen;
    }

    // LC380 - INSERT DELETE GETRANDOM O(1)
    /**
     * APPROACH: HashMap + ArrayList
     *   Map: value → index in list. Remove: swap with last, update map
     */
    static class RandomizedSet {
        Map<Integer,Integer> map=new HashMap<>(); List<Integer> list=new ArrayList<>(); Random rand=new Random();
        boolean insert(int val) {
            if (map.containsKey(val)) return false;
            map.put(val,list.size()); list.add(val); return true;
        }
        boolean remove(int val) {
            if (!map.containsKey(val)) return false;
            int idx=map.get(val), last=list.get(list.size()-1);
            list.set(idx,last); map.put(last,idx); list.remove(list.size()-1); map.remove(val); return true;
        }
        int getRandom() { return list.get(rand.nextInt(list.size())); }
    }

    // LC454 - 4SUM II
    /**
     * APPROACH: Split into two pairs, count a+b sums, look up -(c+d)
     * TIME: O(n²)  SPACE: O(n²)
     */
    static int fourSumCount(int[] a, int[] b, int[] c, int[] d) {
        Map<Integer,Integer> sumAB=new HashMap<>();
        for (int x:a) for(int y:b) sumAB.merge(x+y,1,Integer::sum);
        int count=0;
        for (int x:c) for(int y:d) count+=sumAB.getOrDefault(-(x+y),0);
        return count;
    }

    // LC560 - SUBARRAY SUM EQUALS K
    /**
     * APPROACH: Prefix sum + HashMap
     *   count[sum] = number of times this prefix sum occurred
     *   If (prefixSum - k) seen before → subarrays ending here with sum k
     * TIME: O(n)  SPACE: O(n)
     */
    static int subarraySum(int[] nums, int k) {
        Map<Integer,Integer> count=new HashMap<>(); count.put(0,1);
        int prefixSum=0, result=0;
        for (int n:nums) {
            prefixSum+=n; result+=count.getOrDefault(prefixSum-k,0); count.merge(prefixSum,1,Integer::sum);
        }
        return result;
    }

    // LC202 - HAPPY NUMBER
    static boolean isHappy(int n) {
        Set<Integer> seen=new HashSet<>();
        while (n!=1&&seen.add(n)) { int s=0; while(n>0){int d=n%10;s+=d*d;n/=10;} n=s; }
        return n==1;
    }

    // LC290 - WORD PATTERN
    static boolean wordPattern(String pattern, String s) {
        String[] words=s.split(" ");
        if(words.length!=pattern.length()) return false;
        Map<Character,String> cToW=new HashMap<>(); Map<String,Character> wToC=new HashMap<>();
        for (int i=0;i<pattern.length();i++) {
            char c=pattern.charAt(i); String w=words[i];
            if(cToW.containsKey(c)&&!cToW.get(c).equals(w)) return false;
            if(wToC.containsKey(w)&&wToC.get(w)!=c) return false;
            cToW.put(c,w); wToC.put(w,c);
        }
        return true;
    }

    // LC299 - BULLS AND COWS
    static String getHint(String secret, String guess) {
        int bulls=0; int[] sCount=new int[10],gCount=new int[10];
        for (int i=0;i<secret.length();i++) {
            if (secret.charAt(i)==guess.charAt(i)) bulls++;
            else { sCount[secret.charAt(i)-'0']++; gCount[guess.charAt(i)-'0']++; }
        }
        int cows=0; for(int i=0;i<10;i++) cows+=Math.min(sCount[i],gCount[i]);
        return bulls+"A"+cows+"B";
    }

    // LC204 - COUNT PRIMES (Sieve of Eratosthenes)
    static int countPrimes(int n) {
        boolean[] isComposite=new boolean[n];
        int count=0;
        for (int i=2;i<n;i++) {
            if (!isComposite[i]) {
                count++;
                for (long j=(long)i*i;j<n;j+=i) isComposite[(int)j]=true;
            }
        }
        return count;
    }

    // LC187 - REPEATED DNA SEQUENCES
    static List<String> findRepeatedDnaSequences(String s) {
        Set<String> seen=new HashSet<>(), result=new HashSet<>();
        for (int i=0;i+10<=s.length();i++) {
            String sub=s.substring(i,i+10);
            if (!seen.add(sub)) result.add(sub);
        }
        return new ArrayList<>(result);
    }

    // LC349 - INTERSECTION OF TWO ARRAYS
    static int[] intersection(int[] nums1, int[] nums2) {
        Set<Integer> set=new HashSet<>(); for(int n:nums1) set.add(n);
        Set<Integer> result=new HashSet<>(); for(int n:nums2) if(set.contains(n)) result.add(n);
        return result.stream().mapToInt(Integer::intValue).toArray();
    }

    // LC350 - INTERSECTION OF TWO ARRAYS II (with frequency)
    static int[] intersect(int[] nums1, int[] nums2) {
        Map<Integer,Integer> freq=new HashMap<>();
        for(int n:nums1) freq.merge(n,1,Integer::sum);
        List<Integer> result=new ArrayList<>();
        for(int n:nums2) if(freq.getOrDefault(n,0)>0){result.add(n);freq.merge(n,-1,Integer::sum);}
        return result.stream().mapToInt(Integer::intValue).toArray();
    }

    // GFG - COUNT DISTINCT ELEMENTS IN WINDOW OF SIZE K
    static int[] countDistinct(int[] arr, int k) {
        int n=arr.length;
        int[] result=new int[n-k+1];
        Map<Integer,Integer> freq=new HashMap<>();
        for(int i=0;i<k;i++) freq.merge(arr[i],1,Integer::sum);
        result[0]=freq.size();
        for(int i=k;i<n;i++) {
            freq.merge(arr[i],1,Integer::sum);
            freq.merge(arr[i-k],-1,Integer::sum);
            if(freq.get(arr[i-k])==0) freq.remove(arr[i-k]);
            result[i-k+1]=freq.size();
        }
        return result;
    }

    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║     HASHING PROBLEMS - ALL SOLUTIONS     ║");
        System.out.println("╚══════════════════════════════════════════╝\n");
        System.out.println("LC217 containsDuplicate([1,2,3,1])       = " + containsDuplicate(new int[]{1,2,3,1}));
        System.out.println("LC219 containsNearbyDup([1,2,3,1],k=3)  = " + containsNearbyDuplicate(new int[]{1,2,3,1},3));
        System.out.println("LC128 longestConsecutive([100,4,200,1,3,2]) = " + longestConsecutive(new int[]{100,4,200,1,3,2}));
        System.out.println("LC454 fourSumCount                       = " + fourSumCount(new int[]{1,2},new int[]{-2,-1},new int[]{-1,2},new int[]{0,2}));
        System.out.println("LC560 subarraySum([1,1,1],k=2)           = " + subarraySum(new int[]{1,1,1},2));
        System.out.println("LC202 isHappy(19)                        = " + isHappy(19));
        System.out.println("LC290 wordPattern(abba,dog cat cat dog)  = " + wordPattern("abba","dog cat cat dog"));
        System.out.println("LC299 getHint(1807,7810)                 = " + getHint("1807","7810"));
        System.out.println("LC204 countPrimes(100)                   = " + countPrimes(100));
        System.out.println("LC349 intersection([1,2,2,1],[2,2])      = " + Arrays.toString(intersection(new int[]{1,2,2,1},new int[]{2,2})));
        System.out.println("LC350 intersect([1,2,2,1],[2,2])         = " + Arrays.toString(intersect(new int[]{1,2,2,1},new int[]{2,2})));
        System.out.println("GFG   countDistinct(k=3)                 = " + Arrays.toString(countDistinct(new int[]{1,2,1,3,4,2,3},3)));
    }
}
