/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║          TRIE - LeetCode & GeeksForGeeks Solutions           ║
 * ╚══════════════════════════════════════════════════════════════╝
 * LC208  Implement Trie (Prefix Tree)
 * LC211  Design Add and Search Words Data Structure
 * LC212  Word Search II
 * LC336  Palindrome Pairs
 * LC421  Maximum XOR of Two Numbers
 * LC472  Concatenated Words
 * LC648  Replace Words
 * LC676  Implement Magic Dictionary
 * LC720  Longest Word in Dictionary
 * LC745  Prefix and Suffix Search
 * GFG    Auto-Complete Feature
 * GFG    Count Distinct Substrings
 */
import java.util.*;

public class TrieProblems {

    // ─── TRIE NODE ──────────────────────────────────────────────────
    static class TrieNode {
        TrieNode[] children = new TrieNode[26];
        boolean isEnd = false;
        String word = null; // for Word Search II
        int count = 0;      // for prefix count
    }

    // LC208 - IMPLEMENT TRIE
    /**
     * Trie (Prefix Tree): tree where each node = one character
     * Each root-to-leaf path = a word
     * Children indexed by character (a=0, b=1, ..., z=25)
     *
     * TIME: O(m) per op where m = word length  SPACE: O(m*n) total
     */
    static class Trie {
        TrieNode root = new TrieNode();

        void insert(String word) {
            TrieNode node = root;
            for (char c : word.toCharArray()) {
                int idx = c - 'a';
                if (node.children[idx] == null) node.children[idx] = new TrieNode();
                node = node.children[idx];
                node.count++; // tracks how many words pass through
            }
            node.isEnd = true;
            node.word = word;
        }

        boolean search(String word) {
            TrieNode node = root;
            for (char c : word.toCharArray()) {
                int idx = c - 'a';
                if (node.children[idx] == null) return false;
                node = node.children[idx];
            }
            return node.isEnd;
        }

        boolean startsWith(String prefix) {
            TrieNode node = root;
            for (char c : prefix.toCharArray()) {
                int idx = c - 'a';
                if (node.children[idx] == null) return false;
                node = node.children[idx];
            }
            return true;
        }

        // Count words with given prefix
        int countWithPrefix(String prefix) {
            TrieNode node = root;
            for (char c : prefix.toCharArray()) {
                int idx = c - 'a';
                if (node.children[idx] == null) return 0;
                node = node.children[idx];
            }
            return node.count;
        }

        // Get all words with prefix (autocomplete)
        List<String> autocomplete(String prefix) {
            TrieNode node = root;
            for (char c : prefix.toCharArray()) {
                int idx = c - 'a';
                if (node.children[idx] == null) return new ArrayList<>();
                node = node.children[idx];
            }
            List<String> result = new ArrayList<>();
            dfsCollect(node, new StringBuilder(prefix), result);
            return result;
        }
        void dfsCollect(TrieNode node, StringBuilder sb, List<String> result) {
            if (node.isEnd) result.add(sb.toString());
            for (int i = 0; i < 26; i++) {
                if (node.children[i] != null) {
                    sb.append((char)('a'+i));
                    dfsCollect(node.children[i], sb, result);
                    sb.deleteCharAt(sb.length()-1);
                }
            }
        }
    }

    // LC211 - ADD AND SEARCH WITH WILDCARD (. matches any char)
    /**
     * APPROACH: DFS with wildcard handling
     *   '.' → recurse on all non-null children
     *   else → normal trie traversal
     */
    static class WordDictionary {
        TrieNode root = new TrieNode();

        void addWord(String word) {
            TrieNode node = root;
            for (char c : word.toCharArray()) {
                int idx = c - 'a';
                if (node.children[idx] == null) node.children[idx] = new TrieNode();
                node = node.children[idx];
            }
            node.isEnd = true;
        }

        boolean search(String word) { return dfsSearch(root, word, 0); }
        boolean dfsSearch(TrieNode node, String word, int i) {
            if (i == word.length()) return node.isEnd;
            char c = word.charAt(i);
            if (c == '.') { // wildcard: try all children
                for (TrieNode child : node.children)
                    if (child != null && dfsSearch(child, word, i+1)) return true;
                return false;
            }
            TrieNode next = node.children[c-'a'];
            return next != null && dfsSearch(next, word, i+1);
        }
    }

    // LC212 - WORD SEARCH II (find all words from list in grid)
    /**
     * APPROACH: Build Trie from word list, then DFS on grid
     *   Trie pruning: mark words found, trim exhausted branches
     * TIME: O(M * 4^L) where M=cells, L=max word length
     */
    static List<String> findWords(char[][] board, String[] words) {
        Trie trie = new Trie();
        for (String w : words) trie.insert(w);
        List<String> result = new ArrayList<>();
        int rows = board.length, cols = board[0].length;
        for (int r = 0; r < rows; r++)
            for (int c = 0; c < cols; c++)
                dfsWordSearch(board, r, c, trie.root, result, rows, cols);
        return result;
    }
    static void dfsWordSearch(char[][] board, int r, int c, TrieNode node, List<String> result, int rows, int cols) {
        if (r<0||r>=rows||c<0||c>=cols||board[r][c]=='#') return;
        int idx = board[r][c] - 'a';
        if (node.children[idx] == null) return;
        TrieNode next = node.children[idx];
        if (next.word != null) { result.add(next.word); next.word = null; } // found, avoid dup
        char tmp = board[r][c]; board[r][c] = '#';
        dfsWordSearch(board,r+1,c,next,result,rows,cols); dfsWordSearch(board,r-1,c,next,result,rows,cols);
        dfsWordSearch(board,r,c+1,next,result,rows,cols); dfsWordSearch(board,r,c-1,next,result,rows,cols);
        board[r][c] = tmp;
    }

    // LC648 - REPLACE WORDS
    /**
     * APPROACH: Insert all roots into Trie
     *   For each word in sentence, find shortest root prefix
     * TIME: O(total chars)
     */
    static String replaceWords(List<String> dictionary, String sentence) {
        Trie trie = new Trie();
        for (String root : dictionary) trie.insert(root);
        String[] words = sentence.split(" ");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < words.length; i++) {
            if (i > 0) sb.append(' ');
            TrieNode node = trie.root;
            StringBuilder cur = new StringBuilder();
            boolean replaced = false;
            for (char c : words[i].toCharArray()) {
                int idx = c - 'a';
                if (node.children[idx] == null) break;
                cur.append(c);
                node = node.children[idx];
                if (node.isEnd) { sb.append(cur); replaced = true; break; }
            }
            if (!replaced) sb.append(words[i]);
        }
        return sb.toString();
    }

    // LC720 - LONGEST WORD IN DICTIONARY
    /**
     * APPROACH: Insert all words into Trie
     *   BFS/DFS keeping only words where every prefix exists
     *   Return lexicographically smallest longest
     * TIME: O(total chars)
     */
    static String longestWord(String[] words) {
        Trie trie = new Trie(); trie.root.isEnd = true;
        Arrays.sort(words); // sort ensures lexicographic order for ties
        for (String w : words) trie.insert(w);
        String result = "";
        Queue<TrieNode> q = new LinkedList<>(); q.offer(trie.root);
        while (!q.isEmpty()) {
            TrieNode node = q.poll();
            for (int i = 0; i < 26; i++) {
                TrieNode child = node.children[i];
                if (child != null && child.isEnd) {
                    q.offer(child);
                    if (child.word != null && child.word.length() > result.length())
                        result = child.word;
                }
            }
        }
        return result;
    }

    // LC421 - MAXIMUM XOR OF TWO NUMBERS
    /**
     * APPROACH: Binary Trie on bit representation
     *   For each number, try to find complement bit at each level
     * TIME: O(n * 32)  SPACE: O(n * 32)
     */
    static class BitTrieNode {
        BitTrieNode[] children = new BitTrieNode[2];
    }
    static int findMaximumXOR(int[] nums) {
        BitTrieNode root = new BitTrieNode();
        // Build bit trie
        for (int n : nums) {
            BitTrieNode node = root;
            for (int i = 31; i >= 0; i--) {
                int bit = (n >> i) & 1;
                if (node.children[bit] == null) node.children[bit] = new BitTrieNode();
                node = node.children[bit];
            }
        }
        // Find max XOR
        int maxXOR = 0;
        for (int n : nums) {
            BitTrieNode node = root; int curXOR = 0;
            for (int i = 31; i >= 0; i--) {
                int bit = (n >> i) & 1, want = 1 - bit; // prefer opposite bit
                if (node.children[want] != null) { curXOR |= (1 << i); node = node.children[want]; }
                else if (node.children[bit] != null) node = node.children[bit];
            }
            maxXOR = Math.max(maxXOR, curXOR);
        }
        return maxXOR;
    }

    // LC676 - MAGIC DICTIONARY (search with exactly one char changed)
    static class MagicDictionary {
        Set<String> wordSet = new HashSet<>();
        boolean search(String searchWord) {
            for (String w : wordSet) {
                if (w.length() != searchWord.length()) continue;
                int diff = 0;
                for (int i = 0; i < w.length(); i++) if (w.charAt(i) != searchWord.charAt(i)) diff++;
                if (diff == 1) return true;
            }
            return false;
        }
        void buildDict(String[] dictionary) { wordSet.addAll(Arrays.asList(dictionary)); }
    }

    // GFG - AUTOCOMPLETE SYSTEM
    /**
     * APPROACH: Trie with autocomplete DFS
     * Returns top suggestions for each prefix character typed
     */
    static List<List<String>> suggestedProducts(String[] products, String searchWord) {
        Arrays.sort(products);
        Trie trie = new Trie();
        for (String p : products) trie.insert(p);
        List<List<String>> result = new ArrayList<>();
        StringBuilder prefix = new StringBuilder();
        for (char c : searchWord.toCharArray()) {
            prefix.append(c);
            List<String> suggestions = trie.autocomplete(prefix.toString());
            // Return at most 3 suggestions
            result.add(suggestions.subList(0, Math.min(3, suggestions.size())));
        }
        return result;
    }

    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║       TRIE PROBLEMS - ALL SOLUTIONS      ║");
        System.out.println("╚══════════════════════════════════════════╝\n");

        Trie trie = new Trie();
        for (String w : new String[]{"apple","app","application","apt","banana","band"}) trie.insert(w);
        System.out.println("LC208 search(apple)       = " + trie.search("apple"));
        System.out.println("      search(appl)        = " + trie.search("appl"));
        System.out.println("      startsWith(app)     = " + trie.startsWith("app"));
        System.out.println("      autocomplete(ap)    = " + trie.autocomplete("ap"));

        WordDictionary wd = new WordDictionary();
        for (String w : new String[]{"bad","dad","mad"}) wd.addWord(w);
        System.out.println("LC211 search(pad)         = " + wd.search("pad"));
        System.out.println("      search(.ad)         = " + wd.search(".ad"));
        System.out.println("      search(b..)         = " + wd.search("b.."));

        char[][] board = {{'o','a','a','n'},{'e','t','a','e'},{'i','h','k','r'},{'i','f','l','v'}};
        System.out.println("LC212 wordSearchII        = " + findWords(board, new String[]{"oath","pea","eat","rain"}));

        System.out.println("LC648 replaceWords        = " + replaceWords(Arrays.asList("cat","bat","rat"), "the cattle was rattled by the battery"));
        System.out.println("LC720 longestWord         = " + longestWord(new String[]{"w","wo","wor","word","world"}));
        System.out.println("LC421 maxXOR([3,10,5,25,2,8]) = " + findMaximumXOR(new int[]{3,10,5,25,2,8}));

        MagicDictionary md = new MagicDictionary();
        md.buildDict(new String[]{"hello","leetcode"});
        System.out.println("LC676 magicDict(hello)    = " + md.search("hello"));
        System.out.println("      magicDict(hhllo)    = " + md.search("hhllo"));

        System.out.println("GFG   suggestedProducts   = " + suggestedProducts(new String[]{"mobile","mouse","moneypot","monitor","mousepad"}, "mouse"));
    }
}
