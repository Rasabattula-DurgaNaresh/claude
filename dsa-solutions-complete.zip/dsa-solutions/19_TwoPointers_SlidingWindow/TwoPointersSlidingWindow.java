/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║   TWO POINTERS & SLIDING WINDOW - LeetCode & GFG Solutions  ║
 * ╚══════════════════════════════════════════════════════════════╝
 * TWO POINTERS:
 * LC11  Container With Most Water
 * LC15  3Sum
 * LC16  3Sum Closest
 * LC18  4Sum
 * LC42  Trapping Rain Water
 * LC75  Sort Colors
 * LC125 Valid Palindrome
 * LC167 Two Sum II (sorted)
 * LC259 3Sum Smaller
 * LC283 Move Zeroes
 * LC344 Reverse String
 * LC345 Reverse Vowels
 * LC881 Boats to Save People
 * SLIDING WINDOW:
 * LC3   Longest Substring Without Repeating Chars
 * LC30  Substring with All Words
 * LC76  Minimum Window Substring
 * LC159 At Most Two Distinct Characters
 * LC209 Minimum Size Subarray Sum
 * LC239 Sliding Window Maximum
 * LC340 At Most K Distinct Characters
 * LC424 Longest Repeating Character Replacement
 * LC438 Find All Anagrams
 * LC480 Sliding Window Median
 * LC567 Permutation in String
 * GFG   Max of all subarrays of size k
 */
import java.util.*;

public class TwoPointersSlidingWindow {

    // ═══════════════════════════════════════════════════════════════
    //                        TWO POINTERS
    // ═══════════════════════════════════════════════════════════════

    // LC167 - TWO SUM II (sorted array)
    /**
     * APPROACH: l from left, r from right. Shrink based on sum vs target
     * TIME: O(n)  SPACE: O(1)
     */
    static int[] twoSumSorted(int[] nums, int target) {
        int l = 0, r = nums.length - 1;
        while (l < r) {
            int sum = nums[l] + nums[r];
            if (sum == target) return new int[]{l+1, r+1}; // 1-indexed
            if (sum < target) l++; else r--;
        }
        return new int[]{-1,-1};
    }

    // LC15 - 3SUM
    /**
     * APPROACH: Sort + fix one element, use two pointers for rest
     *   Skip duplicates to avoid repeated triplets
     * TIME: O(n²)  SPACE: O(1)
     */
    static List<List<Integer>> threeSum(int[] nums) {
        Arrays.sort(nums);
        List<List<Integer>> result = new ArrayList<>();
        for (int i = 0; i < nums.length-2; i++) {
            if (i > 0 && nums[i] == nums[i-1]) continue; // skip dup
            int l = i+1, r = nums.length-1;
            while (l < r) {
                int sum = nums[i]+nums[l]+nums[r];
                if (sum == 0) {
                    result.add(Arrays.asList(nums[i],nums[l],nums[r]));
                    while (l<r && nums[l]==nums[l+1]) l++;
                    while (l<r && nums[r]==nums[r-1]) r--;
                    l++; r--;
                } else if (sum < 0) l++; else r--;
            }
        }
        return result;
    }

    // LC16 - 3SUM CLOSEST
    static int threeSumClosest(int[] nums, int target) {
        Arrays.sort(nums);
        int closest = nums[0]+nums[1]+nums[2];
        for (int i = 0; i < nums.length-2; i++) {
            int l = i+1, r = nums.length-1;
            while (l < r) {
                int sum = nums[i]+nums[l]+nums[r];
                if (Math.abs(sum-target) < Math.abs(closest-target)) closest = sum;
                if (sum < target) l++; else r--;
            }
        }
        return closest;
    }

    // LC18 - 4SUM
    static List<List<Integer>> fourSum(int[] nums, int target) {
        Arrays.sort(nums);
        List<List<Integer>> result = new ArrayList<>();
        for (int i = 0; i < nums.length-3; i++) {
            if (i>0 && nums[i]==nums[i-1]) continue;
            for (int j = i+1; j < nums.length-2; j++) {
                if (j>i+1 && nums[j]==nums[j-1]) continue;
                int l=j+1, r=nums.length-1;
                while (l<r) {
                    long sum = (long)nums[i]+nums[j]+nums[l]+nums[r];
                    if (sum==target){
                        result.add(Arrays.asList(nums[i],nums[j],nums[l],nums[r]));
                        while(l<r&&nums[l]==nums[l+1])l++; while(l<r&&nums[r]==nums[r-1])r--;
                        l++; r--;
                    } else if (sum<target) l++; else r--;
                }
            }
        }
        return result;
    }

    // LC42 - TRAPPING RAIN WATER
    /**
     * APPROACH: Two pointers
     *   water[i] = min(maxLeft, maxRight) - height[i]
     *   Process side with smaller max (it's the constraint)
     * TIME: O(n)  SPACE: O(1)
     */
    static int trap(int[] height) {
        int l=0, r=height.length-1, maxL=0, maxR=0, water=0;
        while (l < r) {
            if (height[l] <= height[r]) {
                if (height[l]>=maxL) maxL=height[l]; else water+=maxL-height[l];
                l++;
            } else {
                if (height[r]>=maxR) maxR=height[r]; else water+=maxR-height[r];
                r--;
            }
        }
        return water;
    }

    // LC881 - BOATS TO SAVE PEOPLE (at most 2 per boat, weight <= limit)
    /**
     * APPROACH: Sort, pair heaviest with lightest if possible
     * TIME: O(n log n)  SPACE: O(1)
     */
    static int numRescueBoats(int[] people, int limit) {
        Arrays.sort(people);
        int l=0, r=people.length-1, boats=0;
        while (l<=r) {
            if (people[l]+people[r]<=limit) l++;
            r--; boats++;
        }
        return boats;
    }

    // LC344 - REVERSE STRING
    static void reverseString(char[] s) {
        int l=0, r=s.length-1;
        while (l<r){char t=s[l];s[l++]=s[r];s[r--]=t;}
    }

    // LC345 - REVERSE VOWELS
    static String reverseVowels(String s) {
        char[] arr = s.toCharArray(); String vowels="aeiouAEIOU";
        int l=0, r=arr.length-1;
        while (l<r) {
            while (l<r && vowels.indexOf(arr[l])<0) l++;
            while (l<r && vowels.indexOf(arr[r])<0) r--;
            if (l<r){char t=arr[l];arr[l++]=arr[r];arr[r--]=t;}
        }
        return new String(arr);
    }

    // ═══════════════════════════════════════════════════════════════
    //                      SLIDING WINDOW
    // ═══════════════════════════════════════════════════════════════

    // LC3 - LONGEST SUBSTRING WITHOUT REPEATING CHARS
    /**
     * APPROACH: HashMap stores last seen index
     *   When char seen again, move left to lastSeen+1
     * TIME: O(n)  SPACE: O(min(n,charset))
     */
    static int lengthOfLongestSubstring(String s) {
        Map<Character,Integer> lastSeen=new HashMap<>();
        int left=0, maxLen=0;
        for (int r=0; r<s.length(); r++) {
            char c=s.charAt(r);
            if (lastSeen.containsKey(c) && lastSeen.get(c)>=left) left=lastSeen.get(c)+1;
            lastSeen.put(c,r);
            maxLen=Math.max(maxLen,r-left+1);
        }
        return maxLen;
    }

    // LC209 - MINIMUM SIZE SUBARRAY SUM >= target
    /**
     * APPROACH: Expand right, shrink left when sum >= target
     * TIME: O(n)  SPACE: O(1)
     */
    static int minSubArrayLen(int target, int[] nums) {
        int left=0, sum=0, minLen=Integer.MAX_VALUE;
        for (int right=0; right<nums.length; right++) {
            sum+=nums[right];
            while (sum>=target) { minLen=Math.min(minLen,right-left+1); sum-=nums[left++]; }
        }
        return minLen==Integer.MAX_VALUE?0:minLen;
    }

    // LC438 - FIND ALL ANAGRAMS IN STRING
    /**
     * APPROACH: Fixed window of size p, compare freq arrays
     * TIME: O(n)  SPACE: O(1)
     */
    static List<Integer> findAnagrams(String s, String p) {
        List<Integer> result=new ArrayList<>();
        if (s.length()<p.length()) return result;
        int[] pCount=new int[26], sCount=new int[26];
        for (int i=0;i<p.length();i++){pCount[p.charAt(i)-'a']++;sCount[s.charAt(i)-'a']++;}
        if (Arrays.equals(pCount,sCount)) result.add(0);
        for (int i=p.length();i<s.length();i++){
            sCount[s.charAt(i)-'a']++;
            sCount[s.charAt(i-p.length())-'a']--;
            if (Arrays.equals(pCount,sCount)) result.add(i-p.length()+1);
        }
        return result;
    }

    // LC424 - LONGEST REPEATING CHARACTER REPLACEMENT
    /**
     * APPROACH: Track max frequency char in window
     *   If window - maxFreq > k → shrink (too many replacements needed)
     * TIME: O(n)  SPACE: O(26)
     * EXAMPLE: "AABABBA", k=1 → 4
     */
    static int characterReplacement(String s, int k) {
        int[] freq=new int[26]; int maxFreq=0, left=0, result=0;
        for (int right=0; right<s.length(); right++) {
            freq[s.charAt(right)-'A']++;
            maxFreq=Math.max(maxFreq, freq[s.charAt(right)-'A']);
            if (right-left+1-maxFreq > k) { freq[s.charAt(left)-'A']--; left++; }
            result=Math.max(result, right-left+1);
        }
        return result;
    }

    // LC567 - PERMUTATION IN STRING
    /**
     * APPROACH: Fixed sliding window of size s1, compare freq arrays
     * TIME: O(n)  SPACE: O(1)
     */
    static boolean checkInclusion(String s1, String s2) {
        if (s1.length()>s2.length()) return false;
        int[] p=new int[26], w=new int[26];
        for (int i=0;i<s1.length();i++){p[s1.charAt(i)-'a']++;w[s2.charAt(i)-'a']++;}
        if (Arrays.equals(p,w)) return true;
        for (int i=s1.length();i<s2.length();i++){
            w[s2.charAt(i)-'a']++;
            w[s2.charAt(i-s1.length())-'a']--;
            if (Arrays.equals(p,w)) return true;
        }
        return false;
    }

    // LC340 - LONGEST SUBSTRING WITH AT MOST K DISTINCT CHARS
    static int lengthOfLongestSubstringKDistinct(String s, int k) {
        Map<Character,Integer> map=new HashMap<>(); int left=0, maxLen=0;
        for (int right=0; right<s.length(); right++) {
            map.merge(s.charAt(right),1,Integer::sum);
            while (map.size()>k) {
                char lc=s.charAt(left++);
                map.merge(lc,-1,Integer::sum);
                if (map.get(lc)==0) map.remove(lc);
            }
            maxLen=Math.max(maxLen,right-left+1);
        }
        return maxLen;
    }

    // LC76 - MINIMUM WINDOW SUBSTRING
    static String minWindow(String s, String t) {
        Map<Character,Integer> need=new HashMap<>();
        for (char c:t.toCharArray()) need.merge(c,1,Integer::sum);
        int left=0, have=0, required=need.size(), minLen=Integer.MAX_VALUE, minStart=0;
        Map<Character,Integer> window=new HashMap<>();
        for (int right=0; right<s.length(); right++) {
            char c=s.charAt(right); window.merge(c,1,Integer::sum);
            if (need.containsKey(c)&&window.get(c).equals(need.get(c))) have++;
            while (have==required) {
                if (right-left+1<minLen){minLen=right-left+1;minStart=left;}
                char lc=s.charAt(left++); window.merge(lc,-1,Integer::sum);
                if (need.containsKey(lc)&&window.get(lc)<need.get(lc)) have--;
            }
        }
        return minLen==Integer.MAX_VALUE?"":s.substring(minStart,minStart+minLen);
    }

    // GFG - MAX OF ALL SUBARRAYS OF SIZE K (Deque)
    static int[] maxOfSubarrays(int[] arr, int k) {
        int n=arr.length;
        int[] result=new int[n-k+1];
        Deque<Integer> dq=new ArrayDeque<>(); // stores indices
        for (int i=0; i<n; i++) {
            if (!dq.isEmpty()&&dq.peekFirst()<i-k+1) dq.pollFirst();
            while (!dq.isEmpty()&&arr[dq.peekLast()]<arr[i]) dq.pollLast();
            dq.offerLast(i);
            if (i>=k-1) result[i-k+1]=arr[dq.peekFirst()];
        }
        return result;
    }

    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║  TWO POINTERS & SLIDING WINDOW SOLUTIONS ║");
        System.out.println("╚══════════════════════════════════════════╝\n");

        System.out.println("=== TWO POINTERS ===");
        System.out.println("LC167 twoSumSorted([2,7,11,15],9)     = " + Arrays.toString(twoSumSorted(new int[]{2,7,11,15},9)));
        System.out.println("LC15  threeSum([-1,0,1,2,-1,-4])      = " + threeSum(new int[]{-1,0,1,2,-1,-4}));
        System.out.println("LC16  threeSumClosest([1,1,1,0],-100) = " + threeSumClosest(new int[]{1,1,1,0},-100));
        System.out.println("LC18  fourSum([1,0,-1,0,-2,2],0)      = " + fourSum(new int[]{1,0,-1,0,-2,2},0));
        System.out.println("LC42  trappingRain([4,2,0,3,2,5])     = " + trap(new int[]{4,2,0,3,2,5}));
        System.out.println("LC881 numRescueBoats([3,5,3,4],5)     = " + numRescueBoats(new int[]{3,5,3,4},5));

        char[] s = "hello".toCharArray(); reverseString(s);
        System.out.println("LC344 reverseString                    = " + new String(s));
        System.out.println("LC345 reverseVowels(hello)             = " + reverseVowels("hello"));

        System.out.println("\n=== SLIDING WINDOW ===");
        System.out.println("LC3   longestSubstr(abcabcbb)          = " + lengthOfLongestSubstring("abcabcbb"));
        System.out.println("LC209 minSubArrayLen(7,[2,3,1,2,4,3]) = " + minSubArrayLen(7,new int[]{2,3,1,2,4,3}));
        System.out.println("LC438 findAnagrams(cbaebabacd,abc)     = " + findAnagrams("cbaebabacd","abc"));
        System.out.println("LC424 charReplacement(AABABBA,k=1)     = " + characterReplacement("AABABBA",1));
        System.out.println("LC567 checkInclusion(ab,eidbaooo)      = " + checkInclusion("ab","eidbaooo"));
        System.out.println("LC340 longestKDistinct(eceba,k=2)      = " + lengthOfLongestSubstringKDistinct("eceba",2));
        System.out.println("LC76  minWindow(ADOBECODEBANC,ABC)     = " + minWindow("ADOBECODEBANC","ABC"));
        System.out.println("GFG   maxOfSubarrays(k=3)              = " + Arrays.toString(maxOfSubarrays(new int[]{1,2,3,1,4,5,2,3,6},3)));
    }
}
