/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║         STRINGS - LeetCode & GeeksForGeeks Solutions         ║
 * ╚══════════════════════════════════════════════════════════════╝
 * LC3   Longest Substring Without Repeating Characters
 * LC5   Longest Palindromic Substring
 * LC20  Valid Parentheses
 * LC28  Find Index of First Occurrence (strStr)
 * LC49  Group Anagrams
 * LC76  Minimum Window Substring
 * LC125 Valid Palindrome
 * LC151 Reverse Words in a String
 * LC242 Valid Anagram
 * LC344 Reverse String
 * LC387 First Unique Character
 * LC438 Find All Anagrams in a String
 * LC647 Palindromic Substrings
 * GFG   Roman Number to Integer
 * GFG   Anagram Check
 * GFG   Longest Common Prefix
 * GFG   Implement Atoi
 * GFG   Count and Say
 * GFG   Isomorphic Strings
 * GFG   Rabin Karp String Search
 */
import java.util.*;
import java.util.stream.*;

public class StringProblems {

    // LC3 - LONGEST SUBSTRING WITHOUT REPEATING CHARACTERS
    /**
     * APPROACH: Sliding window + HashMap for last seen index
     *   window [left, right], when char seen again move left past it
     * TIME: O(n)  SPACE: O(min(n,m)) m=charset size
     * EXAMPLE: "abcabcbb" → 3 ("abc")
     */
    static int lengthOfLongestSubstring(String s) {
        Map<Character, Integer> lastSeen = new HashMap<>();
        int left = 0, maxLen = 0;
        for (int right = 0; right < s.length(); right++) {
            char c = s.charAt(right);
            if (lastSeen.containsKey(c) && lastSeen.get(c) >= left)
                left = lastSeen.get(c) + 1;
            lastSeen.put(c, right);
            maxLen = Math.max(maxLen, right - left + 1);
        }
        return maxLen;
    }

    // LC5 - LONGEST PALINDROMIC SUBSTRING
    /**
     * APPROACH: Expand around center (both odd and even length)
     *   For each center, expand while chars match
     * TIME: O(n²)  SPACE: O(1)
     * EXAMPLE: "babad" → "bab" or "aba"
     */
    static String longestPalindrome(String s) {
        int start = 0, maxLen = 1;
        for (int i = 0; i < s.length(); i++) {
            // Odd length palindromes
            int l = i, r = i;
            while (l >= 0 && r < s.length() && s.charAt(l) == s.charAt(r)) { l--; r++; }
            if (r - l - 1 > maxLen) { maxLen = r - l - 1; start = l + 1; }
            // Even length palindromes
            l = i; r = i + 1;
            while (l >= 0 && r < s.length() && s.charAt(l) == s.charAt(r)) { l--; r++; }
            if (r - l - 1 > maxLen) { maxLen = r - l - 1; start = l + 1; }
        }
        return s.substring(start, start + maxLen);
    }

    // LC20 - VALID PARENTHESES
    /**
     * APPROACH: Stack — push open brackets, match/pop for closing
     * TIME: O(n)  SPACE: O(n)
     * EXAMPLE: "()[]{}" → true  |  "([)]" → false
     */
    static boolean isValid(String s) {
        Deque<Character> stack = new ArrayDeque<>();
        for (char c : s.toCharArray()) {
            if (c == '(' || c == '{' || c == '[') stack.push(c);
            else if (stack.isEmpty()) return false;
            else {
                char top = stack.pop();
                if (c == ')' && top != '(') return false;
                if (c == '}' && top != '{') return false;
                if (c == ']' && top != '[') return false;
            }
        }
        return stack.isEmpty();
    }

    // LC28 - FIRST OCCURRENCE OF NEEDLE IN HAYSTACK (KMP)
    /**
     * APPROACH: KMP - precompute LPS (Longest Proper Prefix which is also Suffix)
     *   Use LPS to skip unnecessary comparisons
     * TIME: O(n+m)  SPACE: O(m)
     * EXAMPLE: haystack="hello", needle="ll" → 2
     */
    static int strStr(String haystack, String needle) {
        if (needle.isEmpty()) return 0;
        int n = haystack.length(), m = needle.length();
        int[] lps = new int[m];
        // Build LPS
        int len = 0, i = 1;
        while (i < m) {
            if (needle.charAt(i) == needle.charAt(len)) lps[i++] = ++len;
            else if (len > 0) len = lps[len - 1];
            else lps[i++] = 0;
        }
        // Search
        i = 0; int j = 0;
        while (i < n) {
            if (haystack.charAt(i) == needle.charAt(j)) { i++; j++; }
            if (j == m) return i - j;
            else if (i < n && haystack.charAt(i) != needle.charAt(j)) {
                if (j != 0) j = lps[j - 1]; else i++;
            }
        }
        return -1;
    }

    // LC49 - GROUP ANAGRAMS
    /**
     * APPROACH: Sort each word → use sorted form as key
     *   Group words with same sorted key together
     * TIME: O(n * k log k)  SPACE: O(n*k)
     * EXAMPLE: ["eat","tea","tan","ate","nat","bat"] → [["bat"],["nat","tan"],["ate","eat","tea"]]
     */
    static List<List<String>> groupAnagrams(String[] strs) {
        Map<String, List<String>> map = new HashMap<>();
        for (String s : strs) {
            char[] chars = s.toCharArray(); Arrays.sort(chars);
            String key = new String(chars);
            map.computeIfAbsent(key, k -> new ArrayList<>()).add(s);
        }
        return new ArrayList<>(map.values());
    }

    // LC76 - MINIMUM WINDOW SUBSTRING
    /**
     * APPROACH: Sliding window with character frequency maps
     *   'have' tracks how many chars satisfy requirement
     *   Shrink window from left when all chars found
     * TIME: O(n+m)  SPACE: O(m)
     * EXAMPLE: s="ADOBECODEBANC", t="ABC" → "BANC"
     */
    static String minWindow(String s, String t) {
        if (s.length() < t.length()) return "";
        Map<Character, Integer> need = new HashMap<>();
        for (char c : t.toCharArray()) need.merge(c, 1, Integer::sum);
        int left = 0, have = 0, required = need.size(), minLen = Integer.MAX_VALUE, minStart = 0;
        Map<Character, Integer> window = new HashMap<>();
        for (int right = 0; right < s.length(); right++) {
            char c = s.charAt(right);
            window.merge(c, 1, Integer::sum);
            if (need.containsKey(c) && window.get(c).equals(need.get(c))) have++;
            while (have == required) {
                if (right - left + 1 < minLen) { minLen = right - left + 1; minStart = left; }
                char lc = s.charAt(left++);
                window.merge(lc, -1, Integer::sum);
                if (need.containsKey(lc) && window.get(lc) < need.get(lc)) have--;
            }
        }
        return minLen == Integer.MAX_VALUE ? "" : s.substring(minStart, minStart + minLen);
    }

    // LC125 - VALID PALINDROME (ignoring non-alphanumeric)
    /**
     * TIME: O(n)  SPACE: O(1)
     * EXAMPLE: "A man, a plan, a canal: Panama" → true
     */
    static boolean isPalindrome(String s) {
        int l = 0, r = s.length() - 1;
        while (l < r) {
            while (l < r && !Character.isLetterOrDigit(s.charAt(l))) l++;
            while (l < r && !Character.isLetterOrDigit(s.charAt(r))) r--;
            if (Character.toLowerCase(s.charAt(l)) != Character.toLowerCase(s.charAt(r))) return false;
            l++; r--;
        }
        return true;
    }

    // LC151 - REVERSE WORDS IN A STRING
    /**
     * APPROACH: Split on spaces, collect non-empty, reverse, join
     * TIME: O(n)  SPACE: O(n)
     * EXAMPLE: "  hello world  " → "world hello"
     */
    static String reverseWords(String s) {
        String[] words = s.trim().split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (int i = words.length - 1; i >= 0; i--) {
            sb.append(words[i]); if (i > 0) sb.append(' ');
        }
        return sb.toString();
    }

    // LC242 - VALID ANAGRAM
    /**
     * APPROACH: Frequency array of 26 chars — increment for s, decrement for t
     * TIME: O(n)  SPACE: O(1)
     * EXAMPLE: "anagram","nagaram" → true
     */
    static boolean isAnagram(String s, String t) {
        if (s.length() != t.length()) return false;
        int[] freq = new int[26];
        for (int i = 0; i < s.length(); i++) { freq[s.charAt(i)-'a']++; freq[t.charAt(i)-'a']--; }
        for (int f : freq) if (f != 0) return false;
        return true;
    }

    // LC387 - FIRST UNIQUE CHARACTER
    /**
     * TIME: O(n)  SPACE: O(1)
     * EXAMPLE: "leetcode" → 0 (l is first unique)
     */
    static int firstUniqChar(String s) {
        int[] freq = new int[26];
        for (char c : s.toCharArray()) freq[c-'a']++;
        for (int i = 0; i < s.length(); i++) if (freq[s.charAt(i)-'a'] == 1) return i;
        return -1;
    }

    // LC438 - FIND ALL ANAGRAMS IN A STRING
    /**
     * APPROACH: Fixed sliding window of size p.length(), compare freq arrays
     * TIME: O(n)  SPACE: O(1)
     * EXAMPLE: s="cbaebabacd", p="abc" → [0,6]
     */
    static List<Integer> findAnagrams(String s, String p) {
        List<Integer> result = new ArrayList<>();
        if (s.length() < p.length()) return result;
        int[] pCount = new int[26], sCount = new int[26];
        for (int i = 0; i < p.length(); i++) { pCount[p.charAt(i)-'a']++; sCount[s.charAt(i)-'a']++; }
        if (Arrays.equals(pCount, sCount)) result.add(0);
        for (int i = p.length(); i < s.length(); i++) {
            sCount[s.charAt(i)-'a']++;
            sCount[s.charAt(i-p.length())-'a']--;
            if (Arrays.equals(pCount, sCount)) result.add(i - p.length() + 1);
        }
        return result;
    }

    // LC647 - PALINDROMIC SUBSTRINGS
    /**
     * APPROACH: Expand around each center (same as LC5)
     *   Count each palindrome found
     * TIME: O(n²)  SPACE: O(1)
     * EXAMPLE: "aaa" → 6
     */
    static int countSubstrings(String s) {
        int count = 0;
        for (int i = 0; i < s.length(); i++) {
            // Odd
            for (int l=i, r=i; l>=0&&r<s.length()&&s.charAt(l)==s.charAt(r); l--,r++) count++;
            // Even
            for (int l=i, r=i+1; l>=0&&r<s.length()&&s.charAt(l)==s.charAt(r); l--,r++) count++;
        }
        return count;
    }

    // GFG - ROMAN TO INTEGER
    static int romanToInt(String s) {
        Map<Character, Integer> map = Map.of('I',1,'V',5,'X',10,'L',50,'C',100,'D',500,'M',1000);
        int result = 0;
        for (int i = 0; i < s.length(); i++) {
            int cur = map.get(s.charAt(i));
            int next = (i+1 < s.length()) ? map.get(s.charAt(i+1)) : 0;
            result += (cur < next) ? -cur : cur;
        }
        return result;
    }

    // GFG - LONGEST COMMON PREFIX
    /**
     * APPROACH: Vertical scan — compare char by char across all strings
     * TIME: O(n*m)  SPACE: O(1)
     */
    static String longestCommonPrefix(String[] strs) {
        if (strs.length == 0) return "";
        for (int i = 0; i < strs[0].length(); i++) {
            char c = strs[0].charAt(i);
            for (String s : strs) {
                if (i >= s.length() || s.charAt(i) != c) return strs[0].substring(0, i);
            }
        }
        return strs[0];
    }

    // GFG - IMPLEMENT ATOI
    /**
     * APPROACH: Handle whitespace, sign, digits, overflow
     * EXAMPLE: "  -42" → -42
     */
    static int myAtoi(String s) {
        int i = 0, n = s.length(), sign = 1;
        long result = 0;
        while (i < n && s.charAt(i) == ' ') i++;
        if (i < n && (s.charAt(i) == '+' || s.charAt(i) == '-'))
            sign = s.charAt(i++) == '-' ? -1 : 1;
        while (i < n && Character.isDigit(s.charAt(i))) {
            result = result * 10 + (s.charAt(i++) - '0');
            if (result * sign > Integer.MAX_VALUE) return Integer.MAX_VALUE;
            if (result * sign < Integer.MIN_VALUE) return Integer.MIN_VALUE;
        }
        return (int)(result * sign);
    }

    // GFG - COUNT AND SAY
    /**
     * APPROACH: For each term, count consecutive digits and describe
     * EXAMPLE: n=4 → "1211" (1→11→21→1211)
     */
    static String countAndSay(int n) {
        String cur = "1";
        for (int i = 1; i < n; i++) {
            StringBuilder next = new StringBuilder();
            int j = 0;
            while (j < cur.length()) {
                char c = cur.charAt(j); int count = 0;
                while (j < cur.length() && cur.charAt(j) == c) { count++; j++; }
                next.append(count).append(c);
            }
            cur = next.toString();
        }
        return cur;
    }

    // GFG - ISOMORPHIC STRINGS
    /**
     * APPROACH: Two maps — char in s maps to char in t and vice versa
     * EXAMPLE: "egg","add" → true  |  "foo","bar" → false
     */
    static boolean isIsomorphic(String s, String t) {
        Map<Character,Character> sToT = new HashMap<>(), tToS = new HashMap<>();
        for (int i = 0; i < s.length(); i++) {
            char sc = s.charAt(i), tc = t.charAt(i);
            if (sToT.containsKey(sc) && sToT.get(sc) != tc) return false;
            if (tToS.containsKey(tc) && tToS.get(tc) != sc) return false;
            sToT.put(sc, tc); tToS.put(tc, sc);
        }
        return true;
    }

    // GFG - RABIN-KARP PATTERN SEARCH
    /**
     * APPROACH: Rolling hash — compute hash of pattern and each window
     *   On hash match, verify character by character
     * TIME: O(n+m) avg  SPACE: O(1)
     */
    static List<Integer> rabinKarp(String text, String pattern) {
        List<Integer> result = new ArrayList<>();
        int n = text.length(), m = pattern.length();
        if (m > n) return result;
        int d = 256, q = 101; // base and prime
        int h = 1, pHash = 0, tHash = 0;
        for (int i = 0; i < m - 1; i++) h = (h * d) % q;
        for (int i = 0; i < m; i++) {
            pHash = (d * pHash + pattern.charAt(i)) % q;
            tHash = (d * tHash + text.charAt(i)) % q;
        }
        for (int i = 0; i <= n - m; i++) {
            if (pHash == tHash) {
                if (text.substring(i, i+m).equals(pattern)) result.add(i);
            }
            if (i < n - m) {
                tHash = (d * (tHash - text.charAt(i) * h) + text.charAt(i+m)) % q;
                if (tHash < 0) tHash += q;
            }
        }
        return result;
    }

    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║       STRING PROBLEMS - ALL SOLUTIONS    ║");
        System.out.println("╚══════════════════════════════════════════╝\n");
        System.out.println("LC3   longestSubstring(\"abcabcbb\")     = " + lengthOfLongestSubstring("abcabcbb"));
        System.out.println("LC5   longestPalindrome(\"babad\")       = " + longestPalindrome("babad"));
        System.out.println("LC20  isValid(\"()[]{}\")               = " + isValid("()[]{}"));
        System.out.println("LC28  strStr(\"hello\",\"ll\")           = " + strStr("hello","ll"));
        System.out.println("LC49  groupAnagrams                    = " + groupAnagrams(new String[]{"eat","tea","tan","ate","nat","bat"}));
        System.out.println("LC76  minWindow(ADOBECODEBANC,ABC)     = " + minWindow("ADOBECODEBANC","ABC"));
        System.out.println("LC125 isPalindrome(A man...Panama)     = " + isPalindrome("A man, a plan, a canal: Panama"));
        System.out.println("LC151 reverseWords(\"  hello world  \") = " + reverseWords("  hello world  "));
        System.out.println("LC242 isAnagram(anagram,nagaram)       = " + isAnagram("anagram","nagaram"));
        System.out.println("LC387 firstUniqChar(\"leetcode\")       = " + firstUniqChar("leetcode"));
        System.out.println("LC438 findAnagrams(cbaebabacd,abc)     = " + findAnagrams("cbaebabacd","abc"));
        System.out.println("LC647 countSubstrings(\"aaa\")          = " + countSubstrings("aaa"));
        System.out.println("GFG   romanToInt(\"MCMXCIV\")           = " + romanToInt("MCMXCIV"));
        System.out.println("GFG   longestCommonPrefix              = " + longestCommonPrefix(new String[]{"flower","flow","flight"}));
        System.out.println("GFG   myAtoi(\"  -42\")                 = " + myAtoi("  -42"));
        System.out.println("GFG   countAndSay(5)                   = " + countAndSay(5));
        System.out.println("GFG   isIsomorphic(egg,add)            = " + isIsomorphic("egg","add"));
        System.out.println("GFG   rabinKarp(AABAACAADAABAABA,AABA) = " + rabinKarp("AABAACAADAABAABA","AABA"));
    }
}
