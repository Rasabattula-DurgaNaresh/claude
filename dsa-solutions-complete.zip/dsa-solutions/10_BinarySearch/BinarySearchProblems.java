/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║      BINARY SEARCH - LeetCode & GeeksForGeeks Solutions      ║
 * ╚══════════════════════════════════════════════════════════════╝
 * LC33  Search in Rotated Sorted Array
 * LC34  First and Last Position of Element
 * LC35  Search Insert Position
 * LC69  Sqrt(x)
 * LC74  Search a 2D Matrix
 * LC81  Search in Rotated Array II (with dups)
 * LC153 Find Minimum in Rotated Array
 * LC154 Find Min in Rotated Array II
 * LC162 Find Peak Element
 * LC240 Search a 2D Matrix II
 * LC275 H-Index II
 * LC278 First Bad Version
 * LC287 Find the Duplicate Number (Floyd's)
 * LC374 Guess Number Higher or Lower
 * LC410 Split Array Largest Sum
 * LC441 Arranging Coins
 * LC475 Heaters
 * LC540 Single Element in Sorted Array
 * LC644 Maximum Average Subarray II
 * LC774 Minimize Max Distance to Gas Station
 * GFG   Aggressive Cows
 * GFG   Books Allocation
 * GFG   Koko Eating Bananas
 */
import java.util.*;

public class BinarySearchProblems {

    // LC35 - SEARCH INSERT POSITION
    /**
     * APPROACH: Find leftmost position where nums[pos] >= target
     * TIME: O(log n)
     */
    static int searchInsert(int[] nums, int target) {
        int l=0, r=nums.length;
        while (l<r) { int m=l+(r-l)/2; if(nums[m]<target) l=m+1; else r=m; }
        return l;
    }

    // LC34 - FIRST AND LAST POSITION
    static int[] searchRange(int[] nums, int target) {
        return new int[]{findBound(nums,target,true), findBound(nums,target,false)};
    }
    static int findBound(int[] nums, int target, boolean first) {
        int l=0, r=nums.length-1, idx=-1;
        while (l<=r) {
            int m=l+(r-l)/2;
            if (nums[m]==target) { idx=m; if(first) r=m-1; else l=m+1; }
            else if (nums[m]<target) l=m+1; else r=m-1;
        }
        return idx;
    }

    // LC69 - SQRT(X) (integer floor)
    static int mySqrt(int x) {
        if (x<2) return x;
        int l=1, r=x/2;
        while (l<=r) { long m=l+(r-l)/2; if(m*m==x) return (int)m; if(m*m<x) l=(int)m+1; else r=(int)m-1; }
        return r;
    }

    // LC74 - SEARCH 2D MATRIX (rows sorted, last element < first of next row)
    /**
     * APPROACH: Treat as 1D sorted array; map index to row/col
     * TIME: O(log(m*n))
     */
    static boolean searchMatrix(int[][] matrix, int target) {
        int m=matrix.length, n=matrix[0].length, l=0, r=m*n-1;
        while (l<=r) {
            int mid=l+(r-l)/2, val=matrix[mid/n][mid%n];
            if (val==target) return true; if (val<target) l=mid+1; else r=mid-1;
        }
        return false;
    }

    // LC162 - FIND PEAK ELEMENT
    /**
     * APPROACH: If mid < mid+1, peak is to the right; else to the left
     * TIME: O(log n)
     */
    static int findPeakElement(int[] nums) {
        int l=0, r=nums.length-1;
        while (l<r) { int m=l+(r-l)/2; if(nums[m]<nums[m+1]) l=m+1; else r=m; }
        return l;
    }

    // LC278 - FIRST BAD VERSION
    static int firstBadVersion(int n, int bad) {
        int l=1, r=n;
        while (l<r) { int m=l+(r-l)/2; if(m>=bad) r=m; else l=m+1; }
        return l;
    }

    // LC540 - SINGLE ELEMENT IN SORTED ARRAY
    /**
     * APPROACH: Pairs should be at (even,odd) indices
     *   If nums[mid]==nums[mid^1], single is to the right
     * TIME: O(log n)
     */
    static int singleNonDuplicate(int[] nums) {
        int l=0, r=nums.length-1;
        while (l<r) {
            int m=l+(r-l)/2;
            if (nums[m]==nums[m^1]) l=m+1; else r=m;
        }
        return nums[l];
    }

    // LC410 - SPLIT ARRAY LARGEST SUM
    /**
     * APPROACH: Binary search on answer (min possible largest sum)
     *   Check: can we split into m parts with each <= mid?
     * TIME: O(n log(sum))
     */
    static int splitArray(int[] nums, int m) {
        int l=Arrays.stream(nums).max().getAsInt(), r=Arrays.stream(nums).sum();
        while (l<r) {
            int mid=l+(r-l)/2;
            if (canSplit(nums,m,mid)) r=mid; else l=mid+1;
        }
        return l;
    }
    static boolean canSplit(int[] nums, int m, int maxSum) {
        int parts=1, curSum=0;
        for (int n:nums) {
            if (curSum+n>maxSum) { parts++; curSum=0; }
            curSum+=n;
        }
        return parts<=m;
    }

    // LC475 - HEATERS
    /**
     * APPROACH: For each house, binary search for nearest heater
     * TIME: O((n+m) log m)
     */
    static int findRadius(int[] houses, int[] heaters) {
        Arrays.sort(heaters); int radius=0;
        for (int house:houses) {
            int pos=Arrays.binarySearch(heaters,house);
            if (pos<0) pos=-pos-1;
            int dist=Integer.MAX_VALUE;
            if (pos<heaters.length) dist=Math.min(dist, heaters[pos]-house);
            if (pos>0) dist=Math.min(dist, house-heaters[pos-1]);
            radius=Math.max(radius,dist);
        }
        return radius;
    }

    // GFG - AGGRESSIVE COWS (max min distance)
    /**
     * APPROACH: Binary search on minimum distance between cows
     *   Check: can we place k cows with at least mid distance?
     * TIME: O(n log n + n log(max))
     */
    static int aggressiveCows(int[] stalls, int k) {
        Arrays.sort(stalls);
        int l=1, r=stalls[stalls.length-1]-stalls[0];
        while (l<r) {
            int mid=l+(r-l+1)/2;
            if (canPlace(stalls,k,mid)) l=mid; else r=mid-1;
        }
        return l;
    }
    static boolean canPlace(int[] stalls, int k, int minDist) {
        int count=1, last=stalls[0];
        for (int i=1;i<stalls.length;i++) {
            if (stalls[i]-last>=minDist) { count++; last=stalls[i]; if(count>=k) return true; }
        }
        return false;
    }

    // GFG - BOOK ALLOCATION (minimize max pages)
    /**
     * APPROACH: Binary search on answer (max pages assigned)
     *   Check: can we allocate to k students with each <= mid pages?
     * TIME: O(n log(sum))
     */
    static int allocateBooks(int[] pages, int students) {
        int l=Arrays.stream(pages).max().getAsInt(), r=Arrays.stream(pages).sum();
        while (l<r) {
            int mid=l+(r-l)/2;
            if (canAllocate(pages,students,mid)) r=mid; else l=mid+1;
        }
        return l;
    }
    static boolean canAllocate(int[] pages, int students, int maxPages) {
        int count=1, cur=0;
        for (int p:pages) {
            if (p>maxPages) return false;
            if (cur+p>maxPages) { count++; cur=0; }
            cur+=p;
        }
        return count<=students;
    }

    // LC240 - SEARCH 2D MATRIX II (rows and cols each sorted)
    /**
     * APPROACH: Start from top-right corner
     *   If val>target: go left  |  If val<target: go down
     * TIME: O(m+n)
     */
    static boolean searchMatrixII(int[][] matrix, int target) {
        int r=0, c=matrix[0].length-1;
        while (r<matrix.length&&c>=0) {
            if (matrix[r][c]==target) return true;
            if (matrix[r][c]>target) c--; else r++;
        }
        return false;
    }

    // Koko Eating Bananas (binary search on eating speed)
    static int minEatingSpeed(int[] piles, int h) {
        int l=1, r=Arrays.stream(piles).max().getAsInt();
        while (l<r) {
            int mid=l+(r-l)/2;
            long hours=0; for(int p:piles) hours+=(p+mid-1)/mid;
            if (hours<=h) r=mid; else l=mid+1;
        }
        return l;
    }

    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║   BINARY SEARCH PROBLEMS - ALL SOLUTIONS ║");
        System.out.println("╚══════════════════════════════════════════╝\n");
        System.out.println("LC35  searchInsert([1,3,5,6],5)         = " + searchInsert(new int[]{1,3,5,6},5));
        System.out.println("LC34  searchRange([5,7,7,8,8,10],8)     = " + Arrays.toString(searchRange(new int[]{5,7,7,8,8,10},8)));
        System.out.println("LC69  mySqrt(8)                         = " + mySqrt(8));
        System.out.println("LC74  searchMatrix(target=3)            = " + searchMatrix(new int[][]{{1,3,5,7},{10,11,16,20},{23,30,34,60}},3));
        System.out.println("LC162 findPeak([1,2,3,1])               = " + findPeakElement(new int[]{1,2,3,1}));
        System.out.println("LC278 firstBadVersion(n=5,bad=4)        = " + firstBadVersion(5,4));
        System.out.println("LC540 singleNonDuplicate([1,1,2,3,3,4,4,8,8]) = " + singleNonDuplicate(new int[]{1,1,2,3,3,4,4,8,8}));
        System.out.println("LC410 splitArray([7,2,5,10,8],2)        = " + splitArray(new int[]{7,2,5,10,8},2));
        System.out.println("LC475 findRadius([1,2,3],[2])            = " + findRadius(new int[]{1,2,3},new int[]{2}));
        System.out.println("LC240 searchMatrixII(target=5)          = " + searchMatrixII(new int[][]{{1,4,7,11},{2,5,8,12},{3,6,9,16},{10,13,14,17}},5));
        System.out.println("GFG   aggressiveCows([2,4,12,16],3)     = " + aggressiveCows(new int[]{2,4,12,16},3));
        System.out.println("GFG   allocateBooks([12,34,67,90],2)    = " + allocateBooks(new int[]{12,34,67,90},2));
        System.out.println("GFG   kokoEating([3,6,7,11],8)          = " + minEatingSpeed(new int[]{3,6,7,11},8));
    }
}
