/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║          HEAPS - LeetCode & GeeksForGeeks Solutions          ║
 * ╚══════════════════════════════════════════════════════════════╝
 * LC215  Kth Largest Element in Array
 * LC295  Find Median from Data Stream
 * LC347  Top K Frequent Elements
 * LC373  Find K Pairs with Smallest Sums
 * LC378  Kth Smallest in Sorted Matrix
 * LC407  Trapping Rain Water II
 * LC451  Sort Characters by Frequency
 * LC480  Sliding Window Median
 * LC502  IPO (Maximize Capital)
 * LC621  Task Scheduler
 * LC630  Course Schedule III
 * LC632  Smallest Range Covering K Lists
 * LC658  Find K Closest Elements
 * LC692  Top K Frequent Words
 * LC703  Kth Largest in Stream
 * LC767  Reorganize String
 * LC857  Minimum Cost to Hire K Workers
 * LC973  K Closest Points to Origin
 * GFG    Merge K Sorted Arrays
 * GFG    Binary Heap Implementation
 */
import java.util.*;

public class HeapProblems {

    // ─── BINARY HEAP IMPLEMENTATION ────────────────────────────────
    /**
     * Manual Min-Heap implementation to understand internals
     * Parent at i → children at 2i+1 and 2i+2
     * Heap property: parent <= children (min-heap)
     */
    static class MinHeap {
        int[] data; int size;
        MinHeap(int capacity) { data = new int[capacity]; size = 0; }

        void insert(int val) {
            data[size++] = val;
            siftUp(size - 1);
        }
        int extractMin() {
            int min = data[0];
            data[0] = data[--size];
            siftDown(0);
            return min;
        }
        int peek() { return data[0]; }
        boolean isEmpty() { return size == 0; }

        void siftUp(int i) {
            while (i > 0) {
                int parent = (i - 1) / 2;
                if (data[parent] <= data[i]) break;
                int t = data[i]; data[i] = data[parent]; data[parent] = t;
                i = parent;
            }
        }
        void siftDown(int i) {
            while (2*i+1 < size) {
                int smallest = i, l = 2*i+1, r = 2*i+2;
                if (l < size && data[l] < data[smallest]) smallest = l;
                if (r < size && data[r] < data[smallest]) smallest = r;
                if (smallest == i) break;
                int t = data[i]; data[i] = data[smallest]; data[smallest] = t;
                i = smallest;
            }
        }
    }

    // LC215 - KTH LARGEST ELEMENT IN ARRAY
    /**
     * APPROACH: Min-heap of size k
     *   Keep only k largest elements. Min of heap = kth largest.
     * TIME: O(n log k)  SPACE: O(k)
     * EXAMPLE: [3,2,1,5,6,4], k=2 → 5
     */
    static int findKthLargest(int[] nums, int k) {
        PriorityQueue<Integer> minHeap = new PriorityQueue<>();
        for (int n : nums) {
            minHeap.offer(n);
            if (minHeap.size() > k) minHeap.poll(); // remove smallest
        }
        return minHeap.peek(); // smallest of k largest = kth largest
    }

    // LC295 - FIND MEDIAN FROM DATA STREAM
    /**
     * APPROACH: Two heaps - maxHeap (lower half) + minHeap (upper half)
     *   Balance: maxHeap.size() == minHeap.size() OR maxHeap.size() == minHeap.size()+1
     *   Median: maxHeap.peek() if odd total, else average of both tops
     * TIME: O(log n) addNum, O(1) findMedian
     */
    static class MedianFinder {
        PriorityQueue<Integer> maxHeap = new PriorityQueue<>(Collections.reverseOrder()); // lower half
        PriorityQueue<Integer> minHeap = new PriorityQueue<>();                           // upper half

        void addNum(int num) {
            maxHeap.offer(num);                    // always add to lower half first
            minHeap.offer(maxHeap.poll());         // move max of lower to upper
            if (minHeap.size() > maxHeap.size())  // rebalance: lower >= upper
                maxHeap.offer(minHeap.poll());
        }

        double findMedian() {
            return maxHeap.size() > minHeap.size()
                ? maxHeap.peek()
                : (maxHeap.peek() + minHeap.peek()) / 2.0;
        }
    }

    // LC347 - TOP K FREQUENT ELEMENTS
    /**
     * APPROACH: Bucket sort by frequency — O(n) solution
     *   freq[count] stores elements with that frequency
     * TIME: O(n)  SPACE: O(n)
     * EXAMPLE: [1,1,1,2,2,3], k=2 → [1,2]
     */
    static int[] topKFrequent(int[] nums, int k) {
        Map<Integer, Integer> freq = new HashMap<>();
        for (int n : nums) freq.merge(n, 1, Integer::sum);
        @SuppressWarnings("unchecked")
        List<Integer>[] bucket = new List[nums.length + 1];
        for (int i = 0; i <= nums.length; i++) bucket[i] = new ArrayList<>();
        for (Map.Entry<Integer,Integer> e : freq.entrySet())
            bucket[e.getValue()].add(e.getKey());
        int[] result = new int[k]; int idx = 0;
        for (int i = nums.length; i >= 0 && idx < k; i--)
            for (int n : bucket[i]) if (idx < k) result[idx++] = n;
        return result;
    }

    // LC692 - TOP K FREQUENT WORDS
    /**
     * APPROACH: Min-heap sorted by (frequency asc, lexicographic desc)
     *   So smallest-frequency / lexicographically-last gets evicted first
     * TIME: O(n log k)  SPACE: O(n)
     */
    static List<String> topKFrequentWords(String[] words, int k) {
        Map<String, Integer> freq = new HashMap<>();
        for (String w : words) freq.merge(w, 1, Integer::sum);
        // Min-heap: lowest freq first; on tie, lexicographically larger first (to be removed)
        PriorityQueue<String> heap = new PriorityQueue<>((a, b) ->
            freq.get(a).equals(freq.get(b)) ? b.compareTo(a) : freq.get(a) - freq.get(b));
        for (String w : freq.keySet()) {
            heap.offer(w);
            if (heap.size() > k) heap.poll();
        }
        List<String> result = new ArrayList<>();
        while (!heap.isEmpty()) result.add(0, heap.poll()); // reverse order
        return result;
    }

    // LC703 - KTH LARGEST ELEMENT IN STREAM
    /**
     * APPROACH: Maintain min-heap of size k
     *   Heap always contains k largest seen so far
     *   Top of heap = kth largest
     */
    static class KthLargest {
        PriorityQueue<Integer> minHeap;
        int k;
        KthLargest(int k, int[] nums) {
            this.k = k;
            minHeap = new PriorityQueue<>();
            for (int n : nums) add(n);
        }
        int add(int val) {
            minHeap.offer(val);
            if (minHeap.size() > k) minHeap.poll();
            return minHeap.peek();
        }
    }

    // LC973 - K CLOSEST POINTS TO ORIGIN
    /**
     * APPROACH: Max-heap of size k (by distance)
     *   Remove farthest when size exceeds k
     * TIME: O(n log k)  SPACE: O(k)
     * EXAMPLE: [[1,3],[-2,2]], k=1 → [[-2,2]]
     */
    static int[][] kClosest(int[][] points, int k) {
        PriorityQueue<int[]> maxHeap = new PriorityQueue<>(
            (a, b) -> (b[0]*b[0]+b[1]*b[1]) - (a[0]*a[0]+a[1]*a[1]));
        for (int[] p : points) {
            maxHeap.offer(p);
            if (maxHeap.size() > k) maxHeap.poll();
        }
        return maxHeap.toArray(new int[0][]);
    }

    // LC451 - SORT CHARACTERS BY FREQUENCY
    /**
     * APPROACH: Frequency map + max-heap
     * TIME: O(n log n)  SPACE: O(n)
     * EXAMPLE: "tree" → "eert" or "eetr"
     */
    static String frequencySort(String s) {
        Map<Character, Integer> freq = new HashMap<>();
        for (char c : s.toCharArray()) freq.merge(c, 1, Integer::sum);
        PriorityQueue<Map.Entry<Character,Integer>> maxH =
            new PriorityQueue<>((a,b) -> b.getValue() - a.getValue());
        maxH.addAll(freq.entrySet());
        StringBuilder sb = new StringBuilder();
        while (!maxH.isEmpty()) {
            Map.Entry<Character,Integer> e = maxH.poll();
            sb.append(String.valueOf(e.getKey()).repeat(e.getValue()));
        }
        return sb.toString();
    }

    // LC767 - REORGANIZE STRING (no adjacent same chars)
    /**
     * APPROACH: Greedy with max-heap
     *   Always place two most frequent different chars
     * TIME: O(n log 26)  SPACE: O(26)
     * EXAMPLE: "aab" → "aba"  |  "aaab" → "" (impossible)
     */
    static String reorganizeString(String s) {
        int[] freq = new int[26];
        for (char c : s.toCharArray()) freq[c-'a']++;
        PriorityQueue<int[]> maxH = new PriorityQueue<>((a,b) -> b[1]-a[1]);
        for (int i = 0; i < 26; i++) if (freq[i] > 0) maxH.offer(new int[]{i, freq[i]});
        StringBuilder sb = new StringBuilder();
        while (maxH.size() >= 2) {
            int[] a = maxH.poll(), b = maxH.poll();
            sb.append((char)('a'+a[0])).append((char)('a'+b[0]));
            if (--a[1] > 0) maxH.offer(a);
            if (--b[1] > 0) maxH.offer(b);
        }
        if (!maxH.isEmpty()) {
            if (maxH.peek()[1] > 1) return ""; // impossible
            sb.append((char)('a'+maxH.poll()[0]));
        }
        return sb.toString();
    }

    // LC378 - KTH SMALLEST IN SORTED MATRIX
    /**
     * APPROACH: Min-heap treating each row as sorted list
     *   Start with first element of each row, expand right
     * TIME: O(k log n)  SPACE: O(n)
     */
    static int kthSmallest(int[][] matrix, int k) {
        int n = matrix.length;
        PriorityQueue<int[]> minH = new PriorityQueue<>(Comparator.comparingInt(a -> a[0]));
        for (int i = 0; i < Math.min(n, k); i++) minH.offer(new int[]{matrix[i][0], i, 0});
        int result = 0;
        for (int i = 0; i < k; i++) {
            int[] cur = minH.poll(); result = cur[0];
            if (cur[2]+1 < n) minH.offer(new int[]{matrix[cur[1]][cur[2]+1], cur[1], cur[2]+1});
        }
        return result;
    }

    // LC658 - FIND K CLOSEST ELEMENTS
    /**
     * APPROACH: Binary search for optimal window start
     *   Shrink from left if right endpoint is closer to x
     * TIME: O(log(n-k))  SPACE: O(1)
     */
    static List<Integer> findClosestElements(int[] arr, int k, int x) {
        int l = 0, r = arr.length - k;
        while (l < r) {
            int mid = l + (r-l)/2;
            if (x - arr[mid] > arr[mid+k] - x) l = mid+1; else r = mid;
        }
        List<Integer> result = new ArrayList<>();
        for (int i = l; i < l+k; i++) result.add(arr[i]);
        return result;
    }

    // LC621 - TASK SCHEDULER
    /**
     * APPROACH: Math formula
     *   maxFreq = highest frequency task count
     *   maxCount = how many tasks have maxFreq
     *   result = max(n * tasks.length, (maxFreq-1)*(n+1) + maxCount)
     * TIME: O(n)  SPACE: O(1)
     */
    static int leastInterval(char[] tasks, int n) {
        int[] freq = new int[26]; for (char c : tasks) freq[c-'A']++;
        int maxFreq = 0; for (int f : freq) maxFreq = Math.max(maxFreq, f);
        int maxCount = 0; for (int f : freq) if (f == maxFreq) maxCount++;
        return Math.max(tasks.length, (maxFreq-1)*(n+1) + maxCount);
    }

    // LC630 - COURSE SCHEDULE III (max courses within deadlines)
    /**
     * APPROACH: Greedy + max-heap
     *   Sort by deadline. Always take shortest duration courses in heap.
     *   If total time exceeds deadline, replace longest (top of maxHeap)
     * TIME: O(n log n)
     */
    static int scheduleCourse(int[][] courses) {
        Arrays.sort(courses, (a,b) -> a[1]-b[1]); // sort by deadline
        PriorityQueue<Integer> maxH = new PriorityQueue<>(Collections.reverseOrder());
        int time = 0;
        for (int[] c : courses) {
            time += c[0]; maxH.offer(c[0]);
            if (time > c[1]) time -= maxH.poll(); // remove longest taken course
        }
        return maxH.size();
    }

    // LC502 - IPO (MAXIMIZE CAPITAL)
    /**
     * APPROACH: Two heaps
     *   minCapital heap: sort by required capital
     *   maxProfit heap: unlocked projects by profit
     *   Each round: unlock affordable projects, take max profit one
     * TIME: O(n log n)  SPACE: O(n)
     */
    static int findMaximizedCapital(int k, int w, int[] profits, int[] capital) {
        int n = profits.length;
        PriorityQueue<int[]> minCap = new PriorityQueue<>(Comparator.comparingInt(a->a[0]));
        PriorityQueue<Integer> maxProfit = new PriorityQueue<>(Collections.reverseOrder());
        for (int i = 0; i < n; i++) minCap.offer(new int[]{capital[i], profits[i]});
        for (int i = 0; i < k; i++) {
            while (!minCap.isEmpty() && minCap.peek()[0] <= w) maxProfit.offer(minCap.poll()[1]);
            if (maxProfit.isEmpty()) break;
            w += maxProfit.poll();
        }
        return w;
    }

    // LC480 - SLIDING WINDOW MEDIAN
    /**
     * APPROACH: Two heaps + manual removal
     *   Maintain maxHeap (lower) + minHeap (upper), sliding window
     * TIME: O(n log k)  SPACE: O(k)
     */
    static double[] medianSlidingWindow(int[] nums, int k) {
        PriorityQueue<Integer> maxH = new PriorityQueue<>(Collections.reverseOrder());
        PriorityQueue<Integer> minH = new PriorityQueue<>();
        double[] result = new double[nums.length - k + 1];

        for (int i = 0; i < nums.length; i++) {
            // Add
            if (maxH.isEmpty() || nums[i] <= maxH.peek()) maxH.offer(nums[i]);
            else minH.offer(nums[i]);
            // Rebalance
            while (maxH.size() > minH.size()+1) minH.offer(maxH.poll());
            while (minH.size() > maxH.size())   maxH.offer(minH.poll());
            // Record median for full windows
            if (i >= k-1) {
                result[i-k+1] = maxH.size() > minH.size()
                    ? maxH.peek()
                    : (maxH.peek()/2.0 + minH.peek()/2.0);
                // Remove outgoing element
                int outgoing = nums[i-k+1];
                if (outgoing <= maxH.peek()) maxH.remove(outgoing);
                else minH.remove(outgoing);
                // Rebalance after removal
                while (maxH.size() > minH.size()+1) minH.offer(maxH.poll());
                while (minH.size() > maxH.size())   maxH.offer(minH.poll());
            }
        }
        return result;
    }

    // GFG - MERGE K SORTED ARRAYS
    /**
     * APPROACH: Min-heap with (value, arrayIndex, elementIndex)
     * TIME: O(n log k) where n = total elements
     */
    static int[] mergeKSortedArrays(int[][] arrays) {
        PriorityQueue<int[]> minH = new PriorityQueue<>(Comparator.comparingInt(a->a[0]));
        int total = 0;
        for (int i = 0; i < arrays.length; i++) {
            total += arrays[i].length;
            if (arrays[i].length > 0) minH.offer(new int[]{arrays[i][0], i, 0});
        }
        int[] result = new int[total]; int idx = 0;
        while (!minH.isEmpty()) {
            int[] cur = minH.poll(); result[idx++] = cur[0];
            int nextIdx = cur[2]+1;
            if (nextIdx < arrays[cur[1]].length)
                minH.offer(new int[]{arrays[cur[1]][nextIdx], cur[1], nextIdx});
        }
        return result;
    }

    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║       HEAP PROBLEMS - ALL SOLUTIONS      ║");
        System.out.println("╚══════════════════════════════════════════╝\n");

        // Binary Heap
        MinHeap heap = new MinHeap(10);
        for (int v : new int[]{5,3,8,1,9,2}) heap.insert(v);
        System.out.print("MinHeap extractAll: ");
        while (!heap.isEmpty()) System.out.print(heap.extractMin()+" ");
        System.out.println();

        System.out.println("LC215 kthLargest([3,2,1,5,6,4],k=2)      = " + findKthLargest(new int[]{3,2,1,5,6,4},2));

        MedianFinder mf = new MedianFinder();
        for (int n : new int[]{1,2,3,4,5}) mf.addNum(n);
        System.out.println("LC295 medianFinder(1..5)                  = " + mf.findMedian());

        System.out.println("LC347 topKFrequent([1,1,1,2,2,3],k=2)    = " + Arrays.toString(topKFrequent(new int[]{1,1,1,2,2,3},2)));
        System.out.println("LC692 topKFrequentWords                   = " + topKFrequentWords(new String[]{"i","love","leetcode","i","love","coding"},2));

        KthLargest kl = new KthLargest(3, new int[]{4,5,8,2});
        System.out.println("LC703 kthLargest stream add(3)            = " + kl.add(3));
        System.out.println("      kthLargest stream add(5)            = " + kl.add(5));

        System.out.println("LC973 kClosest([[1,3],[-2,2]],k=1)        = " + Arrays.deepToString(kClosest(new int[][]{{1,3},{-2,2}},1)));
        System.out.println("LC451 frequencySort(\"tree\")              = " + frequencySort("tree"));
        System.out.println("LC767 reorganizeString(\"aab\")            = " + reorganizeString("aab"));
        System.out.println("LC378 kthSmallest(k=8)                    = " + kthSmallest(new int[][]{{1,5,9},{10,11,13},{12,13,15}},8));
        System.out.println("LC658 findClosestElements(k=4,x=3)        = " + findClosestElements(new int[]{1,2,3,4,5},4,3));
        System.out.println("LC621 taskScheduler(n=2)                  = " + leastInterval(new char[]{'A','A','A','B','B','B'},2));
        System.out.println("LC630 scheduleCourse                      = " + scheduleCourse(new int[][]{{100,200},{200,1300},{1000,1250},{2000,3200}}));
        System.out.println("LC502 IPO(k=2,w=0)                        = " + findMaximizedCapital(2,0,new int[]{1,2,3},new int[]{0,1,1}));
        System.out.println("LC480 medianSlidingWindow(k=3)            = " + Arrays.toString(medianSlidingWindow(new int[]{1,3,-1,-3,5,3,6,7},3)));
        System.out.println("GFG   mergeKSortedArrays                  = " + Arrays.toString(mergeKSortedArrays(new int[][]{{1,3,5},{2,4,6},{7,8,9}})));
    }
}
