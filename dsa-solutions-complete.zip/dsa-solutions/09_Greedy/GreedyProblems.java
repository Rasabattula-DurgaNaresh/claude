/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║         GREEDY - LeetCode & GeeksForGeeks Solutions          ║
 * ╚══════════════════════════════════════════════════════════════╝
 * LC45  Jump Game II
 * LC55  Jump Game
 * LC122 Best Time to Buy/Sell Stock II
 * LC134 Gas Station
 * LC135 Candy
 * LC321 Create Maximum Number
 * LC330 Patching Array
 * LC376 Wiggle Subsequence
 * LC392 Is Subsequence
 * LC406 Queue Reconstruction by Height
 * LC435 Non-Overlapping Intervals
 * LC452 Min Arrows to Burst Balloons
 * LC455 Assign Cookies
 * LC484 Find Permutation
 * LC502 IPO (Maximize Capital)
 * LC621 Task Scheduler
 * LC763 Partition Labels
 * LC870 Advantage Shuffle
 * GFG   Fractional Knapsack
 * GFG   N meetings in One Room
 */
import java.util.*;

public class GreedyProblems {

    // LC55 - JUMP GAME
    /**
     * APPROACH: Track max reachable index
     *   If i > maxReach at any point → can't proceed
     * TIME: O(n)  SPACE: O(1)
     */
    static boolean canJump(int[] nums) {
        int maxReach = 0;
        for (int i=0; i<nums.length; i++) {
            if (i>maxReach) return false;
            maxReach = Math.max(maxReach, i+nums[i]);
        }
        return true;
    }

    // LC45 - JUMP GAME II (min jumps)
    /**
     * APPROACH: Track current window end and next window end
     *   When reaching current end, increment jumps, extend window
     * TIME: O(n)  SPACE: O(1)
     */
    static int jump(int[] nums) {
        int jumps=0, curEnd=0, farthest=0;
        for (int i=0; i<nums.length-1; i++) {
            farthest = Math.max(farthest, i+nums[i]);
            if (i==curEnd) { jumps++; curEnd=farthest; }
        }
        return jumps;
    }

    // LC122 - BEST TIME STOCK II (unlimited transactions)
    /**
     * APPROACH: Collect every uphill profit (add whenever price increases)
     * TIME: O(n)  SPACE: O(1)
     */
    static int maxProfitII(int[] prices) {
        int profit=0;
        for (int i=1; i<prices.length; i++) if (prices[i]>prices[i-1]) profit+=prices[i]-prices[i-1];
        return profit;
    }

    // LC134 - GAS STATION
    /**
     * APPROACH: If total gas >= total cost, solution exists
     *   Track start: if current fuel goes negative, new start is i+1
     * TIME: O(n)  SPACE: O(1)
     */
    static int canCompleteCircuit(int[] gas, int[] cost) {
        int total=0, curr=0, start=0;
        for (int i=0; i<gas.length; i++) {
            total += gas[i]-cost[i]; curr += gas[i]-cost[i];
            if (curr<0) { start=i+1; curr=0; }
        }
        return total>=0 ? start : -1;
    }

    // LC135 - CANDY
    /**
     * APPROACH: Two passes
     *   Left to right: give more if higher than left neighbor
     *   Right to left: give more if higher than right neighbor
     * TIME: O(n)  SPACE: O(n)
     */
    static int candy(int[] ratings) {
        int n=ratings.length;
        int[] candies=new int[n]; Arrays.fill(candies,1);
        for (int i=1;i<n;i++) if (ratings[i]>ratings[i-1]) candies[i]=candies[i-1]+1;
        for (int i=n-2;i>=0;i--) if (ratings[i]>ratings[i+1]) candies[i]=Math.max(candies[i],candies[i+1]+1);
        return Arrays.stream(candies).sum();
    }

    // LC455 - ASSIGN COOKIES
    /**
     * APPROACH: Sort both. Two pointers — greedily assign smallest sufficient cookie
     * TIME: O(n log n)  SPACE: O(1)
     */
    static int findContentChildren(int[] g, int[] s) {
        Arrays.sort(g); Arrays.sort(s);
        int child=0, cookie=0;
        while (child<g.length&&cookie<s.length) {
            if (s[cookie]>=g[child]) child++;
            cookie++;
        }
        return child;
    }

    // LC435 - NON-OVERLAPPING INTERVALS (min removals)
    /**
     * APPROACH: Sort by end time, greedily keep non-overlapping
     *   Count removed = total - kept
     * TIME: O(n log n)  SPACE: O(1)
     */
    static int eraseOverlapIntervals(int[][] intervals) {
        Arrays.sort(intervals,(a,b)->a[1]-b[1]);
        int count=1, end=intervals[0][1];
        for (int i=1;i<intervals.length;i++) {
            if (intervals[i][0]>=end) { count++; end=intervals[i][1]; }
        }
        return intervals.length-count;
    }

    // LC452 - MINIMUM ARROWS TO BURST BALLOONS
    /**
     * APPROACH: Sort by end, single arrow can burst all overlapping balloons
     * TIME: O(n log n)  SPACE: O(1)
     */
    static int findMinArrowShots(int[][] points) {
        Arrays.sort(points,(a,b)->Integer.compare(a[1],b[1]));
        int arrows=1, end=points[0][1];
        for (int i=1;i<points.length;i++) if (points[i][0]>end) { arrows++; end=points[i][1]; }
        return arrows;
    }

    // LC763 - PARTITION LABELS
    /**
     * APPROACH: Track last occurrence of each char
     *   Extend current partition's end as we go
     *   When i == end, partition is complete
     * TIME: O(n)  SPACE: O(1)
     */
    static List<Integer> partitionLabels(String s) {
        int[] last=new int[26];
        for (int i=0;i<s.length();i++) last[s.charAt(i)-'a']=i;
        List<Integer> result=new ArrayList<>();
        int start=0, end=0;
        for (int i=0;i<s.length();i++) {
            end=Math.max(end, last[s.charAt(i)-'a']);
            if (i==end) { result.add(end-start+1); start=i+1; }
        }
        return result;
    }

    // LC621 - TASK SCHEDULER
    /**
     * APPROACH: Max-heap of task frequencies
     *   Fill a cycle of n+1 slots greedily with most frequent tasks
     * TIME: O(n)  SPACE: O(1) (26 chars)
     */
    static int leastInterval(char[] tasks, int n) {
        int[] freq=new int[26]; for (char c:tasks) freq[c-'A']++;
        PriorityQueue<Integer> maxH=new PriorityQueue<>(Collections.reverseOrder());
        for (int f:freq) if(f>0) maxH.offer(f);
        int time=0;
        while (!maxH.isEmpty()) {
            List<Integer> tmp=new ArrayList<>();
            for (int i=0;i<=n;i++) { if(!maxH.isEmpty()) tmp.add(maxH.poll()-1); }
            for (int t:tmp) if(t>0) maxH.offer(t);
            time+=maxH.isEmpty()?tmp.size():n+1;
        }
        return time;
    }

    // LC376 - WIGGLE SUBSEQUENCE
    /**
     * APPROACH: Count direction changes
     * TIME: O(n)  SPACE: O(1)
     */
    static int wiggleMaxLength(int[] nums) {
        if (nums.length<2) return nums.length;
        int up=1, down=1;
        for (int i=1;i<nums.length;i++) {
            if (nums[i]>nums[i-1]) up=down+1;
            else if (nums[i]<nums[i-1]) down=up+1;
        }
        return Math.max(up,down);
    }

    // LC392 - IS SUBSEQUENCE
    static boolean isSubsequence(String s, String t) {
        int i=0,j=0;
        while (i<s.length()&&j<t.length()) { if (s.charAt(i)==t.charAt(j)) i++; j++; }
        return i==s.length();
    }

    // LC406 - QUEUE RECONSTRUCTION BY HEIGHT
    /**
     * APPROACH: Sort by height desc (tie: k asc), then insert each person at index k
     * TIME: O(n²)  SPACE: O(n)
     */
    static int[][] reconstructQueue(int[][] people) {
        Arrays.sort(people,(a,b)->a[0]==b[0]?a[1]-b[1]:b[0]-a[0]);
        List<int[]> result=new ArrayList<>();
        for (int[] p:people) result.add(p[1],p);
        return result.toArray(new int[0][]);
    }

    // GFG - FRACTIONAL KNAPSACK
    static double fractionalKnapsack(int capacity, int[] weights, int[] values) {
        Integer[] idx=new Integer[weights.length];
        for (int i=0;i<idx.length;i++) idx[i]=i;
        Arrays.sort(idx,(a,b)->Double.compare((double)values[b]/weights[b],(double)values[a]/weights[a]));
        double total=0; int rem=capacity;
        for (int i:idx) {
            if (rem>=weights[i]) { total+=values[i]; rem-=weights[i]; }
            else { total+=(double)values[i]*rem/weights[i]; break; }
        }
        return total;
    }

    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║      GREEDY PROBLEMS - ALL SOLUTIONS     ║");
        System.out.println("╚══════════════════════════════════════════╝\n");
        System.out.println("LC55  canJump([2,3,1,1,4])              = " + canJump(new int[]{2,3,1,1,4}));
        System.out.println("LC45  minJumps([2,3,1,1,4])             = " + jump(new int[]{2,3,1,1,4}));
        System.out.println("LC122 maxProfitII([7,1,5,3,6,4])        = " + maxProfitII(new int[]{7,1,5,3,6,4}));
        System.out.println("LC134 gasStation                        = " + canCompleteCircuit(new int[]{1,2,3,4,5},new int[]{3,4,5,1,2}));
        System.out.println("LC135 candy([1,0,2])                    = " + candy(new int[]{1,0,2}));
        System.out.println("LC455 assignCookies([1,2,3],[1,1])      = " + findContentChildren(new int[]{1,2,3},new int[]{1,1}));
        System.out.println("LC435 eraseOverlapIntervals             = " + eraseOverlapIntervals(new int[][]{{1,2},{2,3},{3,4},{1,3}}));
        System.out.println("LC452 minArrows                         = " + findMinArrowShots(new int[][]{{10,16},{2,8},{1,6},{7,12}}));
        System.out.println("LC763 partitionLabels(ababcbacadef...)  = " + partitionLabels("ababcbacadefegdehijhklij"));
        System.out.println("LC621 taskScheduler([A,A,A,B,B,B],n=2) = " + leastInterval(new char[]{'A','A','A','B','B','B'},2));
        System.out.println("LC376 wiggleMaxLength([1,17,5,10,13,15,10,5,16,8]) = " + wiggleMaxLength(new int[]{1,17,5,10,13,15,10,5,16,8}));
        System.out.println("LC392 isSubsequence(abc,ahbgdc)        = " + isSubsequence("abc","ahbgdc"));
        System.out.println("GFG   fractionalKnapsack(cap=50)        = " + fractionalKnapsack(50,new int[]{10,20,30},new int[]{60,100,120}));
    }
}
