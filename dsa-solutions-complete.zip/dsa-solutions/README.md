# DSA Complete Solutions — LeetCode + GeeksForGeeks
## Java Solutions with Full Explanations

---

## 📁 Directory Structure

```
dsa-solutions/
├── 01_Arrays/              ArrayProblems.java        (26 problems)
├── 02_Strings/             StringProblems.java       (20 problems)
├── 03_LinkedList/          LinkedListProblems.java   (19 problems)
├── 04_Stack_Queue/         StackQueueProblems.java   (18 problems)
├── 05_Trees/               TreeProblems.java         (23 problems)
├── 06_Graphs/              GraphProblems.java        (19 problems)
├── 07_DynamicProgramming/  DPProblems.java           (29 problems)
├── 08_Backtracking/        BacktrackingProblems.java (17 problems)
├── 09_Greedy/              GreedyProblems.java       (20 problems)
├── 10_BinarySearch/        BinarySearchProblems.java (23 problems)
├── 11_Sorting/             SortingProblems.java      (15 problems + 8 algorithms)
├── 12_Hashing/             HashingProblems.java      (23 problems)
├── 13_Heaps/               HeapProblems.java         (19 problems)
├── 14_Recursion/           RecursionProblems.java    (15 problems)
├── 15_Matrix/              MatrixProblems.java       (18 problems)
├── 16_Trie/                TrieProblems.java         (12 problems)
├── 17_SegmentTree/         SegmentTreeProblems.java  (10 problems + BIT + Sparse Table)
├── 18_BitManipulation/     BitManipulation.java      (22 problems)
├── 19_TwoPointers_SlidingWindow/ TwoPointersSlidingWindow.java (25 problems)
└── 20_MathAndNumberTheory/ MathProblems.java         (25 problems)
```

**Total: 400+ problems across 20 categories**

---

## 📋 Problem Format (Every Solution)

Each solution includes:

```java
// LC53 - MAXIMUM SUBARRAY (KADANE'S ALGORITHM)
/**
 * PROBLEM: Find contiguous subarray with maximum sum
 * APPROACH: Kadane's Algorithm
 *   curSum = max(nums[i], curSum + nums[i])  — extend or start fresh
 *   maxSum = max(maxSum, curSum)
 * TIME: O(n)  SPACE: O(1)
 * EXAMPLE: [-2,1,-3,4,-1,2,1,-5,4] → 6 ([4,-1,2,1])
 */
static int maxSubArray(int[] nums) {
    int curSum = nums[0], maxSum = nums[0];
    for (int i = 1; i < nums.length; i++) {
        curSum = Math.max(nums[i], curSum + nums[i]);
        maxSum = Math.max(maxSum, curSum);
    }
    return maxSum;
}
```

---

## 🗂 Problems By Category

### 01 Arrays (26 problems)
| # | Problem | Approach | Time | Space |
|---|---------|----------|------|-------|
| LC1 | Two Sum | HashMap | O(n) | O(n) |
| LC11 | Container With Most Water | Two Pointers | O(n) | O(1) |
| LC15 | 3Sum | Sort + Two Ptr | O(n²) | O(1) |
| LC26 | Remove Duplicates | Slow-Fast Ptr | O(n) | O(1) |
| LC31 | Next Permutation | Find pivot | O(n) | O(1) |
| LC33 | Search Rotated Array | Binary Search | O(log n) | O(1) |
| LC53 | Maximum Subarray | Kadane's | O(n) | O(1) |
| LC56 | Merge Intervals | Sort+Greedy | O(n log n) | O(n) |
| LC75 | Sort Colors | Dutch Flag | O(n) | O(1) |
| LC121 | Best Time Stock | Track min | O(n) | O(1) |
| LC128 | Longest Consecutive | HashSet | O(n) | O(n) |
| LC152 | Max Product Subarray | Track min/max | O(n) | O(1) |
| LC153 | Min in Rotated Array | Binary Search | O(log n) | O(1) |
| LC169 | Majority Element | Boyer-Moore | O(n) | O(1) |
| LC189 | Rotate Array | Triple Reverse | O(n) | O(1) |
| LC238 | Product Except Self | Prefix+Suffix | O(n) | O(1) |
| LC268 | Missing Number | Sum formula | O(n) | O(1) |
| LC283 | Move Zeroes | Slow pointer | O(n) | O(1) |
| LC347 | Top K Frequent | Bucket Sort | O(n) | O(n) |
| LC442 | Find All Duplicates | Sign marking | O(n) | O(1) |
| GFG | Equilibrium Point | Prefix Sum | O(n) | O(1) |
| GFG | Leaders in Array | Right to left | O(n) | O(1) |
| GFG | Smallest Missing Positive | Cyclic Sort | O(n) | O(1) |
| GFG | Trapping Rain Water | Two Pointers | O(n) | O(1) |
| GFG | Minimize Heights II | Sort+Greedy | O(n log n) | O(1) |
| GFG | Subarray with Given Sum | Sliding Window | O(n) | O(1) |

### 07 Dynamic Programming (29 problems)
| # | Problem | Approach | Time |
|---|---------|----------|------|
| LC70 | Climbing Stairs | Fibonacci | O(n) |
| LC198 | House Robber | Linear DP | O(n) |
| LC213 | House Robber II | Two passes | O(n) |
| LC62 | Unique Paths | Grid DP | O(mn) |
| LC64 | Min Path Sum | Grid DP | O(mn) |
| LC300 | LIS | Patience sort | O(n log n) |
| LC322 | Coin Change | Knapsack | O(nA) |
| LC518 | Coin Change II | Unbounded | O(nA) |
| LC416 | Partition Equal Sum | 0/1 Knapsack | O(nS) |
| LC72 | Edit Distance | String DP | O(mn) |
| LC91 | Decode Ways | Linear DP | O(n) |
| LC309 | Stock with Cooldown | State machine | O(n) |
| LC120 | Triangle | Bottom-up | O(n²) |
| LC96 | Unique BSTs | Catalan | O(n²) |
| LC338 | Counting Bits | Bit DP | O(n) |
| GFG | 0/1 Knapsack | Knapsack | O(nW) |
| GFG | LCS | String DP | O(mn) |

---

## 🧠 Key Algorithms Reference

### Sorting Algorithms
| Algorithm | Time (Best/Avg/Worst) | Space | Stable? |
|-----------|----------------------|-------|---------|
| Bubble | O(n) / O(n²) / O(n²) | O(1) | ✓ |
| Selection | O(n²) / O(n²) / O(n²) | O(1) | ✗ |
| Insertion | O(n) / O(n²) / O(n²) | O(1) | ✓ |
| Merge | O(n log n) all | O(n) | ✓ |
| Quick | O(n log n) / O(n log n) / O(n²) | O(log n) | ✗ |
| Heap | O(n log n) all | O(1) | ✗ |
| Counting | O(n+k) all | O(k) | ✓ |
| Radix | O(nk) all | O(n+k) | ✓ |

### Data Structures — Time Complexity
| Structure | Access | Search | Insert | Delete |
|-----------|--------|--------|--------|--------|
| Array | O(1) | O(n) | O(n) | O(n) |
| Stack/Queue | O(n) | O(n) | O(1) | O(1) |
| HashMap | O(1) | O(1) | O(1) | O(1) |
| TreeMap | O(log n) | O(log n) | O(log n) | O(log n) |
| Heap/PQ | O(1) top | O(n) | O(log n) | O(log n) |
| Trie | O(m) | O(m) | O(m) | O(m) |
| Segment Tree | — | O(log n) | O(log n) | O(log n) |

---

## 🔍 Pattern Recognition

```
PROBLEM HINTS                          PATTERN TO USE
──────────────────────────────────     ──────────────────────
Find pair/triplet summing to X         Two Pointers (if sorted)
Find pair summing to X                 HashMap
Contiguous subarray with property     Sliding Window
Count subarrays with sum = K          Prefix Sum + HashMap
Sorted array, find element            Binary Search
Linked list cycle                      Fast & Slow Pointers
Level by level tree traversal         BFS (Queue)
All paths / any path / cycle          DFS (Recursion/Stack)
Count distinct / duplicates           HashSet/HashMap
Find kth largest/smallest             Heap (Min/Max)
Merge k sorted lists                  K-Way Merge (MinHeap)
All combinations / permutations       Backtracking
Optimal choice at each step           Greedy
Choose to include/exclude             Dynamic Programming
Build from prefixes                   Trie
Range queries with updates            Segment Tree / BIT
Connected components                  Union-Find (DSU)
Next greater/smaller element          Monotonic Stack
Sliding window max/min                Monotonic Deque
```

---

## 📌 Quick Recipes

### Binary Search Template
```java
// Find leftmost position satisfying condition
int lo = 0, hi = n;
while (lo < hi) {
    int mid = lo + (hi - lo) / 2;
    if (condition(mid)) hi = mid;
    else lo = mid + 1;
}
return lo;
```

### BFS Template
```java
Queue<Node> q = new LinkedList<>();
Set<Node> visited = new HashSet<>();
q.offer(start); visited.add(start);
while (!q.isEmpty()) {
    Node cur = q.poll();
    for (Node next : neighbors(cur))
        if (visited.add(next)) q.offer(next);
}
```

### Dynamic Programming Template
```java
// 1. Define state: dp[i] = answer for subproblem i
// 2. Base case: dp[0] = ...
// 3. Recurrence: dp[i] = f(dp[i-1], dp[i-2], ...)
// 4. Answer: dp[n]
int[] dp = new int[n+1];
dp[0] = base;
for (int i = 1; i <= n; i++)
    dp[i] = Math.max(dp[i-1] + ..., dp[i-2] + ...);
return dp[n];
```

### Union-Find Template
```java
int[] parent = new int[n]; int[] rank = new int[n];
for (int i = 0; i < n; i++) parent[i] = i;

int find(int x) {
    if (parent[x] != x) parent[x] = find(parent[x]); // path compression
    return parent[x];
}
void union(int x, int y) {
    int px = find(x), py = find(y);
    if (px == py) return;
    if (rank[px] < rank[py]) { int t=px; px=py; py=t; }
    parent[py] = px;
    if (rank[px] == rank[py]) rank[px]++;
}
```

---

## 🎯 Study Plan

### Week 1-2: Foundations
- Arrays, Strings, Math
- Two Pointers, Sliding Window

### Week 3-4: Core Data Structures
- Linked Lists, Stacks, Queues
- Hashing, Heaps

### Week 5-6: Trees & Graphs
- Binary Trees, BST
- BFS, DFS, Topological Sort

### Week 7-8: Advanced Patterns
- Dynamic Programming (all variants)
- Backtracking, Greedy

### Week 9-10: Advanced Structures
- Tries, Segment Trees, Union-Find
- Bit Manipulation, Binary Search variants

---

*Each Java file is self-contained and compiles independently.*
*Run any file: javac FileName.java && java FileName*
