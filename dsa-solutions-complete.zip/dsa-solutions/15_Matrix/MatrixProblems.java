/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║          MATRIX - LeetCode & GeeksForGeeks Solutions         ║
 * ╚══════════════════════════════════════════════════════════════╝
 * LC48  Rotate Image
 * LC54  Spiral Matrix
 * LC59  Spiral Matrix II
 * LC62  Unique Paths
 * LC63  Unique Paths II
 * LC64  Minimum Path Sum
 * LC73  Set Matrix Zeroes
 * LC74  Search 2D Matrix
 * LC79  Word Search
 * LC130 Surrounded Regions
 * LC200 Number of Islands
 * LC289 Game of Life
 * LC329 Longest Increasing Path in Matrix
 * LC378 Kth Smallest in Sorted Matrix
 * LC542 01 Matrix (Distance to nearest 0)
 * LC695 Max Area of Island
 * GFG   Search in row-column sorted matrix
 * GFG   Print matrix in diagonal order
 */
import java.util.*;

public class MatrixProblems {

    // LC48 - ROTATE IMAGE 90 DEGREES CLOCKWISE
    /**
     * APPROACH: Transpose + Reverse each row
     *   Transpose: matrix[i][j] <-> matrix[j][i]
     *   Reverse rows: matrix[i] reversed
     * TIME: O(n²)  SPACE: O(1)
     * EXAMPLE: [[1,2,3],[4,5,6],[7,8,9]] → [[7,4,1],[8,5,2],[9,6,3]]
     */
    static void rotate(int[][] matrix) {
        int n = matrix.length;
        // Step 1: Transpose
        for (int i=0; i<n; i++) for (int j=i+1; j<n; j++) {
            int t=matrix[i][j]; matrix[i][j]=matrix[j][i]; matrix[j][i]=t;
        }
        // Step 2: Reverse each row
        for (int[] row : matrix) {
            int l=0, r=row.length-1;
            while(l<r){int t=row[l];row[l++]=row[r];row[r--]=t;}
        }
    }

    // LC54 - SPIRAL MATRIX (read in spiral order)
    /**
     * APPROACH: Layer by layer — maintain top/bottom/left/right boundaries
     *   Process top row → right col → bottom row → left col, then shrink
     * TIME: O(m*n)  SPACE: O(1) output excluded
     */
    static List<Integer> spiralOrder(int[][] matrix) {
        List<Integer> result = new ArrayList<>();
        int top=0, bottom=matrix.length-1, left=0, right=matrix[0].length-1;
        while (top<=bottom && left<=right) {
            for (int c=left;c<=right;c++) result.add(matrix[top][c]); top++;
            for (int r=top;r<=bottom;r++) result.add(matrix[r][right]); right--;
            if (top<=bottom) { for (int c=right;c>=left;c--) result.add(matrix[bottom][c]); bottom--; }
            if (left<=right) { for (int r=bottom;r>=top;r--) result.add(matrix[r][left]); left++; }
        }
        return result;
    }

    // LC59 - SPIRAL MATRIX II (fill n×n with 1..n²)
    /**
     * APPROACH: Same boundary approach, fill sequentially
     */
    static int[][] generateMatrix(int n) {
        int[][] matrix = new int[n][n];
        int top=0, bottom=n-1, left=0, right=n-1, num=1;
        while (top<=bottom && left<=right) {
            for (int c=left;c<=right;c++) matrix[top][c]=num++;  top++;
            for (int r=top;r<=bottom;r++) matrix[r][right]=num++; right--;
            if (top<=bottom){for(int c=right;c>=left;c--) matrix[bottom][c]=num++; bottom--;}
            if (left<=right){for(int r=bottom;r>=top;r--) matrix[r][left]=num++; left++;}
        }
        return matrix;
    }

    // LC73 - SET MATRIX ZEROES
    /**
     * APPROACH: Use first row and column as markers (O(1) space)
     *   First pass: mark which rows/cols need zeroing
     *   Second pass: zero out marked rows/cols
     * TIME: O(m*n)  SPACE: O(1)
     */
    static void setZeroes(int[][] matrix) {
        int m=matrix.length, n=matrix[0].length;
        boolean firstRowZero=false, firstColZero=false;
        for (int j=0;j<n;j++) if(matrix[0][j]==0) firstRowZero=true;
        for (int i=0;i<m;i++) if(matrix[i][0]==0) firstColZero=true;
        // Use first row/col as markers
        for (int i=1;i<m;i++) for (int j=1;j<n;j++) if(matrix[i][j]==0){ matrix[i][0]=0; matrix[0][j]=0; }
        // Zero out marked rows/cols
        for (int i=1;i<m;i++) if(matrix[i][0]==0) for(int j=1;j<n;j++) matrix[i][j]=0;
        for (int j=1;j<n;j++) if(matrix[0][j]==0) for(int i=1;i<m;i++) matrix[i][j]=0;
        if (firstRowZero) Arrays.fill(matrix[0],0);
        if (firstColZero) for(int i=0;i<m;i++) matrix[i][0]=0;
    }

    // LC130 - SURROUNDED REGIONS (flip enclosed 'O's to 'X')
    /**
     * APPROACH: DFS from border 'O's, mark safe with '#'
     *   Then: '#' → 'O', remaining 'O' → 'X'
     * TIME: O(m*n)  SPACE: O(m*n) stack
     */
    static void solve(char[][] board) {
        int m=board.length, n=board[0].length;
        // Mark safe 'O's (connected to border)
        for (int r=0;r<m;r++) { dfsSafe(board,r,0,m,n); dfsSafe(board,r,n-1,m,n); }
        for (int c=0;c<n;c++) { dfsSafe(board,0,c,m,n); dfsSafe(board,m-1,c,m,n); }
        // Flip: 'O'→'X', '#'→'O'
        for (int r=0;r<m;r++) for (int c=0;c<n;c++) {
            if (board[r][c]=='O') board[r][c]='X';
            else if (board[r][c]=='#') board[r][c]='O';
        }
    }
    static void dfsSafe(char[][] b, int r, int c, int m, int n) {
        if (r<0||r>=m||c<0||c>=n||b[r][c]!='O') return;
        b[r][c]='#';
        dfsSafe(b,r+1,c,m,n); dfsSafe(b,r-1,c,m,n); dfsSafe(b,r,c+1,m,n); dfsSafe(b,r,c-1,m,n);
    }

    // LC289 - GAME OF LIFE
    /**
     * APPROACH: In-place using extra states
     *   State 2: was alive, becomes dead
     *   State 3: was dead, becomes alive
     *   Then convert: 2→0, 3→1
     * TIME: O(m*n)  SPACE: O(1)
     */
    static void gameOfLife(int[][] board) {
        int m=board.length, n=board[0].length;
        for (int r=0;r<m;r++) for (int c=0;c<n;c++) {
            int neighbors = countLiveNeighbors(board,r,c,m,n);
            if (board[r][c]==1 && (neighbors<2||neighbors>3)) board[r][c]=2; // dies
            if (board[r][c]==0 && neighbors==3) board[r][c]=3;               // born
        }
        for (int r=0;r<m;r++) for (int c=0;c<n;c++) {
            if (board[r][c]==2) board[r][c]=0;
            if (board[r][c]==3) board[r][c]=1;
        }
    }
    static int countLiveNeighbors(int[][] b, int r, int c, int m, int n) {
        int count=0;
        for (int dr=-1;dr<=1;dr++) for (int dc=-1;dc<=1;dc++) {
            if (dr==0&&dc==0) continue;
            int nr=r+dr, nc=c+dc;
            if (nr>=0&&nr<m&&nc>=0&&nc<n&&(b[nr][nc]==1||b[nr][nc]==2)) count++;
        }
        return count;
    }

    // LC542 - 01 MATRIX (BFS distance to nearest 0)
    /**
     * APPROACH: Multi-source BFS from all 0s simultaneously
     * TIME: O(m*n)  SPACE: O(m*n)
     */
    static int[][] updateMatrix(int[][] mat) {
        int m=mat.length, n=mat[0].length;
        int[][] dist = new int[m][n];
        Queue<int[]> q = new LinkedList<>();
        for (int r=0;r<m;r++) for (int c=0;c<n;c++) {
            if (mat[r][c]==0) q.offer(new int[]{r,c});
            else dist[r][c]=Integer.MAX_VALUE;
        }
        int[][] dirs={{1,0},{-1,0},{0,1},{0,-1}};
        while (!q.isEmpty()) {
            int[] cur=q.poll();
            for (int[] d:dirs) {
                int nr=cur[0]+d[0], nc=cur[1]+d[1];
                if (nr>=0&&nr<m&&nc>=0&&nc<n&&dist[nr][nc]>dist[cur[0]][cur[1]]+1) {
                    dist[nr][nc]=dist[cur[0]][cur[1]]+1; q.offer(new int[]{nr,nc});
                }
            }
        }
        return dist;
    }

    // LC329 - LONGEST INCREASING PATH IN MATRIX
    static int[][] dfsCache;
    static int longestIncreasingPath(int[][] matrix) {
        int m=matrix.length, n=matrix[0].length, max=0;
        dfsCache=new int[m][n];
        for (int r=0;r<m;r++) for (int c=0;c<n;c++) max=Math.max(max,dfsLIP(matrix,r,c,m,n));
        return max;
    }
    static int dfsLIP(int[][] mat, int r, int c, int m, int n) {
        if (dfsCache[r][c]!=0) return dfsCache[r][c];
        int best=1;
        int[][] dirs={{1,0},{-1,0},{0,1},{0,-1}};
        for (int[] d:dirs) {
            int nr=r+d[0], nc=c+d[1];
            if (nr>=0&&nr<m&&nc>=0&&nc<n&&mat[nr][nc]>mat[r][c])
                best=Math.max(best,1+dfsLIP(mat,nr,nc,m,n));
        }
        return dfsCache[r][c]=best;
    }

    // GFG - SEARCH IN ROW-COL SORTED MATRIX (top-right corner approach)
    /**
     * APPROACH: Start from top-right
     *   If val > target → move left
     *   If val < target → move down
     * TIME: O(m+n)  SPACE: O(1)
     */
    static boolean searchRowColMatrix(int[][] matrix, int target) {
        int r=0, c=matrix[0].length-1;
        while (r<matrix.length && c>=0) {
            if (matrix[r][c]==target) return true;
            if (matrix[r][c]>target) c--; else r++;
        }
        return false;
    }

    // GFG - DIAGONAL TRAVERSAL
    static List<Integer> diagonalTraversal(int[][] matrix) {
        int m=matrix.length, n=matrix[0].length;
        List<Integer> result = new ArrayList<>();
        for (int d=0; d<m+n-1; d++) {
            if (d%2==0) { // going up
                int r=Math.min(d,m-1), c=d-r;
                while (r>=0&&c<n) { result.add(matrix[r--][c++]); }
            } else { // going down
                int c=Math.min(d,n-1), r=d-c;
                while (c>=0&&r<m) { result.add(matrix[r++][c--]); }
            }
        }
        return result;
    }

    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║     MATRIX PROBLEMS - ALL SOLUTIONS      ║");
        System.out.println("╚══════════════════════════════════════════╝\n");

        int[][] mat = {{1,2,3},{4,5,6},{7,8,9}};
        rotate(mat); System.out.println("LC48  rotate90CW          = " + Arrays.deepToString(mat));

        int[][] mat2 = {{1,2,3},{4,5,6},{7,8,9}};
        System.out.println("LC54  spiralOrder         = " + spiralOrder(mat2));
        System.out.println("LC59  generateMatrix(3)   = " + Arrays.deepToString(generateMatrix(3)));

        int[][] zero = {{1,1,1},{1,0,1},{1,1,1}};
        setZeroes(zero); System.out.println("LC73  setZeroes           = " + Arrays.deepToString(zero));

        char[][] board = {{'X','X','X','X'},{'X','O','O','X'},{'X','X','O','X'},{'X','O','X','X'}};
        solve(board); System.out.println("LC130 surroundedRegions   = " + Arrays.deepToString(board));

        int[][] life = {{0,1,0},{0,0,1},{1,1,1},{0,0,0}};
        gameOfLife(life); System.out.println("LC289 gameOfLife          = " + Arrays.deepToString(life));

        int[][] dist = {{0,0,0},{0,1,0},{0,0,0}};
        System.out.println("LC542 01Matrix            = " + Arrays.deepToString(updateMatrix(dist)));

        int[][] lip = {{9,9,4},{6,6,8},{2,1,1}};
        System.out.println("LC329 longestIncPath      = " + longestIncreasingPath(lip));

        int[][] sorted = {{10,20,30,40},{15,25,35,45},{27,29,37,48},{32,33,39,50}};
        System.out.println("GFG   searchRowCol(29)    = " + searchRowColMatrix(sorted, 29));
        System.out.println("GFG   diagonalTraversal   = " + diagonalTraversal(new int[][]{{1,2,3},{4,5,6},{7,8,9}}));
    }
}
