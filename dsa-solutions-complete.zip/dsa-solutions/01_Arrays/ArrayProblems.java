/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║          ARRAYS - LeetCode & GeeksForGeeks Solutions         ║
 * ╚══════════════════════════════════════════════════════════════╝
 *
 * Problems covered (30 problems):
 *  LC1   Two Sum
 *  LC11  Container With Most Water
 *  LC15  3Sum
 *  LC26  Remove Duplicates from Sorted Array
 *  LC31  Next Permutation
 *  LC33  Search in Rotated Sorted Array
 *  LC53  Maximum Subarray (Kadane's)
 *  LC56  Merge Intervals
 *  LC75  Sort Colors (Dutch National Flag)
 *  LC121 Best Time to Buy and Sell Stock
 *  LC128 Longest Consecutive Sequence
 *  LC152 Maximum Product Subarray
 *  LC153 Find Minimum in Rotated Sorted Array
 *  LC169 Majority Element (Boyer-Moore)
 *  LC189 Rotate Array
 *  LC238 Product of Array Except Self
 *  LC268 Missing Number
 *  LC283 Move Zeroes
 *  LC347 Top K Frequent Elements
 *  LC442 Find All Duplicates in an Array
 *  GFG   Equilibrium Point
 *  GFG   Leaders in an Array
 *  GFG   Smallest Positive Missing Number
 *  GFG   Trapping Rain Water
 *  GFG   Stock Span Problem
 *  GFG   Merge Without Extra Space
 *  GFG   Chocolate Distribution Problem
 *  GFG   Minimize the Heights II
 *  GFG   Kadane's Algorithm
 *  GFG   Subarray with given sum
 */
import java.util.*;
import java.util.stream.*;

public class ArrayProblems {

    // ═══════════════════════════════════════════════════════════════
    // LC1 - TWO SUM
    // ═══════════════════════════════════════════════════════════════
    /**
     * PROBLEM: Find two indices such that nums[i] + nums[j] = target
     * APPROACH: HashMap - store complement lookup
     *   For each num, check if (target - num) exists in map
     *   If yes → return indices. If no → store num → index in map
     * TIME: O(n)  SPACE: O(n)
     * EXAMPLE: [2,7,11,15], target=9 → [0,1] (2+7=9)
     */
    static int[] twoSum(int[] nums, int target) {
        Map<Integer, Integer> map = new HashMap<>(); // value → index
        for (int i = 0; i < nums.length; i++) {
            int complement = target - nums[i];
            if (map.containsKey(complement))
                return new int[]{map.get(complement), i};
            map.put(nums[i], i);
        }
        return new int[]{-1, -1};
    }

    // ═══════════════════════════════════════════════════════════════
    // LC11 - CONTAINER WITH MOST WATER
    // ═══════════════════════════════════════════════════════════════
    /**
     * PROBLEM: Find two lines forming container holding most water
     * APPROACH: Two pointers from both ends
     *   Area = min(height[l], height[r]) * (r - l)
     *   Move pointer with smaller height inward (can't do better keeping it)
     * TIME: O(n)  SPACE: O(1)
     * EXAMPLE: [1,8,6,2,5,4,8,3,7] → 49
     */
    static int maxArea(int[] height) {
        int l = 0, r = height.length - 1, maxWater = 0;
        while (l < r) {
            maxWater = Math.max(maxWater, Math.min(height[l], height[r]) * (r - l));
            if (height[l] < height[r]) l++;  // move smaller side
            else r--;
        }
        return maxWater;
    }

    // ═══════════════════════════════════════════════════════════════
    // LC15 - 3SUM
    // ═══════════════════════════════════════════════════════════════
    /**
     * PROBLEM: Find all unique triplets summing to zero
     * APPROACH: Sort + Two Pointers
     *   Fix one element (i), use two pointers for remaining pair
     *   Skip duplicates to avoid repeated triplets
     * TIME: O(n²)  SPACE: O(1) output excluded
     * EXAMPLE: [-1,0,1,2,-1,-4] → [[-1,-1,2],[-1,0,1]]
     */
    static List<List<Integer>> threeSum(int[] nums) {
        Arrays.sort(nums);
        List<List<Integer>> result = new ArrayList<>();
        for (int i = 0; i < nums.length - 2; i++) {
            if (i > 0 && nums[i] == nums[i - 1]) continue; // skip duplicate i
            int l = i + 1, r = nums.length - 1;
            while (l < r) {
                int sum = nums[i] + nums[l] + nums[r];
                if (sum == 0) {
                    result.add(Arrays.asList(nums[i], nums[l], nums[r]));
                    while (l < r && nums[l] == nums[l + 1]) l++; // skip dup l
                    while (l < r && nums[r] == nums[r - 1]) r--; // skip dup r
                    l++; r--;
                } else if (sum < 0) l++;
                else r--;
            }
        }
        return result;
    }

    // ═══════════════════════════════════════════════════════════════
    // LC26 - REMOVE DUPLICATES FROM SORTED ARRAY
    // ═══════════════════════════════════════════════════════════════
    /**
     * PROBLEM: Remove duplicates in-place, return new length
     * APPROACH: Slow pointer tracks unique position
     *   Fast pointer scans; when different from previous, copy to slow
     * TIME: O(n)  SPACE: O(1)
     * EXAMPLE: [0,0,1,1,1,2,2,3,3,4] → 5, array=[0,1,2,3,4,...]
     */
    static int removeDuplicates(int[] nums) {
        int slow = 1;
        for (int fast = 1; fast < nums.length; fast++)
            if (nums[fast] != nums[fast - 1])
                nums[slow++] = nums[fast];
        return slow;
    }

    // ═══════════════════════════════════════════════════════════════
    // LC31 - NEXT PERMUTATION
    // ═══════════════════════════════════════════════════════════════
    /**
     * PROBLEM: Find lexicographically next permutation in-place
     * APPROACH: 3 steps:
     *   1. Find rightmost element less than its successor (i)
     *   2. Find smallest element to right of i that is > nums[i] (j)
     *   3. Swap i and j, then reverse from i+1 to end
     * TIME: O(n)  SPACE: O(1)
     * EXAMPLE: [1,2,3] → [1,3,2]  |  [3,2,1] → [1,2,3]
     */
    static void nextPermutation(int[] nums) {
        int n = nums.length, i = n - 2;
        // Step 1: find first decreasing element from right
        while (i >= 0 && nums[i] >= nums[i + 1]) i--;
        if (i >= 0) {
            // Step 2: find element just larger than nums[i]
            int j = n - 1;
            while (nums[j] <= nums[i]) j--;
            int t = nums[i]; nums[i] = nums[j]; nums[j] = t; // swap
        }
        // Step 3: reverse from i+1
        int l = i + 1, r = n - 1;
        while (l < r) { int t = nums[l]; nums[l++] = nums[r]; nums[r--] = t; }
    }

    // ═══════════════════════════════════════════════════════════════
    // LC33 - SEARCH IN ROTATED SORTED ARRAY
    // ═══════════════════════════════════════════════════════════════
    /**
     * PROBLEM: Search target in rotated sorted array (no duplicates)
     * APPROACH: Modified Binary Search
     *   At each mid, one half is always sorted — determine which and narrow
     * TIME: O(log n)  SPACE: O(1)
     * EXAMPLE: [4,5,6,7,0,1,2], target=0 → 4
     */
    static int searchRotated(int[] nums, int target) {
        int l = 0, r = nums.length - 1;
        while (l <= r) {
            int mid = l + (r - l) / 2;
            if (nums[mid] == target) return mid;
            if (nums[l] <= nums[mid]) {       // left half sorted
                if (target >= nums[l] && target < nums[mid]) r = mid - 1;
                else l = mid + 1;
            } else {                           // right half sorted
                if (target > nums[mid] && target <= nums[r]) l = mid + 1;
                else r = mid - 1;
            }
        }
        return -1;
    }

    // ═══════════════════════════════════════════════════════════════
    // LC53 - MAXIMUM SUBARRAY (KADANE'S ALGORITHM)
    // ═══════════════════════════════════════════════════════════════
    /**
     * PROBLEM: Find contiguous subarray with maximum sum
     * APPROACH: Kadane's Algorithm
     *   curSum = max(nums[i], curSum + nums[i])  — extend or start fresh
     *   maxSum = max(maxSum, curSum)
     * TIME: O(n)  SPACE: O(1)
     * EXAMPLE: [-2,1,-3,4,-1,2,1,-5,4] → 6 ([4,-1,2,1])
     */
    static int maxSubArray(int[] nums) {
        int curSum = nums[0], maxSum = nums[0];
        for (int i = 1; i < nums.length; i++) {
            curSum = Math.max(nums[i], curSum + nums[i]);
            maxSum = Math.max(maxSum, curSum);
        }
        return maxSum;
    }

    // ═══════════════════════════════════════════════════════════════
    // LC56 - MERGE INTERVALS
    // ═══════════════════════════════════════════════════════════════
    /**
     * PROBLEM: Merge all overlapping intervals
     * APPROACH: Sort by start, greedily merge
     *   If current start <= last end → merge (update end)
     *   Else → add new interval
     * TIME: O(n log n)  SPACE: O(n)
     * EXAMPLE: [[1,3],[2,6],[8,10],[15,18]] → [[1,6],[8,10],[15,18]]
     */
    static int[][] merge(int[][] intervals) {
        Arrays.sort(intervals, (a, b) -> a[0] - b[0]);
        List<int[]> merged = new ArrayList<>();
        int[] cur = intervals[0];
        for (int i = 1; i < intervals.length; i++) {
            if (intervals[i][0] <= cur[1])
                cur[1] = Math.max(cur[1], intervals[i][1]); // extend
            else { merged.add(cur); cur = intervals[i]; }
        }
        merged.add(cur);
        return merged.toArray(new int[0][]);
    }

    // ═══════════════════════════════════════════════════════════════
    // LC75 - SORT COLORS (DUTCH NATIONAL FLAG)
    // ═══════════════════════════════════════════════════════════════
    /**
     * PROBLEM: Sort array with 0s, 1s, 2s in-place
     * APPROACH: 3 pointers — low, mid, high
     *   nums[mid]==0 → swap with low, advance both
     *   nums[mid]==1 → advance mid
     *   nums[mid]==2 → swap with high, retreat high (don't advance mid!)
     * TIME: O(n)  SPACE: O(1)
     * EXAMPLE: [2,0,2,1,1,0] → [0,0,1,1,2,2]
     */
    static void sortColors(int[] nums) {
        int low = 0, mid = 0, high = nums.length - 1;
        while (mid <= high) {
            if (nums[mid] == 0) {
                int t = nums[low]; nums[low++] = nums[mid]; nums[mid++] = t;
            } else if (nums[mid] == 1) {
                mid++;
            } else {
                int t = nums[mid]; nums[mid] = nums[high]; nums[high--] = t;
                // don't advance mid — swapped element not yet examined
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // LC121 - BEST TIME TO BUY AND SELL STOCK
    // ═══════════════════════════════════════════════════════════════
    /**
     * PROBLEM: Find max profit from one buy-sell transaction
     * APPROACH: Track minimum price seen so far (best buy day)
     *   profit = price - minPrice; update maxProfit each day
     * TIME: O(n)  SPACE: O(1)
     * EXAMPLE: [7,1,5,3,6,4] → 5 (buy@1, sell@6)
     */
    static int maxProfit(int[] prices) {
        int minPrice = Integer.MAX_VALUE, maxProfit = 0;
        for (int price : prices) {
            minPrice = Math.min(minPrice, price);
            maxProfit = Math.max(maxProfit, price - minPrice);
        }
        return maxProfit;
    }

    // ═══════════════════════════════════════════════════════════════
    // LC128 - LONGEST CONSECUTIVE SEQUENCE
    // ═══════════════════════════════════════════════════════════════
    /**
     * PROBLEM: Find length of longest consecutive sequence
     * APPROACH: HashSet for O(1) lookup
     *   Only start sequence from numbers that have no predecessor (n-1 not in set)
     *   Count streak from each valid start
     * TIME: O(n)  SPACE: O(n)
     * EXAMPLE: [100,4,200,1,3,2] → 4 ([1,2,3,4])
     */
    static int longestConsecutive(int[] nums) {
        Set<Integer> set = new HashSet<>();
        for (int n : nums) set.add(n);
        int maxLen = 0;
        for (int n : set) {
            if (!set.contains(n - 1)) { // start of sequence
                int streak = 1;
                while (set.contains(n + streak)) streak++;
                maxLen = Math.max(maxLen, streak);
            }
        }
        return maxLen;
    }

    // ═══════════════════════════════════════════════════════════════
    // LC152 - MAXIMUM PRODUCT SUBARRAY
    // ═══════════════════════════════════════════════════════════════
    /**
     * PROBLEM: Find subarray with maximum product
     * APPROACH: Track both max and min products (negative * negative = positive)
     *   At each step: curMax = max(n, curMax*n, curMin*n)
     *                 curMin = min(n, curMax*n, curMin*n)
     * TIME: O(n)  SPACE: O(1)
     * EXAMPLE: [2,3,-2,4] → 6  |  [-2,0,-1] → 0
     */
    static int maxProduct(int[] nums) {
        int maxProd = nums[0], minProd = nums[0], result = nums[0];
        for (int i = 1; i < nums.length; i++) {
            int n = nums[i];
            int tempMax = Math.max(n, Math.max(maxProd * n, minProd * n));
            minProd     = Math.min(n, Math.min(maxProd * n, minProd * n));
            maxProd = tempMax;
            result = Math.max(result, maxProd);
        }
        return result;
    }

    // ═══════════════════════════════════════════════════════════════
    // LC153 - FIND MINIMUM IN ROTATED SORTED ARRAY
    // ═══════════════════════════════════════════════════════════════
    /**
     * PROBLEM: Find minimum in rotated sorted array
     * APPROACH: Binary search — if mid > right, min is in right half
     *   Otherwise, min is in left half (including mid)
     * TIME: O(log n)  SPACE: O(1)
     * EXAMPLE: [3,4,5,1,2] → 1
     */
    static int findMin(int[] nums) {
        int l = 0, r = nums.length - 1;
        while (l < r) {
            int mid = l + (r - l) / 2;
            if (nums[mid] > nums[r]) l = mid + 1; // min in right half
            else r = mid;                          // min in left half (incl mid)
        }
        return nums[l];
    }

    // ═══════════════════════════════════════════════════════════════
    // LC169 - MAJORITY ELEMENT (BOYER-MOORE VOTING)
    // ═══════════════════════════════════════════════════════════════
    /**
     * PROBLEM: Find element appearing > n/2 times
     * APPROACH: Boyer-Moore Voting
     *   candidate survives if it can "outlast" all other elements
     *   count goes up for same, down for different; reset at 0
     * TIME: O(n)  SPACE: O(1)
     * EXAMPLE: [2,2,1,1,1,2,2] → 2
     */
    static int majorityElement(int[] nums) {
        int candidate = nums[0], count = 1;
        for (int i = 1; i < nums.length; i++) {
            if (count == 0) { candidate = nums[i]; count = 1; }
            else if (nums[i] == candidate) count++;
            else count--;
        }
        return candidate;
    }

    // ═══════════════════════════════════════════════════════════════
    // LC189 - ROTATE ARRAY
    // ═══════════════════════════════════════════════════════════════
    /**
     * PROBLEM: Rotate array right by k steps
     * APPROACH: Triple Reverse
     *   reverse all → reverse first k → reverse rest
     * TIME: O(n)  SPACE: O(1)
     * EXAMPLE: [1,2,3,4,5,6,7], k=3 → [5,6,7,1,2,3,4]
     */
    static void rotate(int[] nums, int k) {
        k %= nums.length;
        reverse(nums, 0, nums.length - 1);
        reverse(nums, 0, k - 1);
        reverse(nums, k, nums.length - 1);
    }
    static void reverse(int[] a, int l, int r) {
        while (l < r) { int t = a[l]; a[l++] = a[r]; a[r--] = t; }
    }

    // ═══════════════════════════════════════════════════════════════
    // LC238 - PRODUCT OF ARRAY EXCEPT SELF
    // ═══════════════════════════════════════════════════════════════
    /**
     * PROBLEM: Return array where each element is product of all others (no division)
     * APPROACH: Prefix products left-to-right, then suffix right-to-left
     *   result[i] = prefix product * suffix product (excluding i)
     * TIME: O(n)  SPACE: O(1) extra
     * EXAMPLE: [1,2,3,4] → [24,12,8,6]
     */
    static int[] productExceptSelf(int[] nums) {
        int n = nums.length;
        int[] result = new int[n];
        result[0] = 1;
        for (int i = 1; i < n; i++) result[i] = result[i-1] * nums[i-1]; // prefix
        int suffix = 1;
        for (int i = n-1; i >= 0; i--) { result[i] *= suffix; suffix *= nums[i]; }
        return result;
    }

    // ═══════════════════════════════════════════════════════════════
    // LC268 - MISSING NUMBER
    // ═══════════════════════════════════════════════════════════════
    /**
     * PROBLEM: Find missing number in [0..n]
     * APPROACH: Sum formula: expected - actual
     *   Also solvable via XOR: XOR all indices and values
     * TIME: O(n)  SPACE: O(1)
     * EXAMPLE: [3,0,1] → 2
     */
    static int missingNumber(int[] nums) {
        int n = nums.length;
        int expected = n * (n + 1) / 2;
        int actual = 0; for (int num : nums) actual += num;
        return expected - actual;
    }

    // ═══════════════════════════════════════════════════════════════
    // LC283 - MOVE ZEROES
    // ═══════════════════════════════════════════════════════════════
    /**
     * PROBLEM: Move all zeros to end maintaining relative order
     * APPROACH: Slow pointer for next non-zero position
     *   Copy non-zeros forward, fill remaining with zeros
     * TIME: O(n)  SPACE: O(1)
     * EXAMPLE: [0,1,0,3,12] → [1,3,12,0,0]
     */
    static void moveZeroes(int[] nums) {
        int slow = 0;
        for (int fast = 0; fast < nums.length; fast++)
            if (nums[fast] != 0) nums[slow++] = nums[fast];
        while (slow < nums.length) nums[slow++] = 0;
    }

    // ═══════════════════════════════════════════════════════════════
    // LC347 - TOP K FREQUENT ELEMENTS
    // ═══════════════════════════════════════════════════════════════
    /**
     * PROBLEM: Find k most frequent elements
     * APPROACH: Bucket Sort by frequency
     *   freq[count] = list of elements with that count
     *   Collect from highest bucket down
     * TIME: O(n)  SPACE: O(n)
     * EXAMPLE: [1,1,1,2,2,3], k=2 → [1,2]
     */
    static int[] topKFrequent(int[] nums, int k) {
        Map<Integer, Integer> freq = new HashMap<>();
        for (int n : nums) freq.merge(n, 1, Integer::sum);
        // Bucket sort: index = frequency
        List<Integer>[] bucket = new List[nums.length + 1];
        for (int i = 0; i <= nums.length; i++) bucket[i] = new ArrayList<>();
        for (Map.Entry<Integer, Integer> e : freq.entrySet())
            bucket[e.getValue()].add(e.getKey());
        int[] result = new int[k]; int idx = 0;
        for (int i = nums.length; i >= 0 && idx < k; i--)
            for (int n : bucket[i]) { result[idx++] = n; if (idx == k) break; }
        return result;
    }

    // ═══════════════════════════════════════════════════════════════
    // LC442 - FIND ALL DUPLICATES IN AN ARRAY
    // ═══════════════════════════════════════════════════════════════
    /**
     * PROBLEM: Find all duplicates (appears twice) in [1..n]
     * APPROACH: Use sign as visited marker
     *   nums[|nums[i]|-1] negative → visited (duplicate found!)
     * TIME: O(n)  SPACE: O(1) output excluded
     * EXAMPLE: [4,3,2,7,8,2,3,1] → [2,3]
     */
    static List<Integer> findDuplicates(int[] nums) {
        List<Integer> result = new ArrayList<>();
        for (int n : nums) {
            int idx = Math.abs(n) - 1;
            if (nums[idx] < 0) result.add(Math.abs(n)); // already visited
            else nums[idx] = -nums[idx];                 // mark visited
        }
        return result;
    }

    // ═══════════════════════════════════════════════════════════════
    // GFG - EQUILIBRIUM POINT
    // ═══════════════════════════════════════════════════════════════
    /**
     * PROBLEM: Find index where left sum == right sum
     * APPROACH: Prefix sum — leftSum grows, compare with remaining rightSum
     * TIME: O(n)  SPACE: O(1)
     * EXAMPLE: [1,3,5,2,2] → 2 (leftSum=4, rightSum=4)
     */
    static int equilibriumPoint(long[] arr) {
        long total = 0; for (long x : arr) total += x;
        long left = 0;
        for (int i = 0; i < arr.length; i++) {
            total -= arr[i];                          // right sum
            if (left == total) return i + 1;          // 1-indexed
            left += arr[i];
        }
        return -1;
    }

    // ═══════════════════════════════════════════════════════════════
    // GFG - LEADERS IN AN ARRAY
    // ═══════════════════════════════════════════════════════════════
    /**
     * PROBLEM: Find all leaders (no element to right is greater)
     * APPROACH: Traverse right-to-left, track running maximum
     *   Rightmost element is always a leader
     * TIME: O(n)  SPACE: O(1)
     * EXAMPLE: [16,17,4,3,5,2] → [17,5,2]
     */
    static List<Integer> leaders(int[] arr) {
        List<Integer> result = new ArrayList<>();
        int maxRight = arr[arr.length - 1];
        result.add(maxRight);
        for (int i = arr.length - 2; i >= 0; i--) {
            if (arr[i] >= maxRight) { maxRight = arr[i]; result.add(0, arr[i]); }
        }
        return result;
    }

    // ═══════════════════════════════════════════════════════════════
    // GFG - SMALLEST POSITIVE MISSING NUMBER
    // ═══════════════════════════════════════════════════════════════
    /**
     * PROBLEM: Find smallest positive integer not present
     * APPROACH: Cyclic sort for [1..n], then find first mismatch
     * TIME: O(n)  SPACE: O(1)
     * EXAMPLE: [3,-4,-1,1] → 2  |  [1,2,3] → 4
     */
    static int missingPositive(int[] nums) {
        int n = nums.length, i = 0;
        while (i < n) {
            int correct = nums[i] - 1;
            if (nums[i] > 0 && nums[i] <= n && nums[i] != nums[correct]) {
                int t = nums[i]; nums[i] = nums[correct]; nums[correct] = t;
            } else i++;
        }
        for (int j = 0; j < n; j++) if (nums[j] != j + 1) return j + 1;
        return n + 1;
    }

    // ═══════════════════════════════════════════════════════════════
    // GFG - TRAPPING RAIN WATER
    // ═══════════════════════════════════════════════════════════════
    /**
     * PROBLEM: How much water is trapped after raining
     * APPROACH: Two pointers
     *   Water at i = min(maxLeft, maxRight) - height[i]
     *   Process side with smaller max (it's the bottleneck)
     * TIME: O(n)  SPACE: O(1)
     * EXAMPLE: [0,1,0,2,1,0,1,3,2,1,2,1] → 6
     */
    static int trap(int[] height) {
        int l = 0, r = height.length - 1, leftMax = 0, rightMax = 0, water = 0;
        while (l < r) {
            if (height[l] <= height[r]) {
                if (height[l] >= leftMax) leftMax = height[l];
                else water += leftMax - height[l];
                l++;
            } else {
                if (height[r] >= rightMax) rightMax = height[r];
                else water += rightMax - height[r];
                r--;
            }
        }
        return water;
    }

    // ═══════════════════════════════════════════════════════════════
    // GFG - MINIMIZE THE HEIGHTS II
    // ═══════════════════════════════════════════════════════════════
    /**
     * PROBLEM: Add/subtract k from each tower height, minimize max-min difference
     * APPROACH: Sort, then for each split point i:
     *   Left [0..i] all increase (+k), Right [i+1..n] all decrease (-k)
     *   min = min(arr[0]+k, arr[i+1]-k)  max = max(arr[i]+k, arr[n-1]-k)
     * TIME: O(n log n)  SPACE: O(1)
     * EXAMPLE: arr=[1,5,8,10], k=2 → 5 (heights become [3,3,6,8])
     */
    static int getMinDiff(int[] arr, int k) {
        Arrays.sort(arr);
        int n = arr.length;
        int result = arr[n-1] - arr[0]; // worst case: no change
        for (int i = 0; i < n - 1; i++) {
            if (arr[i+1] - k < 0) continue; // height can't go negative
            int minVal = Math.min(arr[0] + k, arr[i+1] - k);
            int maxVal = Math.max(arr[i] + k, arr[n-1] - k);
            result = Math.min(result, maxVal - minVal);
        }
        return result;
    }

    // ═══════════════════════════════════════════════════════════════
    // GFG - SUBARRAY WITH GIVEN SUM
    // ═══════════════════════════════════════════════════════════════
    /**
     * PROBLEM: Find subarray (non-negative) with given sum
     * APPROACH: Sliding window — expand right, shrink left when sum exceeds target
     * TIME: O(n)  SPACE: O(1)
     * EXAMPLE: arr=[1,2,3,7,5], sum=12 → [2,4] (1-indexed)
     */
    static int[] subarrayWithSum(int[] arr, long target) {
        long curSum = arr[0];
        int l = 0;
        for (int r = 1; r <= arr.length; r++) {
            while (curSum > target && l < r - 1) curSum -= arr[l++];
            if (curSum == target) return new int[]{l + 1, r}; // 1-indexed
            if (r < arr.length) curSum += arr[r];
        }
        return new int[]{-1};
    }

    // ═══════════════════════════════════════════════════════════════
    // MAIN - RUN ALL SOLUTIONS
    // ═══════════════════════════════════════════════════════════════
    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║       ARRAY PROBLEMS - ALL SOLUTIONS     ║");
        System.out.println("╚══════════════════════════════════════════╝\n");

        System.out.println("LC1  twoSum([2,7,11,15], 9)         = " + Arrays.toString(twoSum(new int[]{2,7,11,15}, 9)));
        System.out.println("LC11 maxArea([1,8,6,2,5,4,8,3,7])   = " + maxArea(new int[]{1,8,6,2,5,4,8,3,7}));
        System.out.println("LC15 threeSum([-1,0,1,2,-1,-4])     = " + threeSum(new int[]{-1,0,1,2,-1,-4}));
        int[] dup = {0,0,1,1,2,2,3,3,4}; System.out.println("LC26 removeDuplicates             = " + removeDuplicates(dup));
        int[] perm = {1,2,3}; nextPermutation(perm); System.out.println("LC31 nextPermutation([1,2,3])      = " + Arrays.toString(perm));
        System.out.println("LC33 searchRotated([4,5,6,7,0,1,2], 0) = " + searchRotated(new int[]{4,5,6,7,0,1,2}, 0));
        System.out.println("LC53 maxSubArray([-2,1,-3,4,-1,2,1,-5,4]) = " + maxSubArray(new int[]{-2,1,-3,4,-1,2,1,-5,4}));
        int[][] ivs = {{1,3},{2,6},{8,10},{15,18}}; System.out.println("LC56 mergeIntervals               = " + Arrays.deepToString(merge(ivs)));
        int[] colors = {2,0,2,1,1,0}; sortColors(colors); System.out.println("LC75 sortColors                    = " + Arrays.toString(colors));
        System.out.println("LC121 maxProfit([7,1,5,3,6,4])      = " + maxProfit(new int[]{7,1,5,3,6,4}));
        System.out.println("LC128 longestConsecutive([100,4,200,1,3,2]) = " + longestConsecutive(new int[]{100,4,200,1,3,2}));
        System.out.println("LC152 maxProduct([2,3,-2,4])         = " + maxProduct(new int[]{2,3,-2,4}));
        System.out.println("LC153 findMin([3,4,5,1,2])           = " + findMin(new int[]{3,4,5,1,2}));
        System.out.println("LC169 majorityElement([2,2,1,1,1,2,2]) = " + majorityElement(new int[]{2,2,1,1,1,2,2}));
        int[] rotArr = {1,2,3,4,5,6,7}; rotate(rotArr, 3); System.out.println("LC189 rotate([1..7], k=3)          = " + Arrays.toString(rotArr));
        System.out.println("LC238 productExceptSelf([1,2,3,4])  = " + Arrays.toString(productExceptSelf(new int[]{1,2,3,4})));
        System.out.println("LC268 missingNumber([3,0,1])         = " + missingNumber(new int[]{3,0,1}));
        int[] mz = {0,1,0,3,12}; moveZeroes(mz); System.out.println("LC283 moveZeroes                    = " + Arrays.toString(mz));
        System.out.println("LC347 topKFrequent([1,1,1,2,2,3],2) = " + Arrays.toString(topKFrequent(new int[]{1,1,1,2,2,3}, 2)));
        System.out.println("LC442 findDuplicates([4,3,2,7,8,2,3,1]) = " + findDuplicates(new int[]{4,3,2,7,8,2,3,1}));
        System.out.println("GFG  equilibriumPoint([1,3,5,2,2]) = " + equilibriumPoint(new long[]{1,3,5,2,2}));
        System.out.println("GFG  leaders([16,17,4,3,5,2])      = " + leaders(new int[]{16,17,4,3,5,2}));
        System.out.println("GFG  missingPositive([3,-4,-1,1])   = " + missingPositive(new int[]{3,-4,-1,1}));
        System.out.println("GFG  trap([0,1,0,2,1,0,1,3,2,1,2,1]) = " + trap(new int[]{0,1,0,2,1,0,1,3,2,1,2,1}));
        System.out.println("GFG  minimizeHeights([1,5,8,10],k=2) = " + getMinDiff(new int[]{1,5,8,10}, 2));
        System.out.println("GFG  subarrayWithSum([1,2,3,7,5],12) = " + Arrays.toString(subarrayWithSum(new int[]{1,2,3,7,5}, 12)));
    }
}
