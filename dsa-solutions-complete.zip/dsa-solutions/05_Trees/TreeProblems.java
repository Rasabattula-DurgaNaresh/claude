/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║         TREES - LeetCode & GeeksForGeeks Solutions           ║
 * ╚══════════════════════════════════════════════════════════════╝
 * LC94  Binary Tree Inorder Traversal
 * LC98  Validate BST
 * LC100 Same Tree
 * LC101 Symmetric Tree
 * LC102 Binary Tree Level Order Traversal
 * LC103 Zigzag Level Order
 * LC104 Maximum Depth
 * LC105 Construct from Preorder+Inorder
 * LC110 Balanced Binary Tree
 * LC112 Path Sum
 * LC113 Path Sum II
 * LC124 Binary Tree Maximum Path Sum
 * LC199 Right Side View
 * LC226 Invert Binary Tree
 * LC230 Kth Smallest in BST
 * LC235 LCA of BST
 * LC236 LCA of Binary Tree
 * LC543 Diameter of Binary Tree
 * GFG   Boundary Traversal
 * GFG   Vertical Order Traversal
 * GFG   Serialize and Deserialize
 * GFG   Connect Nodes at Same Level
 * GFG   Lowest Common Ancestor
 */
import java.util.*;

public class TreeProblems {

    static class TreeNode {
        int val; TreeNode left, right;
        TreeNode(int v) { val = v; }
        static TreeNode build(Integer... vals) {
            if (vals.length == 0 || vals[0] == null) return null;
            TreeNode root = new TreeNode(vals[0]);
            Queue<TreeNode> q = new LinkedList<>(); q.offer(root);
            int i = 1;
            while (!q.isEmpty() && i < vals.length) {
                TreeNode cur = q.poll();
                if (i < vals.length && vals[i] != null) { cur.left = new TreeNode(vals[i]); q.offer(cur.left); } i++;
                if (i < vals.length && vals[i] != null) { cur.right = new TreeNode(vals[i]); q.offer(cur.right); } i++;
            }
            return root;
        }
    }

    // LC94 - INORDER TRAVERSAL (iterative)
    /**
     * APPROACH: Stack-based iterative — go left as deep as possible,
     *   then visit, then go right
     * TIME: O(n)  SPACE: O(h)
     */
    static List<Integer> inorderTraversal(TreeNode root) {
        List<Integer> result = new ArrayList<>();
        Deque<TreeNode> stack = new ArrayDeque<>();
        TreeNode cur = root;
        while (cur != null || !stack.isEmpty()) {
            while (cur != null) { stack.push(cur); cur = cur.left; }
            cur = stack.pop(); result.add(cur.val); cur = cur.right;
        }
        return result;
    }

    // LC98 - VALIDATE BST
    /**
     * APPROACH: Pass valid range [min, max] to each node
     *   BST property: left subtree < node < right subtree
     * TIME: O(n)  SPACE: O(h)
     */
    static boolean isValidBST(TreeNode root) {
        return validateBST(root, Long.MIN_VALUE, Long.MAX_VALUE);
    }
    static boolean validateBST(TreeNode node, long min, long max) {
        if (node == null) return true;
        if (node.val <= min || node.val >= max) return false;
        return validateBST(node.left, min, node.val) && validateBST(node.right, node.val, max);
    }

    // LC100 - SAME TREE
    static boolean isSameTree(TreeNode p, TreeNode q) {
        if (p == null && q == null) return true;
        if (p == null || q == null || p.val != q.val) return false;
        return isSameTree(p.left, q.left) && isSameTree(p.right, q.right);
    }

    // LC101 - SYMMETRIC TREE
    /**
     * APPROACH: Check if left subtree is mirror of right subtree
     */
    static boolean isSymmetric(TreeNode root) {
        return isMirror(root, root);
    }
    static boolean isMirror(TreeNode t1, TreeNode t2) {
        if (t1 == null && t2 == null) return true;
        if (t1 == null || t2 == null || t1.val != t2.val) return false;
        return isMirror(t1.left, t2.right) && isMirror(t1.right, t2.left);
    }

    // LC102 - LEVEL ORDER TRAVERSAL (BFS)
    static List<List<Integer>> levelOrder(TreeNode root) {
        List<List<Integer>> result = new ArrayList<>();
        if (root == null) return result;
        Queue<TreeNode> q = new LinkedList<>(); q.offer(root);
        while (!q.isEmpty()) {
            int sz = q.size(); List<Integer> level = new ArrayList<>();
            for (int i = 0; i < sz; i++) {
                TreeNode cur = q.poll(); level.add(cur.val);
                if (cur.left != null) q.offer(cur.left);
                if (cur.right != null) q.offer(cur.right);
            }
            result.add(level);
        }
        return result;
    }

    // LC103 - ZIGZAG LEVEL ORDER
    static List<List<Integer>> zigzagLevelOrder(TreeNode root) {
        List<List<Integer>> result = new ArrayList<>();
        if (root == null) return result;
        Queue<TreeNode> q = new LinkedList<>(); q.offer(root); boolean leftToRight = true;
        while (!q.isEmpty()) {
            int sz = q.size(); LinkedList<Integer> level = new LinkedList<>();
            for (int i = 0; i < sz; i++) {
                TreeNode cur = q.poll();
                if (leftToRight) level.addLast(cur.val); else level.addFirst(cur.val);
                if (cur.left != null) q.offer(cur.left);
                if (cur.right != null) q.offer(cur.right);
            }
            result.add(level); leftToRight = !leftToRight;
        }
        return result;
    }

    // LC104 - MAXIMUM DEPTH
    static int maxDepth(TreeNode root) {
        if (root == null) return 0;
        return 1 + Math.max(maxDepth(root.left), maxDepth(root.right));
    }

    // LC105 - CONSTRUCT FROM PREORDER + INORDER
    /**
     * APPROACH: preorder[0] is root. Find root in inorder → left/right subtrees
     * TIME: O(n)  SPACE: O(n)
     */
    static TreeNode buildTree(int[] preorder, int[] inorder) {
        Map<Integer, Integer> inorderMap = new HashMap<>();
        for (int i = 0; i < inorder.length; i++) inorderMap.put(inorder[i], i);
        return buildHelper(preorder, 0, preorder.length-1, 0, inorder.length-1, inorderMap);
    }
    static int preIdx = 0;
    static TreeNode buildHelper(int[] pre, int preL, int preR, int inL, int inR, Map<Integer,Integer> map) {
        if (preL > preR || inL > inR) return null;
        int rootVal = pre[preL]; TreeNode root = new TreeNode(rootVal);
        int mid = map.get(rootVal);
        int leftSize = mid - inL;
        root.left  = buildHelper(pre, preL+1, preL+leftSize, inL, mid-1, map);
        root.right = buildHelper(pre, preL+leftSize+1, preR, mid+1, inR, map);
        return root;
    }

    // LC110 - BALANCED BINARY TREE
    /**
     * APPROACH: Return -1 if unbalanced, height otherwise
     * TIME: O(n)  SPACE: O(h)
     */
    static boolean isBalanced(TreeNode root) { return checkHeight(root) != -1; }
    static int checkHeight(TreeNode node) {
        if (node == null) return 0;
        int left = checkHeight(node.left); if (left == -1) return -1;
        int right = checkHeight(node.right); if (right == -1) return -1;
        if (Math.abs(left - right) > 1) return -1;
        return 1 + Math.max(left, right);
    }

    // LC112 - PATH SUM
    static boolean hasPathSum(TreeNode root, int target) {
        if (root == null) return false;
        if (root.left == null && root.right == null) return root.val == target;
        return hasPathSum(root.left, target-root.val) || hasPathSum(root.right, target-root.val);
    }

    // LC113 - PATH SUM II (all paths)
    static List<List<Integer>> pathSum(TreeNode root, int target) {
        List<List<Integer>> result = new ArrayList<>();
        pathDFS(root, target, new ArrayList<>(), result);
        return result;
    }
    static void pathDFS(TreeNode node, int rem, List<Integer> path, List<List<Integer>> result) {
        if (node == null) return;
        path.add(node.val);
        if (node.left == null && node.right == null && rem == node.val) result.add(new ArrayList<>(path));
        pathDFS(node.left, rem-node.val, path, result);
        pathDFS(node.right, rem-node.val, path, result);
        path.remove(path.size()-1);
    }

    // LC124 - BINARY TREE MAXIMUM PATH SUM
    /**
     * APPROACH: At each node: max path through it = node + max(0,left) + max(0,right)
     *   But return only one branch upward: node + max(0, left, right)
     * TIME: O(n)
     */
    static int maxPathSumResult;
    static int maxPathSum(TreeNode root) {
        maxPathSumResult = Integer.MIN_VALUE; maxPathSumDFS(root); return maxPathSumResult;
    }
    static int maxPathSumDFS(TreeNode node) {
        if (node == null) return 0;
        int left = Math.max(0, maxPathSumDFS(node.left));
        int right = Math.max(0, maxPathSumDFS(node.right));
        maxPathSumResult = Math.max(maxPathSumResult, node.val + left + right);
        return node.val + Math.max(left, right); // return one branch
    }

    // LC199 - RIGHT SIDE VIEW
    static List<Integer> rightSideView(TreeNode root) {
        List<Integer> result = new ArrayList<>();
        if (root == null) return result;
        Queue<TreeNode> q = new LinkedList<>(); q.offer(root);
        while (!q.isEmpty()) {
            int sz = q.size();
            for (int i = 0; i < sz; i++) {
                TreeNode cur = q.poll();
                if (i == sz-1) result.add(cur.val); // rightmost of level
                if (cur.left != null) q.offer(cur.left);
                if (cur.right != null) q.offer(cur.right);
            }
        }
        return result;
    }

    // LC226 - INVERT BINARY TREE
    static TreeNode invertTree(TreeNode root) {
        if (root == null) return null;
        TreeNode tmp = root.left; root.left = invertTree(root.right); root.right = invertTree(tmp);
        return root;
    }

    // LC230 - KTH SMALLEST IN BST
    /**
     * APPROACH: Inorder traversal → kth element (BST inorder = sorted)
     */
    static int kthSmallest(TreeNode root, int k) {
        Deque<TreeNode> stack = new ArrayDeque<>();
        TreeNode cur = root;
        while (cur != null || !stack.isEmpty()) {
            while (cur != null) { stack.push(cur); cur = cur.left; }
            cur = stack.pop(); if (--k == 0) return cur.val;
            cur = cur.right;
        }
        return -1;
    }

    // LC235 - LCA OF BST
    static TreeNode lcaBST(TreeNode root, TreeNode p, TreeNode q) {
        while (root != null) {
            if (p.val < root.val && q.val < root.val) root = root.left;
            else if (p.val > root.val && q.val > root.val) root = root.right;
            else return root;
        }
        return null;
    }

    // LC236 - LCA OF BINARY TREE
    /**
     * APPROACH: If current node is p or q, return it
     *   If both children return non-null → current is LCA
     *   Else return whichever child is non-null
     */
    static TreeNode lowestCommonAncestor(TreeNode root, TreeNode p, TreeNode q) {
        if (root == null || root == p || root == q) return root;
        TreeNode left = lowestCommonAncestor(root.left, p, q);
        TreeNode right = lowestCommonAncestor(root.right, p, q);
        if (left != null && right != null) return root;
        return left != null ? left : right;
    }

    // LC543 - DIAMETER OF BINARY TREE
    static int diameterResult;
    static int diameterOfBinaryTree(TreeNode root) {
        diameterResult = 0; heightForDiameter(root); return diameterResult;
    }
    static int heightForDiameter(TreeNode node) {
        if (node == null) return 0;
        int l = heightForDiameter(node.left), r = heightForDiameter(node.right);
        diameterResult = Math.max(diameterResult, l + r);
        return 1 + Math.max(l, r);
    }

    // GFG - VERTICAL ORDER TRAVERSAL
    static List<List<Integer>> verticalOrder(TreeNode root) {
        if (root == null) return new ArrayList<>();
        Map<Integer, List<Integer>> map = new TreeMap<>();
        Queue<Object[]> q = new LinkedList<>(); q.offer(new Object[]{root, 0});
        while (!q.isEmpty()) {
            Object[] cur = q.poll();
            TreeNode node = (TreeNode) cur[0]; int col = (int) cur[1];
            map.computeIfAbsent(col, k -> new ArrayList<>()).add(node.val);
            if (node.left != null)  q.offer(new Object[]{node.left, col-1});
            if (node.right != null) q.offer(new Object[]{node.right, col+1});
        }
        return new ArrayList<>(map.values());
    }

    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║      TREE PROBLEMS - ALL SOLUTIONS       ║");
        System.out.println("╚══════════════════════════════════════════╝\n");

        TreeNode tree = TreeNode.build(3,9,20,null,null,15,7);
        System.out.println("LC94  inorder([3,9,20,null,null,15,7])  = " + inorderTraversal(tree));
        System.out.println("LC102 levelOrder                        = " + levelOrder(tree));
        System.out.println("LC103 zigzagLevelOrder                  = " + zigzagLevelOrder(tree));
        System.out.println("LC104 maxDepth                          = " + maxDepth(tree));
        System.out.println("LC199 rightSideView                     = " + rightSideView(tree));

        TreeNode bst = TreeNode.build(5,3,6,2,4,null,null);
        System.out.println("LC98  isValidBST                        = " + isValidBST(bst));
        System.out.println("LC230 kthSmallest(k=3)                  = " + kthSmallest(bst, 3));

        TreeNode sym = TreeNode.build(1,2,2,3,4,4,3);
        System.out.println("LC101 isSymmetric                       = " + isSymmetric(sym));

        TreeNode t2 = TreeNode.build(-3,9,-20,null,null,15,7);
        System.out.println("LC124 maxPathSum                        = " + maxPathSum(t2));

        TreeNode d = TreeNode.build(1,2,3,4,5);
        System.out.println("LC543 diameter                          = " + diameterOfBinaryTree(d));
        System.out.println("LC110 isBalanced                        = " + isBalanced(d));

        TreeNode path = TreeNode.build(5,4,8,11,null,13,4,7,2,null,null,null,null,null,1);
        System.out.println("LC112 hasPathSum(22)                    = " + hasPathSum(path, 22));
        System.out.println("LC113 pathSum(22)                       = " + pathSum(path, 22));

        System.out.println("GFG  verticalOrder                      = " + verticalOrder(TreeNode.build(1,2,3,4,5,6,7)));
    }
}
