/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║        RECURSION - LeetCode & GeeksForGeeks Solutions        ║
 * ╚══════════════════════════════════════════════════════════════╝
 * Classic recursion problems with full explanation of call stack
 * LC50  Pow(x, n)
 * LC231 Power of Two
 * LC326 Power of Three
 * LC779 K-th Symbol in Grammar
 * LC894 All Possible Full Binary Trees
 * LC95  Unique BSTs II (generate all)
 * LC241 Different Ways to Add Parentheses
 * LC282 Expression Add Operators
 * GFG   Tower of Hanoi
 * GFG   Josephus Problem
 * GFG   Print all subsets
 * GFG   Permutations of String
 * GFG   Print N-bit binary strings
 * GFG   Flood Fill
 */
import java.util.*;

public class RecursionProblems {

    // LC50 - POW(x, n) — FAST EXPONENTIATION
    /**
     * APPROACH: Divide and conquer
     *   x^n = x^(n/2) * x^(n/2)  if n is even
     *   x^n = x * x^(n-1)        if n is odd
     *   Handle negative n: x^(-n) = 1 / x^n
     * TIME: O(log n)  SPACE: O(log n) stack
     * EXAMPLE: 2.0^10 → 1024.0  |  2.0^-2 → 0.25
     */
    static double myPow(double x, int n) {
        if (n == 0) return 1;
        if (n < 0) { x = 1/x; n = -(n+1); return x * myPow(x*x, n/2); } // careful: Integer.MIN_VALUE
        if (n % 2 == 0) return myPow(x*x, n/2);
        return x * myPow(x*x, n/2);
    }

    // GFG - TOWER OF HANOI
    /**
     * PROBLEM: Move n disks from src to dst using aux peg
     *   Rule: never place larger disk on smaller
     * APPROACH: 
     *   1. Move (n-1) disks from src to aux
     *   2. Move disk n from src to dst
     *   3. Move (n-1) disks from aux to dst
     * TIME: O(2^n)  MOVES: 2^n - 1
     * EXAMPLE: n=3 → 7 moves
     */
    static void towerOfHanoi(int n, char from, char to, char aux) {
        if (n == 1) { System.out.println("  Move disk 1 from " + from + " to " + to); return; }
        towerOfHanoi(n-1, from, aux, to);
        System.out.println("  Move disk " + n + " from " + from + " to " + to);
        towerOfHanoi(n-1, aux, to, from);
    }

    // GFG - JOSEPHUS PROBLEM
    /**
     * PROBLEM: n people in circle, every k-th person eliminated. Find survivor.
     * APPROACH: Recursive formula
     *   J(1,k) = 0
     *   J(n,k) = (J(n-1,k) + k) % n
     * TIME: O(n)  SPACE: O(n) stack
     */
    static int josephus(int n, int k) {
        if (n == 1) return 0;
        return (josephus(n-1, k) + k) % n;
    }

    // LC779 - K-TH SYMBOL IN GRAMMAR
    /**
     * PROBLEM: Row 1 = "0". Each row: 0→01, 1→10. Find k-th char in row n.
     * APPROACH: 
     *   k-th char in row n = same as (k+1)/2-th char in row n-1, possibly flipped
     *   If k is odd: same as parent
     *   If k is even: flipped from parent
     * TIME: O(n)  SPACE: O(n)
     */
    static int kthGrammar(int n, int k) {
        if (n == 1) return 0;
        int parent = kthGrammar(n-1, (k+1)/2);
        return (k % 2 == 1) ? parent : 1 - parent; // odd=same, even=flip
    }

    // LC241 - DIFFERENT WAYS TO ADD PARENTHESES
    /**
     * APPROACH: Divide at each operator, recursively compute left & right
     *   Then combine all left results with all right results
     * TIME: O(Catalan(n))  SPACE: O(n)
     * EXAMPLE: "2*3-4*5" → [-34,-14,-10,10,34]
     */
    static List<Integer> diffWaysToCompute(String expression) {
        List<Integer> result = new ArrayList<>();
        for (int i = 0; i < expression.length(); i++) {
            char c = expression.charAt(i);
            if (c=='+' || c=='-' || c=='*') {
                List<Integer> left  = diffWaysToCompute(expression.substring(0, i));
                List<Integer> right = diffWaysToCompute(expression.substring(i+1));
                for (int l : left) for (int r : right) {
                    if (c=='+') result.add(l+r);
                    else if (c=='-') result.add(l-r);
                    else result.add(l*r);
                }
            }
        }
        if (result.isEmpty()) result.add(Integer.parseInt(expression)); // single number
        return result;
    }

    // LC95 - UNIQUE BINARY SEARCH TREES II (generate all structures)
    /**
     * APPROACH: For each i as root, generate all left BSTs [1..i-1]
     *   and all right BSTs [i+1..n], combine all pairs
     * TIME: O(Catalan(n))  SPACE: O(Catalan(n))
     */
    static class TreeNode { int val; TreeNode left, right; TreeNode(int v) { val=v; } }
    static List<TreeNode> generateTrees(int n) {
        return generateRange(1, n);
    }
    static List<TreeNode> generateRange(int start, int end) {
        List<TreeNode> result = new ArrayList<>();
        if (start > end) { result.add(null); return result; }
        for (int i = start; i <= end; i++) {
            List<TreeNode> lefts = generateRange(start, i-1);
            List<TreeNode> rights = generateRange(i+1, end);
            for (TreeNode l : lefts) for (TreeNode r : rights) {
                TreeNode root = new TreeNode(i);
                root.left = l; root.right = r; result.add(root);
            }
        }
        return result;
    }

    // GFG - PRINT ALL SUBSETS (Power Set)
    /**
     * APPROACH: Include/exclude each element recursively
     * TIME: O(2^n)  SPACE: O(n)
     */
    static void printSubsets(int[] arr, int idx, List<Integer> current) {
        if (idx == arr.length) {
            System.out.println("    " + current);
            return;
        }
        // Exclude current
        printSubsets(arr, idx+1, current);
        // Include current
        current.add(arr[idx]);
        printSubsets(arr, idx+1, current);
        current.remove(current.size()-1);
    }

    // GFG - PERMUTATIONS OF STRING
    /**
     * APPROACH: Swap character at position i with each character from i to n-1
     * TIME: O(n! * n)  SPACE: O(n)
     */
    static List<String> permutations(char[] str, int l) {
        List<String> result = new ArrayList<>();
        if (l == str.length - 1) { result.add(new String(str)); return result; }
        for (int i = l; i < str.length; i++) {
            char t = str[l]; str[l] = str[i]; str[i] = t; // swap
            result.addAll(permutations(str, l+1));
            t = str[l]; str[l] = str[i]; str[i] = t; // swap back
        }
        return result;
    }

    // GFG - N-BIT BINARY STRINGS (more 1s than 0s at every prefix)
    /**
     * PROBLEM: Print all n-bit binary strings where every prefix has >= 1s than 0s
     * APPROACH: Track count of 1s and 0s; only add 0 if zeros < ones
     */
    static void printBinaryStrings(int n, int ones, int zeros, String cur) {
        if (cur.length() == n) { System.out.println("    " + cur); return; }
        printBinaryStrings(n, ones+1, zeros, cur+"1");
        if (zeros < ones) printBinaryStrings(n, ones, zeros+1, cur+"0");
    }

    // GFG - FLOOD FILL
    /**
     * PROBLEM: Fill connected region starting at (r,c) with newColor
     * APPROACH: DFS from start, paint cells with same original color
     * TIME: O(m*n)  SPACE: O(m*n) stack
     */
    static int[][] floodFill(int[][] image, int sr, int sc, int color) {
        if (image[sr][sc] == color) return image; // already that color
        dfsFlood(image, sr, sc, image[sr][sc], color);
        return image;
    }
    static void dfsFlood(int[][] img, int r, int c, int orig, int newColor) {
        if (r<0||r>=img.length||c<0||c>=img[0].length||img[r][c]!=orig) return;
        img[r][c] = newColor;
        dfsFlood(img,r+1,c,orig,newColor); dfsFlood(img,r-1,c,orig,newColor);
        dfsFlood(img,r,c+1,orig,newColor); dfsFlood(img,r,c-1,orig,newColor);
    }

    // LC231 - POWER OF TWO (recursive)
    static boolean isPowerOfTwo(int n) { return n>0 && (n==1 || (n%2==0 && isPowerOfTwo(n/2))); }

    // LC326 - POWER OF THREE (recursive)
    static boolean isPowerOfThree(int n) { return n>0 && (n==1 || (n%3==0 && isPowerOfThree(n/3))); }

    // LC894 - ALL POSSIBLE FULL BINARY TREES (0 or 2 children)
    /**
     * APPROACH: n must be odd. Root + left(i nodes) + right(n-1-i nodes)
     *   Memoize by n
     */
    static Map<Integer, List<TreeNode>> fbtMemo = new HashMap<>();
    static List<TreeNode> allPossibleFBT(int n) {
        if (fbtMemo.containsKey(n)) return fbtMemo.get(n);
        List<TreeNode> result = new ArrayList<>();
        if (n == 1) { result.add(new TreeNode(0)); }
        else if (n % 2 == 1) {
            for (int i = 1; i < n; i += 2) {
                for (TreeNode l : allPossibleFBT(i))
                    for (TreeNode r : allPossibleFBT(n-1-i)) {
                        TreeNode root = new TreeNode(0);
                        root.left = l; root.right = r; result.add(root);
                    }
            }
        }
        fbtMemo.put(n, result);
        return result;
    }

    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║    RECURSION PROBLEMS - ALL SOLUTIONS    ║");
        System.out.println("╚══════════════════════════════════════════╝\n");

        System.out.println("LC50  myPow(2.0, 10)               = " + myPow(2.0, 10));
        System.out.println("      myPow(2.0, -2)               = " + myPow(2.0, -2));
        System.out.println("LC231 isPowerOfTwo(16)             = " + isPowerOfTwo(16));
        System.out.println("LC326 isPowerOfThree(27)           = " + isPowerOfThree(27));
        System.out.println("LC779 kthGrammar(4, 5)             = " + kthGrammar(4, 5));
        System.out.println("LC241 diffWaysToCompute(2*3-4*5)   = " + diffWaysToCompute("2*3-4*5"));
        System.out.println("LC95  generateTrees(3).size        = " + generateTrees(3).size());
        System.out.println("LC894 allPossibleFBT(7).size       = " + allPossibleFBT(7).size());

        System.out.println("\nGFG  Tower of Hanoi (n=3):");
        towerOfHanoi(3, 'A', 'C', 'B');

        System.out.println("GFG  Josephus(n=7, k=3) survivor = " + josephus(7, 3) + " (0-indexed)");

        System.out.println("\nGFG  Subsets of [1,2,3]:");
        printSubsets(new int[]{1,2,3}, 0, new ArrayList<>());

        System.out.println("GFG  Permutations of \"ABC\": " + permutations("ABC".toCharArray(), 0));

        System.out.println("\nGFG  3-bit valid strings:");
        printBinaryStrings(4, 0, 0, "");

        int[][] img = {{1,1,1},{1,1,0},{1,0,1}};
        System.out.println("GFG  floodFill(sr=1,sc=1,color=2) = " + Arrays.deepToString(floodFill(img,1,1,2)));
    }
}
