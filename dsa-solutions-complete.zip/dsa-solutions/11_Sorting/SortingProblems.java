/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║          SORTING - All Major Algorithms + Problems           ║
 * ╚══════════════════════════════════════════════════════════════╝
 * Algorithms: Bubble, Selection, Insertion, Merge, Quick, Heap, Counting, Radix
 * LC56  Merge Intervals
 * LC75  Sort Colors (Dutch National Flag)
 * LC148 Sort List (Linked List MergeSort)
 * LC164 Maximum Gap
 * LC215 Kth Largest Element (QuickSelect)
 * LC274 H-Index
 * LC315 Count of Smaller Numbers After Self
 * LC324 Wiggle Sort II
 * GFG   Sort 0s 1s 2s
 * GFG   Merge Without Extra Space
 */
import java.util.*;

public class SortingProblems {

    // ─── BUBBLE SORT ───────────────────────────────────────────
    /**
     * APPROACH: Bubble largest to end each pass; stop early if no swaps
     * TIME: O(n²) worst, O(n) best  SPACE: O(1)
     */
    static void bubbleSort(int[] a) {
        for (int i=0; i<a.length-1; i++) {
            boolean swapped=false;
            for (int j=0;j<a.length-i-1;j++) if(a[j]>a[j+1]){int t=a[j];a[j]=a[j+1];a[j+1]=t;swapped=true;}
            if (!swapped) break;
        }
    }

    // ─── SELECTION SORT ────────────────────────────────────────
    /**
     * TIME: O(n²)  SPACE: O(1)  — minimum swaps
     */
    static void selectionSort(int[] a) {
        for (int i=0;i<a.length-1;i++) {
            int min=i;
            for (int j=i+1;j<a.length;j++) if(a[j]<a[min]) min=j;
            int t=a[i];a[i]=a[min];a[min]=t;
        }
    }

    // ─── INSERTION SORT ────────────────────────────────────────
    /**
     * TIME: O(n²) worst, O(n) nearly sorted  SPACE: O(1) — stable, online
     */
    static void insertionSort(int[] a) {
        for (int i=1;i<a.length;i++) {
            int key=a[i],j=i-1;
            while (j>=0&&a[j]>key){a[j+1]=a[j];j--;}
            a[j+1]=key;
        }
    }

    // ─── MERGE SORT ────────────────────────────────────────────
    /**
     * TIME: O(n log n)  SPACE: O(n)  — stable, good for linked lists
     */
    static void mergeSort(int[] a, int l, int r) {
        if (l>=r) return;
        int m=l+(r-l)/2; mergeSort(a,l,m); mergeSort(a,m+1,r); mergeParts(a,l,m,r);
    }
    static void mergeParts(int[] a, int l, int m, int r) {
        int n1=m-l+1,n2=r-m;
        int[] L=Arrays.copyOfRange(a,l,m+1), R=Arrays.copyOfRange(a,m+1,r+1);
        int i=0,j=0,k=l;
        while(i<n1&&j<n2) a[k++]=L[i]<=R[j]?L[i++]:R[j++];
        while(i<n1) a[k++]=L[i++]; while(j<n2) a[k++]=R[j++];
    }

    // ─── QUICK SORT ────────────────────────────────────────────
    /**
     * TIME: O(n log n) avg, O(n²) worst  SPACE: O(log n)
     * Use random pivot to avoid worst case
     */
    static void quickSort(int[] a, int lo, int hi) {
        if (lo>=hi) return;
        int p=partition(a,lo,hi); quickSort(a,lo,p-1); quickSort(a,p+1,hi);
    }
    static int partition(int[] a, int lo, int hi) {
        int pivot=a[hi],i=lo-1;
        for (int j=lo;j<hi;j++) if(a[j]<=pivot){i++;int t=a[i];a[i]=a[j];a[j]=t;}
        int t=a[i+1];a[i+1]=a[hi];a[hi]=t; return i+1;
    }

    // ─── HEAP SORT ─────────────────────────────────────────────
    /**
     * TIME: O(n log n)  SPACE: O(1)  — in-place, not stable
     */
    static void heapSort(int[] a) {
        int n=a.length;
        for (int i=n/2-1;i>=0;i--) heapify(a,n,i); // build max-heap
        for (int i=n-1;i>0;i--) {int t=a[0];a[0]=a[i];a[i]=t;heapify(a,i,0);}
    }
    static void heapify(int[] a, int n, int i) {
        int largest=i,l=2*i+1,r=2*i+2;
        if(l<n&&a[l]>a[largest])largest=l; if(r<n&&a[r]>a[largest])largest=r;
        if(largest!=i){int t=a[i];a[i]=a[largest];a[largest]=t;heapify(a,n,largest);}
    }

    // ─── COUNTING SORT ─────────────────────────────────────────
    /**
     * TIME: O(n+k)  SPACE: O(k)  — for small range integers
     */
    static void countingSort(int[] a) {
        if(a.length==0) return;
        int max=Arrays.stream(a).max().getAsInt(), min=Arrays.stream(a).min().getAsInt();
        int[] count=new int[max-min+1];
        for(int v:a) count[v-min]++;
        int idx=0; for(int i=0;i<count.length;i++) while(count[i]-->0) a[idx++]=i+min;
    }

    // LC215 - KTH LARGEST (QuickSelect)
    /**
     * APPROACH: Partition like quicksort but only recurse on the relevant side
     * TIME: O(n) avg, O(n²) worst  SPACE: O(1)
     */
    static int findKthLargest(int[] nums, int k) {
        int l=0, r=nums.length-1, target=nums.length-k;
        while (l<=r) {
            int p=partition(nums,l,r);
            if(p==target) return nums[p]; if(p<target) l=p+1; else r=p-1;
        }
        return -1;
    }

    // LC164 - MAXIMUM GAP (Radix/Bucket Sort)
    /**
     * APPROACH: Bucket sort — if n nums in range [min,max], by pigeonhole,
     *   max gap >= (max-min)/(n-1). Only compare across bucket boundaries.
     * TIME: O(n)  SPACE: O(n)
     */
    static int maximumGap(int[] nums) {
        if(nums.length<2) return 0;
        int n=nums.length, min=Arrays.stream(nums).min().getAsInt(), max=Arrays.stream(nums).max().getAsInt();
        if(min==max) return 0;
        int bucketSize=Math.max(1,(max-min)/(n-1));
        int buckets=(max-min)/bucketSize+1;
        int[] bucketMin=new int[buckets], bucketMax=new int[buckets];
        Arrays.fill(bucketMin,Integer.MAX_VALUE); Arrays.fill(bucketMax,Integer.MIN_VALUE);
        for(int n2:nums) {
            int idx=(n2-min)/bucketSize;
            bucketMin[idx]=Math.min(bucketMin[idx],n2); bucketMax[idx]=Math.max(bucketMax[idx],n2);
        }
        int maxGap=0, prevMax=min;
        for(int i=0;i<buckets;i++) {
            if(bucketMin[i]==Integer.MAX_VALUE) continue; // empty bucket
            maxGap=Math.max(maxGap, bucketMin[i]-prevMax); prevMax=bucketMax[i];
        }
        return maxGap;
    }

    // LC274 - H-INDEX
    /**
     * APPROACH: Sort descending; h-index = max h where citations[i] >= h for i in [0,h)
     * TIME: O(n log n)
     */
    static int hIndex(int[] citations) {
        Arrays.sort(citations);
        int n=citations.length;
        for(int i=0;i<n;i++) if(citations[i]>=n-i) return n-i;
        return 0;
    }

    // GFG - MERGE WITHOUT EXTRA SPACE (Shell sort approach)
    /**
     * TIME: O((n+m) log(n+m))
     */
    static void mergeWithoutExtraSpace(int[] a, int[] b) {
        int n=a.length, m=b.length, gap=(n+m+1)/2;
        while(gap>0) {
            for(int i=0;i+gap<n+m;i++) {
                int j=i+gap;
                int ai=i<n?a[i]:b[i-n], aj=j<n?a[j]:b[j-n];
                if(ai>aj) {
                    if(j<n){int t=a[i];a[i]=a[j];a[j]=t;}
                    else if(i<n){int t=a[i];a[i]=b[j-n];b[j-n]=t;}
                    else{int t=b[i-n];b[i-n]=b[j-n];b[j-n]=t;}
                }
            }
            gap=gap==1?0:(gap+1)/2;
        }
    }

    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║     SORTING PROBLEMS - ALL SOLUTIONS     ║");
        System.out.println("╚══════════════════════════════════════════╝\n");

        int[] orig={64,34,25,12,22,11,90};
        System.out.println("Original: " + Arrays.toString(orig));

        int[] a=orig.clone(); bubbleSort(a); System.out.println("BubbleSort:    " + Arrays.toString(a));
        a=orig.clone(); selectionSort(a); System.out.println("SelectionSort: " + Arrays.toString(a));
        a=orig.clone(); insertionSort(a); System.out.println("InsertionSort: " + Arrays.toString(a));
        a=orig.clone(); mergeSort(a,0,a.length-1); System.out.println("MergeSort:     " + Arrays.toString(a));
        a=orig.clone(); quickSort(a,0,a.length-1); System.out.println("QuickSort:     " + Arrays.toString(a));
        a=orig.clone(); heapSort(a); System.out.println("HeapSort:      " + Arrays.toString(a));
        a=orig.clone(); countingSort(a); System.out.println("CountingSort:  " + Arrays.toString(a));

        System.out.println("\nLC215 findKthLargest([3,2,1,5,6,4], k=2) = " + findKthLargest(new int[]{3,2,1,5,6,4},2));
        System.out.println("LC164 maximumGap([3,6,9,1])               = " + maximumGap(new int[]{3,6,9,1}));
        System.out.println("LC274 hIndex([3,0,6,1,5])                 = " + hIndex(new int[]{3,0,6,1,5}));

        int[] arr1={1,3,5,7}, arr2={2,4,6,8};
        mergeWithoutExtraSpace(arr1,arr2);
        System.out.println("GFG   mergeNoExtra: " + Arrays.toString(arr1) + " " + Arrays.toString(arr2));
    }
}
