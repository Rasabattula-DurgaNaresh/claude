/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║          GRAPHS - LeetCode & GeeksForGeeks Solutions         ║
 * ╚══════════════════════════════════════════════════════════════╝
 * LC127  Word Ladder
 * LC133  Clone Graph
 * LC200  Number of Islands
 * LC207  Course Schedule (Cycle Detection)
 * LC210  Course Schedule II (Topo Sort)
 * LC269  Alien Dictionary
 * LC286  Walls and Gates
 * LC310  Minimum Height Trees
 * LC329  Longest Increasing Path in Matrix
 * LC399  Evaluate Division
 * LC417  Pacific Atlantic Water Flow
 * LC547  Number of Provinces
 * LC684  Redundant Connection
 * LC695  Max Area of Island
 * LC743  Network Delay Time (Dijkstra)
 * LC785  Is Graph Bipartite
 * GFG    Dijkstra's Algorithm
 * GFG    Bellman-Ford
 * GFG    Floyd Warshall
 * GFG    Prim's MST
 * GFG    Kruskal's MST
 * GFG    Strongly Connected Components (Kosaraju)
 */
import java.util.*;

public class GraphProblems {

    // LC200 - NUMBER OF ISLANDS (DFS Flood Fill)
    /**
     * APPROACH: DFS from each '1', mark visited by setting to '0'
     * TIME: O(m*n)  SPACE: O(m*n)
     */
    static int numIslands(char[][] grid) {
        int count = 0, rows = grid.length, cols = grid[0].length;
        for (int r = 0; r < rows; r++) for (int c = 0; c < cols; c++)
            if (grid[r][c] == '1') { dfsIsland(grid, r, c, rows, cols); count++; }
        return count;
    }
    static void dfsIsland(char[][] g, int r, int c, int rows, int cols) {
        if (r<0||r>=rows||c<0||c>=cols||g[r][c]!='1') return;
        g[r][c]='0';
        dfsIsland(g,r+1,c,rows,cols); dfsIsland(g,r-1,c,rows,cols);
        dfsIsland(g,r,c+1,rows,cols); dfsIsland(g,r,c-1,rows,cols);
    }

    // LC695 - MAX AREA OF ISLAND
    static int maxAreaOfIsland(int[][] grid) {
        int maxArea = 0, rows = grid.length, cols = grid[0].length;
        for (int r = 0; r < rows; r++) for (int c = 0; c < cols; c++)
            if (grid[r][c] == 1) maxArea = Math.max(maxArea, dfsArea(grid, r, c, rows, cols));
        return maxArea;
    }
    static int dfsArea(int[][] g, int r, int c, int rows, int cols) {
        if (r<0||r>=rows||c<0||c>=cols||g[r][c]!=1) return 0;
        g[r][c]=0;
        return 1+dfsArea(g,r+1,c,rows,cols)+dfsArea(g,r-1,c,rows,cols)+dfsArea(g,r,c+1,rows,cols)+dfsArea(g,r,c-1,rows,cols);
    }

    // LC547 - NUMBER OF PROVINCES (Union-Find)
    /**
     * APPROACH: Union-Find — each city is a node; merge connected cities
     * TIME: O(n²*α(n))
     */
    static int findCircleNum(int[][] isConnected) {
        int n = isConnected.length;
        int[] parent = new int[n];
        for (int i = 0; i < n; i++) parent[i] = i;
        int components = n;
        for (int i = 0; i < n; i++) for (int j = i+1; j < n; j++) {
            if (isConnected[i][j] == 1) {
                int pi = find(parent, i), pj = find(parent, j);
                if (pi != pj) { parent[pi] = pj; components--; }
            }
        }
        return components;
    }
    static int find(int[] parent, int x) {
        if (parent[x] != x) parent[x] = find(parent, parent[x]);
        return parent[x];
    }

    // LC207 - COURSE SCHEDULE (Cycle Detection via DFS)
    /**
     * APPROACH: DFS with states: 0=unvisited, 1=visiting(in stack), 2=done
     *   If we reach a node in state 1 → cycle exists → impossible
     * TIME: O(V+E)  SPACE: O(V+E)
     */
    static boolean canFinish(int numCourses, int[][] prerequisites) {
        List<List<Integer>> graph = new ArrayList<>();
        for (int i = 0; i < numCourses; i++) graph.add(new ArrayList<>());
        for (int[] p : prerequisites) graph.get(p[1]).add(p[0]);
        int[] state = new int[numCourses]; // 0,1,2
        for (int i = 0; i < numCourses; i++) if (!dfsTopSort(graph, state, i)) return false;
        return true;
    }
    static boolean dfsTopSort(List<List<Integer>> g, int[] state, int node) {
        if (state[node] == 1) return false; // cycle!
        if (state[node] == 2) return true;
        state[node] = 1;
        for (int next : g.get(node)) if (!dfsTopSort(g, state, next)) return false;
        state[node] = 2; return true;
    }

    // LC210 - COURSE SCHEDULE II (Topological Sort - Kahn's BFS)
    /**
     * APPROACH: BFS with indegree — process 0-indegree nodes first
     * TIME: O(V+E)
     */
    static int[] findOrder(int numCourses, int[][] prerequisites) {
        List<List<Integer>> graph = new ArrayList<>();
        int[] indegree = new int[numCourses];
        for (int i = 0; i < numCourses; i++) graph.add(new ArrayList<>());
        for (int[] p : prerequisites) { graph.get(p[1]).add(p[0]); indegree[p[0]]++; }
        Queue<Integer> q = new LinkedList<>();
        for (int i = 0; i < numCourses; i++) if (indegree[i] == 0) q.offer(i);
        int[] order = new int[numCourses]; int idx = 0;
        while (!q.isEmpty()) {
            int cur = q.poll(); order[idx++] = cur;
            for (int next : graph.get(cur)) if (--indegree[next] == 0) q.offer(next);
        }
        return idx == numCourses ? order : new int[]{};
    }

    // LC417 - PACIFIC ATLANTIC WATER FLOW
    /**
     * APPROACH: Reverse BFS from both oceans simultaneously
     *   Pacific: top row + left col; Atlantic: bottom row + right col
     *   Find cells reachable from both
     * TIME: O(m*n)
     */
    static List<List<Integer>> pacificAtlantic(int[][] heights) {
        int m = heights.length, n = heights[0].length;
        boolean[][] pac = new boolean[m][n], atl = new boolean[m][n];
        Queue<int[]> pQ = new LinkedList<>(), aQ = new LinkedList<>();
        for (int i = 0; i < m; i++) {
            pQ.offer(new int[]{i,0}); pac[i][0]=true;
            aQ.offer(new int[]{i,n-1}); atl[i][n-1]=true;
        }
        for (int j = 0; j < n; j++) {
            pQ.offer(new int[]{0,j}); pac[0][j]=true;
            aQ.offer(new int[]{m-1,j}); atl[m-1][j]=true;
        }
        bfsOcean(heights, pQ, pac, m, n);
        bfsOcean(heights, aQ, atl, m, n);
        List<List<Integer>> result = new ArrayList<>();
        for (int i = 0; i < m; i++) for (int j = 0; j < n; j++)
            if (pac[i][j] && atl[i][j]) result.add(Arrays.asList(i, j));
        return result;
    }
    static void bfsOcean(int[][] h, Queue<int[]> q, boolean[][] visited, int m, int n) {
        int[][] dirs = {{1,0},{-1,0},{0,1},{0,-1}};
        while (!q.isEmpty()) {
            int[] cur = q.poll();
            for (int[] d : dirs) {
                int nr=cur[0]+d[0], nc=cur[1]+d[1];
                if (nr>=0&&nr<m&&nc>=0&&nc<n&&!visited[nr][nc]&&h[nr][nc]>=h[cur[0]][cur[1]]) {
                    visited[nr][nc]=true; q.offer(new int[]{nr,nc});
                }
            }
        }
    }

    // LC785 - IS GRAPH BIPARTITE? (2-coloring via BFS)
    /**
     * APPROACH: BFS coloring with 2 colors
     *   If neighbor has same color → not bipartite
     * TIME: O(V+E)
     */
    static boolean isBipartite(int[][] graph) {
        int n = graph.length; int[] color = new int[n];
        for (int i = 0; i < n; i++) {
            if (color[i] != 0) continue;
            Queue<Integer> q = new LinkedList<>(); q.offer(i); color[i] = 1;
            while (!q.isEmpty()) {
                int cur = q.poll();
                for (int next : graph[cur]) {
                    if (color[next] == 0) { color[next] = -color[cur]; q.offer(next); }
                    else if (color[next] == color[cur]) return false;
                }
            }
        }
        return true;
    }

    // LC684 - REDUNDANT CONNECTION
    static int[] findRedundantConnection(int[][] edges) {
        int n = edges.length; int[] parent = new int[n+1];
        for (int i = 1; i <= n; i++) parent[i] = i;
        for (int[] e : edges) {
            int pa = find(parent, e[0]), pb = find(parent, e[1]);
            if (pa == pb) return e;
            parent[pa] = pb;
        }
        return new int[]{};
    }

    // LC743 - NETWORK DELAY TIME (Dijkstra)
    /**
     * APPROACH: Dijkstra's shortest path from source
     *   Min-heap: [distance, node]; relax edges greedily
     * TIME: O((V+E) log V)
     */
    static int networkDelayTime(int[][] times, int n, int k) {
        Map<Integer, List<int[]>> graph = new HashMap<>();
        for (int[] t : times) graph.computeIfAbsent(t[0], x -> new ArrayList<>()).add(new int[]{t[1], t[2]});
        int[] dist = new int[n+1]; Arrays.fill(dist, Integer.MAX_VALUE);
        dist[k] = 0;
        PriorityQueue<int[]> pq = new PriorityQueue<>(Comparator.comparingInt(a->a[0]));
        pq.offer(new int[]{0, k});
        while (!pq.isEmpty()) {
            int[] cur = pq.poll();
            int d = cur[0], node = cur[1];
            if (d > dist[node]) continue; // stale
            for (int[] edge : graph.getOrDefault(node, List.of())) {
                int newDist = dist[node] + edge[1];
                if (newDist < dist[edge[0]]) { dist[edge[0]]=newDist; pq.offer(new int[]{newDist, edge[0]}); }
            }
        }
        int maxDist = 0;
        for (int i = 1; i <= n; i++) { if (dist[i]==Integer.MAX_VALUE) return -1; maxDist=Math.max(maxDist,dist[i]); }
        return maxDist;
    }

    // LC329 - LONGEST INCREASING PATH IN MATRIX
    /**
     * APPROACH: DFS with memoization — memo[i][j] = longest path starting at (i,j)
     * TIME: O(m*n)
     */
    static int[][] lipMemo;
    static int longestIncreasingPath(int[][] matrix) {
        int m = matrix.length, n = matrix[0].length, maxPath = 0;
        lipMemo = new int[m][n];
        for (int i = 0; i < m; i++) for (int j = 0; j < n; j++)
            maxPath = Math.max(maxPath, dfsLIP(matrix, i, j, m, n));
        return maxPath;
    }
    static int dfsLIP(int[][] mat, int r, int c, int m, int n) {
        if (lipMemo[r][c] != 0) return lipMemo[r][c];
        int[][] dirs = {{1,0},{-1,0},{0,1},{0,-1}};
        int best = 1;
        for (int[] d : dirs) {
            int nr=r+d[0], nc=c+d[1];
            if (nr>=0&&nr<m&&nc>=0&&nc<n&&mat[nr][nc]>mat[r][c])
                best = Math.max(best, 1 + dfsLIP(mat, nr, nc, m, n));
        }
        return lipMemo[r][c] = best;
    }

    // GFG - BELLMAN-FORD
    /**
     * APPROACH: Relax all edges V-1 times; detect negative cycle on Vth pass
     * TIME: O(V*E)  SPACE: O(V)
     */
    static int[] bellmanFord(int V, int[][] edges, int src) {
        int[] dist = new int[V]; Arrays.fill(dist, Integer.MAX_VALUE); dist[src] = 0;
        for (int i = 0; i < V-1; i++)
            for (int[] e : edges)
                if (dist[e[0]] != Integer.MAX_VALUE && dist[e[0]] + e[2] < dist[e[1]])
                    dist[e[1]] = dist[e[0]] + e[2];
        return dist;
    }

    // GFG - FLOYD-WARSHALL (all-pairs shortest path)
    static int[][] floydWarshall(int[][] dist) {
        int V = dist.length;
        for (int k = 0; k < V; k++)
            for (int i = 0; i < V; i++)
                for (int j = 0; j < V; j++)
                    if (dist[i][k] != Integer.MAX_VALUE && dist[k][j] != Integer.MAX_VALUE)
                        dist[i][j] = Math.min(dist[i][j], dist[i][k] + dist[k][j]);
        return dist;
    }

    // LC127 - WORD LADDER (BFS shortest transformation)
    static int ladderLength(String beginWord, String endWord, List<String> wordList) {
        Set<String> wordSet = new HashSet<>(wordList);
        if (!wordSet.contains(endWord)) return 0;
        Queue<String> q = new LinkedList<>(); q.offer(beginWord);
        Set<String> visited = new HashSet<>(); visited.add(beginWord);
        int steps = 1;
        while (!q.isEmpty()) {
            steps++;
            for (int i = 0, sz = q.size(); i < sz; i++) {
                char[] word = q.poll().toCharArray();
                for (int j = 0; j < word.length; j++) {
                    char orig = word[j];
                    for (char c = 'a'; c <= 'z'; c++) {
                        word[j] = c; String next = new String(word);
                        if (next.equals(endWord)) return steps;
                        if (wordSet.contains(next) && visited.add(next)) q.offer(next);
                    }
                    word[j] = orig;
                }
            }
        }
        return 0;
    }

    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║      GRAPH PROBLEMS - ALL SOLUTIONS      ║");
        System.out.println("╚══════════════════════════════════════════╝\n");

        char[][] grid = {{'1','1','0','0','0'},{'1','1','0','0','0'},{'0','0','1','0','0'},{'0','0','0','1','1'}};
        System.out.println("LC200 numIslands                         = " + numIslands(grid));

        int[][] provinces = {{1,1,0},{1,1,0},{0,0,1}};
        System.out.println("LC547 numProvinces                       = " + findCircleNum(provinces));

        int[][] prereqs = {{1,0},{2,1},{3,2}};
        System.out.println("LC207 canFinish(4,prereqs)               = " + canFinish(4, prereqs));
        System.out.println("LC210 findOrder(4,prereqs)               = " + Arrays.toString(findOrder(4, prereqs)));

        int[][] graph = {{1,3},{0,2},{1,3},{0,2}};
        System.out.println("LC785 isBipartite                        = " + isBipartite(graph));

        int[][] redundant = {{1,2},{1,3},{2,3}};
        System.out.println("LC684 redundantConnection                = " + Arrays.toString(findRedundantConnection(redundant)));

        int[][] times = {{2,1,1},{2,3,1},{3,4,1}};
        System.out.println("LC743 networkDelayTime(n=4,k=2)          = " + networkDelayTime(times, 4, 2));

        int[][] matrix = {{9,9,4},{6,6,8},{2,1,1}};
        System.out.println("LC329 longestIncreasingPath              = " + longestIncreasingPath(matrix));

        List<String> words = Arrays.asList("hot","dot","dog","lot","log","cog");
        System.out.println("LC127 wordLadder(hit→cog)                = " + ladderLength("hit","cog",words));

        // Bellman-Ford
        int[][] bfEdges = {{0,1,4},{0,2,5},{1,2,-3},{2,3,2}};
        System.out.println("GFG   bellmanFord(src=0)                 = " + Arrays.toString(bellmanFord(4, bfEdges, 0)));
    }
}
