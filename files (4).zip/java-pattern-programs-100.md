# 100 Java Pattern Programs — Complete Solutions

> **100 Patterns · 6 Java files · 5 PNG diagrams · All logic explained**

---

## Diagram Index

| Diagram | Covers |
|---------|--------|
| `diagrams/01_star_patterns.png` | Star pattern gallery + core loop logic |
| `diagrams/02_number_patterns.png` | Number patterns + spiral/concentric logic |
| `diagrams/03_alphabet_patterns.png` | Alphabet patterns + ASCII arithmetic |
| `diagrams/04_pattern_logic.png` | Universal pattern logic flow chart |
| `diagrams/05_special_patterns.png` | Interview patterns + tips guide |

## Project Structure

```
java-pattern-programs-100/
├── pom.xml
├── diagrams/           ← 5 PNG flow diagrams
├── docs/               ← This guide
└── src/main/java/com/patterns/
    ├── star/       StarPatterns.java      (P1-20)
    ├── number/     NumberPatterns.java    (P21-40)
    ├── alphabet/   AlphabetPatterns.java  (P41-60)
    ├── matrix/     MatrixPatterns.java    (P61-75)
    ├── recursion/  RecursionPatterns.java (P76-80)
    └── special/    SpecialPatterns.java   (P81-100)
```

**Run any class:**
```bash
mvn compile
mvn exec:java -Dexec.mainClass="com.patterns.star.StarPatterns"
mvn exec:java -Dexec.mainClass="com.patterns.number.NumberPatterns"
mvn exec:java -Dexec.mainClass="com.patterns.alphabet.AlphabetPatterns"
mvn exec:java -Dexec.mainClass="com.patterns.matrix.MatrixPatterns"
mvn exec:java -Dexec.mainClass="com.patterns.recursion.RecursionPatterns"
mvn exec:java -Dexec.mainClass="com.patterns.special.SpecialPatterns"
```

---

## Universal Template — Every Pattern Uses This

```java
for (int i = 0; i < n; i++) {          // OUTER LOOP = rows
    // Step 1: print leading spaces
    for (int s = 0; s < spaces(i); s++) System.out.print(" ");

    // Step 2: print pattern characters
    for (int j = 0; j < cols(i); j++) {
        if (condition(i, j)) System.out.print(char_or_num);
        else                 System.out.print(" ");
    }

    System.out.println();               // newline after each row
}
```

## Space & Column Formulas

| Pattern | Spaces | Columns / Stars |
|---------|--------|-----------------|
| Right triangle | 0 | `i+1` |
| Left triangle | `n-i-1` | `i+1` |
| Pyramid | `n-i-1` | `2*i+1` |
| Inverted pyramid | `i` | `2*(n-i)-1` |
| Diamond top | `n-i` | `2*i-1` |
| Diamond bottom | `i-1` | `2*(n-i)+1` |
| Hollow check | — | `j==0 \|\| j==cols-1 \|\| i==0 \|\| i==n-1` |

## ASCII Arithmetic (for Alphabet patterns)

```java
(char)('A' + i)   // i=0 → 'A', i=1 → 'B', i=25 → 'Z'
(char)('A' + j)   // column-based character
// Palindrome row: ascending then descending
for (int j=0; j<=i; j++) print(char('A'+j));     // A B C ...
for (int j=i-1; j>=0; j--) print(char('A'+j));   // ... B A
```

---

# BEGINNER STAR PATTERNS (P1–P20)

---

## P1. Square Star Pattern

**Logic:** Every row has exactly `n` stars — simplest nested loop pattern.

```
* * * * *
* * * * *
* * * * *
* * * * *
* * * * *
```

```java
public static void squareStar(int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) System.out.print("* ");
        System.out.println();
    }
}
```

---

## P2. Hollow Square Pattern

**Logic:** Print `*` only on borders — first/last row or first/last column.

```
* * * * *
*       *
*       *
*       *
* * * * *
```

```java
public static void hollowSquare(int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (i==0 || i==n-1 || j==0 || j==n-1) System.out.print("* ");
            else System.out.print("  ");
        }
        System.out.println();
    }
}
```

---

## P3. Right Triangle Star Pattern

**Logic:** Row `i` prints `i+1` stars. No leading spaces.

```
*
* *
* * *
* * * *
* * * * *
```

```java
for (int i = 1; i <= n; i++) {
    for (int j = 1; j <= i; j++) System.out.print("* ");
    System.out.println();
}
```

---

## P4. Inverted Right Triangle Pattern

**Logic:** Row `i` prints `n-i` stars (decreasing from `n` to `1`).

```
* * * * *
* * * *
* * *
* *
*
```

```java
for (int i = n; i >= 1; i--) {
    for (int j = 1; j <= i; j++) System.out.print("* ");
    System.out.println();
}
```

---

## P5. Left Triangle Pattern

**Logic:** Right-aligned — `n-i-1` spaces then `i+1` stars.

```
        *
      * *
    * * *
  * * * *
* * * * *
```

```java
for (int i = 1; i <= n; i++) {
    for (int s = 0; s < n-i; s++) System.out.print("  "); // spaces
    for (int j = 1; j <= i; j++) System.out.print("* ");
    System.out.println();
}
```

---

## P6. Pyramid Star Pattern ⭐

**Logic:** `n-i-1` spaces, then `2*i+1` stars. Classic centered pyramid.

```
    *
   ***
  *****
 *******
*********
```

```java
for (int i = 0; i < n; i++) {
    for (int s = 0; s < n-i-1; s++) System.out.print(" ");
    for (int j = 0; j < 2*i+1; j++) System.out.print("*");
    System.out.println();
}
```

---

## P7. Inverted Pyramid Pattern

**Logic:** Starts wide (`2n-1` stars), narrows each row with `i` leading spaces.

```
*********
 *******
  *****
   ***
    *
```

```java
for (int i = n; i >= 1; i--) {
    for (int s = 0; s < n-i; s++) System.out.print(" ");
    for (int j = 0; j < 2*i-1; j++) System.out.print("*");
    System.out.println();
}
```

---

## P8. Diamond Star Pattern ⭐

**Logic:** Upper half = pyramid, lower half = inverted pyramid (skip middle row).

```
    *
   ***
  *****
 *******
*********
 *******
  *****
   ***
    *
```

```java
// Upper half (rows 1 to n)
for (int i = 1; i <= n; i++) {
    print(n-i spaces); print(2*i-1 stars); newline();
}
// Lower half (rows n-1 to 1)
for (int i = n-1; i >= 1; i--) {
    print(n-i spaces); print(2*i-1 stars); newline();
}
```

---

## P9. Hollow Diamond Pattern

**Logic:** Diamond, but only print border stars (first and last in each row).

```
    *
   * *
  *   *
 *     *
*       *
 *     *
  *   *
   * *
    *
```

```java
// In each row, print star at j==0 or j==width-1, else print space
if (j==0 || j==stars-1) System.out.print("*");
else                      System.out.print(" ");
```

---

## P10. Hourglass Pattern

**Logic:** Wide-to-narrow (inverted pyramid) then narrow-to-wide (pyramid). Like two triangles meeting at tip.

```
*********
 *******
  *****
   ***
    *
   ***
  *****
 *******
*********
```

---

## P11. Butterfly Pattern ⭐

**Logic:** Print `i` stars, gap of `2*(n-i)` spaces, then `i` stars again on each side.

```
*         *
* *     * *
* * * * * *
* *     * *
*         *
```

```java
for (int i = 1; i <= n; i++) {
    print(i stars);            // left wing
    print(2*(n-i) spaces);    // middle gap
    print(i stars);            // right wing
    newline();
}
// Mirror for lower half
```

---

## P12. Sandglass Pattern

**Logic:** Inverted triangle (n down to 1) then triangle (1 up to n). Each row starts with `n-i` spaces.

---

## P13. X Pattern

**Logic:** Star at position `(i,j)` if `i==j` (main diagonal) or `i+j==n-1` (anti-diagonal).

```
*       *
  *   *
    *
  *   *
*       *
```

```java
if (i==j || i+j==n-1) System.out.print("* ");
else                    System.out.print("  ");
```

---

## P14. Plus (+) Pattern

**Logic:** Star if `i==mid` (middle row) or `j==mid` (middle column). Mid = `n/2`.

```
    *
    *
* * * * *
    *
    *
```

```java
int mid = n / 2;
if (i==mid || j==mid) System.out.print("* ");
```

---

## P15. Hollow Pyramid Pattern

**Logic:** Pyramid shape, but stars only at `j==0`, `j==width-1`, or last row (`i==n-1`).

```
    *
   * *
  *   *
 *     *
*********
```

```java
if (j==0 || j==width-1 || i==n-1) System.out.print("*");
else                                 System.out.print(" ");
```

---

## P16. Hollow Inverted Pyramid

**Logic:** Inverted pyramid shape with hollow interior — border only.

---

## P17. Right Pascal Triangle

**Logic:** First half = triangle (1 to n stars), second half = inverted triangle (n-1 to 1).

```
*
* *
* * *
* * * *
* * * * *
* * * *
* * *
* *
*
```

---

## P18. Left Pascal Triangle

**Logic:** Same as P17 but right-aligned using leading spaces.

---

## P19. Zig-Zag Pattern

**Logic:** Three-row repeating pattern. Stars at calculated column positions based on row and column modulo.

```
*   *   *   *
 * * * * * *
  *   *   *
```

---

## P20. Cross Pattern

**Logic:** Combines X (diagonals) and Plus (middle row/column). Star at any of the four conditions.

```java
if (i==j || i+j==n-1 || i==mid || j==mid) System.out.print("*");
```

---

# NUMBER PATTERNS (P21–P40)

---

## P21. Number Triangle Pattern

**Logic:** Row `i` prints the number `i` exactly `i` times.

```
1
2 2
3 3 3
4 4 4 4
5 5 5 5 5
```

```java
for (int i = 1; i <= n; i++) {
    for (int j = 1; j <= i; j++) System.out.print(i + " ");
    System.out.println();
}
```

---

## P22. Floyd's Triangle ⭐

**Logic:** Sequential numbers `1, 2, 3, ...` filling rows of increasing size.

```
1
2 3
4 5 6
7 8 9 10
```

```java
int num = 1;
for (int i = 1; i <= n; i++) {
    for (int j = 1; j <= i; j++) System.out.print(num++ + " ");
    System.out.println();
}
```

---

## P23. Pascal's Triangle ⭐⭐

**Logic:** Each element = C(row, col) = row! / (col! × (row-col)!). Compute iteratively.

```
         1
        1 1
       1 2 1
      1 3 3 1
     1 4 6 4 1
```

```java
for (int i = 0; i < n; i++) {
    long val = 1;
    for (int j = 0; j <= i; j++) {
        System.out.printf("%-4d", val);
        val = val * (i - j) / (j + 1);  // compute next without factorial overflow
    }
    System.out.println();
}
```

---

## P24. Reverse Number Triangle

**Logic:** Row `i` prints number `n-i+1` repeated `n-i+1` times (decreasing).

```
5 5 5 5 5
4 4 4 4
3 3 3
2 2
1
```

---

## P25. Pyramid Number Pattern

**Logic:** Centered — left side ascending `1 2 3...i`, right side descending `i-1...2 1`.

```
        1
      1 2 1
    1 2 3 2 1
  1 2 3 4 3 2 1
1 2 3 4 5 4 3 2 1
```

```java
for (int i = 1; i <= n; i++) {
    // print spaces
    for (int j = 1; j <= i; j++) System.out.print(j + " ");      // 1 2 ... i
    for (int j = i-1; j >= 1; j--) System.out.print(j + " ");    // i-1 ... 1
    System.out.println();
}
```

---

## P26. Palindrome Number Pyramid

**Logic:** Each row is itself a palindrome: `12321`, `1234321`, etc.

```
    1
   121
  12321
 1234321
123454321
```

---

## P27. Diamond Number Pattern

**Logic:** Upper half: each row prints `1 2 3...2i-1`. Lower half mirrors.

---

## P28. Hollow Number Pyramid

**Logic:** Pyramid shape, but numbers only at border positions.

---

## P29. Incremental Number Pattern

**Logic:** Row `i` prints `1 2 3 ... i` (increasing columns each row).

```
1
1 2
1 2 3
1 2 3 4
```

---

## P30. Decremental Number Pattern

**Logic:** Row `i` prints `n n-1 ... 1` (all n elements, then n-1, etc.).

---

## P31. Binary Number Triangle

**Logic:** Alternating 0 and 1, starting value flips each row.

```
1
0 1
1 0 1
0 1 0 1
1 0 1 0 1
```

```java
int val = (i % 2 == 0) ? 1 : 0;
for (int j = 1; j <= i; j++) {
    System.out.print(val + " ");
    val = 1 - val; // toggle
}
```

---

## P32. Continuous Number Pattern

**Logic:** Numbers continue sequentially across ALL rows (n×n matrix with sequential fill).

---

## P33. Snake Number Pattern ⭐

**Logic:** Even rows filled left-to-right, odd rows filled right-to-left.

```
1   2   3   4   5
10  9   8   7   6
11  12  13  14  15
20  19  18  17  16
```

---

## P34. Spiral Number Matrix ⭐⭐

**Logic:** Fill matrix layer by layer: Top→Right→Bottom→Left. Shrink boundaries after each direction.

```
1  2  3  4  5
16 17 18 19 6
15 24 25 20 7
14 23 22 21 8
13 12 11 10 9
```

```java
int top=0, bottom=n-1, left=0, right=n-1, num=1;
while (top<=bottom && left<=right) {
    for(int i=left; i<=right; i++)  matrix[top][i]=num++;   top++;    // →
    for(int i=top;  i<=bottom; i++) matrix[i][right]=num++; right--;  // ↓
    if(top<=bottom) for(int i=right; i>=left; i--) matrix[bottom][i]=num++; bottom--;  // ←
    if(left<=right) for(int i=bottom; i>=top; i--) matrix[i][left]=num++;  left++;     // ↑
}
```

---

## P35. Concentric Number Square ⭐

**Logic:** Element value = distance from nearest border + 1. Formula: `min(i, j, n-1-i, n-1-j) + 1`.

```
1 1 1 1 1
1 2 2 2 1
1 2 3 2 1
1 2 2 2 1
1 1 1 1 1
```

```java
int val = Math.min(Math.min(i, j), Math.min(n-1-i, n-1-j)) + 1;
```

---

## P36. Alternate 0-1 Triangle

**Logic:** Element at row `i`, column `j` = `(i+j) % 2`.

---

## P37. Centered Number Pyramid

**Logic:** Each row in a pyramid has numbers arranged symmetrically around a center value.

---

## P38. Reverse Floyd's Triangle

**Logic:** Like Floyd's but largest numbers are in the top row.

---

## P39. Number Hourglass Pattern

**Logic:** Inverted pyramid of numbers (decreasing), then pyramid of numbers (increasing).

---

## P40. Number Butterfly Pattern

**Logic:** Left wing has `1 2...i`, right wing mirrors `i...2 1`, with middle gap.

---

# ALPHABET PATTERNS (P41–P60)

---

## P41. Alphabet Triangle Pattern

**Logic:** Row `i` prints letters A to (A+i). Use `(char)('A' + j)`.

```
A
A B
A B C
A B C D
A B C D E
```

```java
for (int i = 0; i < n; i++) {
    for (int j = 0; j <= i; j++) System.out.print((char)('A'+j) + " ");
    System.out.println();
}
```

---

## P42. Reverse Alphabet Triangle

**Logic:** Row `i` starts from the (n-1)th letter and prints down to the (n-i-1)th letter.

```
A B C D E
B C D E
C D E
D E
E
```

---

## P43. Alphabet Pyramid ⭐

**Logic:** Centered pyramid, each row fills with the same letter (A for row 0, B for row 1...).

```
    A
   BBB
  CCCCC
 DDDDDDD
EEEEEEEEE
```

```java
for (int i = 0; i < n; i++) {
    print(n-i-1 spaces);
    for (int j = 0; j < 2*i+1; j++) System.out.print((char)('A'+i));
    newline();
}
```

---

## P44. Alphabet Diamond Pattern

**Logic:** Each row: ascending A-B-C...up to row letter, then descending back to A.

```
    A
   ABA
  ABCBA
 ABCDCBA
ABCDEDCBA
 ABCDCBA
  ABCBA
   ABA
    A
```

---

## P45. Hollow Alphabet Pyramid

**Logic:** Pyramid shape, but print the row-letter only at border positions.

---

## P46. Continuous Alphabet Pattern

**Logic:** Characters continue sequentially across rows, wrapping after Z.

```
A
B C
D E F
G H I J
```

---

## P47. Character Butterfly Pattern

**Logic:** Left and right wings with letters A-B-C-...-i and mirror.

---

## P48. Palindrome Alphabet Pyramid ⭐

**Logic:** Each row is a palindrome of characters: `ABCBA`, `ABCDCBA`, etc.

```
    A
   ABA
  ABCBA
 ABCDCBA
ABCDEDCBA
```

```java
for (int i = 0; i < n; i++) {
    print(n-i-1 spaces);
    for (int j = 0; j <= i; j++) System.out.print((char)('A'+j));   // ascending
    for (int j = i-1; j >= 0; j--) System.out.print((char)('A'+j)); // descending
    newline();
}
```

---

## P49. Zig-Zag Alphabet Pattern

**Logic:** Three-row zig-zag using character A, B, C in respective rows.

---

## P50. Alternate Alphabet Triangle

**Logic:** Alternates between 'A' and 'B' in each position.

---

## P51. Alphabet Hourglass

**Logic:** Wide-to-narrow using A-B-C-... then narrow-to-wide.

---

## P52. Reverse Character Pyramid

**Logic:** Row `i` prints letters from the end of the alphabet down to row `i`'s position.

---

## P53. Incremental Alphabet Pyramid

**Logic:** Each row adds one more letter; row 1: A, row 2: A B, etc.

---

## P54. Decremental Alphabet Pyramid

**Logic:** Opposite of P53 — starts with maximum letters, decreases each row.

---

## P55. Alphabet Box Pattern

**Logic:** Border of the box uses sequential letters; inner cells are spaces.

```
A B C D E
A       E
A       E
A       E
A B C D E
```

---

## P56. Character X Pattern

**Logic:** Letter at position `(i,j)` is the row-letter, printed only on diagonals.

---

## P57. Character Cross Pattern

**Logic:** Middle row and middle column, each position uses the row's letter.

---

## P58. Alphabet Spiral Pattern

**Logic:** Fill n×n matrix spirally with letters A, B, C... (wrapping at Z).

---

## P59. Hollow Alphabet Diamond

**Logic:** Diamond outline only — letter at first and last position of each row.

---

## P60. ABCD Square Pattern

**Logic:** Sequential letters filling entire n×n grid left-to-right, top-to-bottom.

---

# MATRIX PATTERNS (P61–P75)

---

## P61. Spiral Matrix Pattern ⭐⭐

**Logic:** Boundary-shrinking approach. Fill Top→Right→Bottom→Left, repeat inward.

```
1  2  3  4
12 13 14 5
11 16 15 6
10 9  8  7
```

See also P34 for the exact code.

---

## P62. Wave Matrix Pattern

**Logic:** Even columns filled top-to-bottom, odd columns filled bottom-to-top — creates a wave.

```
1   12  13  24  25
2   11  14  23  26
3   10  15  22  27
4   9   16  21  28
5   8   17  20  29
6   7   18  19  30
```

---

## P63. Zig-Zag Matrix

**Logic:** Diagonal traversal — alternate between going top-left and bottom-right.

---

## P64. Border Matrix Pattern

**Logic:** Border cells have sequential numbers; inner cells are 0.

---

## P65. Checkerboard Pattern

**Logic:** `(i+j) % 2` gives alternating 0/1 like a chess board.

```
0 1 0 1 0
1 0 1 0 1
0 1 0 1 0
1 0 1 0 1
0 1 0 1 0
```

---

## P66. Diagonal Matrix Pattern

**Logic:** Number `i+1` on main diagonal, 0 elsewhere.

---

## P67. Anti-Diagonal Matrix Pattern

**Logic:** Numbers on anti-diagonal (`i + j == n-1`), 0 elsewhere.

---

## P68. Snake Matrix Pattern ⭐

**Logic:** Even rows left-to-right, odd rows right-to-left for sequential number fill.

```java
if (i%2==0) { for(int j=0;j<n;j++) matrix[i][j]=num++; }
else          { for(int j=n-1;j>=0;j--) matrix[i][j]=num++; }
```

---

## P69. Spiral Character Matrix

**Logic:** Same as spiral matrix but fills with A, B, C... characters.

---

## P70. Spiral Number Box

**Logic:** Concentric layers numbered outward-in. Uses `min(i, j, n-1-i, n-1-j) + 1`.

---

## P71. Matrix Pyramid Pattern

**Logic:** Print a pyramid inside a matrix grid, where element value = distance from center of that row.

---

## P72. Hollow Matrix Box

**Logic:** Print `*` only on the border of the n×n grid.

---

## P73. Matrix Diamond Pattern

**Logic:** Number at each position reflects distance from center of the diamond shape.

---

## P74. Alternate Matrix Pattern

**Logic:** Row 0: all 0s, Row 1: all 1s, Row 2: all 0s... alternating.

---

## P75. Concentric Rectangle Pattern

**Logic:** Like P70 but uses letters: outermost layer = A, next = B, etc.

```java
char c = (char)('A' + Math.min(Math.min(i,j), Math.min(n-1-i, n-1-j)));
```

---

# RECURSION-BASED PATTERNS (P76–P80)

---

## P76. Recursive Triangle Pattern

**Logic:** Base case: `n==0` return. Recursive case: print smaller triangle, then current row.

```java
public static void recursiveTriangle(int n) {
    if (n == 0) return;
    recursiveTriangle(n - 1);         // print n-1 rows first (stack)
    for (int j = 0; j < n; j++) System.out.print("* ");
    System.out.println();
}
// Call: recursiveTriangle(5)
// Stack unwinds: prints row 1, then 2, then 3, then 4, then 5
```

---

## P77. Recursive Pyramid Pattern

**Logic:** `current` goes from 1 to n. Print spaces then stars, then recurse.

```java
public static void recursivePyramid(int n, int current) {
    if (current > n) return;
    // print n-current spaces, then 2*current-1 stars
    recursivePyramid(n, current + 1);
}
```

---

## P78. Recursive Diamond Pattern

**Logic:** Single recursive function handles both upper and lower halves using the call stack's wind/unwind.

```java
private static void recursiveDiamondUpper(int n, int current) {
    // print current row (upper half)
    if (current < n) recursiveDiamondUpper(n, current + 1);
    // On unwind: print current row again (lower half mirror)
}
```

---

## P79. Recursive Number Pattern

**Logic:** Palindrome structure — print row, recurse deeper, print row again on unwind.

```java
void recursiveNumber(int n, int current) {
    if (current > n) return;
    printRow(current);       // before recursion
    recursiveNumber(n, current + 1);
    printRow(current);       // after recursion (mirror)
}
```

Output: `1 / 1 2 / 1 2 3 / 1 2 / 1` — symmetric around center.

---

## P80. Recursive Alphabet Pattern

**Logic:** Each recursive call adds one more letter to the row.

```java
void recursiveAlphabet(int n, int current) {
    if (current > n) return;
    for (int j=0; j<current; j++) System.out.print((char)('A'+j) + " ");
    System.out.println();
    recursiveAlphabet(n, current + 1);
}
```

---

# SPECIAL INTERVIEW PATTERNS (P81–P100)

---

## P81. Hollow Butterfly Pattern

**Logic:** Butterfly shape but only border stars on each wing (first and last position).

---

## P82. Rhombus Pattern ⭐

**Logic:** Parallelogram — each row shifts right by one extra space (decreasing leading spaces).

```
    * * * * *
   * * * * *
  * * * * *
 * * * * *
* * * * *
```

```java
for (int i = 0; i < n; i++) {
    print(n-i-1 spaces);
    print(n stars);
    newline();
}
```

---

## P83. Hollow Rhombus Pattern

**Logic:** Rhombus shape with only border stars.

---

## P84. Mirrored Right Triangle

**Logic:** Right-aligned triangle — uses leading spaces, then `i` stars.

---

## P85. Double Pyramid Pattern

**Logic:** Two pyramid silhouettes side by side (one solid star group, gap, another star group).

---

## P86. Hollow Hourglass Pattern

**Logic:** Hourglass shape with only border stars.

---

## P87. Binary Pyramid Pattern ⭐

**Logic:** Pyramid shape, each position filled with alternating 0/1, starting value alternates per row.

```
    1
   010
  10101
 0101010
101010101
```

```java
int val = (i%2==0) ? 1 : 0;
for (int j = 0; j < 2*i+1; j++) {
    System.out.print(val);
    val = 1 - val;
}
```

---

## P88. Hollow Pascal Triangle

**Logic:** Pascal's triangle but print `0` (or spaces) for non-border elements inside each row.

---

## P89. Swastika Pattern ⭐

**Logic:** Middle row, middle column, plus top-left/top-right/bottom-left/bottom-right border segments.

```java
boolean isMid = (i==mid || j==mid);
boolean topLeft  = (i < mid && j < mid && i==0);
boolean topRight = (i < mid && j > mid && j==n-1);
// etc.
if (isMid||topLeft||topRight||botLeft||botRight) print("*");
```

---

## P90. Heart Pattern ⭐

**Logic:** Top: two bumps (V-shape inverted) using expanding rows. Bottom: inverted pyramid converging to point.

---

## P91. Christmas Tree Pattern ⭐

**Logic:** Multiple layers of pyramids, each starting from row 1 up to layer count. Trunk at bottom (|||).

```java
for (int layer = 1; layer <= n; layer++) {
    for (int i = 1; i <= layer; i++) {
        print(n-i spaces); print(2*i-1 stars); newline();
    }
}
print trunk (|||);
```

---

## P92. Arrow Pattern

**Logic:** Expanding triangle (rows 1 to n) then contracting triangle (rows n-1 to 1). Like an arrow pointing right.

---

## P93. Kite Pattern

**Logic:** Pyramid on top + vertical line (trunk) below.

---

## P94. Crown Pattern

**Logic:** Three spikes at the top, then a solid base line.

---

## P95. Fish Pattern

**Logic:** Rows where left side increases and right side decreases — creates a fish silhouette.

---

## P96. Circle Pattern ⭐

**Logic:** Use distance formula. If `sqrt(i² + j²) <= r` → print star, else space. Center is origin.

```java
for (int i = -r; i <= r; i++) {
    for (int j = -r; j <= r; j++) {
        double dist = Math.sqrt(i*i + j*j);
        System.out.print(dist <= r ? "* " : "  ");
    }
    System.out.println();
}
```

---

## P97. Hollow Circle Pattern

**Logic:** Same as P96 but print star only when `r-0.5 <= dist <= r+0.5` (on the ring, not filled).

```java
System.out.print(dist >= r-0.5 && dist <= r+0.5 ? "* " : "  ");
```

---

## P98. Staircase Pattern

**Logic:** Right-aligned staircase — each row wider and bottom-aligned.

```
        *
      * *
    * * *
  * * * *
* * * * *
```

---

## P99. S Shape Pattern

**Logic:** Draw the letter S using border conditions for top, middle, and bottom rows + left-right sides.

```java
boolean top    = (i==0);
boolean mid    = (i==n/2);
boolean bot    = (i==n-1);
boolean left   = (j==0 && i>n/2);
boolean right  = (j==n-1 && i<n/2);
if (top||mid||bot||left||right) print("*");
```

---

## P100. Custom User Input Pattern ⭐

**Logic:** Accept any character `c` and size `n`, generate diamond/pyramid with that character.

```java
public static void customPattern(int n, char c) {
    // Upper half
    for (int i = 1; i <= n; i++) {
        print(n-i spaces);
        for (int j = 0; j < 2*i-1; j++) System.out.print(c);
        newline();
    }
    // Lower half
    for (int i = n-1; i >= 1; i--) {
        print(n-i spaces);
        for (int j = 0; j < 2*i-1; j++) System.out.print(c);
        newline();
    }
}
// customPattern(5, '@') prints a diamond of '@' characters
```

---

# Common Interview Questions on Patterns

**Q: How do you determine the number of spaces in each row?**
For a pyramid of size n, row i (0-indexed) has `n - i - 1` leading spaces.

**Q: How to print a pattern without knowing the formula?**
Draw it on paper for n=4. Count spaces and stars per row. Find the pattern mathematically.

**Q: Time and Space complexity of all patterns?**
All patterns: Time **O(n²)** (two nested loops), Space **O(1)** (printing in-place) except matrix patterns which use **O(n²)** space.

**Q: How to reverse a triangle recursively?**
`recursiveTriangle(n-1)` first, then print row n. The recursion stack naturally reverses the order.

**Q: What is the formula for Pascal's Triangle without storing the full array?**
`C(row, col) = C(row, col-1) * (row - col + 1) / col`. Compute iteratively within each row.

---

# Quick Reference Formula Table

| Pattern | Row i Spaces | Row i Elements | Element Value |
|---------|-------------|----------------|---------------|
| Right Triangle | 0 | `i+1` | `*` |
| Left Triangle | `n-i-1` | `i+1` | `*` |
| Pyramid | `n-i-1` | `2*i+1` | `*` |
| Inv. Pyramid | `i` | `2*(n-i)-1` | `*` |
| Diamond Top | `n-i` | `2*i-1` | `*` |
| Diamond Bot | `i-1` | `2*(n-i)+1` | `*` |
| Floyd's | 0 | `i` | sequential num |
| Pascal's | `n-i-1` | `i+1` | `C(i,j)` |
| Alphabet Tri | 0 | `i+1` | `'A'+j` |
| Alpha Pyramid | `n-i-1` | `2*i+1` | `'A'+i` |
| Rhombus | `n-i-1` | `n` | `*` |
| Concentric | — | n×n | `min(i,j,n-1-i,n-1-j)+1` |
| Spiral | — | n×n | boundary fill |
| Circle | — | 2r+1 sq | `sqrt(i²+j²)<=r` |

---

*100 Java Pattern Programs — Complete Solutions with Logic*
