package com.corejava.collections;

import java.util.*;
import java.util.stream.*;

/**
 * TOPIC: Collections Framework — ArrayList, LinkedList, HashMap, TreeMap,
 *        HashSet, TreeSet, PriorityQueue, Comparable, Comparator
 */
public class CollectionsDemo {

    record Student(String name, int grade, double gpa)
            implements Comparable<Student> {
        // Natural ordering by name
        @Override
        public int compareTo(Student other) {
            return this.name.compareTo(other.name);
        }
        @Override
        public String toString() {
            return String.format("Student(%s, grade=%d, gpa=%.1f)", name, grade, gpa);
        }
    }

    public static void main(String[] args) {
        // ── ArrayList ─────────────────────────────────────────────────────
        System.out.println("=== ArrayList (Dynamic array, O(1) get) ===");
        List<Student> students = new ArrayList<>();
        students.add(new Student("Alice", 10, 3.9));
        students.add(new Student("Bob",   11, 3.5));
        students.add(new Student("Carol", 10, 3.7));
        students.add(new Student("Dave",  12, 3.2));
        students.add(0, new Student("Eve", 9, 3.8)); // insert at index

        System.out.println("All: " + students);
        System.out.println("Get(1): " + students.get(1));
        students.removeIf(s -> s.grade() < 10);
        System.out.println("After removing grade<10: " + students);

        // Sort by GPA descending
        students.sort(Comparator.comparingDouble(Student::gpa).reversed());
        System.out.println("Sorted by GPA desc: " + students);

        // Sort with multiple keys
        students.sort(Comparator.comparingInt(Student::grade)
                .thenComparingDouble(Student::gpa).reversed());
        System.out.println("Grade then GPA: " + students);

        // ── HashMap ───────────────────────────────────────────────────────
        System.out.println("\n=== HashMap (O(1) get/put, no order) ===");
        Map<String, Integer> wordCount = new HashMap<>();
        String[] words = {"apple","banana","apple","cherry","banana","apple"};
        for (String w : words) wordCount.merge(w, 1, Integer::sum);
        System.out.println("Word counts: " + wordCount);

        // getOrDefault, putIfAbsent, computeIfAbsent
        System.out.println("date count: " + wordCount.getOrDefault("date", 0));
        wordCount.putIfAbsent("elderberry", 1);
        wordCount.computeIfAbsent("fig", k -> k.length());
        System.out.println("After additions: " + wordCount);

        // Iterate entries
        wordCount.entrySet().stream()
            .sorted(Map.Entry.<String,Integer>comparingByValue().reversed())
            .limit(3)
            .forEach(e -> System.out.println("  " + e.getKey() + ": " + e.getValue()));

        // ── TreeMap ───────────────────────────────────────────────────────
        System.out.println("\n=== TreeMap (Sorted by key, O(log n)) ===");
        TreeMap<String, Integer> sorted = new TreeMap<>(wordCount);
        System.out.println("First key: " + sorted.firstKey());
        System.out.println("Last key:  " + sorted.lastKey());
        System.out.println("Floor 'c': " + sorted.floorKey("c")); // <= 'c'
        System.out.println("Ceiling 'b': " + sorted.ceilingKey("b")); // >= 'b'

        // ── LinkedHashMap — insertion order ───────────────────────────────
        System.out.println("\n=== LinkedHashMap (Insertion order) ===");
        Map<String, String> capitals = new LinkedHashMap<>();
        capitals.put("India", "New Delhi");
        capitals.put("USA",   "Washington DC");
        capitals.put("Japan", "Tokyo");
        capitals.put("UK",    "London");
        System.out.println("Capitals: " + capitals);

        // LRU Cache using LinkedHashMap
        Map<Integer, String> lruCache = new LinkedHashMap<>(16, 0.75f, true) {
            @Override protected boolean removeEldestEntry(Map.Entry<Integer,String> eldest) {
                return size() > 3; // max 3 entries
            }
        };
        lruCache.put(1,"A"); lruCache.put(2,"B"); lruCache.put(3,"C");
        lruCache.get(1);     // access 1 — moves to end
        lruCache.put(4,"D"); // evicts LRU (key=2)
        System.out.println("LRU Cache (max 3): " + lruCache);

        // ── HashSet / TreeSet ─────────────────────────────────────────────
        System.out.println("\n=== HashSet (no duplicates, no order) ===");
        Set<String> fruits = new HashSet<>(Arrays.asList("apple","banana","apple","cherry","banana"));
        System.out.println("Unique fruits: " + fruits);

        Set<Integer> a = new HashSet<>(Set.of(1,2,3,4,5));
        Set<Integer> b = new HashSet<>(Set.of(3,4,5,6,7));
        Set<Integer> intersection = new HashSet<>(a); intersection.retainAll(b);
        Set<Integer> union = new HashSet<>(a); union.addAll(b);
        System.out.println("A: " + a + "  B: " + b);
        System.out.println("Intersection: " + intersection);
        System.out.println("Union: " + new TreeSet<>(union)); // sorted for display

        // ── PriorityQueue ─────────────────────────────────────────────────
        System.out.println("\n=== PriorityQueue (Min-heap by default) ===");
        PriorityQueue<Integer> minHeap = new PriorityQueue<>();
        minHeap.addAll(Arrays.asList(5,1,8,2,9,3));
        System.out.print("Min-heap poll order: ");
        while (!minHeap.isEmpty()) System.out.print(minHeap.poll() + " ");
        System.out.println();

        PriorityQueue<Student> topStudents = new PriorityQueue<>(
            Comparator.comparingDouble(Student::gpa).reversed());
        topStudents.addAll(List.of(
            new Student("Alice",10,3.9), new Student("Bob",11,2.5),
            new Student("Carol",10,3.7), new Student("Dave",12,3.2)));
        System.out.println("Top student: " + topStudents.poll());

        // ── Collections utility methods ───────────────────────────────────
        System.out.println("\n=== Collections Utility Methods ===");
        List<Integer> nums = new ArrayList<>(Arrays.asList(3,1,4,1,5,9,2,6));
        System.out.println("Max: " + Collections.max(nums));
        System.out.println("Min: " + Collections.min(nums));
        System.out.println("Frequency of 1: " + Collections.frequency(nums, 1));
        Collections.sort(nums);
        System.out.println("Sorted: " + nums);
        Collections.reverse(nums);
        System.out.println("Reversed: " + nums);
        Collections.shuffle(nums, new Random(42));
        System.out.println("Shuffled: " + nums);
        System.out.println("Unmodifiable list attempt:");
        List<Integer> unmod = Collections.unmodifiableList(nums);
        try { unmod.add(99); } catch (UnsupportedOperationException e) {
            System.out.println("  Cannot modify! " + e.getClass().getSimpleName());
        }
    }
}