package com.corejava.java8;

import java.util.*;
import java.util.function.*;
import java.util.stream.*;
import java.time.*;
import java.time.format.*;

/**
 * TOPIC: Java 8+ Features — Lambdas, Streams, Optional, Method References,
 *        Default methods, Date/Time API
 */
public class Java8Features {

    // ── Functional Interface ──────────────────────────────────────────────
    @FunctionalInterface
    interface MathOperation {
        int operate(int a, int b);
        // only ONE abstract method allowed
        default String describe() { return "Math operation"; }
    }

    record Product(String name, String category, double price, int stock) {}

    public static void main(String[] args) {
        System.out.println("=== Lambda Expressions ===");
        // Lambda = anonymous function
        MathOperation add = (a, b) -> a + b;
        MathOperation mul = (a, b) -> a * b;
        MathOperation pow = (a, b) -> (int) Math.pow(a, b);

        System.out.println("add(5,3):  " + add.operate(5, 3));
        System.out.println("mul(5,3):  " + mul.operate(5, 3));
        System.out.println("pow(2,10): " + pow.operate(2, 10));

        System.out.println("\n=== Built-in Functional Interfaces ===");
        Predicate<String>     isLong   = s -> s.length() > 5;
        Function<String,Integer> length = String::length;
        Consumer<String>      printer  = s -> System.out.println("  >> " + s);
        Supplier<List<String>> listSup = ArrayList::new;
        BiFunction<Integer,Integer,Integer> max = Math::max;

        System.out.println("isLong("Hello"):   " + isLong.test("Hello"));
        System.out.println("isLong("LongWord"): " + isLong.test("LongWord"));
        System.out.println("length("Java"):    " + length.apply("Java"));
        printer.accept("Consumer prints this");
        System.out.println("Supplier new list: " + listSup.get().getClass().getSimpleName());
        System.out.println("BiFunction max(3,7): " + max.apply(3, 7));

        // Predicate composition
        Predicate<String> startsA = s -> s.startsWith("A");
        Predicate<String> isLongAndStartsA = isLong.and(startsA);
        Predicate<String> isLongOrStartsA  = isLong.or(startsA);
        System.out.println(""Algorithm" - long AND starts A: " + isLongAndStartsA.test("Algorithm"));

        System.out.println("\n=== Stream API ===");
        List<Product> products = List.of(
            new Product("Laptop",   "Electronics", 999.99, 50),
            new Product("Phone",    "Electronics", 699.99, 200),
            new Product("Shirt",    "Clothing",    29.99,  500),
            new Product("Jeans",    "Clothing",    59.99,  300),
            new Product("Headset",  "Electronics", 149.99, 100),
            new Product("Jacket",   "Clothing",    89.99,  150),
            new Product("Tablet",   "Electronics", 399.99, 75),
            new Product("Camera",   "Electronics", 799.99, 30)
        );

        // filter + map + collect
        List<String> expensiveElectronics = products.stream()
            .filter(p -> p.category().equals("Electronics"))
            .filter(p -> p.price() > 500)
            .map(Product::name)
            .sorted()
            .collect(Collectors.toList());
        System.out.println("Expensive Electronics: " + expensiveElectronics);

        // reduce
        double totalValue = products.stream()
            .mapToDouble(p -> p.price() * p.stock())
            .sum();
        System.out.printf("Total inventory value: $%,.2f%n", totalValue);

        // groupingBy
        Map<String, List<Product>> byCategory = products.stream()
            .collect(Collectors.groupingBy(Product::category));
        byCategory.forEach((cat, prods) ->
            System.out.printf("  %s: %d products%n", cat, prods.size()));

        // statistics
        DoubleSummaryStatistics stats = products.stream()
            .mapToDouble(Product::price)
            .summaryStatistics();
        System.out.printf("Price — min=%.2f max=%.2f avg=%.2f%n",
            stats.getMin(), stats.getMax(), stats.getAverage());

        // flatMap
        List<List<Integer>> nested = List.of(List.of(1,2,3), List.of(4,5), List.of(6,7,8,9));
        List<Integer> flat = nested.stream().flatMap(Collection::stream).collect(Collectors.toList());
        System.out.println("flatMap: " + flat);

        // toMap
        Map<String,Double> priceMap = products.stream()
            .collect(Collectors.toMap(Product::name, Product::price));
        System.out.println("Laptop price: " + priceMap.get("Laptop"));

        System.out.println("\n=== Optional ===");
        Optional<Product> cheapest = products.stream()
            .min(Comparator.comparingDouble(Product::price));
        cheapest.ifPresent(p -> System.out.println("Cheapest: " + p.name() + " $" + p.price()));

        Optional<String> name = Optional.of("Java")
            .filter(s -> s.length() > 3)
            .map(String::toUpperCase);
        System.out.println("Optional result: " + name.orElse("not found"));

        Optional<String> empty = Optional.empty();
        System.out.println("Empty orElse: " + empty.orElse("default"));
        System.out.println("Empty orElseGet: " + empty.orElseGet(() -> "computed"));

        System.out.println("\n=== Method References ===");
        // ClassName::staticMethod
        List<String> words = Arrays.asList("banana","apple","cherry","date");
        words.stream().map(String::toUpperCase).forEach(System.out::println);

        // ClassName::instanceMethod
        words.sort(String::compareToIgnoreCase);
        System.out.println("Sorted: " + words);

        // ClassName::new (constructor reference)
        Supplier<ArrayList<String>> listFactory = ArrayList::new;
        ArrayList<String> newList = listFactory.get();

        System.out.println("\n=== Date & Time API (Java 8+) ===");
        LocalDate today     = LocalDate.now();
        LocalTime now       = LocalTime.now();
        LocalDateTime dt    = LocalDateTime.now();
        ZonedDateTime zoned = ZonedDateTime.now(ZoneId.of("Asia/Kolkata"));

        System.out.println("Today:  " + today);
        System.out.println("Time:   " + now.format(DateTimeFormatter.ofPattern("HH:mm:ss")));
        System.out.println("IST:    " + zoned.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm z")));

        LocalDate birthday = LocalDate.of(1995, Month.MARCH, 15);
        Period age = Period.between(birthday, today);
        System.out.printf("Age: %d years, %d months, %d days%n",
            age.getYears(), age.getMonths(), age.getDays());

        Duration duration = Duration.between(
            LocalDateTime.of(2024,1,1,0,0), LocalDateTime.now());
        System.out.printf("Days since 2024-01-01: %d%n", duration.toDays());
    }
}