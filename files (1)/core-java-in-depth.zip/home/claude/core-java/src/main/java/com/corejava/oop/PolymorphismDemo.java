package com.corejava.oop;

/**
 * TOPIC: Polymorphism
 *  - Compile-time (method overloading — resolved at compile time)
 *  - Runtime      (method overriding — resolved via virtual dispatch table)
 *
 * KEY: same method name, different behaviour
 */
public class PolymorphismDemo {

    // ── Compile-time: Method Overloading ─────────────────────────────────
    static class Calculator {
        // Same name, different signatures
        int    add(int a, int b)          { return a + b; }
        double add(double a, double b)    { return a + b; }
        int    add(int a, int b, int c)   { return a + b + c; }
        String add(String a, String b)    { return a + b; }

        // NOTE: cannot overload by return type alone!
        // Overloading resolved at COMPILE TIME based on parameter types
    }

    // ── Runtime: Method Overriding ────────────────────────────────────────
    static class Shape {
        public double area()      { return 0; }
        public String describe()  { return "I am a " + getClass().getSimpleName(); }
    }

    static class Circle extends Shape {
        double radius;
        Circle(double r) { this.radius = r; }

        @Override
        public double area() { return Math.PI * radius * radius; }
    }

    static class Rectangle extends Shape {
        double width, height;
        Rectangle(double w, double h) { this.width=w; this.height=h; }

        @Override
        public double area() { return width * height; }
    }

    static class Triangle extends Shape {
        double base, height;
        Triangle(double b, double h) { this.base=b; this.height=h; }

        @Override
        public double area() { return 0.5 * base * height; }
    }

    // ── Runtime dispatch demo ─────────────────────────────────────────────
    static void printArea(Shape s) {
        // JVM calls the ACTUAL object's area(), not Shape's
        // Determined at runtime via vtable (virtual method table)
        System.out.printf("%s area = %.2f%n", s.getClass().getSimpleName(), s.area());
    }

    public static void main(String[] args) {
        System.out.println("=== Compile-time Polymorphism (Overloading) ===");
        Calculator calc = new Calculator();
        System.out.println("add(2,3):          " + calc.add(2, 3));
        System.out.println("add(2.5,3.5):      " + calc.add(2.5, 3.5));
        System.out.println("add(1,2,3):        " + calc.add(1, 2, 3));
        System.out.println("add("Hello"," World"): " + calc.add("Hello", " World"));

        System.out.println("\n=== Runtime Polymorphism (Overriding via vtable) ===");
        // Same type reference, different actual objects
        Shape[] shapes = { new Circle(5), new Rectangle(4, 6), new Triangle(3, 8) };
        for (Shape s : shapes) {
            printArea(s);           // runtime decides which area() to call
            System.out.println("  " + s.describe());
        }

        System.out.println("\n=== Upcasting & Downcasting ===");
        Shape s = new Circle(3.0);  // upcasting — always safe
        System.out.println("Upcasted: " + s.area());

        if (s instanceof Circle circle) {   // safe downcasting with pattern matching
            System.out.println("Downcasted radius: " + circle.radius);
        }
    }
}