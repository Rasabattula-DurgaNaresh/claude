package com.corejava.strings;

import java.util.regex.*;

/**
 * TOPIC: String immutability, String pool, StringBuilder, StringBuffer,
 *        common methods, comparison, intern(), regex
 */
public class StringDemo {

    public static void main(String[] args) {
        System.out.println("=== String Immutability ===");
        String s = "Hello";
        System.out.println("Before: " + s + " @" + System.identityHashCode(s));
        s = s + " World";  // creates a NEW string object
        System.out.println("After:  " + s + " @" + System.identityHashCode(s));
        // original "Hello" is unchanged — strings are immutable!

        System.out.println("\n=== String Pool ===");
        String a = "Java";        // from pool
        String b = "Java";        // same pool object
        String c = new String("Java"); // new heap object
        System.out.println("a == b:        " + (a == b));           // true (pool)
        System.out.println("a == c:        " + (a == c));           // false (heap)
        System.out.println("a.equals(c):   " + (a.equals(c)));      // true (content)
        System.out.println("a == c.intern(): " + (a == c.intern())); // true (intern forces pool)

        System.out.println("\n=== Common String Methods ===");
        String str = "  Hello World Java  ";
        System.out.println("length():          " + str.length());
        System.out.println("trim():            '" + str.trim() + "'");
        System.out.println("strip():           '" + str.strip() + "' (Java 11+)");
        System.out.println("toUpperCase():     " + str.trim().toUpperCase());
        System.out.println("toLowerCase():     " + str.trim().toLowerCase());
        System.out.println("charAt(6):         " + str.trim().charAt(6));
        System.out.println("indexOf('W'):      " + str.trim().indexOf('W'));
        System.out.println("substring(6,11):   " + str.trim().substring(6, 11));
        System.out.println("replace('l','L'):  " + str.trim().replace('l', 'L'));
        System.out.println("contains("World"): " + str.trim().contains("World"));
        System.out.println("startsWith("Hello"): " + str.trim().startsWith("Hello"));
        System.out.println("split(" "):        " + java.util.Arrays.toString(str.trim().split(" ")));
        System.out.println("join('-',...):     " + String.join("-", "a","b","c"));

        System.out.println("\n=== StringBuilder vs StringBuffer ===");
        // StringBuilder — NOT thread-safe, FASTER
        StringBuilder sb = new StringBuilder("Hello");
        sb.append(" World")
          .append("!")
          .insert(5, ",")
          .replace(0, 5, "Hi")
          .delete(2, 3);
        System.out.println("StringBuilder: " + sb);
        System.out.println("Reversed: " + sb.reverse());

        // StringBuffer — thread-safe (synchronized), slower
        StringBuffer sbf = new StringBuffer("Thread");
        sbf.append(" Safe");
        System.out.println("StringBuffer:  " + sbf);

        // String concatenation in loop — use StringBuilder!
        long start = System.nanoTime();
        String result = "";
        for (int i = 0; i < 1000; i++) result += "x"; // O(n²) — BAD
        long end = System.nanoTime();
        System.out.println("\nString concat (1000x):  " + (end-start)/1_000_000 + "ms");

        start = System.nanoTime();
        StringBuilder fast = new StringBuilder();
        for (int i = 0; i < 1000; i++) fast.append("x"); // O(n) — GOOD
        end = System.nanoTime();
        System.out.println("StringBuilder (1000x): " + (end-start)/1_000_000 + "ms");

        System.out.println("\n=== Regex Pattern Matching ===");
        String email = "user@example.com";
        String emailRegex = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        System.out.println("Email valid: " + email.matches(emailRegex));

        Pattern p = Pattern.compile("\\d+");
        Matcher m = p.matcher("Order #1234 qty=5");
        while (m.find()) System.out.println("Found number: " + m.group());

        System.out.println("\n=== String Formatting ===");
        System.out.printf("Name: %-15s Age: %3d Salary: %,.2f%n", "Alice", 30, 75000.50);
        String formatted = String.format("Pi = %.4f", Math.PI);
        System.out.println(formatted);
        System.out.println("Formatted with text block Java 15+: works in Java 15+");
    }
}