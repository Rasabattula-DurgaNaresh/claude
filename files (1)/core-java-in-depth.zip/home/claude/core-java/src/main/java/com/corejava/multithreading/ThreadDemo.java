package com.corejava.multithreading;

import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.concurrent.locks.*;

/**
 * TOPIC: Threads, Synchronization, Executor Framework, Deadlock, volatile,
 *        AtomicInteger, ReentrantLock, CompletableFuture
 */
public class ThreadDemo {

    // ── Shared counter — race condition without sync ────────────────────────
    static class UnsafeCounter { int count = 0; void increment() { count++; } }
    static class SafeCounter   { AtomicInteger count = new AtomicInteger(0);
        void increment() { count.incrementAndGet(); } }

    // ── Producer-Consumer using BlockingQueue ──────────────────────────────
    static class ProductionLine {
        private final BlockingQueue<Integer> queue = new ArrayBlockingQueue<>(10);
        private final AtomicBoolean running = new AtomicBoolean(true);

        void produce() throws InterruptedException {
            for (int i = 1; i <= 5; i++) {
                queue.put(i);
                System.out.printf("[Producer] Produced: %d (queue size=%d)%n", i, queue.size());
                Thread.sleep(100);
            }
            running.set(false);
        }

        void consume() throws InterruptedException {
            while (running.get() || !queue.isEmpty()) {
                Integer item = queue.poll(200, TimeUnit.MILLISECONDS);
                if (item != null)
                    System.out.printf("  [Consumer] Consumed: %d%n", item);
            }
        }
    }

    // ── ReentrantLock example ─────────────────────────────────────────────
    static class BankTransfer {
        private double balanceA = 1000, balanceB = 500;
        private final ReentrantLock lockA = new ReentrantLock();
        private final ReentrantLock lockB = new ReentrantLock();

        void transferAtoB(double amount) {
            lockA.lock();
            try {
                lockB.lock();
                try {
                    if (balanceA >= amount) {
                        balanceA -= amount;
                        balanceB += amount;
                        System.out.printf("Transfer A→B: %.0f | A=%.0f B=%.0f%n",
                            amount, balanceA, balanceB);
                    }
                } finally { lockB.unlock(); }
            } finally { lockA.unlock(); }
        }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== Thread Creation ===");

        // Way 1: Runnable lambda
        Thread t1 = new Thread(() -> {
            System.out.println("[T1] " + Thread.currentThread().getName() + " running");
        }, "LambdaThread");

        // Way 2: Extend Thread
        Thread t2 = new Thread() {
            @Override public void run() {
                System.out.println("[T2] " + getName() + " running");
            }
        };
        t2.setName("ExtendThread");

        t1.start(); t2.start();
        t1.join();  t2.join();

        System.out.println("\n=== Race Condition Demo ===");
        int THREADS = 10, OPS = 1000;
        UnsafeCounter unsafe = new UnsafeCounter();
        SafeCounter   safe   = new SafeCounter();

        ExecutorService pool = Executors.newFixedThreadPool(THREADS);
        CountDownLatch latch = new CountDownLatch(THREADS * 2);

        for (int i = 0; i < THREADS; i++) {
            pool.submit(() -> {
                for (int j=0;j<OPS;j++) unsafe.increment();
                latch.countDown();
            });
            pool.submit(() -> {
                for (int j=0;j<OPS;j++) safe.increment();
                latch.countDown();
            });
        }
        latch.await();
        System.out.printf("Expected: %d | Unsafe: %d | Safe: %d%n",
            THREADS*OPS, unsafe.count, safe.count.get());

        System.out.println("\n=== Producer-Consumer (BlockingQueue) ===");
        ProductionLine line = new ProductionLine();
        Thread producer = new Thread(() -> {
            try { line.produce(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }, "Producer");
        Thread consumer = new Thread(() -> {
            try { line.consume(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }, "Consumer");
        producer.start(); consumer.start();
        producer.join(); consumer.join();

        System.out.println("\n=== CompletableFuture ===");
        CompletableFuture<String> cf = CompletableFuture
            .supplyAsync(() -> { sleep(100); return "User-42"; })
            .thenApply(user -> "Hello, " + user + "!")
            .exceptionally(ex -> "Error: " + ex.getMessage());
        System.out.println("Result: " + cf.get());

        CompletableFuture<String> combined = CompletableFuture
            .allOf(
                CompletableFuture.supplyAsync(() -> { sleep(50);  return "DB"; }),
                CompletableFuture.supplyAsync(() -> { sleep(80);  return "Cache"; }),
                CompletableFuture.supplyAsync(() -> { sleep(30);  return "API"; })
            ).thenApply(v -> "All services ready");
        System.out.println(combined.get());

        System.out.println("\n=== ReentrantLock ===");
        BankTransfer bank = new BankTransfer();
        bank.transferAtoB(200);
        bank.transferAtoB(300);

        pool.shutdown();
        System.out.println("\n=== volatile keyword ===");
        System.out.println("volatile ensures visibility — each read/write goes to main memory");
        System.out.println("Does NOT ensure atomicity for compound operations (use AtomicXxx)");

        System.out.println("\n=== wait() vs sleep() ===");
        System.out.println("sleep():  static, holds lock, timed wait");
        System.out.println("wait():   instance, RELEASES lock, needs notify()");
    }

    static void sleep(int ms) {
        try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}