package com.corejava.exceptions;

import java.io.*;

/**
 * TOPIC: Exception Handling — try/catch/finally, checked/unchecked,
 *        custom exceptions, try-with-resources, multi-catch, chaining
 */
public class ExceptionDemo {

    // ── Custom Exceptions ─────────────────────────────────────────────────
    static class InsufficientFundsException extends Exception {
        private final double shortage;
        InsufficientFundsException(double shortage) {
            super(String.format("Insufficient funds. Shortage: %.2f", shortage));
            this.shortage = shortage;
        }
        double getShortage() { return shortage; }
    }

    static class InvalidAgeException extends RuntimeException {  // unchecked
        InvalidAgeException(int age) {
            super("Invalid age: " + age + ". Must be 18-120.");
        }
    }

    // ── Resource that implements AutoCloseable ─────────────────────────────
    static class DatabaseConnection implements AutoCloseable {
        private final String url;
        DatabaseConnection(String url) {
            this.url = url;
            System.out.println("[DB] Connected to: " + url);
        }
        void query(String sql) {
            System.out.println("[DB] Executing: " + sql);
            if (sql.contains("DROP")) throw new IllegalStateException("DROP not allowed!");
        }
        @Override
        public void close() {
            System.out.println("[DB] Connection closed: " + url);
        }
    }

    // ── Bank account with checked exception ───────────────────────────────
    static void withdraw(double balance, double amount) throws InsufficientFundsException {
        if (amount > balance) {
            throw new InsufficientFundsException(amount - balance);
        }
        System.out.println("Withdrew: " + amount + " | Remaining: " + (balance - amount));
    }

    public static void main(String[] args) {
        System.out.println("=== Basic Try-Catch-Finally ===");
        try {
            int[] arr = {1, 2, 3};
            System.out.println(arr[5]);  // ArrayIndexOutOfBoundsException
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Caught: " + e.getMessage());
        } finally {
            System.out.println("Finally always executes!");
        }

        System.out.println("\n=== Multi-Catch (Java 7+) ===");
        try {
            String s = null;
            s.length();                   // NullPointerException
        } catch (NullPointerException | IllegalArgumentException e) {
            System.out.println("Multi-catch: " + e.getClass().getSimpleName());
        }

        System.out.println("\n=== Checked Exception ===");
        try {
            withdraw(500.0, 700.0);
        } catch (InsufficientFundsException e) {
            System.out.println("Error: " + e.getMessage());
            System.out.println("Need more: " + e.getShortage());
        }

        System.out.println("\n=== Unchecked (RuntimeException) ===");
        try {
            validateAge(-5);
        } catch (InvalidAgeException e) {
            System.out.println("Caught runtime: " + e.getMessage());
        }

        System.out.println("\n=== Try-with-Resources ===");
        try (DatabaseConnection db = new DatabaseConnection("jdbc:mysql://localhost/test")) {
            db.query("SELECT * FROM users");
            db.query("DROP TABLE users");  // throws exception
        } catch (IllegalStateException e) {
            System.out.println("DB error: " + e.getMessage());
        }
        // connection auto-closed even on exception!

        System.out.println("\n=== Exception Chaining ===");
        try {
            try {
                int result = 10 / 0;
            } catch (ArithmeticException e) {
                throw new RuntimeException("Business logic failed", e);  // chain cause
            }
        } catch (RuntimeException e) {
            System.out.println("Outer: " + e.getMessage());
            System.out.println("Cause: " + e.getCause().getClass().getSimpleName());
        }

        System.out.println("\n=== throw vs throws ===");
        // throw   — actually throws the exception object
        // throws  — declares that method MAY throw (checked exceptions)
        System.out.println("throw  = action  (throw new Exception())");
        System.out.println("throws = declaration (void method() throws Exception)");
    }

    static void validateAge(int age) {
        if (age < 18 || age > 120) throw new InvalidAgeException(age);
        System.out.println("Age " + age + " is valid.");
    }
}