package com.corejava.oop;

/**
 * TOPIC: Encapsulation — Data hiding + controlled access via getters/setters
 *
 * Benefits:
 *  - Protects data integrity (validation in setters)
 *  - Hides implementation details
 *  - Makes code maintainable
 */
public class EncapsulationDemo {

    // ── Encapsulated class ────────────────────────────────────────────────
    static class BankAccount {
        private final String accountId;
        private double balance;
        private int pinCode;     // never exposed directly

        public BankAccount(String id, double initialBalance, int pin) {
            this.accountId = id;
            if (initialBalance < 0) throw new IllegalArgumentException("Balance can't be negative");
            this.balance = initialBalance;
            this.pinCode = pin;
        }

        // Read-only getter — balance is safe from direct modification
        public double getBalance()   { return balance; }
        public String getAccountId() { return accountId; }

        // Validated deposit
        public void deposit(double amount) {
            if (amount <= 0) throw new IllegalArgumentException("Deposit must be positive");
            balance += amount;
            System.out.printf("[%s] Deposited: %.2f | New balance: %.2f%n", accountId, amount, balance);
        }

        // Validated withdrawal
        public boolean withdraw(double amount, int pin) {
            if (pin != pinCode) {
                System.out.println("Wrong PIN! Transaction rejected.");
                return false;
            }
            if (amount > balance) {
                System.out.println("Insufficient funds!");
                return false;
            }
            balance -= amount;
            System.out.printf("[%s] Withdrawn: %.2f | New balance: %.2f%n", accountId, amount, balance);
            return true;
        }

        @Override
        public String toString() {
            return String.format("Account[%s, Balance=%.2f]", accountId, balance);
        }
    }

    public static void main(String[] args) {
        BankAccount account = new BankAccount("ACC-001", 1000.0, 1234);

        System.out.println("=== Encapsulation Demo ===");
        System.out.println(account);

        account.deposit(500.0);
        account.withdraw(200.0, 1234);
        account.withdraw(200.0, 9999);   // wrong PIN
        account.withdraw(5000.0, 1234);  // insufficient

        // account.balance = 1000000;    // COMPILE ERROR — private
        // account.pinCode = 0000;       // COMPILE ERROR — private
        System.out.println("Final: " + account);
    }
}