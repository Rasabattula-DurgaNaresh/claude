package com.corejava.generics;

import java.util.*;
import java.util.function.*;

/**
 * TOPIC: Generics — type-safe containers, bounded types, wildcards, type erasure
 */
public class GenericsDemo {

    // ── Generic class ─────────────────────────────────────────────────────
    static class Pair<A, B> {
        private final A first;
        private final B second;

        Pair(A first, B second) { this.first=first; this.second=second; }

        A getFirst()  { return first; }
        B getSecond() { return second; }

        // Static factory method
        static <X, Y> Pair<X, Y> of(X x, Y y) { return new Pair<>(x, y); }

        @Override
        public String toString() { return "(" + first + ", " + second + ")"; }
    }

    // ── Bounded type parameters ───────────────────────────────────────────
    static class NumberUtils {
        // T must extend Number
        static <T extends Number> double sum(List<T> list) {
            return list.stream().mapToDouble(Number::doubleValue).sum();
        }

        // Multiple bounds: T extends Comparable AND Number
        static <T extends Number & Comparable<T>> T max(T a, T b) {
            return a.compareTo(b) >= 0 ? a : b;
        }
    }

    // ── Generic stack from scratch ────────────────────────────────────────
    static class GenericStack<T> {
        private final Object[] elements;
        private int size = 0;

        @SuppressWarnings("unchecked")
        GenericStack(int capacity) { elements = new Object[capacity]; }

        void push(T item) {
            if (size == elements.length) throw new RuntimeException("Stack full");
            elements[size++] = item;
        }

        @SuppressWarnings("unchecked")
        T pop() {
            if (size == 0) throw new EmptyStackException();
            T item = (T) elements[--size];
            elements[size] = null; // avoid memory leak
            return item;
        }

        @SuppressWarnings("unchecked")
        T peek() { return size == 0 ? null : (T) elements[size-1]; }
        int size()     { return size; }
        boolean empty(){ return size == 0; }
    }

    // ── Wildcard examples ─────────────────────────────────────────────────
    // ? extends T — read (covariant / upper bound)
    static double sumList(List<? extends Number> list) {
        return list.stream().mapToDouble(Number::doubleValue).sum();
    }

    // ? super T — write (contravariant / lower bound)
    static void addNumbers(List<? super Integer> list) {
        list.add(1); list.add(2); list.add(3);
    }

    // ? — unbounded (only Object methods available)
    static void printList(List<?> list) {
        list.forEach(item -> System.out.print(item + " "));
        System.out.println();
    }

    public static void main(String[] args) {
        System.out.println("=== Generic Pair ===");
        Pair<String, Integer> nameAge = Pair.of("Alice", 30);
        Pair<Double, Boolean> score   = Pair.of(98.5, true);
        System.out.println(nameAge);
        System.out.println(score);

        System.out.println("\n=== Generic Stack ===");
        GenericStack<String> strStack = new GenericStack<>(5);
        strStack.push("Hello");
        strStack.push("World");
        strStack.push("Java");
        System.out.println("Peek: " + strStack.peek());
        System.out.println("Pop: " + strStack.pop());
        System.out.println("Pop: " + strStack.pop());
        System.out.println("Size: " + strStack.size());

        System.out.println("\n=== Bounded Type Parameters ===");
        List<Integer> ints    = Arrays.asList(1, 2, 3, 4, 5);
        List<Double>  doubles = Arrays.asList(1.1, 2.2, 3.3);
        System.out.println("Sum of ints:    " + NumberUtils.sum(ints));
        System.out.println("Sum of doubles: " + NumberUtils.sum(doubles));
        System.out.println("Max(3.14, 2.71): " + NumberUtils.max(3.14, 2.71));
        System.out.println("Max(10, 7):      " + NumberUtils.max(10, 7));

        System.out.println("\n=== Wildcards ===");
        List<Integer>  intList  = Arrays.asList(10, 20, 30);
        List<Double>   dblList  = Arrays.asList(1.1, 2.2, 3.3);
        List<Number>   numList  = new ArrayList<>();

        System.out.println("Sum (? extends Number):");
        System.out.println("  ints:    " + sumList(intList));
        System.out.println("  doubles: " + sumList(dblList));

        addNumbers(numList); // ? super Integer
        System.out.println("After addNumbers: " + numList);

        printList(intList); // <?> unbounded

        System.out.println("\n=== Type Erasure ===");
        // At runtime, List<String> and List<Integer> are both just List
        List<String>  strList = new ArrayList<>();
        List<Integer> intList2 = new ArrayList<>();
        System.out.println("Same class at runtime: " + (strList.getClass() == intList2.getClass()));
        System.out.println("Class: " + strList.getClass().getName()); // just java.util.ArrayList

        System.out.println("\n=== Generic Method ===");
        String[] strArr = {"banana","apple","cherry"};
        Integer[] intArr = {3,1,4,1,5,9};
        System.out.println("String array: " + Arrays.toString(sort(strArr)));
        System.out.println("Integer array: " + Arrays.toString(sort(intArr)));
    }

    static <T extends Comparable<T>> T[] sort(T[] arr) {
        Arrays.sort(arr);
        return arr;
    }
}