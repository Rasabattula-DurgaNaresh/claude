package com.corejava.jvm;

import java.lang.management.*;

/**
 * TOPIC: JVM architecture, memory areas, class loading, garbage collection
 */
public class JVMInternalsDemo {

    // Demonstrate class loading order
    static class Parent {
        static int x = 10;
        static { System.out.println("[Parent] Static block — class loaded"); }
        { System.out.println("[Parent] Instance block"); }
        Parent() { System.out.println("[Parent] Constructor"); }
    }

    static class Child extends Parent {
        static int y = 20;
        static { System.out.println("[Child] Static block — class loaded"); }
        { System.out.println("[Child] Instance block"); }
        Child() { System.out.println("[Child] Constructor"); }
    }

    // Demonstrate stack overflow
    static int recursionDepth = 0;
    static void recurse() {
        recursionDepth++;
        recurse(); // infinite recursion → StackOverflowError
    }

    public static void main(String[] args) {
        System.out.println("=== Class Loading Order ===");
        System.out.println("Creating Child instance:");
        Child child = new Child();
        // Order: Parent static → Child static → Parent instance → Child instance → Constructor

        System.out.println("\n=== JVM Memory Info ===");
        Runtime runtime = Runtime.getRuntime();
        long totalMem   = runtime.totalMemory() / (1024*1024);
        long freeMem    = runtime.freeMemory()  / (1024*1024);
        long maxMem     = runtime.maxMemory()   / (1024*1024);
        int  processors = runtime.availableProcessors();

        System.out.printf("Total Memory:  %d MB%n", totalMem);
        System.out.printf("Free Memory:   %d MB%n", freeMem);
        System.out.printf("Max Memory:    %d MB%n", maxMem);
        System.out.printf("Used Memory:   %d MB%n", totalMem - freeMem);
        System.out.printf("CPU cores:     %d%n", processors);

        System.out.println("\n=== Class Loader Hierarchy ===");
        Class<?> cls = JVMInternalsDemo.class;
        ClassLoader loader = cls.getClassLoader();
        System.out.println("Application ClassLoader: " + loader);
        System.out.println("Parent (Extension/Platform): " + loader.getParent());
        System.out.println("Bootstrap (null = native): " + loader.getParent().getParent());

        System.out.println("\n=== Class Info via Reflection ===");
        System.out.println("Class name:         " + cls.getName());
        System.out.println("Simple name:        " + cls.getSimpleName());
        System.out.println("Package:            " + cls.getPackageName());
        System.out.println("Superclass:         " + cls.getSuperclass().getName());
        System.out.println("Declared classes:   " + cls.getDeclaredClasses().length);

        System.out.println("\n=== Garbage Collection ===");
        System.out.println("Creating objects for GC...");
        for (int i = 0; i < 100_000; i++) {
            String s = new String("Object-" + i); // immediately eligible for GC
        }
        long beforeGC = runtime.freeMemory();
        System.gc(); // suggest GC (not guaranteed)
        long afterGC = runtime.freeMemory();
        System.out.printf("Memory freed by GC: ~%d KB%n", (afterGC - beforeGC) / 1024);

        System.out.println("\n=== Stack vs Heap Demo ===");
        System.out.println("Stack: local variables, method calls, primitive values");
        System.out.println("Heap:  all objects, String pool, static fields");
        System.out.println("int x = 5;          → x lives on STACK");
        System.out.println("String s = "hi";    → 's' ref on STACK, 'hi' on HEAP (pool)");
        System.out.println("new Object()        → object on HEAP");

        System.out.println("\n=== StackOverflowError Demo ===");
        try {
            recurse();
        } catch (StackOverflowError e) {
            System.out.println("StackOverflowError at depth: " + recursionDepth);
        }

        System.out.println("\n=== Memory Management Best Practices ===");
        String[] tips = {
            "1. Close streams/connections in finally or try-with-resources",
            "2. Remove objects from collections when done",
            "3. Prefer StringBuilder over String concatenation in loops",
            "4. Use WeakReference for cache-like structures",
            "5. Be careful with static fields — they live for app lifetime",
            "6. Large String: use s = null; System.gc(); to hint GC",
            "7. Use primitive arrays over ArrayList<Integer> for large data"
        };
        for (String tip : tips) System.out.println(tip);
    }
}