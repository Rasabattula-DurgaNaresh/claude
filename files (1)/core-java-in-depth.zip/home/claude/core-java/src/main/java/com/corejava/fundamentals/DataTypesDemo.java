package com.corejava.fundamentals;

/**
 * TOPIC: Primitive Data Types, Wrapper Classes, Autoboxing, Type Casting
 *
 * Java has 8 primitive types:
 *   byte(1B)  short(2B)  int(4B)  long(8B)
 *   float(4B) double(8B) char(2B) boolean(1b)
 *
 * Wrapper classes enable primitives to be used as objects (Collections, Generics).
 */
public class DataTypesDemo {

    public static void main(String[] args) {
        System.out.println("=== Primitive Data Types ===");

        byte   b  = 127;
        short  s  = 32767;
        int    i  = 2_147_483_647;     // underscore for readability (Java 7+)
        long   l  = 9_223_372_036_854_775_807L;
        float  f  = 3.14f;
        double d  = 3.14159265358979;
        char   c  = 'A';
        boolean flag = true;

        System.out.printf("byte=%d  short=%d  int=%d%n", b, s, i);
        System.out.printf("long=%d  float=%.2f  double=%.10f%n", l, f, d);
        System.out.printf("char=%c  boolean=%b%n", c, flag);

        // ── Wrapper Classes ──────────────────────────────────────────────
        System.out.println("\n=== Wrapper Classes & Autoboxing ===");
        Integer wrapped = 42;                  // autoboxing: int → Integer
        int     unwrapped = wrapped;            // unboxing:  Integer → int

        System.out.println("Autoboxed Integer: " + wrapped);
        System.out.println("Unboxed int:       " + unwrapped);

        // Integer cache: -128 to 127 are cached
        Integer a = 100;  // cached
        Integer aa = 100; // same cached object
        Integer x = 200;  // NOT cached — new object
        Integer xx = 200;

        System.out.println("100 == 100 (cached): "  + (a  == aa));   // true
        System.out.println("200 == 200 (new obj): "  + (x  == xx));   // false
        System.out.println("200 equals 200: "         + x.equals(xx)); // true

        // Useful Wrapper methods
        System.out.println("\nWrapper utility methods:");
        System.out.println("parseInt('42'):  " + Integer.parseInt("42"));
        System.out.println("toBinaryString:  " + Integer.toBinaryString(42));
        System.out.println("MAX_VALUE:       " + Integer.MAX_VALUE);
        System.out.println("MIN_VALUE:       " + Integer.MIN_VALUE);

        // ── Type Casting ─────────────────────────────────────────────────
        System.out.println("\n=== Type Casting ===");
        // Widening (implicit) — no data loss
        int   intVal   = 100;
        long  longVal  = intVal;   // implicit widening
        double dbl     = longVal;  // implicit widening

        // Narrowing (explicit) — potential data loss
        double pi    = 3.99;
        int    truncated = (int) pi;  // truncates, NOT rounds → 3
        System.out.println("3.99 cast to int: " + truncated);

        byte overflow = (byte) 130;   // 130 > 127, wraps around
        System.out.println("130 cast to byte (overflow): " + overflow); // -126
    }
}