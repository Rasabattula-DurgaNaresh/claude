package com.corejava.fileio;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.*;

/**
 * TOPIC: File I/O — byte streams, character streams, buffered, NIO,
 *        serialization, deserialization
 */
public class FileIODemo {

    // ── Serializable class ────────────────────────────────────────────────
    static class User implements Serializable {
        private static final long serialVersionUID = 1L;
        private String name;
        private int    age;
        private transient String password; // NOT serialized

        User(String name, int age, String password) {
            this.name = name; this.age = age; this.password = password;
        }

        @Override public String toString() {
            return String.format("User{name=%s, age=%d, password=%s}", name, age, password);
        }
    }

    public static void main(String[] args) throws Exception {
        String tmpDir = System.getProperty("java.io.tmpdir");

        System.out.println("=== Writing Text File (BufferedWriter) ===");
        Path textFile = Path.of(tmpDir, "demo.txt");
        try (BufferedWriter bw = Files.newBufferedWriter(textFile)) {
            bw.write("Line 1: Java is platform independent");
            bw.newLine();
            bw.write("Line 2: Write once, run anywhere");
            bw.newLine();
            bw.write("Line 3: OOP principles");
        }
        System.out.println("Written: " + textFile);

        System.out.println("\n=== Reading Text File (BufferedReader) ===");
        try (BufferedReader br = Files.newBufferedReader(textFile)) {
            String line;
            int lineNum = 1;
            while ((line = br.readLine()) != null)
                System.out.println(lineNum++ + ": " + line);
        }

        System.out.println("\n=== NIO Files API (Java 7+) ===");
        // Write all lines at once
        Path nioFile = Path.of(tmpDir, "nio_demo.txt");
        Files.writeString(nioFile, "Java NIO is fast\nPath API is modern\nChannels beat streams");
        System.out.println("NIO written: " + nioFile);

        // Read all lines as stream
        Files.lines(nioFile).forEach(l -> System.out.println("  " + l));

        // File operations
        System.out.println("Exists: " + Files.exists(nioFile));
        System.out.println("Size:   " + Files.size(nioFile) + " bytes");
        System.out.println("isFile: " + Files.isRegularFile(nioFile));

        // Copy and move
        Path copyFile = Path.of(tmpDir, "nio_copy.txt");
        Files.copy(nioFile, copyFile, StandardCopyOption.REPLACE_EXISTING);
        System.out.println("Copied to: " + copyFile);

        System.out.println("\n=== Serialization ===");
        User user = new User("Alice", 30, "secret123");
        System.out.println("Before: " + user);

        Path binFile = Path.of(tmpDir, "user.bin");
        // Serialize
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(binFile.toFile()))) {
            oos.writeObject(user);
            System.out.println("Serialized to: " + binFile);
        }

        // Deserialize
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(binFile.toFile()))) {
            User loaded = (User) ois.readObject();
            System.out.println("After deserialization: " + loaded);
            System.out.println("(Note: password is null — transient field not serialized)");
        }

        System.out.println("\n=== Byte Stream ===");
        Path byteFile = Path.of(tmpDir, "bytes.bin");
        // Write bytes
        try (FileOutputStream fos = new FileOutputStream(byteFile.toFile());
             BufferedOutputStream bos = new BufferedOutputStream(fos)) {
            byte[] data = "Hello Binary World".getBytes();
            bos.write(data);
        }
        // Read bytes
        try (FileInputStream fis = new FileInputStream(byteFile.toFile())) {
            byte[] buffer = new byte[1024];
            int bytesRead = fis.read(buffer);
            System.out.println("Read " + bytesRead + " bytes: " + new String(buffer, 0, bytesRead));
        }

        System.out.println("\n=== Cleanup ===");
        Files.deleteIfExists(textFile); Files.deleteIfExists(nioFile);
        Files.deleteIfExists(copyFile); Files.deleteIfExists(binFile);
        Files.deleteIfExists(byteFile);
        System.out.println("Temp files cleaned up.");
    }
}