package com.corejava.oop;

/**
 * TOPIC: Inheritance — extends, super, method overriding, constructor chaining
 *
 * Types: Single, Multilevel, Hierarchical
 * Java does NOT support Multiple class inheritance (prevents diamond problem)
 */
public class InheritanceDemo {

    // ── Base class ────────────────────────────────────────────────────────
    static abstract class Animal {
        protected String name;
        protected int age;

        Animal(String name, int age) {
            this.name = name;
            this.age  = age;
            System.out.println("[Animal] Constructor: " + name);
        }

        // Template method
        public void sleep() { System.out.println(name + " is sleeping..."); }

        // To be overridden
        public abstract String speak();

        // final — cannot be overridden
        public final String identify() { return getClass().getSimpleName() + ": " + name; }

        @Override
        public String toString() { return String.format("%s(name=%s, age=%d)", getClass().getSimpleName(), name, age); }
    }

    // ── Single Inheritance ────────────────────────────────────────────────
    static class Dog extends Animal {
        private String breed;

        Dog(String name, int age, String breed) {
            super(name, age);  // MUST be first statement
            this.breed = breed;
            System.out.println("[Dog] Constructor: " + name);
        }

        @Override
        public String speak() { return name + " says: Woof! Woof!"; }

        public void fetch(String item) { System.out.println(name + " fetches the " + item + "!"); }

        @Override
        public String toString() { return super.toString() + ", breed=" + breed; }
    }

    // ── Multilevel Inheritance ────────────────────────────────────────────
    static class Labrador extends Dog {
        private String color;

        Labrador(String name, int age, String color) {
            super(name, age, "Labrador");  // calls Dog constructor
            this.color = color;
            System.out.println("[Labrador] Constructor: " + name);
        }

        @Override
        public String speak() {
            return super.speak() + " (Happy Labrador!)";  // calling parent
        }
    }

    // ── Hierarchical Inheritance ──────────────────────────────────────────
    static class Cat extends Animal {
        Cat(String name, int age) {
            super(name, age);
        }
        @Override
        public String speak() { return name + " says: Meow!"; }
    }

    public static void main(String[] args) {
        System.out.println("=== Inheritance Demo ===\n");

        System.out.println("--- Constructor chain for Labrador ---");
        Labrador lab = new Labrador("Buddy", 3, "Golden");
        System.out.println();

        // Polymorphic reference
        Animal[] animals = { lab, new Dog("Rex", 5, "German Shepherd"), new Cat("Whiskers", 2) };

        System.out.println("--- Polymorphic speak() ---");
        for (Animal a : animals) {
            System.out.println(a.speak());           // runtime dispatch!
            System.out.println("  identify: " + a.identify());
        }

        System.out.println("\n--- instanceof checks ---");
        System.out.println("lab instanceof Animal:    " + (lab instanceof Animal));
        System.out.println("lab instanceof Dog:       " + (lab instanceof Dog));
        System.out.println("lab instanceof Labrador:  " + (lab instanceof Labrador));
        System.out.println("lab instanceof Cat:       " + (lab instanceof Cat));
    }
}