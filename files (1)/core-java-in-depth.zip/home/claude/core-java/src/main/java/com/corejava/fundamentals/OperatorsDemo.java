package com.corejava.fundamentals;

/**
 * TOPIC: All Java Operators
 * Arithmetic, Relational, Logical, Bitwise, Shift, Ternary, instanceof
 */
public class OperatorsDemo {

    public static void main(String[] args) {
        System.out.println("=== Arithmetic Operators ===");
        int a = 17, b = 5;
        System.out.printf("%d + %d = %d%n", a, b, a+b);
        System.out.printf("%d - %d = %d%n", a, b, a-b);
        System.out.printf("%d * %d = %d%n", a, b, a*b);
        System.out.printf("%d / %d = %d%n", a, b, a/b);    // integer division
        System.out.printf("%d %% %d = %d%n", a, b, a%b);   // modulo
        System.out.printf("pre-increment: ++a = %d%n", ++a); // 18
        System.out.printf("post-increment: a++ = %d%n", a++);// 18 (then becomes 19)

        System.out.println("\n=== Bitwise Operators ===");
        int x = 0b1010;  // 10 in binary
        int y = 0b1100;  // 12 in binary
        System.out.printf("AND  1010 & 1100 = %04d (decimal=%d)%n", Integer.parseInt(Integer.toBinaryString(x&y)), x&y);
        System.out.printf("OR   1010 | 1100 = %04d (decimal=%d)%n", Integer.parseInt(Integer.toBinaryString(x|y)), x|y);
        System.out.printf("XOR  1010 ^ 1100 = %04d (decimal=%d)%n", Integer.parseInt(Integer.toBinaryString(x^y)), x^y);
        System.out.printf("NOT  ~1010       = %d%n", ~x);
        System.out.printf("Left shift  10<<1 = %d (multiply by 2)%n", 10<<1);
        System.out.printf("Right shift 10>>1 = %d (divide by 2)%n",  10>>1);

        System.out.println("\n=== Logical & Ternary ===");
        boolean p = true, q = false;
        System.out.println("AND: " + (p && q)); // short-circuit
        System.out.println("OR:  " + (p || q)); // short-circuit
        System.out.println("NOT: " + (!p));

        int max = (a > b) ? a : b;   // ternary operator
        System.out.println("Max via ternary: " + max);

        System.out.println("\n=== instanceof ===");
        Object str = "Hello Java";
        if (str instanceof String s) {   // pattern matching (Java 16+)
            System.out.println("Is String, length: " + s.length());
        }
        System.out.println("Is String: " + (str instanceof String));
        System.out.println("Is Number: " + (str instanceof Number));
    }
}