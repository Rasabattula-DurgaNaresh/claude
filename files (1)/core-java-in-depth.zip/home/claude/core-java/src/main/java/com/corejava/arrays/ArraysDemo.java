package com.corejava.arrays;

import java.util.*;
import java.util.stream.*;

/**
 * TOPIC: Arrays — 1D, 2D, Jagged, Sorting, Searching, Stream operations
 */
public class ArraysDemo {

    public static void main(String[] args) {
        System.out.println("=== Single-Dimensional Arrays ===");
        int[] arr1 = new int[5];             // default 0
        int[] arr2 = {10, 20, 30, 40, 50};   // literal
        int[] arr3 = new int[]{1, 2, 3};     // new keyword with literal

        Arrays.fill(arr1, 7);
        System.out.println("Filled array: " + Arrays.toString(arr1));
        System.out.println("arr2: " + Arrays.toString(arr2));

        // Array operations
        int[] copy = Arrays.copyOf(arr2, arr2.length);
        int[] range = Arrays.copyOfRange(arr2, 1, 4);
        System.out.println("Copy: " + Arrays.toString(copy));
        System.out.println("Range [1,4): " + Arrays.toString(range));

        // Sorting
        int[] unsorted = {64, 34, 25, 12, 22, 11, 90};
        Arrays.sort(unsorted);
        System.out.println("Sorted: " + Arrays.toString(unsorted));

        // Binary search (array must be sorted)
        int idx = Arrays.binarySearch(unsorted, 25);
        System.out.println("BinarySearch(25): index=" + idx);

        System.out.println("\n=== 2D Arrays (Matrix) ===");
        int[][] matrix = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
        };
        System.out.println("Matrix:");
        for (int[] row : matrix) System.out.println(Arrays.toString(row));
        System.out.println("Element [1][2]: " + matrix[1][2]);

        // Matrix transpose
        int rows = matrix.length, cols = matrix[0].length;
        int[][] transposed = new int[cols][rows];
        for (int r = 0; r < rows; r++)
            for (int c = 0; c < cols; c++)
                transposed[c][r] = matrix[r][c];
        System.out.println("Transposed:");
        for (int[] row : transposed) System.out.println(Arrays.toString(row));

        System.out.println("\n=== Jagged Arrays ===");
        int[][] jagged = new int[3][];
        jagged[0] = new int[]{1};
        jagged[1] = new int[]{2, 3};
        jagged[2] = new int[]{4, 5, 6};
        for (int[] row : jagged) System.out.println(Arrays.toString(row));

        System.out.println("\n=== Array Algorithms ===");
        int[] data = {3, 1, 4, 1, 5, 9, 2, 6, 5, 3};
        System.out.println("Data: " + Arrays.toString(data));

        // Find max / min
        int max = data[0], min = data[0];
        for (int x : data) { max = Math.max(max, x); min = Math.min(min, x); }
        System.out.println("Max: " + max + ", Min: " + min);

        // Find duplicates
        System.out.print("Duplicates: ");
        Set<Integer> seen = new HashSet<>();
        for (int x : data) if (!seen.add(x)) System.out.print(x + " ");
        System.out.println();

        // Second largest
        int first = Integer.MIN_VALUE, second = Integer.MIN_VALUE;
        for (int x : data) {
            if (x > first) { second = first; first = x; }
            else if (x > second && x != first) second = x;
        }
        System.out.println("2nd Largest: " + second);

        System.out.println("\n=== Arrays with Streams (Java 8+) ===");
        int[] nums = {5, 3, 8, 1, 9, 2, 7};
        int sum = Arrays.stream(nums).sum();
        double avg = Arrays.stream(nums).average().orElse(0);
        int maximum = Arrays.stream(nums).max().orElse(0);
        long count = Arrays.stream(nums).filter(x -> x > 5).count();

        System.out.println("Sum: " + sum);
        System.out.println("Average: " + avg);
        System.out.println("Max: " + maximum);
        System.out.println("Count > 5: " + count);
        System.out.println("Sorted stream: " + Arrays.stream(nums).sorted()
                .boxed().collect(Collectors.toList()));
    }
}