package com.corejava.reflection;

import java.lang.reflect.*;

/**
 * TOPIC: Reflection API — inspect and modify classes at runtime,
 *        dynamic invocation, accessing private members
 */
public class ReflectionDemo {

    @interface Validate { boolean required() default true; String regex() default ""; }
    @interface Description { String value(); }

    @Description("A sample person entity")
    static class Person {
        private String name;
        private int age;
        private static int count = 0;

        public Person() { count++; }
        public Person(String name, int age) { this.name=name; this.age=age; count++; }

        @Validate(required=true, regex="^[A-Za-z ]+$")
        public String getName() { return name; }

        @Validate
        public int getAge() { return age; }

        public void greet() { System.out.println("Hello, I'm " + name + ", age " + age); }

        private void secret() { System.out.println("Secret method called on: " + name); }

        @Override public String toString() { return "Person{" + name + ", " + age + "}"; }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== Getting Class Info ===");
        Class<?> cls = Class.forName("com.corejava.reflection.ReflectionDemo$Person");
        System.out.println("Name:         " + cls.getName());
        System.out.println("Simple name:  " + cls.getSimpleName());
        System.out.println("Package:      " + cls.getPackageName());
        System.out.println("Superclass:   " + cls.getSuperclass().getSimpleName());
        System.out.println("Interfaces:   " + java.util.Arrays.toString(cls.getInterfaces()));

        System.out.println("\n=== Constructors ===");
        for (Constructor<?> c : cls.getDeclaredConstructors())
            System.out.println("  " + c);

        System.out.println("\n=== Methods ===");
        for (Method m : cls.getDeclaredMethods())
            System.out.printf("  %-20s → %s%n", m.getName(), m.getReturnType().getSimpleName());

        System.out.println("\n=== Fields ===");
        for (Field f : cls.getDeclaredFields())
            System.out.printf("  %-10s %s%n", f.getType().getSimpleName(), f.getName());

        System.out.println("\n=== Creating Instance via Reflection ===");
        Constructor<?> ctor = cls.getDeclaredConstructor(String.class, int.class);
        Object person = ctor.newInstance("Alice", 30);
        System.out.println("Created: " + person);

        System.out.println("\n=== Invoking Method ===");
        Method greet = cls.getDeclaredMethod("greet");
        greet.invoke(person);

        System.out.println("\n=== Accessing Private Method ===");
        Method secret = cls.getDeclaredMethod("secret");
        secret.setAccessible(true); // bypass access control
        secret.invoke(person);

        System.out.println("\n=== Accessing Private Field ===");
        Field nameField = cls.getDeclaredField("name");
        nameField.setAccessible(true);
        System.out.println("Before: " + nameField.get(person));
        nameField.set(person, "Bob");
        System.out.println("After:  " + nameField.get(person));

        System.out.println("\n=== Reading Annotations ===");
        Description desc = cls.getAnnotation(Description.class);
        System.out.println("Class description: " + (desc != null ? desc.value() : "none"));

        for (Method m : cls.getDeclaredMethods()) {
            Validate v = m.getAnnotation(Validate.class);
            if (v != null)
                System.out.printf("  %s — required=%b regex='%s'%n", m.getName(), v.required(), v.regex());
        }

        System.out.println("\n=== Generic Type Info ===");
        // Reflection can sometimes recover generic info
        Field listField; // just an example concept
        System.out.println("Type erasure: List<String> becomes just List at runtime");
        System.out.println("Reflection can see: parameterized types on fields/methods");
    }
}