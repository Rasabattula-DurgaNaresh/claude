package com.corejava.oop;

/**
 * TOPIC: Abstraction — Abstract Classes vs Interfaces
 *
 * Abstract Class:
 *  - Can have state (instance variables)
 *  - Can have constructor
 *  - Can have partial implementation
 *  - extends (single)
 *
 * Interface:
 *  - No state (only constants pre-Java 8)
 *  - Default methods (Java 8+)
 *  - Defines CONTRACT
 *  - implements (multiple)
 */
public class AbstractionDemo {

    // ── Abstract Class ────────────────────────────────────────────────────
    static abstract class Vehicle {
        protected String brand;
        protected int year;
        private int mileage = 0;  // state — only concrete class controls this

        Vehicle(String brand, int year) {
            this.brand = brand;
            this.year  = year;
        }

        // Abstract — subclass MUST implement
        public abstract void start();
        public abstract void stop();
        public abstract double fuelEfficiency(); // km per litre

        // Concrete — shared behaviour
        public void drive(int km) {
            mileage += km;
            System.out.printf("[%s] Drove %dkm — Total: %dkm%n", brand, km, mileage);
        }

        public int getMileage() { return mileage; }
    }

    // ── Interfaces ────────────────────────────────────────────────────────
    interface Electric {
        int getChargeLevel();
        void charge(int percent);

        // Default method (Java 8+)
        default String chargeStatus() {
            int level = getChargeLevel();
            if (level < 20) return "LOW";
            if (level < 80) return "NORMAL";
            return "FULL";
        }

        // Static utility method
        static boolean isFastChargeable(int amps) { return amps >= 50; }
    }

    interface Autopilot {
        void enableAutopilot();
        default String status() { return "Autopilot: OFF"; }
    }

    // ── Concrete — inherits abstract + multiple interfaces ─────────────────
    static class ElectricCar extends Vehicle implements Electric, Autopilot {
        private int chargeLevel;
        private boolean autoPilotOn = false;

        ElectricCar(String brand, int year, int initialCharge) {
            super(brand, year);
            this.chargeLevel = initialCharge;
        }

        @Override public void start()  { System.out.println(brand + " EV starting silently..."); }
        @Override public void stop()   { System.out.println(brand + " EV stopped. Regenerative braking!"); }
        @Override public double fuelEfficiency() { return 6.5; /* km per kWh */ }

        @Override public int  getChargeLevel() { return chargeLevel; }
        @Override public void charge(int p)    { chargeLevel = Math.min(100, chargeLevel + p); }
        @Override public void enableAutopilot() {
            autoPilotOn = true;
            System.out.println(brand + " Autopilot ENABLED");
        }
        @Override public String status() { return "Autopilot: " + (autoPilotOn ? "ON" : "OFF"); }
    }

    public static void main(String[] args) {
        System.out.println("=== Abstraction Demo ===");

        // Vehicle v = new Vehicle(..); // COMPILE ERROR — abstract!
        ElectricCar tesla = new ElectricCar("Tesla Model 3", 2023, 60);

        tesla.start();
        tesla.drive(150);
        tesla.enableAutopilot();
        System.out.println("Charge: " + tesla.getChargeLevel() + "% — " + tesla.chargeStatus());
        System.out.println(tesla.status());
        System.out.println("Efficiency: " + tesla.fuelEfficiency() + " km/kWh");

        // Using interface references (programming to interface)
        Electric ev = tesla;
        ev.charge(25);
        System.out.println("After charging: " + ev.getChargeLevel() + "%");

        System.out.println("Fast chargeable (100A)? " + Electric.isFastChargeable(100));
    }
}