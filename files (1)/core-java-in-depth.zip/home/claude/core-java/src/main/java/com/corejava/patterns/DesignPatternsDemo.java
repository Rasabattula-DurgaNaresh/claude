package com.corejava.patterns;

import java.util.*;
import java.util.function.*;

/**
 * TOPIC: Design Patterns — Singleton, Factory, Builder, Observer, Strategy,
 *        Decorator, Proxy
 */
public class DesignPatternsDemo {

    // ══════════ CREATIONAL ════════════════════════════════════════════════

    // ── Singleton (Thread-safe — Bill Pugh idiom) ─────────────────────────
    static class ConfigManager {
        private final Map<String, String> config = new HashMap<>();

        private ConfigManager() {
            config.put("db.url",  "jdbc:mysql://localhost/prod");
            config.put("db.pool", "10");
            config.put("app.env", "production");
        }

        private static class Holder { static final ConfigManager INSTANCE = new ConfigManager(); }

        public static ConfigManager getInstance() { return Holder.INSTANCE; }
        public String get(String key) { return config.getOrDefault(key, ""); }
        public void set(String key, String value) { config.put(key, value); }
    }

    // ── Factory Method ────────────────────────────────────────────────────
    interface Notification {
        void send(String to, String message);
        String getType();
    }

    static class EmailNotification implements Notification {
        @Override public void send(String to, String message) {
            System.out.printf("[EMAIL] To: %s | Msg: %s%n", to, message);
        }
        @Override public String getType() { return "EMAIL"; }
    }

    static class SMSNotification implements Notification {
        @Override public void send(String to, String message) {
            System.out.printf("[SMS] To: %s | Msg: %s%n", to, message);
        }
        @Override public String getType() { return "SMS"; }
    }

    static class PushNotification implements Notification {
        @Override public void send(String to, String message) {
            System.out.printf("[PUSH] To: %s | Msg: %s%n", to, message);
        }
        @Override public String getType() { return "PUSH"; }
    }

    static class NotificationFactory {
        public static Notification create(String type) {
            return switch (type.toUpperCase()) {
                case "EMAIL" -> new EmailNotification();
                case "SMS"   -> new SMSNotification();
                case "PUSH"  -> new PushNotification();
                default      -> throw new IllegalArgumentException("Unknown: " + type);
            };
        }
    }

    // ── Builder ───────────────────────────────────────────────────────────
    static class HttpRequest {
        private final String method;
        private final String url;
        private final Map<String, String> headers;
        private final String body;
        private final int timeoutMs;

        private HttpRequest(Builder b) {
            this.method    = b.method;
            this.url       = b.url;
            this.headers   = Collections.unmodifiableMap(b.headers);
            this.body      = b.body;
            this.timeoutMs = b.timeoutMs;
        }

        @Override public String toString() {
            return String.format("HttpRequest{%s %s, headers=%s, timeout=%dms}",
                method, url, headers, timeoutMs);
        }

        static class Builder {
            private final String method;
            private final String url;
            private Map<String, String> headers = new LinkedHashMap<>();
            private String body = "";
            private int timeoutMs = 3000;

            Builder(String method, String url) { this.method=method; this.url=url; }

            Builder header(String key, String value) { headers.put(key, value); return this; }
            Builder body(String body)                { this.body=body;           return this; }
            Builder timeout(int ms)                  { this.timeoutMs=ms;        return this; }
            HttpRequest build()                      { return new HttpRequest(this); }
        }
    }

    // ══════════ BEHAVIORAL ════════════════════════════════════════════════

    // ── Observer ──────────────────────────────────────────────────────────
    interface EventListener<T> { void onEvent(T data); }

    static class EventBus<T> {
        private final List<EventListener<T>> listeners = new ArrayList<>();
        void subscribe(EventListener<T> l) { listeners.add(l); }
        void unsubscribe(EventListener<T> l) { listeners.remove(l); }
        void publish(T event) { listeners.forEach(l -> l.onEvent(event)); }
    }

    record OrderEvent(String orderId, String status, double total) {}

    // ── Strategy ─────────────────────────────────────────────────────────
    interface PricingStrategy { double calculate(double basePrice, int quantity); }

    enum Pricing implements PricingStrategy {
        REGULAR    { @Override public double calculate(double p, int q) { return p * q; } },
        BULK       { @Override public double calculate(double p, int q) { return p * q * (q >= 10 ? 0.85 : 1.0); } },
        PREMIUM    { @Override public double calculate(double p, int q) { return p * q * 1.2; } },
        FLASH_SALE { @Override public double calculate(double p, int q) { return p * q * 0.5; } }
    }

    static class ShoppingCart {
        private PricingStrategy strategy = Pricing.REGULAR;
        private final List<double[]> items = new ArrayList<>();

        void setStrategy(PricingStrategy s) { this.strategy = s; }
        void addItem(double price, int qty)  { items.add(new double[]{price, qty}); }

        double checkout() {
            return items.stream()
                .mapToDouble(item -> strategy.calculate(item[0], (int)item[1]))
                .sum();
        }
    }

    // ── Decorator ────────────────────────────────────────────────────────
    interface TextProcessor { String process(String text); }

    static class PlainText    implements TextProcessor {
        @Override public String process(String text) { return text; }
    }
    static class UpperCaseDecorator implements TextProcessor {
        private final TextProcessor inner;
        UpperCaseDecorator(TextProcessor tp) { this.inner=tp; }
        @Override public String process(String text) { return inner.process(text).toUpperCase(); }
    }
    static class TrimDecorator implements TextProcessor {
        private final TextProcessor inner;
        TrimDecorator(TextProcessor tp) { this.inner=tp; }
        @Override public String process(String text) { return inner.process(text).strip(); }
    }
    static class PrefixDecorator implements TextProcessor {
        private final TextProcessor inner;
        private final String prefix;
        PrefixDecorator(TextProcessor tp, String prefix) { this.inner=tp; this.prefix=prefix; }
        @Override public String process(String text) { return prefix + inner.process(text); }
    }

    public static void main(String[] args) {
        System.out.println("=== Singleton ===");
        ConfigManager cfg1 = ConfigManager.getInstance();
        ConfigManager cfg2 = ConfigManager.getInstance();
        System.out.println("Same instance: " + (cfg1 == cfg2));
        System.out.println("DB URL: " + cfg1.get("db.url"));
        cfg1.set("feature.flag", "ON");
        System.out.println("Feature flag (via cfg2): " + cfg2.get("feature.flag"));

        System.out.println("\n=== Factory Method ===");
        for (String type : List.of("EMAIL", "SMS", "PUSH")) {
            Notification n = NotificationFactory.create(type);
            n.send("user@example.com", "Hello from " + n.getType());
        }

        System.out.println("\n=== Builder ===");
        HttpRequest req = new HttpRequest.Builder("POST", "https://api.example.com/orders")
            .header("Content-Type", "application/json")
            .header("Authorization", "Bearer token123")
            .body("{"item":"laptop","qty":1}")
            .timeout(5000)
            .build();
        System.out.println(req);

        System.out.println("\n=== Observer (EventBus) ===");
        EventBus<OrderEvent> orderBus = new EventBus<>();
        orderBus.subscribe(e -> System.out.printf("[EmailService] Order %s %s — $%.2f%n", e.orderId(), e.status(), e.total()));
        orderBus.subscribe(e -> System.out.printf("[Inventory] Update for order %s%n", e.orderId()));
        orderBus.subscribe(e -> { if ("FAILED".equals(e.status())) System.out.println("[Alert] PAYMENT FAILED: " + e.orderId()); });

        orderBus.publish(new OrderEvent("ORD-001", "PLACED",     99.99));
        orderBus.publish(new OrderEvent("ORD-002", "SHIPPED",    149.50));
        orderBus.publish(new OrderEvent("ORD-003", "FAILED",     0.0));

        System.out.println("\n=== Strategy ===");
        ShoppingCart cart = new ShoppingCart();
        cart.addItem(100.0, 15);  // bulk
        cart.addItem( 50.0,  2);

        for (PricingStrategy strategy : Pricing.values()) {
            cart.setStrategy(strategy);
            System.out.printf("%-12s → $%.2f%n", strategy, cart.checkout());
        }

        System.out.println("\n=== Decorator ===");
        TextProcessor pipeline = new PrefixDecorator(
            new UpperCaseDecorator(
                new TrimDecorator(
                    new PlainText())),
            "[PROCESSED] ");

        System.out.println(pipeline.process("  hello world from java  "));
    }
}