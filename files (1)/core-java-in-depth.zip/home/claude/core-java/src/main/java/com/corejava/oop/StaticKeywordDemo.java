package com.corejava.oop;

/**
 * TOPIC: static keyword — variables, methods, blocks, nested classes
 *
 * static = belongs to CLASS, not to any instance
 */
public class StaticKeywordDemo {

    // ── Static variable — shared across all instances ─────────────────────
    static class Employee {
        private static int totalEmployees = 0;  // class-level counter
        private static final String COMPANY = "TechCorp";  // constant

        private int id;
        private String name;
        private double salary;

        // ── Static block — runs once when class is loaded ─────────────────
        static {
            System.out.println("[Static Block] Employee class loaded.");
            System.out.println("[Static Block] Company: " + COMPANY);
        }

        // ── Instance block — runs before every constructor ─────────────────
        {
            totalEmployees++;
            this.id = totalEmployees;
            System.out.println("[Instance Block] Employee #" + id + " initializing...");
        }

        Employee(String name, double salary) {
            this.name   = name;
            this.salary = salary;
            System.out.println("[Constructor] Created: " + name);
        }

        // ── Static method — no 'this', no access to instance vars ─────────
        public static int getTotalEmployees() { return totalEmployees; }
        public static String getCompany()     { return COMPANY; }

        // ── Instance method ───────────────────────────────────────────────
        public void applyRaise(double percent) {
            salary *= (1 + percent / 100);
            System.out.printf("[%s] New salary: %.2f%n", name, salary);
        }

        @Override
        public String toString() {
            return String.format("Employee[#%d, %s, %.2f, %s]", id, name, salary, COMPANY);
        }
    }

    // ── Static nested class ───────────────────────────────────────────────
    static class Registry {
        static class Statistics {  // static nested — doesn't need Registry instance
            static void report() {
                System.out.println("Total employees: " + Employee.getTotalEmployees());
            }
        }
    }

    public static void main(String[] args) {
        System.out.println("=== Static Keyword Demo ===\n");

        System.out.println("Before creation. Total: " + Employee.getTotalEmployees());
        System.out.println();

        Employee e1 = new Employee("Alice", 75000);
        Employee e2 = new Employee("Bob",   80000);
        Employee e3 = new Employee("Carol", 90000);

        System.out.println();
        System.out.println("After creation. Total: " + Employee.getTotalEmployees());
        System.out.println(e1); System.out.println(e2); System.out.println(e3);

        e1.applyRaise(10);
        Registry.Statistics.report();

        System.out.println("\nCompany (via class): " + Employee.getCompany());
        System.out.println("Company (via instance — works but bad practice): " + e1.getCompany());
    }
}