# Crack The Coding Interview — Complete Java Guide

> **389+ Problems · 23 Topics · 10 Flow Diagrams · Full Java Solutions with Explanations**
>
> Sourced from the Crack The Coding Interview spreadsheet (Dinesh Varyani / DurgaNaresh Rasabattula)

---

## Flow Diagram Index

| # | Diagram | Topic |
|---|---------|-------|
| 00 | `diagrams/00_overview_chart.png` | Problem distribution by topic |
| 01 | `diagrams/01_array_patterns.png` | Array pattern decision tree |
| 02 | `diagrams/02_binary_search.png` | Binary search templates & variants |
| 03 | `diagrams/03_dp_patterns.png` | Dynamic programming classification |
| 04 | `diagrams/04_tree_graph.png` | Tree & graph traversal patterns |
| 05 | `diagrams/05_stack_queue_heap.png` | Stack, Queue, Heap patterns |
| 06 | `diagrams/06_backtracking.png` | Backtracking template & taxonomy |
| 07 | `diagrams/07_linked_list.png` | Linked list core techniques |
| 08 | `diagrams/08_bit_manipulation.png` | Bit manipulation tricks |
| 09 | `diagrams/09_master_cheatsheet.png` | Master interview cheat sheet |

---

## Pattern Recognition Quick Guide

| Problem Says | Pattern | Time | Space |
|-------------|---------|------|-------|
| Sorted array + find pair | Two Pointers | O(n) | O(1) |
| Subarray + fixed window K | Sliding Window | O(n) | O(k) |
| Subarray + sum query | Prefix Sum | O(n)+O(1) | O(n) |
| Any array + frequency | HashMap | O(n) | O(n) |
| Find in sorted array | Binary Search | O(log n) | O(1) |
| Tree + path sum | DFS recursion | O(n) | O(h) |
| Tree + level order | BFS + Queue | O(n) | O(w) |
| Shortest unweighted path | BFS | O(V+E) | O(V) |
| Overlapping subproblems | Dynamic Programming | O(n²) | O(n) |
| All combinations/subsets | Backtracking | O(2ⁿ) | O(n) |
| K smallest/largest | Min/Max Heap | O(n log k) | O(k) |
| Brackets/monotone | Stack | O(n) | O(n) |
| Graph connectivity | Union Find | O(n·α) | O(n) |

---

# SECTION 1 — ARRAY (868 Problems)

**Core Patterns:** Two Pointers, Sliding Window, HashMap, Prefix Sum, Sorting

> See diagram: `diagrams/01_array_patterns.png`

## Key Templates

```java
// ── Two Pointers (sorted array) ─────────────────────────────
int left = 0, right = arr.length - 1;
while (left < right) {
    int sum = arr[left] + arr[right];
    if (sum == target) { /* found */ }
    else if (sum < target) left++;
    else right--;
}

// ── Sliding Window (fixed size K) ───────────────────────────
int windowSum = 0;
for (int i = 0; i < k; i++) windowSum += arr[i];
int maxSum = windowSum;
for (int i = k; i < n; i++) {
    windowSum += arr[i] - arr[i-k];
    maxSum = Math.max(maxSum, windowSum);
}

// ── Prefix Sum ───────────────────────────────────────────────
int[] prefix = new int[n+1];
for (int i = 0; i < n; i++) prefix[i+1] = prefix[i] + arr[i];
// Range sum [l,r] = prefix[r+1] - prefix[l]

// ── HashMap counter ──────────────────────────────────────────
Map<Integer, Integer> freq = new HashMap<>();
for (int x : arr) freq.merge(x, 1, Integer::sum);
```

## Must-Know Array Problems

### A1. Two Sum — LeetCode #1 (Easy)
**Problem:** Find two indices such that `arr[i] + arr[j] == target`.

```java
import java.util.*;

public class TwoSum {
    // O(n) time, O(n) space — HashMap complement lookup
    public int[] twoSum(int[] nums, int target) {
        Map<Integer, Integer> seen = new HashMap<>();
        for (int i = 0; i < nums.length; i++) {
            int complement = target - nums[i];
            if (seen.containsKey(complement))
                return new int[]{seen.get(complement), i};
            seen.put(nums[i], i);
        }
        return new int[]{};
    }
    // Key insight: for each number, check if its complement was already seen
}
```

### A2. Maximum Subarray — LeetCode #53 (Easy) ⭐ Kadane's Algorithm
**Problem:** Find the contiguous subarray with the largest sum.

```java
public class MaximumSubarray {
    // Kadane's Algorithm — O(n) time, O(1) space
    public int maxSubArray(int[] nums) {
        int maxSum = nums[0], currentSum = nums[0];
        for (int i = 1; i < nums.length; i++) {
            // Either extend current subarray or start fresh
            currentSum = Math.max(nums[i], currentSum + nums[i]);
            maxSum    = Math.max(maxSum, currentSum);
        }
        return maxSum;
    }
    // Key: if currentSum becomes negative, reset to current element
}
```

### A3. Trapping Rain Water — LeetCode #42 (Hard) ⭐
**Problem:** Compute how much water can be trapped between bars.

```java
public class TrappingRainWater {
    // Two Pointer — O(n) time, O(1) space
    public int trap(int[] height) {
        int left = 0, right = height.length - 1;
        int leftMax = 0, rightMax = 0, water = 0;

        while (left < right) {
            if (height[left] < height[right]) {
                if (height[left] >= leftMax) leftMax = height[left];
                else water += leftMax - height[left];
                left++;
            } else {
                if (height[right] >= rightMax) rightMax = height[right];
                else water += rightMax - height[right];
                right--;
            }
        }
        return water;
    }
    // Key: water at position i = min(maxLeft, maxRight) - height[i]
}
```

### A4. 3Sum — LeetCode #15 (Medium) ⭐
**Problem:** Find all unique triplets summing to zero.

```java
import java.util.*;

public class ThreeSum {
    // Sort + Two Pointers — O(n²) time, O(1) space
    public List<List<Integer>> threeSum(int[] nums) {
        Arrays.sort(nums);
        List<List<Integer>> result = new ArrayList<>();

        for (int i = 0; i < nums.length - 2; i++) {
            if (i > 0 && nums[i] == nums[i-1]) continue; // skip duplicates
            if (nums[i] > 0) break; // no solution possible

            int lo = i+1, hi = nums.length-1;
            while (lo < hi) {
                int sum = nums[i] + nums[lo] + nums[hi];
                if (sum == 0) {
                    result.add(Arrays.asList(nums[i], nums[lo], nums[hi]));
                    while (lo < hi && nums[lo] == nums[lo+1]) lo++;
                    while (lo < hi && nums[hi] == nums[hi-1]) hi--;
                    lo++; hi--;
                } else if (sum < 0) lo++;
                else hi--;
            }
        }
        return result;
    }
}
```

### A5. Container With Most Water — LeetCode #11 (Medium) ⭐
```java
public class ContainerMostWater {
    // Two Pointers — O(n) time, O(1) space
    public int maxArea(int[] height) {
        int left = 0, right = height.length - 1, maxWater = 0;
        while (left < right) {
            maxWater = Math.max(maxWater,
                Math.min(height[left], height[right]) * (right - left));
            if (height[left] < height[right]) left++;
            else right--;
        }
        return maxWater;
    }
    // Key: always move the shorter wall (it's the bottleneck)
}
```

### A6. Best Time to Buy and Sell Stock — LeetCode #121 (Easy) ⭐
```java
public class BestTimeToBuyAndSellStock {
    // Single pass — O(n) time, O(1) space
    public int maxProfit(int[] prices) {
        int minPrice = Integer.MAX_VALUE, maxProfit = 0;
        for (int price : prices) {
            if (price < minPrice) minPrice = price;
            else maxProfit = Math.max(maxProfit, price - minPrice);
        }
        return maxProfit;
    }
}
```

### A7. Product of Array Except Self — LeetCode #238 (Medium) ⭐
```java
public class ProductExceptSelf {
    // Prefix + Suffix — O(n) time, O(1) extra space
    public int[] productExceptSelf(int[] nums) {
        int n = nums.length;
        int[] result = new int[n];
        result[0] = 1;
        for (int i = 1; i < n; i++)
            result[i] = result[i-1] * nums[i-1]; // prefix products
        int suffix = 1;
        for (int i = n-1; i >= 0; i--) {
            result[i] *= suffix;
            suffix *= nums[i]; // multiply suffix right-to-left
        }
        return result;
    }
}
```

### A8. Find Minimum in Rotated Sorted Array — LeetCode #153 (Medium)
```java
public class FindMinimumRotated {
    public int findMin(int[] nums) {
        int lo = 0, hi = nums.length - 1;
        while (lo < hi) {
            int mid = lo + (hi - lo) / 2;
            if (nums[mid] > nums[hi]) lo = mid + 1; // min in right half
            else hi = mid;                           // min in left half (includes mid)
        }
        return nums[lo];
    }
}
```

### A9. Search in Rotated Sorted Array — LeetCode #33 (Medium) ⭐
```java
public class SearchRotatedArray {
    public int search(int[] nums, int target) {
        int lo = 0, hi = nums.length - 1;
        while (lo <= hi) {
            int mid = lo + (hi - lo) / 2;
            if (nums[mid] == target) return mid;

            if (nums[lo] <= nums[mid]) { // left half is sorted
                if (target >= nums[lo] && target < nums[mid]) hi = mid - 1;
                else lo = mid + 1;
            } else { // right half is sorted
                if (target > nums[mid] && target <= nums[hi]) lo = mid + 1;
                else hi = mid - 1;
            }
        }
        return -1;
    }
}
```

### A10. Merge Intervals — LeetCode #56 (Medium) ⭐
```java
import java.util.*;

public class MergeIntervals {
    public int[][] merge(int[][] intervals) {
        Arrays.sort(intervals, (a, b) -> a[0] - b[0]);
        List<int[]> merged = new ArrayList<>();
        for (int[] interval : intervals) {
            if (merged.isEmpty() || merged.get(merged.size()-1)[1] < interval[0])
                merged.add(interval);
            else
                merged.get(merged.size()-1)[1] = Math.max(merged.get(merged.size()-1)[1], interval[1]);
        }
        return merged.toArray(new int[0][]);
    }
}
```

### A11. Find the Duplicate Number — LeetCode #287 (Medium) ⭐
```java
public class FindDuplicateNumber {
    // Floyd's cycle detection — O(n) time, O(1) space
    public int findDuplicate(int[] nums) {
        int slow = nums[0], fast = nums[0];
        do { slow = nums[slow]; fast = nums[nums[fast]]; } while (slow != fast);
        slow = nums[0];
        while (slow != fast) { slow = nums[slow]; fast = nums[fast]; }
        return slow;
    }
}
```

### A12. Jump Game — LeetCode #55 (Medium) ⭐ Greedy
```java
public class JumpGame {
    public boolean canJump(int[] nums) {
        int maxReach = 0;
        for (int i = 0; i < nums.length; i++) {
            if (i > maxReach) return false; // can't reach this position
            maxReach = Math.max(maxReach, i + nums[i]);
        }
        return true;
    }
}
```

### A13. Maximum Product Subarray — LeetCode #152 (Medium) ⭐
```java
public class MaximumProductSubarray {
    public int maxProduct(int[] nums) {
        int max = nums[0], min = nums[0], result = nums[0];
        for (int i = 1; i < nums.length; i++) {
            int temp = max;
            max = Math.max(nums[i], Math.max(max * nums[i], min * nums[i]));
            min = Math.min(nums[i], Math.min(temp * nums[i], min * nums[i]));
            result = Math.max(result, max);
        }
        return result;
    }
    // Key: track both max and min because negative * negative = positive
}
```

### A14. Rotate Array — LeetCode #189 (Medium)
```java
public class RotateArray {
    // Reverse approach — O(n) time, O(1) space
    public void rotate(int[] nums, int k) {
        k %= nums.length;
        reverse(nums, 0, nums.length-1);
        reverse(nums, 0, k-1);
        reverse(nums, k, nums.length-1);
    }
    private void reverse(int[] nums, int lo, int hi) {
        while (lo < hi) { int t=nums[lo]; nums[lo++]=nums[hi]; nums[hi--]=t; }
    }
}
```

### A15. Subarray Sum Equals K — LeetCode #560 (Medium) ⭐⭐
```java
import java.util.*;

public class SubarraySumEqualsK {
    // Prefix sum + HashMap — O(n) time, O(n) space
    public int subarraySum(int[] nums, int k) {
        Map<Integer, Integer> prefixCount = new HashMap<>();
        prefixCount.put(0, 1); // empty prefix
        int count = 0, sum = 0;
        for (int num : nums) {
            sum += num;
            // If (sum - k) was seen, that many subarrays end here with sum k
            count += prefixCount.getOrDefault(sum - k, 0);
            prefixCount.merge(sum, 1, Integer::sum);
        }
        return count;
    }
}
```

---

# SECTION 2 — STRING (420 Problems)

**Core Patterns:** Sliding Window, HashMap frequency, Two Pointers, KMP matching

## Key Templates

```java
// ── Anagram / Permutation check (fixed window) ──────────────
int[] freq = new int[26];
for (char c : t.toCharArray()) freq[c-'a']++;
int k = t.length();
for (int i = 0; i < k; i++) freq[s.charAt(i)-'a']--;
for (int i = k; i < s.length(); i++) {
    if (Arrays.equals(freq, new int[26])) count++;
    freq[s.charAt(i)-'a']--;
    freq[s.charAt(i-k)-'a']++;
}

// ── Palindrome check ─────────────────────────────────────────
boolean isPalindrome(String s) {
    int lo = 0, hi = s.length()-1;
    while (lo < hi) {
        if (s.charAt(lo++) != s.charAt(hi--)) return false;
    }
    return true;
}
```

### S1. Longest Substring Without Repeating — LeetCode #3 (Medium) ⭐⭐
```java
import java.util.*;

public class LongestSubstringNoRepeat {
    public int lengthOfLongestSubstring(String s) {
        Map<Character, Integer> lastSeen = new HashMap<>();
        int left = 0, maxLen = 0;
        for (int right = 0; right < s.length(); right++) {
            char c = s.charAt(right);
            if (lastSeen.containsKey(c) && lastSeen.get(c) >= left)
                left = lastSeen.get(c) + 1;
            lastSeen.put(c, right);
            maxLen = Math.max(maxLen, right - left + 1);
        }
        return maxLen;
    }
}
```

### S2. Longest Palindromic Substring — LeetCode #5 (Medium) ⭐⭐
```java
public class LongestPalindromicSubstring {
    // Expand around center — O(n²) time, O(1) space
    public String longestPalindrome(String s) {
        int start = 0, maxLen = 1;
        for (int i = 0; i < s.length(); i++) {
            int len1 = expand(s, i, i);       // odd length
            int len2 = expand(s, i, i+1);     // even length
            int len  = Math.max(len1, len2);
            if (len > maxLen) { maxLen = len; start = i - (len-1)/2; }
        }
        return s.substring(start, start + maxLen);
    }
    private int expand(String s, int lo, int hi) {
        while (lo >= 0 && hi < s.length() && s.charAt(lo) == s.charAt(hi)) { lo--; hi++; }
        return hi - lo - 1;
    }
}
```

### S3. Valid Anagram — LeetCode #242 (Easy)
```java
import java.util.*;

public class ValidAnagram {
    public boolean isAnagram(String s, String t) {
        if (s.length() != t.length()) return false;
        int[] freq = new int[26];
        for (char c : s.toCharArray()) freq[c-'a']++;
        for (char c : t.toCharArray()) { if (--freq[c-'a'] < 0) return false; }
        return true;
    }
}
```

### S4. Group Anagrams — LeetCode #49 (Medium) ⭐
```java
import java.util.*;

public class GroupAnagrams {
    public List<List<String>> groupAnagrams(String[] strs) {
        Map<String, List<String>> map = new HashMap<>();
        for (String s : strs) {
            char[] arr = s.toCharArray();
            Arrays.sort(arr);
            String key = new String(arr);
            map.computeIfAbsent(key, k -> new ArrayList<>()).add(s);
        }
        return new ArrayList<>(map.values());
    }
}
```

### S5. Minimum Window Substring — LeetCode #76 (Hard) ⭐⭐
```java
import java.util.*;

public class MinimumWindowSubstring {
    public String minWindow(String s, String t) {
        Map<Character, Integer> need = new HashMap<>();
        for (char c : t.toCharArray()) need.merge(c, 1, Integer::sum);
        int left = 0, formed = 0, required = need.size();
        Map<Character, Integer> window = new HashMap<>();
        int[] ans = {-1, 0, 0};

        for (int right = 0; right < s.length(); right++) {
            char c = s.charAt(right);
            window.merge(c, 1, Integer::sum);
            if (need.containsKey(c) && window.get(c).equals(need.get(c))) formed++;

            while (formed == required) {
                if (ans[0] == -1 || right-left+1 < ans[0]) { ans[0]=right-left+1; ans[1]=left; ans[2]=right; }
                char lc = s.charAt(left++);
                window.put(lc, window.get(lc)-1);
                if (need.containsKey(lc) && window.get(lc) < need.get(lc)) formed--;
            }
        }
        return ans[0] == -1 ? "" : s.substring(ans[1], ans[2]+1);
    }
}
```

### S6. Valid Parentheses — LeetCode #20 (Easy) ⭐
```java
import java.util.*;

public class ValidParentheses {
    public boolean isValid(String s) {
        Deque<Character> stack = new ArrayDeque<>();
        for (char c : s.toCharArray()) {
            if (c=='(' || c=='[' || c=='{') stack.push(c);
            else {
                if (stack.isEmpty()) return false;
                char top = stack.pop();
                if (c==')' && top!='(') return false;
                if (c==']' && top!='[') return false;
                if (c=='}' && top!='{') return false;
            }
        }
        return stack.isEmpty();
    }
}
```

### S7. Palindrome Partitioning — LeetCode #131 (Medium)
```java
import java.util.*;

public class PalindromePartitioning {
    public List<List<String>> partition(String s) {
        List<List<String>> result = new ArrayList<>();
        backtrack(result, new ArrayList<>(), s, 0);
        return result;
    }
    private void backtrack(List<List<String>> result, List<String> path, String s, int start) {
        if (start == s.length()) { result.add(new ArrayList<>(path)); return; }
        for (int end = start+1; end <= s.length(); end++) {
            String sub = s.substring(start, end);
            if (isPalin(sub)) { path.add(sub); backtrack(result, path, s, end); path.remove(path.size()-1); }
        }
    }
    private boolean isPalin(String s) {
        int lo=0, hi=s.length()-1;
        while(lo<hi) { if(s.charAt(lo++)!=s.charAt(hi--)) return false; }
        return true;
    }
}
```

### S8. Implement strStr() — LeetCode #28 (Easy) — KMP Algorithm
```java
public class StrStr {
    // KMP — O(n+m) time, O(m) space
    public int strStr(String haystack, String needle) {
        if (needle.isEmpty()) return 0;
        int[] lps = computeLPS(needle);
        int i = 0, j = 0;
        while (i < haystack.length()) {
            if (haystack.charAt(i) == needle.charAt(j)) { i++; j++; }
            if (j == needle.length()) return i - j;
            else if (i < haystack.length() && haystack.charAt(i) != needle.charAt(j)) {
                if (j != 0) j = lps[j-1];
                else i++;
            }
        }
        return -1;
    }
    private int[] computeLPS(String p) {
        int[] lps = new int[p.length()];
        int len = 0, i = 1;
        while (i < p.length()) {
            if (p.charAt(i) == p.charAt(len)) { lps[i++] = ++len; }
            else if (len != 0) len = lps[len-1];
            else lps[i++] = 0;
        }
        return lps;
    }
}
```

---

# SECTION 3 — DYNAMIC PROGRAMMING (313 Problems)

**Core Patterns:** 1D DP, 2D DP, Interval DP, Knapsack

> See diagram: `diagrams/03_dp_patterns.png`

## DP Master Template

```java
// STEP 1: Define state — what does dp[i] represent?
// STEP 2: Write recurrence — how does dp[i] relate to previous?
// STEP 3: Base cases — what are dp[0], dp[1]?
// STEP 4: Traversal order — forward, backward, or diagonal?
// STEP 5: Answer — is it dp[n], dp[n-1], or max of dp[*]?
```

### DP1. Climbing Stairs — LeetCode #70 (Easy) ⭐
```java
public class ClimbingStairs {
    // dp[i] = ways to reach step i = dp[i-1] + dp[i-2]
    public int climbStairs(int n) {
        if (n <= 2) return n;
        int prev2 = 1, prev1 = 2;
        for (int i = 3; i <= n; i++) { int cur = prev1+prev2; prev2=prev1; prev1=cur; }
        return prev1;
    }
}
```

### DP2. House Robber — LeetCode #198 (Medium) ⭐
```java
public class HouseRobber {
    // dp[i] = max money from first i houses
    public int rob(int[] nums) {
        if (nums.length == 1) return nums[0];
        int prev2 = nums[0], prev1 = Math.max(nums[0], nums[1]);
        for (int i = 2; i < nums.length; i++) {
            int cur = Math.max(prev1, prev2 + nums[i]);
            prev2 = prev1; prev1 = cur;
        }
        return prev1;
    }
}
```

### DP3. Coin Change — LeetCode #322 (Medium) ⭐⭐
```java
import java.util.*;

public class CoinChange {
    // dp[amount] = min coins to make amount
    public int coinChange(int[] coins, int amount) {
        int[] dp = new int[amount+1];
        Arrays.fill(dp, amount+1); // infinity
        dp[0] = 0;
        for (int i = 1; i <= amount; i++)
            for (int coin : coins)
                if (coin <= i) dp[i] = Math.min(dp[i], dp[i-coin]+1);
        return dp[amount] > amount ? -1 : dp[amount];
    }
}
```

### DP4. Longest Common Subsequence — LeetCode #1143 (Medium) ⭐⭐
```java
public class LongestCommonSubsequence {
    // dp[i][j] = LCS of text1[0..i-1] and text2[0..j-1]
    public int longestCommonSubsequence(String text1, String text2) {
        int m = text1.length(), n = text2.length();
        int[][] dp = new int[m+1][n+1];
        for (int i = 1; i <= m; i++)
            for (int j = 1; j <= n; j++)
                dp[i][j] = text1.charAt(i-1)==text2.charAt(j-1)
                    ? dp[i-1][j-1]+1 : Math.max(dp[i-1][j], dp[i][j-1]);
        return dp[m][n];
    }
}
```

### DP5. Longest Increasing Subsequence — LeetCode #300 (Medium) ⭐⭐
```java
import java.util.*;

public class LongestIncreasingSubsequence {
    // Binary search + patience sorting — O(n log n)
    public int lengthOfLIS(int[] nums) {
        List<Integer> tails = new ArrayList<>();
        for (int num : nums) {
            int lo = 0, hi = tails.size();
            while (lo < hi) {
                int mid = (lo+hi)/2;
                if (tails.get(mid) < num) lo = mid+1; else hi = mid;
            }
            if (lo == tails.size()) tails.add(num);
            else tails.set(lo, num);
        }
        return tails.size();
    }
}
```

### DP6. Edit Distance — LeetCode #72 (Hard) ⭐⭐
```java
public class EditDistance {
    // dp[i][j] = min operations to convert word1[0..i-1] to word2[0..j-1]
    public int minDistance(String word1, String word2) {
        int m = word1.length(), n = word2.length();
        int[][] dp = new int[m+1][n+1];
        for (int i=0;i<=m;i++) dp[i][0]=i;
        for (int j=0;j<=n;j++) dp[0][j]=j;
        for (int i=1;i<=m;i++)
            for (int j=1;j<=n;j++)
                dp[i][j] = word1.charAt(i-1)==word2.charAt(j-1)
                    ? dp[i-1][j-1]
                    : 1+Math.min(dp[i-1][j-1], Math.min(dp[i-1][j], dp[i][j-1]));
        return dp[m][n];
    }
}
```

### DP7. Best Time to Buy and Sell Stock with Cooldown — LeetCode #309 (Medium)
```java
public class StockCooldown {
    // State machine DP: hold, sold, rest
    public int maxProfit(int[] prices) {
        int hold = -prices[0], sold = 0, rest = 0;
        for (int i = 1; i < prices.length; i++) {
            int prevHold = hold, prevSold = sold, prevRest = rest;
            hold = Math.max(prevHold, prevRest - prices[i]);
            sold = prevHold + prices[i];
            rest = Math.max(prevRest, prevSold);
        }
        return Math.max(sold, rest);
    }
}
```

### DP8. Unique Paths — LeetCode #62 (Medium) ⭐
```java
public class UniquePaths {
    // 2D DP — dp[i][j] = paths to cell (i,j)
    public int uniquePaths(int m, int n) {
        int[] dp = new int[n];
        java.util.Arrays.fill(dp, 1);
        for (int i = 1; i < m; i++)
            for (int j = 1; j < n; j++)
                dp[j] += dp[j-1];
        return dp[n-1];
    }
}
```

### DP9. Word Break — LeetCode #139 (Medium) ⭐
```java
import java.util.*;

public class WordBreak {
    public boolean wordBreak(String s, List<String> wordDict) {
        Set<String> dict = new HashSet<>(wordDict);
        boolean[] dp = new boolean[s.length()+1];
        dp[0] = true;
        for (int i = 1; i <= s.length(); i++)
            for (int j = 0; j < i; j++)
                if (dp[j] && dict.contains(s.substring(j, i))) { dp[i]=true; break; }
        return dp[s.length()];
    }
}
```

### DP10. Partition Equal Subset Sum — LeetCode #416 (Medium) ⭐
```java
public class PartitionEqualSubsetSum {
    // 0/1 Knapsack variant
    public boolean canPartition(int[] nums) {
        int sum = 0;
        for (int n : nums) sum += n;
        if (sum % 2 != 0) return false;
        int target = sum / 2;
        boolean[] dp = new boolean[target+1];
        dp[0] = true;
        for (int num : nums)
            for (int j = target; j >= num; j--)
                dp[j] |= dp[j-num];
        return dp[target];
    }
}
```

---

# SECTION 4 — BINARY SEARCH (141 Problems)

> See diagram: `diagrams/02_binary_search.png`

### BS1. Binary Search — LeetCode #704 (Easy) ⭐
```java
public class BinarySearch {
    public int search(int[] nums, int target) {
        int lo = 0, hi = nums.length - 1;
        while (lo <= hi) {
            int mid = lo + (hi - lo) / 2; // avoid overflow
            if (nums[mid] == target) return mid;
            else if (nums[mid] < target) lo = mid + 1;
            else hi = mid - 1;
        }
        return -1;
    }
}
```

### BS2. Find First and Last Position — LeetCode #34 (Medium) ⭐
```java
public class FindFirstLastPosition {
    public int[] searchRange(int[] nums, int target) {
        return new int[]{findBound(nums,target,true), findBound(nums,target,false)};
    }
    private int findBound(int[] nums, int target, boolean findFirst) {
        int lo=0, hi=nums.length-1, bound=-1;
        while (lo<=hi) {
            int mid=lo+(hi-lo)/2;
            if (nums[mid]==target) { bound=mid; if (findFirst) hi=mid-1; else lo=mid+1; }
            else if (nums[mid]<target) lo=mid+1;
            else hi=mid-1;
        }
        return bound;
    }
}
```

### BS3. Search a 2D Matrix — LeetCode #74 (Medium) ⭐
```java
public class SearchMatrix {
    public boolean searchMatrix(int[][] matrix, int target) {
        int m=matrix.length, n=matrix[0].length, lo=0, hi=m*n-1;
        while (lo<=hi) {
            int mid=lo+(hi-lo)/2, val=matrix[mid/n][mid%n];
            if (val==target) return true;
            else if (val<target) lo=mid+1;
            else hi=mid-1;
        }
        return false;
    }
}
```

### BS4. Kth Smallest Element in Sorted Matrix — LeetCode #378 (Medium) ⭐
```java
public class KthSmallestInMatrix {
    // Binary search on value range — O(n log(max-min))
    public int kthSmallest(int[][] matrix, int k) {
        int n=matrix.length, lo=matrix[0][0], hi=matrix[n-1][n-1];
        while (lo<hi) {
            int mid=lo+(hi-lo)/2, count=countLE(matrix,mid,n);
            if (count<k) lo=mid+1; else hi=mid;
        }
        return lo;
    }
    private int countLE(int[][] m, int mid, int n) {
        int row=n-1, col=0, count=0;
        while (row>=0 && col<n) {
            if (m[row][col]<=mid) { count+=row+1; col++; } else row--;
        }
        return count;
    }
}
```

### BS5. Find Peak Element — LeetCode #162 (Medium) ⭐
```java
public class FindPeakElement {
    public int findPeakElement(int[] nums) {
        int lo=0, hi=nums.length-1;
        while (lo<hi) {
            int mid=lo+(hi-lo)/2;
            if (nums[mid]>nums[mid+1]) hi=mid;
            else lo=mid+1;
        }
        return lo;
    }
}
```

---

# SECTION 5 — TREE & BINARY TREE (136 + 116 Problems)

> See diagram: `diagrams/04_tree_graph.png`

```java
// TreeNode definition
class TreeNode { int val; TreeNode left, right; TreeNode(int v) { val=v; } }
```

### T1. Maximum Depth of Binary Tree — LeetCode #104 (Easy) ⭐
```java
public class MaxDepth {
    public int maxDepth(TreeNode root) {
        if (root == null) return 0;
        return 1 + Math.max(maxDepth(root.left), maxDepth(root.right));
    }
}
```

### T2. Invert Binary Tree — LeetCode #226 (Easy) ⭐
```java
public class InvertBinaryTree {
    public TreeNode invertTree(TreeNode root) {
        if (root == null) return null;
        TreeNode temp = root.left;
        root.left  = invertTree(root.right);
        root.right = invertTree(temp);
        return root;
    }
}
```

### T3. Level Order Traversal — LeetCode #102 (Medium) ⭐⭐
```java
import java.util.*;

public class LevelOrderTraversal {
    public List<List<Integer>> levelOrder(TreeNode root) {
        List<List<Integer>> result = new ArrayList<>();
        if (root == null) return result;
        Queue<TreeNode> q = new LinkedList<>();
        q.offer(root);
        while (!q.isEmpty()) {
            int size = q.size();
            List<Integer> level = new ArrayList<>();
            for (int i = 0; i < size; i++) {
                TreeNode node = q.poll();
                level.add(node.val);
                if (node.left  != null) q.offer(node.left);
                if (node.right != null) q.offer(node.right);
            }
            result.add(level);
        }
        return result;
    }
}
```

### T4. Binary Tree Maximum Path Sum — LeetCode #124 (Hard) ⭐⭐
```java
public class MaxPathSum {
    private int maxSum = Integer.MIN_VALUE;
    public int maxPathSum(TreeNode root) {
        dfs(root);
        return maxSum;
    }
    private int dfs(TreeNode node) {
        if (node == null) return 0;
        int left  = Math.max(0, dfs(node.left));
        int right = Math.max(0, dfs(node.right));
        maxSum = Math.max(maxSum, node.val + left + right); // path through node
        return node.val + Math.max(left, right); // return max single path
    }
}
```

### T5. Validate Binary Search Tree — LeetCode #98 (Medium) ⭐
```java
public class ValidateBST {
    public boolean isValidBST(TreeNode root) {
        return validate(root, Long.MIN_VALUE, Long.MAX_VALUE);
    }
    private boolean validate(TreeNode node, long min, long max) {
        if (node == null) return true;
        if (node.val <= min || node.val >= max) return false;
        return validate(node.left, min, node.val) && validate(node.right, node.val, max);
    }
}
```

### T6. Lowest Common Ancestor — LeetCode #236 (Medium) ⭐⭐
```java
public class LowestCommonAncestor {
    public TreeNode lowestCommonAncestor(TreeNode root, TreeNode p, TreeNode q) {
        if (root == null || root == p || root == q) return root;
        TreeNode left  = lowestCommonAncestor(root.left,  p, q);
        TreeNode right = lowestCommonAncestor(root.right, p, q);
        if (left != null && right != null) return root; // p and q on opposite sides
        return left != null ? left : right;
    }
}
```

### T7. Diameter of Binary Tree — LeetCode #543 (Easy) ⭐
```java
public class DiameterBinaryTree {
    private int diameter = 0;
    public int diameterOfBinaryTree(TreeNode root) {
        depth(root);
        return diameter;
    }
    private int depth(TreeNode node) {
        if (node == null) return 0;
        int left = depth(node.left), right = depth(node.right);
        diameter = Math.max(diameter, left + right);
        return 1 + Math.max(left, right);
    }
}
```

### T8. Serialize and Deserialize Binary Tree — LeetCode #297 (Hard) ⭐
```java
import java.util.*;

public class SerializeDeserialize {
    public String serialize(TreeNode root) {
        if (root == null) return "null";
        return root.val + "," + serialize(root.left) + "," + serialize(root.right);
    }

    public TreeNode deserialize(String data) {
        Queue<String> q = new LinkedList<>(Arrays.asList(data.split(",")));
        return build(q);
    }

    private TreeNode build(Queue<String> q) {
        String val = q.poll();
        if ("null".equals(val)) return null;
        TreeNode node = new TreeNode(Integer.parseInt(val));
        node.left  = build(q);
        node.right = build(q);
        return node;
    }
}
```

---

# SECTION 6 — GRAPH (68 Problems)

> See diagram: `diagrams/04_tree_graph.png`

### G1. Number of Islands — LeetCode #200 (Medium) ⭐⭐
```java
public class NumberOfIslands {
    public int numIslands(char[][] grid) {
        int count = 0;
        for (int r = 0; r < grid.length; r++)
            for (int c = 0; c < grid[0].length; c++)
                if (grid[r][c] == '1') { dfs(grid, r, c); count++; }
        return count;
    }
    private void dfs(char[][] grid, int r, int c) {
        if (r<0||r>=grid.length||c<0||c>=grid[0].length||grid[r][c]!='1') return;
        grid[r][c] = '0'; // mark visited
        dfs(grid,r+1,c); dfs(grid,r-1,c); dfs(grid,r,c+1); dfs(grid,r,c-1);
    }
}
```

### G2. Clone Graph — LeetCode #133 (Medium) ⭐
```java
import java.util.*;

class Node { int val; List<Node> neighbors = new ArrayList<>(); Node(int v){val=v;} }

public class CloneGraph {
    Map<Node, Node> cloned = new HashMap<>();
    public Node cloneGraph(Node node) {
        if (node == null) return null;
        if (cloned.containsKey(node)) return cloned.get(node);
        Node clone = new Node(node.val);
        cloned.put(node, clone);
        for (Node nb : node.neighbors) clone.neighbors.add(cloneGraph(nb));
        return clone;
    }
}
```

### G3. Course Schedule — LeetCode #207 (Medium) ⭐⭐ Topological Sort
```java
import java.util.*;

public class CourseSchedule {
    public boolean canFinish(int numCourses, int[][] prerequisites) {
        int[] inDegree = new int[numCourses];
        List<List<Integer>> adj = new ArrayList<>();
        for (int i=0;i<numCourses;i++) adj.add(new ArrayList<>());
        for (int[] pre : prerequisites) { adj.get(pre[1]).add(pre[0]); inDegree[pre[0]]++; }

        Queue<Integer> q = new LinkedList<>();
        for (int i=0;i<numCourses;i++) if (inDegree[i]==0) q.offer(i);

        int count = 0;
        while (!q.isEmpty()) {
            int course = q.poll(); count++;
            for (int next : adj.get(course)) if (--inDegree[next]==0) q.offer(next);
        }
        return count == numCourses;
    }
}
```

### G4. Word Ladder — LeetCode #127 (Hard) ⭐⭐ BFS
```java
import java.util.*;

public class WordLadder {
    public int ladderLength(String beginWord, String endWord, List<String> wordList) {
        Set<String> dict = new HashSet<>(wordList);
        if (!dict.contains(endWord)) return 0;
        Queue<String> q = new LinkedList<>();
        q.offer(beginWord); dict.remove(beginWord);
        int steps = 1;
        while (!q.isEmpty()) {
            steps++;
            for (int sz = q.size(); sz > 0; sz--) {
                char[] word = q.poll().toCharArray();
                for (int i=0;i<word.length;i++) {
                    char orig = word[i];
                    for (char c='a';c<='z';c++) {
                        word[i]=c; String next=new String(word);
                        if (dict.contains(next)) {
                            if (next.equals(endWord)) return steps;
                            q.offer(next); dict.remove(next);
                        }
                    }
                    word[i]=orig;
                }
            }
        }
        return 0;
    }
}
```

---

# SECTION 7 — LINKED LIST (57 Problems)

> See diagram: `diagrams/07_linked_list.png`

```java
class ListNode { int val; ListNode next; ListNode(int v) { val=v; } }
```

### L1. Reverse Linked List — LeetCode #206 (Easy) ⭐⭐
```java
public class ReverseLinkedList {
    // Iterative — O(n) time, O(1) space
    public ListNode reverseList(ListNode head) {
        ListNode prev = null, curr = head;
        while (curr != null) {
            ListNode next = curr.next;
            curr.next = prev;
            prev = curr;
            curr = next;
        }
        return prev;
    }
}
```

### L2. Linked List Cycle — LeetCode #141 (Easy) ⭐ Floyd's Algorithm
```java
public class LinkedListCycle {
    public boolean hasCycle(ListNode head) {
        ListNode slow = head, fast = head;
        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
            if (slow == fast) return true; // cycle detected!
        }
        return false;
    }
}
```

### L3. Merge Two Sorted Lists — LeetCode #21 (Easy) ⭐
```java
public class MergeTwoSortedLists {
    public ListNode mergeTwoLists(ListNode l1, ListNode l2) {
        ListNode dummy = new ListNode(0), curr = dummy;
        while (l1 != null && l2 != null) {
            if (l1.val <= l2.val) { curr.next=l1; l1=l1.next; }
            else { curr.next=l2; l2=l2.next; }
            curr=curr.next;
        }
        curr.next = l1 != null ? l1 : l2;
        return dummy.next;
    }
}
```

### L4. Remove Nth Node From End — LeetCode #19 (Medium) ⭐
```java
public class RemoveNthFromEnd {
    public ListNode removeNthFromEnd(ListNode head, int n) {
        ListNode dummy = new ListNode(0); dummy.next = head;
        ListNode fast = dummy, slow = dummy;
        for (int i=0;i<=n;i++) fast=fast.next; // fast starts n+1 ahead
        while (fast!=null) { slow=slow.next; fast=fast.next; }
        slow.next = slow.next.next;
        return dummy.next;
    }
}
```

### L5. Merge K Sorted Lists — LeetCode #23 (Hard) ⭐⭐
```java
import java.util.*;

public class MergeKSortedLists {
    public ListNode mergeKLists(ListNode[] lists) {
        PriorityQueue<ListNode> pq = new PriorityQueue<>((a,b)->a.val-b.val);
        for (ListNode node : lists) if (node!=null) pq.offer(node);
        ListNode dummy = new ListNode(0), curr = dummy;
        while (!pq.isEmpty()) {
            curr.next = pq.poll();
            curr = curr.next;
            if (curr.next != null) pq.offer(curr.next);
        }
        return dummy.next;
    }
}
```

---

# SECTION 8 — STACK (106 Problems)

> See diagram: `diagrams/05_stack_queue_heap.png`

### ST1. Min Stack — LeetCode #155 (Medium) ⭐
```java
import java.util.*;

public class MinStack {
    private Deque<Integer> stack = new ArrayDeque<>();
    private Deque<Integer> minStack = new ArrayDeque<>();

    public void push(int val) {
        stack.push(val);
        if (minStack.isEmpty() || val <= minStack.peek())
            minStack.push(val);
    }
    public void pop() {
        if (stack.pop().equals(minStack.peek())) minStack.pop();
    }
    public int top()    { return stack.peek(); }
    public int getMin() { return minStack.peek(); }
}
```

### ST2. Daily Temperatures — LeetCode #739 (Medium) ⭐ Monotonic Stack
```java
import java.util.*;

public class DailyTemperatures {
    public int[] dailyTemperatures(int[] temperatures) {
        int n = temperatures.length;
        int[] result = new int[n];
        Deque<Integer> stack = new ArrayDeque<>(); // stores indices

        for (int i = 0; i < n; i++) {
            // Pop elements that found their warmer day
            while (!stack.isEmpty() && temperatures[i] > temperatures[stack.peek()]) {
                int prev = stack.pop();
                result[prev] = i - prev;
            }
            stack.push(i);
        }
        return result;
    }
}
```

### ST3. Largest Rectangle in Histogram — LeetCode #84 (Hard) ⭐⭐
```java
import java.util.*;

public class LargestRectangleHistogram {
    public int largestRectangleArea(int[] heights) {
        int n = heights.length;
        int[] extended = new int[n+2]; // sentinel 0s at both ends
        System.arraycopy(heights, 0, extended, 1, n);
        Deque<Integer> stack = new ArrayDeque<>();
        int maxArea = 0;

        for (int i = 0; i < extended.length; i++) {
            while (!stack.isEmpty() && extended[i] < extended[stack.peek()]) {
                int height = extended[stack.pop()];
                int width  = i - stack.peek() - 1;
                maxArea = Math.max(maxArea, height * width);
            }
            stack.push(i);
        }
        return maxArea;
    }
}
```

### ST4. Decode String — LeetCode #394 (Medium) ⭐
```java
import java.util.*;

public class DecodeString {
    public String decodeString(String s) {
        Deque<Integer> counts = new ArrayDeque<>();
        Deque<StringBuilder> strings = new ArrayDeque<>();
        StringBuilder curr = new StringBuilder();
        int k = 0;

        for (char c : s.toCharArray()) {
            if (Character.isDigit(c)) {
                k = k*10 + (c-'0');
            } else if (c == '[') {
                counts.push(k); k=0;
                strings.push(curr); curr = new StringBuilder();
            } else if (c == ']') {
                int times = counts.pop();
                StringBuilder repeated = strings.pop();
                for (int i=0;i<times;i++) repeated.append(curr);
                curr = repeated;
            } else {
                curr.append(c);
            }
        }
        return curr.toString();
    }
}
```

---

# SECTION 9 — HEAP / PRIORITY QUEUE (91 Problems)

> See diagram: `diagrams/05_stack_queue_heap.png`

### H1. Kth Largest Element — LeetCode #215 (Medium) ⭐⭐
```java
import java.util.*;

public class KthLargestElement {
    // Min-heap of size k — O(n log k) time, O(k) space
    public int findKthLargest(int[] nums, int k) {
        PriorityQueue<Integer> heap = new PriorityQueue<>(); // min-heap
        for (int num : nums) {
            heap.offer(num);
            if (heap.size() > k) heap.poll(); // remove smallest
        }
        return heap.peek(); // kth largest
    }
}
```

### H2. Top K Frequent Elements — LeetCode #347 (Medium) ⭐⭐
```java
import java.util.*;

public class TopKFrequent {
    public int[] topKFrequent(int[] nums, int k) {
        Map<Integer, Integer> freq = new HashMap<>();
        for (int n : nums) freq.merge(n, 1, Integer::sum);

        PriorityQueue<Integer> heap = new PriorityQueue<>((a,b)->freq.get(a)-freq.get(b));
        for (int n : freq.keySet()) {
            heap.offer(n);
            if (heap.size() > k) heap.poll();
        }
        int[] result = new int[k];
        for (int i=k-1;i>=0;i--) result[i] = heap.poll();
        return result;
    }
}
```

### H3. Find Median from Data Stream — LeetCode #295 (Hard) ⭐⭐
```java
import java.util.*;

public class MedianFinder {
    PriorityQueue<Integer> lo = new PriorityQueue<>(Collections.reverseOrder()); // max-heap
    PriorityQueue<Integer> hi = new PriorityQueue<>(); // min-heap

    public void addNum(int num) {
        lo.offer(num);
        hi.offer(lo.poll());
        if (lo.size() < hi.size()) lo.offer(hi.poll());
    }

    public double findMedian() {
        return lo.size() > hi.size() ? lo.peek() : ((double)lo.peek()+hi.peek())/2;
    }
}
```

---

# SECTION 10 — BACKTRACKING (75 Problems)

> See diagram: `diagrams/06_backtracking.png`

### BT1. Subsets — LeetCode #78 (Medium) ⭐⭐
```java
import java.util.*;

public class Subsets {
    public List<List<Integer>> subsets(int[] nums) {
        List<List<Integer>> result = new ArrayList<>();
        backtrack(result, new ArrayList<>(), nums, 0);
        return result;
    }
    private void backtrack(List<List<Integer>> result, List<Integer> path, int[] nums, int start) {
        result.add(new ArrayList<>(path)); // add current subset
        for (int i=start;i<nums.length;i++) {
            path.add(nums[i]);
            backtrack(result, path, nums, i+1);
            path.remove(path.size()-1);
        }
    }
}
```

### BT2. Permutations — LeetCode #46 (Medium) ⭐⭐
```java
import java.util.*;

public class Permutations {
    public List<List<Integer>> permute(int[] nums) {
        List<List<Integer>> result = new ArrayList<>();
        boolean[] used = new boolean[nums.length];
        backtrack(result, new ArrayList<>(), nums, used);
        return result;
    }
    private void backtrack(List<List<Integer>> result, List<Integer> path, int[] nums, boolean[] used) {
        if (path.size()==nums.length) { result.add(new ArrayList<>(path)); return; }
        for (int i=0;i<nums.length;i++) {
            if (!used[i]) {
                used[i]=true; path.add(nums[i]);
                backtrack(result, path, nums, used);
                used[i]=false; path.remove(path.size()-1);
            }
        }
    }
}
```

### BT3. N-Queens — LeetCode #51 (Hard) ⭐⭐
```java
import java.util.*;

public class NQueens {
    public List<List<String>> solveNQueens(int n) {
        List<List<String>> result = new ArrayList<>();
        char[][] board = new char[n][n];
        for (char[] row : board) Arrays.fill(row, '.');
        backtrack(result, board, 0, n);
        return result;
    }
    private void backtrack(List<List<String>> result, char[][] board, int row, int n) {
        if (row==n) {
            List<String> solution = new ArrayList<>();
            for (char[] r : board) solution.add(new String(r));
            result.add(solution); return;
        }
        for (int col=0;col<n;col++) {
            if (isValid(board,row,col,n)) {
                board[row][col]='Q';
                backtrack(result, board, row+1, n);
                board[row][col]='.';
            }
        }
    }
    private boolean isValid(char[][] board, int row, int col, int n) {
        for (int i=0;i<row;i++) {
            if (board[i][col]=='Q') return false;
            if (col-row+i>=0 && board[i][col-row+i]=='Q') return false;
            if (col+row-i<n  && board[i][col+row-i]=='Q') return false;
        }
        return true;
    }
}
```

---

# SECTION 11 — BIT MANIPULATION (118 Problems)

> See diagram: `diagrams/08_bit_manipulation.png`

### BM1. Single Number — LeetCode #136 (Easy) ⭐
```java
public class SingleNumber {
    // XOR trick: a ^ a = 0, 0 ^ b = b
    public int singleNumber(int[] nums) {
        int result = 0;
        for (int n : nums) result ^= n;
        return result;
    }
}
```

### BM2. Number of 1 Bits — LeetCode #191 (Easy) ⭐ Brian Kernighan
```java
public class NumberOf1Bits {
    public int hammingWeight(int n) {
        int count = 0;
        while (n != 0) {
            n &= (n-1); // removes lowest set bit
            count++;
        }
        return count;
    }
}
```

### BM3. Counting Bits — LeetCode #338 (Easy) ⭐
```java
public class CountingBits {
    // dp[i] = dp[i >> 1] + (i & 1)
    public int[] countBits(int n) {
        int[] dp = new int[n+1];
        for (int i=1;i<=n;i++) dp[i] = dp[i>>1] + (i&1);
        return dp;
    }
}
```

### BM4. Reverse Bits — LeetCode #190 (Easy)
```java
public class ReverseBits {
    public int reverseBits(int n) {
        int result = 0;
        for (int i=0;i<32;i++) {
            result = (result << 1) | (n & 1);
            n >>= 1;
        }
        return result;
    }
}
```

---

# SECTION 12 — UNION FIND (50 Problems)

### UF1. Union Find Template + Number of Provinces — LeetCode #547
```java
public class UnionFind {
    private int[] parent, rank;
    private int components;

    public UnionFind(int n) {
        parent = new int[n]; rank = new int[n]; components = n;
        for (int i=0;i<n;i++) parent[i]=i;
    }

    public int find(int x) {
        if (parent[x]!=x) parent[x]=find(parent[x]); // path compression
        return parent[x];
    }

    public boolean union(int x, int y) {
        int px=find(x), py=find(y);
        if (px==py) return false; // already connected
        if (rank[px]<rank[py]) { int t=px;px=py;py=t; }
        parent[py]=px;
        if (rank[px]==rank[py]) rank[px]++;
        components--;
        return true;
    }

    public int count() { return components; }

    // Problem: Number of Provinces
    public int findCircleNum(int[][] isConnected) {
        int n = isConnected.length;
        UnionFind uf = new UnionFind(n);
        for (int i=0;i<n;i++)
            for (int j=i+1;j<n;j++)
                if (isConnected[i][j]==1) uf.union(i,j);
        return uf.count();
    }
}
```

---

# SECTION 13 — TRIE (33 Problems)

### TR1. Implement Trie — LeetCode #208 (Medium) ⭐⭐
```java
public class Trie {
    private TrieNode root = new TrieNode();

    static class TrieNode {
        TrieNode[] children = new TrieNode[26];
        boolean isEnd;
    }

    public void insert(String word) {
        TrieNode curr = root;
        for (char c : word.toCharArray()) {
            if (curr.children[c-'a']==null) curr.children[c-'a']=new TrieNode();
            curr = curr.children[c-'a'];
        }
        curr.isEnd = true;
    }

    public boolean search(String word) {
        TrieNode node = find(word);
        return node != null && node.isEnd;
    }

    public boolean startsWith(String prefix) {
        return find(prefix) != null;
    }

    private TrieNode find(String s) {
        TrieNode curr = root;
        for (char c : s.toCharArray()) {
            if (curr.children[c-'a']==null) return null;
            curr = curr.children[c-'a'];
        }
        return curr;
    }
}
```

### TR2. Word Search II — LeetCode #212 (Hard) ⭐⭐ Trie + Backtracking
```java
import java.util.*;

public class WordSearchII {
    static class TrieNode { TrieNode[] ch=new TrieNode[26]; String word; }

    public List<String> findWords(char[][] board, String[] words) {
        TrieNode root = new TrieNode();
        for (String w : words) {
            TrieNode curr = root;
            for (char c : w.toCharArray()) {
                if (curr.ch[c-'a']==null) curr.ch[c-'a']=new TrieNode();
                curr=curr.ch[c-'a'];
            }
            curr.word = w;
        }

        List<String> result = new ArrayList<>();
        for (int r=0;r<board.length;r++)
            for (int c=0;c<board[0].length;c++)
                dfs(board,root,r,c,result);
        return result;
    }

    private void dfs(char[][] board, TrieNode node, int r, int c, List<String> result) {
        if (r<0||r>=board.length||c<0||c>=board[0].length||board[r][c]=='#') return;
        char ch=board[r][c];
        TrieNode next=node.ch[ch-'a'];
        if (next==null) return;
        if (next.word!=null) { result.add(next.word); next.word=null; }
        board[r][c]='#';
        dfs(board,next,r+1,c,result); dfs(board,next,r-1,c,result);
        dfs(board,next,r,c+1,result); dfs(board,next,r,c-1,result);
        board[r][c]=ch;
    }
}
```

---

# FULL PROBLEM LIST — MUST DO (Top 100)

> Sourced directly from the "Must Do Questions" sheet

| # | Problem | Difficulty | Topic |
|---|---------|-----------|-------|
| 1 | [Two Sum](https://leetcode.com/problems/two-sum) | Easy | Array |
| 2 | [Longest Substring Without Repeating](https://leetcode.com/problems/longest-substring-without-repeating-characters) | Medium | String |
| 3 | [Maximum Subarray](https://leetcode.com/problems/maximum-subarray) | Easy | Array |
| 4 | [Trapping Rain Water](https://leetcode.com/problems/trapping-rain-water) | Hard | Array |
| 5 | [Add Two Numbers](https://leetcode.com/problems/add-two-numbers) | Medium | Linked List |
| 6 | [3Sum](https://leetcode.com/problems/3sum) | Medium | Array |
| 7 | [Longest Palindromic Substring](https://leetcode.com/problems/longest-palindromic-substring) | Medium | String |
| 8 | [Median of Two Sorted Arrays](https://leetcode.com/problems/median-of-two-sorted-arrays) | Hard | Binary Search |
| 9 | [Container With Most Water](https://leetcode.com/problems/container-with-most-water) | Medium | Array |
| 10 | [Best Time to Buy and Sell Stock](https://leetcode.com/problems/best-time-to-buy-and-sell-stock) | Easy | DP |
| 11 | [Valid Parentheses](https://leetcode.com/problems/valid-parentheses) | Easy | Stack |
| 12 | [Merge Two Sorted Lists](https://leetcode.com/problems/merge-two-sorted-lists) | Easy | Linked List |
| 13 | [Maximum Depth of Binary Tree](https://leetcode.com/problems/maximum-depth-of-binary-tree) | Easy | Tree |
| 14 | [Binary Tree Inorder Traversal](https://leetcode.com/problems/binary-tree-inorder-traversal) | Easy | Tree |
| 15 | [Climbing Stairs](https://leetcode.com/problems/climbing-stairs) | Easy | DP |
| 16 | [Search in Rotated Sorted Array](https://leetcode.com/problems/search-in-rotated-sorted-array) | Medium | Binary Search |
| 17 | [Coin Change](https://leetcode.com/problems/coin-change) | Medium | DP |
| 18 | [Number of Islands](https://leetcode.com/problems/number-of-islands) | Medium | Graph |
| 19 | [Product of Array Except Self](https://leetcode.com/problems/product-of-array-except-self) | Medium | Array |
| 20 | [Reverse Linked List](https://leetcode.com/problems/reverse-linked-list) | Easy | Linked List |
| 21 | [Word Search](https://leetcode.com/problems/word-search) | Medium | Backtracking |
| 22 | [Merge Intervals](https://leetcode.com/problems/merge-intervals) | Medium | Array |
| 23 | [Group Anagrams](https://leetcode.com/problems/group-anagrams) | Medium | String |
| 24 | [Lowest Common Ancestor of BST](https://leetcode.com/problems/lowest-common-ancestor-of-a-binary-search-tree) | Medium | Tree |
| 25 | [Find Minimum in Rotated Sorted Array](https://leetcode.com/problems/find-minimum-in-rotated-sorted-array) | Medium | Binary Search |
| 26 | [Maximum Product Subarray](https://leetcode.com/problems/maximum-product-subarray) | Medium | DP |
| 27 | [House Robber](https://leetcode.com/problems/house-robber) | Medium | DP |
| 28 | [Decode Ways](https://leetcode.com/problems/decode-ways) | Medium | DP |
| 29 | [Jump Game](https://leetcode.com/problems/jump-game) | Medium | Greedy |
| 30 | [Rotate Image](https://leetcode.com/problems/rotate-image) | Medium | Matrix |
| 31 | [Spiral Matrix](https://leetcode.com/problems/spiral-matrix) | Medium | Matrix |
| 32 | [Set Matrix Zeroes](https://leetcode.com/problems/set-matrix-zeroes) | Medium | Matrix |
| 33 | [Minimum Path Sum](https://leetcode.com/problems/minimum-path-sum) | Medium | DP |
| 34 | [Unique Paths](https://leetcode.com/problems/unique-paths) | Medium | DP |
| 35 | [Word Break](https://leetcode.com/problems/word-break) | Medium | DP |
| 36 | [Longest Common Subsequence](https://leetcode.com/problems/longest-common-subsequence) | Medium | DP |
| 37 | [Coin Change II](https://leetcode.com/problems/coin-change-ii) | Medium | DP |
| 38 | [Target Sum](https://leetcode.com/problems/target-sum) | Medium | DP |
| 39 | [Subsets](https://leetcode.com/problems/subsets) | Medium | Backtracking |
| 40 | [Permutations](https://leetcode.com/problems/permutations) | Medium | Backtracking |
| 41 | [Combination Sum](https://leetcode.com/problems/combination-sum) | Medium | Backtracking |
| 42 | [Letter Combinations of Phone](https://leetcode.com/problems/letter-combinations-of-a-phone-number) | Medium | Backtracking |
| 43 | [Binary Tree Level Order](https://leetcode.com/problems/binary-tree-level-order-traversal) | Medium | Tree |
| 44 | [Construct Binary Tree from Preorder](https://leetcode.com/problems/construct-binary-tree-from-preorder-and-inorder-traversal) | Medium | Tree |
| 45 | [Flatten Binary Tree to Linked List](https://leetcode.com/problems/flatten-binary-tree-to-linked-list) | Medium | Tree |
| 46 | [Binary Tree Maximum Path Sum](https://leetcode.com/problems/binary-tree-maximum-path-sum) | Hard | Tree |
| 47 | [Serialize and Deserialize Binary Tree](https://leetcode.com/problems/serialize-and-deserialize-binary-tree) | Hard | Tree |
| 48 | [Kth Smallest in BST](https://leetcode.com/problems/kth-smallest-element-in-a-bst) | Medium | Tree |
| 49 | [Number of Connected Components](https://leetcode.com/problems/number-of-connected-components-in-an-undirected-graph) | Medium | Graph |
| 50 | [Graph Valid Tree](https://leetcode.com/problems/graph-valid-tree) | Medium | Graph |
| 51 | [Course Schedule](https://leetcode.com/problems/course-schedule) | Medium | Graph |
| 52 | [Pacific Atlantic Water Flow](https://leetcode.com/problems/pacific-atlantic-water-flow) | Medium | Graph |
| 53 | [Alien Dictionary](https://leetcode.com/problems/alien-dictionary) | Hard | Graph |
| 54 | [Clone Graph](https://leetcode.com/problems/clone-graph) | Medium | Graph |
| 55 | [Word Ladder](https://leetcode.com/problems/word-ladder) | Hard | Graph |
| 56 | [Merge K Sorted Lists](https://leetcode.com/problems/merge-k-sorted-lists) | Hard | Heap |
| 57 | [Find Median From Data Stream](https://leetcode.com/problems/find-median-from-data-stream) | Hard | Heap |
| 58 | [Kth Largest Element](https://leetcode.com/problems/kth-largest-element-in-an-array) | Medium | Heap |
| 59 | [Top K Frequent Elements](https://leetcode.com/problems/top-k-frequent-elements) | Medium | Heap |
| 60 | [Task Scheduler](https://leetcode.com/problems/task-scheduler) | Medium | Heap |
| 61 | [Sliding Window Maximum](https://leetcode.com/problems/sliding-window-maximum) | Hard | Sliding Window |
| 62 | [Minimum Window Substring](https://leetcode.com/problems/minimum-window-substring) | Hard | Sliding Window |
| 63 | [Longest Repeating Char Replacement](https://leetcode.com/problems/longest-repeating-character-replacement) | Medium | Sliding Window |
| 64 | [Longest Substring K Distinct](https://leetcode.com/problems/longest-substring-with-at-most-k-distinct-characters) | Medium | Sliding Window |
| 65 | [Subarray Sum Equals K](https://leetcode.com/problems/subarray-sum-equals-k) | Medium | Prefix Sum |
| 66 | [Range Sum Query 2D](https://leetcode.com/problems/range-sum-query-2d-immutable) | Medium | Prefix Sum |
| 67 | [Single Number](https://leetcode.com/problems/single-number) | Easy | Bit Manipulation |
| 68 | [Number of 1 Bits](https://leetcode.com/problems/number-of-1-bits) | Easy | Bit Manipulation |
| 69 | [Missing Number](https://leetcode.com/problems/missing-number) | Easy | Bit Manipulation |
| 70 | [Implement Trie](https://leetcode.com/problems/implement-trie-prefix-tree) | Medium | Trie |
| 71 | [Add and Search Word](https://leetcode.com/problems/design-add-and-search-words-data-structure) | Medium | Trie |
| 72 | [Word Search II](https://leetcode.com/problems/word-search-ii) | Hard | Trie |
| 73 | [LRU Cache](https://leetcode.com/problems/lru-cache) | Medium | Design |
| 74 | [Design HashMap](https://leetcode.com/problems/design-hashmap) | Easy | Design |
| 75 | [Min Stack](https://leetcode.com/problems/min-stack) | Medium | Stack |
| 76 | [Daily Temperatures](https://leetcode.com/problems/daily-temperatures) | Medium | Stack |
| 77 | [Largest Rectangle in Histogram](https://leetcode.com/problems/largest-rectangle-in-histogram) | Hard | Stack |
| 78 | [Decode String](https://leetcode.com/problems/decode-string) | Medium | Stack |
| 79 | [Two Sum II](https://leetcode.com/problems/two-sum-ii-input-array-is-sorted) | Medium | Two Pointers |
| 80 | [3Sum Closest](https://leetcode.com/problems/3sum-closest) | Medium | Two Pointers |
| 81 | [Sort Colors](https://leetcode.com/problems/sort-colors) | Medium | Two Pointers |
| 82 | [Partition Labels](https://leetcode.com/problems/partition-labels) | Medium | Greedy |
| 83 | [Jump Game II](https://leetcode.com/problems/jump-game-ii) | Medium | Greedy |
| 84 | [Gas Station](https://leetcode.com/problems/gas-station) | Medium | Greedy |
| 85 | [Find the Duplicate Number](https://leetcode.com/problems/find-the-duplicate-number) | Medium | Array |
| 86 | [Longest Increasing Subsequence](https://leetcode.com/problems/longest-increasing-subsequence) | Medium | DP |
| 87 | [Edit Distance](https://leetcode.com/problems/edit-distance) | Hard | DP |
| 88 | [Burst Balloons](https://leetcode.com/problems/burst-balloons) | Hard | DP |
| 89 | [Regular Expression Matching](https://leetcode.com/problems/regular-expression-matching) | Hard | DP |
| 90 | [N-Queens](https://leetcode.com/problems/n-queens) | Hard | Backtracking |
| 91 | [Sudoku Solver](https://leetcode.com/problems/sudoku-solver) | Hard | Backtracking |
| 92 | [Diameter of Binary Tree](https://leetcode.com/problems/diameter-of-binary-tree) | Easy | Tree |
| 93 | [Path Sum II](https://leetcode.com/problems/path-sum-ii) | Medium | Tree |
| 94 | [Symmetric Tree](https://leetcode.com/problems/symmetric-tree) | Easy | Tree |
| 95 | [Validate BST](https://leetcode.com/problems/validate-binary-search-tree) | Medium | Tree |
| 96 | [Recover BST](https://leetcode.com/problems/recover-binary-search-tree) | Medium | Tree |
| 97 | [Shortest Path in Binary Matrix](https://leetcode.com/problems/shortest-path-in-binary-matrix) | Medium | BFS |
| 98 | [01 Matrix](https://leetcode.com/problems/01-matrix) | Medium | BFS |
| 99 | [Rotting Oranges](https://leetcode.com/problems/rotting-oranges) | Medium | BFS |
| 100 | [Walls and Gates](https://leetcode.com/problems/walls-and-gates) | Medium | BFS |

---

# STUDY PLAN — 3 Month FAANG Prep

## Month 1 — Fundamentals (Easy + Pattern Recognition)
```
Week 1: Array (Two Sum, Max Subarray, Trapping Rain, Kadane's)
Week 2: String (Valid Anagram, Group Anagrams, Longest Palindrome)
Week 3: LinkedList + Stack (Reverse, Merge, Min Stack, Valid Parens)
Week 4: Tree + Binary Search (Level Order, Validate BST, Binary Search)
```

## Month 2 — Core Patterns (Medium)
```
Week 1: DP (House Robber, Coin Change, Climbing Stairs, Jump Game)
Week 2: Graph (Number of Islands, Course Schedule, Clone Graph)
Week 3: Sliding Window + Two Pointers (Min Window Sub, Longest No Repeat)
Week 4: Backtracking (Subsets, Permutations, Combination Sum)
```

## Month 3 — Advanced (Hard + System Design)
```
Week 1: Hard DP (Edit Distance, LCS, Burst Balloons, Regex)
Week 2: Hard Graph (Word Ladder, Alien Dictionary, Topological Sort)
Week 3: Heap + Trie (Merge K Lists, Median Stream, Word Search II)
Week 4: Mock Interviews + System Design patterns
```

---

*Sourced from Crack The Coding Interview spreadsheet | ~868 Array + 420 String + 313 DP + 74 more topics | Total 2500+ problems*
