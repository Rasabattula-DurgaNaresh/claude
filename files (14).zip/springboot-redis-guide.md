# Spring Boot Microservices + Redis — Complete Guide

> **Microservices Architecture · Redis Internal Working · Caching · Session · Pub/Sub · Distributed Lock · Rate Limiting · Testing · Monitoring**

---

## Diagram Index

| Diagram | Covers |
|---------|--------|
| `diagrams/01_microservices_architecture.png` | Full system: API Gateway → 4 Microservices → Redis Cluster → PostgreSQL + Monitoring |
| `diagrams/02_redis_internal_cache_flow.png` | Redis event loop internals, memory encoding, @Cacheable flow, RESP protocol |
| `diagrams/03_pubsub_session_ratelimit.png` | Pub/Sub channel flow, Spring Session Redis, Lua rate-limit script |
| `diagrams/04_lock_cache_config.png` | Redisson distributed lock, cache annotations, RedisConfig code |
| `diagrams/05_dataflow_testing_monitoring.png` | E2E request flow, Testcontainers setup, Prometheus metrics dashboard |

## Project Structure

```
springboot-redis-microservices/
├── pom.xml                          Spring Boot 3.2.5, Redisson, Testcontainers
├── Dockerfile                       JRE 17 Alpine container image
├── docker-compose.yml               Redis, PostgreSQL, RedisInsight, Prometheus, Grafana
├── docs/                            This guide
├── diagrams/                        5 flow diagrams PNG
├── src/main/resources/
│   └── application.yml              Full config: Redis, JPA, Session, Cache TTLs, Actuator
└── src/main/java/com/redisdemo/
    ├── SpringBootRedisApp.java       Main application entry point
    ├── config/
    │   ├── RedisConfig.java          Lettuce, RedisTemplate, CacheManager, Redisson
    │   └── PubSubConfig.java         RedisMessageListenerContainer
    ├── model/Product.java            JPA Entity
    ├── dto/ProductDto.java           Serializable DTO (cached in Redis as JSON)
    ├── repository/ProductRepository.java  Spring Data JPA
    ├── service/
    │   ├── ProductService.java       @Cacheable, @CachePut, @CacheEvict, Distributed Lock
    │   ├── OrderEventService.java    Redis Pub/Sub publisher + MessageListener
    │   └── SessionService.java       Spring Session + manual Redis operations
    ├── controller/ProductController.java  REST endpoints
    ├── filter/RateLimitFilter.java   Lua script atomic rate limiting
    └── exception/
        └── ProductNotFoundException.java
└── src/test/java/com/redisdemo/
    └── ProductServiceTest.java       Testcontainers real Redis + MockBean JPA
```

---

# PART 1: Redis Internal Working

## 1.1 Event Loop Architecture

Redis uses a single-threaded event loop for ALL command processing:

```
                    REDIS SERVER
    ┌──────────────────────────────────────────┐
    │  Clients connect via TCP port 6379        │
    │         ↓                                 │
    │  epoll/kqueue (non-blocking I/O)          │
    │         ↓                                 │
    │  ae_event_loop.c  (event dispatcher)      │
    │         ↓                                 │
    │  RESP Parser → Command Table lookup       │
    │         ↓                                 │
    │  Command Handler (GET, SET, ZADD...)      │
    │         ↓                                 │
    │  In-Memory Data Structures                │
    │         ↓                                 │
    │  Reply Encoder → Socket write             │
    └──────────────────────────────────────────┘
```

**Why single-threaded for commands?**
- No mutex/locking needed — all commands are naturally atomic
- No context switching overhead
- CPU stays hot, cache-warm on data structures
- Network I/O multiplexed (one thread handles thousands of clients)
- Background tasks (AOF fsync, RDB fork, expiry) use separate threads

**Redis 6+ I/O Threads:** Multi-threaded for reading/writing sockets, single-threaded for command execution.

---

## 1.2 Memory Encoding

Redis optimizes memory by switching between compact and full representations:

| Type | Small (compact) | Large (full) | Threshold |
|------|----------------|--------------|-----------|
| String | embstr (<=44 bytes) | raw SDS | 44 bytes |
| Hash | ziplist | hashtable | 128 entries, 64B value |
| List | quicklist (ziplist nodes) | quicklist (larger) | node size |
| Set | intset (integers) | hashtable | 512 integers |
| ZSet | ziplist | skiplist + hashtable | 128 members, 64B |

**SDS (Simple Dynamic String):**
```c
struct sdshdr {
    int len;      // O(1) length — no strlen() scan needed
    int free;     // pre-allocated buffer space
    char buf[];   // binary-safe bytes (can contain null bytes)
};
```

**Skip List (Sorted Set):**
- Multiple levels of forward pointers for O(log n) traversal
- Simultaneously maintained hashtable for O(1) score lookup by member
- Why not BST? Skip list is simpler, cache-friendly, easier to implement range queries

---

## 1.3 RESP Protocol (Redis Serialization Protocol)

All communication between client and Redis uses RESP:

```
Type            First byte   Example
─────────────────────────────────────────────────
Simple String   +            +OK
Error           -            -ERR unknown command
Integer         :            :42
Bulk String     $            $6  foobar
Null            $            $-1
Array           *            *3  (3 elements follow)
```

**SET key value over the wire:**
```
*3         (array of 3 elements)
$3
SET
$8
product:1
$42
{"id":1,"name":"iPhone","price":999.99}
```

---

## 1.4 Lettuce vs Jedis

| Feature | Lettuce (Spring Boot Default) | Jedis |
|---------|------------------------------|-------|
| I/O model | Async, non-blocking (Netty) | Sync, blocking |
| Thread safety | Single shared connection | Pool needed |
| Reactive | Yes (Project Reactor) | No |
| Cluster | Yes | Yes |
| Typical use | High-throughput services | Simple scripts |

**Lettuce multiplexing — how ONE connection handles ALL threads:**
```
Thread-1 issue command ─┐
Thread-2 issue command ─┤→ Lettuce Channel → Netty EventLoop → TCP → Redis
Thread-3 issue command ─┘                 ← responses demultiplexed back
```

---

# PART 2: Spring Boot Redis Configuration

## 2.1 RedisConfig.java — Complete Breakdown

```java
@Configuration
@EnableCaching             // Activates @Cacheable/@CachePut/@CacheEvict AOP proxy
@EnableRedisHttpSession(maxInactiveIntervalInSeconds = 1800)
public class RedisConfig {

    // STEP 1: Connection Factory
    // Lettuce uses a single Netty channel shared across threads
    @Bean @Primary
    public LettuceConnectionFactory redisConnectionFactory() {
        RedisStandaloneConfiguration cfg = new RedisStandaloneConfiguration(host, port);
        return new LettuceConnectionFactory(cfg);
    }

    // STEP 2: RedisTemplate — the main operations interface
    // Key:   StringRedisSerializer   → stored as "products::42"
    // Value: Jackson2JsonSerializer  → {"@class":"...ProductDto","id":42,...}
    @Bean
    public RedisTemplate<String, Object> redisTemplate() {
        RedisTemplate<String, Object> tpl = new RedisTemplate<>();
        tpl.setConnectionFactory(redisConnectionFactory());
        tpl.setKeySerializer(new StringRedisSerializer());
        tpl.setValueSerializer(new GenericJackson2JsonRedisSerializer(objectMapper()));
        return tpl;
    }

    // STEP 3: CacheManager — used by @Cacheable AOP proxy
    // Configures different TTLs per cache name
    @Bean
    public CacheManager cacheManager() {
        RedisCacheConfiguration def = RedisCacheConfiguration.defaultCacheConfig()
            .entryTtl(Duration.ofMinutes(60))
            .disableCachingNullValues()
            .prefixCacheNameWith("cache:product-service:");

        Map<String, RedisCacheConfiguration> caches = new HashMap<>();
        caches.put("products",   def.entryTtl(Duration.ofMinutes(10)));  // 10m TTL
        caches.put("categories", def.entryTtl(Duration.ofHours(1)));     // 1h TTL
        caches.put("inventory",  def.entryTtl(Duration.ofSeconds(60)));  // 60s TTL

        return RedisCacheManager.builder(redisConnectionFactory())
            .cacheDefaults(def)
            .withInitialCacheConfigurations(caches)
            .transactionAware()
            .build();
    }

    // STEP 4: Redisson — distributed locks with watchdog TTL extension
    @Bean
    public RedissonClient redissonClient() {
        Config cfg = new Config();
        cfg.useSingleServer().setAddress("redis://" + host + ":" + port);
        cfg.setLockWatchdogTimeout(30_000);  // watchdog extends lock every 10s
        return Redisson.create(cfg);
    }
}
```

---

# PART 3: @Cacheable Annotations

## 3.1 How @Cacheable Works Internally

Spring AOP creates a CGLIB proxy around your service bean:

```
HTTP Request → Controller → [CacheProxy wraps Service]
                                ↓
                     1. Build key: SpEL "#id" → "42"
                     2. Full key: "cache:product-service:products::42"
                     3. Redis GET key
                           ↓ HIT: deserialize JSON → return (method NOT called)
                           ↓ MISS: call method → Redis SET key {json} EX 600 → return
```

## 3.2 All Annotations with Examples

```java
// @Cacheable — CHECK cache first, EXECUTE only on miss
@Cacheable(cacheNames = "products", key = "#id", unless = "#result == null")
public ProductDto findById(Long id) {
    return repo.findById(id).map(this::toDto).orElse(null);
    // On MISS: SET "cache:product-service:products::42" {json} EX 600
}

// @CachePut — ALWAYS execute, ALWAYS update cache
@CachePut(cacheNames = "products", key = "#result.id")
public ProductDto create(ProductDto dto) {
    Product saved = repo.save(fromDto(dto));
    return toDto(saved);
    // Always: SET "cache:product-service:products::{newId}" {json} EX 600
}

// @CacheEvict — REMOVE from cache
@CacheEvict(cacheNames = "products", key = "#id")
public void delete(Long id) {
    repo.deleteById(id);
    // After: DEL "cache:product-service:products::42"
}

// @CacheEvict with allEntries
@CacheEvict(cacheNames = "products", allEntries = true)
public void clearAll() {
    // SCAN cache:product-service:products::* then DEL all
}

// @Caching — combine multiple operations
@Caching(
    put = @CachePut(cacheNames = "products", key = "#id"),
    evict = {
        @CacheEvict(cacheNames = "products", key = "'all:active'"),
        @CacheEvict(cacheNames = "products", key = "'category:' + #dto.category")
    }
)
public ProductDto update(Long id, ProductDto dto) {
    // Update DB, refresh individual cache, evict stale list caches
}
```

## 3.3 Cache Key Examples

```
Method Call                     Redis Key (stored in Redis)
─────────────────────────────────────────────────────────────────────
findById(42L)                   cache:product-service:products::42
findAllActive()                 cache:product-service:products::all:active
findByCategory("Electronics")   cache:product-service:products::category:Electronics
findAllCategories()             cache:product-service:categories::all
```

---

# PART 4: Pub/Sub — Internal Working

## 4.1 Publisher Side

```java
// Sends PUBLISH orders.created {json} over TCP to Redis
// Redis fans out to ALL subscribers of that channel
redisTemplate.convertAndSend("orders.created", payload);
```

## 4.2 Subscriber Setup

```java
@Bean
public RedisMessageListenerContainer messageListenerContainer(
        RedisConnectionFactory cf, OrderEventService listener) {
    RedisMessageListenerContainer container = new RedisMessageListenerContainer();
    container.setConnectionFactory(cf);

    // Dedicated connection maintained by container (not shared Lettuce connection)
    // On startup: SUBSCRIBE orders.created (or PSUBSCRIBE orders.*)

    container.addMessageListener(listener, new ChannelTopic("orders.created"));
    container.addMessageListener(listener, new ChannelTopic("orders.shipped"));
    container.addMessageListener(listener, new PatternTopic("orders.*")); // wildcard
    return container;
}
```

## 4.3 Message Flow

```
1. POST /api/orders → OrderService.placeOrder()
2. orderEventService.publishOrderCreated(orderId, userId, total)
3. RedisTemplate.convertAndSend("orders.created", "{json}")
   → PUBLISH orders.created {"orderId":1,"userId":42,"total":999.99}
4. Redis delivers to all SUBSCRIBE/PSUBSCRIBE connections
5. NotificationService.onMessage() called in listener thread pool
6. Sends email / SMS based on event type
```

**Important:** Messages are NOT persisted. Use Streams (XADD/XREAD) for guaranteed delivery.

---

# PART 5: Spring Session with Redis

## 5.1 How Sessions Are Stored

```
Redis Key: spring:session:product-service:sessions:abc123def456
Redis Type: HASH

Fields stored:
  creationTime              1700000000000
  lastAccessedTime          1700003600000
  maxInactiveInterval       1800
  sessionAttr:userId        42
  sessionAttr:userRole      "ADMIN"
  sessionAttr:cart          {"1":2,"5":1}

TTL: 1800 seconds (refreshed on every authenticated request)
```

## 5.2 Session Lifecycle

```
1. Login request
   └─ session.setAttribute("userId", 42)
   └─ Spring: HSET spring:session:...:newSessionId sessionAttr:userId 42
   └─ Spring: EXPIRE spring:session:...:newSessionId 1800
   └─ Response: Set-Cookie: SESSION=abc123; HttpOnly

2. Subsequent request (Cookie: SESSION=abc123)
   └─ SessionRepositoryFilter intercepts
   └─ Spring: HGETALL spring:session:...:abc123
   └─ Populates HttpSession, refreshes TTL
   └─ session.getAttribute("userId") → 42 (available in controller)

3. Logout
   └─ session.invalidate()
   └─ Spring: DEL spring:session:...:abc123
```

---

# PART 6: Rate Limiting with Lua

## 6.1 Why Lua?

Single atomic operation on Redis server — no race conditions:
```
Without Lua (WRONG - race condition possible):
  Thread A: INCR count → 1
  Thread B: INCR count → 2
  Thread A: EXPIRE count 60  ← both threads set expiry independently
  Thread B: EXPIRE count 60

With Lua (CORRECT - atomic):
  All steps execute as one indivisible operation
```

## 6.2 The Lua Script

```lua
local current = redis.call('INCR', KEYS[1])    -- atomic increment
if current == 1 then                            -- first request in window
  redis.call('EXPIRE', KEYS[1], ARGV[2])        -- set window expiry
end
if current > tonumber(ARGV[1]) then
  return 0   -- blocked: over limit
end
return 1     -- allowed
```

## 6.3 Rate Limit Key Strategy

```
Key: "rate:limit:/api/products:user42:1700000"
         prefix   endpoint    userId  time-bucket (minute)

Time bucket ensures window resets every minute:
  System.currentTimeMillis() / (60 * 1000) = minute bucket
```

---

# PART 7: Distributed Lock with Redisson

## 7.1 Redisson RLock Internal Steps

```
ACQUIRE:
  Redis: SET lock:inventory:42 {uuid} NX PX 30000
  NX    = Set if Not eXists (atomic check + set)
  PX    = Millisecond expiry (30 seconds)
  → Returns OK (acquired) or nil (already held)

WATCHDOG:
  Background thread runs every 10 seconds (lockWatchdogTimeout/3):
  → PEXPIRE lock:inventory:42 30000  (extend TTL)
  → Prevents lock expiry while holder is still working

RELEASE (Lua — atomic verify + delete):
  if redis.call('get', KEYS[1]) == ARGV[1] then
    return redis.call('del', KEYS[1])  -- only owner can release
  else
    return 0  -- someone else holds lock
  end

Safety properties:
  ✓ Only lock owner can release (UUID verification)
  ✓ TTL prevents deadlock if owner process crashes
  ✓ Watchdog prevents expiry on long operations
  ✓ Reentrant: same thread can lock multiple times (Redisson tracks count)
```

## 7.2 Usage Pattern

```java
RLock lock = redissonClient.getLock("lock:inventory:" + productId);
try {
    if (lock.tryLock(5, 30, TimeUnit.SECONDS)) {
        try {
            // === CRITICAL SECTION ===
            updateInventory(productId, delta);
            // ========================
        } finally {
            if (lock.isHeldByCurrentThread()) lock.unlock();
        }
    }
} catch (InterruptedException e) {
    Thread.currentThread().interrupt();
}
```

---

# PART 8: REST API Reference

| Method | Endpoint | Cache Effect |
|--------|----------|--------------|
| GET | /api/products/{id} | @Cacheable TTL 10m |
| GET | /api/products | @Cacheable TTL 10m |
| GET | /api/products/category/{cat} | @Cacheable TTL 10m |
| GET | /api/products/categories | @Cacheable TTL 1hr |
| POST | /api/products | @CachePut new entry |
| PUT | /api/products/{id} | @CachePut + @CacheEvict lists |
| DELETE | /api/products/{id} | @CacheEvict |
| POST | /api/products/{id}/inventory | Distributed lock + DEL cache |
| POST | /api/products/{id}/view | ZINCRBY sorted set |
| GET | /api/products/popular | ZREVRANGE sorted set |
| DELETE | /api/products/cache | allEntries=true |

---

# PART 9: Testing

```java
@SpringBootTest
@Testcontainers
class ProductServiceTest {

    @Container
    static GenericContainer<?> redis =
        new GenericContainer<>("redis:7-alpine").withExposedPorts(6379);

    @DynamicPropertySource
    static void props(DynamicPropertyRegistry reg) {
        reg.add("spring.data.redis.host", redis::getHost);
        reg.add("spring.data.redis.port", () -> redis.getMappedPort(6379));
    }

    @Test void cacheHitTest() {
        // First call → MISS → DB
        productService.findById(42L);
        verify(productRepository, times(1)).findById(42L);

        // Second call → HIT → no DB
        productService.findById(42L);
        verify(productRepository, times(1)).findById(42L); // still 1!
    }
}
```

---

# PART 10: Run the Project

```bash
# Start infrastructure
docker-compose up redis postgres redisinsight -d

# Run application
./mvnw spring-boot:run

# Verify cache behavior
curl http://localhost:8081/api/products/1  # MISS: DB query + cache fill
curl http://localhost:8081/api/products/1  # HIT:  from Redis

# Inspect Redis
redis-cli KEYS 'cache:product-service:*'
redis-cli GET 'cache:product-service:products::1'
redis-cli TTL 'cache:product-service:products::1'

# Full stack + monitoring
docker-compose up -d
# App:          http://localhost:8081
# RedisInsight: http://localhost:5540
# Prometheus:   http://localhost:9090
# Grafana:      http://localhost:3000

# Run tests (requires Docker for Testcontainers)
./mvnw test
```

---

*Spring Boot + Redis Microservices — Production-Ready Patterns | Redis Internals | Complete Implementation*
