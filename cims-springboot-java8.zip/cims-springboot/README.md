# CIMS — Credit Information Management System
## Spring Boot 2.7 · Java 8 · React 18 · Microservices

Production-ready implementation of the CIMS architecture diagram.

---

## Architecture

```
[RTOB/COS/Jocata]
    ↓
[Nginx LB :80/443]
    ↓
[Spring Cloud Gateway :8080]  ← JWT validation + rate limiting + circuit breaker
    ├── [Auth Service   :8081]  ← JWT, BCrypt, MFA, Redis sessions, Flyway
    ├── [Bureau Service :8082]  ← Feign→ICLNET2, MinIO, Spring Data JPA
    ├── [Batch Service  :8083]  ← Spring Batch, @Scheduled, 9 downstream systems
    └── [MCRA Service   :8084]  ← TCP Socket (TU), Feign (CRP/OneConnect)
           ↓
    [PostgreSQL Primary / Standby + Redis + MinIO]
           ↓ (via ICLNET2 Kong OAG)
    [CRP · OneConnect · TransUnion (socket via Kong EAG)]
           ↓ (batch dispatch)
    [ICM · RLS · PDW · RDS · CCMS · PROBE · OAMS · EDMP · ECARS · BRS]
```

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Backend | Spring Boot 2.7.18, Java 8 |
| API Gateway | Spring Cloud Gateway 2021 |
| Security | Spring Security, JWT (jjwt 0.9.1), BCrypt |
| Persistence | Spring Data JPA, PostgreSQL 15, Flyway |
| Batch | Spring Batch 4.x, @Scheduled |
| HTTP Client | OpenFeign with Circuit Breaker |
| Object Storage | MinIO SDK |
| Cache | Spring Data Redis |
| Monitoring | Micrometer → Prometheus → Grafana |
| API Docs | Springfox Swagger 3 |
| Frontend | React 18, TypeScript, Vite, TailwindCSS |
| Container | Docker + Docker Compose |

## Quick Start

```bash
# 1. Configure environment
make setup && vim .env

# 2. Build everything (requires Java 8 + Maven + Node 18)
make build

# 3. Build Docker images
make docker-build

# 4. Start all services
make up

# 5. Verify health
make health

# 6. View Swagger APIs
make swagger
```

## Service Ports

| Service | Port | Description |
|---------|------|-------------|
| Nginx (Frontend) | 80/443 | React SPA |
| Spring Cloud Gateway | 8080 | API entry point |
| Auth Service | 8081 | JWT/MFA auth |
| Bureau Service | 8082 | Credit enquiries |
| Batch Service | 8083 | Spring Batch jobs |
| MCRA Service | 8084 | Risk assessment |
| MinIO API | 9000 | Object storage |
| MinIO Console | 9001 | Storage UI |
| Prometheus | 9090 | Metrics |
| Grafana | 3001 | Dashboards |

## API Examples

```bash
# Login
curl -X POST http://localhost:8080/api/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"username":"admin","password":"Admin@2024!"}'

# Submit Bureau Enquiry
curl -X POST http://localhost:8080/api/bureau/enquiry \
  -H 'Authorization: Bearer <token>' \
  -H 'Content-Type: application/json' \
  -d '{"subjectId":"<id>","enquiryType":"STANDARD","purpose":"Credit assessment"}'

# Trigger Batch Job
curl -X POST http://localhost:8080/api/batch/trigger/downstream-dispatch \
  -H 'Authorization: Bearer <token>'

# Submit MCRA Assessment
curl -X POST http://localhost:8080/api/mcra/assess \
  -H 'Authorization: Bearer <token>' \
  -H 'Content-Type: application/json' \
  -d '{"subjectId":"<id>","assessmentType":"STANDARD"}'
```

## ICLNET2 Connectivity Notes

Per architecture diagram:
1. **Existing connectivity unchanged** — RTOB, COS, Jocata connect via Kong IAG
2. **MCRA → CRP** via ICLNET2 leased line (Feign client via Kong OAG)
3. **MCRA → OneConnect** via ICLNET2 leased line (Feign client via Kong OAG)
4. **MCRA → TransUnion** via **Socket Connection** through Kong EAG
   - TransUnion is NOT migrating to API — remains socket/leased line
   - `TransUnionSocketService` maintains persistent TCP connection

## Swagger UI

- Auth: http://localhost:8081/swagger-ui/
- Bureau: http://localhost:8082/swagger-ui/
- Batch: http://localhost:8083/swagger-ui/
- MCRA: http://localhost:8084/swagger-ui/
