/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary:   { 50:'#f0f4ff',100:'#e0e9ff',500:'#4361ee',600:'#3a56d4',700:'#2f44b0',900:'#1a2672' },
        accent:    { 400:'#f72585',500:'#e5177e' },
        surface:   { 50:'#f8fafc',100:'#f1f5f9',200:'#e2e8f0',900:'#0f172a' },
        status:    { success:'#10b981', warning:'#f59e0b', error:'#ef4444', info:'#3b82f6' }
      },
      fontFamily: {
        display: ['"Syne"', 'system-ui', 'sans-serif'],
        body:    ['"DM Sans"', 'system-ui', 'sans-serif'],
        mono:    ['"JetBrains Mono"', 'monospace'],
      },
      boxShadow: {
        card: '0 1px 3px 0 rgba(0,0,0,0.07), 0 1px 2px -1px rgba(0,0,0,0.07)',
        'card-hover': '0 4px 6px -1px rgba(0,0,0,0.10), 0 2px 4px -2px rgba(0,0,0,0.10)',
        glow: '0 0 20px rgba(67,97,238,0.15)',
      }
    }
  },
  plugins: [],
};