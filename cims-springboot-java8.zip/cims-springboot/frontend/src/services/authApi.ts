import { api } from './api';
import axios from 'axios';

export const authApi = {
  login: async (username: string, password: string, mfaToken?: string) => {
    const { data } = await axios.post('/api/auth/login', { username, password, mfaToken });
    return data.data;
  },
  logout: async () => { await api.post('/auth/logout'); },
  me: async () => { const { data } = await api.get('/auth/me'); return data.data; },
  changePassword: async (currentPassword: string, newPassword: string) => {
    await api.post('/auth/change-password', { currentPassword, newPassword });
  },
};