import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';
import { LayoutDashboard, FileSearch, Server, BarChart3, FileText, Settings, LogOut, Shield, Activity, ChevronRight } from 'lucide-react';
import clsx from 'clsx';

const nav = [
  { to: '/dashboard', icon: LayoutDashboard, label: 'Dashboard',      desc: 'System overview' },
  { to: '/bureau',    icon: FileSearch,      label: 'Bureau Enquiry', desc: 'Credit data lookup' },
  { to: '/batch',     icon: Server,          label: 'Batch Jobs',     desc: 'Spring Batch management' },
  { to: '/mcra',      icon: BarChart3,       label: 'MCRA',           desc: 'Risk assessment' },
  { to: '/reports',   icon: FileText,        label: 'Reports',        desc: 'Analytics & reports' },
  { to: '/settings',  icon: Settings,        label: 'Settings',       desc: 'Configuration' },
];

export function MainLayout() {
  const { user, logout } = useAuthStore();
  const navigate = useNavigate();

  const handleLogout = async () => { await logout(); navigate('/login'); };

  return (
    <div className="flex h-full">
      {/* Sidebar */}
      <aside className="w-[260px] bg-surface-900 flex flex-col shrink-0 fixed inset-y-0 left-0 z-30">
        {/* Logo */}
        <div className="flex items-center gap-3 px-5 py-5 border-b border-white/5">
          <div className="w-9 h-9 bg-gradient-to-br from-primary-400 to-primary-600 rounded-xl flex items-center justify-center shadow-glow">
            <Shield size={18} className="text-white" />
          </div>
          <div>
            <div className="font-display font-bold text-white text-base leading-none">CIMS</div>
            <div className="text-white/40 text-[10px] mt-0.5 font-mono uppercase tracking-wider">v1.0 · Spring Boot</div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
          <div className="text-white/25 text-[10px] font-semibold uppercase tracking-widest px-3 mb-3">Navigation</div>
          {nav.map(({ to, icon: Icon, label }) => (
            <NavLink key={to} to={to} className={({ isActive }) =>
              clsx('nav-link group', isActive ? 'active' : 'text-white/50 hover:text-white hover:bg-white/5')}>
              <Icon size={16} className="shrink-0" />
              <span className="flex-1">{label}</span>
              <ChevronRight size={12} className="opacity-0 group-hover:opacity-40 transition-opacity" />
            </NavLink>
          ))}
        </nav>

        {/* Status indicator */}
        <div className="px-4 py-3 border-t border-white/5">
          <div className="flex items-center gap-2 px-2 py-2 rounded-lg bg-white/5">
            <div className="w-2 h-2 rounded-full bg-status-success animate-pulse-slow" />
            <span className="text-white/50 text-xs font-mono">All systems operational</span>
          </div>
        </div>

        {/* User */}
        <div className="px-3 py-3 border-t border-white/5">
          <div className="flex items-center gap-3 px-3 py-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary-400 to-accent-500 flex items-center justify-center text-white text-sm font-bold font-display shrink-0">
              {(user?.fullName || user?.username || 'U').charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-white text-sm font-semibold truncate">{user?.fullName || user?.username}</div>
              <div className="text-white/40 text-[11px] truncate font-mono">{user?.role}</div>
            </div>
            <button onClick={handleLogout} className="text-white/30 hover:text-red-400 transition-colors p-1" title="Logout">
              <LogOut size={15} />
            </button>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 ml-[260px] min-h-full bg-surface-50 overflow-auto">
        <Outlet />
      </main>
    </div>
  );
}