import { useQuery } from '@tanstack/react-query';
import { api } from '../services/api';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { Activity, FileSearch, Server, BarChart3, CheckCircle2, AlertCircle, Clock, TrendingUp } from 'lucide-react';
import clsx from 'clsx';

const activityData = [
  {t:'00:00',bureau:12,mcra:5},{t:'04:00',bureau:8,mcra:3},{t:'08:00',bureau:62,mcra:28},
  {t:'10:00',bureau:89,mcra:41},{t:'12:00',bureau:134,mcra:67},{t:'14:00',bureau:98,mcra:52},
  {t:'16:00',bureau:76,mcra:38},{t:'18:00',bureau:45,mcra:22},{t:'20:00',bureau:30,mcra:15},
];

const services = [
  {name:'Auth Service (8081)',    status:'UP', latency:'12ms'},
  {name:'Bureau Service (8082)',  status:'UP', latency:'23ms'},
  {name:'Batch Service (8083)',   status:'UP', latency:'8ms'},
  {name:'MCRA Service (8084)',    status:'UP', latency:'45ms'},
  {name:'API Gateway (8080)',     status:'UP', latency:'5ms'},
  {name:'Primary PostgreSQL',    status:'UP', latency:'2ms'},
  {name:'Standby PostgreSQL',    status:'UP', latency:'3ms'},
  {name:'Redis Cache',            status:'UP', latency:'1ms'},
  {name:'MinIO Storage',          status:'UP', latency:'18ms'},
  {name:'ICLNET2 Gateway',       status:'UP', latency:'89ms'},
  {name:'TransUnion Socket',     status:'UP', latency:'Socket'},
];

function StatCard({title,value,icon:Icon,color,change,desc}:any) {
  return (
    <div className="stat-card">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-semibold text-surface-400 uppercase tracking-wider">{title}</p>
          <p className="text-3xl font-display font-bold text-surface-900 mt-1">{value}</p>
          {desc && <p className="text-xs text-surface-400 mt-1">{desc}</p>}
        </div>
        <div className={clsx('w-10 h-10 rounded-xl flex items-center justify-center shrink-0', color)}>
          <Icon size={18} className="text-white" />
        </div>
      </div>
      {change && (
        <div className="flex items-center gap-1 text-xs font-medium text-emerald-600">
          <TrendingUp size={12} />
          <span>{change} vs yesterday</span>
        </div>
      )}
    </div>
  );
}

function ServiceRow({name,status,latency}:{name:string;status:string;latency:string}) {
  const isUp = status === 'UP';
  return (
    <div className="flex items-center gap-3 py-2 border-b border-surface-100 last:border-0">
      <div className={clsx('w-2 h-2 rounded-full shrink-0', isUp ? 'bg-status-success animate-pulse-slow' : 'bg-status-error')} />
      <span className="text-sm text-surface-700 flex-1 font-mono text-xs">{name}</span>
      <span className={clsx('text-xs font-semibold px-2 py-0.5 rounded-full', isUp ? 'badge-success' : 'badge-error')}>{status}</span>
      <span className="text-xs text-surface-400 font-mono w-14 text-right">{latency}</span>
    </div>
  );
}

export function DashboardPage() {
  const { data: batchData } = useQuery({ queryKey: ['batch-jobs'], queryFn: async () => { const {data} = await api.get('/batch/jobs'); return data; }, refetchInterval: 30000 });

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div className="page-header">
        <h1 className="page-title">System Dashboard</h1>
        <p className="page-subtitle">Real-time overview of CIMS microservices and operations</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        <StatCard title="Bureau Enquiries" value="1,847" icon={FileSearch} color="bg-primary-500" change="+14.2%" />
        <StatCard title="Active Batch Jobs" value={batchData?.data?.jobs?.filter((j:any)=>j.status==='running').length ?? '0'} icon={Server} color="bg-amber-500" desc="Spring Batch" />
        <StatCard title="MCRA Assessments" value="523" icon={BarChart3} color="bg-purple-500" change="+8.1%" />
        <StatCard title="System Uptime" value="99.98%" icon={Activity} color="bg-emerald-500" desc="Last 30 days" />
      </div>

      {/* Charts + Services */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2 card p-5">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h2 className="font-display font-bold text-surface-900">Transaction Volume (24h)</h2>
              <p className="text-xs text-surface-400 mt-0.5">Bureau enquiries and MCRA assessments</p>
            </div>
            <span className="badge badge-success">Live</span>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={activityData} margin={{left:-20}}>
              <defs>
                <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#4361ee" stopOpacity={0.15} /><stop offset="95%" stopColor="#4361ee" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="g2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f72585" stopOpacity={0.15} /><stop offset="95%" stopColor="#f72585" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="t" tick={{fontSize:11,fill:'#94a3b8'}} axisLine={false} tickLine={false} />
              <YAxis tick={{fontSize:11,fill:'#94a3b8'}} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{borderRadius:'10px',border:'1px solid #e2e8f0',fontSize:'12px',fontFamily:'DM Sans'}} />
              <Area type="monotone" dataKey="bureau" name="Bureau" stroke="#4361ee" strokeWidth={2} fill="url(#g1)" />
              <Area type="monotone" dataKey="mcra" name="MCRA" stroke="#f72585" strokeWidth={2} fill="url(#g2)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="card p-5">
          <h2 className="font-display font-bold text-surface-900 mb-4">Service Health</h2>
          <div className="overflow-y-auto max-h-[280px]">
            {services.map(s => <ServiceRow key={s.name} {...s} />)}
          </div>
        </div>
      </div>

      {/* Recent Batch Jobs */}
      <div className="card">
        <div className="px-5 py-4 border-b border-surface-100 flex items-center justify-between">
          <div>
            <h2 className="font-display font-bold text-surface-900">Spring Batch Jobs</h2>
            <p className="text-xs text-surface-400 mt-0.5">Downstream dispatch & reconciliation jobs</p>
          </div>
        </div>
        <div className="table-wrapper !rounded-none !border-0">
          <table className="table">
            <thead>
              <tr>
                <th>Job Name</th><th>Type</th><th>Status</th>
                <th>Processed</th><th>Failed</th><th>Completed</th>
              </tr>
            </thead>
            <tbody>
              {batchData?.data?.jobs?.slice(0,8).map((job:any) => (
                <tr key={job.id}>
                  <td className="font-medium text-surface-900">{job.jobName}</td>
                  <td><span className="font-mono text-xs text-surface-400">{job.jobType}</span></td>
                  <td>
                    <span className={clsx('badge', job.status==='COMPLETED'?'badge-success':job.status==='running'?'badge-warning':'badge-neutral')}>
                      {job.status}
                    </span>
                  </td>
                  <td className="font-mono text-xs">{job.processedRecords ?? 0}</td>
                  <td className="font-mono text-xs text-red-500">{job.failedRecords ?? 0}</td>
                  <td className="text-xs text-surface-400">{job.completedAt ? new Date(job.completedAt).toLocaleString() : '—'}</td>
                </tr>
              )) || (
                <tr><td colSpan={6} className="text-center py-10 text-surface-400">No batch jobs found</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}