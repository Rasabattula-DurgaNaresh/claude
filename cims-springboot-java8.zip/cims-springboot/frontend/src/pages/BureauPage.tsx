export function BureauPage() {
  return (
    <div className="p-6 animate-fade-in">
      <div className="page-header">
        <h1 className="page-title">Bureau Enquiry</h1>
        <p className="page-subtitle">Credit bureau data lookups via ICLNET2</p>
      </div>
      <div className="card p-8 text-center">
        <div className="max-w-lg mx-auto">
          <div className="w-16 h-16 bg-primary-50 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <span className="text-primary-500 text-2xl">⚙</span>
          </div>
          <h3 className="font-display font-bold text-surface-900 text-lg mb-2">Bureau Enquiry Module</h3>
          <p className="text-surface-500 text-sm leading-relaxed">Submit enquiries to external credit bureau via ICLNET2 Kong OAG. Supports individual and corporate subjects with MinIO document storage.</p>
        </div>
      </div>
    </div>
  );
}
