import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useAuthStore } from '../store/authStore';
import { Shield, Loader2, Eye, EyeOff, AlertTriangle, Lock, User } from 'lucide-react';
import toast from 'react-hot-toast';

const schema = z.object({
  username: z.string().min(1, 'Username required'),
  password: z.string().min(1, 'Password required'),
  mfaToken: z.string().optional(),
});
type Form = z.infer<typeof schema>;

export function LoginPage() {
  const navigate = useNavigate();
  const { login } = useAuthStore();
  const [requiresMfa, setRequiresMfa] = useState(false);
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState('');

  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<Form>({ resolver: zodResolver(schema) });

  const onSubmit = async (data: Form) => {
    setError('');
    try {
      const result = await login(data.username, data.password, data.mfaToken);
      if (result?.requiresMfa) { setRequiresMfa(true); toast('Please enter your MFA code'); return; }
      toast.success('Welcome back!');
      navigate('/dashboard');
    } catch (err: any) {
      const msg = err.response?.data?.message || 'Authentication failed';
      setError(msg);
    }
  };

  return (
    <div className="min-h-screen flex relative overflow-hidden" style={{background:'#0f172a'}}>
      {/* Animated background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-96 h-96 rounded-full opacity-10" style={{background:'radial-gradient(circle, #4361ee, transparent)'}} />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 rounded-full opacity-10" style={{background:'radial-gradient(circle, #f72585, transparent)'}} />
        <div className="absolute top-1/2 left-1/4 w-64 h-64 rounded-full opacity-5" style={{background:'radial-gradient(circle, #4361ee, transparent)'}} />
        {/* Grid */}
        <div className="absolute inset-0 opacity-[0.03]" style={{backgroundImage:'linear-gradient(rgba(255,255,255,0.5) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.5) 1px,transparent 1px)',backgroundSize:'40px 40px'}} />
      </div>

      {/* Left branding panel */}
      <div className="hidden lg:flex flex-col justify-center px-16 w-1/2 relative z-10">
        <div className="max-w-md">
          <div className="flex items-center gap-3 mb-10">
            <div className="w-12 h-12 bg-gradient-to-br from-primary-400 to-primary-600 rounded-2xl flex items-center justify-center">
              <Shield size={24} className="text-white" />
            </div>
            <div>
              <div className="font-display font-bold text-white text-xl">CIMS</div>
              <div className="text-white/40 text-xs font-mono">Spring Boot · Java 8</div>
            </div>
          </div>
          <h1 className="font-display font-bold text-white text-5xl leading-tight mb-6">
            Credit Information<br />
            <span className="text-transparent bg-clip-text" style={{backgroundImage:'linear-gradient(135deg,#4361ee,#f72585)'}}>
              Management System
            </span>
          </h1>
          <p className="text-white/50 text-lg leading-relaxed mb-10">
            Enterprise-grade credit risk platform with microservices architecture. Secure, scalable, and built for financial institutions.
          </p>
          <div className="grid grid-cols-2 gap-4">
            {[
              {label:'Microservices', value:'5 Services'},
              {label:'Architecture', value:'Spring Boot'},
              {label:'API Gateway', value:'Spring Cloud'},
              {label:'Database', value:'PostgreSQL'},
            ].map(item => (
              <div key={item.label} className="bg-white/5 rounded-xl p-4 border border-white/10">
                <div className="text-white/40 text-xs font-mono uppercase mb-1">{item.label}</div>
                <div className="text-white font-display font-semibold">{item.value}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right login panel */}
      <div className="flex items-center justify-center w-full lg:w-1/2 px-6 relative z-10">
        <div className="w-full max-w-md animate-fade-in">
          <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
            {/* Card header */}
            <div className="px-8 pt-8 pb-6 border-b border-surface-100">
              <div className="lg:hidden flex items-center gap-2 mb-6">
                <Shield size={20} className="text-primary-500" />
                <span className="font-display font-bold text-surface-900">CIMS</span>
              </div>
              <h2 className="font-display font-bold text-surface-900 text-2xl">
                {requiresMfa ? 'Two-Factor Auth' : 'Sign In'}
              </h2>
              <p className="text-surface-500 text-sm mt-1">
                {requiresMfa ? 'Enter your authenticator code' : 'Enter your credentials to continue'}
              </p>
            </div>

            <div className="px-8 py-6">
              {error && (
                <div className="flex items-start gap-2.5 p-3.5 bg-red-50 border border-red-100 rounded-xl mb-5 text-red-700 text-sm">
                  <AlertTriangle size={16} className="mt-0.5 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                {!requiresMfa ? (
                  <>
                    <div>
                      <label className="label">Username or Email</label>
                      <div className="relative">
                        <User size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-surface-400" />
                        <input {...register('username')} className="input pl-9" placeholder="username or email" autoComplete="username" />
                      </div>
                      {errors.username && <p className="text-red-500 text-xs mt-1">{errors.username.message}</p>}
                    </div>
                    <div>
                      <label className="label">Password</label>
                      <div className="relative">
                        <Lock size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-surface-400" />
                        <input {...register('password')} type={showPw ? 'text' : 'password'} className="input pl-9 pr-10" placeholder="••••••••" autoComplete="current-password" />
                        <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-surface-400 hover:text-surface-600">
                          {showPw ? <EyeOff size={15} /> : <Eye size={15} />}
                        </button>
                      </div>
                      {errors.password && <p className="text-red-500 text-xs mt-1">{errors.password.message}</p>}
                    </div>
                  </>
                ) : (
                  <div>
                    <label className="label">Authentication Code</label>
                    <input {...register('mfaToken')} className="input text-center text-2xl tracking-[0.5em] font-mono" placeholder="000000" maxLength={6} autoFocus />
                  </div>
                )}

                <button type="submit" disabled={isSubmitting} className="btn-primary w-full justify-center py-3 mt-2">
                  {isSubmitting && <Loader2 size={15} className="animate-spin" />}
                  {isSubmitting ? 'Authenticating...' : requiresMfa ? 'Verify Code' : 'Sign In'}
                </button>
              </form>
            </div>
          </div>

          <p className="text-center text-white/25 text-xs mt-6 font-mono">
            CIMS Platform · Spring Boot 2.7 · Java 8 · TLS 1.3
          </p>
        </div>
      </div>
    </div>
  );
}