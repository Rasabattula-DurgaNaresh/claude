export function BatchPage() {
  return (
    <div className="p-6 animate-fade-in">
      <div className="page-header">
        <h1 className="page-title">Spring Batch Jobs</h1>
        <p className="page-subtitle">Downstream dispatch & reconciliation</p>
      </div>
      <div className="card p-8 text-center">
        <div className="max-w-lg mx-auto">
          <div className="w-16 h-16 bg-primary-50 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <span className="text-primary-500 text-2xl">⚙</span>
          </div>
          <h3 className="font-display font-bold text-surface-900 text-lg mb-2">Spring Batch Jobs Module</h3>
          <p className="text-surface-500 text-sm leading-relaxed">Manage Spring Batch jobs for dispatching credit data to ICM, RLS, PDW, RDS, CCMS, PROBE, OAMS, EDMP, ECARS and Business Report Server.</p>
        </div>
      </div>
    </div>
  );
}
