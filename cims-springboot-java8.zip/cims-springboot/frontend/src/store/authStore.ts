import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { authApi } from '../services/authApi';

interface User { id: string; username: string; email: string; role: string; fullName: string; mfaEnabled: boolean; }
interface AuthState {
  user: User | null;
  accessToken: string | null;
  refreshToken: string | null;
  isAuthenticated: boolean;
  login: (username: string, password: string, mfaToken?: string) => Promise<any>;
  logout: () => Promise<void>;
  setTokens: (access: string, refresh?: string) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null, accessToken: null, refreshToken: null, isAuthenticated: false,
      login: async (username, password, mfaToken) => {
        const data = await authApi.login(username, password, mfaToken);
        if (data.requiresMfa) return data;
        set({ user: data.user, accessToken: data.accessToken, refreshToken: data.refreshToken, isAuthenticated: true });
        return data;
      },
      logout: async () => {
        try { await authApi.logout(); } catch {}
        set({ user: null, accessToken: null, refreshToken: null, isAuthenticated: false });
      },
      setTokens: (access, refresh) => set(s => ({ accessToken: access, refreshToken: refresh || s.refreshToken })),
    }),
    { name: 'cims-auth', partialize: s => ({ user: s.user, accessToken: s.accessToken, refreshToken: s.refreshToken, isAuthenticated: s.isAuthenticated }) }
  )
);