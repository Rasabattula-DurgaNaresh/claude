package com.cims.common.util;

import io.jsonwebtoken.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Component
public class JwtUtil {

    @Value("${cims.jwt.secret}")
    private String jwtSecret;

    @Value("${cims.jwt.expiration:3600000}")
    private Long jwtExpiration;

    @Value("${cims.jwt.refresh-expiration:604800000}")
    private Long refreshExpiration;

    public String generateToken(String username, String role, String userId) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("role", role);
        claims.put("userId", userId);
        return buildToken(claims, username, jwtExpiration);
    }

    public String generateRefreshToken(String username) {
        return buildToken(new HashMap<>(), username, refreshExpiration);
    }

    private String buildToken(Map<String, Object> claims, String subject, Long expiration) {
        return Jwts.builder()
                .setClaims(claims)
                .setSubject(subject)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + expiration))
                .signWith(SignatureAlgorithm.HS512, jwtSecret)
                .compact();
    }

    public String extractUsername(String token) {
        return extractClaims(token).getSubject();
    }

    public String extractRole(String token) {
        return (String) extractClaims(token).get("role");
    }

    public String extractUserId(String token) {
        return (String) extractClaims(token).get("userId");
    }

    public boolean validateToken(String token) {
        try {
            extractClaims(token);
            return true;
        } catch (SignatureException e)   { log.error("Invalid JWT signature: {}", e.getMessage()); }
        catch (MalformedJwtException e)  { log.error("Invalid JWT token: {}", e.getMessage()); }
        catch (ExpiredJwtException e)    { log.error("JWT token is expired: {}", e.getMessage()); }
        catch (UnsupportedJwtException e){ log.error("JWT token is unsupported: {}", e.getMessage()); }
        catch (IllegalArgumentException e){ log.error("JWT claims string is empty: {}", e.getMessage()); }
        return false;
    }

    public boolean isTokenExpired(String token) {
        return extractClaims(token).getExpiration().before(new Date());
    }

    private Claims extractClaims(String token) {
        return Jwts.parser().setSigningKey(jwtSecret).parseClaimsJws(token).getBody();
    }
}
