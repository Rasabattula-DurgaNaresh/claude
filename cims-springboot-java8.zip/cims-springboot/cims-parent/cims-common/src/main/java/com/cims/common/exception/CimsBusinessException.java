package com.cims.common.exception;

import org.springframework.http.HttpStatus;
import lombok.Getter;

@Getter
public class CimsBusinessException extends RuntimeException {
    private final String errorCode;
    private final HttpStatus httpStatus;

    public CimsBusinessException(String message, String errorCode, HttpStatus httpStatus) {
        super(message);
        this.errorCode = errorCode;
        this.httpStatus = httpStatus;
    }

    public static CimsBusinessException badRequest(String message, String errorCode) {
        return new CimsBusinessException(message, errorCode, HttpStatus.BAD_REQUEST);
    }

    public static CimsBusinessException conflict(String message, String errorCode) {
        return new CimsBusinessException(message, errorCode, HttpStatus.CONFLICT);
    }
}
