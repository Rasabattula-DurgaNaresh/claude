package com.cims.auth.dto;

import lombok.Data;
import javax.validation.constraints.*;

@Data
public class RegisterRequest {
    @NotBlank @Size(min = 3, max = 100)
    private String username;

    @NotBlank @Email @Size(max = 255)
    private String email;

    @NotBlank @Size(min = 8, max = 128)
    @Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$",
             message = "Password must contain uppercase, lowercase, digit and special character")
    private String password;

    @NotBlank @Size(max = 255)
    private String fullName;

    @Size(max = 100)
    private String department;

    private String role;
}
