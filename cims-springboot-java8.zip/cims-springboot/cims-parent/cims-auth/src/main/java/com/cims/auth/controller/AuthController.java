package com.cims.auth.controller;

import com.cims.auth.dto.*;
import com.cims.auth.entity.User;
import com.cims.auth.repository.UserRepository;
import com.cims.auth.service.AuthService;
import com.cims.common.dto.ApiResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@Api(tags = "Authentication")
public class AuthController {

    private final AuthService authService;
    private final UserRepository userRepository;

    @PostMapping("/login")
    @ApiOperation("User login")
    public ResponseEntity<ApiResponse<LoginResponse>> login(
            @Valid @RequestBody LoginRequest request, HttpServletRequest httpRequest) {
        LoginResponse response = authService.login(request, httpRequest.getRemoteAddr());
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @PostMapping("/refresh")
    @ApiOperation("Refresh access token")
    public ResponseEntity<ApiResponse<LoginResponse>> refresh(@RequestBody java.util.Map<String, String> body) {
        LoginResponse response = authService.refreshToken(body.get("refreshToken"));
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @PostMapping("/logout")
    @ApiOperation("Logout current session")
    public ResponseEntity<ApiResponse<Void>> logout(Authentication auth) {
        String userId = (String) auth.getDetails();
        authService.logout(userId);
        return ResponseEntity.ok(ApiResponse.success("Logged out successfully", null));
    }

    @GetMapping("/me")
    @ApiOperation("Get current user profile")
    public ResponseEntity<ApiResponse<User>> getProfile(Authentication auth) {
        String userId = (String) auth.getDetails();
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new com.cims.common.exception.ResourceNotFoundException("User", userId));
        return ResponseEntity.ok(ApiResponse.success(user));
    }

    @PostMapping("/register")
    @ApiOperation("Register new user (Admin only)")
    public ResponseEntity<ApiResponse<User>> register(@Valid @RequestBody RegisterRequest request) {
        User user = authService.register(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.success("User registered successfully", user));
    }

    @PostMapping("/change-password")
    @ApiOperation("Change password")
    public ResponseEntity<ApiResponse<Void>> changePassword(
            @Valid @RequestBody ChangePasswordRequest request, Authentication auth) {
        String userId = (String) auth.getDetails();
        authService.changePassword(userId, request);
        return ResponseEntity.ok(ApiResponse.success("Password changed. Please login again.", null));
    }

    @GetMapping("/health")
    public ResponseEntity<ApiResponse<String>> health() {
        return ResponseEntity.ok(ApiResponse.success("Auth service is healthy", null));
    }
}
