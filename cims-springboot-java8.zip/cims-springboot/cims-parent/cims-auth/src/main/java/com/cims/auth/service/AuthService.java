package com.cims.auth.service;

import com.cims.auth.dto.*;
import com.cims.auth.entity.RefreshToken;
import com.cims.auth.entity.User;
import com.cims.auth.repository.RefreshTokenRepository;
import com.cims.auth.repository.UserRepository;
import com.cims.common.audit.AuditService;
import com.cims.common.exception.CimsBusinessException;
import com.cims.common.util.JwtUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.DigestUtils;

import java.time.LocalDateTime;
import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final RefreshTokenRepository refreshTokenRepository;
    private final JwtUtil jwtUtil;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final AuditService auditService;
    private static final int MAX_FAILED_ATTEMPTS = 5;
    private static final int LOCK_DURATION_MINUTES = 15;

    @Transactional
    public LoginResponse login(LoginRequest request, String ipAddress) {
        User user = userRepository.findByUsernameOrEmail(request.getUsername(), request.getUsername())
                .orElseThrow(() -> new BadCredentialsException("Invalid credentials"));

        if (!user.isAccountNonLocked()) {
            throw CimsBusinessException.badRequest("Account is temporarily locked. Try again in " + LOCK_DURATION_MINUTES + " minutes.", "ACCOUNT_LOCKED");
        }

        if (user.getStatus() != User.UserStatus.ACTIVE) {
            throw CimsBusinessException.badRequest("Account is not active", "ACCOUNT_INACTIVE");
        }

        if (!passwordEncoder.matches(request.getPassword(), user.getPasswordHash())) {
            handleFailedLogin(user, ipAddress);
            throw new BadCredentialsException("Invalid credentials");
        }

        // MFA check
        if (user.isMfaEnabled() && (request.getMfaToken() == null || request.getMfaToken().isEmpty())) {
            return LoginResponse.builder().requiresMfa(true).build();
        }

        // Reset failed attempts on success
        userRepository.resetFailedAttempts(user.getId());
        user.setLastLogin(LocalDateTime.now());
        userRepository.save(user);

        String accessToken = jwtUtil.generateToken(user.getUsername(), user.getRole().name(), user.getId());
        String rawRefresh = UUID.randomUUID().toString();
        String refreshHash = DigestUtils.md5DigestAsHex(rawRefresh.getBytes());

        RefreshToken refreshToken = RefreshToken.builder()
                .user(user)
                .tokenHash(refreshHash)
                .expiresAt(LocalDateTime.now().plusDays(7))
                .build();
        refreshTokenRepository.save(refreshToken);

        auditService.log(user.getId(), user.getUsername(), "LOGIN", "USER", user.getId(), "SUCCESS", ipAddress);

        return LoginResponse.builder()
                .accessToken(accessToken)
                .refreshToken(rawRefresh)
                .tokenType("Bearer")
                .expiresIn(3600L)
                .user(LoginResponse.UserInfo.builder()
                        .id(user.getId())
                        .username(user.getUsername())
                        .email(user.getEmail())
                        .role(user.getRole().name())
                        .fullName(user.getFullName())
                        .mfaEnabled(user.isMfaEnabled())
                        .build())
                .build();
    }

    private void handleFailedLogin(User user, String ipAddress) {
        userRepository.incrementFailedAttempts(user.getId());
        if (user.getFailedAttempts() + 1 >= MAX_FAILED_ATTEMPTS) {
            user.setLockedUntil(LocalDateTime.now().plusMinutes(LOCK_DURATION_MINUTES));
            userRepository.save(user);
            log.warn("User {} locked until {} due to failed attempts", user.getUsername(), user.getLockedUntil());
        }
        auditService.log(user.getId(), user.getUsername(), "LOGIN_FAILED", "USER", user.getId(), "FAILURE", ipAddress);
    }

    @Transactional
    public LoginResponse refreshToken(String rawRefreshToken) {
        String hash = DigestUtils.md5DigestAsHex(rawRefreshToken.getBytes());
        RefreshToken refreshToken = refreshTokenRepository.findByTokenHashAndRevokedFalse(hash)
                .orElseThrow(() -> CimsBusinessException.badRequest("Invalid refresh token", "INVALID_TOKEN"));

        if (refreshToken.isExpired()) {
            refreshToken.setRevoked(true);
            refreshTokenRepository.save(refreshToken);
            throw CimsBusinessException.badRequest("Refresh token expired", "TOKEN_EXPIRED");
        }

        User user = refreshToken.getUser();
        String accessToken = jwtUtil.generateToken(user.getUsername(), user.getRole().name(), user.getId());

        return LoginResponse.builder()
                .accessToken(accessToken)
                .tokenType("Bearer")
                .expiresIn(3600L)
                .build();
    }

    @Transactional
    public void logout(String userId) {
        refreshTokenRepository.revokeAllByUserId(userId);
        auditService.log(userId, "", "LOGOUT", "USER", userId, "SUCCESS", null);
    }

    @Transactional
    public User register(RegisterRequest request) {
        if (userRepository.existsByUsername(request.getUsername())) {
            throw CimsBusinessException.conflict("Username already exists", "USERNAME_EXISTS");
        }
        if (userRepository.existsByEmail(request.getEmail())) {
            throw CimsBusinessException.conflict("Email already registered", "EMAIL_EXISTS");
        }

        User user = User.builder()
                .username(request.getUsername())
                .email(request.getEmail())
                .passwordHash(passwordEncoder.encode(request.getPassword()))
                .fullName(request.getFullName())
                .department(request.getDepartment())
                .role(request.getRole() != null ? User.UserRole.valueOf(request.getRole()) : User.UserRole.USER)
                .status(User.UserStatus.ACTIVE)
                .build();

        return userRepository.save(user);
    }

    @Transactional
    public void changePassword(String userId, ChangePasswordRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new CimsBusinessException("User not found", "NOT_FOUND", org.springframework.http.HttpStatus.NOT_FOUND));

        if (!passwordEncoder.matches(request.getCurrentPassword(), user.getPasswordHash())) {
            throw CimsBusinessException.badRequest("Current password is incorrect", "WRONG_PASSWORD");
        }

        user.setPasswordHash(passwordEncoder.encode(request.getNewPassword()));
        userRepository.save(user);
        refreshTokenRepository.revokeAllByUserId(userId);
        auditService.log(userId, user.getUsername(), "CHANGE_PASSWORD", "USER", userId, "SUCCESS", null);
    }
}
