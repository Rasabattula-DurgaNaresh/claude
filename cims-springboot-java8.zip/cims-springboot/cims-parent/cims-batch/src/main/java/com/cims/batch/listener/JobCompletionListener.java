package com.cims.batch.listener;

import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class JobCompletionListener extends JobExecutionListenerSupport {

    @Override
    public void beforeJob(JobExecution jobExecution) {
        log.info("Starting batch job: {}", jobExecution.getJobInstance().getJobName());
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
            log.info("Batch job COMPLETED: {} | Read: {} | Written: {} | Skipped: {}",
                jobExecution.getJobInstance().getJobName(),
                jobExecution.getStepExecutions().stream().mapToLong(s -> s.getReadCount()).sum(),
                jobExecution.getStepExecutions().stream().mapToLong(s -> s.getWriteCount()).sum(),
                jobExecution.getStepExecutions().stream().mapToLong(s -> s.getSkipCount()).sum());
        } else {
            log.error("Batch job FAILED: {} | Status: {}",
                jobExecution.getJobInstance().getJobName(), jobExecution.getStatus());
        }
    }
}
