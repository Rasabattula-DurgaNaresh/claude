package com.cims.batch.client;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor
public class DownstreamSystemClient {

    private final RestTemplate restTemplate;

    @Value("${cims.downstream.icm-url:http://icm.internal:8080}")
    private String icmUrl;
    @Value("${cims.downstream.rls-url:http://rls.internal:8080}")
    private String rlsUrl;
    @Value("${cims.downstream.pdw-url:http://pdw.internal:8080}")
    private String pdwUrl;
    @Value("${cims.downstream.rds-url:http://rds.internal:8080}")
    private String rdsUrl;
    @Value("${cims.downstream.ccms-url:http://ccms.internal:8080}")
    private String ccmsUrl;
    @Value("${cims.downstream.probe-url:http://probe.internal:8080}")
    private String probeUrl;
    @Value("${cims.downstream.oams-url:http://oams.internal:8080}")
    private String oamsUrl;
    @Value("${cims.downstream.edmp-url:http://edmp.internal:8080}")
    private String edmpUrl;
    @Value("${cims.downstream.ecars-url:http://ecars.internal:8080}")
    private String ecarsUrl;

    public void dispatch(String system, List<? extends Map<String, Object>> records) {
        String url = resolveUrl(system);
        if (url == null) {
            log.warn("No URL configured for system: {}", system);
            return;
        }

        Map<String, Object> payload = new HashMap<>();
        payload.put("sourceSystem", "CIMS");
        payload.put("targetSystem", system);
        payload.put("records", records);
        payload.put("recordCount", records.size());

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("X-Source-System", "CIMS-BATCH");

        ResponseEntity<Map> response = restTemplate.exchange(
            url + "/cims/ingest", HttpMethod.POST,
            new HttpEntity<>(payload, headers), Map.class);

        if (!response.getStatusCode().is2xxSuccessful()) {
            throw new RuntimeException("Dispatch to " + system + " failed with status: " + response.getStatusCode());
        }
    }

    private String resolveUrl(String system) {
        switch (system) {
            case "ICM": return icmUrl;
            case "RLS": return rlsUrl;
            case "PDW": return pdwUrl;
            case "RDS": return rdsUrl;
            case "CCMS": return ccmsUrl;
            case "PROBE": return probeUrl;
            case "OAMS": return oamsUrl;
            case "EDMP": return edmpUrl;
            case "ECARS": return ecarsUrl;
            default: return null;
        }
    }
}
