package com.cims.batch.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class BatchSchedulerService {

    private final JobLauncher jobLauncher;
    private final Job downstreamDispatchJob;

    // Run daily at 2:00 AM
    @Scheduled(cron = "${cims.batch.cron.downstream:0 0 2 * * ?}")
    public void runDownstreamDispatch() {
        log.info("Triggering scheduled downstream dispatch job");
        runJob(downstreamDispatchJob, "scheduled-dispatch");
    }

    // Run every 6 hours - reconciliation
    @Scheduled(cron = "${cims.batch.cron.reconciliation:0 0 */6 * * ?}")
    public void runReconciliation() {
        log.info("Triggering scheduled reconciliation job");
        // Additional reconciliation logic
    }

    public void runJob(Job job, String source) {
        try {
            JobParameters params = new JobParametersBuilder()
                    .addLong("timestamp", System.currentTimeMillis())
                    .addString("source", source)
                    .toJobParameters();
            jobLauncher.run(job, params);
        } catch (Exception e) {
            log.error("Failed to launch batch job: {}", e.getMessage(), e);
        }
    }
}
