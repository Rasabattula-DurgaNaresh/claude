package com.cims.batch.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class BatchConfig {
    @Bean
    public RestTemplate restTemplate() {
        return new org.springframework.boot.web.client.RestTemplateBuilder()
                .setConnectTimeout(java.time.Duration.ofSeconds(5))
                .setReadTimeout(java.time.Duration.ofSeconds(60))
                .build();
    }
}
