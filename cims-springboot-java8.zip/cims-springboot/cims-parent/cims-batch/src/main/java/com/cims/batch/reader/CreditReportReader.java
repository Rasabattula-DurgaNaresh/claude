package com.cims.batch.reader;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.ColumnMapRowMapper;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor
public class CreditReportReader {

    private final DataSource dataSource;

    @Bean
    public JdbcCursorItemReader<Map<String, Object>> creditReportItemReader() {
        return new JdbcCursorItemReaderBuilder<Map<String, Object>>()
                .name("creditReportReader")
                .dataSource(dataSource)
                .sql("SELECT be.id, be.status, be.credit_score, be.risk_grade, " +
                     "cs.national_id, cs.full_name, cs.subject_type " +
                     "FROM bureau_enquiries be " +
                     "JOIN credit_subjects cs ON be.subject_id = cs.id " +
                     "WHERE be.status = 'COMPLETED' " +
                     "AND be.created_at > NOW() - INTERVAL '24 hours' " +
                     "ORDER BY be.created_at ASC")
                .rowMapper(new ColumnMapRowMapper())
                .fetchSize(100)
                .build();
    }
}
