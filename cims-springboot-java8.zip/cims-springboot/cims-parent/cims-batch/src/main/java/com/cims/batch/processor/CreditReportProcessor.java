package com.cims.batch.processor;

import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Component
public class CreditReportProcessor implements ItemProcessor<Map<String, Object>, Map<String, Object>> {

    @Override
    public Map<String, Object> process(Map<String, Object> item) throws Exception {
        Map<String, Object> processed = new HashMap<>(item);
        processed.put("processedAt", LocalDateTime.now().toString());
        processed.put("sourceSystem", "CIMS");
        processed.put("batchId", System.getProperty("batch.jobId", "UNKNOWN"));

        // Enrich with computed fields
        Integer score = (Integer) item.get("credit_score");
        if (score != null) {
            processed.put("riskCategory", classifyRisk(score));
        }

        log.debug("Processed credit report for: {}", item.get("national_id"));
        return processed;
    }

    private String classifyRisk(int score) {
        if (score >= 750) return "EXCELLENT";
        if (score >= 650) return "GOOD";
        if (score >= 550) return "FAIR";
        if (score >= 450) return "POOR";
        return "VERY_POOR";
    }
}
