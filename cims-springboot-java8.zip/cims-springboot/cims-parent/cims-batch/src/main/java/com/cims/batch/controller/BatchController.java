package com.cims.batch.controller;

import com.cims.batch.service.BatchSchedulerService;
import com.cims.common.dto.ApiResponse;
import io.swagger.annotations.Api;
import lombok.RequiredArgsConstructor;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/batch")
@RequiredArgsConstructor
@Api(tags = "Batch Service")
public class BatchController {

    private final BatchSchedulerService schedulerService;
    private final JobExplorer jobExplorer;
    private final Job downstreamDispatchJob;

    @PostMapping("/trigger/downstream-dispatch")
    @PreAuthorize("hasAnyRole('ADMIN', 'BATCH_OPERATOR')")
    public ResponseEntity<ApiResponse<String>> triggerDispatch() {
        schedulerService.runJob(downstreamDispatchJob, "manual-trigger");
        return ResponseEntity.ok(ApiResponse.success("Downstream dispatch job triggered", null));
    }

    @GetMapping("/jobs")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getJobInfo() {
        Map<String, Object> info = new HashMap<>();
        info.put("jobNames", jobExplorer.getJobNames());
        info.put("lastRunTime", jobExplorer.getLastJobInstance("downstreamDispatchJob", 1));
        return ResponseEntity.ok(ApiResponse.success(info));
    }

    @GetMapping("/health")
    public ResponseEntity<ApiResponse<String>> health() {
        return ResponseEntity.ok(ApiResponse.success("Batch service healthy", null));
    }
}
