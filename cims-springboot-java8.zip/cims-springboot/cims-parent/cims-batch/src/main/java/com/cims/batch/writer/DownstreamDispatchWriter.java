package com.cims.batch.writer;

import com.cims.batch.client.DownstreamSystemClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor
public class DownstreamDispatchWriter implements ItemWriter<Map<String, Object>> {

    private final DownstreamSystemClient downstreamClient;

    private static final String[] DOWNSTREAM_SYSTEMS = {
        "ICM", "RLS", "PDW", "RDS", "CCMS", "PROBE", "OAMS", "EDMP", "ECARS"
    };

    @Override
    public void write(List<? extends Map<String, Object>> items) throws Exception {
        log.info("Dispatching {} records to downstream systems", items.size());

        for (String system : DOWNSTREAM_SYSTEMS) {
            try {
                downstreamClient.dispatch(system, items);
                log.info("Dispatched {} records to {}", items.size(), system);
            } catch (Exception e) {
                log.error("Failed to dispatch to system {}: {}", system, e.getMessage());
                // Continue with next system - individual failures are tolerated
            }
        }
    }
}
