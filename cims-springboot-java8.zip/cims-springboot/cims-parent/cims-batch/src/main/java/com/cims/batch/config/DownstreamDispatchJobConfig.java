package com.cims.batch.config;

import com.cims.batch.listener.JobCompletionListener;
import com.cims.batch.processor.CreditReportProcessor;
import com.cims.batch.reader.CreditReportReader;
import com.cims.batch.writer.DownstreamDispatchWriter;
import lombok.RequiredArgsConstructor;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

@Configuration
@RequiredArgsConstructor
public class DownstreamDispatchJobConfig {

    private final JobBuilderFactory jobBuilderFactory;
    private final StepBuilderFactory stepBuilderFactory;
    private final CreditReportReader creditReportReader;
    private final CreditReportProcessor creditReportProcessor;
    private final DownstreamDispatchWriter dispatchWriter;
    private final JobCompletionListener jobCompletionListener;

    @Bean
    public Job downstreamDispatchJob() {
        return jobBuilderFactory.get("downstreamDispatchJob")
                .incrementer(new RunIdIncrementer())
                .listener(jobCompletionListener)
                .start(dispatchStep())
                .build();
    }

    @Bean
    public Step dispatchStep() {
        return stepBuilderFactory.get("dispatchStep")
                .<Map<String, Object>, Map<String, Object>>chunk(100)
                .reader(creditReportReader)
                .processor(creditReportProcessor)
                .writer(dispatchWriter)
                .faultTolerant()
                .retryLimit(3)
                .retry(Exception.class)
                .skipLimit(10)
                .skip(org.springframework.batch.item.ItemWriterException.class)
                .build();
    }
}
