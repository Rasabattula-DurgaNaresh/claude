package com.cims.bureau.service;

import com.cims.bureau.client.Iclnet2BureauClient;
import com.cims.bureau.dto.EnquiryRequest;
import com.cims.bureau.dto.EnquiryResponse;
import com.cims.bureau.entity.BureauEnquiry;
import com.cims.bureau.entity.CreditSubject;
import com.cims.bureau.repository.BureauEnquiryRepository;
import com.cims.bureau.repository.CreditSubjectRepository;
import com.cims.common.audit.AuditService;
import com.cims.common.dto.PageResponse;
import com.cims.common.exception.ResourceNotFoundException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class BureauEnquiryService {

    private final BureauEnquiryRepository enquiryRepository;
    private final CreditSubjectRepository subjectRepository;
    private final Iclnet2BureauClient iclnet2Client;
    private final AuditService auditService;
    private final ObjectMapper objectMapper;

    @Transactional
    public EnquiryResponse submitEnquiry(EnquiryRequest request, String userId) {
        CreditSubject subject = subjectRepository.findById(request.getSubjectId())
                .orElseThrow(() -> new ResourceNotFoundException("CreditSubject", request.getSubjectId()));

        BureauEnquiry enquiry = BureauEnquiry.builder()
                .subject(subject)
                .enquiryType(request.getEnquiryType())
                .purpose(request.getPurpose())
                .status(BureauEnquiry.EnquiryStatus.PENDING)
                .requestedBy(userId)
                .sourceSystem("CIMS")
                .build();
        enquiry = enquiryRepository.save(enquiry);

        // Call ICLNET2 asynchronously
        processEnquiryAsync(enquiry.getId(), subject, request);

        auditService.log(userId, "", "BUREAU_ENQUIRY", "BureauEnquiry", enquiry.getId(), "SUBMITTED", null);

        return EnquiryResponse.builder()
                .enquiryId(enquiry.getId())
                .status(enquiry.getStatus().name())
                .message("Enquiry submitted successfully")
                .build();
    }

    @Async
    public void processEnquiryAsync(String enquiryId, CreditSubject subject, EnquiryRequest request) {
        BureauEnquiry enquiry = enquiryRepository.findById(enquiryId).orElse(null);
        if (enquiry == null) return;

        try {
            enquiry.setStatus(BureauEnquiry.EnquiryStatus.IN_PROGRESS);
            enquiryRepository.save(enquiry);

            Map<String, Object> payload = new HashMap<>();
            payload.put("subjectId", subject.getId());
            payload.put("nationalId", subject.getNationalId());
            payload.put("fullName", subject.getFullName());
            payload.put("enquiryType", request.getEnquiryType());
            payload.put("purpose", request.getPurpose());

            Map<String, Object> response = iclnet2Client.submitEnquiry(
                    UUID.randomUUID().toString(), "CIMS", payload);

            enquiry.setStatus(BureauEnquiry.EnquiryStatus.COMPLETED);
            enquiry.setCreditScore((Integer) response.get("creditScore"));
            enquiry.setRiskGrade((String) response.get("riskGrade"));
            enquiry.setBureauReference((String) response.get("reference"));
            enquiry.setResponseData(objectMapper.writeValueAsString(response));
        } catch (Exception e) {
            log.error("Bureau enquiry {} failed: {}", enquiryId, e.getMessage());
            enquiry.setStatus(BureauEnquiry.EnquiryStatus.FAILED);
            enquiry.setErrorMessage(e.getMessage());
        }
        enquiryRepository.save(enquiry);
    }

    @Transactional(readOnly = true)
    public EnquiryResponse getEnquiry(String enquiryId) {
        BureauEnquiry enquiry = enquiryRepository.findById(enquiryId)
                .orElseThrow(() -> new ResourceNotFoundException("BureauEnquiry", enquiryId));
        return EnquiryResponse.builder()
                .enquiryId(enquiry.getId())
                .status(enquiry.getStatus().name())
                .creditScore(enquiry.getCreditScore())
                .riskGrade(enquiry.getRiskGrade())
                .bureauReference(enquiry.getBureauReference())
                .build();
    }

    @Transactional(readOnly = true)
    public PageResponse<EnquiryResponse> getEnquiriesBySubject(String subjectId, Pageable pageable) {
        return PageResponse.of(enquiryRepository.findBySubjectId(subjectId, pageable)
                .map(e -> EnquiryResponse.builder()
                        .enquiryId(e.getId())
                        .status(e.getStatus().name())
                        .creditScore(e.getCreditScore())
                        .riskGrade(e.getRiskGrade())
                        .build()));
    }
}
