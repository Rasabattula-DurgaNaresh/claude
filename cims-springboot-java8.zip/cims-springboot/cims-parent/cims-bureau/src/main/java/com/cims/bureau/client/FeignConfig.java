package com.cims.bureau.client;

import feign.Logger;
import feign.Request;
import feign.Retryer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.util.concurrent.TimeUnit;

@Configuration
public class FeignConfig {
    @Bean
    public Logger.Level feignLogLevel() { return Logger.Level.BASIC; }

    @Bean
    public Request.Options options() {
        return new Request.Options(5, TimeUnit.SECONDS, 30, TimeUnit.SECONDS, true);
    }

    @Bean
    public Retryer retryer() {
        return new Retryer.Default(500L, 2000L, 3);
    }
}
