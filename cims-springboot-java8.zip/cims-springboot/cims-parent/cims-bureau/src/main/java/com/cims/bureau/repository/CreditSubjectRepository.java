package com.cims.bureau.repository;

import com.cims.bureau.entity.CreditSubject;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface CreditSubjectRepository extends JpaRepository<CreditSubject, String> {
    Optional<CreditSubject> findByNationalId(String nationalId);
    Optional<CreditSubject> findByCompanyRegNo(String companyRegNo);
}
