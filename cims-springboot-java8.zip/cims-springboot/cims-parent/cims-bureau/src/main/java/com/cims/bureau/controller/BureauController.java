package com.cims.bureau.controller;

import com.cims.bureau.dto.EnquiryRequest;
import com.cims.bureau.dto.EnquiryResponse;
import com.cims.bureau.entity.CreditSubject;
import com.cims.bureau.repository.CreditSubjectRepository;
import com.cims.bureau.service.BureauEnquiryService;
import com.cims.bureau.service.MinioStorageService;
import com.cims.common.dto.ApiResponse;
import com.cims.common.dto.PageResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Map;

@RestController
@RequestMapping("/api/bureau")
@RequiredArgsConstructor
@Api(tags = "Bureau Service")
public class BureauController {

    private final BureauEnquiryService enquiryService;
    private final CreditSubjectRepository subjectRepository;
    private final MinioStorageService minioService;

    @PostMapping("/enquiry")
    @ApiOperation("Submit a bureau enquiry")
    public ResponseEntity<ApiResponse<EnquiryResponse>> submitEnquiry(
            @Valid @RequestBody EnquiryRequest request, Authentication auth) {
        String userId = (String) auth.getDetails();
        EnquiryResponse response = enquiryService.submitEnquiry(request, userId);
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(ApiResponse.success(response));
    }

    @GetMapping("/enquiry/{enquiryId}")
    @ApiOperation("Get enquiry result")
    public ResponseEntity<ApiResponse<EnquiryResponse>> getEnquiry(@PathVariable String enquiryId) {
        return ResponseEntity.ok(ApiResponse.success(enquiryService.getEnquiry(enquiryId)));
    }

    @GetMapping("/subject/{subjectId}/enquiries")
    @ApiOperation("Get all enquiries for a subject")
    public ResponseEntity<ApiResponse<PageResponse<EnquiryResponse>>> getSubjectEnquiries(
            @PathVariable String subjectId, @PageableDefault(size = 20) Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success(enquiryService.getEnquiriesBySubject(subjectId, pageable)));
    }

    @PostMapping("/subject")
    @ApiOperation("Create credit subject")
    public ResponseEntity<ApiResponse<CreditSubject>> createSubject(@RequestBody CreditSubject subject) {
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.success(subjectRepository.save(subject)));
    }

    @PostMapping("/upload")
    @ApiOperation("Upload document to MinIO storage")
    public ResponseEntity<ApiResponse<Map<String, String>>> uploadDocument(@RequestBody Map<String, String> body) {
        String storedName = minioService.uploadFile(
            body.get("filename"), body.get("content"), body.get("contentType"));
        return ResponseEntity.ok(ApiResponse.success(java.util.Collections.singletonMap("storedName", storedName)));
    }

    @GetMapping("/health")
    public ResponseEntity<ApiResponse<String>> health() {
        return ResponseEntity.ok(ApiResponse.success("Bureau service healthy", null));
    }
}
