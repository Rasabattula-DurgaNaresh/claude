package com.cims.bureau.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EnquiryResponse {
    private String enquiryId;
    private String status;
    private String message;
    private Integer creditScore;
    private String riskGrade;
    private String bureauReference;
    private String responseData;
}
