package com.cims.bureau.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import java.util.Map;

@FeignClient(name = "iclnet2-bureau", url = "${cims.iclnet2.bureau-url}", configuration = FeignConfig.class)
public interface Iclnet2BureauClient {

    @PostMapping("/enquiry")
    Map<String, Object> submitEnquiry(
        @RequestHeader("X-Request-ID") String requestId,
        @RequestHeader("X-Source-System") String sourceSystem,
        @RequestBody Map<String, Object> payload);

    @PostMapping("/batch-enquiry")
    Map<String, Object> submitBatchEnquiry(
        @RequestHeader("X-Request-ID") String requestId,
        @RequestBody java.util.List<Map<String, Object>> payload);
}
