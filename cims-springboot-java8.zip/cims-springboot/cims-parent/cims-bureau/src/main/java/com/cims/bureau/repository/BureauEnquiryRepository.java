package com.cims.bureau.repository;

import com.cims.bureau.entity.BureauEnquiry;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BureauEnquiryRepository extends JpaRepository<BureauEnquiry, String> {
    Page<BureauEnquiry> findBySubjectId(String subjectId, Pageable pageable);
    List<BureauEnquiry> findByStatusAndCreatedAtBefore(
        BureauEnquiry.EnquiryStatus status, java.time.LocalDateTime before);

    @Query("SELECT e FROM BureauEnquiry e WHERE e.requestedBy = :userId ORDER BY e.createdAt DESC")
    Page<BureauEnquiry> findByRequestedBy(String userId, Pageable pageable);
}
