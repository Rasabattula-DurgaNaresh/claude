package com.cims.bureau.entity;

import com.cims.common.entity.BaseEntity;
import lombok.*;
import javax.persistence.*;

@Entity
@Table(name = "credit_subjects", indexes = {
    @Index(name = "idx_cs_national_id", columnList = "national_id", unique = true),
    @Index(name = "idx_cs_company_reg", columnList = "company_reg_no")
})
@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class CreditSubject extends BaseEntity {

    @Enumerated(EnumType.STRING)
    @Column(name = "subject_type", length = 20, nullable = false)
    private SubjectType subjectType;

    @Column(name = "national_id", length = 50, unique = true)
    private String nationalId;

    @Column(name = "company_reg_no", length = 50)
    private String companyRegNo;

    @Column(name = "full_name", length = 500, nullable = false)
    private String fullName;

    @Column(name = "date_of_birth")
    private java.time.LocalDate dateOfBirth;

    @Column(name = "address", columnDefinition = "TEXT")
    private String address;

    @Column(name = "phone", length = 50)
    private String phone;

    @Column(name = "email", length = 255)
    private String email;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 20)
    private SubjectStatus status = SubjectStatus.ACTIVE;

    public enum SubjectType { INDIVIDUAL, CORPORATE }
    public enum SubjectStatus { ACTIVE, INACTIVE, BLACKLISTED }
}
