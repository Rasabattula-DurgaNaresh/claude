package com.cims.bureau.entity;

import com.cims.common.entity.BaseEntity;
import lombok.*;
import javax.persistence.*;

@Entity
@Table(name = "bureau_enquiries", indexes = {
    @Index(name = "idx_be_subject", columnList = "subject_id"),
    @Index(name = "idx_be_status", columnList = "status")
})
@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class BureauEnquiry extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "subject_id", nullable = false)
    private CreditSubject subject;

    @Column(name = "enquiry_type", length = 50)
    private String enquiryType;

    @Column(name = "purpose", length = 255)
    private String purpose;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 30)
    private EnquiryStatus status = EnquiryStatus.PENDING;

    @Column(name = "credit_score")
    private Integer creditScore;

    @Column(name = "risk_grade", length = 10)
    private String riskGrade;

    @Column(name = "bureau_reference", length = 255)
    private String bureauReference;

    @Column(name = "response_data", columnDefinition = "TEXT")
    private String responseData;

    @Column(name = "error_message", length = 500)
    private String errorMessage;

    @Column(name = "requested_by", length = 100)
    private String requestedBy;

    @Column(name = "source_system", length = 50)
    private String sourceSystem;

    public enum EnquiryStatus { PENDING, IN_PROGRESS, COMPLETED, FAILED, TIMEOUT }
}
