package com.cims.bureau.service;

import io.minio.*;
import io.minio.http.Method;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Base64;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

@Slf4j
@Service
@RequiredArgsConstructor
public class MinioStorageService {

    private final MinioClient minioClient;

    @Value("${cims.minio.bucket:cims-documents}")
    private String bucket;

    public String uploadFile(String originalName, String base64Content, String contentType) {
        try {
            ensureBucketExists();
            String storedName = UUID.randomUUID() + "-" + originalName;
            byte[] data = Base64.getDecoder().decode(base64Content);

            minioClient.putObject(PutObjectArgs.builder()
                    .bucket(bucket)
                    .object(storedName)
                    .stream(new ByteArrayInputStream(data), data.length, -1)
                    .contentType(contentType != null ? contentType : "application/octet-stream")
                    .build());

            log.info("Uploaded file {} as {}", originalName, storedName);
            return storedName;
        } catch (Exception e) {
            log.error("Failed to upload file {}", originalName, e);
            throw new RuntimeException("File upload failed: " + e.getMessage(), e);
        }
    }

    public String getPresignedUrl(String storedName) {
        try {
            return minioClient.getPresignedObjectUrl(GetPresignedObjectUrlArgs.builder()
                    .method(Method.GET)
                    .bucket(bucket)
                    .object(storedName)
                    .expiry(1, TimeUnit.HOURS)
                    .build());
        } catch (Exception e) {
            throw new RuntimeException("Failed to generate presigned URL", e);
        }
    }

    public void deleteFile(String storedName) {
        try {
            minioClient.removeObject(RemoveObjectArgs.builder().bucket(bucket).object(storedName).build());
        } catch (Exception e) {
            log.error("Failed to delete file {}", storedName, e);
        }
    }

    private void ensureBucketExists() throws Exception {
        boolean exists = minioClient.bucketExists(BucketExistsArgs.builder().bucket(bucket).build());
        if (!exists) {
            minioClient.makeBucket(MakeBucketArgs.builder().bucket(bucket).build());
            log.info("Created MinIO bucket: {}", bucket);
        }
    }
}
