package com.cims.bureau.dto;

import lombok.Data;
import javax.validation.constraints.NotBlank;

@Data
public class EnquiryRequest {
    @NotBlank
    private String subjectId;
    private String enquiryType = "STANDARD";
    private String purpose;
}
