
CREATE TABLE credit_subjects (
    id VARCHAR(36) PRIMARY KEY,
    subject_type VARCHAR(20) NOT NULL,
    national_id VARCHAR(50) UNIQUE,
    company_reg_no VARCHAR(50),
    full_name VARCHAR(500) NOT NULL,
    date_of_birth DATE,
    address TEXT,
    phone VARCHAR(50),
    email VARCHAR(255),
    status VARCHAR(20) DEFAULT 'ACTIVE',
    created_by VARCHAR(100), updated_by VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    version BIGINT DEFAULT 0
);

CREATE TABLE bureau_enquiries (
    id VARCHAR(36) PRIMARY KEY,
    subject_id VARCHAR(36) NOT NULL REFERENCES credit_subjects(id),
    enquiry_type VARCHAR(50),
    purpose VARCHAR(255),
    status VARCHAR(30) DEFAULT 'PENDING',
    credit_score INTEGER,
    risk_grade VARCHAR(10),
    bureau_reference VARCHAR(255),
    response_data TEXT,
    error_message VARCHAR(500),
    requested_by VARCHAR(100),
    source_system VARCHAR(50),
    created_by VARCHAR(100), updated_by VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    version BIGINT DEFAULT 0
);

CREATE TABLE document_files (
    id VARCHAR(36) PRIMARY KEY DEFAULT gen_random_uuid()::text,
    original_name VARCHAR(500) NOT NULL,
    stored_name VARCHAR(500) NOT NULL,
    bucket VARCHAR(100) NOT NULL,
    content_type VARCHAR(100),
    size_bytes BIGINT,
    entity_type VARCHAR(100),
    entity_id VARCHAR(36),
    uploaded_by VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_cs_national ON credit_subjects(national_id);
CREATE INDEX idx_be_subject ON bureau_enquiries(subject_id);
CREATE INDEX idx_be_status ON bureau_enquiries(status);
