package com.cims.mcra.service;

import com.cims.mcra.client.CrpClient;
import com.cims.mcra.client.OneConnectClient;
import com.cims.mcra.dto.AssessmentRequest;
import com.cims.mcra.dto.AssessmentResponse;
import com.cims.mcra.socket.TransUnionSocketService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

@Slf4j
@Service
@RequiredArgsConstructor
public class McraService {

    private final CrpClient crpClient;
    private final OneConnectClient oneConnectClient;
    private final TransUnionSocketService tuSocketService;
    private final ObjectMapper objectMapper;

    public AssessmentResponse assess(AssessmentRequest request, String userId) {
        String assessmentId = UUID.randomUUID().toString();
        log.info("Starting MCRA assessment {} for subject {}", assessmentId, request.getSubjectId());

        // 1. Query TransUnion via Socket Connection
        CompletableFuture<String> tuFuture = queryTransUnion(assessmentId, request);

        // 2. Submit to CRP via ICLNET2
        Map<String, Object> crpResult = submitToCrp(assessmentId, request);

        // 3. Lookup via OneConnect via ICLNET2
        Map<String, Object> ocResult = lookupOneConnect(assessmentId, request);

        // 4. Aggregate results
        String tuResponse = null;
        try { tuResponse = tuFuture.get(30, java.util.concurrent.TimeUnit.SECONDS); }
        catch (Exception e) { log.warn("TransUnion response timeout for {}", assessmentId); }

        int compositeScore = computeCompositeScore(crpResult, ocResult, tuResponse);
        String riskGrade = classifyRisk(compositeScore);

        return AssessmentResponse.builder()
                .assessmentId(assessmentId)
                .status("COMPLETED")
                .compositeScore(compositeScore)
                .riskGrade(riskGrade)
                .crpReference((String) crpResult.getOrDefault("referenceId", null))
                .build();
    }

    private CompletableFuture<String> queryTransUnion(String requestId, AssessmentRequest request) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("nationalId", request.getSubjectId());
        payload.put("queryType", request.getAssessmentType());
        return tuSocketService.query(requestId + "-TU", payload);
    }

    private Map<String, Object> submitToCrp(String requestId, AssessmentRequest request) {
        try {
            Map<String, Object> payload = new HashMap<>();
            payload.put("subjectId", request.getSubjectId());
            payload.put("assessmentType", request.getAssessmentType());
            payload.put("parameters", request.getParameters());
            return crpClient.submitRiskAssessment(requestId + "-CRP", payload);
        } catch (Exception e) {
            log.error("CRP call failed: {}", e.getMessage());
            return new HashMap<>();
        }
    }

    private Map<String, Object> lookupOneConnect(String requestId, AssessmentRequest request) {
        try {
            Map<String, Object> payload = new HashMap<>();
            payload.put("subjectId", request.getSubjectId());
            return oneConnectClient.lookup(requestId + "-OC", payload);
        } catch (Exception e) {
            log.error("OneConnect call failed: {}", e.getMessage());
            return new HashMap<>();
        }
    }

    private int computeCompositeScore(Map<String, Object> crp, Map<String, Object> oc, String tu) {
        // Weighted composite scoring
        int crpScore = crp.containsKey("score") ? Integer.parseInt(crp.get("score").toString()) : 500;
        int ocScore  = oc.containsKey("score")  ? Integer.parseInt(oc.get("score").toString())  : 500;
        int tuScore  = 500; // Default if TU unavailable
        try {
            if (tu != null) {
                Map<String, Object> tuData = objectMapper.readValue(tu, Map.class);
                if (tuData.containsKey("score")) tuScore = Integer.parseInt(tuData.get("score").toString());
            }
        } catch (Exception ignored) {}
        // Weighted: CRP 40%, OC 30%, TU 30%
        return (int)(crpScore * 0.4 + ocScore * 0.3 + tuScore * 0.3);
    }

    private String classifyRisk(int score) {
        if (score >= 750) return "A";
        if (score >= 650) return "B";
        if (score >= 550) return "C";
        if (score >= 450) return "D";
        return "E";
    }
}
