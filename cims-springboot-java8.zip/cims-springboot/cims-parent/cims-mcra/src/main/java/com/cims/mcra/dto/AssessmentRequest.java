package com.cims.mcra.dto;

import lombok.Data;
import javax.validation.constraints.NotBlank;
import java.util.Map;

@Data
public class AssessmentRequest {
    @NotBlank
    private String subjectId;
    private String assessmentType = "STANDARD";
    private Map<String, Object> parameters;
}
