package com.cims.mcra.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

/**
 * OneConnect — connects via ICLNET2 Kong OAG leased line
 */
@FeignClient(name = "oneconnect-client", url = "${cims.iclnet2.oneconnect-url}")
public interface OneConnectClient {
    @PostMapping("/lookup")
    Map<String, Object> lookup(
        @RequestHeader("X-Request-ID") String requestId,
        @RequestBody Map<String, Object> payload);

    @PostMapping("/verify")
    Map<String, Object> verify(
        @RequestHeader("X-Request-ID") String requestId,
        @RequestBody Map<String, Object> payload);
}
