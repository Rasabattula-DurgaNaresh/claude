package com.cims.mcra.socket;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.io.*;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.*;

/**
 * TransUnion (TU) connects via Socket Connection through ICLNET2/Kong EAG.
 * TU is NOT migrating to API — remains on socket/leased line per architecture notes.
 */
@Slf4j
@Service
public class TransUnionSocketService {

    @Value("${cims.transunion.host}")
    private String host;

    @Value("${cims.transunion.port:9443}")
    private int port;

    @Value("${cims.transunion.timeout:30000}")
    private int timeoutMs;

    @Value("${cims.transunion.enabled:false}")
    private boolean enabled;

    private Socket socket;
    private PrintWriter writer;
    private BufferedReader reader;
    private final ConcurrentHashMap<String, CompletableFuture<String>> pendingRequests = new ConcurrentHashMap<>();
    private ExecutorService listenerThread;
    private volatile boolean connected = false;
    private static final int RECONNECT_DELAY_MS = 5000;
    private static final int MAX_RETRY_ATTEMPTS = 3;

    @PostConstruct
    public void init() {
        if (!enabled) {
            log.info("TransUnion socket connection is DISABLED. Set cims.transunion.enabled=true to enable.");
            return;
        }
        connect();
        startListenerThread();
    }

    public synchronized void connect() {
        if (!enabled) return;
        int attempts = 0;
        while (!connected && attempts < MAX_RETRY_ATTEMPTS) {
            try {
                log.info("Connecting to TransUnion socket {}:{} (attempt {})", host, port, attempts + 1);
                socket = new Socket(host, port);
                socket.setSoTimeout(timeoutMs);
                writer = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
                reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                connected = true;
                log.info("TransUnion socket connected successfully");
            } catch (IOException e) {
                attempts++;
                log.error("TU socket connection attempt {} failed: {}", attempts, e.getMessage());
                if (attempts < MAX_RETRY_ATTEMPTS) {
                    try { Thread.sleep(RECONNECT_DELAY_MS); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
                }
            }
        }
    }

    private void startListenerThread() {
        listenerThread = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "tu-socket-listener");
            t.setDaemon(true);
            return t;
        });
        listenerThread.submit(() -> {
            while (!Thread.currentThread().isInterrupted()) {
                try {
                    if (!connected) { Thread.sleep(RECONNECT_DELAY_MS); connect(); continue; }
                    String line = reader.readLine();
                    if (line != null) handleResponse(line);
                } catch (SocketTimeoutException e) {
                    // Normal — send keepalive
                    sendKeepalive();
                } catch (IOException e) {
                    log.warn("TU socket read error, reconnecting: {}", e.getMessage());
                    connected = false;
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        });
    }

    public CompletableFuture<String> query(String requestId, Map<String, Object> payload) {
        if (!enabled || !connected) {
            return CompletableFuture.failedFuture(new RuntimeException("TransUnion socket not connected"));
        }
        CompletableFuture<String> future = new CompletableFuture<>();
        future.orTimeout(30, TimeUnit.SECONDS);
        pendingRequests.put(requestId, future);

        String message = buildMessage(requestId, payload);
        synchronized (this) { writer.println(message); }
        return future;
    }

    private void handleResponse(String line) {
        // Parse requestId from response and resolve corresponding future
        try {
            // Simple delimiter-based: "REQID|JSON_RESPONSE"
            int sep = line.indexOf('|');
            if (sep > 0) {
                String reqId = line.substring(0, sep);
                String responseJson = line.substring(sep + 1);
                CompletableFuture<String> future = pendingRequests.remove(reqId);
                if (future != null) future.complete(responseJson);
            }
        } catch (Exception e) {
            log.error("Error handling TU response: {}", e.getMessage());
        }
    }

    private String buildMessage(String requestId, Map<String, Object> payload) {
        // Custom socket protocol format for TU
        return requestId + "|" + payload.toString();
    }

    private void sendKeepalive() {
        try {
            if (connected && writer != null) writer.println("KEEPALIVE|" + UUID.randomUUID());
        } catch (Exception e) {
            log.warn("Keepalive failed: {}", e.getMessage());
        }
    }

    @PreDestroy
    public void disconnect() {
        connected = false;
        if (listenerThread != null) listenerThread.shutdownNow();
        try {
            if (socket != null && !socket.isClosed()) socket.close();
        } catch (IOException e) {
            log.error("Error closing TU socket", e);
        }
    }

    public boolean isConnected() { return connected; }
}
