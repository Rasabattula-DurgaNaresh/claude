package com.cims.mcra.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

/**
 * CRP (Credit Risk Platform) — connects via ICLNET2 Kong OAG leased line
 */
@FeignClient(name = "crp-client", url = "${cims.iclnet2.crp-url}")
public interface CrpClient {
    @PostMapping("/submit")
    Map<String, Object> submitRiskAssessment(
        @RequestHeader("X-Request-ID") String requestId,
        @RequestBody Map<String, Object> payload);

    @GetMapping("/status/{referenceId}")
    Map<String, Object> getStatus(@PathVariable("referenceId") String referenceId);
}
