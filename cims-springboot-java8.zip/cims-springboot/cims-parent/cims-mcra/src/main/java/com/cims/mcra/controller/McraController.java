package com.cims.mcra.controller;

import com.cims.common.dto.ApiResponse;
import com.cims.mcra.dto.AssessmentRequest;
import com.cims.mcra.dto.AssessmentResponse;
import com.cims.mcra.service.McraService;
import com.cims.mcra.socket.TransUnionSocketService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/mcra")
@RequiredArgsConstructor
@Api(tags = "MCRA Service")
public class McraController {

    private final McraService mcraService;
    private final TransUnionSocketService tuSocketService;

    @PostMapping("/assess")
    @ApiOperation("Submit MCRA assessment")
    public ResponseEntity<ApiResponse<AssessmentResponse>> assess(
            @Valid @RequestBody AssessmentRequest request, Authentication auth) {
        String userId = (String) auth.getDetails();
        AssessmentResponse response = mcraService.assess(request, userId);
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(ApiResponse.success(response));
    }

    @GetMapping("/status/transunion")
    @ApiOperation("Check TransUnion socket connection status")
    public ResponseEntity<ApiResponse<Map<String, Object>>> tuStatus() {
        Map<String, Object> status = new HashMap<>();
        status.put("connected", tuSocketService.isConnected());
        status.put("connectionType", "SOCKET_VIA_ICLNET2_KONG_EAG");
        status.put("note", "TU is NOT migrating to API - uses socket connection per architecture");
        return ResponseEntity.ok(ApiResponse.success(status));
    }

    @GetMapping("/health")
    public ResponseEntity<ApiResponse<String>> health() {
        return ResponseEntity.ok(ApiResponse.success("MCRA service healthy", null));
    }
}
