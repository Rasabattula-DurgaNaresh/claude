package com.cims.mcra.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AssessmentResponse {
    private String assessmentId;
    private String status;
    private Integer compositeScore;
    private String riskGrade;
    private String crpReference;
    private String message;
}
