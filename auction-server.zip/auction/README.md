# Auction Server

Thread-safe concurrent auction system implemented from the class specification pseudo-code.

## Project Structure

```
auction/
├── pom.xml
└── src/
    ├── main/java/com/auction/
    │   ├── AuctionMain.java              ← Entry point / demo runner
    │   ├── model/
    │   │   └── Item.java                 ← Auction item entity
    │   ├── server/
    │   │   └── AuctionServer.java        ← Core singleton server (all 6 methods)
    │   └── client/
    │       ├── Seller.java               ← Seller thread
    │       └── Buyer.java                ← Buyer thread
    └── test/java/com/auction/server/
        └── AuctionServerTest.java        ← 26 unit tests (JUnit 5)
```

## Methods Implemented

| Method | Description |
|---|---|
| `submitItem` | Lists item for auction; validates price range, seller cap, server capacity |
| `getItems` | Returns snapshot of all active listings |
| `itemPrice` | Returns current highest bid or floor price for a listing |
| `itemUnbid` | Returns true if no bid has been placed on an item |
| `submitBid` | Places a bid; validates item availability, buyer cap, price floor |
| `checkBidStatus` | Returns status (1=won, 2=active, 3=lost, -1=not found) and cleans up expired auctions |

## Pre/Post Conditions Enforced

### submitItem
- **A** Price in range [0, 99]
- **B** Sellers with price > 75 capped at 3 items (disqualification)
- **C** Server total capacity not exceeded
- **D** Seller active items ≤ maxSellerItems (3)

### submitBid
- Item must be active
- Buyer must not exceed 20 active bids
- Buyer must not already hold the highest bid
- Bid must exceed current price

### checkBidStatus
- Returns 1 (won), 2 (active), 3 (lost), -1 (not found)
- Cleans up expired auctions from all maps
- Adjusts seller/buyer counts
- Updates revenue and sold count on win

## Running the Project

### Prerequisites
- Java 17+
- Maven 3.8+

### Run the demo
```bash
cd auction
mvn compile
mvn exec:java -Dexec.mainClass="com.auction.AuctionMain"
```

### Run tests
```bash
mvn test
```

### Build executable JAR
```bash
mvn package
java -jar target/auction-server.jar
```

## Thread Safety

- `AuctionServer` is a thread-safe singleton (double-checked locking)
- All mutating methods are `synchronized` on the server instance
- `getItems()` returns a defensive copy to prevent external mutation
- `Seller` and `Buyer` are `Runnable` implementations designed for `Thread` or `ExecutorService`
