package com.auction.model;

/**
 * Represents an auction item listed by a seller.
 */
public class Item {

    private final String sellerName;
    private final String itemName;
    private final int    lowestBiddingPrice;
    private final long   startTimeMs;
    private final int    biddingDurationMs;

    public Item(String sellerName, String itemName,
                int lowestBiddingPrice, int biddingDurationMs) {
        this.sellerName        = sellerName;
        this.itemName          = itemName;
        this.lowestBiddingPrice = lowestBiddingPrice;
        this.biddingDurationMs = biddingDurationMs;
        this.startTimeMs       = System.currentTimeMillis();
    }

    public String sellerName()         { return sellerName; }
    public String itemName()           { return itemName; }
    public int    lowestBiddingPrice() { return lowestBiddingPrice; }
    public int    biddingDurationMs()  { return biddingDurationMs; }

    /**
     * Returns true if the bidding window is still open.
     */
    public boolean isBiddingActive() {
        return System.currentTimeMillis() < startTimeMs + biddingDurationMs;
    }

    @Override
    public String toString() {
        return String.format("Item{seller='%s', name='%s', lowestBid=%d, active=%b}",
                sellerName, itemName, lowestBiddingPrice, isBiddingActive());
    }
}
