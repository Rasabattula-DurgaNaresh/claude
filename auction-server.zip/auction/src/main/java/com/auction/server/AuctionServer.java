package com.auction.server;

import com.auction.model.Item;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * AuctionServer — thread-safe singleton auction engine.
 *
 * Implements all methods specified in Class_Specifications_Pseudo_Code.pdf:
 *   submitItem, getItems, itemPrice, itemUnbid, submitBid, checkBidStatus
 */
public class AuctionServer {

    // ── Singleton ────────────────────────────────────────────────────────────

    private static AuctionServer instance;

    private AuctionServer() {}

    public static synchronized AuctionServer getInstance() {
        if (instance == null) {
            instance = new AuctionServer();
        }
        return instance;
    }

    // ── Server Configuration ─────────────────────────────────────────────────

    /** Maximum total items the server can hold at one time. */
    private static final int SERVER_CAPACITY   = 100;

    /** Maximum items a single seller may have active simultaneously. */
    private static final int MAX_SELLER_ITEMS  = 3;

    /** Maximum items a single buyer may be actively bidding on. */
    private static final int MAX_BUYER_BIDS    = 20;

    /** Highest allowed lowestBiddingPrice. */
    private static final int MAX_BIDDING_PRICE = 99;

    // ── State ─────────────────────────────────────────────────────────────────

    /** Auto-incrementing listing ID counter. */
    private int lastListingId = 0;

    /** Map of listingId → Item (includes historical / expired items). */
    private final Map<Integer, Item> itemsAndIds = new HashMap<>();

    /** Active items currently open for bidding. */
    private final ArrayList<Item> itemsUpForBidding = new ArrayList<>();

    /** Seller name → number of active listings. */
    private final Map<String, Integer> itemsPerSeller = new HashMap<>();

    /** Buyer name → number of items currently being bid on. */
    private final Map<String, Integer> itemsPerBuyer = new HashMap<>();

    /** listingId → current highest bid amount. */
    private final Map<Integer, Integer> highestBids = new HashMap<>();

    /** listingId → name of current highest bidder. */
    private final Map<Integer, String> highestBidders = new HashMap<>();

    /** Seller name → count of their expired/unsold listings. */
    private final Map<String, Integer> expiredItemsPerSeller = new HashMap<>();

    /** Total revenue earned from successfully completed auctions. */
    private double revenue = 0;

    /** Total number of items sold. */
    private int soldItemsCount = 0;

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Lists a new item for auction.
     *
     * Pre-conditions:
     *   A. lowestBiddingPrice must be in range [0, 99]
     *   B. Seller with price > 75 may not have more than 3 active listings,
     *      and must not be disqualified
     *   C. Total active items must be below server capacity
     *   D. Seller's active item count must be below maxSellerItems
     *
     * Post-conditions:
     *   Returns the new listing ID on success, -1 on failure.
     *   Increments seller's active item count and adds item to active list.
     */
    public synchronized int submitItem(String sellerName, String itemName,
                                       int lowestBiddingPrice, int biddingDurationMs) {

        // Pre-condition A — price range
        if (lowestBiddingPrice < 0 || lowestBiddingPrice > MAX_BIDDING_PRICE) {
            System.err.println("[submitItem] REJECTED: lowestBiddingPrice " +
                    lowestBiddingPrice + " out of range [0, 99].");
            return -1;
        }

        // Pre-condition C — server capacity
        if (itemsUpForBidding.size() >= SERVER_CAPACITY) {
            System.err.println("[submitItem] REJECTED: server at capacity (" +
                    SERVER_CAPACITY + ").");
            return -1;
        }

        // Pre-condition B — disqualification check for high-price sellers
        int currentSellerItems = itemsPerSeller.getOrDefault(sellerName, 0);
        if (lowestBiddingPrice > 75 && currentSellerItems >= MAX_SELLER_ITEMS) {
            System.err.println("[submitItem] REJECTED: seller '" + sellerName +
                    "' is disqualified (>3 items with price >75).");
            return -1;
        }

        // Pre-condition D — seller item cap
        if (currentSellerItems >= MAX_SELLER_ITEMS) {
            System.err.println("[submitItem] REJECTED: seller '" + sellerName +
                    "' already has " + currentSellerItems + " active items.");
            return -1;
        }

        // ── Create the listing ──────────────────────────────────────────────

        lastListingId++;
        Item item = new Item(sellerName, itemName, lowestBiddingPrice, biddingDurationMs);

        // Invariant — only add if not already in the active list
        if (!itemsUpForBidding.contains(item)) {
            itemsAndIds.put(lastListingId, item);
            itemsUpForBidding.add(item);
        }

        // Update seller's active item count
        itemsPerSeller.put(sellerName, currentSellerItems + 1);

        System.out.println("[submitItem] Listed '" + itemName + "' by '" + sellerName +
                "' → listingId=" + lastListingId);
        return lastListingId;
    }

    /**
     * Returns a snapshot of all items currently up for bidding.
     */
    public ArrayList<Item> getItems() {
        return new ArrayList<>(itemsUpForBidding);
    }

    /**
     * Returns the current price for a listing.
     *
     * Pre-condition : listingId must be valid (non-negative integer).
     * Post-conditions:
     *   -1               → listing not found
     *   highestBid value → if a bid exists
     *   lowestBidPrice   → if no bids yet
     *
     * @throws NumberFormatException if listingId is negative (invalid).
     */
    public int itemPrice(int listingId) {
        if (listingId < 0) {
            throw new NumberFormatException("listingId must be non-negative, got: " + listingId);
        }

        Item item = itemsAndIds.get(listingId);
        if (item == null) {
            return -1;
        }

        // Return highest bid if one exists, otherwise the floor price
        if (highestBids.containsKey(listingId)) {
            return highestBids.get(listingId);
        }
        return item.lowestBiddingPrice();
    }

    /**
     * Returns whether an item has received any bids.
     *
     * Post-conditions:
     *   true  → no bid has been placed
     *   false → at least one bid exists
     */
    public synchronized boolean itemUnbid(int listingId) {
        Item item = itemsAndIds.get(listingId);
        boolean unbid = true;

        if (item != null) {
            unbid = true;
            // If the listing appears in highestBids it has been bid upon
            if (highestBids.containsKey(listingId)) {
                unbid = false;
            }
        }
        return unbid;
    }

    /**
     * Submits a bid from a buyer on a listed item.
     *
     * Pre-conditions:
     *   a. Item must be actively available for bidding
     *   b. Buyer must not exceed MAX_BUYER_BIDS active bids
     *   c. Buyer must not already hold the highest bid on this item
     *   d. Bid amount must be strictly greater than the current price
     *
     * Post-conditions:
     *   true  → bid accepted; counters updated
     *   false → bid rejected
     */
    public synchronized boolean submitBid(String bidderName, int listingId, int biddingAmount) {

        // Pre-condition a — item must be in the active list
        Item item = null;
        for (Item i : itemsUpForBidding) {
            if (itemsAndIds.get(listingId) == i) {
                item = i;
                break;
            }
        }
        if (item == null) {
            System.err.println("[submitBid] REJECTED: listingId " + listingId + " not active.");
            return false;
        }

        // Pre-condition b — buyer bid cap
        int buyerBidCount = itemsPerBuyer.getOrDefault(bidderName, 0);
        if (buyerBidCount >= MAX_BUYER_BIDS) {
            System.err.println("[submitBid] REJECTED: '" + bidderName +
                    "' already bidding on " + buyerBidCount + " items.");
            return false;
        }

        // Pre-condition c — buyer must not already be the highest bidder
        String currentHighestBidder = highestBidders.get(listingId);
        if (bidderName.equals(currentHighestBidder)) {
            System.err.println("[submitBid] REJECTED: '" + bidderName +
                    "' already holds highest bid on listing " + listingId);
            return false;
        }

        // Pre-condition d — new bid must exceed current price
        int currentPrice = itemPrice(listingId);
        if (biddingAmount <= currentPrice) {
            System.err.println("[submitBid] REJECTED: bid " + biddingAmount +
                    " must exceed current price " + currentPrice);
            return false;
        }

        // ── Accept the bid ──────────────────────────────────────────────────

        // Increment new highest bidder's count
        if (itemsPerBuyer.get(bidderName) == null) {
            itemsPerBuyer.put(bidderName, 1);
        } else {
            itemsPerBuyer.put(bidderName, itemsPerBuyer.get(bidderName) + 1);
        }

        // Decrement former highest bidder's count (if there was one)
        if (currentHighestBidder != null && itemsPerBuyer.containsKey(currentHighestBidder)) {
            itemsPerBuyer.put(currentHighestBidder,
                    itemsPerBuyer.get(currentHighestBidder) - 1);
        }

        highestBids.put(listingId, biddingAmount);
        highestBidders.put(listingId, bidderName);

        System.out.println("[submitBid] ACCEPTED: '" + bidderName + "' bid " +
                biddingAmount + " on listing " + listingId);
        return true;
    }

    /**
     * Checks the bid status of a listing from a specific bidder's perspective.
     *
     * Pre-conditions:
     *   a. listingId must exist in the historical item list (itemsAndIds)
     *   b. Item should be available in the historical items list
     *
     * Post-conditions / Return values:
     *    1 → bidding has ended AND bidderName is the winner
     *    2 → bidding is still active (item accepting bids)
     *    3 → bidding ended AND bidderName did NOT win
     *   -1 → listing not found in historical list
     *
     * Side-effects on expiry:
     *   - Removes item from active list and highest bids/bidders maps
     *   - Adjusts seller and buyer item counts
     *   - Increments revenue and soldItemsCount on a win
     *   - Records expired listing per seller on a loss
     *
     * @throws NumberFormatException if listingId is negative.
     */
    public synchronized int checkBidStatus(String bidderName, int listingId) {
        if (listingId < 0) {
            throw new NumberFormatException("listingId must be non-negative, got: " + listingId);
        }

        // Pre-condition — listing must exist historically
        if (!itemsAndIds.containsKey(listingId)) {
            return -1;
        }

        Item item = itemsAndIds.get(listingId);

        // Case 2 — bidding window still open
        if (itemsUpForBidding.contains(item) && item.isBiddingActive()) {
            return 2;
        }

        String winner = highestBidders.get(listingId);

        // ── Shared clean-up for expired listings ────────────────────────────
        // Remove from active list
        itemsUpForBidding.remove(item);

        // Decrement seller's active count
        String sellerName    = item.sellerName();
        int    sellerCount   = itemsPerSeller.getOrDefault(sellerName, 1);
        itemsPerSeller.put(sellerName, Math.max(0, sellerCount - 1));

        // Decrement buyer's active bid count
        int buyerCount = itemsPerBuyer.getOrDefault(bidderName, 1);
        itemsPerBuyer.put(bidderName, Math.max(0, buyerCount - 1));

        // Case 1 — bidding over, this bidder won
        if (bidderName.equals(winner)) {
            int winningBid = highestBids.getOrDefault(listingId, item.lowestBiddingPrice());
            highestBidders.remove(listingId);
            highestBids.remove(listingId);

            revenue        += winningBid;
            soldItemsCount += 1;

            System.out.println("[checkBidStatus] '" + bidderName +
                    "' WON listing " + listingId + " for " + winningBid);
            return 1;
        }

        // Case 3 — bidding over, this bidder did NOT win
        highestBidders.remove(listingId);
        highestBids.remove(listingId);

        // Track expired items per seller
        int expiredCount = expiredItemsPerSeller.getOrDefault(sellerName, 0);
        expiredItemsPerSeller.put(sellerName, expiredCount + 1);

        System.out.println("[checkBidStatus] '" + bidderName +
                "' did NOT win listing " + listingId +
                ". Winner was: " + (winner != null ? winner : "nobody"));
        return 3;
    }

    // ── Diagnostics ───────────────────────────────────────────────────────────

    public double getRevenue()        { return revenue; }
    public int    getSoldItemsCount() { return soldItemsCount; }

    public Map<String, Integer> getItemsPerSeller()        { return new HashMap<>(itemsPerSeller); }
    public Map<String, Integer> getItemsPerBuyer()         { return new HashMap<>(itemsPerBuyer); }
    public Map<String, Integer> getExpiredItemsPerSeller() { return new HashMap<>(expiredItemsPerSeller); }

    /** Resets the server state — useful for testing. */
    public synchronized void reset() {
        lastListingId = 0;
        itemsAndIds.clear();
        itemsUpForBidding.clear();
        itemsPerSeller.clear();
        itemsPerBuyer.clear();
        highestBids.clear();
        highestBidders.clear();
        expiredItemsPerSeller.clear();
        revenue        = 0;
        soldItemsCount = 0;
    }
}
