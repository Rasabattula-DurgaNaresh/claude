package com.auction.client;

import com.auction.server.AuctionServer;

/**
 * Seller — a runnable that submits items to the auction server concurrently.
 *
 * Each Seller thread attempts to list a configurable number of items.
 * All server calls are thread-safe via AuctionServer's synchronized methods.
 */
public class Seller implements Runnable {

    private final String   sellerName;
    private final String[] itemNames;
    private final int[]    prices;
    private final int      biddingDurationMs;

    /**
     * @param sellerName       Unique seller identifier
     * @param itemNames        Names of items to list
     * @param prices           Corresponding lowest bidding prices
     * @param biddingDurationMs Duration of each auction in milliseconds
     */
    public Seller(String sellerName, String[] itemNames,
                  int[] prices, int biddingDurationMs) {
        this.sellerName       = sellerName;
        this.itemNames        = itemNames;
        this.prices           = prices;
        this.biddingDurationMs = biddingDurationMs;
    }

    @Override
    public void run() {
        AuctionServer server = AuctionServer.getInstance();

        for (int i = 0; i < itemNames.length; i++) {
            int listingId = server.submitItem(
                    sellerName, itemNames[i], prices[i], biddingDurationMs);

            if (listingId != -1) {
                System.out.printf("[Seller:%s] Listed '%s' → listingId=%d%n",
                        sellerName, itemNames[i], listingId);
            } else {
                System.out.printf("[Seller:%s] FAILED to list '%s'%n",
                        sellerName, itemNames[i]);
            }

            // Small pause to simulate real-world timing
            try { Thread.sleep(50); } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }
}
