package com.auction.client;

import com.auction.model.Item;
import com.auction.server.AuctionServer;

import java.util.ArrayList;
import java.util.List;

/**
 * Buyer — a runnable that browses active listings and places bids concurrently.
 *
 * Each Buyer thread:
 *   1. Fetches the current active item list
 *   2. Attempts to bid on every item it can afford
 *   3. Polls bid statuses and prints results
 */
public class Buyer implements Runnable {

    private final String buyerName;
    private final int    budget;       // maximum bid per item
    private final int    bidIncrement; // how much above current price to bid

    private final List<Integer> myListingIds = new ArrayList<>();

    /**
     * @param buyerName    Unique buyer identifier
     * @param budget       Maximum amount this buyer will bid on any single item
     * @param bidIncrement Amount to add above current price when bidding
     */
    public Buyer(String buyerName, int budget, int bidIncrement) {
        this.buyerName    = buyerName;
        this.budget       = budget;
        this.bidIncrement = bidIncrement;
    }

    @Override
    public void run() {
        AuctionServer server = AuctionServer.getInstance();

        // Phase 1 — browse and bid
        ArrayList<Item> items = server.getItems();

        // We need listing IDs — iterate through known range
        // (In production this would come from a dedicated index API)
        for (int id = 1; id <= 50; id++) {
            int currentPrice = server.itemPrice(id);
            if (currentPrice == -1) continue; // listing doesn't exist

            int myBid = currentPrice + bidIncrement;
            if (myBid > budget) continue;     // can't afford it

            boolean won = server.submitBid(buyerName, id, myBid);
            if (won) {
                myListingIds.add(id);
                System.out.printf("[Buyer:%s] Bid %d on listing %d%n",
                        buyerName, myBid, id);
            }
        }

        // Phase 2 — wait for auctions to complete then check status
        try { Thread.sleep(500); } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        for (int listingId : myListingIds) {
            int status = server.checkBidStatus(buyerName, listingId);
            switch (status) {
                case  1 -> System.out.printf("[Buyer:%s] WON listing %d!%n",
                                buyerName, listingId);
                case  2 -> System.out.printf("[Buyer:%s] Listing %d still active.%n",
                                buyerName, listingId);
                case  3 -> System.out.printf("[Buyer:%s] Did NOT win listing %d.%n",
                                buyerName, listingId);
                case -1 -> System.out.printf("[Buyer:%s] Listing %d not found.%n",
                                buyerName, listingId);
                default -> System.out.printf("[Buyer:%s] Unknown status %d for listing %d.%n",
                                buyerName, status, listingId);
            }
        }
    }
}
