package com.auction;

import com.auction.client.Buyer;
import com.auction.client.Seller;
import com.auction.server.AuctionServer;

import java.util.ArrayList;
import java.util.List;

/**
 * AuctionMain — demonstrates concurrent sellers and buyers against AuctionServer.
 *
 * Run order:
 *   1. Multiple Seller threads list items concurrently
 *   2. After a short delay, multiple Buyer threads browse and bid concurrently
 *   3. Buyers poll status after auctions expire
 *   4. Final statistics are printed
 */
public class AuctionMain {

    public static void main(String[] args) throws InterruptedException {

        AuctionServer server = AuctionServer.getInstance();

        System.out.println("=== Auction Server Starting ===\n");

        // ── 1. Launch Seller threads ─────────────────────────────────────────

        List<Thread> sellerThreads = new ArrayList<>();

        // Seller A — 2 affordable items
        sellerThreads.add(new Thread(new Seller(
                "Alice",
                new String[]{"Laptop", "Keyboard"},
                new int[]{50, 20},
                800  // 800ms auction duration
        ), "Thread-Seller-Alice"));

        // Seller B — 2 items (one high-price to test pre-condition B)
        sellerThreads.add(new Thread(new Seller(
                "Bob",
                new String[]{"Monitor", "Desk"},
                new int[]{80, 30},
                800
        ), "Thread-Seller-Bob"));

        // Seller C — tries to list 4 items (should be rejected at item 4)
        sellerThreads.add(new Thread(new Seller(
                "Carol",
                new String[]{"Chair", "Headset", "Mouse", "ExtraItem"},
                new int[]{10, 15, 25, 10},
                800
        ), "Thread-Seller-Carol"));

        // Seller D — invalid price (should be rejected)
        sellerThreads.add(new Thread(new Seller(
                "Dave",
                new String[]{"OutOfRangeItem"},
                new int[]{150},   // > 99 — invalid
                800
        ), "Thread-Seller-Dave"));

        sellerThreads.forEach(Thread::start);
        sellerThreads.forEach(t -> {
            try { t.join(); } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });

        System.out.println("\n--- All sellers done. Active listings: " +
                server.getItems().size() + " ---\n");

        // ── 2. Print active listings ─────────────────────────────────────────

        server.getItems().forEach(item ->
                System.out.println("  • " + item));
        System.out.println();

        // ── 3. Launch Buyer threads ──────────────────────────────────────────

        List<Thread> buyerThreads = new ArrayList<>();

        buyerThreads.add(new Thread(new Buyer("Eve",   90, 5), "Thread-Buyer-Eve"));
        buyerThreads.add(new Thread(new Buyer("Frank", 60, 3), "Thread-Buyer-Frank"));
        buyerThreads.add(new Thread(new Buyer("Grace", 99, 7), "Thread-Buyer-Grace"));

        buyerThreads.forEach(Thread::start);
        buyerThreads.forEach(t -> {
            try { t.join(); } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });

        // ── 4. Wait for auctions to expire then check all statuses ───────────

        System.out.println("\n--- Waiting for all auctions to expire... ---\n");
        Thread.sleep(1000); // ensure 800ms duration has passed

        // A second buyer round-trip to collect final results
        for (int listingId = 1; listingId <= 10; listingId++) {
            int price = server.itemPrice(listingId);
            if (price != -1) {
                System.out.printf("Listing %d final price: %d | unbid: %b%n",
                        listingId, price, server.itemUnbid(listingId));
            }
        }

        // ── 5. Server statistics ─────────────────────────────────────────────

        System.out.println("\n=== Auction Server Statistics ===");
        System.out.printf("  Total revenue     : %.2f%n", server.getRevenue());
        System.out.printf("  Items sold        : %d%n",   server.getSoldItemsCount());
        System.out.printf("  Seller counts     : %s%n",   server.getItemsPerSeller());
        System.out.printf("  Buyer bids active : %s%n",   server.getItemsPerBuyer());
        System.out.printf("  Expired per seller: %s%n",   server.getExpiredItemsPerSeller());
        System.out.println("=================================");
    }
}
