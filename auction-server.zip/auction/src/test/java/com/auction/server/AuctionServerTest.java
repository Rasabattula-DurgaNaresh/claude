package com.auction.server;

import com.auction.model.Item;
import org.junit.jupiter.api.*;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for AuctionServer — covers all six methods from the spec.
 * Each test resets the singleton to ensure isolation.
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class AuctionServerTest {

    private AuctionServer server;

    @BeforeEach
    void setUp() {
        server = AuctionServer.getInstance();
        server.reset(); // clean slate for each test
    }

    // ── submitItem ────────────────────────────────────────────────────────────

    @Test
    @org.junit.jupiter.api.Order(1)
    @DisplayName("submitItem: valid item returns positive listing ID")
    void submitItem_validItem_returnsListingId() {
        int id = server.submitItem("Alice", "Laptop", 50, 5000);
        assertTrue(id > 0, "Expected a positive listing ID");
    }

    @Test
    @org.junit.jupiter.api.Order(2)
    @DisplayName("submitItem: price above 99 is rejected")
    void submitItem_priceOutOfRange_returnsMinusOne() {
        int id = server.submitItem("Alice", "Laptop", 150, 5000);
        assertEquals(-1, id);
    }

    @Test
    @org.junit.jupiter.api.Order(3)
    @DisplayName("submitItem: price below 0 is rejected")
    void submitItem_negativePriceIsRejected() {
        int id = server.submitItem("Alice", "Laptop", -5, 5000);
        assertEquals(-1, id);
    }

    @Test
    @org.junit.jupiter.api.Order(4)
    @DisplayName("submitItem: seller cannot exceed max active items (3)")
    void submitItem_sellerExceedsMaxItems_rejected() {
        server.submitItem("Alice", "Item1", 10, 5000);
        server.submitItem("Alice", "Item2", 20, 5000);
        server.submitItem("Alice", "Item3", 30, 5000);

        int id = server.submitItem("Alice", "Item4", 40, 5000);
        assertEquals(-1, id, "Fourth item should be rejected");
    }

    @Test
    @org.junit.jupiter.api.Order(5)
    @DisplayName("submitItem: high-price seller (>75) limited to 3 items")
    void submitItem_highPriceSeller_disqualifiedAfter3() {
        server.submitItem("Bob", "A", 80, 5000);
        server.submitItem("Bob", "B", 85, 5000);
        server.submitItem("Bob", "C", 90, 5000);

        int id = server.submitItem("Bob", "D", 95, 5000);
        assertEquals(-1, id, "High-price seller should be disqualified after 3 items");
    }

    @Test
    @org.junit.jupiter.api.Order(6)
    @DisplayName("submitItem: listing IDs increment correctly")
    void submitItem_listingIdsAreSequential() {
        int id1 = server.submitItem("Alice", "A", 10, 5000);
        int id2 = server.submitItem("Bob",   "B", 20, 5000);
        assertEquals(id1 + 1, id2, "Listing IDs should be sequential");
    }

    // ── getItems ──────────────────────────────────────────────────────────────

    @Test
    @org.junit.jupiter.api.Order(7)
    @DisplayName("getItems: returns all active listings")
    void getItems_returnsAllActiveItems() {
        server.submitItem("Alice", "Laptop",  50, 5000);
        server.submitItem("Bob",   "Monitor", 30, 5000);

        ArrayList<Item> items = server.getItems();
        assertEquals(2, items.size());
    }

    @Test
    @org.junit.jupiter.api.Order(8)
    @DisplayName("getItems: returns empty list when no items submitted")
    void getItems_emptyWhenNoItems() {
        assertTrue(server.getItems().isEmpty());
    }

    // ── itemPrice ─────────────────────────────────────────────────────────────

    @Test
    @org.junit.jupiter.api.Order(9)
    @DisplayName("itemPrice: returns lowestBiddingPrice when no bids yet")
    void itemPrice_noBids_returnsFloorPrice() {
        int id = server.submitItem("Alice", "Laptop", 50, 5000);
        assertEquals(50, server.itemPrice(id));
    }

    @Test
    @org.junit.jupiter.api.Order(10)
    @DisplayName("itemPrice: returns -1 for unknown listing")
    void itemPrice_unknownId_returnsMinusOne() {
        assertEquals(-1, server.itemPrice(9999));
    }

    @Test
    @org.junit.jupiter.api.Order(11)
    @DisplayName("itemPrice: throws NumberFormatException for negative id")
    void itemPrice_negativeId_throwsNumberFormatException() {
        assertThrows(NumberFormatException.class, () -> server.itemPrice(-1));
    }

    @Test
    @org.junit.jupiter.api.Order(12)
    @DisplayName("itemPrice: returns highest bid after a bid is placed")
    void itemPrice_afterBid_returnsHighestBid() {
        int id = server.submitItem("Alice", "Laptop", 50, 5000);
        server.submitBid("Eve", id, 60);
        assertEquals(60, server.itemPrice(id));
    }

    // ── itemUnbid ─────────────────────────────────────────────────────────────

    @Test
    @org.junit.jupiter.api.Order(13)
    @DisplayName("itemUnbid: returns true when no bids placed")
    void itemUnbid_noBids_returnsTrue() {
        int id = server.submitItem("Alice", "Laptop", 50, 5000);
        assertTrue(server.itemUnbid(id));
    }

    @Test
    @org.junit.jupiter.api.Order(14)
    @DisplayName("itemUnbid: returns false after a bid is placed")
    void itemUnbid_afterBid_returnsFalse() {
        int id = server.submitItem("Alice", "Laptop", 50, 5000);
        server.submitBid("Eve", id, 60);
        assertFalse(server.itemUnbid(id));
    }

    // ── submitBid ─────────────────────────────────────────────────────────────

    @Test
    @org.junit.jupiter.api.Order(15)
    @DisplayName("submitBid: valid bid is accepted")
    void submitBid_valid_returnsTrue() {
        int id = server.submitItem("Alice", "Laptop", 50, 5000);
        assertTrue(server.submitBid("Eve", id, 60));
    }

    @Test
    @org.junit.jupiter.api.Order(16)
    @DisplayName("submitBid: bid must exceed current price")
    void submitBid_equalToCurrentPrice_rejected() {
        int id = server.submitItem("Alice", "Laptop", 50, 5000);
        assertFalse(server.submitBid("Eve", id, 50), "Bid equal to floor should be rejected");
    }

    @Test
    @org.junit.jupiter.api.Order(17)
    @DisplayName("submitBid: highest bidder cannot outbid themselves")
    void submitBid_sameHighestBidder_rejected() {
        int id = server.submitItem("Alice", "Laptop", 50, 5000);
        server.submitBid("Eve", id, 60);
        assertFalse(server.submitBid("Eve", id, 70), "Existing highest bidder should be rejected");
    }

    @Test
    @org.junit.jupiter.api.Order(18)
    @DisplayName("submitBid: outbidding replaces the highest bidder")
    void submitBid_outbid_replacesHighestBidder() {
        int id = server.submitItem("Alice", "Laptop", 50, 5000);
        server.submitBid("Eve",   id, 60);
        assertTrue(server.submitBid("Frank", id, 70));
        assertEquals(70, server.itemPrice(id));
    }

    @Test
    @org.junit.jupiter.api.Order(19)
    @DisplayName("submitBid: returns false for unknown listing ID")
    void submitBid_unknownListing_returnsFalse() {
        assertFalse(server.submitBid("Eve", 9999, 50));
    }

    // ── checkBidStatus ────────────────────────────────────────────────────────

    @Test
    @org.junit.jupiter.api.Order(20)
    @DisplayName("checkBidStatus: returns 2 while auction is still active")
    void checkBidStatus_auctionActive_returns2() {
        int id = server.submitItem("Alice", "Laptop", 50, 5000); // 5 second window
        server.submitBid("Eve", id, 60);
        assertEquals(2, server.checkBidStatus("Eve", id));
    }

    @Test
    @org.junit.jupiter.api.Order(21)
    @DisplayName("checkBidStatus: returns -1 for unknown listing ID")
    void checkBidStatus_unknownId_returnsMinusOne() {
        assertEquals(-1, server.checkBidStatus("Eve", 9999));
    }

    @Test
    @org.junit.jupiter.api.Order(22)
    @DisplayName("checkBidStatus: returns 1 when bidder wins after expiry")
    void checkBidStatus_winnerAfterExpiry_returns1() throws InterruptedException {
        int id = server.submitItem("Alice", "Laptop", 50, 200); // 200ms duration
        server.submitBid("Eve", id, 60);
        Thread.sleep(300); // let auction expire
        assertEquals(1, server.checkBidStatus("Eve", id));
    }

    @Test
    @org.junit.jupiter.api.Order(23)
    @DisplayName("checkBidStatus: returns 3 when bidder loses after expiry")
    void checkBidStatus_loserAfterExpiry_returns3() throws InterruptedException {
        int id = server.submitItem("Alice", "Laptop", 50, 200);
        server.submitBid("Eve",   id, 60);
        server.submitBid("Frank", id, 70);
        Thread.sleep(300);
        assertEquals(3, server.checkBidStatus("Eve", id));
    }

    @Test
    @org.junit.jupiter.api.Order(24)
    @DisplayName("checkBidStatus: revenue increments on successful sale")
    void checkBidStatus_winner_incrementsRevenue() throws InterruptedException {
        int id = server.submitItem("Alice", "Laptop", 50, 200);
        server.submitBid("Eve", id, 75);
        Thread.sleep(300);
        server.checkBidStatus("Eve", id);
        assertEquals(75.0, server.getRevenue(), 0.001);
        assertEquals(1, server.getSoldItemsCount());
    }

    @Test
    @org.junit.jupiter.api.Order(25)
    @DisplayName("checkBidStatus: throws NumberFormatException for negative listingId")
    void checkBidStatus_negativeId_throwsNumberFormatException() {
        assertThrows(NumberFormatException.class,
                () -> server.checkBidStatus("Eve", -1));
    }

    // ── Concurrency smoke test ────────────────────────────────────────────────

    @Test
    @org.junit.jupiter.api.Order(26)
    @DisplayName("Concurrent sellers: no duplicate listing IDs under thread contention")
    void concurrency_multipleSellers_uniqueListingIds() throws InterruptedException {
        int threadCount = 3;
        Thread[] threads = new Thread[threadCount];
        int[] ids = new int[threadCount];

        for (int i = 0; i < threadCount; i++) {
            final int idx = i;
            threads[i] = new Thread(() -> {
                ids[idx] = server.submitItem("Seller" + idx, "Item" + idx, idx * 10 + 5, 5000);
            });
        }

        for (Thread t : threads) t.start();
        for (Thread t : threads) t.join();

        // All accepted IDs should be distinct positive integers
        long uniqueIds = java.util.Arrays.stream(ids)
                .filter(id -> id > 0)
                .distinct()
                .count();
        long accepted = java.util.Arrays.stream(ids).filter(id -> id > 0).count();
        assertEquals(accepted, uniqueIds, "Concurrent submits should produce unique listing IDs");
    }
}
